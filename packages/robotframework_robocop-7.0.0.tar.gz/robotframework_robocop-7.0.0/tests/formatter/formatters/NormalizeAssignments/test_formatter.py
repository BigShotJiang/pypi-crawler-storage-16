import pytest

from tests.formatter import FormatterAcceptanceTest


class TestNormalizeAssignments(FormatterAcceptanceTest):
    FORMATTER_NAME = "NormalizeAssignments"

    @pytest.mark.parametrize(
        "filename", ["common_remove.robot", "common_equal_sign.robot", "common_space_and_equal_sign.robot"]
    )
    def test_autodetect(self, filename):
        self.compare(source=filename)

    @pytest.mark.parametrize("filename", ["common_remove", "common_equal_sign", "common_space_and_equal_sign"])
    def test_autodetect_variables(self, filename):
        self.compare(
            source=filename + ".robot",
            expected=filename + "_variables.robot",
            configure=[f"{self.FORMATTER_NAME}.equal_sign_type_variables=autodetect"],
        )

    def test_remove(self):
        self.compare(
            source="tests.robot", expected="remove.robot", configure=[f"{self.FORMATTER_NAME}.equal_sign_type=remove"]
        )

    def test_add_equal_sign(self):
        self.compare(
            source="tests.robot",
            expected="equal_sign.robot",
            configure=[f"{self.FORMATTER_NAME}.equal_sign_type=equal_sign"],
            test_on_version=">=6",
        )

    def test_add_equal_sign_v4(self):
        """Robot Framework <6 does not support assigning to attributes yet."""
        self.compare(
            source="tests.robot",
            expected="equal_sign_v4.robot",
            configure=[f"{self.FORMATTER_NAME}.equal_sign_type=equal_sign"],
            test_on_version="<6",
        )

    def test_add_space_and_equal_sign(self):
        self.compare(
            source="tests.robot",
            expected="space_and_equal_sign.robot",
            configure=[f"{self.FORMATTER_NAME}.equal_sign_type=space_and_equal_sign"],
            test_on_version=">=6",
        )

    # TODO check test error output
    # @pytest.mark.parametrize("param_name", ["equal_sign_type", "equal_sign_type_variables"])
    # def test_invalid_equal_sign_type(self, param_name):
    #     result = self.run_tidy(
    #         select=[self.FORMATTER_NAME],
    #         configure=[f"{self.FORMATTER_NAME}.{param_name}=="],
    #         source="tests.robot",
    #         exit_code=1,
    #     )
    #     expected_output = (
    #         f"Error: {self.FORMATTER_NAME}: Invalid '=' parameter value: '{param_name}'. "
    #         "Possible values:\n    remove\n    equal_sign\n    space_and_equal_sign\n"
    #     )
    #     assert expected_output == result.output

    def test_disablers(self):
        self.compare(source="disablers.robot", not_modified=True)

    @pytest.mark.parametrize("equal_sign_type", ["remove", "autodetect", "equal_sign", "space_and_equal_sign"])
    def test_var_syntax(self, equal_sign_type):
        self.compare(
            source="var.robot",
            expected=f"var_{equal_sign_type}.robot",
            configure=[f"{self.FORMATTER_NAME}.equal_sign_type={equal_sign_type}"],
            test_on_version=">=7",
        )

    def test_bug_1407(self):
        self.compare(source="most_common_attr.robot", not_modified=True)
