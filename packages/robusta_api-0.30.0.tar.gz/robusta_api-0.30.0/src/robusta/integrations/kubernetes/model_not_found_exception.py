class ModelNotFoundException(Exception):
    """Kubernetes model not found"""

    pass
