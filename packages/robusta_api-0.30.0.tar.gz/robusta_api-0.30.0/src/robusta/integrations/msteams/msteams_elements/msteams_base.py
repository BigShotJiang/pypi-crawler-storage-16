class MsTeamsBase:
    def __init__(self, map_value: dict):
        self.map_value = map_value

    def get_map_value(self) -> dict:
        return self.map_value
