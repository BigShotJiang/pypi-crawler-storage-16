"""
Rohkun CLI v3 - Client-side code analysis tool with UI inspection
"""

__version__ = "3.3.3"
