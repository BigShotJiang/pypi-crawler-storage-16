#############
 About Rohmu
#############

.. include:: ../README.rst
   :start-after: start-include-features
   :end-before: end-include-features

.. include:: ../README.rst
   :start-after: start-include-links
