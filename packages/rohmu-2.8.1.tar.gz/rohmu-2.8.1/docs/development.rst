#############
 Development
#############

.. include:: ../README.rst
   :start-after: start-include-requirements
   :end-before: end-include-requirements

.. include:: ../README.rst
   :start-after: start-include-building-the-package
   :end-before: end-include-building-the-package

.. include:: ../README.rst
   :start-after: start-include-links
