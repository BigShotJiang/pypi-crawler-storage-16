.. toctree::
   :maxdepth: 2
   :caption: Contents
   :hidden:

   autodoc
   about
   usage
   development
