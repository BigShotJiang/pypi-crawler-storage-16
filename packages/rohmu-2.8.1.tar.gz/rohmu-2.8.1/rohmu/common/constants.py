# Copyright (c) 2023 Aiven, Helsinki, Finland. https://aiven.io/

IO_BLOCK_SIZE = 2**20  # 1 MiB
