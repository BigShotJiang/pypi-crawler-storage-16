#######
 Rohmu
#######

.. include:: toc.rst

.. include:: ../README.rst
   :start-after: start-include-intro
   :end-before: end-include-intro

.. include:: ../README.rst
   :start-after: start-include-license
   :end-before: end-include-license

.. include:: ../README.rst
   :start-after: start-include-trademarks-and-credits
   :end-before: end-include-trademarks-and-credits

.. include:: ../README.rst
   :start-after: start-include-contact
   :end-before: end-include-contact

.. include:: ../README.rst
   :start-after: start-include-copyright
   :end-before: end-include-copyright

.. include:: ../README.rst
   :start-after: start-include-links
