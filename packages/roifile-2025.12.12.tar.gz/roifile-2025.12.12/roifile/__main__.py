# roifile/__main__.py

"""Roifile package command line script."""

import sys

from .roifile import main

sys.exit(main())
