import logging
from collections import OrderedDict
from datetime import datetime, timedelta
from pathlib import Path
from unittest import mock

import numpy as np
import pytest
import xarray as xr

from roms_tools.download import download_test_data
from roms_tools.setup.lat_lon_datasets import (
    GLORYS_GLOBAL_GRID_PATH,
    CESMBGCDataset,
    ERA5ARCODataset,
    ERA5Correction,
    GLORYSDataset,
    GLORYSDefaultDataset,
    LatLonDataset,
    TPXODataset,
    _concatenate_longitudes,
    choose_subdomain,
    get_glorys_bounds,
)
from roms_tools.setup.surface_forcing import DEFAULT_ERA5_ARCO_PATH
from roms_tools.setup.utils import get_target_coords
from roms_tools.tests.test_setup.utils import download_regional_and_bigger

try:
    import copernicusmarine  # type: ignore
except ImportError:
    copernicusmarine = None


@pytest.fixture
def global_dataset():
    lon = np.linspace(0, 359, 360)
    lat = np.linspace(-90, 90, 180)
    depth = np.linspace(0, 2000, 10)
    time = [
        np.datetime64("2022-01-01T00:00:00"),
        np.datetime64("2022-01-02T00:00:00"),
        np.datetime64("2022-01-03T00:00:00"),
        np.datetime64("2022-01-04T00:00:00"),
    ]
    data = np.random.rand(4, 10, 180, 360)
    ds = xr.Dataset(
        {"var": (["time", "depth", "latitude", "longitude"], data)},
        coords={
            "time": (["time"], time),
            "depth": (["depth"], depth),
            "latitude": (["latitude"], lat),
            "longitude": (["longitude"], lon),
        },
    )
    return ds


@pytest.fixture
def global_dataset_with_noon_times():
    lon = np.linspace(0, 359, 360)
    lat = np.linspace(-90, 90, 180)
    time = [
        np.datetime64("2022-01-01T12:00:00"),
        np.datetime64("2022-01-02T12:00:00"),
        np.datetime64("2022-01-03T12:00:00"),
        np.datetime64("2022-01-04T12:00:00"),
    ]
    data = np.random.rand(4, 180, 360)
    ds = xr.Dataset(
        {"var": (["time", "latitude", "longitude"], data)},
        coords={
            "time": (["time"], time),
            "latitude": (["latitude"], lat),
            "longitude": (["longitude"], lon),
        },
    )
    return ds


@pytest.fixture
def global_dataset_with_multiple_times_per_day():
    lon = np.linspace(0, 359, 360)
    lat = np.linspace(-90, 90, 180)
    time = [
        np.datetime64("2022-01-01T00:00:00"),
        np.datetime64("2022-01-01T12:00:00"),
        np.datetime64("2022-01-02T00:00:00"),
        np.datetime64("2022-01-02T12:00:00"),
        np.datetime64("2022-01-03T00:00:00"),
        np.datetime64("2022-01-03T12:00:00"),
        np.datetime64("2022-01-04T00:00:00"),
        np.datetime64("2022-01-04T12:00:00"),
    ]
    data = np.random.rand(8, 180, 360)
    ds = xr.Dataset(
        {"var": (["time", "latitude", "longitude"], data)},
        coords={
            "time": (["time"], time),
            "latitude": (["latitude"], lat),
            "longitude": (["longitude"], lon),
        },
    )
    return ds


@pytest.fixture
def non_global_dataset():
    lon = np.linspace(0, 180, 181)
    lat = np.linspace(-90, 90, 180)
    data = np.random.rand(180, 181)
    ds = xr.Dataset(
        {"var": (["latitude", "longitude"], data)},
        coords={"latitude": (["latitude"], lat), "longitude": (["longitude"], lon)},
    )
    return ds


@pytest.mark.parametrize(
    "data_fixture, expected_time_values",
    [
        (
            "global_dataset",
            [
                np.datetime64("2022-01-02T00:00:00"),
                np.datetime64("2022-01-03T00:00:00"),
                np.datetime64("2022-01-04T00:00:00"),
            ],
        ),
        (
            "global_dataset_with_noon_times",
            [
                np.datetime64("2022-01-01T12:00:00"),
                np.datetime64("2022-01-02T12:00:00"),
                np.datetime64("2022-01-03T12:00:00"),
                np.datetime64("2022-01-04T12:00:00"),
            ],
        ),
        (
            "global_dataset_with_multiple_times_per_day",
            [
                np.datetime64("2022-01-02T00:00:00"),
                np.datetime64("2022-01-02T12:00:00"),
                np.datetime64("2022-01-03T00:00:00"),
                np.datetime64("2022-01-03T12:00:00"),
                np.datetime64("2022-01-04T00:00:00"),
            ],
        ),
    ],
)
def test_select_times(data_fixture, expected_time_values, request, tmp_path, use_dask):
    """Test selecting times with different datasets."""
    start_time = datetime(2022, 1, 2)
    end_time = datetime(2022, 1, 4)

    dataset = request.getfixturevalue(data_fixture)

    filepath = tmp_path / "test.nc"
    dataset.to_netcdf(filepath)
    dataset = LatLonDataset(
        filename=filepath,
        var_names={"var": "var"},
        start_time=start_time,
        end_time=end_time,
        use_dask=use_dask,
    )

    assert dataset.ds is not None
    assert len(dataset.ds.time) == len(expected_time_values)
    for expected_time in expected_time_values:
        assert expected_time in dataset.ds.time.values


@pytest.mark.parametrize(
    "data_fixture, expected_time_values",
    [
        ("global_dataset", [np.datetime64("2022-01-02T00:00:00")]),
        ("global_dataset_with_noon_times", [np.datetime64("2022-01-02T12:00:00")]),
    ],
)
def test_select_times_valid_start_no_end_time(
    data_fixture, expected_time_values, request, tmp_path, use_dask
):
    """Test selecting times with only start_time specified."""
    start_time = datetime(2022, 1, 2)
    # Get the fixture dynamically based on the parameter
    dataset = request.getfixturevalue(data_fixture)

    # Create a temporary file
    filepath = tmp_path / "test.nc"
    dataset.to_netcdf(filepath)

    # Instantiate Dataset object using the temporary file
    dataset = LatLonDataset(
        filename=filepath,
        var_names={"var": "var"},
        start_time=start_time,
        use_dask=use_dask,
        allow_flex_time=True,
    )

    assert dataset.ds is not None
    assert "time" in dataset.ds.dims
    assert len(dataset.ds.time) == len(expected_time_values)
    for expected_time in expected_time_values:
        assert expected_time in dataset.ds.time.values


@pytest.mark.parametrize(
    "data_fixture, expected_time_values",
    [
        ("global_dataset", [np.datetime64("2022-02-01T00:00:00")]),
        ("global_dataset_with_noon_times", [np.datetime64("2022-02-01T12:00:00")]),
    ],
)
def test_select_times_invalid_start_no_end_time(
    data_fixture, expected_time_values, request, tmp_path, use_dask
):
    """Test selecting times with only start_time specified."""
    # Get the fixture dynamically based on the parameter
    dataset = request.getfixturevalue(data_fixture)

    # Create a temporary file
    filepath = tmp_path / "test.nc"
    dataset.to_netcdf(filepath)

    with pytest.raises(
        ValueError,
        match="No exact match found ",
    ):
        dataset = LatLonDataset(
            filename=filepath,
            var_names={"var": "var"},
            start_time=datetime(2022, 5, 1),
            use_dask=use_dask,
        )


def test_multiple_matching_times(
    global_dataset_with_multiple_times_per_day, tmp_path, use_dask
):
    """Test handling when multiple matching times are found when end_time is not
    specified.
    """
    filepath = tmp_path / "test.nc"
    global_dataset_with_multiple_times_per_day.to_netcdf(filepath)
    dataset = LatLonDataset(
        filename=filepath,
        var_names={"var": "var"},
        start_time=datetime(2021, 12, 31, 22, 0),
        use_dask=use_dask,
        allow_flex_time=True,
    )

    assert dataset.ds["time"].values == np.datetime64(datetime(2022, 1, 1, 0, 0))


def test_warnings_times(global_dataset, tmp_path, caplog, use_dask):
    """Test handling when no matching times are found."""
    # Create a temporary file
    filepath = tmp_path / "test.nc"
    global_dataset.to_netcdf(filepath)
    with caplog.at_level(logging.WARNING):
        start_time = datetime(2021, 1, 1)
        end_time = datetime(2021, 2, 1)

        LatLonDataset(
            filename=filepath,
            var_names={"var": "var"},
            start_time=start_time,
            end_time=end_time,
            use_dask=use_dask,
        )
    # Verify the warning message in the log
    assert "No records found at or before the start_time" in caplog.text

    with caplog.at_level(logging.WARNING):
        start_time = datetime(2024, 1, 1)
        end_time = datetime(2024, 2, 1)

        LatLonDataset(
            filename=filepath,
            var_names={"var": "var"},
            start_time=start_time,
            end_time=end_time,
            use_dask=use_dask,
        )
    # Verify the warning message in the log
    assert "No records found at or after the end_time" in caplog.text


def test_from_ds(global_dataset, global_dataset_with_noon_times, use_dask, tmp_path):
    """Test the from_ds method of the LatLonDataset class."""
    start_time = datetime(2022, 1, 1)

    filepath = tmp_path / "test.nc"
    global_dataset.to_netcdf(filepath)

    dataset = LatLonDataset(
        filename=filepath,
        var_names={"var": "var"},
        dim_names={
            "latitude": "latitude",
            "longitude": "longitude",
            "time": "time",
            "depth": "depth",
        },
        start_time=start_time,
        use_dask=use_dask,
        allow_flex_time=True,
    )

    new_dataset = LatLonDataset.from_ds(dataset, global_dataset_with_noon_times)

    assert isinstance(new_dataset, LatLonDataset)
    assert new_dataset.ds.equals(
        global_dataset_with_noon_times
    )  # Verify the new ds attribute is set correctly

    # Ensure other attributes are copied correctly
    for attr in vars(dataset):
        if attr != "ds":
            assert getattr(new_dataset, attr) == getattr(dataset, attr), (
                f"Attribute {attr} not copied correctly."
            )


def test_reverse_latitude_reverse_depth_choose_subdomain(
    global_dataset, tmp_path, use_dask
):
    """Test reversing latitude when it is not ascending, the choose_subdomain method,
    and the convert_to_negative_depth method of the LatLonDataset class.
    """
    start_time = datetime(2022, 1, 1)

    filepath = tmp_path / "test.nc"
    global_dataset["latitude"] = global_dataset["latitude"][::-1]
    global_dataset["depth"] = global_dataset["depth"][::-1]
    global_dataset.to_netcdf(filepath)

    dataset = LatLonDataset(
        filename=filepath,
        var_names={"var": "var"},
        dim_names={
            "latitude": "latitude",
            "longitude": "longitude",
            "time": "time",
            "depth": "depth",
        },
        start_time=start_time,
        use_dask=use_dask,
        allow_flex_time=True,
    )

    assert np.all(np.diff(dataset.ds["latitude"]) > 0)
    assert np.all(np.diff(dataset.ds["depth"]) > 0)

    # test choosing subdomain for domain that straddles the dateline
    target_coords = {
        "lat": xr.DataArray(np.linspace(-10, 10, 100)),
        "lon": xr.DataArray(np.linspace(-10, 10, 100)),
        "straddle": True,
    }
    sub_dataset = dataset.choose_subdomain(
        target_coords,
        buffer_points=1,
        return_copy=True,
    )

    assert -11 <= sub_dataset.ds["latitude"].min() <= 11
    assert -11 <= sub_dataset.ds["latitude"].max() <= 11
    assert -11 <= sub_dataset.ds["longitude"].min() <= 11
    assert -11 <= sub_dataset.ds["longitude"].max() <= 11

    target_coords = {
        "lat": xr.DataArray(np.linspace(-10, 10, 100)),
        "lon": xr.DataArray(np.linspace(10, 20, 100)),
        "straddle": False,
    }
    sub_dataset = dataset.choose_subdomain(
        target_coords,
        buffer_points=1,
        return_copy=True,
    )

    assert -11 <= sub_dataset.ds["latitude"].min() <= 11
    assert -11 <= sub_dataset.ds["latitude"].max() <= 11
    assert 9 <= sub_dataset.ds["longitude"].min() <= 21
    assert 9 <= sub_dataset.ds["longitude"].max() <= 21


def test_check_if_global_with_global_dataset(global_dataset, tmp_path, use_dask):
    filepath = tmp_path / "test.nc"
    global_dataset.to_netcdf(filepath)
    dataset = LatLonDataset(
        filename=filepath, var_names={"var": "var"}, use_dask=use_dask
    )
    is_global = dataset.check_if_global(dataset.ds)
    assert is_global


def test_check_if_global_with_non_global_dataset(
    non_global_dataset, tmp_path, use_dask
):
    filepath = tmp_path / "test.nc"
    non_global_dataset.to_netcdf(filepath)
    dataset = LatLonDataset(
        filename=filepath, var_names={"var": "var"}, use_dask=use_dask
    )
    is_global = dataset.check_if_global(dataset.ds)

    assert not is_global


def test_check_dataset(global_dataset, tmp_path, use_dask):
    ds = global_dataset.copy()
    ds = ds.drop_vars("var")

    filepath = tmp_path / "test.nc"
    ds.to_netcdf(filepath)

    start_time = datetime(2022, 2, 1)
    end_time = datetime(2022, 3, 1)
    with pytest.raises(
        ValueError, match="Dataset does not contain all required variables."
    ):
        LatLonDataset(
            filename=filepath,
            var_names={"var": "var"},
            start_time=start_time,
            end_time=end_time,
            use_dask=use_dask,
        )

    ds = global_dataset.copy()
    ds = ds.rename({"latitude": "lat", "longitude": "long"})

    filepath = tmp_path / "test2.nc"
    ds.to_netcdf(filepath)

    start_time = datetime(2022, 2, 1)
    end_time = datetime(2022, 3, 1)
    with pytest.raises(
        ValueError, match="Dataset does not contain all required dimensions."
    ):
        LatLonDataset(
            filename=filepath,
            var_names={"var": "var"},
            start_time=start_time,
            end_time=end_time,
            use_dask=use_dask,
        )


def test_era5_correction_match_subdomain(use_dask):
    data = ERA5Correction(use_dask=use_dask)
    lats = data.ds.latitude[10:20]
    lons = data.ds.longitude[10:20]
    target_coords = {"lat": lats, "lon": lons}
    data.match_subdomain(target_coords)
    assert (data.ds["latitude"] == lats).all()
    assert (data.ds["longitude"] == lons).all()


@pytest.mark.use_gcsfs
def test_default_era5_dataset_loading_without_dask() -> None:
    """Verify that loading the default ERA5 dataset fails if use_dask is not True."""
    start_time = datetime(2020, 2, 1)
    end_time = datetime(2020, 2, 2)

    with pytest.raises(ValueError):
        _ = ERA5ARCODataset(
            filename=DEFAULT_ERA5_ARCO_PATH,
            start_time=start_time,
            end_time=end_time,
            use_dask=False,
        )


@pytest.mark.skip("Temporary skip until memory consumption issue is addressed. # TODO")
@pytest.mark.stream
@pytest.mark.use_dask
@pytest.mark.use_gcsfs
def test_default_era5_dataset_loading() -> None:
    """Verify the default ERA5 dataset is loaded correctly."""
    start_time = datetime(2020, 2, 1)
    end_time = datetime(2020, 2, 2)

    ds = ERA5ARCODataset(
        filename=DEFAULT_ERA5_ARCO_PATH,
        start_time=start_time,
        end_time=end_time,
        use_dask=True,
    )

    expected_vars = {"uwnd", "vwnd", "swrad", "lwrad", "Tair", "rain"}
    assert set(ds.var_names).issuperset(expected_vars)


@pytest.mark.use_copernicus
def test_default_glorys_dataset_loading_dask_not_installed() -> None:
    """Verify that loading the default GLORYS dataset fails if dask is not available."""
    start_time = datetime(2020, 2, 1)
    end_time = datetime(2020, 2, 2)

    with (
        pytest.raises(RuntimeError),
        mock.patch("roms_tools.utils.has_dask", return_value=False),
    ):
        _ = GLORYSDefaultDataset(
            filename=GLORYSDefaultDataset.dataset_name,
            start_time=start_time,
            end_time=end_time,
            use_dask=True,
        )


@pytest.mark.stream
@pytest.mark.use_copernicus
@pytest.mark.use_dask
def test_default_glorys_dataset_loading() -> None:
    """Verify the default GLORYS dataset is loaded correctly."""
    start_time = datetime(2012, 1, 1)

    for end_time in [start_time, start_time + timedelta(days=0.5)]:
        data = GLORYSDefaultDataset(
            filename=GLORYSDefaultDataset.dataset_name,
            start_time=start_time,
            end_time=end_time,
            use_dask=True,
        )

        expected_vars = {"temp", "salt", "u", "v", "zeta"}
        assert set(data.var_names).issuperset(expected_vars)

        expected_vars = {"thetao", "so", "uo", "vo", "zos"}
        assert "time" in data.ds.dims
        assert set(data.ds.data_vars).issuperset(expected_vars)


@pytest.mark.parametrize(
    "fname,start_time",
    [
        (download_test_data("GLORYS_NA_2012.nc"), datetime(2012, 1, 1, 12)),
        (download_test_data("GLORYS_NA_20121231.nc"), datetime(2012, 12, 31, 12)),
        (download_test_data("GLORYS_coarse_test_data.nc"), datetime(2021, 6, 29)),
    ],
)
@pytest.mark.parametrize("allow_flex_time", [True, False])
def test_non_default_glorys_dataset_loading(
    fname, start_time, allow_flex_time, use_dask
) -> None:
    """Verify the default GLORYS dataset is loaded correctly."""
    for end_time in [None, start_time, start_time]:
        data = GLORYSDataset(
            filename=fname,
            start_time=start_time,
            end_time=end_time,
            use_dask=use_dask,
            allow_flex_time=allow_flex_time,
        )

        expected_vars = {"temp", "salt", "u", "v", "zeta"}
        assert set(data.var_names).issuperset(expected_vars)

        expected_vars = {"thetao", "so", "uo", "vo", "zos"}
        assert "time" in data.ds.dims
        assert set(data.ds.data_vars).issuperset(expected_vars)


def test_data_concatenation(use_dask):
    fname = download_test_data("GLORYS_NA_2012.nc")
    data = GLORYSDataset(
        filename=fname,
        start_time=datetime(2012, 1, 1),
        end_time=datetime(2013, 1, 1),
        use_dask=use_dask,
    )

    # Concatenating the datasets at fname0 and fname1 should result in the dataset at fname
    fname0 = download_test_data("GLORYS_NA_20120101.nc")
    fname1 = download_test_data("GLORYS_NA_20121231.nc")

    # Test concatenation based on wildcards
    directory_path = Path(fname0).parent
    data_concatenated = GLORYSDataset(
        filename=str(directory_path) + "/GLORYS_NA_2012????.nc",
        start_time=datetime(2012, 1, 1),
        end_time=datetime(2013, 1, 1),
        use_dask=use_dask,
    )
    assert data.ds.equals(data_concatenated.ds)

    # Test concatenation based on lists
    data_concatenated = GLORYSDataset(
        filename=[fname0, fname1],
        start_time=datetime(2012, 1, 1),
        end_time=datetime(2013, 1, 1),
        use_dask=use_dask,
    )
    assert data.ds.equals(data_concatenated.ds)


def test_time_validation(use_dask):
    fname = download_test_data("GLORYS_NA_2012.nc")

    with pytest.raises(TypeError, match="start_time must be a datetime object"):
        GLORYSDataset(
            filename=fname,
            start_time="dummy",
            end_time=datetime(2013, 1, 1),
            use_dask=use_dask,
        )
    with pytest.raises(TypeError, match="end_time must be a datetime object"):
        GLORYSDataset(
            filename=fname,
            start_time=datetime(2012, 1, 1),
            end_time="dummy",
            use_dask=use_dask,
        )


def test_climatology_error(use_dask):
    fname = download_test_data("GLORYS_NA_2012.nc")

    with pytest.raises(
        ValueError,
        match="The dataset contains 2 time steps, but the climatology flag is set to True, which requires exactly 12 time steps.",
    ):
        GLORYSDataset(
            filename=fname,
            start_time=datetime(2012, 1, 1),
            end_time=datetime(2013, 1, 1),
            climatology=True,
            use_dask=use_dask,
        )

    fname_bgc = download_test_data("CESM_regional_coarse_test_data_climatology.nc")

    with pytest.raises(
        ValueError,
        match="The dataset contains integer time values, which are only supported when the climatology flag is set to True. However, your climatology flag is set to False.",
    ):
        CESMBGCDataset(
            filename=fname_bgc,
            start_time=datetime(2012, 1, 1),
            end_time=datetime(2013, 1, 1),
            climatology=False,
            use_dask=use_dask,
        )


@pytest.mark.parametrize(
    "data_fixture, expected_resolution",
    [
        ("era5_data", 0.25),
        ("glorys_data", 1 / 12),
        # ("tpxo_data", 1 / 6),
        ("cesm_bgc_data", 1.0),
        ("cesm_surface_bgc_data", 1.0),
        ("unified_bgc_data", 2.0),
        ("unified_surface_bgc_data", 2.0),
    ],
)
def test_horizontal_resolution(data_fixture, expected_resolution, request):
    data = request.getfixturevalue(data_fixture)
    assert np.isclose(data.resolution, expected_resolution)


class TestTPXODataset:
    @pytest.fixture
    def regional_tpxo_dataset(self, use_dask):
        """TPXO dataset with regional coverage and 25 constituents: M2, S2, N2, K2, K1, O1, P1, Q1, MM, Mf, MSF, M4, Mn4, Ms4, ..."""
        fname_grid = Path(download_test_data("regional_grid_tpxo10v2.nc"))
        fname_h = Path(download_test_data("regional_h_tpxo10v2.nc"))

        return TPXODataset(
            filename=fname_h,
            grid_filename=fname_grid,
            location="h",
            var_names={"ssh_Re": "hRe", "ssh_Im": "hIm"},
            use_dask=use_dask,
        )

    @pytest.fixture
    def global_tpxo_dataset(self, use_dask):
        """TPXO dataset with global coverage and 1 constituent: M2."""
        fname_grid = Path(download_test_data("global_grid_tpxo10.v2.nc"))
        fname_h = Path(download_test_data("global_h_tpxo10.v2.nc"))

        return TPXODataset(
            filename=fname_h,
            grid_filename=fname_grid,
            location="h",
            var_names={"ssh_Re": "hRe", "ssh_Im": "hIm"},
            use_dask=use_dask,
        )

    @pytest.fixture
    def omega(self):
        return {
            "m2": 1.405189e-04,
            "s2": 1.454441e-04,
            "n2": 1.378797e-04,
            "k2": 1.458423e-04,
            "k1": 7.292117e-05,
            "o1": 6.759774e-05,
            "p1": 7.252295e-05,
            "q1": 6.495854e-05,
            "mm": 0.026392e-04,
            "mf": 0.053234e-04,
            "m4": 2.810377e-04,
            "mn4": 2.783984e-04,
            "ms4": 2.859630e-04,
            "2n2": 1.352405e-04,
            "s1": 7.2722e-05,
        }

    @pytest.mark.parametrize(
        "tpxo_dataset_fixture",
        [
            "regional_tpxo_dataset",
            "global_tpxo_dataset",
        ],
    )
    def test_initialization_and_clean_up(self, tpxo_dataset_fixture, request):
        tpxo_dataset = request.getfixturevalue(tpxo_dataset_fixture)
        assert tpxo_dataset.location == "h"

        assert "hRe" in tpxo_dataset.ds.data_vars
        assert "hIm" in tpxo_dataset.ds.data_vars
        assert "mask" in tpxo_dataset.ds.data_vars
        assert "longitude" in tpxo_dataset.ds.dims
        assert "latitude" in tpxo_dataset.ds.dims
        assert "longitude" in tpxo_dataset.ds.variables
        assert "latitude" in tpxo_dataset.ds.variables

    def test_select_fewer_constituents(self, regional_tpxo_dataset, omega):
        regional_tpxo_dataset.select_constituents(2, omega)
        assert (
            regional_tpxo_dataset.ds["ntides"].values.astype("U3") == ["m2", "s2"]
        ).all()

    def test_select_constituents_with_reordering(self, regional_tpxo_dataset, omega):
        regional_tpxo_dataset.select_constituents(11, omega)

        assert len(regional_tpxo_dataset.ds["ntides"]) == 11
        # check that m4 has been moved from 12th to 11th position to follow TPXO9 order
        assert (
            regional_tpxo_dataset.ds["ntides"].isel(ntides=10).item().decode("utf-8")
            == "m4"
        )

    def test_select_constituents_omega_mismatch(self, regional_tpxo_dataset, omega):
        omega = OrderedDict(
            [*list(omega.items())[:3], ("fake", 6.495854e-05), *list(omega.items())[3:]]
        )
        with pytest.raises(ValueError, match="The dataset contains tidal constituents"):
            regional_tpxo_dataset.select_constituents(11, omega)

    def test_select_constituents_too_few(self, global_tpxo_dataset, omega):
        with pytest.raises(ValueError, match="The dataset contains tidal constituents"):
            global_tpxo_dataset.select_constituents(11, omega)


# test _concatenate_longitudes


@pytest.fixture
def sample_ds(use_dask):
    lon = xr.DataArray(np.array([0, 90, 180]), dims="lon", name="lon")
    lat = xr.DataArray(np.array([-30, 0, 30]), dims="lat", name="lat")

    var_with_lon = xr.DataArray(
        np.arange(9).reshape(3, 3),
        dims=("lat", "lon"),
        coords={"lat": lat, "lon": lon},
        name="var_with_lon",
    )

    var_no_lon = xr.DataArray(
        np.array([1, 2, 3]),
        dims="lat",
        coords={"lat": lat},
        name="var_no_lon",
    )

    ds = xr.Dataset({"var_with_lon": var_with_lon, "var_no_lon": var_no_lon})

    if use_dask:
        ds = ds.chunk({"lat": -1, "lon": -1})

    return ds


@pytest.mark.parametrize(
    "end,expected_lons",
    [
        ("lower", [-360, -270, -180, 0, 90, 180]),
        ("upper", [0, 90, 180, 360, 450, 540]),
        ("both", [-360, -270, -180, 0, 90, 180, 360, 450, 540]),
    ],
)
def test_concatenate_longitudes(sample_ds, end, expected_lons, use_dask):
    dim_names = {"longitude": "lon"}

    ds_concat = _concatenate_longitudes(
        sample_ds, dim_names, end=end, use_dask=use_dask
    )

    # longitude should be extended as expected
    np.testing.assert_array_equal(ds_concat.lon.values, expected_lons)

    # variable with longitude should be extended in size
    assert ds_concat.var_with_lon.shape[-1] == len(expected_lons)

    # variable without longitude should remain untouched
    np.testing.assert_array_equal(
        ds_concat.var_no_lon.values,
        sample_ds.var_no_lon.values,
    )

    if use_dask:
        import dask

        # Ensure dask array backing the data
        assert isinstance(ds_concat.var_with_lon.data, dask.array.Array)
        # Longitude dimension should be chunked (-1 → one chunk spanning the whole dim)
        assert ds_concat.var_with_lon.chunks[-1] == (len(expected_lons),)
    else:
        # With use_dask=False, data should be a numpy array
        assert isinstance(ds_concat.var_with_lon.data, np.ndarray)


def test_invalid_end_raises(sample_ds):
    dim_names = {"longitude": "lon"}
    with pytest.raises(ValueError):
        _concatenate_longitudes(sample_ds, dim_names, end="invalid")


# test choose_subdomain


def test_choose_subdomain_basic(global_dataset, use_dask):
    target_coords = {
        "lat": xr.DataArray([0, 10]),
        "lon": xr.DataArray([30, 40]),
        "straddle": False,
    }
    out = choose_subdomain(
        global_dataset,
        dim_names={"latitude": "latitude", "longitude": "longitude"},
        resolution=1.0,
        is_global=True,
        target_coords=target_coords,
        buffer_points=2,
        use_dask=use_dask,
    )
    assert out.latitude.min() <= 0
    assert out.latitude.max() >= 10
    assert out.longitude.min() <= 30
    assert out.longitude.max() >= 40


def test_choose_subdomain_raises_on_empty_lon(non_global_dataset, use_dask):
    target_coords = {
        "lat": xr.DataArray([-10, 10]),
        "lon": xr.DataArray([210, 215]),  # outside 0-180
        "straddle": False,
    }
    with pytest.raises(ValueError, match="longitude range"):
        choose_subdomain(
            non_global_dataset,
            dim_names={"latitude": "latitude", "longitude": "longitude"},
            resolution=1.0,
            is_global=False,
            target_coords=target_coords,
            use_dask=use_dask,
        )


def test_choose_subdomain_raises_on_empty_lat(global_dataset, use_dask):
    target_coords = {
        "lat": xr.DataArray([1000, 1010]),  # outside dataset range
        "lon": xr.DataArray([30, 40]),
        "straddle": False,
    }
    with pytest.raises(ValueError, match="latitude range"):
        choose_subdomain(
            global_dataset,
            dim_names={"latitude": "latitude", "longitude": "longitude"},
            resolution=1.0,
            is_global=True,
            target_coords=target_coords,
            use_dask=use_dask,
        )


def test_choose_subdomain_straddle(global_dataset, use_dask):
    target_coords = {
        "lat": xr.DataArray([-10, 10]),
        "lon": xr.DataArray([-170, 170]),  # cross the dateline
        "straddle": True,
    }
    out = choose_subdomain(
        global_dataset,
        dim_names={"latitude": "latitude", "longitude": "longitude"},
        resolution=1.0,
        is_global=True,
        target_coords=target_coords,
        buffer_points=5,
        use_dask=use_dask,
    )
    # Ensure output includes both sides of the dateline, mapped into -180 - 180
    assert (out.longitude.min() < 0) and (out.longitude.max() > 0)


def test_choose_subdomain_wraps_negative_lon(global_dataset, use_dask):
    target_coords = {
        "lat": xr.DataArray([0, 20]),
        "lon": xr.DataArray([-20, -10]),  # negative longitudes
        "straddle": False,
    }
    out = choose_subdomain(
        global_dataset,
        dim_names={"latitude": "latitude", "longitude": "longitude"},
        resolution=1.0,
        is_global=True,
        target_coords=target_coords,
        buffer_points=2,
        use_dask=use_dask,
    )
    # Output longitudes should be shifted into [0, 360]
    assert (out.longitude >= 0).all()


def test_choose_subdomain_respects_buffer(global_dataset, use_dask):
    target_coords = {
        "lat": xr.DataArray([0, 0]),
        "lon": xr.DataArray([50, 50]),
        "straddle": False,
    }
    out = choose_subdomain(
        global_dataset,
        dim_names={"latitude": "latitude", "longitude": "longitude"},
        resolution=1.0,
        is_global=True,
        target_coords=target_coords,
        buffer_points=10,
        use_dask=use_dask,
    )
    # Buffer should extend at least 10 degrees beyond target lon
    assert out.longitude.min() <= 40
    assert out.longitude.max() >= 60


# test get_glorys_bounds


@pytest.fixture
def glorys_grid_0_360(tmp_path):
    lats = np.linspace(-90, 90, 181)
    lons = np.linspace(0, 360, 361)
    ds = xr.Dataset(coords={"latitude": lats, "longitude": lons})
    path = tmp_path / "GLORYS_0_360.nc"
    ds.to_netcdf(path)
    return path


@pytest.fixture
def glorys_grid_neg180_180(tmp_path):
    lats = np.linspace(-90, 90, 181)
    lons = np.linspace(-180, 180, 361)
    ds = xr.Dataset(coords={"latitude": lats, "longitude": lons})
    path = tmp_path / "GLORYS_neg180_180.nc"
    ds.to_netcdf(path)
    return path


@pytest.fixture
def glorys_grid_real():
    return GLORYS_GLOBAL_GRID_PATH


@pytest.mark.parametrize(
    "grid_fixture",
    [
        "grid",
        "grid_that_straddles_dateline",
        "grid_that_straddles_180_degree_meridian",
        "small_grid",
        "tiny_grid",
    ],
)
@pytest.mark.parametrize(
    "glorys_grid_fixture",
    ["glorys_grid_0_360", "glorys_grid_neg180_180", "glorys_grid_real"],
)
def test_get_glorys_bounds(tmp_path, grid_fixture, glorys_grid_fixture, request):
    grid = request.getfixturevalue(grid_fixture)
    glorys_grid_path = request.getfixturevalue(glorys_grid_fixture)

    bounds = get_glorys_bounds(grid=grid, glorys_grid_path=glorys_grid_path)
    assert set(bounds) == {
        "minimum_latitude",
        "maximum_latitude",
        "minimum_longitude",
        "maximum_longitude",
    }


@pytest.mark.use_copernicus
@pytest.mark.skipif(copernicusmarine is None, reason="copernicusmarine required")
@pytest.mark.parametrize(
    "grid_fixture",
    [
        "tiny_grid_that_straddles_dateline",
        "tiny_grid_that_straddles_180_degree_meridian",
        "tiny_rotated_grid",
    ],
)
def test_invariance_to_get_glorys_bounds(tmp_path, grid_fixture, use_dask, request):
    start_time = datetime(2012, 1, 1)
    grid = request.getfixturevalue(grid_fixture)
    target_coords = get_target_coords(grid)

    regional_file, bigger_regional_file = download_regional_and_bigger(
        tmp_path, grid, start_time, variables=["thetao", "uo", "zos"]
    )

    # create datasets from regional and bigger regional data
    regional_data = GLORYSDataset(
        var_names={"temp": "thetao", "u": "uo", "zeta": "zos"},
        filename=regional_file,
        start_time=start_time,
        climatology=False,
        allow_flex_time=False,
        use_dask=use_dask,
    )
    bigger_regional_data = GLORYSDataset(
        var_names={"temp": "thetao", "u": "uo", "zeta": "zos"},
        filename=bigger_regional_file,
        start_time=start_time,
        climatology=False,
        allow_flex_time=False,
        use_dask=use_dask,
    )

    # subset both datasets and check they are the same
    regional_data.choose_subdomain(target_coords)
    bigger_regional_data.choose_subdomain(target_coords)

    # Use assert_allclose instead of equals: necessary for grids that straddle the 180° meridian.
    # Copernicus returns data on [-180, 180] by default, but if you request a range
    # like [170, 190], it remaps longitudes. That remapping introduces tiny floating
    # point differences in the longitude coordinate, so strict equality will fail
    # even though the data are effectively identical.
    # For grids that do not straddle the 180° meridian, strict equality still holds.
    xr.testing.assert_allclose(bigger_regional_data.ds, regional_data.ds)
