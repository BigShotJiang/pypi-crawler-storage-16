# ROTools



# Note
```
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass 
```

```
python setup.py sdist
rm .\dist\* 
python -m build
twine upload dist/*
```

```
Build z Pycharm console window


```

```
pip install --upgrade ROTools
```


