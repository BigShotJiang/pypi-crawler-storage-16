class ImagemNaoEncontradaException(Exception):
    """Exceção levantada quando a imagem especificada não é encontrada na tela."""
    pass