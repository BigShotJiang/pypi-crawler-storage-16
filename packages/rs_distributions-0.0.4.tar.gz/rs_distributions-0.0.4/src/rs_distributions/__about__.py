# SPDX-FileCopyrightText: 2024-present Kevin M. Dalton <kmdalton@fas.harvard.edu>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.4"
