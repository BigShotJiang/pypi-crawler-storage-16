# SPDX-FileCopyrightText: 2024-present Kevin M. Dalton <kmdalton@fas.harvard.edu>
#
# SPDX-License-Identifier: MIT
