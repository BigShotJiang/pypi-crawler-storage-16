# rssrender

Render RSS feeds for terminal display with customizable Jinja2 templates.

## Features

- Parse RSS feeds and render them for terminal output
- Filter entries by age (only show recent entries)
- Customizable output using Jinja2 templates
- HTML to plain text conversion with formatting preservation
- Content length limiting
- Optional link hiding

## Installation

```bash
pip install rssrender
```

Or install from source:

```bash
git clone git@github.com:berkeley-stat/rssrender.git
cd rssrender
pip install -e .
```

## Usage

```bash
rssrender --feed-url <RSS_FEED_URL> [--template <TEMPLATE_PATH>]
```

### Options

- `--feed-url` (required): RSS feed URL
- `--template`: Path to Jinja2 template file (default: included example template)
- `--day-threshold`: Number of days to consider an entry as recent (default: 30)
- `--max-body-length`: Maximum length of the body content (default: 400)
- `--hide-http-link`: If set, the HTTP link will not be displayed in the output

### Example

```bash
# Use the default template
rssrender --feed-url https://example.com/feed.xml

# Use a custom template and filter by last 7 days
rssrender --feed-url https://example.com/feed.xml --template ./my-template.j2 --day-threshold 7
```

## Template Format

Templates use Jinja2 syntax and have access to:

- `description`: Feed description (if available)
- `entries`: List of entries with the following fields:
  - `date`: Publication date (YYYY-MM-DD format)
  - `title`: Entry title
  - `link`: Entry URL (if not hidden)
  - `content`: Entry content (HTML converted to plain text)

### Custom Filters

Two custom filters are available in templates:

- `wrap(width, subsequent_indent, indent_all)`: Wrap text to specified width
- `indent(width, first)`: Indent lines by specified number of spaces

See the included example template for reference.

## Use Cases

- Generate MOTD (Message of the Day) from RSS feeds
- Display news feeds in terminal dashboards
- Create plain text digests from blogs
- Any terminal-based RSS feed display

## License

BSD 3-Clause License - See LICENSE file for details.
