"""rssrender: Render RSS feeds for terminal display."""

__version__ = "0.1.0"
