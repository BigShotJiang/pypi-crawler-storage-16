"""Command-line interface for rssrender."""

import argparse
import sys
from pathlib import Path

from rssrender.feed_parser import parse_feed
from rssrender.template import load_template


def get_default_template_path():
    """Find the default template path in the installation."""
    # Check in sys.prefix/share (works for system, user, and venv installs)
    template_path = (
        Path(sys.prefix) / "share" / "rssrender" / "templates" / "example.j2"
    )
    if template_path.exists():
        return str(template_path)

    # Fallback for development/editable install
    dev_path = Path(__file__).parent / "templates" / "example.j2"
    if dev_path.exists():
        return str(dev_path)

    return None


def parse_arguments():
    parser = argparse.ArgumentParser(
        description="Render RSS feeds for terminal display."
    )
    parser.add_argument(
        "--day-threshold",
        type=int,
        default=30,
        help="Number of days to consider an entry as recent (default: 30).",
    )
    parser.add_argument(
        "--max-body-length",
        type=int,
        default=400,
        help="Maximum length of the body content (default: 400).",
    )
    parser.add_argument(
        "--feed-url",
        type=str,
        required=True,
        help="RSS feed URL (required).",
    )
    parser.add_argument(
        "--hide-http-link",
        action="store_true",
        help="If set, the HTTP link will not be displayed in the output.",
    )

    default_template = get_default_template_path()
    parser.add_argument(
        "--template",
        type=str,
        default=default_template,
        help=f"Path to Jinja2 template file (default: {default_template or 'example.j2'}).",
    )
    return parser.parse_args()


def main():
    """Main entry point for the CLI."""
    args = parse_arguments()

    if not args.template:
        print(
            "Error: Could not find default template. Please specify --template.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Load the template
    template = load_template(args.template)

    # Parse the feed
    description, entries = parse_feed(args.feed_url, args)

    # Render the template with description and all entries
    output = template.render(
        description=description,
        entries=entries,
    )
    print(output)


if __name__ == "__main__":
    main()
