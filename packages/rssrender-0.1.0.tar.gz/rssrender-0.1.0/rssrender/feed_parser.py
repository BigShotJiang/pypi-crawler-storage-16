"""RSS feed parsing utilities."""

from datetime import datetime, timedelta, timezone
from time import mktime

import feedparser

from rssrender.html_parser import html_to_plaintext


def is_entry_recent(entry, day_threshold):
    """Determine if the entry date is within the threshold."""
    # feedparser provides parsed dates as time.struct_time
    date_tuple = entry.get("published_parsed") or entry.get("updated_parsed")

    if not date_tuple:
        return True  # If no date is present, include it

    try:
        # Convert time.struct_time to datetime
        entry_date = datetime.fromtimestamp(mktime(date_tuple), tz=timezone.utc)
        threshold_date = datetime.now(timezone.utc) - timedelta(days=day_threshold)
        return entry_date >= threshold_date
    except (TypeError, ValueError, OSError):
        # If conversion fails, include the entry
        return True


def prepare_entry(entry, args):
    """Prepare RSS entry data for template rendering."""
    # feedparser provides parsed dates as time.struct_time
    date_tuple = entry.get("published_parsed") or entry.get("updated_parsed")

    # Format date as YYYY-MM-DD
    date = None
    if date_tuple:
        try:
            # Convert time.struct_time to datetime and format
            entry_date = datetime.fromtimestamp(mktime(date_tuple))
            date = entry_date.strftime("%Y-%m-%d")
        except (TypeError, ValueError, OSError):
            # If conversion fails, try to use the raw string
            date_str = entry.get("published") or entry.get("updated")
            if date_str:
                date = date_str

    content = entry.get("content", [{}])[0].get("value", "") or entry.get("summary", "")

    # Convert HTML to plain text
    if content:
        content = html_to_plaintext(content)

        # Apply max body length
        if len(content) > args.max_body_length:
            content = content[: args.max_body_length - 3] + "..."

    title = entry.get("title", None)
    link = None if args.hide_http_link else entry.get("link", None)

    return {
        "date": date,
        "title": title,
        "link": link,
        "content": content,
    }


def parse_feed(feed_url, args):
    """Parse RSS feed and return description and filtered entries."""
    # Read and parse the feed itself
    feed = feedparser.parse(feed_url)

    # Get feed description if present
    description = None
    try:
        description_html = feed.feed.description  # type: ignore
        if description_html:
            description = html_to_plaintext(description_html)
    except AttributeError:
        pass

    # Prepare all recent entries
    entries = []
    for entry in feed["entries"]:
        # Skip entries older than the threshold
        if not is_entry_recent(entry, args.day_threshold):
            continue
        entries.append(prepare_entry(entry, args))

    return description, entries
