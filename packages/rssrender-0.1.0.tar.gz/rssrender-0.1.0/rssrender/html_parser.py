"""HTML to plain text conversion utilities."""

import re
from html.parser import HTMLParser


class HTMLToPlainText(HTMLParser):
    """Convert HTML to plain text, preserving basic formatting."""

    def __init__(self):
        super().__init__()
        self.text = []
        self.in_script = False
        self.in_style = False
        self.in_li = False

    def handle_starttag(self, tag, attrs):
        if tag in ["script", "style"]:
            self.in_script = True
            self.in_style = True
        elif tag == "br":
            self.text.append("\n")
        elif tag == "p":
            # Don't add newline at start, will add at end
            pass
        elif tag in ["li"]:
            self.in_li = True
            self.text.append("\n  • ")

    def handle_endtag(self, tag):
        if tag in ["script", "style"]:
            self.in_script = False
            self.in_style = False
        elif tag == "li":
            self.in_li = False
        elif tag in ["p", "div", "h1", "h2", "h3", "h4", "h5", "h6"]:
            # Don't add paragraph breaks if we're inside a list item
            if not self.in_li:
                self.text.append("\n\n")

    def handle_data(self, data):
        if not (self.in_script or self.in_style):
            # Replace newlines within data with spaces (they're not semantic)
            data = data.replace("\n", " ")
            self.text.append(data)

    def get_text(self):
        # Join text, normalize whitespace, and clean up
        text = "".join(self.text)
        # Normalize spaces within lines
        lines = text.split("\n")
        normalized_lines = []
        for line in lines:
            # Replace multiple spaces with single space
            line = re.sub(r" +", " ", line.strip())
            if line:  # Only add non-empty lines
                normalized_lines.append(line)
            elif normalized_lines and normalized_lines[-1] != "":
                # Add empty line for paragraph breaks, but avoid multiple empties
                normalized_lines.append("")

        return "\n".join(normalized_lines).strip()


def html_to_plaintext(html_content):
    """Convert HTML content to plain text."""
    parser = HTMLToPlainText()
    parser.feed(html_content)
    return parser.get_text()
