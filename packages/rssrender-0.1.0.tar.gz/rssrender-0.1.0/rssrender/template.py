"""Template loading and rendering utilities."""

import textwrap
import jinja2


def load_template(template_path):
    """Load the Jinja2 template from file with custom filters."""
    try:
        with open(template_path, "r") as f:
            template_content = f.read()

        # Create Jinja2 environment with custom filters
        env = jinja2.Environment()

        # Add a wrap filter for line wrapping
        def wrap_filter(text, width=74, subsequent_indent="", indent_all=False):
            """Wrap text to specified width.

            Args:
                text: Text to wrap
                width: Maximum line width
                subsequent_indent: Indent for continuation lines
                indent_all: If True, indent all lines (including paragraph starts)
            """
            if not text:
                return text

            # Convert to string and process line by line
            text_str = str(text)

            # If indent_all is True, we need to wrap and indent everything
            if indent_all and subsequent_indent:
                # Process each paragraph separately
                paragraphs = text_str.split("\n")
                wrapped_paragraphs = []
                for para in paragraphs:
                    if para.strip():
                        wrapped = textwrap.fill(
                            para,
                            width=width,
                            break_long_words=False,
                            break_on_hyphens=False,
                            initial_indent=subsequent_indent,
                            subsequent_indent=subsequent_indent,
                        )
                        wrapped_paragraphs.append(wrapped)
                    else:
                        wrapped_paragraphs.append("")
                return "\n".join(wrapped_paragraphs)
            else:
                # Standard wrapping - each paragraph separately
                lines = []
                for line in text_str.split("\n"):
                    if line.strip():
                        wrapped = textwrap.fill(
                            line,
                            width=width,
                            break_long_words=False,
                            break_on_hyphens=False,
                            subsequent_indent=subsequent_indent,
                        )
                        lines.append(wrapped)
                    else:
                        lines.append("")
                return "\n".join(lines)

        # Add an indent filter
        def indent_filter(text, width=2, first=True):
            """Indent all lines of text by width spaces."""
            if not text:
                return text
            indent_str = " " * width
            lines = str(text).split("\n")
            if first:
                return "\n".join(indent_str + line if line else "" for line in lines)
            else:
                return (
                    lines[0]
                    + "\n"
                    + "\n".join(indent_str + line if line else "" for line in lines[1:])
                )

        env.filters["wrap"] = wrap_filter
        env.filters["indent"] = indent_filter

        return env.from_string(template_content)
    except FileNotFoundError:
        print(
            f"Error: Template file not found: {template_path}",
            file=__import__("sys").stderr,
        )
        raise
    except Exception as e:
        print(f"Error loading template: {e}", file=__import__("sys").stderr)
        raise
