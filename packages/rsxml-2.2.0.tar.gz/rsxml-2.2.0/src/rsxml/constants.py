XSD_URL = "https://xml.riverscapes.net/Projects/XSD/V2/RiverscapesProject.xsd"

MULTIPART_CHUNK_SIZE = 50 * 1024**2
MULTIPART_THRESHOLD = 50 * 1024**2
