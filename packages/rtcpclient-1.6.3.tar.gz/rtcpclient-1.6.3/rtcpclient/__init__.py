from .rtcpclient import main
main()