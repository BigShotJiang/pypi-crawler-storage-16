"""RTFD - Real-time library documentation access for AI coding agents."""

__version__ = "0.5.1"
