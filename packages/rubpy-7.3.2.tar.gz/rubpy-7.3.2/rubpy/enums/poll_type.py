class PollType:
    """Poll type enumeration"""

    QUIZ = 'Quiz'
    "Quiz poll"

    REGULAR = 'Regular'
    "Regular poll"