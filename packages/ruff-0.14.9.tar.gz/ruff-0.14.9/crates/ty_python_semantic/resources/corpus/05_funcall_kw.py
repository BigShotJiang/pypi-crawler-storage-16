fun(a=a, kw=2)
