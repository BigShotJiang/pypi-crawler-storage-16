if False:
    b
else:
    c
