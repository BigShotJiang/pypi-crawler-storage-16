while a:
    if x:
        break
    y = 1
