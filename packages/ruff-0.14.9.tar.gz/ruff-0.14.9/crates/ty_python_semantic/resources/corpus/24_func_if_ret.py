def foo(a):
    if a:
        return b
    return c
