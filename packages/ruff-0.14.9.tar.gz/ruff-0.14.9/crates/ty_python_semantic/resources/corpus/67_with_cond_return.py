def foo():
    with a:
        if x:
            return
        if y:
            return None
