with foo, bar:
    a
