for a in seq:
    try:
        continue
    except Exc:
        b
