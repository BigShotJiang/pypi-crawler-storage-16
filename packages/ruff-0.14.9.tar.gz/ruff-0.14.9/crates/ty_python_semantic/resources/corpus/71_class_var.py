class C:
    var = 1
