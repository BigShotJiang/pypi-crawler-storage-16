class Foo:

    def foo(self, bar):
        def inner():
            bar
