def f():
    def g():
        __class__
