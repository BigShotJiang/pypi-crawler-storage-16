def foo(z, *y, x, **c):
    a
