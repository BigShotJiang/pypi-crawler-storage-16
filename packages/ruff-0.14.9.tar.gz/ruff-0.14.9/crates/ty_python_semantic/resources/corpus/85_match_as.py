match x:
    case 0 as y:
        pass
