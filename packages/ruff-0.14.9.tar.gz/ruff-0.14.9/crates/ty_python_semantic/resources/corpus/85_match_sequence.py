match ():
    case []:
        pass
    case [x, 2]:
        pass
