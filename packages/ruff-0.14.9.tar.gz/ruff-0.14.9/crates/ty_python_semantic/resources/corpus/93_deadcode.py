def foo():
    return
    print(1)
