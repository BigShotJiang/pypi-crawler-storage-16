lst[a, b]: int
