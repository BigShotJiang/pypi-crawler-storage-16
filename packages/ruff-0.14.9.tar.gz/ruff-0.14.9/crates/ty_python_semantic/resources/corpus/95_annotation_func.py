def f(x: int):
    pass

