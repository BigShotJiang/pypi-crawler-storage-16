name_3: Foo = 0
name_4 = 0

if _0:
    type name_3 = name_5
    type name_4 = name_3

_1: name_3

def name_1(_2: name_4):
    pass

match 0:
    case name_1._3:
        pass
    case 1:
        type name_5 = name_4
    case name_5:
        pass
name_3 = name_5
