### Description



### Details

* OS:
* Python version:
* ruff-api version:
* Can you repro on master?
* Can you repro in a clean virtualenv?
