from rundeck_mcp.server import app


def main():
    """Main entry point for the rundeck-mcp command."""
    app()


if __name__ == "__main__":
    main()
