DIST_NAME = "rundeck-mcp"
