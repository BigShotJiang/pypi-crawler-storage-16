# rune
Rune is a Python library for structured terminal rendering. Compose components like boxes and text into high-level layouts, then render them dynamically. Ideal for building interactive CLI tools and TUI apps.
