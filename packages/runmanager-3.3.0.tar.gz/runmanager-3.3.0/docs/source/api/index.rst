=============
API Reference
=============

.. autosummary::
    :toctree: _autosummary
    :template: autosummary-module.rst
    :recursive:

    runmanager
    runmanager.functions
    runmanager.remote
    runmanager.batch_compiler
    runmanager.globals_diff
    runmanager.__main__
