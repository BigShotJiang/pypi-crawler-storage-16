# this string is used for the version string in the documentation, as well as the egg
__version__ = '2.2.1'
