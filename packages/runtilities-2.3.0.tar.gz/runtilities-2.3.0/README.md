runtilities - running utilities
===================================

This is a package with a few hopefully useful running utilities.

package name is "running". Yes I know that's confusing.

Install

    pip install runtilities
    
Usage, e.g.

    from running.runsignup import RunSignUp

A lot of this may be obsolete and hasn't been tested for a while, 
so your mileage may vary. Sorry about that.
