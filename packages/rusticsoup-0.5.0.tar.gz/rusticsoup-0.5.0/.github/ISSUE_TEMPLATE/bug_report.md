---
name: Bug report
about: Report a problem
labels: bug
---

### Describe the bug

### Steps to reproduce

### Expected behavior

### Environment
- OS:
- Python:
- rusticsoup version:
