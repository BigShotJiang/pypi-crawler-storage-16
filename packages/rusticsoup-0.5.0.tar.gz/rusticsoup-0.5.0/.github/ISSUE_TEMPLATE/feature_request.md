---
name: Feature request
about: Suggest an idea
labels: enhancement
---

### Problem to solve

### Proposed solution / API sketch

### Alternatives considered
