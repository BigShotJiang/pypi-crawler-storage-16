# Code of Conduct

This project adheres to the Contributor Covenant Code of Conduct, version 2.1.

- Home: https://www.contributor-covenant.org/version/2/1/code_of_conduct.html
- FAQ: https://www.contributor-covenant.org/faq
- Translations: https://www.contributor-covenant.org/translations

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported by contacting the maintainers at your.email@example.com.
