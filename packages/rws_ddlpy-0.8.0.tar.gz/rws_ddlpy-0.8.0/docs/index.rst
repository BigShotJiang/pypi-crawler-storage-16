.. mdinclude:: ../README.md

.. toctree::
   :titlesonly:
   :hidden:

   usage
   modules
   contributing
   history