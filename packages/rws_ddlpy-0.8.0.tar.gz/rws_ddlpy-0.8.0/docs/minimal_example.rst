Minimal example
===============

.. literalinclude:: examples/minimal_example.py
   :language: python
   :linenos:
