"""Tests for tracer application"""
