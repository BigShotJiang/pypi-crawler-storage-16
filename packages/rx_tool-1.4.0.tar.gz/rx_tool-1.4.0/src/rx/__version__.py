"""Version information for RX"""

__version__ = '1.4.0'
