"""Version information for RX"""

__version__ = '2.0.1'
