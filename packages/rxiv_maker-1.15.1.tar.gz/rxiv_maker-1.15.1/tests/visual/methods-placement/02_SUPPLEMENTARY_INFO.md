## Supplementary Information

This is supplementary information for the methods placement test manuscript.
