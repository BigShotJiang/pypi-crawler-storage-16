# `ryo3-tokio-websockets`

python + `tokio-websockets` crate.

`tokio-websockets`:

- [crates.io](https://crates.io/crates/tokio-websockets)
- [docs.rs](https://docs.rs/tokio-websockets)
