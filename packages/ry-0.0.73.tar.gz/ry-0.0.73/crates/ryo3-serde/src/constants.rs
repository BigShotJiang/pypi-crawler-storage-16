pub(crate) type Depth = u8;
pub(crate) const MAX_DEPTH: Depth = 255;
