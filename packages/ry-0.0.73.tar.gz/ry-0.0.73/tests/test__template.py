from __future__ import annotations

import ry


def test_fn() -> None:
    assert ry is not None
