#!!!!! do not change this file !!!!!
app_version="6.13"
app_bulld_anchor="Noh_2025-12-11 17:47:35.541018"
app_name="ryry-cli"
import sys, os
if getattr(sys, 'frozen', False):
    base_path = sys._MEIPASS
else:
    base_path = os.path.dirname(os.path.abspath(__file__))

