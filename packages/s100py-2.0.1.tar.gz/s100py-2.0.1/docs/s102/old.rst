Older versions of S102
======================

Version 2.1
-----------
..  automodapi:: s100py.s102.v2_1.utils
..  automodapi:: s100py.s102.v2_1.api

Version 2.0
-----------
..  automodapi:: s100py.s102.v2_0.utils
..  automodapi:: s100py.s102.v2_0.api

