.. mdinclude:: ../../s100py/s102/README.md

..
    or use .. include:: ../../s100py/s102/README.rst
