.. mdinclude:: ../../s100py/s104/README.md

..
    or use .. include:: ../../s100py/s104/README.rst
