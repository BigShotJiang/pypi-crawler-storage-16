.. mdinclude:: ../../s100py/s111/README.md

..
    or use .. include:: ../../s100py/s111/README.rst
