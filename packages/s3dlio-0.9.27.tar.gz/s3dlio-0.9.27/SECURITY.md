# Security Policy

## Supported Versions

The following versions are supported.

| Version | Supported          |
| ------- | ------------------ |
| 0.8.x   | :white_check_mark: |
| < 0.8.0   | :x:                |

## Reporting a Vulnerability

Please send an email directly to the project maintainers to report vulnerabilities
