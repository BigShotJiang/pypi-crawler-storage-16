"""
(Unofficial) SAD to XSuite Converter: Output Writer Initialisation
=============================================
Author(s):  John P T Salvesen
Email:      john.salvesen@cern.ch
Date:       09-10-2025
"""
