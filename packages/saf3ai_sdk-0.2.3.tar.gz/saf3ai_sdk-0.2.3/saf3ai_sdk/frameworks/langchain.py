"""
LangChain framework adapter.

This module provides security callback integration for LangChain agents/chains.
"""

import logging
from typing import Optional, Callable

from .base import BaseFrameworkAdapter

logger = logging.getLogger(__name__)


class LangChainFrameworkAdapter(BaseFrameworkAdapter):
    """
    Framework adapter for LangChain.
    
    Integrates security scanning with LangChain using BaseCallbackHandler.
    
    Example Usage:
        ```python
        from saf3ai_sdk import create_framework_security_callbacks
        
        callback = create_framework_security_callbacks(
            framework='langchain',
            api_endpoint='http://localhost:8082',
            agent_identifier='my-langchain-agent-abc123'
        )
        
        # Add to LangChain chain/agent
        chain = LLMChain(
            llm=llm,
            prompt=prompt,
            callbacks=[callback]  # Add security callback
        )
        ```
    """
    
    def get_framework_name(self) -> str:
        return "langchain"
    
    def create_prompt_callback(self):
        """
        Create LangChain BaseCallbackHandler for prompt scanning.
        
        Returns:
            LangChain-compatible BaseCallbackHandler instance
        """
        # Import LangChain-specific callback creator
        from saf3ai_sdk.langchain_callbacks import create_security_callback
        
        callback = create_security_callback(
            api_endpoint=self.api_endpoint,
            api_key=self.api_key,
            timeout=self.timeout,
            on_scan_complete=self.on_scan_complete,
            scan_responses=False,
            agent_identifier=self.agent_identifier
        )
        
        return callback  # Returns SecurityCallback instance
    
    def create_response_callback(self):
        """
        Create LangChain BaseCallbackHandler for response scanning.
        
        Returns:
            LangChain-compatible BaseCallbackHandler instance with response scanning enabled
        """
        # Import LangChain-specific callback creator
        from saf3ai_sdk.langchain_callbacks import create_security_callback
        
        callback = create_security_callback(
            api_endpoint=self.api_endpoint,
            api_key=self.api_key,
            timeout=self.timeout,
            on_scan_complete=self.on_scan_complete,
            scan_responses=True,
            agent_identifier=self.agent_identifier
        )
        
        return callback  # Returns SecurityCallback instance with scan_responses=True
    
    def create_callbacks(self, scan_responses: bool = False):
        """
        Convenience method to create callback with optional response scanning.
        
        Args:
            scan_responses: Whether to also scan responses after generation
            
        Returns:
            SecurityCallback instance (BaseCallbackHandler subclass)
        """
        from saf3ai_sdk.langchain_callbacks import create_security_callback
        
        return create_security_callback(
            api_endpoint=self.api_endpoint,
            api_key=self.api_key,
            timeout=self.timeout,
            on_scan_complete=self.on_scan_complete,
            scan_responses=scan_responses,
            agent_identifier=self.agent_identifier
        )

