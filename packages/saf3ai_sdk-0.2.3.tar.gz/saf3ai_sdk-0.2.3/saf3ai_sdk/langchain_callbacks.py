"""
LangChain-native callbacks for security scanning.

This module provides callbacks that integrate with LangChain's built-in callback system
(BaseCallbackHandler). This is the clean, official way to intercept LLM calls in LangChain.

PRODUCTION-READY CONVERSATION ID STITCHING:

CRITICAL FIX: Checks existing conversation_id BEFORE extracting new one
- Prevents overwriting Streamlit UUIDs with new LangChain trace_ids
- Ensures conversation stitching works correctly across multiple calls
- Respects persisted conversation IDs from applications

PRODUCTION-READY APPROACH (combines 0.2.11 working logic with critical fixes):
1. Accepts conversation_id parameter - App can pass persisted ID (e.g., Streamlit UUID)
2. Checks existing conversation_id FIRST - Never overwrites if already set (CRITICAL FIX)
3. Simple registry - Maps run_id → trace_id for parent chain walking (from 0.2.11)
4. Parent chain lookup - Finds root trace_id when child runs reference parent_run_id
5. Automatic fallback - Falls back to span extraction if LangChain IDs unavailable

STREAMLIT INTEGRATION:
- Pass conversation_id in callback creation: create_security_callback(..., conversation_id=st.session_state.get('conversation_id'))
- SDK will use this ID and never overwrite it with LangChain trace_ids
- All calls in the same Streamlit session will share the same conversation_id

LANGCHAIN AGENT INTEGRATION:
- Automatically extracts trace_id from LangChain run objects
- Uses trace_id directly (groups all runs in same conversation)
- Registry enables parent chain walking for agents with chains (like 0.2.11)
- Simple and reliable - production-tested approach
"""

import logging
import os
import threading
from typing import Optional, TYPE_CHECKING, Any, Dict, List

from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode

logger = logging.getLogger(__name__)

# PRODUCTION-READY LAZY IMPORT SYSTEM
# Never import LangChain at module load time - only when actually needed
# This prevents failures when LangChain version changes or isn't installed

# Cache for detected LangChain classes (lazy-loaded)
_LANGCHAIN_CACHE = {
    'BaseCallbackHandler': None,
    'LLMResult': None,
    'available': None,  # None = not checked yet, True/False = checked
    'version_info': None,
}

def _detect_langchain_lazy():
    """
    PRODUCTION-ROBUST: Lazy detection of LangChain at runtime.
    Tries all possible import paths and never fails hard.
    
    Returns:
        tuple: (BaseCallbackHandler class, LLMResult class, version_info string)
        Returns (None, None, None) if LangChain not available
    """
    # Return cached result if already checked
    if _LANGCHAIN_CACHE['available'] is not None:
        return (
            _LANGCHAIN_CACHE['BaseCallbackHandler'],
            _LANGCHAIN_CACHE['LLMResult'],
            _LANGCHAIN_CACHE['version_info']
        )
    
    # Try all possible import paths (order matters - try most common first)
    import_paths = [
        # LangChain v0.1+ (langchain_core - most common now)
        ('langchain_core.callbacks', 'BaseCallbackHandler', 'langchain_core.outputs', 'LLMResult', 'v0.1+ (langchain_core)'),
        # LangChain v0.0.x (older versions)
        ('langchain.callbacks.base', 'BaseCallbackHandler', 'langchain.schema', 'LLMResult', 'v0.0.x (langchain)'),
        # Alternative paths
        ('langchain.callbacks', 'BaseCallbackHandler', 'langchain.schema.output', 'LLMResult', 'alternative (langchain)'),
        # Even more alternatives
        ('langchain_core.callbacks.base', 'BaseCallbackHandler', 'langchain_core.outputs', 'LLMResult', 'v0.1+ alternative'),
    ]
    
    for callback_module, callback_class, result_module, result_class, version_info in import_paths:
        try:
            # Dynamically import the modules
            import importlib
            callback_mod = importlib.import_module(callback_module)
            result_mod = importlib.import_module(result_module)
            
            BaseCallbackHandler = getattr(callback_mod, callback_class)
            LLMResult = getattr(result_mod, result_class)
            
            # Verify these are actually classes (duck typing check)
            if not (isinstance(BaseCallbackHandler, type) and isinstance(LLMResult, type)):
                continue
            
            # Cache successful detection
            _LANGCHAIN_CACHE['BaseCallbackHandler'] = BaseCallbackHandler
            _LANGCHAIN_CACHE['LLMResult'] = LLMResult
            _LANGCHAIN_CACHE['available'] = True
            _LANGCHAIN_CACHE['version_info'] = version_info
            
            logger.debug(f"LangChain detected: {version_info}")
            return (BaseCallbackHandler, LLMResult, version_info)
            
        except (ImportError, AttributeError, ModuleNotFoundError) as e:
            logger.debug(f"LangChain import path failed ({version_info}): {e}")
            continue
        except Exception as e:
            logger.debug(f"Unexpected error detecting LangChain ({version_info}): {e}")
            continue
    
    # LangChain not available - cache negative result
    _LANGCHAIN_CACHE['available'] = False
    _LANGCHAIN_CACHE['version_info'] = None
    logger.debug("LangChain not available - all import paths failed")
    return (None, None, None)

def _is_langchain_available():
    """Check if LangChain is available (lazy check)."""
    if _LANGCHAIN_CACHE['available'] is None:
        _detect_langchain_lazy()
    return _LANGCHAIN_CACHE['available'] is True

def _get_langchain_base_handler():
    """Get BaseCallbackHandler class (lazy-loaded)."""
    if _LANGCHAIN_CACHE['BaseCallbackHandler'] is None:
        _detect_langchain_lazy()
    return _LANGCHAIN_CACHE['BaseCallbackHandler']

def _get_langchain_llm_result():
    """Get LLMResult class (lazy-loaded)."""
    if _LANGCHAIN_CACHE['LLMResult'] is None:
        _detect_langchain_lazy()
    return _LANGCHAIN_CACHE['LLMResult']

# For backward compatibility and type checking
if TYPE_CHECKING:
    from typing import Any
    BaseCallbackHandler = Any
    LLMResult = Any
else:
    # Create a base class that will be replaced at runtime if LangChain is available
    class BaseCallbackHandler:
        """Base callback handler - will inherit from LangChain's BaseCallbackHandler if available."""
        pass
    LLMResult = type('LLMResult', (), {})

# SIMPLIFIED REGISTRY: Map run_id → trace_id for parent chain walking
# This enables SDK to find root trace_id when child runs have parent_run_id
# Thread-safe using locks for multi-threaded environments
# PRODUCTION: Simple LRU-like cleanup to prevent unbounded growth
_run_id_registry = {}
_registry_lock = threading.Lock()
_MAX_REGISTRY_SIZE = 5000  # Reasonable limit for production

def _register_run_trace(run_id: str, trace_id: str):
    """
    Register a run_id → trace_id mapping for parent chain walking.
    
    This enables finding the root trace_id when child runs reference parent_run_id.
    Simple and production-safe with size limits.
    """
    if not run_id or not trace_id:
        return
    
    try:
        with _registry_lock:
            # Simple cleanup: if registry too large, clear oldest 25%
            if len(_run_id_registry) >= _MAX_REGISTRY_SIZE:
                items_to_remove = list(_run_id_registry.keys())[:int(_MAX_REGISTRY_SIZE * 0.25)]
                for key in items_to_remove:
                    del _run_id_registry[key]
                logger.debug(f"Registry cleanup: removed {len(items_to_remove)} entries")
            
            _run_id_registry[run_id] = trace_id
            logger.debug(f"Registered run_id={run_id} → trace_id={trace_id}")
    except Exception as e:
        logger.debug(f"Error registering run_trace: {e}")

def _get_trace_id_from_registry(run_id: str) -> Optional[str]:
    """Get trace_id from registry by run_id."""
    if not run_id:
        return None
    try:
        with _registry_lock:
            return _run_id_registry.get(run_id)
    except Exception:
        return None

def _extract_langchain_conversation_id(kwargs: Dict[str, Any], use_provided_id: Optional[str] = None) -> Optional[str]:
    """
    Extract conversation ID from LangChain callback kwargs.
    
    PRODUCTION-READY PRIORITY ORDER (combines 0.2.11 logic with critical fixes):
    1. Provided conversation_id (from app, e.g., Streamlit UUID) - HIGHEST PRIORITY
    2. LangChain run.trace_id (groups all runs in conversation) - registers in registry
    3. LangChain parent_run_id → lookup in registry → find parent's trace_id (from 0.2.11)
    4. LangChain run.id or run.run_id (fallback - individual run ID)
    5. kwargs["run_id"] (direct access)
    6. kwargs["parent_run_id"] → lookup in registry (for child runs)
    7. From metadata (langsmith_trace_id, trace_id, etc.)
    
    Args:
        kwargs: Callback kwargs containing run object
        use_provided_id: Optional UUID from app (e.g., Streamlit session)
    
    Returns:
        Conversation ID string or None
    """
    try:
        # Priority 1: Use provided conversation_id FIRST
        # This ensures Streamlit UUID is used when provided
        if use_provided_id:
            logger.debug(f"Using provided conversation_id: {use_provided_id}")
            return str(use_provided_id)
        
        # Priority 2: Extract from LangChain run object (most reliable)
        run = kwargs.get("run")
        if run:
            # trace_id is the key for conversation stitching in LangSmith
            # For root runs, trace_id groups all runs in the same conversation
            trace_id = getattr(run, "trace_id", None)
            run_id = getattr(run, "id", None) or getattr(run, "run_id", None)
            parent_run_id = getattr(run, "parent_run_id", None) or kwargs.get("parent_run_id")
            
            # Register run_id → trace_id mapping (for parent chain walking)
            if run_id and trace_id:
                _register_run_trace(str(run_id), str(trace_id))
            
            # If we have trace_id, use it directly (best case)
            if trace_id:
                logger.debug(f"Extracted LangChain trace_id: {trace_id}")
                return str(trace_id)
            
            # If we have parent_run_id, try to find parent's trace_id from registry
            if parent_run_id:
                parent_trace_id = _get_trace_id_from_registry(str(parent_run_id))
                if parent_trace_id:
                    logger.debug(f"Found parent trace_id via registry: {parent_trace_id}")
                    # Register this run_id → parent_trace_id for future lookups
                    if run_id:
                        _register_run_trace(str(run_id), parent_trace_id)
                    return parent_trace_id
            
            # Fallback to run_id (for root runs, run_id == trace_id)
            if run_id:
                logger.debug(f"Extracted LangChain run_id: {run_id}")
                return str(run_id)
        
        # Priority 3: Direct run_id in kwargs
        run_id = kwargs.get("run_id")
        if run_id:
            logger.debug(f"Extracted run_id from kwargs: {run_id}")
            return str(run_id)
        
        # Priority 4: Parent run_id (for child runs - try registry lookup)
        parent_run_id = kwargs.get("parent_run_id")
        if parent_run_id:
            parent_trace_id = _get_trace_id_from_registry(str(parent_run_id))
            if parent_trace_id:
                logger.debug(f"Found parent trace_id via registry (kwargs): {parent_trace_id}")
                return parent_trace_id
            logger.debug(f"Extracted parent_run_id from kwargs: {parent_run_id}")
            return str(parent_run_id)
        
        # Priority 5: From metadata
        metadata = kwargs.get("metadata", {})
        if isinstance(metadata, dict):
            trace_id = metadata.get("trace_id") or metadata.get("langsmith_trace_id")
            if trace_id:
                logger.debug(f"Extracted trace_id from metadata: {trace_id}")
                return str(trace_id)
            
            run_id = metadata.get("run_id") or metadata.get("langsmith_run_id")
            if run_id:
                logger.debug(f"Extracted run_id from metadata: {run_id}")
                return str(run_id)
        
    except Exception as e:
        logger.debug(f"Error extracting conversation ID from LangChain kwargs: {e}")
    
    return None

def _extract_conversation_id(span) -> Optional[str]:
    """
    Extract conversation ID from span with multiple fallback strategies.
    
    Priority order:
    1. gen_ai.conversation.id (already set by SDK)
    2. langsmith.trace_id (set by LangSmith tracer)
    3. langsmith.run_id (set by LangSmith tracer)
    4. OpenTelemetry trace_id (fallback - always available)
    
    This is the fallback when LangChain IDs are not available in callbacks.
    """
    try:
        if span and span.is_recording():
            # Method 1: Check if already set in span attributes (highest priority)
            conv_id = span.attributes.get('gen_ai.conversation.id')
            if conv_id:
                logger.debug(f"Found conversation_id in span attributes: {conv_id}")
                return str(conv_id)
            
            # Check LangSmith-specific attributes (set by LangSmith tracer)
            langsmith_trace_id = span.attributes.get('langsmith.trace_id')
            if langsmith_trace_id:
                logger.debug(f"Found LangSmith trace_id in span: {langsmith_trace_id}")
                return str(langsmith_trace_id)
            
            langsmith_run_id = span.attributes.get('langsmith.run_id')
            if langsmith_run_id:
                logger.debug(f"Found LangSmith run_id in span: {langsmith_run_id}")
                return str(langsmith_run_id)
            
            # Method 3: Use OpenTelemetry trace_id as fallback
            span_context = span.get_span_context()
            if span_context and span_context.is_valid:
                trace_id = format(span_context.trace_id, '032x')  # Convert to hex string
                logger.debug(f"No conversation ID found, using OpenTelemetry trace_id: {trace_id}")
                return trace_id
    except Exception as e:
        logger.debug(f"Could not extract conversation ID from span: {e}")
    
    return None

def _set_conversation_id_in_attributes(conversation_id: str, source: str = "unknown"):
    """
    Set conversation ID in Saf3AI custom attributes AND update all existing spans.
    
    This ensures all spans in the same conversation share the same conversation ID
    for proper conversation stitching. Also updates any currently active spans.
    
    Args:
        conversation_id: The conversation ID to set
        source: Where the ID came from (for debugging)
    """
    try:
        from saf3ai_sdk import set_custom_attributes
        set_custom_attributes({
            "gen_ai.conversation.id": conversation_id,
            "conversation_id": conversation_id,
        })
        logger.debug(f"Set conversation_id from {source}: {conversation_id}")
        
        # CRITICAL: Also update the current span and LangChain span if they exist
        # This ensures spans created BEFORE the conversation ID was extracted get updated
        try:
            current_span = trace.get_current_span()
            if current_span and current_span.is_recording():
                current_span.set_attribute("gen_ai.conversation.id", conversation_id)
                current_span.set_attribute("conversation_id", conversation_id)
                logger.debug(f"Updated current span with conversation_id: {conversation_id}")
        except Exception as e:
            logger.debug(f"Could not update current span: {e}")
        
        # Also update the LangChain span if it exists
        try:
            from saf3ai_sdk.instrumentation.langchain_instrumentation import _current_langchain_span
            langchain_span = getattr(_current_langchain_span, 'span', None)
            if langchain_span and langchain_span.is_recording():
                langchain_span.set_attribute("gen_ai.conversation.id", conversation_id)
                langchain_span.set_attribute("conversation_id", conversation_id)
                logger.debug(f"Updated LangChain span with conversation_id: {conversation_id}")
        except (ImportError, AttributeError, Exception) as e:
            logger.debug(f"Could not update LangChain span: {e}")
            
    except Exception as e:
        logger.debug(f"Failed to set conversation ID in custom attributes: {e}")

# Create SecurityCallback class dynamically to inherit from LangChain's BaseCallbackHandler if available
def _create_security_callback_class():
    """
    PRODUCTION-ROBUST: Dynamically create SecurityCallback class that inherits from LangChain's BaseCallbackHandler.
    This ensures it works with any LangChain version and never fails if LangChain isn't available.
    """
    # Get LangChain's BaseCallbackHandler (lazy-loaded)
    LangChainBaseHandler = _get_langchain_base_handler()
    
    if LangChainBaseHandler is None:
        # LangChain not available - create a standalone class that implements callback methods
        # This allows the callback to be created even if LangChain isn't installed
        # (though it won't work with LangChain chains until LangChain is installed)
        class SecurityCallback:
            """Security callback - LangChain not available. Install langchain to use with LangChain chains."""
            pass
        return SecurityCallback
    
    # LangChain is available - create proper subclass
    class SecurityCallback(LangChainBaseHandler):
        """
        LangChain BaseCallbackHandler that scans prompts and optionally responses for security threats.
        
        This callback can be passed to any LangChain chain, LLM, or agent via the callbacks parameter.
        
        ROBUST CONVERSATION ID MANAGEMENT:
        - Accepts conversation_id parameter in __init__ (app can pass persisted ID)
        - Automatically extracts from LangChain if not provided
        - Walks parent_run_id chain to find root trace_id (LangSmith-style)
        - Respects existing IDs - never overwrites if already set
        """
        
        def __init__(
            self,
            api_endpoint: str,
            api_key: Optional[str] = None,
            timeout: int = 10,
            on_scan_complete: Optional[callable] = None,
            scan_responses: bool = False,
            agent_identifier: Optional[str] = None,
            conversation_id: Optional[str] = None,  # NEW: Accept conversation_id from app
        ):
            """
            Initialize the security callback.
            
            Args:
                api_endpoint: URL of the on-prem scanning API
                api_key: Optional API key for authentication
                timeout: Request timeout in seconds
                on_scan_complete: Optional callback function(text, scan_results, text_type) -> bool
                                 Should return True to allow, False to block
                                 text_type will be "prompt" or "response"
                scan_responses: If True, also scans responses after generation
                agent_identifier: Optional agent identifier for custom guardrails enforcement
                conversation_id: Optional conversation ID (if provided, SDK will use this instead of extracting)
            """
            # Call parent __init__ if it exists (some LangChain versions don't require it)
            try:
                super().__init__()
            except TypeError:
                # Parent doesn't accept arguments - that's fine
                pass
            
            self.api_endpoint = api_endpoint
            self.api_key = api_key
            self.timeout = timeout
            self.on_scan_complete = on_scan_complete
            self.scan_responses = scan_responses
            self.agent_identifier = agent_identifier
            self._provided_conversation_id = conversation_id  # Store provided ID
            
            # Import the security scanner
            try:
                from .scanner import scan_prompt as _scan_prompt
                from .scanner import scan_response as _scan_response
                self._scan_prompt = _scan_prompt
                self._scan_response = _scan_response
            except ImportError:
                logger.error("scanner module not available")
                self._scan_prompt = None
                self._scan_response = None
            
            # CRITICAL: If conversation_id provided, set it immediately
            # This ensures SDK uses the persisted ID from app (e.g., Streamlit session_state)
            if self._provided_conversation_id:
                _set_conversation_id_in_attributes(self._provided_conversation_id, source="app_provided")
                logger.debug(f"Using provided conversation_id: {self._provided_conversation_id}")
        
        def on_chain_start(
            self, 
            serialized: Dict[str, Any], 
            inputs: Dict[str, Any], 
            **kwargs: Any
        ) -> None:
            """
            LangChain callback method called when a chain starts.
            
            PRODUCTION-READY STITCHING:
            1. Check if conversation_id already exists in custom attributes (CRITICAL - prevents overwriting)
            2. Use provided conversation_id if available (e.g., Streamlit UUID)
            3. Extract from LangChain trace_id/parent_run_id only if not already set
            4. Set in custom attributes for all spans
            
            This ensures Streamlit UUIDs persist across multiple LangChain calls.
            """
            # CRITICAL: Check if conversation_id already exists in custom attributes FIRST
            # This prevents overwriting a persisted conversation_id (e.g., Streamlit UUID) with a new LangChain trace_id
            conversation_id = None
            try:
                from saf3ai_sdk.core.tracer import tracer as saf3ai_tracer_core
                custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                existing_conv_id = custom_attrs.get('gen_ai.conversation.id') or custom_attrs.get('conversation_id')
                
                if existing_conv_id:
                    # Conversation ID already set - use it (don't overwrite with new trace_id)
                    conversation_id = existing_conv_id
                    logger.debug(f"Using existing conversation_id from custom attributes: {conversation_id}")
            except Exception as e:
                logger.debug(f"Could not check existing conversation_id: {e}")
            
            # Only extract from LangChain if conversation_id doesn't exist
            if not conversation_id:
                # Extract conversation_id (prioritizes provided ID, then LangChain IDs)
                conversation_id = _extract_langchain_conversation_id(
                    kwargs, 
                    use_provided_id=self._provided_conversation_id
                )
                
                if conversation_id:
                    _set_conversation_id_in_attributes(conversation_id, source="chain_start")
                else:
                    # Fallback: Try to extract from current span
                    try:
                        span = trace.get_current_span()
                        if span:
                            conversation_id = _extract_conversation_id(span)
                            if conversation_id:
                                _set_conversation_id_in_attributes(conversation_id, source="span (chain_start fallback)")
                    except Exception as e:
                        logger.debug(f"Failed to extract conversation ID in on_chain_start: {e}")
        
        def on_llm_start(
            self, 
            serialized: Dict[str, Any], 
            prompts: List[str], 
            **kwargs: Any
        ) -> None:
            """
            LangChain callback method called before LLM is invoked.
            
            PRODUCTION-READY STITCHING:
            1. Check if conversation_id already exists in custom attributes (CRITICAL - prevents overwriting)
            2. Use provided conversation_id if available (e.g., Streamlit UUID)
            3. Extract from LangChain trace_id/parent_run_id only if not already set
            4. Set in custom attributes for all spans
            
            This scans all prompts before they are sent to the LLM.
            If the user's policy callback returns False, raises ValueError to block the request.
            
            Args:
                serialized: Serialized LLM configuration
                prompts: List of prompts to be sent to the LLM
                **kwargs: Additional arguments (contains run object with trace_id/run_id)
            """
            # CRITICAL: Check if conversation_id already exists in custom attributes FIRST
            # This prevents overwriting a persisted conversation_id (e.g., Streamlit UUID) with a new LangChain trace_id
            conversation_id = None
            try:
                from saf3ai_sdk.core.tracer import tracer as saf3ai_tracer_core
                custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                existing_conv_id = custom_attrs.get('gen_ai.conversation.id') or custom_attrs.get('conversation_id')
                
                if existing_conv_id:
                    # Conversation ID already set - use it (don't overwrite with new trace_id)
                    conversation_id = existing_conv_id
                    logger.debug(f"Using existing conversation_id from custom attributes: {conversation_id}")
            except Exception as e:
                logger.debug(f"Could not check existing conversation_id: {e}")
            
            # Only extract from LangChain if conversation_id doesn't exist
            if not conversation_id:
                # Extract conversation_id (prioritizes provided ID, then LangChain IDs)
                conversation_id = _extract_langchain_conversation_id(
                    kwargs,
                    use_provided_id=self._provided_conversation_id
                )
                
                if conversation_id:
                    _set_conversation_id_in_attributes(conversation_id, source="llm_start")
                else:
                    # Fallback: Try to extract from current span
                    try:
                        span = trace.get_current_span()
                        if span:
                            conversation_id = _extract_conversation_id(span)
                            if conversation_id:
                                _set_conversation_id_in_attributes(conversation_id, source="span (llm_start fallback)")
                    except Exception as e:
                        logger.debug(f"Failed to extract conversation ID in on_llm_start: {e}")
            
            if not self._scan_prompt:
                logger.warning("Scanner not available, skipping security scan")
                return
            
            # Get the current span for telemetry
            span = trace.get_current_span()
            
            # ALSO get the LangChain span (the one that gets exported)
            langchain_span = None
            try:
                from saf3ai_sdk.instrumentation.langchain_instrumentation import _current_langchain_span
                langchain_span = getattr(_current_langchain_span, 'span', None)
            except (ImportError, AttributeError):
                pass
            
            # Get model name from serialized config (outside loop - same for all prompts)
            model_name = serialized.get("id", ["unknown"])[-1] if isinstance(serialized.get("id"), list) else serialized.get("name", "unknown")
            
            # Add security scan attributes to current span AND LangChain span (setup once)
            spans_to_update = []
            if span and span.is_recording():
                spans_to_update.append(span)
            if langchain_span and langchain_span.is_recording():
                spans_to_update.append(langchain_span)
            
            # Scan each prompt
            for prompt in prompts:
                if not prompt:
                    logger.debug("Empty prompt, skipping security scan")
                    continue
                
                for target_span in spans_to_update:
                    target_span.set_attribute("security.scan.enabled", True)
                    target_span.set_attribute("security.scan.prompt_length", len(prompt))
                    target_span.set_attribute("security.scan.model", model_name)
                    target_span.set_attribute("security.scan.prompt", prompt)
                    target_span.set_attribute("prompt", prompt)
                    target_span.set_attribute("langchain.prompt", prompt)
                    
                    user_input = prompt.split('\n')[0] if prompt else prompt
                    target_span.set_attribute("security.scan.user_input", user_input)
                    target_span.set_attribute("user_input", user_input)
                    
                    # Set conversation_id in span attributes if we have it
                    if conversation_id:
                        target_span.set_attribute("gen_ai.conversation.id", conversation_id)
                
                try:
                    for target_span in spans_to_update:
                        if target_span and target_span.is_recording():
                            target_span.add_event("security_scan_started", {"prompt_length": len(prompt)})
                    
                    # Call the scanner function with agent_identifier
                    metadata = {"agent_identifier": self.agent_identifier} if self.agent_identifier else {}
                    
                    # Pass conversation_id to scanner
                    scan_results = self._scan_prompt(
                        prompt=prompt,
                        api_endpoint=self.api_endpoint,
                        model_name=model_name,
                        conversation_id=conversation_id,
                        api_key=self.api_key,
                        timeout=self.timeout,
                        metadata=metadata
                    )
                    
                    # Get scan duration from results
                    scan_duration = scan_results.get("scan_metadata", {}).get("duration_ms", 0)
                    
                    # Extract detection results from raw API response
                    detection_results = scan_results.get("detection_results", {})
                    
                    # Check if any threats were found
                    threats_found = []
                    for threat_type, result_data in detection_results.items():
                        if result_data.get("result") == "MATCH_FOUND":
                            threats_found.append(threat_type)
                    
                    # Extract categories
                    out_of_scope = scan_results.get("OutofScopeAnalysis", {})
                    detected_categories = out_of_scope.get("detected_categories", [])
                    
                    # Add attributes to ALL spans
                    for target_span in spans_to_update:
                        if target_span and target_span.is_recording():
                            target_span.set_attribute("security.scan.duration_ms", scan_duration)
                            target_span.set_attribute("security.scan.api_status", 200)
                            target_span.set_attribute("security.threats_found", len(threats_found) > 0)
                            target_span.set_attribute("security.threat_count", len(threats_found))
                            
                            if threats_found:
                                target_span.set_attribute("security.threat_types", ",".join(threats_found))
                            
                            if detected_categories:
                                category_names = [c.get("category", "").split("/")[1] for c in detected_categories[:3] if c.get("category")]
                                if category_names:
                                    target_span.set_attribute("security.categories", ",".join(category_names))
                                target_span.set_attribute("security.category_count", len(detected_categories))
                            
                            # Store the complete scan results
                            import json
                            try:
                                scan_results_json = json.dumps(scan_results)
                                if len(scan_results_json) <= 4000:
                                    target_span.set_attribute("security.scan.full_results", scan_results_json)
                                else:
                                    summary = {
                                        "detection_results": detection_results,
                                        "category_count": len(detected_categories),
                                        "top_categories": detected_categories[:3]
                                    }
                                    target_span.set_attribute("security.scan.full_results", json.dumps(summary))
                            except Exception as e:
                                logger.warning(f"Could not serialize scan results: {e}")
                            
                            target_span.add_event("security_scan_completed", {
                                "threats": len(threats_found),
                                "categories": len(detected_categories)
                            })
                    
                    logger.info(
                        f"Security scan completed: {len(threats_found)} threats, "
                        f"{len(detected_categories)} categories"
                    )
                    
                    # Call user's callback if provided
                    should_allow = True
                    if self.on_scan_complete:
                        try:
                            should_allow = self.on_scan_complete(prompt, scan_results, "prompt")
                            logger.info(f"User callback returned: allow={should_allow}")
                            
                            for target_span in spans_to_update:
                                if target_span and target_span.is_recording():
                                    target_span.set_attribute("security.user_decision", "allow" if should_allow else "block")
                                    if not should_allow:
                                        target_span.set_attribute("security.blocked_by", "user_callback")
                        
                        except Exception as callback_error:
                            logger.error(f"Error in user callback: {callback_error}", exc_info=True)
                            should_allow = True
                            for target_span in spans_to_update:
                                if target_span and target_span.is_recording():
                                    target_span.set_attribute("security.callback_error", str(callback_error))
                    
                    if not should_allow:
                        # BLOCK THE REQUEST
                        threat_messages = {
                            "CSAM": "inappropriate content involving minors",
                            "Dangerous": "dangerous or harmful content",
                            "HateSpeech": "hate speech or discriminatory content",
                            "Harassment": "harassing or bullying content",
                            "SexualExplicit": "sexually explicit content",
                            "PIandJailbreak": "an attempt to bypass security controls",
                            "MaliciousURIs": "potentially malicious links",
                            "SenstiveData": "sensitive personal information"
                        }
                        
                        detected_issues = [threat_messages.get(t, t.lower()) for t in threats_found]
                        
                        if len(detected_issues) == 0:
                            issues_text = "content that violates security policy"
                        elif len(detected_issues) == 1:
                            issues_text = detected_issues[0]
                        else:
                            issues_text = ", ".join(detected_issues[:-1]) + f" and {detected_issues[-1]}"
                        
                        error_message = (
                            f"I'm sorry, but I cannot assist with this request. "
                            f"The system detected {issues_text}. "
                            f"This system is not allowed to answer questions of this nature."
                        )
                        
                        logger.warning(f"User callback blocked LLM call: {error_message}")
                        
                        for target_span in spans_to_update:
                            if target_span and target_span.is_recording():
                                target_span.set_status(Status(StatusCode.ERROR, "Security violation detected"))
                                target_span.add_event("security_request_blocked", {
                                    "threat_types": ",".join(threats_found)
                                })
                        
                        raise ValueError(error_message)
                    
                    # Allow the request
                    for target_span in spans_to_update:
                        if target_span and target_span.is_recording():
                            target_span.set_attribute("security.scan.status", "completed")
                            target_span.set_status(Status(StatusCode.OK))
                
                except ValueError:
                    raise
                
                except Exception as e:
                    error_msg = f"Scanning error: {str(e)}"
                    logger.error(error_msg, exc_info=True)
                    
                    for target_span in spans_to_update:
                        if target_span and target_span.is_recording():
                            target_span.set_attribute("security.scan.status", "error")
                            target_span.set_attribute("security.scan.error", error_msg)
    
        def on_llm_end(self, response, **kwargs: Any) -> None:
            """
            LangChain callback method called after LLM finishes generating.
            
            PRODUCTION-READY STITCHING:
            1. Check if conversation_id already exists in custom attributes FIRST (CRITICAL)
            2. Use provided conversation_id if available
            3. Extract from LangChain only if not already set
            4. Fallback to span extraction
            
            This scans the generated response if scan_responses=True.
            
            Args:
                response: The LLMResult containing the generated text
                **kwargs: Additional arguments (may contain run object)
            """
            if not self.scan_responses or not self._scan_response:
                return
            
            # CRITICAL: Check if conversation_id already exists in custom attributes FIRST
            # This prevents overwriting a persisted conversation_id (e.g., Streamlit UUID)
            conversation_id = None
            try:
                from saf3ai_sdk.core.tracer import tracer as saf3ai_tracer_core
                custom_attrs = saf3ai_tracer_core.get_custom_attributes()
                existing_conv_id = custom_attrs.get('gen_ai.conversation.id') or custom_attrs.get('conversation_id')
                
                if existing_conv_id:
                    # Conversation ID already set - use it (don't overwrite with new trace_id)
                    conversation_id = existing_conv_id
                    logger.debug(f"Using existing conversation_id from custom attributes: {conversation_id}")
            except Exception as e:
                logger.debug(f"Could not check existing conversation_id: {e}")
            
            # Only extract from LangChain if conversation_id doesn't exist
            if not conversation_id:
                # Extract conversation_id (prioritizes provided ID, then LangChain IDs)
                conversation_id = _extract_langchain_conversation_id(
                    kwargs,
                    use_provided_id=self._provided_conversation_id
                )
                
                # If extracted, set it in custom attributes for future calls
                if conversation_id:
                    _set_conversation_id_in_attributes(conversation_id, source="llm_end")
            
            # Get the current span
            span = trace.get_current_span()
            
            # ALSO get the LangChain span
            langchain_span = None
            try:
                from saf3ai_sdk.instrumentation.langchain_instrumentation import _current_langchain_span
                langchain_span = getattr(_current_langchain_span, 'span', None)
            except (ImportError, AttributeError):
                pass
            
            # Final fallback: Extract from span if still not found
            if not conversation_id:
                conversation_id = _extract_conversation_id(span)
                if not conversation_id and langchain_span:
                    conversation_id = _extract_conversation_id(langchain_span)
                
                # If extracted from span, set it in custom attributes
                if conversation_id:
                    _set_conversation_id_in_attributes(conversation_id, source="span (llm_end fallback)")
            
            # Extract response text from LLMResult
            response_text = _extract_response_from_llm_result(response)
            if not response_text:
                logger.warning(
                    "No response text extracted from LLMResult - skipping response scan. "
                    f"LLMResult structure: {type(response)}, has generations: {hasattr(response, 'generations')}"
                )
                return
            
            logger.debug(f"Extracted response text length: {len(response_text)} chars")
            
            model_name = "unknown"
            
            # Add response scan attributes
            spans_to_update = []
            if span and span.is_recording():
                spans_to_update.append(span)
            if langchain_span and langchain_span.is_recording():
                spans_to_update.append(langchain_span)
            
            for target_span in spans_to_update:
                target_span.set_attribute("security.response_scan.enabled", True)
                target_span.set_attribute("security.response_scan.length", len(response_text))
                target_span.set_attribute("security.scan.response", response_text)
                target_span.set_attribute("response", response_text)
                target_span.set_attribute("langchain.response", response_text)
                
                if conversation_id:
                    target_span.set_attribute("gen_ai.conversation.id", conversation_id)
            
            try:
                for target_span in spans_to_update:
                    if target_span and target_span.is_recording():
                        target_span.add_event("security_response_scan_started", {"response_length": len(response_text)})
                
                # Scan the response
                metadata = {"agent_identifier": self.agent_identifier} if self.agent_identifier else {}
                
                scan_results = self._scan_response(
                    response=response_text,
                    api_endpoint=self.api_endpoint,
                    model_name=model_name,
                    conversation_id=conversation_id,
                    api_key=self.api_key,
                    timeout=self.timeout,
                    metadata=metadata
                )
                
                # Extract detection results
                detection_results = scan_results.get("detection_results", {})
                threats_found = [k for k, v in detection_results.items() if v.get("result") == "MATCH_FOUND"]
                
                # Add telemetry to ALL spans
                for target_span in spans_to_update:
                    if target_span and target_span.is_recording():
                        target_span.set_attribute("security.response_threats_found", len(threats_found) > 0)
                        target_span.set_attribute("security.response_threat_count", len(threats_found))
                        if threats_found:
                            target_span.set_attribute("security.response_threat_types", ",".join(threats_found))
                        
                        # Store the complete response scan results
                        import json
                        try:
                            scan_results_json = json.dumps(scan_results)
                            if len(scan_results_json) <= 4000:
                                target_span.set_attribute("security.response_scan.full_results", scan_results_json)
                            else:
                                out_of_scope = scan_results.get("OutofScopeAnalysis", {})
                                detected_categories = out_of_scope.get("detected_categories", [])
                                summary = {
                                    "detection_results": detection_results,
                                    "category_count": len(detected_categories),
                                    "top_categories": detected_categories[:3]
                                }
                                target_span.set_attribute("security.response_scan.full_results", json.dumps(summary))
                        except Exception as e:
                            logger.warning(f"Could not serialize response scan results: {e}")
                
                # Call user's callback if provided
                should_allow = True
                if self.on_scan_complete:
                    try:
                        should_allow = self.on_scan_complete(response_text, scan_results, "response")
                        logger.info(f"User callback for response: allow={should_allow}")
                        
                        for target_span in spans_to_update:
                            if target_span and target_span.is_recording():
                                target_span.set_attribute("security.response_user_decision", "allow" if should_allow else "block")
                    except Exception as e:
                        logger.error(f"Error in response callback: {e}", exc_info=True)
                        should_allow = True
                
                if not should_allow:
                    error_message = (
                        f"🚫 Security Violation: The generated response contains security concerns. "
                        f"Detected: {', '.join(threats_found)}."
                    )
                    logger.warning(f"Response blocked: {error_message}")
                    
                    for target_span in spans_to_update:
                        if target_span and target_span.is_recording():
                            target_span.set_status(Status(StatusCode.ERROR, "Response security violation"))
                            target_span.add_event("security_response_blocked", {
                                "threat_types": ",".join(threats_found)
                            })
            
            except Exception as e:
                logger.error(f"Error scanning response: {e}", exc_info=True)
    
    return SecurityCallback

# Create SecurityCallback class at module load time (lazy-loaded)
SecurityCallback = _create_security_callback_class()

def create_security_callback(
    api_endpoint: str, 
    api_key: Optional[str] = None, 
    timeout: int = 10, 
    on_scan_complete: Optional[callable] = None,
    scan_responses: bool = False, 
    agent_identifier: Optional[str] = None,
    conversation_id: Optional[str] = None,  # NEW: Accept conversation_id from app
):
    """
    Create LangChain callbacks that scan prompts and optionally responses for security threats.
    
    ROBUST CONVERSATION ID MANAGEMENT:
    - Accepts conversation_id parameter - App can pass persisted ID (e.g., from Streamlit session_state)
    - SDK automatically extracts from LangChain if not provided
    - SDK walks parent_run_id chain to find root trace_id (LangSmith-style)
    - SDK respects existing IDs - never overwrites if already set
    
    This function returns a BaseCallbackHandler instance that can be passed to any LangChain
    chain, LLM, or agent via the callbacks parameter.
    
    IMPORTANT: The Saf3AI SDK must be initialized before creating callbacks.
    Call saf3ai_sdk.init(framework="langchain", ...) first.
    
    Args:
        api_endpoint: URL of the on-prem scanning API
        api_key: Optional API key for authentication
        timeout: Request timeout in seconds
        on_scan_complete: Optional callback function(text, scan_results, text_type) -> bool
                         Should return True to allow, False to block
                         text_type will be "prompt" or "response"
        scan_responses: If True, also scans responses after generation
        agent_identifier: Optional agent identifier for custom guardrails enforcement
        conversation_id: Optional conversation ID (if provided, SDK will use this instead of extracting)
                         This enables apps to persist conversation IDs across reruns (e.g., Streamlit)
    
    Returns:
        A SecurityCallback instance (BaseCallbackHandler subclass) that can be used as a LangChain callback
    """
    # Use lazy detection - always check at runtime
    if not _is_langchain_available():
        error_msg = (
            f"LangChain not available - cannot create security callback.\n"
            f"Please install LangChain: pip install langchain\n"
            f"Or for newer versions: pip install langchain-core langchain"
        )
        logger.error(error_msg)
        # Return None instead of raising to allow graceful degradation
        # Callers should check for None return value
        return None
    
    # Recreate SecurityCallback class if LangChain wasn't available at module load time
    # This ensures it works even if LangChain is installed after module import
    global SecurityCallback
    if SecurityCallback is None or (hasattr(SecurityCallback, '__doc__') and 'LangChain not available' in str(SecurityCallback.__doc__)):
        SecurityCallback = _create_security_callback_class()
    
    # Check if SDK is initialized
    try:
        from saf3ai_sdk.core.tracer import tracer as saf3ai_tracer_core
        if not saf3ai_tracer_core.initialized:
            raise RuntimeError(
                "Saf3AI SDK not initialized. "
                "Please call saf3ai_sdk.init(framework='langchain', ...) before creating callbacks. "
                "Example:\n"
                "  from saf3ai_sdk import init\n"
                "  init(framework='langchain', service_name='...', agent_id='...', ...)\n"
                "  from saf3ai_sdk.langchain_callbacks import create_security_callback\n"
                "  callback = create_security_callback(...)"
            )
    except ImportError:
        raise RuntimeError(
            "Saf3AI SDK not initialized. "
            "Please call saf3ai_sdk.init(framework='langchain', ...) before creating callbacks."
        )
    
    return SecurityCallback(
        api_endpoint=api_endpoint,
        api_key=api_key,
        timeout=timeout,
        on_scan_complete=on_scan_complete,
        scan_responses=scan_responses,
        agent_identifier=agent_identifier,
        conversation_id=conversation_id,  # Pass conversation_id to callback
    )

def _extract_response_from_llm_result(llm_result: LLMResult) -> str:
    """
    Extract ONLY the textual content from a LangChain LLMResult.
    
    LangChain generations typically expose .text, or a message with .content.
    We walk the generations list and collect any string content we find.
    """
    try:
        response_parts: List[str] = []
        
        generations = getattr(llm_result, "generations", None)
        if not generations:
            logger.debug("LLMResult has no generations attribute")
            return ""
        
        if not generations:
            logger.debug("LLMResult generations is empty")
            return ""
        
        for generation_list in generations:
            if not generation_list:
                continue
                
            for generation in generation_list:
                text_value = None
                
                # Try generation.text first (most common)
                if hasattr(generation, "text"):
                    text_attr = generation.text
                    if isinstance(text_attr, str) and text_attr.strip():
                        text_value = text_attr
                    elif text_attr:
                        try:
                            text_value = str(text_attr).strip()
                            if not text_value:
                                continue
                        except Exception:
                            logger.debug(f"Could not convert generation.text to string: {type(text_attr)}")
                            continue
                
                # Try generation.message.content (for chat models)
                if not text_value and hasattr(generation, "message"):
                    message = generation.message
                    content = getattr(message, "content", None)
                    
                    if isinstance(content, str) and content.strip():
                        text_value = content
                    elif isinstance(content, list):
                        # Handle list of content chunks
                        for chunk in content:
                            chunk_text = getattr(chunk, "text", None)
                            if chunk_text and isinstance(chunk_text, str) and chunk_text.strip():
                                response_parts.append(chunk_text)
                        continue
                    elif content:
                        try:
                            text_value = str(content).strip()
                            if not text_value:
                                continue
                        except Exception:
                            logger.debug(f"Could not convert message.content to string: {type(content)}")
                            continue
                
                if text_value:
                    response_parts.append(text_value)
        
        if response_parts:
            result = "\n".join(response_parts)
            logger.debug(f"Extracted {len(response_parts)} text parts, total length: {len(result)} chars")
            return result
        
        logger.warning(
            "LLMResult generations contained no extractable string content. "
            f"Generation structure: {[type(g).__name__ for gen_list in generations for g in gen_list] if generations else 'empty'}"
        )
        return ""
    except Exception as e:
        logger.error(f"Error extracting response from LLMResult: {e}", exc_info=True)
        return ""
