from .safe_to_l2_migration import safe_to_l2_migration

__all__ = ["safe_to_l2_migration"]
