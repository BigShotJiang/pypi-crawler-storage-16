import enum


class SafeOperatorMode(enum.Enum):
    BLOCKCHAIN = 0
    TX_SERVICE = 1
