class InvalidDerivationPath(Exception):
    message = "The provided derivation path is not valid"
