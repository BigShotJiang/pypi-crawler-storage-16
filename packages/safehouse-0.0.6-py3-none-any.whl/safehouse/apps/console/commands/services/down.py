from safehouse.services import docker_compose

def run():
    docker_compose.down()
