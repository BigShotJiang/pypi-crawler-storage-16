from typing import List


def run(args: List[str]):
    pass
