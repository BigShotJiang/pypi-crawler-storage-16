from typing import Dict


JsonBlob = Dict[str, object]
