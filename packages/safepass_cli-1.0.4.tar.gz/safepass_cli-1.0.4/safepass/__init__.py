"""SafePass - Offline Password Manager"""

__version__ = "1.0.4"
__author__ = "SafePass Team"
