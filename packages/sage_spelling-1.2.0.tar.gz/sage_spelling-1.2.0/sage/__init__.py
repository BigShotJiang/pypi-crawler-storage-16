__version__ = "1.1.0"
__author__ = "Nikita Martynov, Mark Baushenko, Alexandr Abramov and Alena Fenogenova"
__email__ = "nikita.martynov.98@list.ru"

from .utils.lang_utils import AVAILABLE_LANG_CODES

__all__ = [
    "AVAILABLE_LANG_CODES",
]
