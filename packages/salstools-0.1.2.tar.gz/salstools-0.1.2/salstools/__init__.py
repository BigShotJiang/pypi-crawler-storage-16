#SalsTools
'''
add_pct = helper function for formulas - adds a Pct column to a Count column.

smart_bar = smart bar chart with a number of variables to set visual parameters




Make module importable system-wide:	"pip install -e ." if installing locally(use terminal from dir with files) 
Must run from folder containing	setup.py
Access functions with	import SalsTools as sals
Control which functions are exposed	Use __init__.py

'''



from .main import add_pct,smart_bar
