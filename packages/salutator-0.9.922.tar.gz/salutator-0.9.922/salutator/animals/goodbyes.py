class GoodByer:
    def __init__(self, name: str):
        self.name = name

    def salute(self):
        print(f"{self.name} trots away happily with a final bark of farewell!")

