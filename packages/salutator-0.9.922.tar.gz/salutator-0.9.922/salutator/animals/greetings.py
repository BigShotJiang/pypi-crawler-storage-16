class Greeter:
    def __init__(self, name: str):
        self.name = name

    def salute(self):
        print(f"{self.name} wags its tail excitedly in greeting!")

