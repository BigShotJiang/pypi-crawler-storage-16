# salutator/goodbyes.py

class GoodByer:
    def __init__(self, name: str):
        self.name = name

    def salute(self):
        print(f"Goodbye, {self.name}! See you soon!")

