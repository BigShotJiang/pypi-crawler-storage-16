class GoodByer:
    def __init__(self, name: str):
        self.name = name

    def salute(self):
        print(f"The {self.name} sways gently as a goodbye in the breeze.")

