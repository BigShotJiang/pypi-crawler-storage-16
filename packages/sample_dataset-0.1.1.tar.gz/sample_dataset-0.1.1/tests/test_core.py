from sample_dataset import hello

def test_hello():
    assert hello("Ludovica") == "Hello, Ludovica!"