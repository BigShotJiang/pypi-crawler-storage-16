# -*- coding: utf-8 -*-

import samplemaker.baselib.devices

print("Base library loaded")