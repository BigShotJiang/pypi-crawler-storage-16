# -*- coding: utf-8 -*-
"""
Resources module for samplemaker.

This module provides access to resource files and compiled extensions,
including the boopy C++ extension for Boolean polygon operations.
"""
