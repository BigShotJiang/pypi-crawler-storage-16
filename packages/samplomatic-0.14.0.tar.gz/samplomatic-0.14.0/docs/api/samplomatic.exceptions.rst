samplomatic.exceptions
======================

.. automodapi:: samplomatic.exceptions
   :no-inheritance-diagram:
   :no-heading:
