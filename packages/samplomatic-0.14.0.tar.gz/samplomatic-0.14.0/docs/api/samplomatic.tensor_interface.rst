samplomatic.tensor_interface
============================

.. automodapi:: samplomatic.tensor_interface
   :no-heading:
   :sort:
