samplomatic.virtual_registers
=============================

.. automodapi:: samplomatic.virtual_registers
   :no-heading:
