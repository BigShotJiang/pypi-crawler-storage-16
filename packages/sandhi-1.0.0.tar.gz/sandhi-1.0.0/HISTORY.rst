History
=======

1.0.0 (2025-12-10)
------------------

* Marked the project as Production/Stable and bumped the version to 1.0.0.
* Implemented a usable command-line interface (``sandhi``) wrapping ``sandhi.Sandhi``.
* Documented CLI usage alongside the library API in ``README.rst`` and ``USAGE.rst``.
* Added tests for the CLI to complement the existing rule and transliteration tests.
* Updated CI and metadata for consistent Python 3 support.

0.1.0 (2022-07-03)
------------------

* First release on PyPI.
