require "../perl/apavAxa_any.pl";

my $input = $ARGV[0];
my $result_string = apavAdaniyamAH($input);
print $result_string;