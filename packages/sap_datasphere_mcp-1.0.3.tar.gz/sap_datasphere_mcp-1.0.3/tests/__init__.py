"""
SAP Datasphere MCP Server - Test Suite

Integration tests for validating MCP server functionality with real SAP Datasphere APIs.
"""

__version__ = "1.0.0"
