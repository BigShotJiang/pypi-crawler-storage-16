"""
This algorithm is a proposal from Sapiens Technology®️ for a new concept of language model architecture focused on direct CPU training.
Its concept aims to establish a new type of paradigm that enables cheaper and more accessible training.
The CPUModel architecture allows for fast and efficient training on home hardware with low computational power.
It is useful for students and developers looking to create specialized models quickly, cheaply, and accurately.
Although large language models can be created with this architecture, it will perform better on small language models that are hyper-specialized.
Any alteration, disclosure, or public comment about the technical and theoretical concepts involved in this algorithm without prior authorization
from Sapiens Technology®️ is strictly prohibited and subject to legal action by our legal team.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from .sapiens_cpu import *
"""
This algorithm is a proposal from Sapiens Technology®️ for a new concept of language model architecture focused on direct CPU training.
Its concept aims to establish a new type of paradigm that enables cheaper and more accessible training.
The CPUModel architecture allows for fast and efficient training on home hardware with low computational power.
It is useful for students and developers looking to create specialized models quickly, cheaply, and accurately.
Although large language models can be created with this architecture, it will perform better on small language models that are hyper-specialized.
Any alteration, disclosure, or public comment about the technical and theoretical concepts involved in this algorithm without prior authorization
from Sapiens Technology®️ is strictly prohibited and subject to legal action by our legal team.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
