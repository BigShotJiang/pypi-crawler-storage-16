from importlib import metadata

from .sdk import *

__app_name__ = "satcat"
__version__ = metadata.version(__package__)
