class SATException(Exception):
    pass
