from satispy.solver.minisat import *
from satispy.solver.lingeling import *
