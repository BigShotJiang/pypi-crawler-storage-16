from .test import print_x
def run():
    print_x("今天是2025/12/9")