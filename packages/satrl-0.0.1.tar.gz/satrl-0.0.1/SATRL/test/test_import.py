def print_x(x):
    print(f"x={x}")
