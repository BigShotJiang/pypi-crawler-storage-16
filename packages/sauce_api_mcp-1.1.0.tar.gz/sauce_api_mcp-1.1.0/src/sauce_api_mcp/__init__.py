"""Sauce Labs MCP Server.

A Model Context Protocol (MCP) server for interacting with Sauce Labs APIs.
Provides tools for managing jobs, builds, teams, users, and test assets.
"""

# Version information
__version__ = "1.1.0"
__author__ = "Marcus Merrell"
__email__ = "marcus.merrell@saucelabs.com"

from .main import SauceLabsAgent
from .models import (
    AccountInfo,
    LookupUsers,
    LookupServiceAccounts,
    LookupTeamsResponse,
    ErrorResponse
)
__all__ = [
    "SauceLabsAgent",
    "AccountInfo",
    "LookupUsers",
    "LookupServiceAccounts",
    "LookupTeamsResponse",
    "ErrorResponse"
]

# Optional: Set up logging
import logging
logging.getLogger(__name__).addHandler(logging.NullHandler())