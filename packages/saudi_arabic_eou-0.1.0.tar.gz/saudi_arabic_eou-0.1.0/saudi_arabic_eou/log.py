import logging

logger = logging.getLogger("livekit.plugins.arabic_eou")
