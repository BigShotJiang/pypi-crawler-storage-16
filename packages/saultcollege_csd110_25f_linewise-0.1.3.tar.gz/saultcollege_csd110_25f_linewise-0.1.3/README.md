Here is a **shorter, clean, well-formatted, English README**, ideal for PyPI:

---

# **linewise**

`linewise` is a simple and safe command-line tool for analyzing text files.
It can count:

* **Lines**
* **Words**
* **Characters**
* Or **all metrics at once**

---

## **Installation**

```bash
pip install linewise
```

---

## **Usage**

```bash
linewise <file> [options]
```

### **Options**

| Option         | Description           |
| -------------- | --------------------- |
| `-h`, `--help` | Show help message     |
| `--lines`      | Count only lines      |
| `--words`      | Count only words      |
| `--chars`      | Count only characters |

If no option is provided, all metrics are returned.

---

## **Examples**

```bash
linewise notes.txt --lines
linewise notes.txt --words
linewise notes.txt --chars
linewise notes.txt
```

Example output:

```
lines: 12
words: 85
chars: 451
```

---

## **How It Works**

### **Argument Parsing**

`parse_args()` validates:

* One file per command
* One metric flag at a time
* Valid flags only (`lines`, `words`, `chars`)

### **Safe File Reading**

`linewise()` reads the file with full error handling:

* File not found
* Directory instead of file
* Permission denied
* Invalid encoding

### **Counting Functions**

All counting functions are **pure**:

* `count_lines(text)` → uses `.splitlines()`
* `count_words(text)` → uses `.split()`
* `count_char(text)` → uses `len(text)`

### **Main Entry Point**

`main()` coordinates:

1. Argument parsing
2. File processing
3. Formatted CLI output

---

## **Help Command**

```bash
linewise --help
```

---

## **License**

MIT (or your choice)

---

If you want, I can also generate a **pyproject.toml**, **setup.cfg**, and **entry point** configuration for PyPI.
