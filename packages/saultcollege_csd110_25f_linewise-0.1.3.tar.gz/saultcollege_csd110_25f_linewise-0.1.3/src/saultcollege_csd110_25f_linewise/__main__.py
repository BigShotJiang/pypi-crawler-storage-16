from saultcollege_csd110_25f_linewise.cli import main

if __name__ == "__main__":
    main()