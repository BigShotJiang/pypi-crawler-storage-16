def are_equal(str1: str, str2: str) -> bool:
    if str1.lower() == str2.lower():
        return True
    else:
        return False
