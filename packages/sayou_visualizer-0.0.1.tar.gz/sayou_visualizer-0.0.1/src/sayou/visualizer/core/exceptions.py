from sayou.core.exceptions import SayouCoreError


class VisualizerError(SayouCoreError):
    pass
