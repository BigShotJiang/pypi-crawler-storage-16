FRAME_H5_VERSION = "3.0"

class FrameH5:
    X_SEQ               = "x_seq"
    Y_SEQ               = "y_seq"
    Z                   = "z"
    TUNER_PROFILE       = "tuner_profile"
    RESULT_VALUES       = "result_values"
    RESULT_META         = "result_meta"
    FORMAT_VERSION      = "format_version"