RAYBATCH_COLLECTION_H5_VERSION = "1.0"

class BatchesH5:
    BATCHES = "batches"
