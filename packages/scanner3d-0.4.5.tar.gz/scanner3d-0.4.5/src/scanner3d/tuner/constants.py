from typing import Final
WD_COMMENT = "working distance"
FOCUS_COMMENT = "focus"

__all__ = ["WD_COMMENT", "FOCUS_COMMENT"]