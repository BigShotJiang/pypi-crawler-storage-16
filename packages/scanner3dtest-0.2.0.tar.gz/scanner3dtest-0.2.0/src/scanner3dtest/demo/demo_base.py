from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from scanner3d.test.base.analysis import Analysis
from scanner3d.test.base.album_settings import AlbumSettings
from scanner3d.ray_trace.raytrace_settings import RayTraceSettings


@dataclass(slots=True)
class DemoBase(ABC):
    required_analysis: Analysis
    required_settings: AlbumSettings | RayTraceSettings
    fallback_file: Path | None = None

    @property
    def name(self) -> str:
        return type(self).__name__

    @abstractmethod
    def run(self, file_path: Path) -> None:
        ...