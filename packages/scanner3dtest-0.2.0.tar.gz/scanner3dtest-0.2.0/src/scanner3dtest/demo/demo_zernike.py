from __future__ import annotations
import matplotlib.pyplot as plt
from pathlib import Path
from allytools.types import validate_cast
from allytools.logger import get_logger
from scanner3d.afs.album import Album
from scanner3d.test.base.test_factory import zernike_quick
from scanner3d.test.base.albums import album_radial_quick, album_sparse_grid_quick
from scanner3dtest.demo.demo_base import DemoBase
from scanner3d.analysis.zernike_meta import ZernikeMeta
from scanner3d.analysis.zernike_data import ZernikeData

log = get_logger(__name__)

class DemoZernikeStandard(DemoBase):

    def __init__(self) -> None:
        super().__init__(required_analysis=zernike_quick, required_settings=album_sparse_grid_quick)

    def run(self, file_path: Path) -> None:
        """
        Demo of loading a Zernike album (HDF5), selecting frame/shot,
        reading Zernike coefficients + meta, and plotting them.
        """
        # 1️⃣ Load album
        log.info(f"Reading Zernike album: {file_path}")
        album = Album.load(file_path)

        # 2️⃣ Restore camera reference
        camera = album.camera_ref.resolve()

        # 3️⃣ Pick Z-frame
        z_focus = camera.z_range.z_focus
        frame = album[z_focus]
        log.info(f"Requested z={z_focus.value_mm:.3f} mm → selected frame z={frame.z.value_mm:.3f}")

        # 4️⃣ Select shot — here: center of grid
        shot = frame.top_right_shot()
        log.info(f"Selected Zernike shot at grid cell (row={frame.n_rows}, col={frame.n_cols})")
        print(shot)

        # 5️⃣ The shot result must be ZernikeData
        result  = validate_cast(shot.result, ZernikeData)
        meta: ZernikeMeta = result.meta

        print("\n──────── ZERNIKE META ────────")
        print(meta)

        # 6️⃣ Retrieve coefficients
        coeffs = result.get_raw()        # ndarray, sorted by index
        terms = result.terms             # list[ZernikeTerm]

        print("\n──────── ZERNIKE TERMS ────────")
        for t in terms:
            print(f"Z{t.index:3d} = {t.coefficient:+.6f}  {t.label or ''}")

        # 7️⃣ Plot coefficients
        indices = [t.index for t in terms]
        plt.figure(figsize=(10, 4))
        plt.bar(indices, coeffs)
        plt.xlabel("Zernike Index")
        plt.ylabel("Coefficient")
        plt.title(f"Zernike Coefficients at z={frame.z.value_mm:.3f} mm\ncell ({frame.n_rows},{frame.n_cols})")
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()
        log.info("Zernike Standard demo complete.")
