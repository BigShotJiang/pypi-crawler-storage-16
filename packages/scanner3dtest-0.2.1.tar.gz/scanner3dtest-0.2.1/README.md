# PythonLibs

A.Sharapov Python libraries

---

## 🚀 Features


---

## 📦 Installation

```bash
1️⃣  From the `scanner3dtest` folder create and activate a virtual environment (if not created yet)

2️⃣  Install the package in editable mode:
pip install -e .

3️⃣  To quickly see how all demo modules work, you can run the combined demo launcher:
python run_all_demos.py