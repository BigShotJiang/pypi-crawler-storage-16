import textwrap
import matplotlib.font_manager as fm

def wrap_preserve_lines(text: str, width: int = 80) -> str:

    text = text.replace("────────────────────────────", "-" * 28)

    wrapped_lines = []
    for line in text.splitlines():
        if not line.strip():
            wrapped_lines.append("")  # keep empty lines
        else:
            wrapped_lines.extend(textwrap.wrap(line, width=width))

    return "\n".join(wrapped_lines)


def get_emoji_font():
    for font_path in fm.findSystemFonts():
        lower = font_path.lower()
        if (
            "emoji" in lower
            or "seguiemj" in lower
            or "seguisym" in lower
            or "apple color emoji" in lower
            or "notoemoji" in lower
        ):
            return fm.FontProperties(fname=font_path)
    return fm.FontProperties(family="sans-serif")