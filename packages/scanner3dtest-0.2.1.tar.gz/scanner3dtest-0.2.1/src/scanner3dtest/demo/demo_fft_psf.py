import matplotlib.pyplot as plt
import re
from pathlib import Path
from scanner3d.afs.album import Album
from allytools.units import Length, LengthUnit
from allytools.logger import get_logger
from imagera.plotter import PlotParameters, CMaps
from scanner3d.test.base.test_factory import fft_psf_quick
from scanner3d.test.base.albums import album_major_frame_3
from scanner3dtest.demo.demo_base import DemoBase
from scanner3d.analysis.fft_psf_from_shot import fft_psf_from_shot
from scanner3dtest.aid import wrap_preserve_lines,get_emoji_font


log = get_logger(__name__)
class DemoFftPsf(DemoBase):

    def __init__(self) -> None:
        # Declare required analysis and settings for this demo
        super().__init__(required_analysis=fft_psf_quick, required_settings=album_major_frame_3)

    def run(self, file_path: Path) -> None:
        # 1️⃣ Load PSF album from disk
        log.info(f"Reading PSF album: {file_path}")
        album = Album.load(file_path)

        # 2️⃣ Resolve camera and focus index
        camera = album.camera_ref.resolve()
        z_focus = camera.z_range.z_focus

        # 3️⃣ Select frame at focus
        frame = album[z_focus]
        log.info(f"Requested z : {z_focus.value_mm:.3f} [mm] and selected z: {frame.z.value_mm} [mm]")

        # 4️⃣ Select PSF shot at grid corner
        shot = frame.top_right_shot()

        # 5️⃣ Compute FFT PSF from shot data
        fft_shot = fft_psf_from_shot(shot=shot, wavelength=camera.primary_wavelength)

        # 6️⃣ Compute Airy radius and crop FFT PSF around core
        airy_radius = camera.objective.airy_radius(camera.primary_wavelength)
        k = 5
        fft_shot_cropped = fft_shot.get_crop(k, airy_radius)

        # 7️⃣ Log selected shot information
        log.info(
            f"Selected PSF shot at grid corner: row={frame.n_rows}, "
            f"col={frame.n_cols}, shape: {shot.shape}"
        )

        # 8️⃣ Define plotting parameters for PSF visualization
        plot_params = PlotParameters(
            cmap=CMaps.JET,
            dpi=300,
            with_colorbar=True,
            show_lattice=True,
            lattice_pitch=Length(25, LengthUnit.UM),
        )

        # 9️⃣ Render original PSF shot image
        shot_image = shot.plot(
            plot_params,
            plot_label=(
                f"PSF at {z_focus.value_mm:.2f} mm\n"
                f"cell ({frame.n_rows},{frame.n_cols})"
            ),
        )

        # 🔟 Render cropped FFT PSF image
        fft_shot_image = fft_shot_cropped.scalar2d.get_image_bundle(
            plot_params,
            plot_label=(
                f"Crop ±{k}x Airy radius {airy_radius.to(LengthUnit.UM):.2f}[um]"
            ),
        )

        # 1️⃣1️⃣ Render overview frame image
        frame_img = frame.plot(
            fig_size_in=(Length(2, LengthUnit.INCH), Length(2, LengthUnit.INCH))
        )

        # 1️⃣2️⃣ Convert all images to RGB arrays
        rgb_shot = shot_image.to_numpy("rgb8")
        rgb_frame = frame_img.to_numpy("rgb8")
        rgb_fft_shot = fft_shot_image.to_numpy("rgb8")

        # 1️⃣3️⃣ Show frame, shot, FFT PSF, and album __str__ side-by-side
        album_text = str(album)
        frame_text = str(frame)
        shot_text  = str(shot)

        text_block = (f"ALBUM:\n{album_text}\n\n"
                      f"FRAME:\n{frame_text}\n\n"
                      f"SHOT:\n{shot_text}")
        wrapped_text = wrap_preserve_lines(text_block)


        plt.figure(figsize=(20, 5))

        # 1️⃣ Frame overview
        plt.subplot(1, 4, 1)
        plt.imshow(rgb_frame)
        plt.axis("off")

        # 2️⃣ PSF shot
        plt.subplot(1, 4, 2)
        plt.imshow(rgb_shot)
        plt.axis("off")

        # 3️⃣ FFT PSF (cropped)
        plt.subplot(1, 4, 3)
        plt.imshow(rgb_fft_shot)
        plt.axis("off")

        # 4️⃣ Text panel: ALBUM + FRAME + SHOT (with emojis)
        ax = plt.subplot(1, 4, 4)
        ax.axis("off")
        ax.text(
            0.02, 0.98,
            wrapped_text,
            va="top",
            ha="left",
            fontsize=12,
            fontproperties=get_emoji_font(),
            transform=ax.transAxes)
        plt.tight_layout()
        plt.show()