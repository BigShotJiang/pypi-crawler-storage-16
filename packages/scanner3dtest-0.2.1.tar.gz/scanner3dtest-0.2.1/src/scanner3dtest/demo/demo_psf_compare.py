import matplotlib.pyplot as plt
import scanner3dtest
from pathlib import Path
from allytools.units import LengthUnit, Length
from allytools.logger import get_logger
from imagera.plotter import PlotParameters, CMaps
from scanner3d.afs.album import Album
from scanner3d.scanners.ScannersDB import ScannersDB
from scanner3d.test.base.test_factory import zernike_quick
from scanner3d.test.base.albums import album_sparse_grid_quick
from gosti.fft_psf.fft_psf import FftPsf
from gosti.fft_psf.fft_psf_from_zemax_report import fft_psf_from_zemax_report
from gosti.scalar2d.compare_scalar2d import Scalar2Comparator
from scanner3d.test.base.test_factory import fft_psf_quick
from scanner3dtest.resolve_album_h5 import resolve_album_h5
from scanner3dtest.demo.demo_base import DemoBase
from scanner3d.analysis.fft_psf_from_shot import fft_psf_from_shot


log = get_logger(__name__)
class DemoPSFCompare(DemoBase):
    def __init__(self) -> None:
        super().__init__(required_analysis=zernike_quick, required_settings=album_sparse_grid_quick)

    def run(self, file_path: Path) -> None:

        # 1️⃣ Load Zernike PSF album
        log.info(f"Reading Zernike album: {file_path}")
        zernike_album = Album.load(file_path)

        # 2️⃣ Load FFT PSF album for the same scanner
        fft_psf_album_path = resolve_album_h5(
            scanner=ScannersDB.Spider2ProC,
            required_analysis=fft_psf_quick,
            required_settings=album_sparse_grid_quick)
        fft_psf_album = Album.load(fft_psf_album_path)

        # 3️⃣ Resolve camera and obtain focus index
        camera = zernike_album.camera_ref.resolve()
        z_focus = camera.z_range.z_focus

        # 4️⃣ Extract Zernike and FFT shots at the same field
        zernike_frame = zernike_album[z_focus]
        zernike_shot = zernike_frame.top_right_shot()
        fft_psf_frame = fft_psf_album[z_focus]
        fft_psf_shot = fft_psf_frame.top_right_shot()
        log.info("Selecting Shot from Zernike album: row=%d, col=%d with image coordinates x=%s y=%s",
            zernike_frame.n_rows, zernike_frame.n_cols, zernike_shot.field_x, zernike_shot.field_y)
        log.info("Selecting Shot from FFT PSF album: row=%d, col=%d with image coordinates x=%s y=%s",
                 fft_psf_frame.n_rows, fft_psf_frame.n_cols, fft_psf_shot.field_x, fft_psf_shot.field_y)


        # 5️⃣ Create "general" FFT PSF instance from Shot
        fft_psf_ = fft_psf_from_shot(shot=fft_psf_shot, wavelength=camera.primary_wavelength)
        fft_psf_.save_psf_npz(Path("test.npz"))


        # 7️⃣ Extract Zernike coefficients for PSF reconstruction
        coefficients = zernike_shot.result.get_raw()
        n_coef = zernike_shot.result.shape[0]
        wavelength = camera.primary_wavelength
        exit_pupil_diameter = camera.objective.exit_pupil_diameter
        exit_pupil_position = camera.objective.exit_pupil_position_to_image
        focal_length = camera.objective.EFL

        # 8️⃣ Parameters for FFT / Zernike PSF resolution
        grid_size = 256
        pad_factor = 16

        # 9️⃣ Compute Zernike PSF using FFT synthesis
        psf_zernike = FftPsf.from_zernike(
            coefficients=coefficients,
            n_coef=n_coef,
            wavelength=wavelength,
            exit_pupil_diameter=exit_pupil_diameter,
            exit_pupil_position=exit_pupil_position,
            focal_length=focal_length,
            grid_size=grid_size,
            pad_factor=pad_factor,
            field_x_img=zernike_shot.field_x,
            field_y_img=zernike_shot.field_y)

        # 🔟 Load reference Zemax FFT PSF from report
        p = Path(scanner3dtest.__file__).resolve().parent
        data_dir = p / "zemax_data"
        zemax_psf_path = data_dir / "Spider2ProC_FFT_PSF_Quick_Sparse_Grid_Quick_top_right.txt"
        log.info("Reading Zemax FFT PSF report from: %s", zemax_psf_path)
        if not zemax_psf_path.is_file():
            raise FileNotFoundError(
                f"Expected Zemax FFT PSF report at {zemax_psf_path}, "
                f"please place the file there or adjust the path."
            )
        psf_zemax = fft_psf_from_zemax_report(path=zemax_psf_path)

        # 1️⃣1️⃣ Crop all PSFs around Airy radius for fair comparison
        airy_radius = camera.objective.airy_radius(wavelength)
        k = 5
        cropped_psf_zernike = psf_zernike.get_crop(k, airy_radius)
        cropped_psf_zemax = psf_zemax.get_crop(k, airy_radius)
        cropped_psf_fft = fft_psf_.get_crop(k, airy_radius)


        # 1️⃣2️⃣ Configure plotting parameters
        plot_params = PlotParameters(
            cmap=CMaps.JET,
            dpi=300,
            size_in=(Length(4, LengthUnit.INCH), Length(4, LengthUnit.INCH)),
            with_colorbar=True
        )

        # 1️⃣3️⃣ Compute Zernike → Zemax similarity metrics
        cmp_zernike = Scalar2Comparator(cropped_psf_zemax.scalar2d, cropped_psf_zernike.scalar2d)
        metrics_zernike = cmp_zernike.compare()

        # 1️⃣4️⃣ Compute FFT → Zemax similarity metrics
        cmp_fft = Scalar2Comparator(cropped_psf_zemax.scalar2d, cropped_psf_fft.scalar2d)
        metrics_fft = cmp_fft.compare()

        # 1️⃣5️⃣ Generate image bundles with correlation in title
        psf_zemax_bundle = cropped_psf_zemax.scalar2d.get_image_bundle(
            plot_params, plot_label="Original Zemax PSF (Reference)"
        )
        psf_zernike_bundle = cropped_psf_zernike.scalar2d.get_image_bundle(
            plot_params, plot_label=f"PSF from Zernike, corr {metrics_zernike.corr:.3f}"
        )
        psf_fft_bundle = cropped_psf_fft.scalar2d.get_image_bundle(
            plot_params, plot_label=f"FFT PSF, corr {metrics_fft.corr:.3f}"
        )

        # 1️⃣6️⃣ Convert image bundles to RGB arrays
        psf_zemax_rgb = psf_zemax_bundle.to_numpy("rgb8")
        psf_zernike_rgb = psf_zernike_bundle.to_numpy("rgb8")
        psf_fft_rgb = psf_fft_bundle.to_numpy("rgb8")

        # 1️⃣7️⃣ Display PSFs side-by-side
        fig, axes = plt.subplots(1, 3, figsize=(4.5, 2.3), dpi=300)
        axes[0].imshow(psf_zemax_rgb);   axes[0].axis("off")
        axes[1].imshow(psf_zernike_rgb); axes[1].axis("off")
        axes[2].imshow(psf_fft_rgb);     axes[2].axis("off")
        plt.tight_layout(pad=0.2)
        plt.show()
