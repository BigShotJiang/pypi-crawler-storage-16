import matplotlib.pyplot as plt
from pathlib import Path
from scanner3d.afs.album import Album
from allytools.units import LengthUnit, Length
from allytools.logger import get_logger
from scanner3d.test.base.test_factory import zernike_quick
from scanner3d.test.base.albums import album_radial_quick
from gosti.fft_psf.fft_psf import FftPsf
from scanner3dtest.demo.demo_base import DemoBase
from imagera.plotter import PlotParameters, CMaps

log = get_logger(__name__)
class DemoZernikePSF(DemoBase):

    def __init__(self) -> None:
        super().__init__(required_analysis=zernike_quick,required_settings=album_radial_quick)

    def run(self, file_path: Path) -> None:
        # 1️⃣ Load Zernike PSF album
        log.info(f"Reading Zernike album: {file_path}")
        album = Album.load(file_path)

        # 2️⃣ Resolve camera and focus index
        camera = album.camera_ref.resolve()
        z_focus = camera.z_range.z_focus

        # 3️⃣ Select frame at focus plane
        frame = album[z_focus]

        # 4️⃣ Select PSF shot at grid corner
        shot = frame.top_right_shot()
        field_x = shot.field_x
        field_y = shot.field_y
        log.info(
            "Selecting Zernike shot at grid corner: "
            "row=%d, col=%d with image coordinates x=%s y=%s",
            frame.n_rows, frame.n_cols, field_x, field_y
        )

        # 5️⃣ Extract Zernike coefficients for PSF reconstruction
        coefficients = shot.result.get_raw()
        n_coef = shot.result.shape[0]

        # 6️⃣ Gather optical parameters for Zernike PSF computation
        wavelength = camera.primary_wavelength
        exit_pupil_diameter = camera.objective.exit_pupil_diameter
        exit_pupil_position = camera.objective.exit_pupil_position_to_image
        focal_length = camera.objective.EFL
        grid_size = 256
        pad_factor = 16

        # 7️⃣ Compute PSF from Zernike coefficients using FFT synthesis
        fft_psf = FftPsf.from_zernike(
            coefficients=coefficients,
            n_coef=n_coef,
            wavelength=wavelength,
            exit_pupil_diameter=exit_pupil_diameter,
            exit_pupil_position=exit_pupil_position,
            focal_length=focal_length,
            grid_size=grid_size,
            pad_factor=pad_factor,
            field_x_img=field_x,
            field_y_img=field_y
        )

        # 8️⃣ Compute Airy radius and crop PSF around main lobe
        airy_radius = camera.objective.airy_radius(wavelength)
        k = 5
        cropped_fft_psf = fft_psf.get_crop(k, airy_radius)

        # 9️⃣ Configure visualization parameters
        plot_params = PlotParameters(
            cmap=CMaps.JET,
            dpi=300,
            size_in=(Length(4, LengthUnit.INCH), Length(4, LengthUnit.INCH)),
            with_colorbar=True,
            plot_label="Cropped PSF",
            show_lattice=True,
            lattice_pitch=Length(10, LengthUnit.UM)
        )

        # 🔟 Generate RGB image of cropped PSF
        image_bundle = cropped_fft_psf.scalar2d.get_image_bundle(
            plot_params,
            plot_label=f"Restored PSF (Crop ±{k}x Airy)"
        )
        rgb_shot = image_bundle.to_numpy("rgb8")

        # 1️⃣1️⃣ Display PSF
        plt.imshow(rgb_shot)
        plt.axis("off")
        plt.tight_layout(pad=0)
        plt.show()

