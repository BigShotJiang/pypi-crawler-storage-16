from __future__ import annotations
from typing import List
from scanner3dtest.demo.demo_base import DemoBase
from scanner3dtest.demo.demo_fft_psf import DemoFftPsf
from scanner3dtest.demo.demo_zernike_psf import DemoZernikePSF
from scanner3dtest.demo.demo_zernike import DemoZernikeStandard
from scanner3dtest.demo.demo_batch_raytrace import DemoBatchRaytrace
from scanner3dtest.demo.demo_psf_compare import DemoPSFCompare

DEMOS: List[DemoBase] = [
    DemoFftPsf(),
    DemoZernikeStandard(),
    DemoZernikePSF(),
    DemoBatchRaytrace(),
    DemoPSFCompare()
]
