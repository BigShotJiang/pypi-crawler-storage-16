import json
import logging
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)
def load_results_index(output_root: Path) -> list[dict[str, Any]]:
    """Collect all entries from any results_index* file under output_root.

    Supports both:
      - standard JSON (one document per file)
      - JSON Lines (.jsonl) with one JSON object per line
    """
    entries: list[dict[str, Any]] = []

    if not output_root.exists():
        log.debug("Output root %s does not exist; no results_index to load.", output_root)
        return entries
    for idx_path in output_root.rglob("results_index*"):
        if not idx_path.is_file():
            continue
        log.debug("Loading results index file: %s", idx_path)
        try:
            text = idx_path.read_text(encoding="utf-8")
        except OSError:
            log.exception("Failed to read results index file %s", idx_path)
            continue
        for line_no, line in enumerate(text.splitlines(), start=1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                log.exception("Failed to parse JSON line %d in %s", line_no, idx_path)
                continue
            _add_index_data(entries, obj, idx_path, line_no=line_no)
    log.debug("Collected %d entries from results_index files.", len(entries))
    return entries


def _add_index_data(
    entries: list[dict[str, Any]],
    data: Any,
    source: Path,
    *,
    line_no: int | None = None,
) -> None:
    """Normalize index data into flat list[dict]."""

    prefix = f"{source}" if line_no is None else f"{source}:{line_no}"
    if isinstance(data, dict):
        entries.append(data)
    elif isinstance(data, list):
        for e in data:
            if isinstance(e, dict):
                entries.append(e)
            else:
                log.warning("Non-dict entry in list in %s: %r", prefix, type(e))
    else:
        log.warning("Unexpected JSON structure in %s: %r", prefix, type(data))