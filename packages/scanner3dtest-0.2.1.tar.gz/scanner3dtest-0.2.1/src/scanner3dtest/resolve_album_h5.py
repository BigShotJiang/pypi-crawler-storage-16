import logging
from datetime import datetime
from pathlib import Path
from typing import Any
from allytools.strings import sanitize
from scanner3d.test.result_path import get_output_dir
from scanner3d.scanner.scanner import Scanner
from scanner3dtest.index_data import load_results_index
from scanner3dtest.demo.demo_base import DemoBase
from scanner3d.test.base.analysis import Analysis
from scanner3d.test.base.album_settings import AlbumSettings
from scanner3d.ray_trace.raytrace_settings import RayTraceSettings


log = logging.getLogger(__name__)


def _derive_test_name(analysis: Any) -> str:
    for attr in ("test_name", "label", "name"):
        if hasattr(analysis, attr):
            v = getattr(analysis, attr)
            if v is not None:
                return str(v)
    return str(analysis)


def _derive_album_name(album: Any) -> str:
    for attr in ("album_name", "name", "label"):
        if hasattr(album, attr):
            v = getattr(album, attr)
            if v is not None:
                return str(v)
    return str(album)


def _parse_timestamp(ts: str | None) -> datetime:
    if not ts:
        return datetime.min
    try:
        return datetime.fromisoformat(ts)
    except Exception:
        return datetime.min


def resolve_album_h5(
    scanner: Scanner,
    required_analysis: Analysis,
    required_settings: AlbumSettings | RayTraceSettings,
    local_h5_dir: Path | None = None,
) -> Path:
    """
    Resolve .h5 album for a given demo + scanner.
    1) Look into results_index.json under get_output_dir().
       - filter by scanner_name, test_name, album_name
       - pick the newest timestamp
    2) If file missing or no index entry:
       - try local_h5_dir / f"{scanner_name}_{test_name}.h5"
    """
    scanner_name = sanitize(scanner.name)
    test_name = sanitize(_derive_test_name(required_analysis))
    settings_name = sanitize(_derive_album_name(required_settings))
    output_root = get_output_dir(create=False)

    if local_h5_dir is None:
        local_h5_dir = Path(__file__).resolve().parent / "h5"
    log.info("Resolving album for scanner=%s", scanner_name)
    expected_filename = f"{scanner_name}_{test_name}_{settings_name}.h5"
    index_entries = load_results_index(output_root)
    if index_entries:
        log.debug("results_index found, scanning…")
        candidates = [
            e
            for e in index_entries
            if e.get("kind") in {"album_h5", "ray_batch_h5"}
            and e.get("scanner_name") == scanner_name
            and e.get("test_name") == test_name
            and e.get("settings_name") == settings_name
        ]

        if candidates:
            best = max(candidates, key=lambda e: _parse_timestamp(e.get("timestamp")))
            rel = Path(best["path"])
            h5_path = (output_root / rel).resolve()
            log.info("Found matching entry: %s", rel)

            if h5_path.exists():
                log.info("h5 found at %s", h5_path)
                return h5_path
            log.warning("File listed in results_index is missing: %s", h5_path)
            # try same filename in local_h5_dir
            same_name_local = local_h5_dir / rel.name
            if same_name_local.exists():
                log.info("Using local h5 fallback: %s", same_name_local)
                return same_name_local.resolve()
            log.warning("Local fallback with same file name does not exist: %s",same_name_local)
        else:
            log.info(
                "No matching results_index entry for (scanner=%s, test=%s, album=%s)",
                scanner_name,
                test_name,
                settings_name,
            )
    else:
        log.info("No results_index JSON found at all.")
    local_fallback = local_h5_dir / expected_filename
    log.debug("Trying local fallback by name: %s", local_fallback)
    if local_fallback.exists():
        log.info("Using fallback local album: %s", local_fallback)
        return local_fallback.resolve()

    msg = (
        f"Album .h5 not found.\n"
        f"Scanner: {scanner_name!r}\n"
        f"Test:    {test_name!r}\n"
        f"Settings:   {settings_name!r}\n"
        f"Tried:\n"
        f"  • results_index under {output_root}\n"
        f"  • local same-name fallback if entry found\n"
        f"  • local {local_fallback}\n"
    )
    log.error(msg)
    raise FileNotFoundError(msg)
