from scanner3d.scanners.ScannersDB import ScannersDB
from scanner3d.scanner.scanner import Scanner
from scanner3dtest.resolve_album_h5 import resolve_album_h5
from scanner3dtest.demo.demos import DEMOS
from allytools.logger import configure_file_logger

log = configure_file_logger(__file__, console=True)
def run_all_demos_for_scanner(scanner: Scanner) -> None:
    for demo in DEMOS:
        album_path = resolve_album_h5(
            scanner=scanner,
            required_analysis=demo.required_analysis,
            required_settings=demo.required_settings)
        log.info(
            "Run %s on scanner %s with album %s",
            demo.name,
            scanner.name,
            album_path)
        demo.run(album_path)
if __name__ == "__main__":
    run_all_demos_for_scanner(ScannersDB.Spider2ProC)
