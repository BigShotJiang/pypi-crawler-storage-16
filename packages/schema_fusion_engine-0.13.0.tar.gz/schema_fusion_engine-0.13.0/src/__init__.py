"""SchemaFusion Engine - Data Virtualization and Federation Middleware."""

__version__ = "0.11.0"
