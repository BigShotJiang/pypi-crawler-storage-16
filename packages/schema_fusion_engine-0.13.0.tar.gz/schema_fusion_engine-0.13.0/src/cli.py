"""CLI entry point for SchemaFusion - delegates to modular CLI."""

from src.cli import main

if __name__ == "__main__":
    main()
