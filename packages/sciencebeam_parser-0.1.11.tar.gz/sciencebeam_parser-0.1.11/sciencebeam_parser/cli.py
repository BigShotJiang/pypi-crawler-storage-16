import logging


def main():
    print('main')


if __name__ == '__main__':
    logging.basicConfig(level='INFO')
    main()
