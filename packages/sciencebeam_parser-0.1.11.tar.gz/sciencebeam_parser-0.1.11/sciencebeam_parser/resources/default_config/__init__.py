import os


DEFAULT_CONFIG_DIR = os.path.dirname(__file__)


DEFAULT_CONFIG_FILE = os.path.join(DEFAULT_CONFIG_DIR, 'config.yml')
