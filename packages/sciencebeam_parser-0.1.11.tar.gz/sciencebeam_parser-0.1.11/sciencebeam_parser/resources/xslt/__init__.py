import os


XSLT_DIR = os.path.dirname(__file__)


TEI_TO_JATS_XSLT_FILE = os.path.join(XSLT_DIR, 'tei-to-jats.xsl')
