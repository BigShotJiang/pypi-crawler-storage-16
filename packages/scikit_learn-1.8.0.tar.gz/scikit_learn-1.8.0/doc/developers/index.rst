.. _developers_guide:

=================
Developer's Guide
=================

.. toctree::

   contributing
   development_setup
   minimal_reproducer
   develop
   tips
   utilities
   performance
   cython
   misc_info
   bug_triaging
   maintainer
   plotting
