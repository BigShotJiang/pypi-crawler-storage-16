"""Defines mesh-based and meshless domains."""
