"""Various numerical integrators for ODEs.

Includes Runge-Kutta and Störmer-Verlet methods.
"""
