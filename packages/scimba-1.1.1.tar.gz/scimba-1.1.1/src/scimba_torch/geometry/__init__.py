"""A module implementing tools for geometry learning."""
