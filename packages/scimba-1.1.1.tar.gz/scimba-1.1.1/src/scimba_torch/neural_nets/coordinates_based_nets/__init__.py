"""Neural networks based on coordinates."""
