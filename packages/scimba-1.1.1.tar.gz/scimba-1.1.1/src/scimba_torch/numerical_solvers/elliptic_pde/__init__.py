"""Various PINN-based solvers for elliptic PDEs."""
