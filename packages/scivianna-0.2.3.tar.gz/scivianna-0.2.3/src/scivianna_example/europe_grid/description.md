##   Europe grid example

In this example, we plot an Europe map, and display electric production and consumptions per country with a weekly time-step.

Hovering the mouse on the map will update the 1D plot to display the values on the hovered country.

The countries polygons come from:
https://gisco-services.ec.europa.eu/distribution/v1/countries-2024.html

The country time series are aggregated from:
https://www.entsoe.eu/eraa/
