##   MEDCoupling example

In this example, we make a dashboard arranging several 2D slice of a 3D **medcoupling** field. 

Clicking inside the 2D mesh of one panel will offset the other views to the clicked position.

The **medcoupling** documentation can be found at:
https://github.com/SalomePlatform/medcoupling
