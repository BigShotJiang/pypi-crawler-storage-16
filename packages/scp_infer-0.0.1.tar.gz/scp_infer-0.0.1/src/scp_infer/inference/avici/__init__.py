"""init inference modules"""

from .avici_imp import AVICI_Imp
