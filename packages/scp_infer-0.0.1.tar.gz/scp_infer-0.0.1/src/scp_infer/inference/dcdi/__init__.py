"""init inference modules"""

from .dcdi_imp import DCDIImp
# from .dcdi_load import DataManagerAnndata
