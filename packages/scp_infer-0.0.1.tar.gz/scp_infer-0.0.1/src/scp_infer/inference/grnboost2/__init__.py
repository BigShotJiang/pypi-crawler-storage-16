"""init inference modules"""

from .grnboost2_imp import GRNBoost2Imp
