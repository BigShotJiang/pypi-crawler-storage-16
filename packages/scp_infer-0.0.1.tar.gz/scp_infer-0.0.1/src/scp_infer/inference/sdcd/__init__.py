"""init inference modules"""

from .sdcd_imp import SDCDImp
