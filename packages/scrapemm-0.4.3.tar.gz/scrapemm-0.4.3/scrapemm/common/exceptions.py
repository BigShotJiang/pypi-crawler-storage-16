class RateLimitError(Exception):
    pass

class IPBannedError(Exception):
    pass

class ContentNotFoundError(Exception):
    pass
