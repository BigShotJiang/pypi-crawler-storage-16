idk what to say thank you for using my webscraper it took a couple hours to make i personally like it 
