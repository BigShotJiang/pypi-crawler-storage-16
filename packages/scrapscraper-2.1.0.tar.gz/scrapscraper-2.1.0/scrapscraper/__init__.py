
__version__ = "0.1.0"

from .scrapscraper import (
    scrape_website,
    crawl_with_depth,
    is_valid_url,
    scrapedepth,
    scrapelinks,
    scrapetext,
    scrapetitle
)
