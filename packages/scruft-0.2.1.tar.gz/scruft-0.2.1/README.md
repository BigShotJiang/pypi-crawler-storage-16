# scruft

A tool for managing consistency across repositories. This project is a fork of [cruft](https://github.com/cruft/cruft), which is a fantastic project for managing consistency across repos. However,
the project hasn't had any updates since April 2023.
