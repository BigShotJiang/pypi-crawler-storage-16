## __<center> ScurryPy </center>__

[![PyPI version](https://badge.fury.io/py/scurrypy.svg)](https://badge.fury.io/py/scurrypy)

A lightweight, fully readable Discord API framework built to accommodate everything from basic bots to custom frameworks.

## Philosophy

ScurryPy is built on a simple idea: clarity over magic.

* Every operation should be traceable
* No hidden behavior or side effects
* Legacy features can be removed or replaced without rewriting the library
* Models = pure data
* Resources = HTTP logic
* Nothing mixes responsibilities

ScurryPy is not discord.py, hikari, disnake, or any other framework.
ScurryPy is built from scratch.
It is a true Discord API wrapper built on predictable, modern Python principles.

## Framework Features

These features are built into ScurryPy's core. Addons do NOT have to worry about these features.

* Lightweight core (<1000 lines)
* Respects Discord's rate limits
* Models supports both legacy and new features
* No `__future__` hacks to avoid circular import
* Capable of sharding

## ScurryKit

Looking for a higher-level framework comparable to the discord.py, hikari, and others? 
Check out [ScurryKit](link-to-repo), built on top of ScurryPy.
All EasyBot-based examples live in the EasyBot repository.

## Installation

To install the ScurryPy package, run:

```bash
pip install scurrypy
```

## Minimal Addon Example

Demonstrates a minimal slash command using an addon.

```py
    # example
```

## Like What You See?

Explore the full [documentation](https://scurry-works.github.io/scurrypy) for more examples, guides, and API reference.
