# scurrypy/plugins

from .addon import Addon

__all__ = [
    "Addon"
]
