from ._model import POISSONVI

__all__ = ["POISSONVI"]
