from ._minification import get_minified_adata_scrna, get_minified_mudata

__all__ = ["get_minified_adata_scrna", "get_minified_mudata"]
