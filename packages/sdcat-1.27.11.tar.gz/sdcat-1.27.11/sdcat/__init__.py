# sdcat/__init__.py
__version__ = "1.27.11"
