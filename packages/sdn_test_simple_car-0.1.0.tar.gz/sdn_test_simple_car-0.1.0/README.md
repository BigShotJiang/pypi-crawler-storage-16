# sdn-test-simple-car

Simple vehicle abstractions.

## Install
```bash
pip install sdn-test-simple-car
```

## Usage
```python
from sdn_test_simple_car import SimpleCar

car = SimpleCar('Toyota', 'Corolla', 2018)
car.start()
print(car)
```

