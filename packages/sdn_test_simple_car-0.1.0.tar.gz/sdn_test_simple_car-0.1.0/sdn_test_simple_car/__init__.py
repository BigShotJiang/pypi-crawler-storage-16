"""Simple vehicle abstractions."""

from .simple_car import SimpleCar

__version__ = "0.1.0"
__all__ = ["SimpleCar"]

