"""Simple vehicle in memory repository."""

from .in_memory_simple_car_repository import InMemorySimpleCarRepository

__version__ = "1.0.0"
__all__ = ["InMemorySimpleCarRepository"]

