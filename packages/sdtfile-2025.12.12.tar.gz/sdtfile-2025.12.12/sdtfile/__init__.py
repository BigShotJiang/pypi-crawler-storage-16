# sdtfile/__init__.py

from .sdtfile import *
from .sdtfile import __all__, __doc__, __version__

# constants are repeated for documentation

__version__ = __version__
"""Sdtfile version string."""
