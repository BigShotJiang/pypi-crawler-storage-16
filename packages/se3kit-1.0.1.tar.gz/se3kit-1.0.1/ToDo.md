# ToDo List
- Check tests coverage
- save to csv
- Enhance README with examples
    - Create transformations and compose them
    - Transform a homogeneous point
- Add support for multiplication of transformation with a hpoint
- (Omid) Test eye_in_hand and pivot calibrations
- (Omid) Add "add_poses", identify duplicate poses and "remove_poses" methods for eye_in_hand

