SE3kit package
==============

se3kit.degrees module
---------------------

.. automodule:: se3kit.degrees
   :members:
   :undoc-members:
   :show-inheritance:

se3kit.hpoint module
--------------------

.. automodule:: se3kit.hpoint
   :members:
   :undoc-members:
   :show-inheritance:

se3kit.rotation module
----------------------

.. automodule:: se3kit.rotation
   :members:
   :undoc-members:
   :show-inheritance:

se3kit.transformation module
----------------------------

.. automodule:: se3kit.transformation
   :members:
   :undoc-members:
   :show-inheritance:

se3kit.translation module
-------------------------

.. automodule:: se3kit.translation
   :members:
   :undoc-members:
   :show-inheritance:

se3kit.utils module
-------------------

.. automodule:: se3kit.utils
   :members:
   :undoc-members:
   :show-inheritance:

se3kit.calibration module
-------------------------

.. automodule:: se3kit.calibration
   :members:
   :undoc-members:
   :show-inheritance:

