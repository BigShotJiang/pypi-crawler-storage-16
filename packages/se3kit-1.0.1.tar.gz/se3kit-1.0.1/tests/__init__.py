"""
Unit tests for SE3Kit library.

This package contains separate test modules for each major component
of the SE3Kit library (rotation, translation, transformation, robot, etc.).
"""
