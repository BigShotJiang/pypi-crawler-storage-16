.. Seal5 documentation master file, created by
   sphinx-quickstart on Fri Apr 26 15:11:01 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Seal5's documentation!
=================================

.. autosummary::
   :toctree: _autosummary
   :recursive:

   seal5

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
