#!/bin/bash

set -e

python3 -m flake8 seal5 examples
