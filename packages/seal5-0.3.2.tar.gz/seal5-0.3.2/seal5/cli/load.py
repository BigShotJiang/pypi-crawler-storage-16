#
# Copyright (c) 2023 TUM Department of Electrical and Computer Engineering.
#
# This file is part of Seal5.
# See https://github.com/tum-ei-eda/seal5.git for further info.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""Command line subcommand for loading Seal5 inputs (CoreDesc,yml, ll,.c ...) ."""

from seal5.flow import Seal5Flow
from seal5.logging import Logger


logger = Logger("cli")


def add_load_options(parser):
    """Setup parser for load argument group."""
    load_parser = parser.add_argument_group("load options")
    load_parser.add_argument(
        "--files",
        nargs="+",
        type=str,
        default="examples/cdsl/rv_example/Example.core_desc",
        help="Files that should be loaded",
    )
    load_parser.add_argument("--overwrite", default=False, action="store_true", help="Overwrite loaded file")


def get_parser(subparsers):
    """ "Define and return a subparser for the load subcommand."""
    parser = subparsers.add_parser("load", description="load Seal5 inputs.")
    parser.set_defaults(func=handle)
    add_load_options(parser)
    return parser


def handle(args):
    """Callback function which will be called to process the load subcommand"""
    seal5_flow = Seal5Flow(args.dir, name=args.name)
    logger.warning(args.files)
    seal5_flow.load(files=list(args.files), overwrite=args.overwrite, verbose=args.verbose)
