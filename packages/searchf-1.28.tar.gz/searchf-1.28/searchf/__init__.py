'''Module global properties'''
__url__ = 'https://github.com/human3/searchf'
__version__ = '1.28'
