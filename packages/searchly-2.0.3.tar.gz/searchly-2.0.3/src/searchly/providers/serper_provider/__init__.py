"""Serper API client."""
