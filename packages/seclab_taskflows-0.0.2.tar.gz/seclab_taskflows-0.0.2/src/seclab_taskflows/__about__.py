# SPDX-FileCopyrightText: 2025 GitHub
# SPDX-License-Identifier: MIT

__version__ = "0.0.2"
