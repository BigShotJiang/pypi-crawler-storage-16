License
=======

.. include:: ../LICENSE
   :literal:
