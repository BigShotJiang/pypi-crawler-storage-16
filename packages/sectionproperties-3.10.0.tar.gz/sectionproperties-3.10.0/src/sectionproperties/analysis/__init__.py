"""sectionproperties analysis module."""

from sectionproperties.analysis.section import Section
