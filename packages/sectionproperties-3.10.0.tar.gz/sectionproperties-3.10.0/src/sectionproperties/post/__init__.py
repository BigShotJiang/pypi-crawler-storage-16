"""sectionproperties post-processor."""
