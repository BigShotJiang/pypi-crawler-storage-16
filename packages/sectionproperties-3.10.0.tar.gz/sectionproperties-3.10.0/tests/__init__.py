"""Test suite for the sectionproperties package."""
