"""Benchmark tests for sectionproperties."""
