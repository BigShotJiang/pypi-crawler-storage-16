"""Geometry tests for sectionproperties."""
