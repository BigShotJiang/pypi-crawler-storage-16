from __future__ import annotations

def crack_hash(*args, **kwargs):
    raise RuntimeError(
        "Password cracking is not provided by securezy. "
        "Use `securezy hash ...` and `securezy hash verify ...` for legitimate auditing/verification workflows."
    )
