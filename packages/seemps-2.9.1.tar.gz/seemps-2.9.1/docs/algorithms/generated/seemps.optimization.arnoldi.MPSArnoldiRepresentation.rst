seemps.optimization.arnoldi.MPSArnoldiRepresentation
====================================================

.. currentmodule:: seemps.optimization.arnoldi

.. autoclass:: MPSArnoldiRepresentation

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         MPSArnoldiRepresentation.add_vector
         MPSArnoldiRepresentation.build_Krylov_basis
         MPSArnoldiRepresentation.eigenvector
         MPSArnoldiRepresentation.energy_and_variance
         MPSArnoldiRepresentation.exponential
         MPSArnoldiRepresentation.restart_with_ground_state
         MPSArnoldiRepresentation.restart_with_vector



   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         MPSArnoldiRepresentation.empty
         MPSArnoldiRepresentation.operator
         MPSArnoldiRepresentation.H
         MPSArnoldiRepresentation.N
         MPSArnoldiRepresentation.V
         MPSArnoldiRepresentation.strategy
         MPSArnoldiRepresentation.tol_ill_conditioning
         MPSArnoldiRepresentation.gamma
         MPSArnoldiRepresentation.orthogonalize

