from importlib.metadata import version

number = version("seemps")
