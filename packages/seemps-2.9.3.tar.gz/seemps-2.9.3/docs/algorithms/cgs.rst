.. _alg_cgs:

*******************************
Conjugate gradient descent
*******************************

The conjugate gradient method solves systems of linear equations whose matrix is positive-semidefinite.

.. autosummary::
    :toctree: generated/

    ~seemps.cgs.cgs






