﻿

seemps.analysis.chebyshev.estimate\_order
=========================================

.. currentmodule:: seemps.analysis.chebyshev



.. autofunction:: seemps.analysis.chebyshev.estimate_order

