﻿

seemps.analysis.chebyshev.projection\_coefficients
==================================================

.. currentmodule:: seemps.analysis.chebyshev



.. autofunction:: seemps.analysis.chebyshev.projection_coefficients

