﻿

seemps.analysis.lagrange.lagrange\_basic
========================================

.. currentmodule:: seemps.analysis.lagrange



.. autofunction:: seemps.analysis.lagrange.lagrange_basic

