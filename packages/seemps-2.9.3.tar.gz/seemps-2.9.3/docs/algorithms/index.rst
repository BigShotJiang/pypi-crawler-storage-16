*******************
Index of algorithms
*******************

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   tensor_split
   mps_simplification
   gradient_descent
   cgs
   arnoldi
   dmrg
   runge_kutta
   crank_nicolson
   tebd_evolution
   chebyshev
   tt-cross
   lagrange
