.. currentmodule:: seemps

.. _analysis_chebyshev:

*********************
Chebyshev Polynomials
*********************
