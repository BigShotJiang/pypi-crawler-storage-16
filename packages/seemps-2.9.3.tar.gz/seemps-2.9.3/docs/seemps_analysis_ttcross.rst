.. currentmodule:: seemps

.. _analysis_ttcross:

*******************************************
Tensor Train Cross Interpolation (TT-Cross)
*******************************************
