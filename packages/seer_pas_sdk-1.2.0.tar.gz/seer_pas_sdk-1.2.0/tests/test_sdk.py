"""
`test_sdk` -- high-level tests for the seer-pas-sdk package
"""


def test_import():
    """
    Stub test that importing the root module is successful.
    TODO: replace this with more meaningful tests
    """
    import seer_pas_sdk
