"""
Endpoints module - Agnostic endpoint management.
"""

from .manager import EndpointManager

__all__ = ['EndpointManager']
