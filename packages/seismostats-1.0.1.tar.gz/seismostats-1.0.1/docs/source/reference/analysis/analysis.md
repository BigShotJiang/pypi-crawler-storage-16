# Analysis

```{toctree}
:maxdepth: 2

bvalues
avalues
mc
declustering
various
```