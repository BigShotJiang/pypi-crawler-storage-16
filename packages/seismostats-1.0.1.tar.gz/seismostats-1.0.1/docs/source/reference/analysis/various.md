# Various
```{eval-rst}
.. currentmodule:: seismostats
```

## Magnitude Conversion
```{eval-rst}
.. autosummary::
    :toctree: ../api/
    :nosignatures:

    analysis.apply_edwards
```