# Settings and Options

```{eval-rst}
.. currentmodule:: seismostats
```


## Working with options
    
```{eval-rst}
.. autosummary::
    :toctree: api/
    :nosignatures:

    utils.set_option
    utils.get_option
```