# API Documentation

```{toctree}
:maxdepth: 2

formats/formats
client
analysis/analysis
plots
utils
config
```