# User Guide

```{toctree}
:maxdepth: 2

what_is_seismostats
getting_started
10minute_intro
usage
docs
contributing
```