# Fundamentals and usage

```{toctree}
:maxdepth: 1

dataformats
catalogs
estimate_mc
estimate_b
estimate_a
plots
synthetic
b_significant
../notebooks/manual.nblink
```