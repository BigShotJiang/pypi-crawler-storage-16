# flake8: noqa
from seismostats.io.parser import (QuakeMLHandler, parse_quakeml,
                                   parse_quakeml_file, parse_quakeml_response)
