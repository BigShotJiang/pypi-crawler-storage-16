"""
Exemples d'utilisation de la bibliothèque Selenium UI Test Tool
"""

