# API Reference

## Core Functions

::: semantic_frame.main
    options:
      show_root_heading: true

## Analyzers (The Math)

::: semantic_frame.core.analyzers
    options:
      show_root_heading: true

## Enums (The Dictionary)

::: semantic_frame.core.enums
    options:
      show_root_heading: true
