"""semiautomatic test suite"""
