from enum import Enum


class DataSourceType(Enum):
    CSV = "CSV"
