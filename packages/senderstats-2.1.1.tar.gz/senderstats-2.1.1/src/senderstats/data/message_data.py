from dataclasses import dataclass


@dataclass
class MessageData:
    def __init__(self):
        pass
