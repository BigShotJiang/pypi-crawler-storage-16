"""CLI entry point for `python -m sensei.eval`."""

from sensei.eval.runner import main


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
