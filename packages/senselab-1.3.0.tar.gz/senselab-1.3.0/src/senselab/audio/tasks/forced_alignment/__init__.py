"""This module provides the API for forced alignment."""

from .forced_alignment import align_transcriptions  # noqa: F401
