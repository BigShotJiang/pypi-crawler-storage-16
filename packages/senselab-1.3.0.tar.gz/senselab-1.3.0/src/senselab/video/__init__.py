"""This module contains implementation for video processing."""
