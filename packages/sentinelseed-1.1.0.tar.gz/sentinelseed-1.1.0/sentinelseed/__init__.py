"""
sentinelseed - AI safety guardrails using Sentinel alignment seeds.

Add safety to any LLM with one line of code.

Example:
    >>> from sentinelseed import SentinelGuard
    >>> guard = SentinelGuard()
    >>> messages = guard.wrap_messages([{"role": "user", "content": "Hello!"}])

    # Or use Sentinel for validation
    >>> from sentinelseed import Sentinel
    >>> sentinel = Sentinel(seed_level="standard")
    >>> result = sentinel.validate_action("Delete all files")

See https://sentinelseed.dev for documentation.
"""

from .guard import SentinelGuard, create_guard, get_seed, Sentinel, SeedLevel
from .seeds import SEEDS

__version__ = "1.1.0"
__all__ = [
    "SentinelGuard",
    "create_guard",
    "get_seed",
    "Sentinel",
    "SeedLevel",
    "SEEDS",
]
