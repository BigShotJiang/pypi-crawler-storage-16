"""
Sentinel Guard - AI safety guardrails for LLMs.

Example:
    >>> from sentinelseed import SentinelGuard
    >>> guard = SentinelGuard()
    >>> messages = guard.wrap_messages([{"role": "user", "content": "Hello!"}])

    # Or use Sentinel class for validation
    >>> from sentinelseed import Sentinel
    >>> sentinel = Sentinel(seed_level="standard")
    >>> result = sentinel.validate_action("Delete all files")
"""

from typing import List, Dict, Optional, Literal, Any, Tuple, Union
from dataclasses import dataclass
from enum import Enum
import re

from .seeds import SEEDS

SeedVersion = Literal["v1", "v2"]
SeedVariant = Literal["minimal", "standard", "full"]


class SeedLevel(Enum):
    """Seed levels for Sentinel."""
    MINIMAL = "minimal"
    STANDARD = "standard"
    FULL = "full"


@dataclass
class THSPAnalysis:
    """Result of THSP gate analysis."""
    safe: bool
    gates: Dict[str, str]
    issues: List[str]
    confidence: float


class SentinelGuard:
    """
    Sentinel Guard - Add AI safety to any LLM.

    Example:
        >>> guard = SentinelGuard()
        >>> seed = guard.get_seed()
        >>> messages = guard.wrap_messages([{"role": "user", "content": "Hello!"}])

    Args:
        version: Seed version ('v1' or 'v2'). Default: 'v2'
        variant: Seed variant ('minimal' or 'standard'). Default: 'standard'
        custom_seed: Custom seed content. If provided, version/variant are ignored.
    """

    def __init__(
        self,
        version: SeedVersion = "v2",
        variant: SeedVariant = "standard",
        custom_seed: Optional[str] = None
    ):
        self.version = version
        self.variant = variant

        if custom_seed:
            self._seed = custom_seed
        else:
            self._seed = self._load_seed(version, variant)

    def _load_seed(self, version: SeedVersion, variant: SeedVariant) -> str:
        """Load a seed by version and variant."""
        key = f"{version}_{variant}"

        if key not in SEEDS:
            available = [k for k in SEEDS.keys() if "_" in k]
            raise ValueError(
                f"Seed not found: {version}/{variant}. "
                f"Available: {', '.join(available)}"
            )

        return SEEDS[key]

    def get_seed(self) -> str:
        """Get the raw seed content."""
        return self._seed

    def get_metadata(self) -> Dict[str, Any]:
        """Get seed metadata."""
        protocols = {
            "v1": "THS (Truth, Harm, Scope)",
            "v2": "THSP (Truth, Harm, Scope, Purpose)"
        }

        return {
            "version": self.version,
            "variant": self.variant,
            "tokens": len(self._seed) // 4,  # Rough estimate
            "protocol": protocols.get(self.version, "Unknown")
        }

    def wrap_messages(
        self,
        messages: List[Dict[str, str]],
        append_to_existing: bool = False
    ) -> List[Dict[str, str]]:
        """
        Wrap messages with the Sentinel seed as system prompt.

        Args:
            messages: List of message dicts with 'role' and 'content' keys
            append_to_existing: If True, append seed to existing system message

        Returns:
            Messages with seed prepended as system message

        Example:
            >>> messages = guard.wrap_messages([{"role": "user", "content": "Hello!"}])
            # Returns:
            # [
            #   {"role": "system", "content": "# SENTINEL ALIGNMENT SEED..."},
            #   {"role": "user", "content": "Hello!"}
            # ]
        """
        existing_system = None
        for msg in messages:
            if msg.get("role") == "system":
                existing_system = msg
                break

        if existing_system and append_to_existing:
            return [
                {**msg, "content": self._seed + "\n\n" + msg["content"]}
                if msg.get("role") == "system" else msg
                for msg in messages
            ]

        non_system = [msg for msg in messages if msg.get("role") != "system"]
        system_content = (
            self._seed + "\n\n" + existing_system["content"]
            if existing_system
            else self._seed
        )

        return [{"role": "system", "content": system_content}] + non_system

    def analyze(self, content: str) -> THSPAnalysis:
        """
        Analyze content using THSP heuristics.

        Note: This is a simple heuristic analysis. For production use,
        consider using an LLM-based classifier.

        Args:
            content: Content to analyze

        Returns:
            THSPAnalysis with gate results and safety assessment
        """
        content_lower = content.lower()
        issues = []

        # Truth gate - check for deception patterns
        deception_patterns = [
            "fake", "pretend", "deceive", "misinformation",
            "phishing", "impersonate", "forge"
        ]
        truth_fail = any(p in content_lower for p in deception_patterns)
        if truth_fail:
            issues.append("Potential deception detected")

        # Harm gate - check for harmful patterns
        harm_patterns = [
            "bomb", "weapon", "kill", "hack", "malware",
            "poison", "attack", "exploit", "steal"
        ]
        harm_fail = any(p in content_lower for p in harm_patterns)
        if harm_fail:
            issues.append("Potential harm detected")

        # Scope gate - check for bypass attempts
        scope_patterns = [
            "ignore previous", "ignore instructions", "you are now",
            "jailbreak", "dan mode", "developer mode"
        ]
        scope_fail = any(p in content_lower for p in scope_patterns)
        if scope_fail:
            issues.append("Potential scope violation detected")

        # Purpose gate - harder to detect heuristically
        purpose_pass = True

        safe = not (truth_fail or harm_fail or scope_fail)
        confidence = 0.7 if safe else 0.85

        return THSPAnalysis(
            safe=safe,
            gates={
                "truth": "fail" if truth_fail else "pass",
                "harm": "fail" if harm_fail else "pass",
                "scope": "fail" if scope_fail else "pass",
                "purpose": "pass" if purpose_pass else "unknown"
            },
            issues=issues,
            confidence=confidence
        )

    def is_safe(self, content: str) -> bool:
        """
        Check if content is likely safe.

        Args:
            content: Content to check

        Returns:
            True if content passes basic safety checks
        """
        return self.analyze(content).safe


def create_guard(
    version: SeedVersion = "v2",
    variant: SeedVariant = "standard",
    custom_seed: Optional[str] = None
) -> SentinelGuard:
    """
    Create a SentinelGuard with the specified configuration.

    Example:
        >>> guard = create_guard(version="v2", variant="minimal")
        >>> messages = guard.wrap_messages([...])
    """
    return SentinelGuard(version=version, variant=variant, custom_seed=custom_seed)


def get_seed(
    version: SeedVersion = "v2",
    variant: SeedVariant = "standard"
) -> str:
    """
    Get a seed directly without creating a guard instance.

    Example:
        >>> seed = get_seed("v2", "standard")
    """
    guard = SentinelGuard(version=version, variant=variant)
    return guard.get_seed()


class Sentinel:
    """
    Sentinel safety validator for AI agents.

    Provides validation methods for actions, requests, and content.
    Used by integrations (LangGraph, AutoGPT, CrewAI, Solana Agent Kit).

    Example:
        >>> sentinel = Sentinel(seed_level="standard")
        >>> is_safe, concerns = sentinel.validate_action("Delete all files")
        >>> # (False, ["Potential destructive action"])

        >>> result = sentinel.validate_request("How to hack a website")
        >>> # {"should_proceed": False, "concerns": [...], "risk_level": "high"}
    """

    def __init__(
        self,
        seed_level: Union[SeedLevel, str] = "standard",
        version: str = "v2"
    ):
        """
        Initialize Sentinel validator.

        Args:
            seed_level: Safety level (minimal, standard, full)
            version: Seed version (v1, v2)
        """
        if isinstance(seed_level, SeedLevel):
            level = seed_level.value
        else:
            level = seed_level

        self.seed_level = level
        self.version = version
        self._guard = SentinelGuard(version=version, variant=level)

        # Patterns for validation
        self._harm_patterns = [
            r"\b(bomb|weapon|kill|murder|assassinate)\b",
            r"\b(hack|malware|virus|exploit|ddos)\b",
            r"\b(poison|toxin|overdose)\b",
            r"\b(steal|fraud|scam|phishing)\b",
            r"\bdelete\s+all\b",
            r"\bformat\s+(drive|disk|c:)\b",
            r"\brm\s+-rf\b",
            r"\bdrop\s+table\b",
        ]

        self._deception_patterns = [
            r"\b(fake|forge|counterfeit)\b",
            r"\b(impersonate|pretend\s+to\s+be)\b",
            r"\b(misinformation|disinformation)\b",
            r"\b(deceive|manipulate|trick)\b",
        ]

        self._bypass_patterns = [
            r"ignore\s+(previous|all|your)\s+instructions?",
            r"you\s+are\s+now\s+",
            r"(jailbreak|dan\s+mode|developer\s+mode)",
            r"pretend\s+you\s+(have\s+no|don'?t\s+have)",
        ]

    def get_seed(self) -> str:
        """Get the alignment seed content."""
        return self._guard.get_seed()

    def validate(self, content: str) -> Tuple[bool, List[str]]:
        """
        Validate content for safety concerns.

        Args:
            content: Text content to validate

        Returns:
            Tuple of (is_safe, list_of_violations)
        """
        violations = []
        content_lower = content.lower()

        # Check harm patterns
        for pattern in self._harm_patterns:
            if re.search(pattern, content_lower, re.IGNORECASE):
                violations.append("Potential harmful content detected")
                break

        # Check deception patterns
        for pattern in self._deception_patterns:
            if re.search(pattern, content_lower, re.IGNORECASE):
                violations.append("Potential deception detected")
                break

        # Check bypass patterns
        for pattern in self._bypass_patterns:
            if re.search(pattern, content_lower, re.IGNORECASE):
                violations.append("Potential safety bypass attempt")
                break

        is_safe = len(violations) == 0
        return is_safe, violations

    def validate_action(self, action: str) -> Tuple[bool, List[str]]:
        """
        Validate a proposed action for safety.

        Args:
            action: Description of the action to validate

        Returns:
            Tuple of (is_safe, list_of_concerns)
        """
        concerns = []
        action_lower = action.lower()

        # Destructive action patterns
        destructive_patterns = [
            (r"\b(delete|remove|destroy|erase)\s+(all|every)", "Destructive bulk operation"),
            (r"\b(format|wipe)\s+(drive|disk|system)", "System-level destructive action"),
            (r"\brm\s+-rf", "Recursive file deletion"),
            (r"\bdrop\s+(table|database)", "Database destruction"),
            (r"\b(shutdown|halt|kill)\s+(system|server|process)", "System termination"),
        ]

        for pattern, concern in destructive_patterns:
            if re.search(pattern, action_lower, re.IGNORECASE):
                concerns.append(concern)

        # Physical harm patterns
        physical_patterns = [
            (r"\b(turn\s+on|start)\s+.*(leave|unattended)", "Unsupervised hazardous operation"),
            (r"\b(stove|oven|heater|fire).*leave", "Fire hazard"),
            (r"\b(throw|drop|break)\s+", "Potential physical damage"),
        ]

        for pattern, concern in physical_patterns:
            if re.search(pattern, action_lower, re.IGNORECASE):
                concerns.append(concern)

        # General harm check
        is_safe_content, content_violations = self.validate(action)
        concerns.extend(content_violations)

        is_safe = len(concerns) == 0
        return is_safe, concerns

    def validate_request(self, request: str) -> Dict[str, Any]:
        """
        Validate a request and return detailed assessment.

        Args:
            request: The request to validate

        Returns:
            Dict with should_proceed, concerns, and risk_level
        """
        is_safe, violations = self.validate(request)
        action_safe, action_concerns = self.validate_action(request)

        all_concerns = list(set(violations + action_concerns))

        # Determine risk level
        if not is_safe or not action_safe:
            if any("bypass" in c.lower() for c in all_concerns):
                risk_level = "critical"
            elif any("harm" in c.lower() or "destruct" in c.lower() for c in all_concerns):
                risk_level = "high"
            else:
                risk_level = "medium"
        else:
            risk_level = "low"

        should_proceed = is_safe and action_safe

        return {
            "should_proceed": should_proceed,
            "concerns": all_concerns,
            "risk_level": risk_level,
        }
