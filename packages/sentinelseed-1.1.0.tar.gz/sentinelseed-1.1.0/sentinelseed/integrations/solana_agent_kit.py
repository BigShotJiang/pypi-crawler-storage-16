"""
Solana Agent Kit integration for Sentinel AI.

Provides safety validation for Solana blockchain agents.

Usage:
    from sentinelseed.integrations.solana_agent_kit import (
        SentinelValidator,
        safe_transaction
    )

    validator = SentinelValidator(max_transfer=100.0)
    result = validator.check("transfer", amount=50.0, recipient="ABC...")

    if result.should_proceed:
        # Execute your Solana Agent Kit transaction
        pass
"""

from typing import Any, Dict, List, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum

from sentinelseed import Sentinel, SeedLevel


class TransactionRisk(Enum):
    """Risk levels for blockchain transactions."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class TransactionSafetyResult:
    """Result of transaction safety validation."""
    safe: bool
    risk_level: TransactionRisk
    transaction_type: str
    concerns: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    should_proceed: bool = True
    requires_confirmation: bool = False


class SentinelValidator:
    """
    Safety validator for Solana Agent Kit transactions.

    Example:
        from solana_agent_kit import SolanaAgentKit
        from sentinelseed.integrations.solana_agent_kit import SentinelValidator

        agent = SolanaAgentKit(wallet, rpc_url, config)
        validator = SentinelValidator(max_transfer=10.0)

        result = validator.check("transfer", amount=5.0, recipient="ABC...")
        if result.should_proceed:
            agent.transfer(recipient, amount)
        else:
            print(f"Blocked: {result.concerns}")
    """

    def __init__(
        self,
        seed_level: str = "standard",
        max_transfer: float = 100.0,
        confirm_above: float = 10.0,
        blocked_addresses: Optional[List[str]] = None,
        allowed_programs: Optional[List[str]] = None,
    ):
        self.sentinel = Sentinel(seed_level=seed_level)
        self.max_transfer = max_transfer
        self.confirm_above = confirm_above
        self.blocked_addresses = set(blocked_addresses or [])
        self.allowed_programs = set(allowed_programs or [])
        self.history: List[TransactionSafetyResult] = []

    def check(
        self,
        action: str,
        amount: float = 0,
        recipient: str = "",
        program_id: str = "",
        memo: str = "",
        **kwargs
    ) -> TransactionSafetyResult:
        """Check if a transaction is safe to execute."""
        concerns = []
        recommendations = []
        risk_level = TransactionRisk.LOW

        if recipient and recipient in self.blocked_addresses:
            concerns.append(f"Recipient is blocked: {recipient[:8]}...")
            risk_level = TransactionRisk.CRITICAL

        if self.allowed_programs and program_id:
            if program_id not in self.allowed_programs:
                concerns.append(f"Program not whitelisted: {program_id[:8]}...")
                risk_level = TransactionRisk.HIGH

        if amount > self.max_transfer:
            concerns.append(f"Amount {amount} exceeds limit {self.max_transfer}")
            risk_level = TransactionRisk.CRITICAL

        requires_confirmation = amount > self.confirm_above

        description = self._describe_action(action, amount, recipient, kwargs)
        is_safe, sentinel_concerns = self.sentinel.validate_action(description)

        if not is_safe:
            concerns.extend(sentinel_concerns)
            if risk_level.value < TransactionRisk.HIGH.value:
                risk_level = TransactionRisk.HIGH

        suspicious = self._check_patterns(action, amount, memo)
        if suspicious:
            concerns.extend(suspicious)
            if risk_level.value < TransactionRisk.MEDIUM.value:
                risk_level = TransactionRisk.MEDIUM

        should_proceed = risk_level not in [TransactionRisk.CRITICAL, TransactionRisk.HIGH]

        if requires_confirmation:
            recommendations.append("High-value: manual confirmation recommended")
        if risk_level in [TransactionRisk.HIGH, TransactionRisk.CRITICAL]:
            recommendations.append("Review transaction details before proceeding")

        result = TransactionSafetyResult(
            safe=len(concerns) == 0,
            risk_level=risk_level,
            transaction_type=action,
            concerns=concerns,
            recommendations=recommendations,
            should_proceed=should_proceed,
            requires_confirmation=requires_confirmation,
        )

        self.history.append(result)
        return result

    def _describe_action(
        self,
        action: str,
        amount: float,
        recipient: str,
        extra: Dict
    ) -> str:
        parts = [f"Solana {action}"]
        if amount:
            parts.append(f"amount={amount}")
        if recipient:
            parts.append(f"to={recipient[:8]}...")
        return " ".join(parts)

    def _check_patterns(
        self,
        action: str,
        amount: float,
        memo: str
    ) -> List[str]:
        suspicious = []
        action_lower = action.lower()

        if "drain" in action_lower or "sweep" in action_lower:
            suspicious.append("Potential drain operation detected")

        if "all" in action_lower and ("transfer" in action_lower or "send" in action_lower):
            suspicious.append("Bulk transfer operation")

        if "approve" in action_lower and amount == 0:
            suspicious.append("Potential unlimited approval")

        if memo:
            memo_check = self.sentinel.validate_request(memo)
            if not memo_check.get("should_proceed", True):
                suspicious.append("Suspicious memo content")

        return suspicious

    def get_stats(self) -> Dict[str, Any]:
        """Get validation statistics."""
        if not self.history:
            return {"total": 0}

        blocked = sum(1 for r in self.history if not r.should_proceed)
        high_risk = sum(1 for r in self.history
                       if r.risk_level in [TransactionRisk.HIGH, TransactionRisk.CRITICAL])

        return {
            "total": len(self.history),
            "blocked": blocked,
            "approved": len(self.history) - blocked,
            "high_risk": high_risk,
            "block_rate": blocked / len(self.history),
        }

    def clear_history(self) -> None:
        """Clear validation history."""
        self.history = []


def safe_transaction(
    action: str,
    params: Optional[Dict[str, Any]] = None,
    validator: Optional[SentinelValidator] = None,
    **kwargs
) -> TransactionSafetyResult:
    """
    Validate a Solana transaction before execution.

    Example:
        from sentinelseed.integrations.solana_agent_kit import safe_transaction

        result = safe_transaction("transfer", amount=5.0, recipient="ABC...")

        if result.should_proceed:
            agent.transfer(recipient, amount)
        else:
            print(f"Blocked: {result.concerns}")
    """
    if validator is None:
        validator = SentinelValidator()

    all_params = {**(params or {}), **kwargs}

    return validator.check(
        action=action,
        amount=all_params.get("amount", 0),
        recipient=all_params.get("recipient", all_params.get("to", "")),
        program_id=all_params.get("program_id", ""),
        memo=all_params.get("memo", ""),
        **{k: v for k, v in all_params.items()
           if k not in ["amount", "recipient", "to", "program_id", "memo"]}
    )


def create_sentinel_actions(
    validator: Optional[SentinelValidator] = None
) -> Dict[str, Callable]:
    """
    Create Sentinel validation actions.

    Example:
        from sentinelseed.integrations.solana_agent_kit import create_sentinel_actions

        actions = create_sentinel_actions()
        result = actions["validate_transfer"](50.0, "ABC123...")
    """
    if validator is None:
        validator = SentinelValidator()

    def validate_transfer(amount: float, recipient: str) -> Dict[str, Any]:
        result = validator.check("transfer", amount=amount, recipient=recipient)
        return {
            "safe": result.should_proceed,
            "risk": result.risk_level.value,
            "concerns": result.concerns,
        }

    def validate_swap(
        amount: float,
        from_token: str = "SOL",
        to_token: str = ""
    ) -> Dict[str, Any]:
        result = validator.check(
            "swap",
            amount=amount,
            memo=f"{from_token} -> {to_token}"
        )
        return {
            "safe": result.should_proceed,
            "risk": result.risk_level.value,
            "concerns": result.concerns,
        }

    def validate_action(action: str, **params) -> Dict[str, Any]:
        result = validator.check(action, **params)
        return {
            "safe": result.should_proceed,
            "risk": result.risk_level.value,
            "concerns": result.concerns,
            "recommendations": result.recommendations,
        }

    def get_safety_seed() -> str:
        return validator.sentinel.get_seed()

    return {
        "validate_transfer": validate_transfer,
        "validate_swap": validate_swap,
        "validate_action": validate_action,
        "get_safety_seed": get_safety_seed,
    }


def create_langchain_tools(
    validator: Optional[SentinelValidator] = None
):
    """
    Create LangChain tools for Solana transaction validation.

    Example:
        from langchain.agents import create_react_agent
        from sentinelseed.integrations.solana_agent_kit import create_langchain_tools

        safety_tools = create_langchain_tools()
        all_tools = solana_tools + safety_tools
        agent = create_react_agent(llm, all_tools)
    """
    try:
        from langchain.tools import Tool
    except ImportError:
        raise ImportError("langchain is required: pip install langchain")

    if validator is None:
        validator = SentinelValidator()

    def check_transaction(description: str) -> str:
        parts = description.strip().split()
        action = parts[0] if parts else "unknown"
        amount = float(parts[1]) if len(parts) > 1 else 0
        recipient = parts[2] if len(parts) > 2 else ""

        result = validator.check(action, amount=amount, recipient=recipient)

        if result.should_proceed:
            msg = f"SAFE: {action} validated"
            if result.requires_confirmation:
                msg += " (high-value: confirm recommended)"
            return msg
        else:
            return f"BLOCKED: {', '.join(result.concerns)}"

    return [
        Tool(
            name="sentinel_check_transaction",
            description=(
                "Check if a Solana transaction is safe before executing. "
                "Input: 'action amount recipient' (e.g., 'transfer 5.0 ABC123'). "
                "Use BEFORE any transfer, swap, or on-chain action."
            ),
            func=check_transaction,
        ),
    ]


class SentinelSafetyMiddleware:
    """
    Wrapper for adding safety checks to function calls.

    Example:
        from sentinelseed.integrations.solana_agent_kit import SentinelSafetyMiddleware

        middleware = SentinelSafetyMiddleware()

        def my_transfer(amount, recipient):
            # your transfer logic
            pass

        safe_transfer = middleware.wrap(my_transfer, "transfer")
        safe_transfer(5.0, "ABC...")  # Validates before executing
    """

    def __init__(self, validator: Optional[SentinelValidator] = None):
        self.validator = validator or SentinelValidator()

    def wrap(self, func: Callable, action_name: str) -> Callable:
        """Wrap a function with safety validation."""
        def wrapper(*args, **kwargs):
            amount = kwargs.get("amount", args[0] if args else 0)
            recipient = kwargs.get("recipient", kwargs.get("to", ""))
            if not recipient and len(args) > 1:
                recipient = args[1]

            result = self.validator.check(
                action_name,
                amount=amount if isinstance(amount, (int, float)) else 0,
                recipient=str(recipient) if recipient else "",
            )

            if not result.should_proceed:
                raise ValueError(
                    f"Transaction blocked: {', '.join(result.concerns)}"
                )

            if result.requires_confirmation:
                print(f"[SENTINEL] High-value {action_name}: {amount}")

            return func(*args, **kwargs)

        return wrapper
