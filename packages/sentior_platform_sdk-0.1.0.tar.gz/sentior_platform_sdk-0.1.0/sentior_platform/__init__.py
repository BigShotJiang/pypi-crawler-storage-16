"""
Sentior Platform SDK (Python)

Gebruik:
    from sentior_platform.generated import ENTITLEMENTS, COLLECTIONS, EVENTS, SDK_VERSION
"""
from . import generated  # type: ignore
