from setuptools import setup, find_packages

setup(
    name="sentior-platform-sdk",
    version="0.1.0",
    description="Internal Sentior platform SDK (entitlements, collections, events)",
    author="Sentior",
    packages=find_packages(),
    install_requires=[],
)
