"""
AUTO-GENERATED package initializer.
"""
from .entitlements import ENTITLEMENTS, Entitlement
from .collections import COLLECTIONS
from .events import EVENTS
from .version import SDK_VERSION

