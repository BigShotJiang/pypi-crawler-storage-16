"""
AUTO-GENERATED. NIET HANDMATIG AANPASSEN.
"""
from typing import Dict

COLLECTIONS: Dict[str, str] = {
  "jobs": "viktor_jobs",
  "evaluations": "users.workspaces.evaluations",
  "recommendations": "viktor_recommendations"
}

