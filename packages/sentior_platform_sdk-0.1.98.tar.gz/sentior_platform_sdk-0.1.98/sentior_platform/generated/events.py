"""
AUTO-GENERATED. NIET HANDMATIG AANPASSEN.
"""
from typing import Dict

EVENTS: Dict[str, str] = {
  "evaluation_created": "sentior.evaluation.created",
  "evaluation_requested": "sentior.evaluation.requested",
  "opportunity_created": "sentior.opportunity.created",
  "opportunity_updated": "sentior.opportunity.updated",
  "nomination_created": "sentior.nomination.created",
  "nomination_updated": "sentior.nomination.updated",
  "nomination_deleted": "sentior.nomination.deleted",
  "nomination_prepare": "sentior.nomination.prepare"
}

