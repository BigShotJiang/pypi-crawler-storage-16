# 🔍 网站SEO优化检查系统

## 📋 系统概述

这是一个全面的网站SEO优化检查系统，可以自动采集指定域名的所有页面源代码，并根据SEO最佳实践进行全面检查和分析。

## 🚀 快速开始

### 基本使用
```bash
# 检查单个网站
python seo_checker.py https://example.com

# 检查并生成详细报告
python seo_checker.py https://example.com --report

# 批量检查多个网站
python seo_checker.py https://site1.com https://site2.com --batch
```

### 高级使用
```bash
# 自定义检查规则
python seo_checker.py https://example.com --rules custom_rules.json

# 生成Excel报告
python seo_checker.py https://example.com --excel

# 深度分析模式
python seo_checker.py https://example.com --deep-analysis
```

## 📁 文件结构

```
website_seo_optimization/
├── 📚 文档
│   ├── README.md                    # 本文件 - 使用指南
│   ├── seo.md                       # 全面的SEO优化标准文档
│   └── 检查规则说明.md               # 检查规则详细说明
├── 🐍 Python脚本
│   ├── seo_checker.py               # 主检查脚本
│   ├── seo_analyzer.py              # SEO分析引擎
│   ├── website_crawler.py           # 网站爬虫
│   └── report_generator.py          # 报告生成器
├── ⚙️ 配置文件
│   ├── seo_config.json              # 主配置文件
│   ├── default_rules.json           # 默认检查规则
│   └── custom_rules.json            # 自定义规则示例
├── 📊 输出文件
│   ├── reports/                     # 生成的报告目录
│   ├── data/                        # 采集的数据目录
│   └── logs/                        # 日志文件目录
└── 🧪 测试文件
    ├── test_seo_checker.py          # 单元测试
    └── sample_websites.txt          # 测试网站列表
```

## 🎯 主要功能

### 1. 网站爬取
- 自动发现和爬取所有页面
- 支持JavaScript渲染
- 智能去重和过滤
- 多线程并发处理

### 2. SEO检查项目
- **页面基础优化**：标题、描述、关键词、H标签
- **技术SEO**：页面速度、移动友好性、结构化数据
- **内容优化**：内容质量、关键词密度、内链外链
- **用户体验**：导航结构、页面布局、可访问性

### 3. 报告生成
- 详细的HTML报告
- Excel数据表格
- JSON格式数据
- 可视化图表

## ⚙️ 配置说明

### 主配置文件 (seo_config.json)
```json
{
  "crawler": {
    "max_pages": 1000,
    "delay": 1.0,
    "timeout": 30,
    "max_depth": 5,
    "user_agent": "SEO-Checker/1.0"
  },
  "seo_rules": {
    "title_min_length": 30,
    "title_max_length": 60,
    "description_min_length": 120,
    "description_max_length": 160,
    "h1_required": true,
    "max_h1_count": 1
  },
  "output": {
    "generate_html": true,
    "generate_excel": true,
    "generate_json": true,
    "include_screenshots": false
  }
}
```

## 📊 检查项目详情

### 页面基础优化
- ✅ 页面标题优化
- ✅ Meta描述优化
- ✅ Meta关键词设置
- ✅ H标签层次结构
- ✅ 图片Alt属性
- ✅ 内部链接优化

### 技术SEO
- ✅ 页面加载速度
- ✅ 移动端适配
- ✅ 结构化数据
- ✅ 网站地图
- ✅ Robots.txt
- ✅ 404错误检查

### 内容优化
- ✅ 关键词密度分析
- ✅ 内容长度检查
- ✅ 重复内容检测
- ✅ 内容质量评分
- ✅ 内链外链分析

### 用户体验
- ✅ 页面导航结构
- ✅ 面包屑导航
- ✅ 页面布局分析
- ✅ 可访问性检查
- ✅ 用户交互元素

## 🚀 使用示例

### 示例1: 基础检查
```bash
python seo_checker.py https://example.com
```

### 示例2: 生成完整报告
```bash
python seo_checker.py https://example.com --report --excel
```

### 示例3: 批量检查
```bash
python seo_checker.py --batch --input websites.txt
```

### 示例4: 自定义规则
```bash
python seo_checker.py https://example.com --rules custom_rules.json
```

## 📈 输出报告

### HTML报告
- 美观的可视化界面
- 详细的检查结果
- 问题优先级分类
- 改进建议

### Excel报告
- 数据表格格式
- 可筛选和排序
- 便于进一步分析

### JSON数据
- 结构化数据格式
- 便于程序处理
- 支持API集成

## 🔧 高级功能

### 1. 自定义检查规则
可以创建自定义的SEO检查规则，满足特定需求。

### 2. 批量处理
支持批量检查多个网站，提高效率。

### 3. 定期监控
可以设置定期检查，监控SEO改进效果。

### 4. 对比分析
支持不同时间点的对比分析。

## 🛠️ 故障排除

### 常见问题
1. **网络超时**：增加timeout设置
2. **内存不足**：减少max_pages设置
3. **权限问题**：检查输出目录权限

### 调试模式
```bash
python seo_checker.py https://example.com --debug --verbose
```

## 📞 技术支持

如果遇到问题，请检查：
1. Python版本（需要3.7+）
2. 依赖包安装
3. 网络连接
4. 目标网站可访问性

## 🔄 更新日志

- v1.0.0 - 初始版本，基础SEO检查功能
- v1.1.0 - 添加批量处理和报告生成
- v1.2.0 - 增加自定义规则支持
- v1.3.0 - 优化性能和用户体验

