"""
Serena VB.NET Plugin

Adds Visual Basic .NET language support to Serena MCP Server.
"""

__version__ = "1.0.1"
__author__ = "LaunchCG"
__license__ = "MIT"

__all__ = ["__version__"]
