::: sereto.singleton
