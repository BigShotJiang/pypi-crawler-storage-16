cli_aliases: dict[str, str] = {
    # Resolve ambiguous command prefixes
    "c": "config",
}
