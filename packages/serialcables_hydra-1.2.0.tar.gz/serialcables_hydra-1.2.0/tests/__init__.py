"""Test suite for JBOF Controller"""
