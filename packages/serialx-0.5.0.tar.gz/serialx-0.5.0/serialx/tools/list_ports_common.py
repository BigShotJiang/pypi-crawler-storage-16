"""Pyserial compatibility module."""

from serialx import SerialPortInfo as ListPortInfo

__all__ = ["ListPortInfo"]
