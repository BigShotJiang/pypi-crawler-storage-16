"""Unit tests for serialx."""
