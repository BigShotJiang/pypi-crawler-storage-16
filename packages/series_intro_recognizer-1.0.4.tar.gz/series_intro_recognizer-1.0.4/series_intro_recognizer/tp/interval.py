from typing import NamedTuple

Interval = NamedTuple('Interval', [('start', float), ('end', float)])
