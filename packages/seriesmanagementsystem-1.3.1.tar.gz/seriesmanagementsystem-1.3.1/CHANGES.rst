Changelog
============

1.3.1 (unreleased)
------------------

- doc: Update documentation

- ci: better ci/cd pipelines


1.3.0 (2024-02-26)
------------------

- fix: correct name in pyproject.toml to match name in pypi
- feature(actions): project now builds with github actions
- refactor(py12): Feature/upgrade to modern python (#1)


1.1.7 (2017-02-24)
------------------

- Adapted to PPIC

- Made Ready for Travis-CI

- Made Read for Readthedocs

- Added initial tests. But we still need more tests.
