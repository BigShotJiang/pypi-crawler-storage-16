About
=====

``seriesManagementSystem`` is a tool to administrate a pool of individual exercisese out of which weekly exercice lessons - a series - can be created. Each exercise come with the task and its solution. The idea is to create weekly collections of exercises - series - which are then  distributed to the students. After a week they have to hand in their solutions. During the next lesson the solution sheet is distributed. The ``seriesManagementSystem`` allows to dynamically create these series out of the bucket of available individual exercises.
