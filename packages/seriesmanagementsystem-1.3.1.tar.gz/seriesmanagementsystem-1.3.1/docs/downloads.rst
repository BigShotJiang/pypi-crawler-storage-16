Downloads
===========

.. only:: builder_html

    Download files directly from here:

    * :download:`seriesmgmt_.pex <../dist/seriesmgmt_.pex>`
