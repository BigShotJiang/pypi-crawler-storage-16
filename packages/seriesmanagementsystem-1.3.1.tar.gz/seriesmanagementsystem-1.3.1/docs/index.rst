
.. include:: ../README.rst

Contents
========

.. toctree::
    :maxdepth: 2

    about
    changes
    install
    usage
    downloads
    credits
    license
