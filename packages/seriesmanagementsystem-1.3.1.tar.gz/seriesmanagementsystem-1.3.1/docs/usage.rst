Usage
=================





Installation
-------------

From pipx
^^^^^^^^^^

Simply run::

    pipx install seriesManagementSystem


Uninstall
-----------

Via pip::

    pips uninstall missingTVShows




Configuration
--------------

Upon the first launch, the script creates the ~/.seriesmgmtsystem/ directory containing:
* logging.yaml where the logger is configured
* seriesmgmtsystem.conf where the general configuration is stored. 
