print("imported seriesmgmtsystem package")
