print("imported seriesmgmtsystem.main package")
