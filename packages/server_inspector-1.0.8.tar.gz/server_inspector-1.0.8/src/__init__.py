"""
Home Server Hardware Inspector Package
Automatically detects and inventories hardware for home server deployment
"""

__version__ = "1.0.0"
