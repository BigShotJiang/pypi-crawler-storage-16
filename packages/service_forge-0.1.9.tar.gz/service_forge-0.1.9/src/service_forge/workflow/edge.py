from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .node import Node
    from .port import Port

class Edge:
    def __init__(
        self,
        start_node: Node,
        end_node: Node,
        start_port: Port,
        end_port: Port,
    ) -> None:
        self.start_node = start_node
        self.end_node = end_node
        self.start_port = start_port
        self.end_port = end_port

    def _simple_clone(self, node_map: dict[Node, Node], port_map: dict[Port, Port]) -> Edge:
        # 检查节点是否为None，避免KeyError
        start_node = node_map[self.start_node] if self.start_node is not None else None
        end_node = node_map[self.end_node] if self.end_node is not None else None
        return Edge(
            start_node=start_node,
            end_node=end_node,
            start_port=port_map[self.start_port],
            end_port=port_map[self.end_port],
        )