from service_now_api_sdk.exceptions import ITSMException


class DownloadAttachment(ITSMException):
    pass


class RecordFilterException(ITSMException):
    pass


class DeleteAttachment(ITSMException):
    pass
