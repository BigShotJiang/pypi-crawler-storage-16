class URLPatterns:
    SYSPARM_QUERY = "sysparm_query"
    NUMBER_FIELD = "number"
    ACTION = "do"
    URI = "uri"
