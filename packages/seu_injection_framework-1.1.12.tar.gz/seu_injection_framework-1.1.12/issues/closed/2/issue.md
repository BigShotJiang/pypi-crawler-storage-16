# Issue #2: Using model.compile() for faster inference.

This will add a huge performance boost to the code. However this seems to require a linux device and I currently use windows.

https://docs.pytorch.org/tutorials/intermediate/torch_compile_tutorial.html#demonstrating-speedups

______________________________________________________________________

| Field       | Value                                                      |
| ----------- | ---------------------------------------------------------- |
| **State**   | closed                                                     |
| **Created** | 2025-06-08T10:49:02Z                                       |
| **Updated** | 2025-12-09T08:35:20Z                                       |
| **Labels**  | enhancement                                                |
| **Author**  | @wd7512                                                    |
| **URL**     | https://github.com/wd7512/seu-injection-framework/issues/2 |
