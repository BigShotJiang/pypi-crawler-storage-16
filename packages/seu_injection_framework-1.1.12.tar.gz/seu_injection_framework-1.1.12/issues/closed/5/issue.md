# Issue #5: Criterion Score has gone negative during multi-class classification

_No description provided._

______________________________________________________________________

| Field       | Value                                                      |
| ----------- | ---------------------------------------------------------- |
| **State**   | closed                                                     |
| **Created** | 2025-06-29T10:08:10Z                                       |
| **Updated** | 2025-12-09T08:35:27Z                                       |
| **Labels**  | bug                                                        |
| **Author**  | @wd7512                                                    |
| **URL**     | https://github.com/wd7512/seu-injection-framework/issues/5 |
