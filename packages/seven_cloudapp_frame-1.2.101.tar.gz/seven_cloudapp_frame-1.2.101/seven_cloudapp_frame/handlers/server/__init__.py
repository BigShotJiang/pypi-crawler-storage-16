# -*- coding: utf-8 -*-
"""
:Author: HuangJianYi
:Date: 2021-07-15 11:57:53
@LastEditTime: 2021-08-10 11:26:21
@LastEditors: HuangJianYi
:description: 
"""
__all__ = ["base_s", "app_s", "act_s", "report_s", "user_s", "launch_s", "theme_s", "ip_s", "price_s", "goods_s", "module_s", "prize_s", "order_s", "task_s","cms_s"]
