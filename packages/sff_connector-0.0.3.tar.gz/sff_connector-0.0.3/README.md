# sff_connector

This is a connector package for Snowflake integration.

## Installation

```bash
pip install sff_connector
```

## Usage

```python
from sff_connector import hello_world

hello_world()
```
