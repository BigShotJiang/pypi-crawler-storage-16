# SPDX-License-Identifier: MPL-2.0

"""Shaper - Minimal Embedded Analytics and Data Platform"""

__version__ = "0.12.7"
