import numpy as np
import sys
import lz4.frame
from matplotlib.pylab import record
import pandas as pd
import os
import threading
import json
import requests
import lz4
import bson
import hashlib
import pymongo
import time
from pymongo import ASCENDING, DESCENDING

from SharedData.IO.MongoDBClient import MongoDBClient
from SharedData.Logger import Logger
from SharedData.IO.ClientAPI import ClientAPI
from SharedData.CollectionMongoDB import CollectionMongoDB



class WorkerPool:

    """
    Manages a pool of worker jobs with support for job creation, reservation, and status updates.
    
    This class interfaces with MongoDB collections to coordinate job distribution and processing among workers. It supports atomic fetching and reservation of jobs, broadcasting jobs to multiple workers, and periodic status updates based on job dependencies and due dates.
    
    Key functionalities include:
    - Creating necessary MongoDB indexes for efficient querying.
    - Fetching and reserving direct and broadcast jobs for specific workers.
    - Fetching a batch of pending jobs filtered by user and computer identifiers.
    - Periodically updating job statuses from 'NEW' or 'WAITING' to 'PENDING' when due and dependencies are met.
    - Retrieving CPU model information in a cross-platform manner.
    
    All database operations are designed to be atomic to prevent job duplication or conflicts among workers.
    """
    
    @staticmethod
    def get_command_table(shdata):        
        return shdata.table(
            'Hashs','D1','WORKERPOOL','COMMANDS',
            user='master',
            names = ['hash'],formats=['|S64'],
            is_schemaless=True, size=1e4,
        )
    
    @staticmethod
    def post_commands(shdata, commands):
        tnow = pd.Timestamp.utcnow().tz_localize(None)
        errmsg = ''
        try:
            cmd_table = WorkerPool.get_command_table(shdata)
            cmd_table.acquire()
                            
            for record in commands:

                if not 'sender' in record:
                    raise Exception('sender not in record')
                if not 'target' in record:
                    raise Exception('target not in record')
                if not 'job' in record:
                    raise Exception('job not in record')
                
                record['target'] = str(record['target']).upper()
                if record['target'] == 'ALL':
                    record['status'] = 'BROADCAST'
                else:
                    record['status'] = 'NEW'
                            
                if not 'date' in record:
                    record['date'] = tnow
                                
                record['mtime'] = tnow

                # find worker    
                workername = record['target']
                buff = np.full((1,),dtype=cmd_table.dtype,fill_value=np.nan)
                buff['hash'][0] = workername
                loc = cmd_table.get_loc(buff, acquire=False)
                if loc[0] != -1:
                    worker = cmd_table.get_dict_list(cmd_table[loc[0]],acquire=False)[0]
                else:
                    worker = {
                        'hash': workername,
                        'commands': [],
                    }

                if not record['job'] == 'batch':                
                    worker['commands'].append(record)
                else:
                    pass
            
            # remove old commands
            for cmd in worker['commands']:
                if tnow - cmd['date'] > pd.Timedelta(seconds=60):
                    worker['commands'].remove(cmd)

            cmd_table.upsert(worker, acquire=False)

        except Exception as e:
            errmsg = f'Error in post_workerpool: {str(e)}'        
        finally:
            cmd_table.release()
            if errmsg != '':
                Logger.log.error(errmsg)
                raise Exception(errmsg)

    @staticmethod
    def get_commands(shdata, workername):
        """
        Atomically fetch and reserve pending jobs for the specified worker.
        
        This method retrieves commands from the database that are not older than 60 seconds and processes them as follows:
        - Direct jobs targeted specifically at the worker (with status "NEW" and target equal to the worker's name) are marked as "SENT" to indicate they have been reserved.
        - Broadcast jobs (with status "BROADCAST" and target "ALL") are updated to include the worker in their 'fetched' list to prevent the same job from being delivered multiple times to the same worker.
        
        Parameters
        ----------
        workername : str
            Case-insensitive identifier of the requesting worker.
        
        Returns
        -------
        list of dict
            A list of job documents that have been reserved for the worker.
        """
        jobs = []
        errmsg = ''
        workername = workername.upper()
        tnow = pd.Timestamp.utcnow().tz_localize(None)
        try:
            cmd_table = WorkerPool.get_command_table(shdata)
            cmd_table.acquire()
            
            #direct commands            
            buff = np.full((1,),dtype=cmd_table.dtype,fill_value=np.nan)
            buff['hash'][0] = workername
            loc = cmd_table.get_loc(buff, acquire=False)
            if loc[0] != -1:
                worker = cmd_table.get_dict_list(cmd_table[loc[0]], acquire=False)[0]
            else:
                worker = {
                    'hash': workername,
                    'commands': [],
                }

            cmds_to_remove = []
            for cmd in worker['commands']:
                if tnow - cmd['date'] < pd.Timedelta(seconds=60):
                    jobs.append(cmd)
                else:
                    cmds_to_remove.append(cmd)
                worker['commands'] = []
            
            for cmd in cmds_to_remove:
                worker['commands'].remove(cmd)

            cmd_table.upsert(worker, acquire=False)
            
            #broadcast commands                        
            buff = np.full((1,),dtype=cmd_table.dtype,fill_value=np.nan)
            buff['hash'][0] = 'ALL'
            loc = cmd_table.get_loc(buff, acquire=False)
            if loc[0] != -1:
                broadcast = cmd_table.get_dict_list(cmd_table[loc[0]], acquire=False)[0]
            else:
                broadcast = {
                    'hash': 'ALL',
                    'commands': [],
                }
            
            cmd_to_remove = []
            for cmd in broadcast['commands']:
                if tnow - cmd['date'] < pd.Timedelta(seconds=60):
                    if not 'fetched_by' in cmd:
                        cmd['fetched_by'] = []
                    if not workername in cmd['fetched_by']:
                        cmd['fetched_by'].append(workername)
                        
                        _cmd = cmd.copy()
                        del _cmd['fetched_by']
                        jobs.append(_cmd)
                        
                else:
                    cmd_to_remove.append(cmd)
            
            for cmd in cmd_to_remove:
                broadcast['commands'].remove(cmd)

            cmd_table.upsert(broadcast, acquire=False)

        except Exception as e:
            errmsg = f'Error in get_commands: {str(e)}'
        finally:
            cmd_table.release()
            if errmsg != '':
                Logger.log.error(errmsg)
                raise Exception(errmsg)
            

        return jobs
           
    @staticmethod
    def fetch_jobs(workername, njobs=1):
        """
        Fetches and atomically reserves a specified number of pending jobs from a MongoDB collection for a given worker.
        
        Parameters:
            workername (str): The worker identifier in the format 'user@computer'.
            njobs (int, optional): The number of jobs to fetch. Defaults to 1.
        
        Returns:
            list: A list of job documents that have been fetched and marked as 'FETCHED' for the specified worker.
        
        The method filters jobs by matching the user and computer fields (or 'ANY'), and only considers jobs with status 'PENDING'.
        Each fetched job's status is updated to 'FETCHED', the target is set to the worker, and the modification time is updated to the current UTC timestamp.
        Jobs are fetched in descending order by their 'date' field.
        """
        user = workername.split('@')[0]
        computer = workername.split('@')[1]
        mongodb= MongoDBClient(user='master')
        coll = mongodb['Text/RT/WORKERPOOL/collection/JOBS']

        filter_query = {
            'user': {'$in': [user, 'ANY']},
            'computer': {'$in': [computer, 'ANY']},
            'status': 'PENDING',  # Only fetch jobs that are in 'PENDING' status
        }

        # Define the update operation to set status to 'FETCHED'
        update_query = {
            '$set': {
                'status': 'FETCHED',
                'target': user+'@'+computer,
                'mtime': pd.Timestamp('now', tz='UTC')
            }
        }

        sort_order = [('date', pymongo.DESCENDING)]

        fetched_jobs = []
        for _ in range(njobs):
            # Atomically find and update a single job
            job = coll.find_one_and_update(
                filter=filter_query,
                update=update_query,
                sort=sort_order,
                return_document=pymongo.ReturnDocument.AFTER
            )

            if job:
                fetched_jobs.append(job)
            else:
                # No more jobs available
                break
        
        return fetched_jobs

    @staticmethod
    def update_jobs_status() -> None:
        """
        Periodically updates job statuses in the MongoDB collection from 'NEW' or 'WAITING' to 'PENDING' if the job's due date has passed and all its dependencies have been completed.
        Also marks jobs as ERROR with timeout if they have been running for more than 1 hour.
        
        This method runs indefinitely, performing the update every 5 seconds. If an error occurs during the update process, it logs the error and waits 60 seconds before retrying.
        
        The update is performed using a MongoDB aggregation pipeline that:
        - Filters jobs with status 'NEW' or 'WAITING' and a due date earlier than the current time.
        - Looks up the job dependencies and checks if all dependencies have status 'COMPLETED'.
        - Updates the status of eligible jobs to 'PENDING' and sets the modification time to the current timestamp.
        - Marks jobs with status 'FETCHED' or 'RUNNING' as 'ERROR' with stderr 'timeout' if they have been running for more than 1 hour.
        """
        while True:
            try:
                now = pd.Timestamp('now', tz='UTC')
                pipeline = [
                    {
                        '$match': {
                            'status': {'$in': ['NEW', 'WAITING']},
                            'date': {'$lt': now}
                        }
                    },
                    {
                        '$lookup': {
                            'from': 'Text/RT/WORKERPOOL/collection/JOBS',
                            'localField': 'dependencies',
                            'foreignField': 'hash',
                            'as': 'deps'
                        }
                    },
                    {
                        '$addFields': {
                            'all_deps_completed': {
                                '$cond': [
                                    {'$gt': [{'$size': {'$ifNull': ['$dependencies', []]}}, 0]},
                                    {
                                        '$allElementsTrue': {
                                            '$map': {
                                                'input': "$deps",
                                                'as': "d",
                                                'in': {'$eq': ["$$d.status", "COMPLETED"]}
                                            }
                                        }
                                    },
                                    True
                                ]
                            }
                        }
                    },
                    {
                        '$match': {'all_deps_completed': True}
                    },
                    {
                        "$project": {"date": 1, "hash": 1}
                    }
                ]
                pipeline.append({
                    "$merge": {
                        "into": "Text/RT/WORKERPOOL/collection/JOBS",
                        "whenMatched": [
                            {"$set": {"status": "PENDING", "mtime": now}}
                        ],
                        "whenNotMatched": "discard"
                    }
                })

                mongodb = MongoDBClient(user='master')
                coll = mongodb['Text/RT/WORKERPOOL/collection/JOBS']
                coll.aggregate(pipeline)

                # Check for jobs running longer than 1 hour and mark them as ERROR
                one_hour_ago = now - pd.Timedelta(hours=1)
                timeout_filter = {
                    'status': {'$in': ['FETCHED', 'RUNNING']},
                    'mtime': {'$lt': one_hour_ago}
                }
                timeout_update = {
                    '$set': {
                        'status': 'ERROR',
                        'stderr': 'timeout',
                        'mtime': now
                    }
                }
                
                result = coll.update_many(timeout_filter, timeout_update)
                if result.modified_count > 0:
                    Logger.log.warning(f"Marked {result.modified_count} jobs as ERROR due to timeout (>1 hour)")

                time.sleep(5)
            except Exception as e:
                Logger.log.error(f"Error in update_jobs_status: {e}")
                time.sleep(60)  # Wait before retrying in case of error
 