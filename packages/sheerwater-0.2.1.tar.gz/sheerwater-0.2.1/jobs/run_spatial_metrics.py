#!/usr/bin/env python
"""Runs metrics and updates the caches."""
import itertools
import traceback


from sheerwater.metrics import metric
from sheerwater.utils import start_remote
from jobs import parse_args, run_in_parallel, prune_metrics

(start_time, end_time, forecasts, truth, metrics, variables,
 grids, regions, agg_days, time_groupings,
 parallelism, recompute, backend, remote_name, remote, remote_config) = parse_args()

if remote:
    start_remote(remote_config=remote_config, remote_name=remote_name)

combos = itertools.product(metrics, variables, grids, regions, agg_days, forecasts, time_groupings, truth)
combos = prune_metrics(combos, global_run=False)

filepath_only = True
if backend is not None:
    filepath_only = False


def run_metric(combo):
    """Run spatial metric."""
    print(combo)
    metric_name, variable, grid, region, agg, forecast, time_grouping, truth = combo

    try:
        metric(start_time, end_time, variable, agg_days=agg, forecast=forecast,
               truth=truth, metric_name=metric_name, spatial=True,
               time_grouping=time_grouping, grid=grid, region=region,
               force_overwrite=True, filepath_only=filepath_only, recompute=recompute, storage_backend=backend)
    except KeyboardInterrupt as e:
        raise (e)
    except:  # noqa:E722
        print(f"Failed to run global metric {forecast} {agg} {grid} {variable} {metric}: {traceback.format_exc()}")


if __name__ == "__main__":
    if backend == 'terracotta':
        run_in_parallel(run_metric, combos, parallelism, local_multiproc=True)
    else:
        run_in_parallel(run_metric, combos, parallelism)
