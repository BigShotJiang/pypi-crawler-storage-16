sheetwise.classifiers module
============================

.. automodule:: sheetwise.classifiers
   :members:
   :show-inheritance:
   :undoc-members:
