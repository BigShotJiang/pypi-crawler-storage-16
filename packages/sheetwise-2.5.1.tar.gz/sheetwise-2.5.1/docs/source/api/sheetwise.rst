sheetwise package
=================

.. automodule:: sheetwise
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

.. toctree::
   :maxdepth: 4

   sheetwise.chain
   sheetwise.classifiers
   sheetwise.cli
   sheetwise.compressor
   sheetwise.core
   sheetwise.data_types
   sheetwise.detectors
   sheetwise.encoders
   sheetwise.extractors
   sheetwise.formula_parser
   sheetwise.smart_tables
   sheetwise.utils
   sheetwise.visualizer
   sheetwise.workbook
