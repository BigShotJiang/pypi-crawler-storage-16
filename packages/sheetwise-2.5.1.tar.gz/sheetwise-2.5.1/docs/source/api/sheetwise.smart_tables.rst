sheetwise.smart\_tables module
==============================

.. automodule:: sheetwise.smart_tables
   :members:
   :show-inheritance:
   :undoc-members:
