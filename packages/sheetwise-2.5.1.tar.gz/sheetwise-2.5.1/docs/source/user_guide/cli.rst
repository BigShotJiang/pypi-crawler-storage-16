Command Line Interface
======================

Use SheetWise from the command line.

.. automodule:: sheetwise.cli
   :members:
