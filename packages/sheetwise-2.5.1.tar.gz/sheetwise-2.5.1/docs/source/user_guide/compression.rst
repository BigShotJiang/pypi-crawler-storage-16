Compression Guide
================

Learn how to use SheetWise's compression features.

.. automodule:: sheetwise.compressor
   :members:
