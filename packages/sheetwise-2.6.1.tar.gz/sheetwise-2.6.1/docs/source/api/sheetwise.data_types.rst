sheetwise.data\_types module
============================

.. automodule:: sheetwise.data_types
   :members:
   :show-inheritance:
   :undoc-members:
