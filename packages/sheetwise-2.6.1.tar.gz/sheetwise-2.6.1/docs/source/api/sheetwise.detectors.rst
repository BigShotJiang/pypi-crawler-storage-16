sheetwise.detectors module
==========================

.. automodule:: sheetwise.detectors
   :members:
   :show-inheritance:
   :undoc-members:
