Encoding Guide
==============

Learn about different encoding strategies.

.. automodule:: sheetwise.encoders
   :members:
