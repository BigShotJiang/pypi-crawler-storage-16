Table Detection
===============

Detect and classify tables in spreadsheets.

.. automodule:: sheetwise.smart_tables
   :members:
