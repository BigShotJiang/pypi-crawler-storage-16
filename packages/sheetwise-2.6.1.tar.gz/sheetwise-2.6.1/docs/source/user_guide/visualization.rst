Visualization
=============

Generate visual reports and charts.

.. automodule:: sheetwise.visualizer
   :members:
