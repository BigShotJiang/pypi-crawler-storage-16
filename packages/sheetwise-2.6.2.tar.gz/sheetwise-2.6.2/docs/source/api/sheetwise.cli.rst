sheetwise.cli module
====================

.. automodule:: sheetwise.cli
   :members:
   :show-inheritance:
   :undoc-members:
