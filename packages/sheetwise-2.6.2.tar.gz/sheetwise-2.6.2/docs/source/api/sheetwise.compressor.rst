sheetwise.compressor module
===========================

.. automodule:: sheetwise.compressor
   :members:
   :show-inheritance:
   :undoc-members:
