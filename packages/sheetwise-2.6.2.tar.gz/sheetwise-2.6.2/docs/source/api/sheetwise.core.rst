sheetwise.core module
=====================

.. automodule:: sheetwise.core
   :members:
   :show-inheritance:
   :undoc-members:
