sheetwise.encoders module
=========================

.. automodule:: sheetwise.encoders
   :members:
   :show-inheritance:
   :undoc-members:
