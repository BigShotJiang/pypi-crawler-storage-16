License
=======

.. include:: ../../LICENSE
   :literal:
