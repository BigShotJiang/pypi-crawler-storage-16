from .base_offensive import OffensiveLanguageClassifier
from .logistic_offensive_classifier import LogisticOffensiveClassifier

__all__ = ["OffensiveLanguageClassifier", "LogisticOffensiveClassifier"]
