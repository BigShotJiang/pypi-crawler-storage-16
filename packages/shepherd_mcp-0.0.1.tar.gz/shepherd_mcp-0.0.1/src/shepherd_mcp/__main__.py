"""Entry point for running shepherd-mcp as a module."""

from shepherd_mcp.server import main

if __name__ == "__main__":
    main()
