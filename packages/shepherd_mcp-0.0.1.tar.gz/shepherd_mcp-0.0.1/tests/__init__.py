"""Tests for shepherd-mcp."""
