from shieldcommit.patterns import PATTERNS

def test_patterns_not_empty():
    assert len(PATTERNS) > 0
