from shiny.express import ui

ui.panel_title("Page title", "Window title")
