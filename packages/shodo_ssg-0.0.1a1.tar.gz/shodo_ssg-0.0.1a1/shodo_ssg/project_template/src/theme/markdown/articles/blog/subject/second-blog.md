@frontmatter
{
    "title": "Second Blog",
    "category": "updates",
    "body_class": "blog-page second-blog",
    "description": "This is the second blog description",
    "tags": ["six", "seven", "eight"],
    "published_datetime": "2025-02-25T00:00:00Z"
}
@endfrontmatter

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam porttitor odio sed dui maximus, in tempus sem rhoncus. Aliquam purus magna, ullamcorper efficitur risus et, hendrerit finibus odio. Donec ultrices nibh augue, ut volutpat leo elementum id. Duis suscipit eleifend dolor, nec ornare elit cursus quis. Vestibulum lobortis, risus sed efficitur semper, sapien magna condimentum nulla, non bibendum nulla ante tincidunt magna. Maecenas accumsan efficitur augue non faucibus. Phasellus sollicitudin nibh vel tortor interdum placerat. Fusce ac lectus nec nulla feugiat pharetra. Vestibulum nibh mi, dictum id orci vel, vestibulum venenatis diam. Fusce sed pretium justo, non finibus sem. Sed volutpat dui in felis aliquam condimentum.

[Back to home](/)