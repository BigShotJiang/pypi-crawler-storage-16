## Getting Started

Get started by editing `src/theme/views/home.jinja` and then running 

```
python serve.py
```

to build your static site in the `dist/` directory and start up the development server!

[See the docs](https://shodo.dev/docs) for more.
