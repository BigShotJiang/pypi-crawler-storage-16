function init() {
  console.log("Main JS initialized");
}

init();
