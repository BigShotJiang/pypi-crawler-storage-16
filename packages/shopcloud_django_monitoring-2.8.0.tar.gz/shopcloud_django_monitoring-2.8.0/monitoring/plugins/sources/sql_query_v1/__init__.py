from .sql_query_v1 import Plugin
