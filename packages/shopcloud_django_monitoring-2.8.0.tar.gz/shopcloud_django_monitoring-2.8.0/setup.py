from setuptools import find_packages, setup

with open("README.md") as readme_file:
    README = readme_file.read()

setup_args = {
    "name": "shopcloud_django_monitoring",
    "version": "2.8.0",
    "description": "A Module for create site reliable engineering",
    "long_description_content_type": "text/markdown",
    "long_description": README,
    "license": "MIT",
    "packages": find_packages(),
    "author": "Konstantin Stoldt",
    "author_email": "konstantin.stoldt@talk-point.de",
    "url": "https://github.com/Talk-Point/shopcloud-django-monitoring",
    "python_requires": ">=3.10",
    "classifiers": [
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Framework :: Django",
        "Framework :: Django :: 3.2",
        "Framework :: Django :: 4.0",
        "Framework :: Django :: 4.1",
        "Framework :: Django :: 4.2",
        "Framework :: Django :: 5.0",
        "Framework :: Django :: 5.1",
        "Framework :: Django :: 6.0",
        "License :: OSI Approved :: MIT License",
    ],
}

install_requires = [
    "Django>=3.2,<7.0",
    "shopcloud-streams",
    "shopcloud-django-toolbox",
    "shopcloud-django-instrumenting",
    "djangorestframework",
    "django-filter",
    "markdown",
]

if __name__ == "__main__":
    setup(**setup_args, install_requires=install_requires)
