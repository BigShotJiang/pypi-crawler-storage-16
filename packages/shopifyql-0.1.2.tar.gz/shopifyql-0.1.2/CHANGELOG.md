# Changelog

All notable changes to this project will be documented in this file.

The format is based on Keep a Changelog and this project adheres to Semantic Versioning.

## [0.1.2] - 2025-11-05

- Initial public release.

# Changelog

All notable changes to this project will be documented in this file.

## 0.1.2 - Initial release

- Initial client
