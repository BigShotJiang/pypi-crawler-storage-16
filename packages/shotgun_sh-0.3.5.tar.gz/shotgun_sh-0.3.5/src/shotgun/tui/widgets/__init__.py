"""Widget utilities and coordinators for TUI."""

from shotgun.tui.widgets.widget_coordinator import WidgetCoordinator

__all__ = ["WidgetCoordinator"]
