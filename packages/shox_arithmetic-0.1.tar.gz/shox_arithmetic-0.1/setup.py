from setuptools import setup
setup(
    name='shox-arithmetic',
    version='0.1',
    packages=[],
    description='Arithmetic mathematics library',
    author='Shoxrux',
    author_email='shoxruxaminboyev367@gmail.com',
    requires=[],
    python_requires='>=3.11',
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",

)