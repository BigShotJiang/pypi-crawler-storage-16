from setuptools import setup
setup(
    name='shox-eds',
    version='0.1.2',
    packages=[],
    description='Arithmetic mathematics library',
    requires=[],
    python_requires='>=3.11',
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",

)