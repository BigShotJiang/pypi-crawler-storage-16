# shutilspy python工具库

## 子模块

- [dag](docs/dag.md)调度框架

## 安装

前往Release页面下载whl包，使用pip安装。

## TODO

- [ ] 升级rate_limiter支持同步、异步多种限流器
- [ ] 增加重试工具
