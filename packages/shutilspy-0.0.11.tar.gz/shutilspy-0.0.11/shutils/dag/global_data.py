#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
File: global.py
Date: 2025/04/29 20:26:26
Author: shlll(shlll7347@gmail.com)
Modified By: shlll(shlll7347@gmail.com)
Last Modified: 2025/04/29 20:26:26
Brief:
"""

debug_mode = False
