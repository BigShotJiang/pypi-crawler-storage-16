====================
Methods
====================

Overview of methods contained in SIGN-XAI2:

- Gradient
- Gradient x Input
- Gradient x SIGN
- ...
- LRP-z
- ...
- LRP-epsilon
- LRP-epsilon / LRP-SIGN
- ...
