# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2025/12/8 14:57
# Description: alphalens polens 版本

from .plot import model_performance_graph

import logair
import pandas as pd
from .utils import demean_forward_returns, get_forward_returns_columns
from tqdm.auto import tqdm
import polars.selectors as cs
import polars as pl

logger = logair.get_logger(__name__)

def _to_alphalens(factor_data: pl.DataFrame,
                  alpha_name: str,
                  periods: list[str],
                  bins: int = 10,
                  by_group: bool = False):
    """转成 alphalens 所需要的因子分析格式"""
    grouper = ["date", "time"]
    if by_group:
        grouper.append("group")
    factor_data = factor_data.select(
        "date", "time", "asset",
        pl.col(alpha_name).alias("factor"),
        *periods, "group", "cap",
    )
    return (
        factor_data
        .with_columns(
            pl.col("factor")
            .qcut(bins,
                  labels=[str(i) for i in range(1, bins + 1)],
                  allow_duplicates=True).over(grouper).alias("factor_quantile"))
        .with_columns(
            pl.col(pl.Categorical).cast(pl.Int32))
        .select("date", "time", "asset",
                "factor", "group", "cap",
                *periods, "factor_quantile")
    )

def factor_report(factor_data: pl.DataFrame,
                  by_group: bool = False,
                  reverse: bool = False,
                  lag: int = 1,
                  N: int = 10,
                  demeaned: bool = False,
                  group_adjust: bool = False,
                  beg_date: str = None,
                  end_date: str = None,
                  times: str = None,
                  show_notebook: bool = True, ):
    """
    qlib 版本的因子报告

    Parameters
    ----------
    factor_data: polars.DataFrame
        因子数据
    by_group : bool
        分组是否在行业内进行分组, 默认False-全市场分组
    reverse : bool
    lag: int
        计算因子自回归以及换手时的滞后期数, 默认上一期:1
    N: int
        分组数量, 默认10
    demeaned : bool
        是否进行去均值处理。如果为 True，则在计算收益时会去掉因子的均值影响。
    group_adjust : bool
        是否进行组中性处理。如果为 True，则收益会减去行业均值
        **注意**: 该参数优先级大于 demeaned，该参数为True时，demeaned参数失去作用
    beg_date: str
    end_date: str
    times: list[str]
    show_notebook: bool

    Notes
    -----
    group_neutral 和 demeaned 控制是否对收益做调整, group_neutral优先级更高
        - group_neutral 为 True: 收益-行业均值
        - group_neutral 为 False: 如果demeaned 为 True，则收益 - 全市场均值
    """
    beg_date = factor_data["date"].min() if beg_date is None else beg_date
    end_date = factor_data["date"].max() if end_date is None else end_date
    _times = factor_data["time"].unique().to_list()
    _times.sort()
    times = _times if times is None else times
    periods = get_forward_returns_columns(factor_data.columns)
    logger.info(f"{beg_date} -> {end_date}: {times}")
    # 处理收益列
    factor_data = factor_data.filter(
         (pl.col("date") >= beg_date),
         (pl.col("date") <= end_date),
         (pl.col("time").is_in(times)))
    factor_data = factor_data.sort(by=["date", "time", "asset"])
    if group_adjust:
        grouper = pd.Index(["date", "time"]).intersection(factor_data.columns).tolist()
        factor_data = demean_forward_returns(factor_data, grouper + ["group"]).sort(by=["date", "time", "asset"])
    elif demeaned:
        factor_data = demean_forward_returns(factor_data)
    factor_data = factor_data.with_columns(
        (factor_data[period]).alias(period)
        for period in periods
    )
    _alpha_cols = factor_data.head(1).select(cs.exclude("date", "time", "asset", *periods, "group", "cap"))

    task_num = len(_alpha_cols)
    figs_collect = dict()
    with tqdm(total=task_num) as bar:
        for alpha in _alpha_cols:
            logger.info(alpha)
            if reverse:
                factor_data = factor_data.with_columns((pl.col(alpha) * -1).alias(alpha))
            _factor_data = _to_alphalens(factor_data, alpha, periods=periods, bins=N, by_group=by_group)
            figs_collect[alpha] = model_performance_graph(_factor_data, lag=lag, N=N, show_notebook=show_notebook)
            bar.update()
        bar.close()
    return figs_collect
