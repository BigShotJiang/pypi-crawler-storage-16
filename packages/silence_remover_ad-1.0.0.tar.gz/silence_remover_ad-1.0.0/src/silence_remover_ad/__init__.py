__version__ = "1.0.0"
from .silence_remover import VideoProcessor, AudioAnalyzer, AppController