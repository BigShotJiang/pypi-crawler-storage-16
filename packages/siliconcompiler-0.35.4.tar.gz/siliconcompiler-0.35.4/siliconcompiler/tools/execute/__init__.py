'''
This tool is used to execute the output of a previous step.
For example, if the flow contains a compile step which generates the
next executable needed in the flow.
'''
