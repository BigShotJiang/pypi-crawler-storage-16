'''
Icarus is a verilog simulator with full support for Verilog
IEEE-1364. Icarus can simulate synthesizable as well as
behavioral Verilog.

Documentation: https://steveicarus.github.io/iverilog/

Sources: https://github.com/steveicarus/iverilog

Installation: https://github.com/steveicarus/iverilog
'''
