'''
Surfer is a waveform viewer with a focus on a snappy usable
interface and extensibility.

Documentation: https://gitlab.com/surfer-project/surfer/-/wikis/home

Sources: https://gitlab.com/surfer-project/surfer

Installation: https://gitlab.com/surfer-project/surfer#installation
'''
