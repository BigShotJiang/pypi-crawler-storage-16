#!/bin/sh

set -ex

sudo yum install -y ImageMagick
