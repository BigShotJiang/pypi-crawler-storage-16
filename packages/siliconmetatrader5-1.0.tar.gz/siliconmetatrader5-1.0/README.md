# SiliconMetaTrader5 (macOS Silicon Optimized)

**Developer:** Bahadir Umut Iscimen

A Python wrapper for MetaTrader5 that enables seamless Algorithmic Trading on **macOS (Apple Silicon M1/M2/M3)** via Docker/Wine.

This library acts as a bridge between your native macOS Python environment and the MetaTrader5 terminal running inside a compatibility layer (Docker/Wine).

## Features
- **macOS Silicon Native Feel:** Use `import siliconmetatrader5` directly in your Mac's terminal or IDE (VSCode, PyCharm).
- **High Performance:** Optimized for low-latency IPC with the Dockerized MT5 engine.
- **Full Compatibility:** Supports 99% of the official `MetaTrader5` Python API.

## Prerequisites
You need the accompanying Docker engine running. Please refer to the [Main Repository Layout](https://github.com/buiscimen/siliconmetatrader5) for full setup instructions.

## Installation

```bash
pip install siliconmetatrader5
```
    
## Usage
Once your Docker engine is running:

```python
from siliconmetatrader5 import MetaTrader5

# Connect to the Dockerized MT5
mt5 = MetaTrader5(host="localhost", port=8001)

# Use it just like the standard library
if mt5.initialize():
    print("Connected to SiliconMetaTrader5!")
    print(mt5.terminal_info())
    mt5.shutdown()
```