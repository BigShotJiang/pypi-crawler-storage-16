# Marks integration tests as a package to avoid module name collisions in tooling.
