from win32com.client import GetActiveObject as AppAttach, Dispatch as AppCreate, CDispatch
from pythoncom import CoInitialize, CoUninitialize, com_error
from abc import ABC, abstractmethod

def com_server_is_running(prog_id: str):
    try:
        return AppAttach(prog_id)
    except com_error as e:
        return False
        raise com_error(e)

class Application(ABC):
    __com_interface__:CDispatch = None
    _instance = None

    @property
    @abstractmethod
    def __app_name__(): ...
    @property
    @abstractmethod
    def __app_version__(): ...

    def __new__(cls, *args, **kwargs):
        if not cls.__com_interface__: 
            CoInitialize()
            ifc_name = GetProgID(cls)
            ifc = com_server_is_running(ifc_name)
            if ifc:
                cls.__com_interface__ = ifc
            else:
                try:
                    cls.__com_interface__ = AppCreate(ifc_name)
                except:
                    clear_com_cache()
                    cls.__com_interface__ = AppCreate(ifc_name)
        if not cls._instance:
            cls._instance = super(Application, cls).__new__(cls)
        return cls._instance
    
    def __del__(self):
        CoUninitialize()
        self.__com_interface__ = None
        self._instance = None

class AppObject:
    def __init__(self, obj):
        if not isinstance(obj,CDispatch): 
            obj = obj._obj
        self._obj = obj
    def __repr__(self):
        return self._obj.__class__
    def __str__(self):
        return f'{self._obj}'
    def __getattr__(self, name):
        return getattr(self._obj,name)
    def __call__(self):
        return self._obj

class AppObjectCollection(AppObject):
    def __init__(self, obj):
        super().__init__(obj)

    @property
    def Count(self) -> int: 
        return self._obj.Count

    def Item(self, Index: int|str) -> AppObject:
        return AppObject(self._obj.Item(Index))

    def __iter__(self):
        for item in self._obj:
            obj = AppObject(item)
            yield obj


def GetProgID(cls: Application, progid_name: str = 'Application'):
    progID = f'{cls.__app_name__}.{progid_name}'
    if cls.__app_version__:
        progID += f'.{cls.__app_version__}'
    else:
        if cls.__com_interface__:
            try:
                cls.__app_version__(cls.__com_interface__.Version.split('.')[0])
                progID += f'.{cls.__app_version__}'
            except: pass
    return progID

def clear_com_cache():
    import win32com.client.gencache
    import os
    import shutil
    gentype_path = win32com.client.gencache.GetGeneratePath()
    if os.path.exists(gentype_path):
        # logger.debug(f"Удаление кэша COM: {gentype_path}")
        try:
            shutil.rmtree(gentype_path)
            # logger.debug("Кэш успешно удален.")
        except OSError as e:
            raise com_error(f"Ошибка при удалении кэша: {e}. Закройте приложение COM-сервер и повторите попытку.")
    else:
        pass
        # logger.debug("Папка кэша gen_py не найдена. Возможно, кэш еще не был создан.")