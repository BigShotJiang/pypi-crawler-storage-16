from __future__ import annotations
from ..Objects.AcadSubEntity import *

class AcadSubEntSolidEdge(AcadSubEntity):
    def __init__(self, obj) -> None: super().__init__(obj)
    