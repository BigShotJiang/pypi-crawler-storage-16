def e(a):
    b = int(input(a))
    return b

def i(a):
    b = input(a)
    return b
    