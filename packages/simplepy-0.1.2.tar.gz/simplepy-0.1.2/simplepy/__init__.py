# simplepy/__init__.py

from .mycode import *   # import everything from mycode.py