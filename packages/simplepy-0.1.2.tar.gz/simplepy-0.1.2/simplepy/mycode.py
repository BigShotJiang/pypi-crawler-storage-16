def e(text=""):
    return int(input(text))

def i(text=""):
    return input(text)

def p(*args, **kwargs):
    return print(*args, **kwargs)