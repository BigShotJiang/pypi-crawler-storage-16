def e(text=""):
    return int(input(text))

def i(text=""):
    return input(text)

def p(*args, **kwargs):
    return print(*args, **kwargs)

def add(a,b):
    c = a+b
    return c
