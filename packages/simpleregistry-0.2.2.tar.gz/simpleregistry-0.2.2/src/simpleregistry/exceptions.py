class PolymorphismNotAllowed(ValueError):
    pass


class TypeNotAllowed(ValueError):
    pass


class NoMatch(ValueError):
    pass


class MultipleMatches(ValueError):
    pass
