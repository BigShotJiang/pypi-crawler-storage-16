from enum import Enum


class VectorProvider(Enum):
    LOCAL = 1
    QDRANT = 2
