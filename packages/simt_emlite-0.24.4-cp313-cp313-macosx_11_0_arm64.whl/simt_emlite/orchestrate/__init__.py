"""
Scripts for orchestrating spinning up docker images for the mediator sync
processes and the mediator server processes.
"""
