# -*- coding: utf-8 -*-
from enum import Enum


class Tags(Enum):
    HUGGINGFACE = "huggingface"
    MODELS = "models"
