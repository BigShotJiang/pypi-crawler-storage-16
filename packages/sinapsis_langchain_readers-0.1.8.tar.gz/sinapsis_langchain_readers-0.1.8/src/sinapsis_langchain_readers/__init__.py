# -*- coding: utf-8 -*-
# sinapsis_langchain_readers package
