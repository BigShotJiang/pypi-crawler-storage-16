# -*- coding: utf-8 -*-
# sinapsis_openai package
