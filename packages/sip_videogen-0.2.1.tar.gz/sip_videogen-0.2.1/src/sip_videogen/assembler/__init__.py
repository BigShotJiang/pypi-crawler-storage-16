"""Video assembly and FFmpeg integration."""

from sip_videogen.assembler.ffmpeg import FFmpegAssembler, FFmpegError

__all__ = ["FFmpegAssembler", "FFmpegError"]
