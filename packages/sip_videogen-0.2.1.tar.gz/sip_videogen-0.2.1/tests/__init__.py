"""Test suite for sip-videogen."""
