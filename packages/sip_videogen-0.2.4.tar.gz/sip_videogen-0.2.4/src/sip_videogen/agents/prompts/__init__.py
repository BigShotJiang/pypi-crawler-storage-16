"""Agent prompt templates."""
