"""Allow running as python -m sip_videogen."""

from sip_videogen.cli import app

if __name__ == "__main__":
    app()
