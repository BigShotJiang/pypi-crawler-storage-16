## Summary
- What changed and why?

## Required metadata
- Task ID: 
- Spec/PRD ID: (use N/A if not applicable)
- Task plan file: (e.g., docs/latest/tasks/TASK-1234-foo.md or N/A)
- Tests run: (include `uv run verify_server.py` when relevant)

## Checklist
- [ ] Linked ticket (GitHub Projects/Linear) shares the same Task ID
- [ ] Acceptance criteria covered (per Spec/PRD)
- [ ] Added/updated tests
