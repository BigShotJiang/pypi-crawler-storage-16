"""Property-based tests using Hypothesis."""
