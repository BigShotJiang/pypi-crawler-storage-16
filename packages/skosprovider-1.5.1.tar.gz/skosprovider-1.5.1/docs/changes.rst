.. _changelog:

=======
History
=======

.. include:: ../HISTORY.rst
