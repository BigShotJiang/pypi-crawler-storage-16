.. _api:

=================
API Documentation
=================

Providers module
----------------

.. automodule:: skosprovider_getty.providers
   :members:

Utility module
--------------

.. automodule:: skosprovider_getty.utils
   :members:
