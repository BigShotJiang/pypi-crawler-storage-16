{{ objname | escape | underline(line="=") }}

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
   :exclude-members: skb, __call__
