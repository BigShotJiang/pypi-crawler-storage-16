Learning Materials
==================

You are being redirected to the new learning materials page.

.. raw:: html

    <meta http-equiv="refresh" content="0; url=https://skrub-data.org/skrub-materials/">

If you are not redirected automatically, follow this
`link <https://skrub-data.org/skrub-materials/>`_.
