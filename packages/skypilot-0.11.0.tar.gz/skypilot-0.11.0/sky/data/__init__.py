"""Sky Data."""
from sky.data.storage import Storage
from sky.data.storage import StorageMode
from sky.data.storage import StoreType

__all__ = ['Storage', 'StorageMode', 'StoreType']
