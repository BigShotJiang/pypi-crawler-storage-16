"""
Linearity-exploiting reverse mode autodiff library and nonlinear program solver
DSL
"""

from ._sleipnir import *

__version__ = "0.3.2"
