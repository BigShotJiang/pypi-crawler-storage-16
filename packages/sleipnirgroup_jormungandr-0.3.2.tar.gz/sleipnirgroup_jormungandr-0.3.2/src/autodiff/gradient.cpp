// Copyright (c) Sleipnir contributors

#include "sleipnir/autodiff/gradient.hpp"

template class EXPORT_TEMPLATE_DEFINE(SLEIPNIR_DLLEXPORT) slp::Gradient<double>;
