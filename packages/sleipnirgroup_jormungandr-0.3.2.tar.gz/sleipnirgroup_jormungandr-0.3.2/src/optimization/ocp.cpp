// Copyright (c) Sleipnir contributors

#include "sleipnir/optimization/ocp.hpp"

template class EXPORT_TEMPLATE_DEFINE(SLEIPNIR_DLLEXPORT) slp::OCP<double>;
