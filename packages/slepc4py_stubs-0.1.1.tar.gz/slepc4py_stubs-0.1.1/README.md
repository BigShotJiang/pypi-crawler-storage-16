# slepc4py-stubs

Type stubs for [slepc4py](https://slepc.upv.es/release/slepc4py/).

## Installation

```bash
pip install slepc4py-stubs
```

## Usage

After installation, type checkers like Pylance/Pyright and mypy will automatically use these stubs for `slepc4py`.