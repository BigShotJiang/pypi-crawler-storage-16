__app_name__ = "sloth"
__version__ = "0.1.0"