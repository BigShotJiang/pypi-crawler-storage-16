import json
from pathlib import Path
from typing import Optional
from rich.console import Console

console = Console()
APP_NAME = "sloth_scr"

def get_config_dir() -> Path:

    app_dir = Path.home() / f".{APP_NAME}"

    if not app_dir.exists():
        app_dir.mkdir()
    
    return app_dir / "config.json"

def save_api_key(api_key: str):
    config_path = get_config_dir()
    try:
        with open(config_path, "w")as f:
            json.dump({"api_key": api_key}, f)
        console.print(f"[green]Key saved to {config_path}[/green]")
    except Exception as e:
        console.print(f"[red]Failed to save API key: {e}[/red]")

def load_api_key() -> Optional[str]:
    config_path = get_config_dir()
    if not config_path.exists():
        return None
    
    try:
        with open(config_path, "r") as f:
            data = json.load(f)
            return data.get("api_key")
    except Exception as e:
        console.print(f"[red]Failed to load API key: {e}[/red]")
        return None
