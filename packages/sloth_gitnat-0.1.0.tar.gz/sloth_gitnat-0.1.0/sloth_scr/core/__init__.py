# Expose the critical types and functions so other modules 
# can import them like: "from ..core import CommandResult"
# instead of: "from ..core.types import CommandResult"

from .types import CommandResult, Confidence
from .executor import execute_git_command

__all__ = ["CommandResult", "Confidence", "execute_git_command"]