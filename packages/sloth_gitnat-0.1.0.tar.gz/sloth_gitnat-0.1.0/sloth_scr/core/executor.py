import subprocess
import shlex
import re
import os  # Needed for Bug #3 (cd)
from rich.console import Console

console = Console()

def execute_git_command(command_str: str) -> bool:
    """
    Executes git commands. Supports chaining (&&), interactive modes, and cd.
    """
    
    # --- BUG FIX #1: THE SMART SPLITTER ---
    # We use Regex to split by '&&' ONLY if it's not inside quotes.
    # Logic: Match '&&' followed by an even number of quotes (meaning we are outside).
    chain_pattern = r'\s*&&\s*(?=(?:[^"]*"[^"]*")*[^"]*$)'
    parts = re.split(chain_pattern, command_str)
    
    # If we found multiple commands (and the split wasn't just empty), chain them.
    if len(parts) > 1:
        for sub in parts:
            sub = sub.strip()
            if not sub: continue
            
            # Clean "git " prefix if AI added it
            if sub.startswith("git "):
                sub = sub[4:].strip()
                
            console.print(f"[dim]Running sub-command: git {sub}[/dim]")
            
            # Recursive call: If any link in the chain fails, stop.
            if not execute_git_command(sub):
                return False 
        return True

    # --- BUG FIX #3: THE CD TRAP ---
    # Handle "cd" manually because subprocess can't change the parent shell's directory.
    if command_str.startswith("cd "):
        target_dir = command_str[3:].strip()
        try:
            # We use Python's os.chdir instead of git
            os.chdir(target_dir)
            console.print(f"[green]Changed directory to: {os.getcwd()}[/green]")
            return True
        except FileNotFoundError:
            console.print(f"[red]Directory not found: {target_dir}[/red]")
            return False
        except Exception as e:
            console.print(f"[red]Could not change directory: {e}[/red]")
            return False

    # --- STANDARD EXECUTION ---
    try:
        args = ["git"] + shlex.split(command_str)
        
        # --- BUG FIX #2: THE INTERACTIVE HANG ---
        # Detect commands that require a human interface (Vim/Nano/Prompts)
        is_interactive = False
        
        # Case A: 'commit' without a message flag (opens Vim)
        if "commit" in args and "-m" not in args:
            is_interactive = True
            
        # Case B: 'add' with patch mode (interactive selection)
        if "add" in args and ("-p" in args or "-i" in args):
            is_interactive = True

        if is_interactive:
            # Run without capturing output (let the user see/type in Vim)
            result = subprocess.run(args, check=False)
            return result.returncode == 0
            
        else:
            # Run normally and capture output to print it prettily
            result = subprocess.run(
                args, 
                capture_output=True, 
                text=True
            )
            
            # Handle Output
            if result.stdout:
                console.print(result.stdout.strip())
            
            # Handle Errors/Warnings
            if result.stderr:
                console.print(f"[yellow]{result.stderr.strip()}[/yellow]")
                
            return result.returncode == 0
        
    except FileNotFoundError:
        console.print("[bold red]Error:[/bold red] Git is not installed.")
        return False
    except Exception as e:
        console.print(f"[bold red]System Error:[/bold red] {e}")
        return False