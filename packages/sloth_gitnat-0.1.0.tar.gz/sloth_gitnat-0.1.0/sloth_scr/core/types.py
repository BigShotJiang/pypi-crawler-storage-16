from dataclasses import dataclass
from enum import Enum

class Confidence(float, Enum):
    CERTAIN = 1.0
    HIGH = 0.9
    MEDIUM = 0.7
    LOW = 0.4
    ZERO = 0.0

@dataclass
class CommandResult:
    cmd: str
    confidence: float
    source: str
    is_dangerous: bool = False