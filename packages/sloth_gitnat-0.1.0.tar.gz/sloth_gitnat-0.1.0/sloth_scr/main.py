import click 
from rich.console import Console
from .parsers.router import route_command
from .core.executor import execute_git_command
from .config import save_api_key

console = Console()


class NatralOrderGroup(click.Group):
    """
    This custom group allows us to mix subcommands (like 'config') 
    with a default argument (the prompt).
    """
    def parse_args(self, ctx, args):
        if not args:
            return super().parse_args(ctx, args)
        first_arg = args[0]

        if first_arg in self.commands:
            return super().parse_args(ctx, args)
        
        return super().parse_args(ctx, ["run"] + args)
    
@click.group(cls=NatralOrderGroup)
def cli():
    "sloth: Natural Language Git Command Line Tool"
    pass
# -- -Sub command 1: Config ---
@cli.command()
def config():
    console.print("[bold]Setup Gemini API[/bold]")
    console.print("Get your free key here: https://aistudio.google.com/app/apikey")
    key = click.prompt("Paste your API Key", hide_input=True)
    if key:
        save_api_key(key)
    else:
        console.print("[yellow]No key provided.[/yellow]")

# --- SUBCOMMAND 2: RUN (The Default) ---
@cli.command()
@click.argument("prompt", nargs=-1) # nargs=-1 means "capture all remaining words"
def run(prompt):
    """
    Main logic to parse and execute commands.
    """
    # Join the tuple of words back into a string
    # (e.g. ("undo", "last", "commit") -> "undo last commit")
    full_prompt = " ".join(prompt)
    
    if not full_prompt:
        ctx = click.get_current_context()
        click.echo(ctx.get_parent().get_help())
        ctx.exit()

    # --- THE BRAIN ---
    with console.status("[bold green]Thinking...[/bold green]", spinner="dots"):
        result = route_command(full_prompt)
    
    if not result:
        console.print("[yellow]I didn't understand that.[/yellow]")
        return

    # --- THE UI ---
    console.print(f"[dim]Match Source: {result.source} (Confidence: {result.confidence})[/dim]")
    console.print(f"[bold cyan]I will run:[/bold cyan] git {result.cmd}")
    
    # --- THE SAFETY VALVE ---
    if click.confirm("Do it?", default=True):
        success = execute_git_command(result.cmd)
        if success:
            console.print("[bold green]✔ Done![/bold green]")
        else:
            console.print("[bold red]✘ Failed.[/bold red]")
    else:
        console.print("[dim]Aborted.[/dim]")

if __name__ == "__main__":
    cli()