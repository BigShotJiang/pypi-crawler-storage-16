# The only thing the outside world needs from this folder 
# is the function that makes the decision: route_command.

from .router import route_command

__all__ = ["route_command"]