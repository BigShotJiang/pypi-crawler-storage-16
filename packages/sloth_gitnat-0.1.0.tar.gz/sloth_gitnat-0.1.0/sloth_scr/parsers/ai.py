import google.generativeai as genai
import os
from ..core.types import CommandResult, Confidence
from ..config import load_api_key

SYSTEM_PROMPT = """
You are a command line translator. 
User input will be a natural language request for Git.
You must output ONLY the git command. 
Do not use markdown blocks. 
Do not explain. 
If the request is dangerous, prefix it with "WARNING:".
"""

def parse(prompt: str)-> CommandResult | None:
    api_key = load_api_key()
    if not api_key:
        return None
    
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel("gemini-2.5-flash-lite")
        full_prompt = f"{SYSTEM_PROMPT}\nUser Request: {prompt}\nGit Command:"

        response = model.generate_content(full_prompt)
        text = response.text.strip()

        clean_cmd = text.replace("```bash", "").replace("```", "").strip()
        if clean_cmd.startswith("git "):
            clean_cmd = clean_cmd[4:].strip()

        return CommandResult(
            cmd=clean_cmd,
            confidence=Confidence.LOW,
            source="gemini_pro"
        )

    except Exception as e:
        print(f"AI parser error: {e}")
        return None
        