from ..core.types import CommandResult, Confidence

COMMON_COMMANDS = {
    "undo last commit": "reset --soft HEAD~1",
    "discard changes": "checkout -- .",
    "show branches": "branch -a",
    "status": "status",
    "push": "push",
    "pull": "pull",
    "stop tracking": "rm --cached"
}

def parse(prompt: str)-> CommandResult | None:
    clean_prompt = prompt.strip().lower()

    if clean_prompt in COMMON_COMMANDS:
        return CommandResult(
            cmd=COMMON_COMMANDS[clean_prompt],
            confidence=Confidence.CERTAIN,
            source="exact_match"
        )
    return None
