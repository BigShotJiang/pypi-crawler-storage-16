import re
from ..core.types import CommandResult, Confidence

PATTERNS = [
    # Commit with message (HIGH confidence - explicit quotes)
    (
        re.compile(r'commit\s+(?:with\s+message\s+)?["\'](?P<msg>.*?)["\']', re.IGNORECASE),
        'commit -m "{msg}"',
        Confidence.HIGH
    ),
    
    # Commit without quotes (MEDIUM confidence - might be incomplete)
    (
        re.compile(r'commit\s+(?P<msg>.+)', re.IGNORECASE),
        'commit -m "{msg}"',
        Confidence.MEDIUM
    ),
    
    # Status checks (HIGH confidence - clear keywords)
    (
        re.compile(r'\b(status|what.?s?\s+(?:changed|different)|show\s+changes?)\b', re.IGNORECASE),
        "status",
        Confidence.HIGH
    ),
    
    # Add all/everything (HIGH confidence)
    (
        re.compile(r'\b(?:add|stage)\s+(?:all|everything|\.)\b', re.IGNORECASE),
        "add .",
        Confidence.HIGH
    ),
    
    # Add specific files (MEDIUM confidence)
    (
        re.compile(r'\b(?:add|stage)\s+(?P<files>[\w./\-]+(?:\s+(?:and\s+)?[\w./\-]+)*)', re.IGNORECASE),
        'add {files}',
        Confidence.MEDIUM
    ),
    
    # Switch/checkout branch (MEDIUM confidence - branch name validation needed)
    (
        re.compile(r'\b(?:switch\s+to|checkout|switch)\s+(?P<branch>[\w\-./]+)', re.IGNORECASE),
        'checkout {branch}',
        Confidence.MEDIUM
    ),
    
    # Create new branch (HIGH confidence - explicit "new" or "create")
    (
        re.compile(r'\b(?:create|make|new)\s+(?:branch\s+)?(?P<branch>[\w\-./]+)', re.IGNORECASE),
        'checkout -b {branch}',
        Confidence.HIGH
    ),
    
    # Push (HIGH confidence)
    (
        re.compile(r'\bpush(?:\s+to\s+(?P<remote>\w+))?(?:\s+(?P<branch>[\w\-./]+))?\b', re.IGNORECASE),
        'push{remote}{branch}',
        Confidence.HIGH
    ),
    
    # Pull (HIGH confidence)
    (
        re.compile(r'\bpull(?:\s+from\s+(?P<remote>\w+))?(?:\s+(?P<branch>[\w\-./]+))?\b', re.IGNORECASE),
        'pull{remote}{branch}',
        Confidence.HIGH
    ),
    
    # Log/history (HIGH confidence)
    (
        re.compile(r'\b(?:log|history|show\s+(?:commit\s+)?history)\b', re.IGNORECASE),
        "log --oneline --graph --all",
        Confidence.HIGH
    ),
    
    # Show diff (HIGH confidence)
    (
        re.compile(r'\b(?:diff|show\s+diff(?:erence)?s?|what\s+changed)\b', re.IGNORECASE),
        "diff",
        Confidence.HIGH
    ),
    
    # Stash changes (HIGH confidence)
    (
        re.compile(r'\b(?:stash|save\s+changes?)\b', re.IGNORECASE),
        "stash",
        Confidence.HIGH
    ),
    
    # List branches (HIGH confidence)
    (
        re.compile(r'\b(?:list|show|display)\s+(?:all\s+)?branches?\b', re.IGNORECASE),
        "branch -a",
        Confidence.HIGH
    ),
    
    # Delete branch (MEDIUM confidence - needs validation)
    (
        re.compile(r'\b(?:delete|remove)\s+(?:branch\s+)?(?P<branch>[\w\-./]+)', re.IGNORECASE),
        'branch -d {branch}',
        Confidence.MEDIUM
    ),
    
    # Undo last commit (HIGH confidence - explicit keywords)
    (
        re.compile(r'\b(?:undo|revert)\s+(?:last|previous)\s+commit\b', re.IGNORECASE),
        "reset --soft HEAD~1",
        Confidence.HIGH
    ),
    
    # Discard changes (MEDIUM confidence - destructive operation)
    (
        re.compile(r'\b(?:discard|reset|revert)\s+(?:all\s+)?changes?\b', re.IGNORECASE),
        "checkout -- .",
        Confidence.MEDIUM
    ),
]

# Common stopwords to remove for better matching
STOPWORDS = {'please', 'can', 'you', 'could', 'would', 'i', 'want', 'to', 
             'like', 'need', 'me', 'the', 'a', 'an', 'now', 'just', 'quickly'}

def _sanitize_captures(captured: str) -> str:
    sanitized = {}
    for key, value in captured.items():

        if value is None:
            continue

        if key == 'msg':
            value = value.strip()[:200]
            if not value:
                return None
        
            value = value.replace('"', '\\"')
            sanitized[key] = value

        elif key == 'branch':
            value = value.strip()
            if re.match(r'^[\w\-./]+$', value):
                return None
            if value in ['.', '..', '-'] or value.startswith('-'):
                return None
            sanitized[key] = value

        elif key == 'files':
            value = value.strip()
            # Basic validation - allow common file patterns
            if not re.match(r'^[\w\s./\-*]+$', value):
                return None
            sanitized[key] = value
        
        # Sanitize remote names
        elif key == 'remote':
            value = value.strip()
            if not re.match(r'^\w+$', value):
                return None
            sanitized[key] = f' {value}'
        
        else:
            sanitized[key] = value.strip()
    
    return sanitized

def _preprocess_prompt(prompt: str) -> str:
    """
    Preprocess prompt: normalize whitespace, optionally remove stopwords.
    """
    # Normalize whitespace
    cleaned = ' '.join(prompt.strip().split())
    
    # Optional: Remove stopwords (be careful - might break some patterns)
    words = cleaned.split()
    cleaned = ' '.join(w for w in words if w.lower() not in STOPWORDS)
    
    return cleaned

def parse(prompt:str )-> CommandResult | None:
        if not prompt or not prompt.strip():
            return None
        if " and " in prompt.lower() or " then " in prompt.lower():
            return None
    # Length limit to prevent abuse
        if len(prompt) > 500:
            return None
    
    # Preprocess
        clean_prompt = _preprocess_prompt(prompt)
    
    # Try patterns in order (most specific first)
        for pattern, template, confidence in PATTERNS:
            match = pattern.search(clean_prompt)
        
            if match:
                try:
                    captured = match.groupdict()
                
                # Sanitize captured groups
                    sanitized = _sanitize_captures(captured)
                    if sanitized is None:  # Validation failed
                        continue
                
                # Handle optional groups (like remote/branch in push/pull)
                # Fill empty optional groups with empty string
                    for key in captured.keys():
                        if key not in sanitized:
                            sanitized[key] = ''
                
                # Format command
                    git_cmd = template.format(**sanitized)
                
                    return CommandResult(
                        cmd=git_cmd,
                        confidence=confidence,
                        source=f"regex:{pattern.pattern[:50]}..."
                    )
                
                except (KeyError, ValueError, IndexError) as e:
                # Pattern matching failed, try next pattern
                # Optional: log for debugging
                # print(f"Pattern failed: {e}")
                    continue
    
        return None