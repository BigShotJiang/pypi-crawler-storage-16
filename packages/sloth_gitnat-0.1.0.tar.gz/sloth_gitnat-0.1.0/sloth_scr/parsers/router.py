from ..core.types import CommandResult, Confidence
from . import exact, regex, ai
def route_command(prompt: str) -> CommandResult | None:
    # Tier 1
    result = exact.parse(prompt)
    if result:
        return result

    # Tier 2
    result = regex.parse(prompt)
    if result:
        return result

    # Tier 3
    result = ai.parse(prompt)
    if result:
        return result

    return None
