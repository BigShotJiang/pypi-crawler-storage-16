"""
Smart Commit - AI-powered git commit message generator.
"""

__version__ = "0.2.1"
