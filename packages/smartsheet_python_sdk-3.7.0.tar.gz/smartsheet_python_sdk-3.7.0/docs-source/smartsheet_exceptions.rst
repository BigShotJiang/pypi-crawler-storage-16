Exceptions
==================

.. automodule:: smartsheet.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
