## Preprocessing: `pp`

## Preprocessing module diagram
```{image} ../_static/smftools_preprocessing_diagram.png
:width: 1000px
```

```{eval-rst}
.. module:: smftools.pp
```

```{eval-rst}
.. currentmodule:: smftools
```
