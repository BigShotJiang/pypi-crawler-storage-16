# Contributors

## Current

- Joseph Mckenna, lead developer (2024)

## Acknowledgments

- [Tjian/Darzacq Lab](https://www.tjian-darzacq.mcb.berkeley.edu/): Funding and a supportive lab environment!
