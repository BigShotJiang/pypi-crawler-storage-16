from .device import detect_device
from .grl import GradReverse