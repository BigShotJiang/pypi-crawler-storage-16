# Copyright (c) 2021 Mitsuru Ohno
#  Use of this source code is governed by a BSD-3-style
#  license that can be found in the LICENSE file.

# 08/21/2022, M. Ohno
# smipoly __init__

from ._version import __version__
