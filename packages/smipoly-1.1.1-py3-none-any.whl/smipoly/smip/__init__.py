# smipoly/smip/__init__

from . import funclib
from .._version import __version__
