from django.apps import AppConfig


class CoreConfig(AppConfig):
    name = "smoothglue.core"
    verbose_name = "SmoothGlue Core"
