from django.apps import AppConfig


class TrackerConfig(AppConfig):
    name = "smoothglue.tracker"
    verbose_name = "SmoothGlue Event Tracker"
