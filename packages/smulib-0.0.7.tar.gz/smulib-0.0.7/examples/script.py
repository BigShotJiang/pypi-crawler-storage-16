from smulib import SMU, smu_script

@smu_script(name="Test")
def test(smu_instance: SMU, v: float, *args, **kwargs) -> dict[str, float]:
    smu_instance.set_voltage(v)

    return {
        "v": smu_instance.measure_voltage(),
        "a": smu_instance.measure_current()
    }


smu = SMU("/dev/cu.usbmodem11401")

res = smu.run_script(test, v=4.20)
print(res)