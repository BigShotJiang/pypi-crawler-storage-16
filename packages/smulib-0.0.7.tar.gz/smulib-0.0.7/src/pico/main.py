import time

from machine import I2C, Pin

from .lib import DAC8571
from .serial import read_line, write_line

i2c = I2C(0, scl=Pin(5), sda=Pin(4), freq=400_000)

voltage_dac = DAC8571(i2c, 0x4C)
current_dac = DAC8571(i2c, 0x4C)

def process_line(line: str) -> str:
    pass

def main():
    while True:
        line = read_line()
        reply = process_line(line)
        write_line(reply)

        time.sleep(0.01)


if __name__ == "__main__":
    main()