import functools
from typing import Protocol, Any, runtime_checkable, Literal, TYPE_CHECKING

if TYPE_CHECKING:
    from . import SMU

def smu_script(name: str):
    def _decorator(func):
        @functools.wraps(func)
        def wrapper(smu, *args, **kwargs):
            return func(smu, *args, **kwargs)

        wrapper._is_smu_script = True
        wrapper._smu_script_name = name

        return wrapper

    return _decorator

@runtime_checkable
class SMUScriptCallable(Protocol):
    def __call__(self, smu: SMU, *args, **kwargs) -> Any | list | dict:
        ...

class SMUScriptParameter:
    def __init__(self, name: str, value_type: Literal["str", "int", "float"], default_value: Any):
        self.name = name
        self.value_type = value_type
        self.default = default_value

class SMUScript:
    def __init__(self, name: str, parameters: list[SMUScriptParameter], callable: SMUScriptCallable):
        self.name = name
        self.parameters = parameters
        self.callable = callable