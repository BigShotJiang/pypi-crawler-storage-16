"""支持 python -m xueqiu_mcp 运行"""

from xueqiu_mcp import main

if __name__ == "__main__":
    main()
