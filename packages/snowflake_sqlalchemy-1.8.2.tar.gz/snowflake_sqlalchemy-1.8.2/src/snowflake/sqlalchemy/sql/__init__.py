#
# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
#
