#
# Copyright (c) 2012-2025 Snowflake Computing Inc. All rights reserved.
#

"""
Client-specific utilities.

These are minimal versions of utilities that don't require heavy dependencies
like config, telemetry, UDF caches, etc.
"""
