from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from snx.ast import (
    AddressOperand,
    InstructionIR,
    InstructionNode,
    IRProgram,
    LabelRefOperand,
    Opcode,
    Program,
    RegisterOperand,
)
from snx.constants import DEFAULT_MEM_SIZE, DEFAULT_REG_COUNT
from snx.word import normalize_imm8, WORD_MASK
from snx.diagnostics import DiagnosticCollector, RelatedInfo, SourceSpan

if TYPE_CHECKING:
    pass


OPCODE_OPERAND_SPEC: dict[Opcode, tuple[int, tuple[type, ...]]] = {
    Opcode.ADD: (3, (RegisterOperand, RegisterOperand, RegisterOperand)),
    Opcode.AND: (3, (RegisterOperand, RegisterOperand, RegisterOperand)),
    Opcode.SUB: (3, (RegisterOperand, RegisterOperand, RegisterOperand)),
    Opcode.SLT: (3, (RegisterOperand, RegisterOperand, RegisterOperand)),
    Opcode.NOT: (2, (RegisterOperand, RegisterOperand)),
    Opcode.SR: (2, (RegisterOperand, RegisterOperand)),
    Opcode.HLT: (0, ()),
    Opcode.LD: (2, (RegisterOperand, AddressOperand)),
    Opcode.ST: (2, (RegisterOperand, AddressOperand)),
    Opcode.LDA: (2, (RegisterOperand, AddressOperand)),
    Opcode.IN: (1, (RegisterOperand,)),
    Opcode.OUT: (1, (RegisterOperand,)),
    Opcode.BZ: (2, (RegisterOperand, LabelRefOperand)),
    Opcode.BAL: (2, (RegisterOperand, (LabelRefOperand, AddressOperand))),
}


@dataclass(slots=True)
class AnalysisResult:
    program: Program
    ir: IRProgram | None
    diagnostics: list


class Analyzer:
    def __init__(
        self,
        program: Program,
        diagnostics: DiagnosticCollector,
        *,
        reg_count: int = DEFAULT_REG_COUNT,
        mem_size: int = DEFAULT_MEM_SIZE,
    ) -> None:
        self._program = program
        self._diagnostics = diagnostics
        self._reg_count = reg_count
        self._mem_size = mem_size
        self._labels: dict[str, int] = {}
        self._label_spans: dict[str, SourceSpan] = {}
        self._instructions: list[InstructionIR] = []

    def analyze(self) -> AnalysisResult:
        self._build_label_table()
        self._analyze_instructions()

        if self._diagnostics.has_errors():
            return AnalysisResult(
                program=self._program,
                ir=None,
                diagnostics=self._diagnostics.diagnostics,
            )

        ir = IRProgram(
            instructions=tuple(self._instructions),
            labels=dict(self._labels),
        )
        return AnalysisResult(
            program=self._program,
            ir=ir,
            diagnostics=self._diagnostics.diagnostics,
        )

    def _build_label_table(self) -> None:
        pc = 0
        for line in self._program.lines:
            if line.label is not None:
                label_name = line.label.name
                if label_name in self._labels:
                    prev_span = self._label_spans[label_name]
                    self._diagnostics.add_error(
                        "S006",
                        f"Duplicate label definition: '{line.label.original}'",
                        line.label.span,
                        (RelatedInfo(
                            "Previous definition",
                            prev_span,
                        ),),
                    )
                else:
                    self._labels[label_name] = pc
                    self._label_spans[label_name] = line.label.span

            if line.instruction is not None:
                pc += 1

    def _analyze_instructions(self) -> None:
        pc = 0
        for line in self._program.lines:
            if line.instruction is None:
                continue

            inst = line.instruction
            if inst.opcode is None:
                pc += 1
                continue

            self._check_operand_spec(inst, line.line_no)
            self._check_register_bounds(inst, line.line_no)
            self._check_label_refs(inst, line.line_no)
            self._check_branch_target_range(inst, line.line_no)
            self._check_memory_bounds(inst, line.line_no)
            self._check_immediate_range(inst, line.line_no)

            inst_ir = InstructionIR(
                opcode=inst.opcode,
                operands=inst.operands,
                text=inst.text,
                pc=pc,
            )
            self._instructions.append(inst_ir)
            pc += 1

    def _check_operand_spec(self, inst: InstructionNode, line_no: int) -> None:
        if inst.opcode is None:
            return

        spec = OPCODE_OPERAND_SPEC.get(inst.opcode)
        if spec is None:
            return

        expected_count, expected_types = spec
        actual_count = len(inst.operands)

        if actual_count != expected_count:
            self._diagnostics.add_line_error(
                line_no,
                "S002",
                f"'{inst.opcode.name}' requires {expected_count} operand(s), but {actual_count} provided.",
                inst.span,
            )
            return

        for i, (operand, expected_type) in enumerate(zip(inst.operands, expected_types)):
            if isinstance(expected_type, tuple):
                if not isinstance(operand, expected_type):
                    type_names = " or ".join(t.__name__ for t in expected_type)
                    self._diagnostics.add_line_error(
                        line_no,
                        "S003",
                        f"Operand {i+1} of '{inst.opcode.name}' must be of type {type_names}.",
                        operand.span,
                    )
            else:
                if not isinstance(operand, expected_type):
                    self._diagnostics.add_line_error(
                        line_no,
                        "S003",
                        f"Operand {i+1} of '{inst.opcode.name}' must be of type {expected_type.__name__}.",
                        operand.span,
                    )

    def _check_register_bounds(self, inst: InstructionNode, line_no: int) -> None:
        for operand in inst.operands:
            if isinstance(operand, RegisterOperand):
                if operand.index < 0 or operand.index >= self._reg_count:
                    self._diagnostics.add_line_error(
                        line_no,
                        "S005",
                        f"Register index out of range: {operand.text} (valid: $0-${self._reg_count - 1})",
                        operand.span,
                    )
            elif isinstance(operand, AddressOperand):
                if operand.base.index < 0 or operand.base.index >= self._reg_count:
                    self._diagnostics.add_line_error(
                        line_no,
                        "S005",
                        f"Register index out of range: {operand.base.text} (valid: $0-${self._reg_count - 1})",
                        operand.base.span,
                    )

    def _check_label_refs(self, inst: InstructionNode, line_no: int) -> None:
        for operand in inst.operands:
            if isinstance(operand, LabelRefOperand):
                if operand.name not in self._labels:
                    self._diagnostics.add_line_error(
                        line_no,
                        "S004",
                        f"Undefined label: '{operand.original}'",
                        operand.span,
                    )

    def _check_branch_target_range(self, inst: InstructionNode, line_no: int) -> None:
        if inst.opcode not in (Opcode.BZ, Opcode.BAL):
            return

        for operand in inst.operands:
            if not isinstance(operand, LabelRefOperand):
                continue

            if operand.name not in self._labels:
                continue

            target_pc = self._labels[operand.name]
            if target_pc >= 1024:
                self._diagnostics.add_line_warning(
                    line_no,
                    "B001",
                    f"Branch target '{operand.original}' has PC {target_pc}, which exceeds "
                    f"the 10-bit branch field limit (0-1023); encoding will overflow into "
                    f"opcode/register bits (matching original snxasm behavior)",
                    operand.span,
                )

    def _check_memory_bounds(self, inst: InstructionNode, line_no: int) -> None:
        if inst.opcode not in (Opcode.LD, Opcode.ST):
            return

        for operand in inst.operands:
            if not isinstance(operand, AddressOperand):
                continue

            if operand.base.index != 0:
                continue

            eff_offset = normalize_imm8(operand.offset)
            ea = eff_offset & WORD_MASK
            if ea >= self._mem_size:
                self._diagnostics.add_line_error(
                    line_no,
                    "M001",
                    f"Memory address {ea} (0x{ea:04X}) is out of bounds "
                    f"(mem_size={self._mem_size})",
                    operand.span,
                )

    def _check_immediate_range(self, inst: InstructionNode, line_no: int) -> None:
        if inst.opcode in (Opcode.BZ,):
            return

        if inst.opcode == Opcode.BAL:
            if len(inst.operands) >= 2 and isinstance(inst.operands[1], LabelRefOperand):
                return

        for operand in inst.operands:
            if not isinstance(operand, AddressOperand):
                continue

            offset = operand.offset
            norm = normalize_imm8(offset)
            if norm != offset:
                self._diagnostics.add_line_warning(
                    line_no,
                    "I001",
                    f"Immediate value {offset} will be encoded as 8-bit and interpreted as {norm} (0x{norm & 0xFF:02X})",
                    operand.span,
                )


def analyze(
    program: Program,
    diagnostics: DiagnosticCollector | None = None,
    *,
    reg_count: int = DEFAULT_REG_COUNT,
    mem_size: int = DEFAULT_MEM_SIZE,
) -> AnalysisResult:
    if diagnostics is None:
        diagnostics = DiagnosticCollector()

    analyzer = Analyzer(program, diagnostics, reg_count=reg_count, mem_size=mem_size)
    return analyzer.analyze()
