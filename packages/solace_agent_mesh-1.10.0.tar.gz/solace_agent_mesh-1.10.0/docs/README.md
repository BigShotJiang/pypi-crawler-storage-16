# Solace Agent Mesh Documentation

## Local Run

To run Solace Agent Mesh locally, follow these steps:

```sh
cd docs
npm ci
npm start
```

## Build Pages

To build Solace Agent Mesh documentation pages, follow these steps:

```sh
cd docs
npm ci
npm run build
```