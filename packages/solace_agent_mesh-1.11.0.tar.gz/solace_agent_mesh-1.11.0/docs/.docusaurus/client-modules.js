export default [
  require("/home/runner/work/solace-agent-mesh/solace-agent-mesh/docs/node_modules/infima/dist/css/default/default.css"),
  require("/home/runner/work/solace-agent-mesh/solace-agent-mesh/docs/node_modules/@docusaurus/theme-classic/lib/prism-include-languages"),
  require("/home/runner/work/solace-agent-mesh/solace-agent-mesh/docs/node_modules/@docusaurus/theme-classic/lib/nprogress"),
];
