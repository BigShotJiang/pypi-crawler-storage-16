"""
Tools for the Solana Agent system.

This package contains the base AutoTool class and built-in tool implementations.
"""
