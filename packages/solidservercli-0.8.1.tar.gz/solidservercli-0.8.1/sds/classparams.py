import re
import json
from sds.config import log

from SOLIDserverRest import *
from SOLIDserverRest import adv as sdsadv


def add_classparams_from_string(sdsobj: sdsadv.ClassParams, meta: str) -> bool:
    if not meta or meta == "":
        return True

    kvs = re.findall(r'((\w+)=\'([^\']*)\'),?', meta)
    if kvs:
        for g in kvs:
            sjson = f'{{"{g[1]}":"{g[2]}"}}'
            sdsobj.add_class_params(json.loads(sjson))
        return True
    elif len(meta) > 0:
        log.error('syntax error on meta format')
        return False
