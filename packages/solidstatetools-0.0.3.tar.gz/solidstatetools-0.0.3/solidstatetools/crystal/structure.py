import numpy as np
from pymatgen.core import Structure
from pymatgen.ext.matproj import MPRester
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


class CrystalStructure:
    """
    A utility class for loading and analyzing crystal structures using pymatgen.

    This class supports:
        - Loading from Materials Project ID
        - Loading from CIF files
        - Basic crystallographic calculations (d-spacing, plane normals)
        - Angle between two crystal planes

    Parameters
    ----------
    structure : pymatgen.core.Structure
        A pymatgen Structure object representing the crystal.
    """

    def __init__(self, structure: Structure):
        self.structure = structure

    # --------------------------------------------------------------------------
    # Constructors
    # --------------------------------------------------------------------------
    @classmethod
    def from_mp(cls, mp_id: str, api_key=None):
        """
        Load a structure directly from the Materials Project database.

        Parameters
        ----------
        mp_id : str
            Materials Project ID (e.g. "mp-149").
        api_key : str, optional
            Your Materials Project API key.

        Returns
        -------
        CrystalStructure
            A new instance containing the downloaded structure.
        """
        mpr = MPRester(api_key)
        structure = mpr.get_structure_by_material_id(mp_id)
        sga = SpacegroupAnalyzer(structure)
        conv_structure = sga.get_conventional_standard_structure()
        return cls(conv_structure)

    @classmethod
    def from_cif(cls, path: str):
        """
        Load a structure from a CIF file.

        Parameters
        ----------
        path : str
            Path to the CIF file.

        Returns
        -------
        CrystalStructure
            Instance containing the structure from file.
        """
        return cls(Structure.from_file(path))

    # --------------------------------------------------------------------------
    # Basic getters
    # --------------------------------------------------------------------------
    def lattice(self):
        """
        Get the lattice object of the structure.

        Returns
        -------
        pymatgen.core.lattice.Lattice
        """
        return self.structure.lattice

    def formula(self):
        """
        Return the chemical formula.

        Returns
        -------
        str
            Formula of the crystal (e.g. "SiO2").
        """
        return self.structure.composition.formula

    # --------------------------------------------------------------------------
    # Crystallographic calculations
    # --------------------------------------------------------------------------
    def dhkl(self, hkl):
        """
        Compute the d-spacing of a given plane.

        Parameters
        ----------
        hkl : array-like of int
            Miller indices (h, k, l).

        Returns
        -------
        float
            Interplanar spacing in angstroms.
        """
        return self.structure.lattice.d_hkl(hkl)

    def plane_normal(self, hkl):
        """
        Compute the Cartesian plane normal vector for Miller indices (hkl).

        Notes
        -----
        The normal of a plane is given by the reciprocal lattice vector:
            n = h*b1 + k*b2 + l*b3

        Parameters
        ----------
        hkl : array-like of int
            Miller indices.

        Returns
        -------
        np.ndarray
            3D Cartesian vector normal to the plane.
        """
        rec = self.structure.lattice.reciprocal_lattice
        return rec.get_cartesian_coords(hkl)

    def angle_between_planes(self, hkl1, hkl2):
        """
        Compute the angle between two planes (hkl1) and (hkl2).

        The angle between planes equals the angle between their reciprocal
        lattice normal vectors.

        Parameters
        ----------
        hkl1 : array-like of int
            First set of Miller indices.
        hkl2 : array-like of int
            Second set of Miller indices.

        Returns
        -------
        float
            Angle in degrees between the two planes.
        """
        # Get plane normals
        n1 = self.plane_normal(hkl1)
        n2 = self.plane_normal(hkl2)

        # Normalize the vectors
        n1 = n1 / np.linalg.norm(n1)
        n2 = n2 / np.linalg.norm(n2)

        # Dot product (clipped to avoid numerical issues)
        dot = np.clip(np.dot(n1, n2), -1.0, 1.0)

        # Return angle in degrees
        return np.degrees(np.arccos(dot))

    @property
    def atom_positions(self):
        return self.structure.frac_coords.tolist()
