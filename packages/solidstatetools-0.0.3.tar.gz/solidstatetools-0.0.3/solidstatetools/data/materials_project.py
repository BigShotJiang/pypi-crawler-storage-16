from pymatgen.ext.matproj import MPRester

def fetch_mp_structure(mp_id, api_key=None):
    mpr = MPRester(api_key)
    return mpr.get_structure_by_material_id(mp_id)
