import numpy as np
from solidstatetools.utils import generate_planes
from solidstatetools.crystal.structure import CrystalStructure


def F_function(f, plane, maille):
    F = f * np.exp(2 * np.pi * 1j * (plane[0] * maille[0] + plane[1] * maille[1] + plane[2] * maille[2]))
    return F

def F_plane(structure, plane):
    F = 0 + 0j
    for i in structure.atom_positions:
        F += F_function(1, plane, i)
    return np.abs(F)

def all_planes(structure:CrystalStructure, n:int, distance_min=None):
    planes = generate_planes(n, m=3)
    planes.remove([0, 0, 0])
    F_list = []
    plane_list = []
    for plane in planes:
        F = F_plane(structure, plane)
        if F >= 0.1 or F <= -0.1:
            if distance_min is None:
                F_list.append(np.round(np.abs(F)))
                plane_list.append(plane)
            else:
                if structure.dhkl(plane) >= distance_min:
                    F_list.append(np.round(np.abs(F)))
                    plane_list.append(plane)
    return plane_list, F_list

def reduced_planes(planes):
    planes = np.array(planes)
    n_max = np.max(planes)
    # print(n_max)
    stop = True
    n = 0
    while stop:
        bool_array = np.array([True for _ in range(planes.shape[0])])
        for i in range(2, n_max + 1):
            bool_array = np.logical_and(bool_array, np.any(planes != planes[n] * i, axis=1))
        index_array = np.array([j for j, x in enumerate(bool_array) if not x])
        count = np.sum(index_array < n)
        n -= count
        planes = planes[bool_array]
        if planes.shape[0] - 1 <= n:
            stop = False
        n += 1
    return planes

def xrd_plane_list(structure: CrystalStructure, n, distance_min=None):
    plane_list, _ = all_planes(structure, n, distance_min)
    reduced_list = reduced_planes(plane_list)
    return reduced_list