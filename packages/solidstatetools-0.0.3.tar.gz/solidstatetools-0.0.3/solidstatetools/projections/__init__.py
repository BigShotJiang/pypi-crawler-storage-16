from .stereo import StereographicProjection

__all__ = ['StereographicProjection']
