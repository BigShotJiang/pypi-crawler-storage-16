import numpy as np
from solidstatetools import CrystalStructure
import matplotlib.pyplot as plt


def phi(a, b, h, k):
    return np.arctan((a/h)/(b/k))

def d_droite(phi, b, k):
    return b*np.sin(phi)/k

def d_gauche(phi, a, h):
    return a*np.sin(phi)/h

def rho(c, l, d):
    return np.arctan((c/l)/d)


class StereographicProjection:
    """
    General stereographic projector along a fixed projection axis.

    Parameters
    ----------
    projection_axis : array-like, default [0,0,1]
        The axis along which the projection is made.
    x_axis : array-like, default [1,0,0]
        Reference axis in the projection plane (defines x orientation).
    """

    def __init__(self, crystal_structure:CrystalStructure, projection_axis=None):
        # Normalize and store projection axis and x-axis
        if projection_axis is None:
            projection_axis = [0, 0, 1]

        self.crystal_structure = crystal_structure
        self.projection_axis = np.array(projection_axis, dtype=float)
        self.projection_axis /= np.linalg.norm(self.projection_axis)


        # Precompute rotation to align projection axis with z-axis
        z_axis = np.array([0,0,1])
        k = np.cross(self.projection_axis, z_axis)
        s = np.linalg.norm(k)
        c = np.dot(self.projection_axis, z_axis)
        if s == 0:
            if c > 0:
                self.R_align = np.eye(3)
            else:
                self.R_align = -np.eye(3)
        else:
            kx, ky, kz = k
            K = np.array([[0, -kz, ky],
                          [kz, 0, -kx],
                          [-ky, kx, 0]])
            self.R_align = np.eye(3) + K + K @ K * ((1 - c)/(s**2))

    # ----------------------------------------------------------------------
    # Project a single vector
    # ----------------------------------------------------------------------
    def project_plane(self, hkl):
        """
        Project a single 3D vector stereographically.

        Parameters
        ----------
        plane : array-like
            3D vector to project.

        Returns
        -------
        (X, Y) : tuple of floats
            2D stereographic coordinates.
        """


        p = np.array(self.crystal_structure.plane_normal(hkl), dtype=float)
        p /= np.linalg.norm(p)

        # Rotate vector to align projection axis with z-axis
        p_rot = self.R_align @ p

        # Standard stereographic projection
        x, y, z = p_rot
        x, y, z = float(x), float(y), float(z)

        if np.isclose(z, 1):
            return [0, 0, True]
        if np.isclose(z, -1):
            return [0, 0, False]
        if np.isclose(z, 0):
            X, Y = x, y
            return [X, Y, True]


        if z>0:
            denom = 1 + z
            X, Y = x / denom, y / denom
            return [X, Y, True]
        else:
            denom = 1 - z
            X, Y = x / denom, y / denom
            return [X, Y, False]



    # ----------------------------------------------------------------------
    # Project a list of vectors
    # ----------------------------------------------------------------------
    def project_planes(self, vectors):
        """
        Project a list of 3D vectors stereographically.

        Parameters
        ----------
        vectors : list or array-like
            List of 3D vectors to project.

        Returns
        -------
        projections : list of tuples
            List of 2D projected coordinates [(X1,Y1), (X2,Y2), ...].
        """
        return [self.project_plane(v) for v in vectors]

    # ----------------------------------------------------------------------
    # Plot poles
    # ----------------------------------------------------------------------
    def plot(self, hkl_list, figsize=(6,6), title="Stereographic Projection"):
        """
        Plot a set of poles on a stereographic projection.

        Parameters
        ----------
        hkl_list : list of HKL tuples
            Example: [(1,1,1), (1,0,0), (1,1,0)]
        figsize : tuple
            Matplotlib figure size
        """

        projections = self.project_planes(hkl_list)

        xs_true, ys_true = [], []
        xs_false, ys_false = [], []
        labels_true, labels_false = [], []

        # Separate by hemisphere + keep labels
        for (x, y, is_upper), hkl in zip(projections, hkl_list):
            lbl = f"{hkl}"
            if is_upper:
                xs_true.append(x)
                ys_true.append(y)
                labels_true.append(lbl)
            else:
                xs_false.append(x)
                ys_false.append(y)
                labels_false.append(lbl)

        fig, ax = plt.subplots(figsize=figsize)

        # Circle boundary (unit radius)
        circle = plt.Circle((0, 0), 1, edgecolor='black', facecolor='none', linewidth=1.5)
        ax.add_patch(circle)

        # Plot poles
        if xs_true:
            ax.scatter(xs_true, ys_true, marker='x', s=80, label='Upper hemisphere', linewidths=2)
        if xs_false:
            ax.scatter(xs_false, ys_false, marker='o', s=70, label='Lower hemisphere',
                       facecolors='none', edgecolors='black')

        # ---------- Add HKL labels ----------
        text_offset = 0.03
        for x, y, lbl in zip(xs_true, ys_true, labels_true):
            ax.text(x + text_offset, y + text_offset, lbl, fontsize=8)

        for x, y, lbl in zip(xs_false, ys_false, labels_false):
            ax.text(x + text_offset, y - text_offset, lbl, fontsize=8)

        # Formatting
        ax.set_aspect('equal', 'box')
        ax.set_xlim(-1.05, 1.05)
        ax.set_ylim(-1.05, 1.05)
        ax.set_xlabel("X")
        ax.set_ylabel("Y")
        ax.set_title(title)
        ax.grid(True, linestyle="--", alpha=0.5)

        # Smaller legend, top right
        ax.legend(loc='upper right', fontsize="small")

        plt.show()