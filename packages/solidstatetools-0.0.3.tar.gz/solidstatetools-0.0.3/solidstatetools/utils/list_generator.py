

def generate_planes(n, m=3):
    if m == 0:
        return []
    if m == 1:
        l = []
        for i in range(-n, n + 1):
            l.append([i])
        return l

    l = []
    for i in range(-n, n + 1):
        for j in generate_planes(n, m - 1):
            l.append([i] + j)
    return l