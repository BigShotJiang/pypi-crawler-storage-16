This folder has models that are in testing process.

The astrophysics domain produces nice results, but it needs revision with negative samples. This model was train with scikit-learn 1.2.0.

The sequential domain has too few labels, hence producing results that can be improved
