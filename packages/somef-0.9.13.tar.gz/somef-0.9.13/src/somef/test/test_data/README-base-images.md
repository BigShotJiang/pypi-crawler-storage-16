# base_images [![Build Status](https://travis-ci.com/mintproject/base_images.svg?branch=master)](https://travis-ci.com/mintproject/base_images)
