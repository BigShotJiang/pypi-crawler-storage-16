# PANDA
Pipeline for Analyzing braiN Diffusion imAges

PANDA download: http://www.nitrc.org/projects/panda

The paper for PANDA: 

(1) Cui Z, Zhong S, Xu P, He Y, Gong G. (2013): PANDA: a pipeline toolbox for analyzing brain diffusion images. Front Hum Neurosci 7:42.
    http://journal.frontiersin.org/article/10.3389/fnhum.2013.00042/full
    
(2) Cui Z, Zhao C, Gong G. (2015): Parallel workflow tools to facilitate human brain MRI post-processing. Front Neurosci 9:171.
    http://journal.frontiersin.org/article/10.3389/fnins.2015.00171/full
    
Copyright (c) Zaixu Cui, State Key Laboratory of Cognitive Neuroscience and Learning, Beijing Normal University.  
Contact information: 
zaixucui@gmail.com