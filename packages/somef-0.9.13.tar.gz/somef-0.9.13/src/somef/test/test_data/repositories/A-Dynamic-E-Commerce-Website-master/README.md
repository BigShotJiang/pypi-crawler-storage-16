# A-Dynamic-E-Commerce-Website
## A dynamic e-commerce website built with PHP, MySQL, HTML and CSS
### Languages Used:
- HTML
- CSS
- PHP
- MySQL

MySQL Database folder contains the .sql file
mangola folder contains all the .php files

This is a very basic website built to implement dynamic website.
