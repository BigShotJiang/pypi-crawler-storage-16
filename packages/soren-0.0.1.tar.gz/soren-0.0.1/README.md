# Soren Fieldguide

Minimal React + TypeScript + Tailwind CSS frontend for Soren MVP.

## Overview

This is a lightweight dashboard for CLI onboarding and viewing evaluation runs. No authentication UI is included in this version.

## Tech Stack

- React 18
- TypeScript
- Tailwind CSS
- Vite
- React Router

## Getting Started

### Install Dependencies

```bash
npm install
```

### Run Development Server

```bash
npm run dev
```

The app will be available at http://localhost:5173

### Build for Production

```bash
npm run build
```

### Preview Production Build

```bash
npm run preview
```

## Project Structure

```
src/
├── api/              # API layer with mock data
├── components/       # Shared components
│   ├── ui/          # Reusable UI components
│   └── Layout.tsx   # Main layout with navigation
├── pages/           # Page components
│   ├── GettingStarted.tsx
│   ├── Runs.tsx
│   └── RunDetail.tsx
├── types/           # TypeScript interfaces
├── App.tsx          # Main app with routing
├── main.tsx         # Entry point
└── index.css        # Global styles with Tailwind
```

## Routes

- `/` - Getting Started page with CLI setup instructions
- `/runs` - List of all evaluation runs
- `/runs/:id` - Details for a specific run

## Features

- Minimalistic light theme using gray palette
- CLI onboarding flow with API key management
- Runs list with search and filtering
- Run detail view with metrics and logs
- Mock data structure ready for backend integration
