from setuptools import setup, find_packages

setup(
    name="soren",
    version="0.0.1",
    author="Your Name",
    author_email="your.email@example.com",
    description="Placeholder package - reserved name",
    long_description="This package name is reserved for future use.",
    long_description_content_type="text/plain",
    url="https://github.com/yourusername/soren",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
