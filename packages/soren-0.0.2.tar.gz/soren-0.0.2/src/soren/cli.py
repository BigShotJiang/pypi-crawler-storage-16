"""
Soren CLI - Command-line interface for Soren AI evaluation framework
"""
import argparse
import sys
import getpass
from . import __version__
from .client import SorenClient
from .config import SorenConfig


def handle_login(args):
    """Handle the login command"""
    config = SorenConfig()
    
    # Get credentials
    email = args.email or input("Email: ")
    password = args.password or getpass.getpass("Password: ")
    
    try:
        # Authenticate with backend
        client = SorenClient(base_url=config.get_api_url())
        response = client.login(email, password)
        
        # Store API key locally
        api_key = response.get('access_token')
        if api_key:
            config.set_api_key(api_key)
            print("✓ Successfully logged in!")
            print(f"API key stored in {config.config_file}")
        else:
            print("✗ Login failed: No API key received")
            sys.exit(1)
            
    except Exception as e:
        print(f"✗ Login failed: {e}")
        sys.exit(1)


def handle_run(args):
    """Handle the run command"""
    config = SorenConfig()
    api_key = config.get_api_key()
    
    if not api_key:
        print("✗ Not logged in. Run 'soren login' first.")
        sys.exit(1)
    
    try:
        client = SorenClient(api_key=api_key, base_url=config.get_api_url())
        
        # Create a new evaluation run
        run = client.create_run(
            project=args.project,
            # Add other parameters as needed
        )
        
        print(f"✓ Run created: {run.get('id')}")
        print(f"View at: {config.get_api_url() or 'https://soren-ai.com'}/runs/{run.get('id')}")
        
    except Exception as e:
        print(f"✗ Run failed: {e}")
        sys.exit(1)


def handle_logout(args):
    """Handle the logout command"""
    config = SorenConfig()
    config.clear()
    print("✓ Logged out successfully")


def main():
    """Main entry point for the Soren CLI"""
    parser = argparse.ArgumentParser(
        prog="soren",
        description="Soren AI - Evaluation framework CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    parser.add_argument(
        "--version",
        action="version",
        version=f"soren {__version__}",
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Login command
    login_parser = subparsers.add_parser("login", help="Authenticate with Soren")
    login_parser.add_argument("--email", help="Your email address")
    login_parser.add_argument("--password", help="Your password (will prompt if not provided)")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Create and run an evaluation")
    run_parser.add_argument("project", help="Project name")
    run_parser.add_argument("--dataset", help="Dataset to evaluate")
    run_parser.add_argument("--judge", help="Judge model to use")
    
    # Logout command
    logout_parser = subparsers.add_parser("logout", help="Clear stored credentials")
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        sys.exit(0)
    
    # Route to command handlers
    if args.command == "login":
        handle_login(args)
    elif args.command == "run":
        handle_run(args)
    elif args.command == "logout":
        handle_logout(args)
    else:
        print(f"Command '{args.command}' not yet implemented")


if __name__ == "__main__":
    main()
