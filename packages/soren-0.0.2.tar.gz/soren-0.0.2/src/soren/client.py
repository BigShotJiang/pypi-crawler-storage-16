"""
API client for communicating with the Soren backend service
"""
import os
import requests
from typing import Optional, Dict, Any


class SorenClient:
    """Client for interacting with the Soren backend API"""
    
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        """
        Initialize the Soren API client
        
        Args:
            api_key: API key for authentication (defaults to env var SOREN_API_KEY)
            base_url: Base URL for the Soren API (defaults to env var SOREN_API_URL or production URL)
        """
        self.api_key = api_key or os.getenv("SOREN_API_KEY")
        self.base_url = base_url or os.getenv("SOREN_API_URL", "https://api.soren-ai.com")
        self.session = requests.Session()
        
        if self.api_key:
            self.session.headers.update({"Authorization": f"Bearer {self.api_key}"})
    
    def login(self, email: str, password: str) -> Dict[str, Any]:
        """
        Authenticate with the Soren backend and retrieve API key
        
        Args:
            email: User email
            password: User password
            
        Returns:
            Response containing API key and user info
        """
        response = self.session.post(
            f"{self.base_url}/auth/login",
            data={"username": email, "password": password}
        )
        response.raise_for_status()
        return response.json()
    
    def create_run(self, project: str, **kwargs) -> Dict[str, Any]:
        """
        Create a new evaluation run
        
        Args:
            project: Project name
            **kwargs: Additional run parameters
            
        Returns:
            Response containing run ID and details
        """
        if not self.api_key:
            raise ValueError("API key required. Run 'soren login' first.")
        
        response = self.session.post(
            f"{self.base_url}/runs",
            json={"project": project, **kwargs}
        )
        response.raise_for_status()
        return response.json()
    
    def get_run(self, run_id: str) -> Dict[str, Any]:
        """
        Get details for a specific run
        
        Args:
            run_id: Run ID
            
        Returns:
            Run details
        """
        if not self.api_key:
            raise ValueError("API key required. Run 'soren login' first.")
        
        response = self.session.get(f"{self.base_url}/runs/{run_id}")
        response.raise_for_status()
        return response.json()
