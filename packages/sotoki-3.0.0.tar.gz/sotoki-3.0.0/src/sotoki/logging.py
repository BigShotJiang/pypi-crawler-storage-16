from sotoki.context import Context

context = Context.get()
logger = context.logger
