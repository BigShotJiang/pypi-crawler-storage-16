"""SpaC-Kit package initialization."""
