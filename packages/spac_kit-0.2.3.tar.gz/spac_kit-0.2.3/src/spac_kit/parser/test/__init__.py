"""Parser unit tests"""
