"""Tests for spark-dist-fit."""
