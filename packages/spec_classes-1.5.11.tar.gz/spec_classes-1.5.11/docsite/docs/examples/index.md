This section of the documentation provides some concrete examples for how you
can use `spec_classes` in the real world. It is intended to allow you to get a
quick sense of `spec_classes`'s capabilities, and to act as a quick-start guide
for the impatient. For more thorough usage documentation, refer to
[Usage](../usage/index.md).