"""
SpecFact CLI - Spec→Contract→Sentinel tool for contract-driven development.
"""

# Define the package version (kept in sync with pyproject.toml and setup.py)
__version__ = "0.16.3"
