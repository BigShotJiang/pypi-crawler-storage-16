Shortcut: New CLI release

Instructions:

1. Read @docs/general/agent-setup/github-cli-setup.md and make sure `gh` is working

2. Read @cli/docs/development.md for release steps and follow instructions to create a
   new release
