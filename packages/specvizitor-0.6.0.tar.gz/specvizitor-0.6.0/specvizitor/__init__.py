__all__ = [
    "ORGANIZATION",
    "APPLICATION"
]

ORGANIZATION = "FRESCO"
APPLICATION = __package__.split('.')[0].capitalize()
