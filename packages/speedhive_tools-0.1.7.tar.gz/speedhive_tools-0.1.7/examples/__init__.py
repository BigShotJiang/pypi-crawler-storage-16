"""Package marker for examples to allow importing example modules in tests."""

__all__ = []
