#!/usr/bin/env python3

from localecmd import Module, printout, programfunction


@programfunction()
def Func(a: int = 9, *b: float, cC: int = 8, **d: str):  # pragma: no cover
    """
    This is a docstring

    This has many lines

    ```python
    Doctest example
    >>> Func()

    ```
    :::{lcmd-example}
    Func 8 9 10 -cC 80
    :::

    """
    printout(a)


module = Module('test', [Func], 'Module docstring')

# Output to be parsed with myst-parser and sphinx
expected_output = """# Module test
Module docstring

```{py:function} Func a b... -cC -d... 
:label: Func

This is a docstring

This has many lines


:::{lcmd-example}
Func 8 9 10 -cC 80
:::
```
"""

# output as result from sphinx with markdown builder
expected_output_built_md = """# Module test

Module docstring

### Func a b... -cC -d...

This is a docstring

This has many lines

```bash
¤ Func 8 9 10 -cC 80
8
```

"""
# output as result from sphinx with markdown builder
expected_output_package = """# Module package

Module docstring

### Func a b... -cC -d...

This is a docstring

This has many lines

```bash
¤ Func 8 9 10 -cC 80
8
```

"""
