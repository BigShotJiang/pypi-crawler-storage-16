JSONs created using GitHub Copilot Pro.

To convert to locale files run _convert.py in this folder.