extensions = ["sphinxcontrib.pseudocode2"]

pseudocode2_math_engine = "katex"
