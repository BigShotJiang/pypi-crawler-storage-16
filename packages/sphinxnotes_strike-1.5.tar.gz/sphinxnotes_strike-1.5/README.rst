.. This file is generated from sphinx-notes/cookiecutter.
   You need to consider modifying the TEMPLATE or modifying THIS FILE.

==================
sphinxnotes-strike
==================

.. |docs| image:: https://img.shields.io/github/deployments/sphinx-notes/strike/github-pages
   :target: https://sphinx.silverrainz.me/strike
   :alt: Documentation Status
.. |license| image:: https://img.shields.io/github/license/sphinx-notes/strike
   :target: https://github.com/sphinx-notes/strike/blob/master/LICENSE
   :alt: Open Source License
.. |pypi| image:: https://img.shields.io/pypi/v/sphinxnotes-strike.svg
   :target: https://pypi.python.org/pypi/sphinxnotes-strike
   :alt: PyPI Package
.. |download| image:: https://img.shields.io/pypi/dm/sphinxnotes-strike
   :target: https://pypistats.org/packages/sphinxnotes-strike
   :alt: PyPI Package Downloads

|docs| |license| |pypi| |download|

An extension that adds strikethrough text support to Sphinx.

.. INTRODUCTION START 
   (MUST written in standard reStructuredText, without Sphinx stuff)

.. INTRODUCTION END

Please refer to Documentation_ for more details.

.. _Documentation: https://sphinx.silverrainz.me/strike
