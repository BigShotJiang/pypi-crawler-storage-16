![logo](_media/spiderweb_logo_cropped.png)

> the web framework just big enough for a spider

[GitHub](https://github.com/itsthejoker/spiderweb/)
[Get Started](/README)


![color](#222)
