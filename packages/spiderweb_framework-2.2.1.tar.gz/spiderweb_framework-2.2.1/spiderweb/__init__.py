from spiderweb.main import SpiderwebRouter  # noqa: F401
from spiderweb.middleware import *  # noqa: F401, F403
from spiderweb.constants import __version__ as __version__
