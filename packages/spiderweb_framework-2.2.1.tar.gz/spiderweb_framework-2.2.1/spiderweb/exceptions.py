class SpiderwebException(Exception):
    # parent error class; all child exceptions should inherit from this
    def __str__(self):
        name = self.__class__.__name__
        msg = self.args[0] if len(self.args) > 0 else ""
        if msg:
            return f"{name}() - {msg}"
        return f"{name}()"


class SpiderwebNetworkException(SpiderwebException):
    """Something has gone wrong with the network stack."""

    def __init__(self, code, msg=None, desc=None):
        self.code = code
        self.msg = msg
        self.desc = desc

    def __str__(self):
        return f"{self.__class__.__name__}({self.code}, {self.msg})"


class APIError(SpiderwebNetworkException):
    pass


class NotFound(SpiderwebNetworkException):
    def __init__(self):
        self.code = 404
        self.msg = "Not Found"
        self.desc = "The requested resource could not be found"


class BadRequest(SpiderwebNetworkException):
    def __init__(self, desc=None):
        self.code = 400
        self.msg = "Bad Request"
        self.desc = (
            desc if desc else "The request could not be understood by the server"
        )


class Unauthorized(SpiderwebNetworkException):
    def __init__(self, desc=None):
        self.code = 401
        self.msg = "Unauthorized"
        self.desc = desc if desc else "The request requires user authentication"


class Forbidden(SpiderwebNetworkException):
    def __init__(self, desc=None):
        self.code = 403
        self.msg = "Forbidden"
        self.desc = desc if desc else "You are not allowed to access this resource"


class ServerError(SpiderwebNetworkException):
    def __init__(self, desc=None):
        self.code = 500
        self.msg = "Internal Server Error"
        self.desc = desc if desc else "The server has encountered an error"


class CSRFError(SpiderwebNetworkException):
    def __init__(self, desc=None):
        self.code = 403
        self.msg = "Forbidden"
        self.desc = desc if desc else "CSRF token is invalid"


class ConfigError(SpiderwebException):
    pass


class ParseError(SpiderwebException):
    pass


class GeneralException(SpiderwebException):
    pass


class UnusedMiddleware(SpiderwebException):
    pass


class NoResponseError(SpiderwebException):
    pass


class StartupErrors(ExceptionGroup):
    pass


class ReverseNotFound(SpiderwebException):
    pass
