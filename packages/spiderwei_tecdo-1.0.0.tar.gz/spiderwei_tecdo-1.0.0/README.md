# spiderWei_TecDo 爬虫框架

快速创建和运行爬虫任务的脚手架框架。

## 安装

```bash
# 开发模式安装（推荐）
cd spiderWei
pip install -e .

# 或直接安装
pip install .
```

## 快速开始

### 1. 创建爬虫

```bash
# 在当前目录创建爬虫
spiderWei_TecDo start my_spider

# 在指定目录创建
spiderWei_TecDo start my_spider -o ./spiders
```

### 2. 查看配置说明

```bash
spiderWei_TecDo list
```

### 3. 编辑生成的爬虫文件

打开生成的 `my_spider.py`，修改以下内容：

1. **Apollo 配置** - 根据实际环境修改
   ```python
   APOLLOID='Your-Apollo-ID',
   APOLLO_URL_TEST='http://your-test-apollo.com',
   APOLLO_URL_PROD='http://your-prod-apollo.com',
   ```

2. **数据推送配置** - 二选一
   ```python
   DB_table_name='your_table_name',  # 直接写表
   # 或
   DB_topic_name='your_topic_name',  # 写 Kafka
   ```

3. **实现 `getexeList()` 函数** - 构造任务列表
   ```python
   def getexeList():
       return [{"id": 1}, {"id": 2}, {"id": 3}]
   ```

4. **实现 `main(arg, app)` 函数** - 编写采集逻辑
   ```python
   def main(arg, app):
       # 发起请求
       result = app.crawl.crawl(f"https://api.example.com/{arg['id']}")
       data = json.loads(result['html'])
       
       # 推送数据
       app.push_queue.put({"id": arg['id'], "data": data})
   ```

### 4. 运行爬虫

```bash
python my_spider.py
```

## 配置项说明

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| **Apollo配置** | | |
| APOLLOID | Apollo 应用ID | 'Creatives-spider' |
| APOLLO_URL_TEST | 测试环境 Apollo 地址 | 'http://dev-apollo.tec-develop.com' |
| APOLLO_URL_PROD | 生产环境 Apollo 地址 | 'http://hwsgprod.in.apolloconfig...:8080' |
| **环境配置** | | |
| isTest | 从环境变量 ISTEST 获取 | 默认 1 (测试环境) |
| Threadnum | 并发线程数 | 20 |
| **代理配置** | | |
| openproXies | 是否启用代理 | 1 (启用) |
| **数据库配置** | | |
| readDb | 是否连接数据库 | 1 (连接) |
| DB_table_name | 数仓表名 | '' |
| DB_topic_name | Kafka Topic | '' |
| PRIMARY_KEY_NAME | 主键名 | '' |
| **Kafka配置** | | |
| needKafka | 是否需要Kafka | 1 (需要) |
| download_topic_name | 下载器Topic | '' |
| **OBS/OSS配置** | | |
| needOBS | 是否需要对象存储 | 0 (不需要) |
| isHwOBS | OBS类型 | 0 (阿里云) |
| **调试配置** | | |
| is_print_item | 是否打印推送数据 | 0 (不打印) |

## 环境变量

```bash
# Windows
set ISTEST=0    # 0=生产环境, 1=测试环境

# Linux/Mac
export ISTEST=0
```

## app 对象属性

在 `main(arg, app)` 函数中，`app` 对象提供以下属性：

- `app.push_queue` - 数据推送队列
- `app.download_queue` - 下载器队列
- `app.holo_client` - 数据库客户端
- `app.OBSHelper` - OBS/OSS 客户端
- `app.videoOp` - 视频操作工具
- `app.fileOp` - 文件操作工具
- `app.crawl` - 爬虫请求工具
- `app.configurations` - Apollo 配置

## 依赖

- requests
- psycopg
- kafka-python
- yt-dlp
- esdk-obs-python
- oss2
