"""
爬虫框架 spiderWei_TecDo
========================

快速创建和运行爬虫任务的脚手架框架。

使用方式:
    1. 命令行创建爬虫: spiderWei_TecDo start my_spider
    2. 在生成的文件中配置 settings
    3. 实现 getexeList() 和 main() 函数
    4. 运行: python my_spider.py

示例:
    from spiderWei_TecDo import run_spider, SpiderSettings
    
    settings = SpiderSettings(
        APOLLOID='Your-Apollo-ID',
        Threadnum=20,
        DB_topic_name='your_topic',
    )
    
    def getexeList():
        return [{"id": 1}, {"id": 2}]
    
    def main(arg, app):
        app.push_queue.put({"data": arg})
    
    run_spider(main, getexeList, settings)
"""

from .framework import SpiderSettings, SpiderApp, run_spider
from .tools import (
    configHelper,
    KafkaHelper,
    HologresClient,
    HwyOBSHelper,
    AiyunOBSHelper,
    Mthread,
    videoOperations,
    FileOperations,
    Crawl,
    proxyList,
)

__version__ = "1.0.0"
__all__ = [
    "SpiderSettings",
    "SpiderApp", 
    "run_spider",
    "configHelper",
    "KafkaHelper",
    "HologresClient",
    "HwyOBSHelper",
    "AiyunOBSHelper",
    "Mthread",
    "videoOperations",
    "FileOperations",
    "Crawl",
    "proxyList",
]
