#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
爬虫脚手架 CLI 工具
用法：
    spiderWei_TecDo start <爬虫名称>           # 创建新爬虫
    spiderWei_TecDo start <爬虫名称> -o <目录>  # 指定输出目录
    spiderWei_TecDo list                       # 列出配置项说明
"""
import argparse
import os
import sys
from datetime import datetime


# 爬虫模板内容
SPIDER_TEMPLATE = '''# -*- coding: utf-8 -*-
"""
爬虫名称: {spider_name}
创建时间: {create_time}
描述: 在此添加爬虫描述
"""
from spiderWei_TecDo import run_spider, SpiderSettings


# ============================================================================
#                              配置区域 (必填)
# ============================================================================
# 环境说明: isTest 从环境变量 ISTEST 获取，不存在则默认为 1（测试环境）
#          设置环境变量: set ISTEST=0 (Windows) 或 export ISTEST=0 (Linux/Mac)
#          也可在 settings 中设置 isTest=0 覆盖环境变量

settings = SpiderSettings(
    # ==================== Apollo配置 ⭐必须根据实际情况修改 ====================
    APOLLOID='Creatives-spider',                                       # Apollo 应用ID
    APOLLO_URL_TEST='http://dev-apollo.tec-develop.com',               # 测试环境 Apollo 地址
    APOLLO_URL_PROD='http://hwsgprod.in.apolloconfig.tec-develop.com:8080',  # 生产环境 Apollo 地址
    
    # ==================== 基础配置 ====================
    # isTest=0,                  # 可选：覆盖环境变量，0=生产环境, 1=测试环境
    Threadnum=1,                # 并发线程数
    
    # ==================== 代理配置 ====================
    openproXies=0,               # 是否启用代理: 1=启用, 0=禁用
    IPlist='IPlist',             # Apollo配置中代理IP列表的key名
    
    # ==================== 数据库配置 ====================
    readDb=1,                    # 是否连接数据库: 1=连接, 0=不连接
    
    # ⚠️ 以下两项二选一，不能同时设置
    # ⚠️ 测试环境(isTest=1)可都为空(不推送)，生产环境(isTest=0)必须设置一个
    DB_table_name='',            # 直接写入数仓表名
    DB_topic_name='',            # 写入Kafka Topic，由数仓消费
    
    PRIMARY_KEY_NAME='',         # 主键名 (重复则更新)，支持多主键: "col1,col2"
    
    # ==================== Kafka配置 ====================
    needKafka=0,                 # 是否需要Kafka: 1=需要, 0=不需要
    download_topic_name='',      # 下载器Topic，留空则不推送下载器
    # download_topic_name='common_material_topic',  # 需要下载器时启用此行
    
    # ==================== OBS/OSS配置 ====================
    needOBS=0,                   # 是否需要对象存储: 1=需要, 0=不需要
    isHwOBS=0,                   # OBS类型: 1=华为云OBS, 0=阿里云OSS
    
    # ==================== 调试配置 ====================
    is_print_item=0,             # 是否打印推送数据: 1=打印, 0=不打印
)


# ============================================================================
#                           任务列表构造 (必填)
# ============================================================================
def getexeList():
    """
    构造需要采集的任务列表
    返回值会依次传入 main 函数的 arg 参数
    
    示例:
        return [
            {{"url": "https://example.com/1", "id": 1}},
            {{"url": "https://example.com/2", "id": 2}},
        ]
    """
    argsList = []
    
    # TODO: 在此构造任务列表
    # 可以从数据库读取、从文件读取、或直接构造
    # 例如: argsList = [dict(id=i) for i in range(100)]
    
    return argsList


# ============================================================================
#                            主处理函数 (必填)
# ============================================================================
def main(arg, app):
    """
    单个任务的处理函数
    
    Args:
        arg: 任务参数，来自 getexeList 返回的列表中的一个元素
        app: SpiderApp 实例，提供以下属性和方法:
            - app.push_queue      : 数据推送队列，使用 app.push_queue.put(dict) 推送
            - app.download_queue  : 下载器队列，使用 app.download_queue.put(dict) 推送
            - app.holo_client     : 数据库客户端 (如果 readDb=1)
            - app.OBSHelper       : OBS/OSS 客户端 (如果 needOBS=1)
            - app.videoOp         : 视频操作工具
            - app.fileOp          : 文件操作工具
            - app.crawl           : 爬虫请求工具
            - app.configurations  : Apollo 配置
    """
    # -------------------- 数据结构示例 --------------------
    # 推送到数仓的数据格式
    itemDict = {{
        # "id": arg.get("id"),
        # "title": "示例标题",
        # "content": "示例内容",
        # "create_time": int(time.time()),
    }}
    
    # 推送到下载器的数据格式 (如果需要)
    itemDict_download = {{
        # "key": "唯一标识",
        # "file_name": "文件名",
        # "url": "下载地址",
        # "site": "平台名称",
    }}
    
    # -------------------- 开发区域 --------------------
    """
    在此编写你的采集逻辑:
    
    1. 发起请求:
       result = app.crawl.crawl(url, headers={{}}, ...)
       html = result['html']
    
    2. 解析数据:
       import json
       data = json.loads(html)
    
    3. 构造 itemDict
    
    4. 如需下载素材，构造 itemDict_download
    """
    
    
    
    # -------------------- 数据推送 --------------------
    # 推送数据到数仓
    if itemDict:
        app.push_queue.put(itemDict)
    
    # 推送到下载器 (如果配置了 download_topic_name)
    if settings.download_topic_name and itemDict_download:
        app.download_queue.put(itemDict_download)
    
    # 防止数据堆积
    if app.push_queue.qsize() > 1000:
        import time
        while app.push_queue.qsize() > 100:
            print(f"数据堆积，等待推送...剩余: {{app.push_queue.qsize()}}")
            time.sleep(5)


# ============================================================================
#                                 启动入口
# ============================================================================
if __name__ == "__main__":
    run_spider(main, getexeList, settings)
'''


def create_spider(name: str, output_dir: str = '.'):
    """创建新的爬虫文件"""
    # 清理名称
    safe_name = name.replace('-', '_').replace(' ', '_')
    if not safe_name.isidentifier():
        print(f"❌ 错误: '{name}' 不是有效的 Python 标识符")
        sys.exit(1)
    
    # 构建文件路径
    filename = f"{safe_name}.py"
    filepath = os.path.join(output_dir, filename)
    
    # 检查文件是否存在
    if os.path.exists(filepath):
        response = input(f"⚠️  文件 '{filepath}' 已存在，是否覆盖? (y/N): ")
        if response.lower() != 'y':
            print("已取消")
            sys.exit(0)
    
    # 生成内容
    content = SPIDER_TEMPLATE.format(
        spider_name=safe_name,
        create_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    )
    
    # 写入文件
    os.makedirs(output_dir, exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"""
✅ 爬虫创建成功!

   文件位置: {os.path.abspath(filepath)}

📝 下一步:
   1. 打开 {filename}
   2. 修改 Apollo 配置（APOLLOID、APOLLO_URL_TEST、APOLLO_URL_PROD）
   3. 修改 settings 配置（设置 DB_table_name 或 DB_topic_name）
   4. 实现 getexeList() 函数，构造任务列表
   5. 实现 main(arg, app) 函数，编写采集逻辑
   6. 运行: python {filename}
""")


def show_settings_help():
    """显示配置项说明"""
    help_text = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                        SpiderSettings 配置项说明                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  【Apollo配置】⭐ 必须根据实际情况修改                                         ║
║  ├─ APOLLOID          Apollo 应用ID                                          ║
║  │                    默认: 'Creatives-spider'                               ║
║  ├─ APOLLO_URL_TEST   测试环境 Apollo 地址                                    ║
║  │                    默认: 'http://dev-apollo.tec-develop.com'              ║
║  └─ APOLLO_URL_PROD   生产环境 Apollo 地址                                    ║
║                       默认: 'http://hwsgprod.in.apolloconfig...:8080'        ║
║                                                                              ║
║  【环境配置】                                                                 ║
║  └─ isTest            从环境变量 ISTEST 获取，不存在则默认为 1                 ║
║                       0 = 生产环境, 1 = 测试环境                              ║
║                       可在 settings 中设置 isTest=0 覆盖环境变量               ║
║                       环境变量设置: set ISTEST=0 (Win) / export ISTEST=0      ║
║                                                                              ║
║  【基础配置】                                                                 ║
║  └─ Threadnum         并发线程数，默认 20                                     ║
║                                                                              ║
║  【代理配置】                                                                 ║
║  ├─ openproXies       是否启用代理，1=启用, 0=禁用                            ║
║  └─ IPlist            Apollo配置中代理IP列表的key名，默认 'IPlist'            ║
║                                                                              ║
║  【数据库配置】                                                               ║
║  ├─ readDb            是否连接数据库，1=连接, 0=不连接                         ║
║  ├─ DB_table_name     直接写入的数仓表名                                      ║
║  ├─ DB_topic_name     写入Kafka Topic，由数仓消费                             ║
║  │                    ⚠️ 以上两项二选一，不能同时设置                          ║
║  │                    ⚠️ 测试环境(isTest=1)可都为空，生产环境必须设置一个       ║
║  └─ PRIMARY_KEY_NAME  主键名，重复数据则更新                                   ║
║                       支持多主键格式: "col1,col2,col3"                        ║
║                                                                              ║
║  【Kafka配置】                                                                ║
║  ├─ needKafka         是否需要Kafka，1=需要, 0=不需要                          ║
║  └─ download_topic_name                                                      ║
║                       下载器Topic，留空则不推送下载器                          ║
║                       常用值: 'common_material_topic'                        ║
║                                                                              ║
║  【OBS/OSS配置】                                                              ║
║  ├─ needOBS           是否需要对象存储，1=需要, 0=不需要                        ║
║  └─ isHwOBS           OBS类型，1=华为云OBS, 0=阿里云OSS                        ║
║                                                                              ║
║  【调试配置】                                                                 ║
║  └─ is_print_item     是否打印推送数据，1=打印, 0=不打印                       ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
    print(help_text)


def main():
    parser = argparse.ArgumentParser(
        description='🕷️ spiderWei_TecDo 爬虫脚手架 CLI 工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
  spiderWei_TecDo start my_spider                 创建名为 my_spider.py 的爬虫
  spiderWei_TecDo start meta_ads -o ./spiders     在 ./spiders 目录下创建
  spiderWei_TecDo list                            查看配置项说明
        '''
    )
    
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # start 命令
    start_parser = subparsers.add_parser('start', help='创建新爬虫')
    start_parser.add_argument('name', help='爬虫名称')
    start_parser.add_argument('-o', '--output', default='.', help='输出目录，默认当前目录')
    
    # list 命令
    subparsers.add_parser('list', help='查看配置项说明')
    
    args = parser.parse_args()
    
    if args.command == 'start':
        create_spider(args.name, args.output)
    elif args.command == 'list':
        show_settings_help()
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
