"""
爬虫框架 spiderWei_TecDo
========================

快速创建和运行爬虫任务的脚手架框架。

使用方式:
    1. 命令行创建爬虫: spiderWei_TecDo start my_spider
    2. 在生成的文件中配置 settings
    3. 实现 getexeList(app) 和 main(arg, app) 函数
    4. 运行: python my_spider.py

示例:
    from spiderWei_TecDo import run_spider, SpiderSettings
    
    settings = SpiderSettings(
        APOLLOID='Your-Apollo-ID',
        Threadnum=20,
        readDb=1,
        DB_topic_name='your_topic',
    )
    
    def getexeList(app):
        # 可以直接使用 app.holo_client 查询数据库
        sql = "SELECT id, url FROM your_table LIMIT 10"
        results = app.holo_client.execute_sql_query(sql)
        return [{"id": row[0], "url": row[1]} for row in results]
    
    def main(arg, app):
        app.push_queue.put({"data": arg})
    
    run_spider(main, getexeList, settings)
"""

from .framework import SpiderSettings, SpiderApp, run_spider
from .tools import (
    configHelper,
    KafkaHelper,
    HologresClient,
    HwyOBSHelper,
    AiyunOBSHelper,
    Mthread,
    videoOperations,
    FileOperations,
    Crawl,
    proxyList,
)

__version__ = "1.1.0"
__all__ = [
    "SpiderSettings",
    "SpiderApp", 
    "run_spider",
    "configHelper",
    "KafkaHelper",
    "HologresClient",
    "HwyOBSHelper",
    "AiyunOBSHelper",
    "Mthread",
    "videoOperations",
    "FileOperations",
    "Crawl",
    "proxyList",
]
