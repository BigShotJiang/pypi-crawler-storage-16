"""
爬虫框架核心模块
"""
import os
import time
import queue
import threading
import json
from typing import List, Callable, Any, Optional
from dataclasses import dataclass

from .tools import (
    configHelper, KafkaHelper, HologresClient,
    HwyOBSHelper, AiyunOBSHelper, Mthread,
    videoOperations, FileOperations, Crawl, proxyList
)


def _get_isTest_from_env() -> int:
    """从环境变量获取 isTest，默认为 1（测试环境）"""
    env_val = os.getenv("ISTEST")
    if env_val is None:
        return 1  # 默认测试环境
    try:
        return int(env_val)
    except (ValueError, TypeError):
        return 1


@dataclass
class SpiderSettings:
    """
    爬虫配置类 - 根据实际需求调整以下参数
    """
    # ==================== Apollo配置 ====================
    APOLLOID: str = 'Creatives-spider'                                      # Apollo 应用ID
    APOLLO_URL_TEST: str = 'http://dev-apollo.tec-develop.com'              # 测试环境 Apollo 地址
    APOLLO_URL_PROD: str = 'http://hwsgprod.in.apolloconfig.tec-develop.com:8080'  # 生产环境 Apollo 地址
    
    # ==================== 基础配置 ====================
    Threadnum: int = 1                   # 并发线程数
    
    # ==================== 代理配置 ====================
    openproXies: int = 0                  # 是否启用代理: 1=启用, 0=禁用
    IPlist: str = 'IPlist'                # Apollo配置中代理IP列表的key名
    
    # ==================== 数据库配置 ====================
    readDb: int = 0                       # 是否连接数据库: 1=连接, 0=不连接
    DB_table_name: str = ''               # 数仓表名 (与 DB_topic_name 二选一)
    PRIMARY_KEY_NAME: str = ''            # 主键名称，重复则更新 (支持多主键: "col1,col2")
    
    # ==================== Kafka配置 ====================
    needKafka: int = 0                    # 是否需要Kafka: 1=需要, 0=不需要
    DB_topic_name: str = ''               # 数仓Topic (与 DB_table_name 二选一)
    download_topic_name: str = ''         # 下载器Topic，留空则不推送下载器
    
    # ==================== OBS/OSS配置 ====================
    needOBS: int = 0                      # 是否需要对象存储: 1=需要, 0=不需要
    isHwOBS: int = 0                      # OBS类型: 1=华为云OBS, 0=阿里云OSS
    
    # ==================== 调试配置 ====================
    is_print_item: int = 0                # 是否打印推送数据: 1=打印, 0=不打印
    
    # isTest 从环境变量获取，此字段仅用于覆盖（一般不需要手动设置）
    _isTest_override: Optional[int] = None
    
    @property
    def isTest(self) -> int:
        """获取环境配置：优先使用覆盖值，否则从环境变量获取"""
        if self._isTest_override is not None:
            return self._isTest_override
        return _get_isTest_from_env()
    
    @isTest.setter
    def isTest(self, value: Optional[int]):
        """设置环境配置（覆盖环境变量）"""
        self._isTest_override = value


class SpiderApp:
    """爬虫应用运行器"""
    
    def __init__(
        self,
        main_func: Callable[[Any], Any],
        getexeList_func: Callable[[], List[Any]],
        settings: SpiderSettings,
    ):
        self.main_func = main_func
        self.getexeList_func = getexeList_func
        self.settings = settings

        # 运行期队列
        self.Task_queue = queue.Queue()
        self.push_queue = queue.Queue()
        self.download_queue = queue.Queue()
        
        # 统计数据
        self.push_data_num = 0
        self.push_data_num_download = 0
        self.spider_time = int(time.time())
        self.init_num = 0

        # 外部依赖实例
        self.configurations = {}
        self.pushKfk = None
        self.holo_client = None
        self.OBSHelper = None
        self.OSS_Http_Link = ''
        
        # 工具类实例
        self.videoOp = videoOperations()
        self.fileOp = FileOperations()
        self.crawl = Crawl()

    def _validate_config(self):
        """校验配置合法性"""
        has_table = bool(self.settings.DB_table_name)
        has_topic = bool(self.settings.DB_topic_name)
        
        if has_table and has_topic:
            raise ValueError("配置错误: DB_table_name 与 DB_topic_name 不能同时设置，请选择其一")
        
        # 测试环境下允许都为空（不推送数据，仅调试）
        if not has_table and not has_topic:
            if self.settings.isTest == 1:
                print("⚠️  测试环境: DB_table_name 与 DB_topic_name 均为空，数据不会推送")
            else:
                raise ValueError("配置错误: 生产环境下 DB_table_name 与 DB_topic_name 至少设置一个")

    def _init_dependencies(self):
        """初始化外部依赖"""
        apollo_config = configHelper()
        self.configurations = apollo_config.fetch_apollo_config(
            self.settings.isTest,
            APOLLOID=self.settings.APOLLOID,
            APOLLO_URL_TEST=self.settings.APOLLO_URL_TEST,
            APOLLO_URL_PROD=self.settings.APOLLO_URL_PROD,
        )

        # Kafka
        if self.settings.needKafka == 1 and self.configurations.get("kafkaAddress"):
            self.pushKfk = KafkaHelper(list(eval(self.configurations["kafkaAddress"])))

        # 代理IP
        if self.settings.openproXies == 1:
            # 使用 IPlist 作为 key 从 Apollo 配置获取代理IP列表
            ip_list = eval(self.configurations.get(self.settings.IPlist, "[]"))
            proxyList.clear()
            proxyList.extend(ip_list)

        # 数据库
        if self.settings.readDb == 1 and self.configurations.get("holoHost"):
            self.holo_client = HologresClient(
                self.configurations["holoHost"],
                self.configurations["holoPort"],
                self.configurations["holoDBname"],
                self.configurations["holoUser"],
                self.configurations["holoPassword"],
            )

        # OBS/OSS
        if self.settings.needOBS == 1:
            if self.settings.isHwOBS == 1:
                self.OBSHelper = HwyOBSHelper(
                    self.configurations["HWOBS_AK"],
                    self.configurations["HWOBS_SK"],
                    self.configurations["HWOBS_Endpoint"],
                    self.configurations["HWOBS_BucketName"],
                )
                self.OSS_Http_Link = self.configurations["HWOBS_Link"]
            else:
                self.OBSHelper = AiyunOBSHelper(
                    self.configurations["AliOSS_AK"],
                    self.configurations["AliOSS_SK"],
                    self.configurations["AliOSS_BucketName"],
                    self.configurations["AliOSS_Endpoint"],
                )
                self.OSS_Http_Link = self.configurations["AliOSS_Link"]

    def _fill_tasks(self):
        """填充任务队列"""
        # 传递 self (app) 给 getexeList，使其可以访问 holo_client 等资源
        exe_list = self.getexeList_func(self) or []
        self.init_num = len(exe_list)
        print(f"初始化任务队列，任务数量: {self.init_num}")
        for arg in exe_list:
            self.Task_queue.put(arg)

    def _push_thread(self):
        """数据推送线程"""
        while True:
            # 测试模式：两个目标都为空时，仅消费队列不推送
            if not self.push_queue.empty() and not self.settings.DB_table_name and not self.settings.DB_topic_name:
                loop_num = min(self.push_queue.qsize(), 1000)
                for _ in range(loop_num):
                    if self.push_queue.empty():
                        break
                    item = self.push_queue.get()
                    self.push_data_num += 1
                    if self.settings.is_print_item:
                        print("测试模式数据-->", item)
            
            # 推送到数据库表
            if not self.push_queue.empty() and self.settings.DB_table_name:
                loop_num = min(self.push_queue.qsize(), 1000)
                data_list = []
                for _ in range(loop_num):
                    if self.push_queue.empty():
                        break
                    item = self.push_queue.get()
                    if isinstance(item, str):
                        try:
                            item = json.loads(item)
                        except:
                            print(f"警告: 无法解析为字典: {item}")
                            continue
                    if isinstance(item, dict):
                        if self.settings.is_print_item:
                            print("推送数据-->", item)
                        self.push_data_num += 1
                        data_list.append(item)
                
                if data_list and self.holo_client:
                    try:
                        self.holo_client.batch_insert(
                            self.settings.DB_table_name,
                            data_list,
                            CONFLICT_COLUMN=self.settings.PRIMARY_KEY_NAME,
                        )
                    except Exception as e:
                        print(f"数据库推送失败: {e}")

            # 推送到 Kafka Topic
            if not self.push_queue.empty() and self.settings.DB_topic_name:
                loop_num = min(self.push_queue.qsize(), 1000)
                for _ in range(loop_num):
                    if self.push_queue.empty():
                        break
                    item = self.push_queue.get()
                    self.push_data_num += 1
                    if isinstance(item, str):
                        try:
                            item = json.loads(item)
                        except:
                            continue
                    try:
                        if self.settings.is_print_item:
                            print("推送数据-->", item)
                        if self.pushKfk:
                            self.pushKfk.sendToKafka(item, topic_name=self.settings.DB_topic_name)
                    except Exception as e:
                        print(f"Kafka推送失败: {e}")

            # 推送到下载器
            if self.settings.download_topic_name and not self.download_queue.empty():
                loop_num = min(self.download_queue.qsize(), 1000)
                for _ in range(loop_num):
                    if self.download_queue.empty():
                        break
                    item = self.download_queue.get()
                    self.push_data_num_download += 1
                    try:
                        if self.settings.is_print_item:
                            print("下载器数据-->", item)
                        if self.pushKfk:
                            self.pushKfk.sendToKafka(item, topic_name=self.settings.download_topic_name)
                    except Exception as e:
                        print(f"下载器推送失败: {e}")

            # 检查是否结束
            if self.Task_queue.empty() and self.push_queue.empty() and self.download_queue.empty():
                time.sleep(5)
                if self.Task_queue.empty() and self.push_queue.empty() and self.download_queue.empty():
                    break
            time.sleep(2)

    def _print_info(self):
        """状态打印线程"""
        while True:
            now = int(time.time())
            elapsed = now - self.spider_time
            remaining = self.Task_queue.qsize()
            completed = self.init_num - remaining
            
            print("\n" + "=" * 80)
            print(f"  开始时间: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(self.spider_time))}")
            print(f"  当前时间: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(now))}")
            print(f"  运行时长: {elapsed // 60} 分 {elapsed % 60} 秒")
            print(f"  任务进度: {completed}/{self.init_num} (剩余: {remaining})")
            print(f"  推送队列: {self.push_queue.qsize()} | 下载队列: {self.download_queue.qsize()}")
            print(f"  累计推送: {self.push_data_num} | 下载器推送: {self.push_data_num_download}")
            print(f"  线程数量: {self.settings.Threadnum}")
            
            if completed > 0 and elapsed > 0:
                speed = completed / elapsed
                eta = int(remaining / speed) if speed > 0 else 0
                print(f"  处理速度: {speed:.2f} 条/秒")
                print(f"  预计剩余: {eta // 60} 分 {eta % 60} 秒")
            print("=" * 80 + "\n")
            
            time.sleep(30)

    def _wrapped_main(self, arg):
        """包装 main 函数，注入上下文"""
        return self.main_func(arg, self)

    def run(self):
        """启动爬虫"""
        print("\n🕷️  爬虫启动中...")
        env_name = "测试环境" if self.settings.isTest == 1 else "生产环境"
        print(f"   环境: {env_name} (isTest={self.settings.isTest})")
        print(f"   Apollo: {self.settings.APOLLOID}")
        print(f"   配置: Threadnum={self.settings.Threadnum}, openproXies={self.settings.openproXies}")
        
        self._validate_config()
        self._init_dependencies()
        self._fill_tasks()

        if self.init_num == 0:
            print("⚠️  任务列表为空，退出")
            return

        # 启动推送线程
        push_thread = threading.Thread(target=self._push_thread, daemon=True)
        push_thread.start()

        # 启动打印线程
        print_thread = threading.Thread(target=self._print_info, daemon=True)
        print_thread.start()

        # 启动工作线程
        thread_list = []
        for _ in range(self.settings.Threadnum):
            t = Mthread(self.Task_queue, lambda arg: self._wrapped_main(arg))
            thread_list.append(t)
        
        for t in thread_list:
            t.start()
        for t in thread_list:
            t.join()

        # 等待推送完成
        push_thread.join(timeout=30)
        print("\n✅ 爬虫任务完成!")


def run_spider(
    main_func: Callable[[Any, 'SpiderApp'], Any],
    getexeList_func: Callable[['SpiderApp'], List[Any]],
    settings: SpiderSettings,
):
    """
    启动爬虫的入口函数
    
    Args:
        main_func: 主处理函数，签名为 main(arg, app)
        getexeList_func: 返回任务列表的函数，签名为 getexeList(app)
        settings: SpiderSettings 配置实例
    """
    app = SpiderApp(main_func, getexeList_func, settings)
    app.run()

