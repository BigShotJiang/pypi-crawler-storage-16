"""
爬虫工具类集合
包含 Apollo 配置、OBS/OSS、Kafka、数据库、多线程等工具
"""
import requests
import os
import hashlib
import time
from obs import ObsClient
import yt_dlp
import random
from typing import List
import psycopg
import traceback
from threading import Thread
from kafka import KafkaProducer
import json
from urllib.parse import urlparse
from datetime import datetime
import gzip
import urllib.request
import logging
import sys
from io import StringIO
import oss2


# 代理IP列表（全局共享）
proxyList = []

# Apollo 默认配置
APOLLO_DEFAULT_ID = "Creatives-spider"
APOLLO_DEFAULT_URL_TEST = "http://dev-apollo.tec-develop.com"
APOLLO_DEFAULT_URL_PROD = "http://hwsgprod.in.apolloconfig.tec-develop.com:8080"


class configHelper:
    """Apollo 配置获取工具"""
    
    def __init__(self):
        pass
    
    def fetch_apollo_config(
        self,
        isTest,
        APOLLOID: str = None,
        APOLLO_URL_TEST: str = None,
        APOLLO_URL_PROD: str = None,
    ):
        """
        获取 Apollo 配置
        
        Args:
            isTest: 环境标识，1=测试环境，0=生产环境
            APOLLOID: Apollo 应用ID，默认 "Creatives-spider"
            APOLLO_URL_TEST: 测试环境 Apollo 地址
            APOLLO_URL_PROD: 生产环境 Apollo 地址
        """
        # 使用默认值
        APOLLOID = APOLLOID or APOLLO_DEFAULT_ID
        APOLLO_URL_TEST = APOLLO_URL_TEST or APOLLO_DEFAULT_URL_TEST
        APOLLO_URL_PROD = APOLLO_URL_PROD or APOLLO_DEFAULT_URL_PROD
        
        # 处理 isTest
        if isTest is None:
            isTest = 0
        else:
            try:
                isTest = int(isTest)
            except (ValueError, TypeError):
                isTest = 0
        
        # 根据环境选择 URL
        if isTest == 1:
            APOLLO_URL = APOLLO_URL_TEST
            url = f"{APOLLO_URL}/configs/{APOLLOID}/DEV/application"
        else:
            APOLLO_URL = APOLLO_URL_PROD
            url = f"{APOLLO_URL}/configs/{APOLLOID}/PRO-HWSG/application"
            
        config_data = {}
        try:
            response = requests.get(url, timeout=5)
            response.raise_for_status()
            config_data = response.json()
        except Exception as err:
            print(f"Apollo 配置获取失败: {err}")
        
        configurations = config_data.get("configurations", {})
        if configurations:
            return configurations
        else:
            print("Apollo 获取配置失败，请检查配置是否正确")
            print(f"  URL: {url}")
            return {}


class HwyOBSHelper:
    """华为云 OBS 工具类"""
    
    def __init__(self, ak='', sk='', server='', bucketName='', endpoint=""):
        self.ak = ak
        self.sk = sk
        self.server = server
        self.bucketName = bucketName
        self.endpoint = endpoint
        self.obs_client = ObsClient(
            access_key_id=self.ak,
            secret_access_key=self.sk,
            server=self.server
        )
    
    def upload_file(self, file_path, object_key):
        """上传文件到 OBS"""
        try:
            resp = self.obs_client.putFile(
                bucketName=self.bucketName,
                objectKey=object_key,
                file_path=file_path
            )
            if resp.status < 300:
                signed_url = self.obs_client.createSignedUrl(
                    method='GET',
                    bucketName=self.bucketName,
                    objectKey=object_key,
                    expires=8640000
                )
                file_url = signed_url["signedUrl"]
                if self.endpoint:
                    parsed_url = urlparse(file_url)
                    file_url = file_url.replace(
                        f"{parsed_url.scheme}://{parsed_url.netloc}",
                        self.endpoint
                    )
                return {"code": 200, "fileUrl": file_url, "message": "上传成功"}
            else:
                return {
                    "code": resp.errorCode,
                    "fileUrl": None,
                    "file_path": file_path,
                    "message": resp.errorMessage
                }
        except Exception as e:
            print(f'OBS 上传异常: {e}')
            return None


class AiyunOBSHelper:
    """阿里云 OSS 工具类"""
    
    def __init__(self, access_key_id, access_key_secret, bucket_name='', endpoint=''):
        self.endpoint = endpoint if endpoint.startswith('http') else f'https://{endpoint}'
        self.bucket_name = bucket_name
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret
        self.auth = oss2.Auth(self.access_key_id, self.access_key_secret)
        self.bucket = oss2.Bucket(self.auth, self.endpoint, self.bucket_name)

    def upload_file(self, local_file_path, object_key=''):
        """上传文件（公有读）"""
        local_file_path = local_file_path.replace("\\", '/')
        object_name = object_key if object_key else local_file_path.split('/')[-1]
        try:
            self.bucket.put_object_from_file(object_name, local_file_path)
            url = f"https://{self.bucket_name}.{self.endpoint.replace('https://', '').replace('http://', '')}/{object_name}"
            return url
        except Exception as e:
            print(f"上传失败: {e}")
            return None

    def upload_file_with_expire(self, local_file_path, period_of_validity=86400*180):
        """上传文件（私有，带签名URL）"""
        local_file_path = local_file_path.replace("\\", '/')
        object_name = 'meta/ads/' + local_file_path.split('/')[-1]
        try:
            self.bucket.put_object_from_file(object_name, local_file_path)
            url = self.bucket.sign_url('GET', object_name, period_of_validity)
            return url
        except Exception as e:
            print(f"上传或签名失败: {e}")
            return None

    def get_temp_url_by_key(self, object_key, period_of_validity=86400*180):
        """获取临时访问URL"""
        try:
            return self.bucket.sign_url('GET', object_key, period_of_validity)
        except Exception as e:
            print(f"获取临时链接失败: {e}")
            return None

    def is_object_exist(self, object_key):
        """检查对象是否存在"""
        try:
            return self.bucket.object_exists(object_key)
        except Exception as e:
            print(f"判断对象是否存在失败: {e}")
            return False


class Mthread(Thread):
    """多线程任务执行器"""
    
    def __init__(self, q, functionObj):
        self.q = q
        self.functionObj = functionObj
        super(Mthread, self).__init__()
    
    def run(self):
        while not self.q.empty():
            arg = self.q.get()
            try:
                self.functionObj(arg)
            except BaseException as e:
                print(f"任务执行错误: {e}")
                print(f"错误类型: {type(e)}")
                traceback.print_exc()


class HologresClient:
    """Hologres 数据库客户端"""
    
    def __init__(self, host, port, dbname, user, password):
        self.conn = psycopg.connect(
            host=host,
            port=port,
            dbname=dbname,
            user=user,
            password=password,
            keepalives=1,
            keepalives_idle=10,
            keepalives_interval=10,
            keepalives_count=5
        )
    
    def execute_sql_query(self, sql: str):
        """执行 SQL 查询"""
        cur = self.conn.cursor()
        cur.execute(sql)
        if "select" in sql.lower():
            result = cur.fetchall()
        else:
            self.conn.commit()
            result = 0
        cur.close()
        return result
    
    def batch_update(self, table_name: str, data_list: List[dict], key_column: str):
        """批量更新数据"""
        if not data_list:
            return 0
        cur = self.conn.cursor()
        updated_rows = 0
        try:
            for data in data_list:
                if key_column not in data:
                    continue
                set_clause = ", ".join([f"{k} = %s" for k in data.keys() if k != key_column])
                values = [data[k] for k in data.keys() if k != key_column]
                values.append(data[key_column])
                sql = f"UPDATE {table_name} SET {set_clause} WHERE {key_column} = %s"
                cur.execute(sql, values)
                updated_rows += cur.rowcount
            self.conn.commit()
        except Exception as e:
            self.conn.rollback()
            print(f"批量更新失败: {e}")
            raise e
        finally:
            cur.close()
        return updated_rows

    def batch_insert(self, table_name: str, data_list: List[dict], CONFLICT_COLUMN: str = ""):
        """批量插入数据"""
        if not data_list:
            return 0
        cur = self.conn.cursor()
        inserted_rows = 0
        try:
            for data in data_list:
                if not data:
                    continue
                columns = ", ".join(data.keys())
                placeholders = ", ".join(["%s"] * len(data))
                values = list(data.values())
                if CONFLICT_COLUMN:
                    conflict_cols = ",".join([col.strip() for col in CONFLICT_COLUMN.split(",") if col.strip()])
                    sql = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders}) ON CONFLICT ({conflict_cols}) DO NOTHING"
                else:
                    sql = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
                cur.execute(sql, values)
                inserted_rows += cur.rowcount
            self.conn.commit()
        except Exception as e:
            self.conn.rollback()
            print(f"批量插入失败: {e}")
            raise e
        finally:
            cur.close()
        return inserted_rows


class FileOperations:
    """文件操作工具"""
    
    def __init__(self):
        pass

    def move_local_file(self, imgpath):
        """删除本地文件"""
        if os.path.exists(imgpath):
            os.remove(imgpath)

    def download_img(self, imgurl, ip=None, save_path=None, keyid=None):
        """下载图片"""
        try:
            if not save_path:
                script_dir = os.path.dirname(os.path.abspath(__file__))
                image_save_dir = os.path.join(script_dir, 'imageSave')
                img_hash = hashlib.md5(imgurl.encode('utf-8')).hexdigest()
                save_path = os.path.join(image_save_dir, f"{img_hash}.jpg")
            
            if ip:
                proxies = {"http": f"http://{ip}", "https": f"http://{ip}"}
                response = requests.get(imgurl, proxies=proxies, timeout=30)
            else:
                response = requests.get(imgurl, timeout=30)
            response.raise_for_status()
            
            save_dir = os.path.dirname(save_path)
            if save_dir and not os.path.exists(save_dir):
                os.makedirs(save_dir)
            
            with open(save_path, 'wb') as f:
                f.write(response.content)
            
            if os.path.exists(save_path) and os.path.getsize(save_path) > 0:
                return save_path, keyid
            return None
        except Exception as e:
            print(f"下载图片失败: {e}")
            return None


class videoOperations:
    """视频操作工具"""
    
    def __init__(self):
        pass

    def get_video_info(self, url: str, verbose: bool = False, ip=""):
        """使用 yt_dlp 提取视频信息"""
        ydl_opts = {
            'quiet': True,
            'no_warnings': True,
            'extract_flat': False,
            'ignoreerrors': True,
            'logger': logging.getLogger('yt_dlp'),
        }
        if ip:
            ydl_opts['proxy'] = ip
        
        logger = logging.getLogger('yt_dlp')
        logger.setLevel(logging.CRITICAL)
        logger.disabled = True
        
        if verbose:
            logger.disabled = False
            logger.setLevel(logging.INFO)
            ydl_opts['quiet'] = False
            ydl_opts['no_warnings'] = False
        
        old_stderr = sys.stderr
        stderr_redirected = False
        
        try:
            if not verbose:
                sys.stderr = StringIO()
                stderr_redirected = True
            
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                if info is None:
                    return None
                
                video_info = {
                    'title': info.get('title', ''),
                    'description': info.get('description', ''),
                    'duration': info.get('duration', 0),
                    'uploader': info.get('uploader', ''),
                    'uploader_id': info.get('uploader_id', ''),
                    'upload_date': info.get('upload_date', ''),
                    'view_count': info.get('view_count', 0),
                    'like_count': info.get('like_count', 0),
                    'url': info.get('webpage_url', url),
                    'thumbnail': info.get('thumbnail', ''),
                    'formats': []
                }
                
                if 'formats' in info:
                    for fmt in info['formats']:
                        video_info['formats'].append({
                            'format_id': fmt.get('format_id', ''),
                            'ext': fmt.get('ext', ''),
                            'resolution': fmt.get('resolution', ''),
                            'filesize': fmt.get('filesize', 0),
                            'fps': fmt.get('fps', 0),
                            'vcodec': fmt.get('vcodec', 'none'),
                            'acodec': fmt.get('acodec', 'none'),
                            'url': fmt.get('url', '')
                        })
                
                if not video_info['formats'] and 'url' in info:
                    video_info['direct_url'] = info.get('url', '')
                
                return video_info
        except Exception:
            return None
        finally:
            if stderr_redirected:
                sys.stderr = old_stderr
            logger.disabled = False

    def get_best_mp4_url(self, S):
        """获取最佳 MP4 视频 URL"""
        formats = S.get("formats", [])
        
        for fmt in formats:
            if "hd" in str(fmt.get("format_id", "")).lower() and fmt.get("url"):
                return fmt["url"]
        
        for fmt in formats:
            if "sd" in str(fmt.get("format_id", "")).lower() and fmt.get("url"):
                return fmt["url"]
        
        for fmt in formats:
            if fmt.get("ext") == "mp4" and fmt.get("url"):
                return fmt["url"]
        
        return ""


class KafkaHelper:
    """Kafka 工具类"""
    
    def __init__(self, kafka_server=None):
        try:
            self.producer = KafkaProducer(
                bootstrap_servers=kafka_server,
                value_serializer=lambda v: json.dumps(v).encode('utf-8')
            )
        except Exception:
            print("Kafka 连接失败")
            self.producer = None
    
    def sendToKafka(self, data, topic_name=''):
        """发送单条消息"""
        self.producer.send(topic_name, value=data)
        self.producer.flush()

    def sendBatchToKafka(self, data_list, topic_name=''):
        """批量发送消息"""
        if self.producer is None:
            print("Kafka 连接失败，无法推送")
            return
        for data in data_list:
            self.producer.send(topic_name, value=data)
        self.producer.flush()


class Crawl:
    """爬虫请求工具"""
    
    def __init__(self, procoder=""):
        self.crawlTarget = procoder
    
    def crawl(
        self,
        url,
        PostData='',
        Method='GET',
        Cookie='',
        json_data={},
        params={},
        encoding='utf8',
        _gzip=True,
        headers={},
        _maxtimes=5,
        _timeout=15
    ):
        """发起 HTTP 请求"""
        if _gzip:
            headers['Accept-encoding'] = 'gzip'
        
        times = 0
        while times < _maxtimes:
            try:
                if len(proxyList) > 0:
                    ip = random.choice(proxyList)
                    proxies = {"http": f"http://{ip}", "https": f"http://{ip}"}
                    
                    if Method == "GET":
                        if params:
                            data = requests.get(url, headers=headers, params=params, cookies=Cookie, proxies=proxies, timeout=_timeout, verify=False)
                        else:
                            data = requests.get(url, headers=headers, cookies=Cookie, proxies=proxies, timeout=_timeout, verify=False)
                    else:
                        if json_data:
                            data = requests.post(url, json=json_data, headers=headers, cookies=Cookie, verify=False, timeout=_timeout, proxies=proxies)
                        else:
                            data = requests.post(url, data=PostData, headers=headers, cookies=Cookie, verify=False, timeout=_timeout, proxies=proxies)
                else:
                    if Method == "GET":
                        if params:
                            data = requests.get(url, headers=headers, params=params, cookies=Cookie, timeout=_timeout, verify=False)
                        else:
                            data = requests.get(url, headers=headers, cookies=Cookie, timeout=_timeout, verify=False)
                    else:
                        if json_data:
                            data = requests.post(url, json=json_data, cookies=Cookie, headers=headers, verify=False, timeout=_timeout)
                        else:
                            data = requests.post(url, data=PostData, cookies=Cookie, headers=headers, verify=False, timeout=_timeout)
                
                data.encoding = encoding
                html = data.text
                
                if _gzip:
                    try:
                        html = gzip.decompress(html)
                    except Exception:
                        pass
                
                return {'url': url, 'html': html, 'crawltime': datetime.now()}
            except Exception as e:
                times += 1
                if times >= _maxtimes:
                    print(f'抓取 {url} 失败: {e}')
        
        return {'url': url, 'html': None, 'ctime': datetime.now()}

    def Download(self, url, filename):
        """下载文件"""
        try:
            urllib.request.urlretrieve(url, filename)
            return True
        except Exception as e:
            print(f'下载 {url} 出现错误: {e}')
            return False

    def download_image_upload_ods(self, url, imgpath):
        """下载图片"""
        try:
            os.makedirs(os.path.dirname(imgpath), exist_ok=True)
            if len(proxyList) > 0:
                ip = random.choice(proxyList)
                proxies = {"http": f"http://{ip}", "https": f"http://{ip}"}
                response = requests.get(url, verify=False, timeout=30, proxies=proxies)
            else:
                response = requests.get(url, verify=False, timeout=30)
            response.raise_for_status()
            with open(imgpath, 'wb') as f:
                f.write(response.content)
            return True
        except Exception as e:
            print(f"下载图片失败: {e}")
            return False

