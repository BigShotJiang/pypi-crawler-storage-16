pub use spikard_core::bindings::response::*;
