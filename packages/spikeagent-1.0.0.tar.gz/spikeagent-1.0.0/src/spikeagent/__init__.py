"""SpikeAgent - AI-powered assistant for spike sorting and neural data analysis."""

__version__ = "1.0.0"

