"""SpikeAgent App - Main application functionality."""

