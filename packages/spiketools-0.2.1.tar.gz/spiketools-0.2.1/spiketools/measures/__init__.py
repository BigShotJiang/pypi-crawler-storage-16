"""Functions for computing measures on various data types / organizations."""
