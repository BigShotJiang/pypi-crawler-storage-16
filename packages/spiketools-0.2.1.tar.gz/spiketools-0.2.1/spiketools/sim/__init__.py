"""Simulations."""

from .times import sim_spiketimes
from .train import sim_spiketrain
from .trials import sim_trials
