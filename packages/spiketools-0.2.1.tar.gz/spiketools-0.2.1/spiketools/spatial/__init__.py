"""Analyses and utilities related to spatial data."""
