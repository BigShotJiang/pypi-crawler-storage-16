"""Statistics related functions and utilities."""
