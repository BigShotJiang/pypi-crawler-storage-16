"""Utility functions."""

from .random import set_random_seed
