#!/usr/bin/python3
# coding=utf-8
##################################################################
#              ____     _     _ __  __                 
#             / __/__  (_)___(_) /_/ /  ___  ___  ___ _
#            _\ \/ _ \/ / __/ / __/ /__/ _ \/ _ \/ _ `/
#           /___/ .__/_/_/ /_/\__/____/\___/_//_/\_, / 
#              /_/                              /___/  
# 
# Copyright (c) 2025 Chongqing Spiritlong Technology Co., Ltd.
# All rights reserved.
# @author	arthuryang
# @brief	从参考目录生成py文件
##################################################################

import	os
import	SpiritLong_utility

def generate_generator_file(filename, path):
	pass

# 脚本执行
if __name__ == '__main__':
	# 给文件增加版权说明
	SpiritLong_utility.copyright(__file__, author='arthuryang')
