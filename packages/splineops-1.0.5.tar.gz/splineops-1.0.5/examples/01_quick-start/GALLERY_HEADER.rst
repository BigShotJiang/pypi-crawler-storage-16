.. splineops/examples/01_quick-start/GALLERY_HEADER.rst

Quick-start
===========

Examples showing the basic functionality of the Spline interpolation module.
