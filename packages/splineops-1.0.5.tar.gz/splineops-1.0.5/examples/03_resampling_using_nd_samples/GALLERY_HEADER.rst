.. splineops/examples/03_resampling_using_nd_samples/GALLERY_HEADER.rst

Resampling using ND Samples
===========================

Examples using the Spline Interpolation and Resize modules on multidimensional samples, specially 1D and 2D.