.. splineops/examples/05_adaptive_regression_splines/GALLERY_HEADER.rst

Adaptive Regression Splines Examples
====================================

Examples using the Adaptive regression splines module.