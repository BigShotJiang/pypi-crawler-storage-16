.. splineops/examples/08_multiscale/GALLERY_HEADER.rst

Multiscale Examples
===================

Examples using the Multiscale module.