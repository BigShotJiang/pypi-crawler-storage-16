.. splineops/examples/01_spline_interpolation/GALLERY_HEADER.rst

Spline Interpolation Examples
=============================

Examples showing the basic functionality of the Spline interpolation module.
We also show the equivalence with Resize module methods where relevant.
