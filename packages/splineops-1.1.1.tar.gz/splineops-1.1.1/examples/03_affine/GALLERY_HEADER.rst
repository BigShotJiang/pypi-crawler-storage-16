.. splineops/examples/03_affine/GALLERY_HEADER.rst

Affine Examples
===============

Examples using the Affine module for data rotation transformations.