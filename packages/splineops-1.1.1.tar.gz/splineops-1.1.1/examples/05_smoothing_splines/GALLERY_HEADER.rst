.. splineops/examples/05_smoothing_splines/GALLERY_HEADER.rst

Smoothing Splines Examples
==========================

Examples using the Smoothing splines module.