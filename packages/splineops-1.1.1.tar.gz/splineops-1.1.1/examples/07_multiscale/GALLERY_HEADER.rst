.. splineops/examples/07_multiscale/GALLERY_HEADER.rst

Multiscale Examples
===================

Examples using the Multiscale module.