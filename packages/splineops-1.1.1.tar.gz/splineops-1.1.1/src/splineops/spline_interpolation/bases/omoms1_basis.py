# splineops/src/splineops/spline_interpolation/bases/omoms1_basis.py

from .bspline1_basis import BSpline1Basis

OMOMS1Basis = BSpline1Basis
