# SPONGE CLI

A modern terminal user interface (TUI) for SPONGE molecular dynamics simulations, built with [Textual](https://textual.textualize.io/).

## Features

- **Real-time Monitoring**: Monitor CPU, memory, GPU, and VRAM usage with live charts
- **Simulation Data Tracking**: Track potential energy, temperature, and pressure from MD simulations
- **Interactive UI**: Easy-to-use terminal interface with configurable paths and parameters
- **Dynamic Chart Visualization**: Plotext-based line charts for data visualization
- **SPONGE Integration**: Direct support for running SPONGE simulations with custom parameters

## Installation

Install from PyPI:

```bash
pip install sponge-cli
```

### Requirements

- Python >= 3.8
- textual >= 0.12.0
- rich >= 13.0.0
- psutil >= 5.8.0
- plotext >= 5.0.0

### Optional Dependencies

For development:

```bash
pip install sponge-cli[dev]
```

## Usage

Start the SPONGE CLI:

```bash
sponge-cli
```

Or from Python:

```python
from sponge_cli import SpongeCLI

app = SpongeCLI()
app.run()
```

## Configuration

In the CLI interface, you can configure:

1. **SPONGE Executable Path**: Set the path to your SPONGE binary
2. **Output File Path Prefix**: Specify where to save simulation outputs
3. **Simulation Parameters**: Add custom SPONGE parameters

## Features

### Monitoring Panel (Right Side)
- **CPU**: CPU utilization percentage with trend
- **Memory**: RAM usage percentage with trend
- **GPU**: GPU utilization percentage (if nvidia-smi available)
- **VRAM**: GPU memory usage percentage (if nvidia-smi available)

### Simulation Tracking (Bottom)
- **Potential**: Total potential energy trends
- **Temperature**: Temperature evolution
- **Pressure**: Pressure changes

### Controls
- Run SPONGE simulations with custom parameters
- Real-time viewing of simulation output
- Monitor resource usage during simulations

## Requirements for SPONGE

- SPONGE executable binary (MD.x or SPONGE.exe)
- Input files: mdin.txt, mdinfo.txt, etc.
- Output file: mdout.txt (or custom prefix with .out extension)

## License

MIT License - See LICENSE file for details

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Support

For issues and questions, please use the [GitHub Issues](https://github.com/yourusername/sponge-cli/issues) page.

## Changelog

### v0.1.0
- Initial release
- Basic TUI with monitoring panels
- SPONGE simulation support
- Real-time data visualization
