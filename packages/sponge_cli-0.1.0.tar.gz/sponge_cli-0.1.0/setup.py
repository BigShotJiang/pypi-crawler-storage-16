from setuptools import setup, find_packages

# Note: Project metadata is defined in pyproject.toml
# This setup.py is kept for backwards compatibility
setup(
    packages=find_packages(),
)
