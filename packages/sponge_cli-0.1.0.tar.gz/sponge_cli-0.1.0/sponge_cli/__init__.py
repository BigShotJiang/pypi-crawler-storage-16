"""SPONGE CLI - A terminal user interface for SPONGE molecular dynamics simulations"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"
__description__ = "A Textual-based TUI for monitoring and running SPONGE MD simulations with real-time visualization"

from .main import SpongeCLI, main

__all__ = ["SpongeCLI", "main"]
