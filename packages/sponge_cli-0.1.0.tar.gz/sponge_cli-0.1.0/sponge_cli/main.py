from textual.app import App, ComposeResult
from textual.widgets import Header, Footer, Input, Button, Static, Log, Label
from textual.containers import Horizontal, Vertical, Container, VerticalScroll
from rich.text import Text
import subprocess, threading, time, re, os, sys
import psutil
from collections import deque

try:
    import plotext as plt
    PLOTEXT_AVAILABLE = True
except ImportError:
    plt = None
    PLOTEXT_AVAILABLE = False


# ========== 你的 SPONGE 可执行路径 ==========
SPONGE_EXEC = r".\SPONGE\bin\SPONGE.exe" if sys.platform == "win32" else "./bin/SPONGE"
MDOUT_FILE = "./mdout.txt"       # mdout 输出文件路径
# ==========================================


class SpongeCLI(App):
    CSS = """
    #left {
        width: 30%;
        border: solid gray;
        padding: 1;
        overflow: auto;
    }
    #middle {
        width: 50%;
        border: solid gray;
        overflow: auto;
    }
    #right_monitor {
        width: 20%;
        border: solid gray;
        padding: 0 1;
        height: 100%;
        overflow: auto;
        scrollbar-size: 1 2;
    }
    #top_section {
        height: 65%;
        overflow: auto;
    }
    #bottom_section {
        height: 35%;
        border: solid blue;
        padding: 1;
        overflow: auto;
        scrollbar-size: 1 2;
    }
    #log {
        height: 85%;
        overflow: auto;
    }
    .monitor-title {
        text-align: center;
        background: $panel;
        margin: 0 0 0 0;
        padding: 0;
        text-style: bold;
        height: 1;
    }
    .monitor-section {
        height: auto;
        margin: 0 0 1 0;
        padding: 0;
    }
    .monitor-value {
        text-align: center;
        color: $success;
        text-style: bold;
        height: 1;
    .chart {
        height: 12;
        margin: 0 0 1 0;
        padding: 0 1;
        overflow: auto;
        text-align: left;
    }
    .sim-chart {
        height: 20;
        margin: 0;
        padding: 0 1;
        overflow: auto;
        text-align: left;
    }   text-align: left;
    }
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # SPONGE 可执行文件路径
        self.sponge_exec_path = SPONGE_EXEC
        self.current_mdout_file = MDOUT_FILE  # 当前的 mdout 文件路径
        
        # 保存历史数据用于绘制折线图
        self.cpu_history = deque([0] * 50, maxlen=50)
        self.mem_history = deque([0] * 50, maxlen=50)
        self.gpu_history = deque([0] * 50, maxlen=50)
        self.vram_history = deque([0] * 50, maxlen=50)
        
        # 保存模拟数据
        self.step_history = deque(maxlen=100)
        self.potential_history = deque(maxlen=100)
        self.temperature_history = deque(maxlen=100)
        self.pressure_history = deque(maxlen=100)
        self.mdout_last_pos = 0  # 记录上次读取的文件位置
        self.monitor_chart_size = (32, 10)  # 监控图表分辨率
        self.sim_chart_size = (60, 14)  # 模拟数据图表分辨率
        self.chart_fallback_text = "安装 plotext 查看折线图: pip install plotext"
        
        # 控制折线图更新
        self.sponge_running = False  # SPONGE是否正在运行
        self.sim_update_handle = None  # 模拟数据更新的定时器句柄

    def compose(self) -> ComposeResult:
        yield Header(name="SPONGE CLI")
        
        with Vertical():
            # 上半部分：原有的三栏布局
            with Horizontal(id="top_section"):
                # 左侧菜单
                with Vertical(id="left"):
                    yield Static(" SPONGE 控制面板", classes="monitor-title")
                    yield Static("")
                    yield Static("SPONGE可执行文件路径")
                    yield Input(placeholder="SPONGE 路径", id="sponge_path", value=SPONGE_EXEC)
                    yield Static("")
                    yield Static("输出文件路径前缀")
                    yield Input(placeholder="输出路径 (可选)", id="output_path")
                    yield Static("")
                    yield Button("▶ 运行 SPONGE", id="run")
                
                # 中间运行日志区
                with Vertical(id="middle"):
                    yield Log(id="log", highlight=True)
                    yield Input(placeholder="输入参数: 如 -mdin mdin.txt", id="params")
                
                # 右侧资源监控区（可滚动）
                with Vertical(id="right_monitor"):
                    yield Static(" 资源监控", classes="monitor-title")
                    
                    # CPU 监控
                    with Container(classes="monitor-section"):
                        yield Static("CPU", classes="monitor-title")
                        yield Label("0.0%", id="cpu_value", classes="monitor-value")
                        yield Static("等待数据...", id="cpu_chart", classes="chart", markup=False)
                    
                    # 内存监控
                    with Container(classes="monitor-section"):
                        yield Static("内存", classes="monitor-title")
                        yield Label("0.0%", id="mem_value", classes="monitor-value")
                        yield Static("等待数据...", id="mem_chart", classes="chart", markup=False)
                    
                    # GPU 监控
                    with Container(classes="monitor-section"):
                        yield Static("GPU", classes="monitor-title")
                        yield Label("0.0%", id="gpu_value", classes="monitor-value")
                        yield Static("等待数据...", id="gpu_chart", classes="chart", markup=False)
                    
                    # 显存监控
                    with Container(classes="monitor-section"):
                        yield Static("显存", classes="monitor-title")
                        yield Label("0.0%", id="vram_value", classes="monitor-value")
                        yield Static("等待数据...", id="vram_chart", classes="chart", markup=False)
            
            # 下半部分：模拟数据实时监控
            with Vertical(id="bottom_section"):
                with Horizontal():
                    # 势能图
                    with Vertical():
                        yield Static("势能 (Potential)", classes="monitor-title")
                        yield Label("N/A", id="potential_value", classes="monitor-value")
                        yield Static("等待数据...", id="potential_chart", classes="sim-chart", markup=False)
                        yield Static("")  # 空栏位激活滚动条
                    
                    # 温度图
                    with Vertical():
                        yield Static("温度 (Temperature)", classes="monitor-title")
                        yield Label("N/A", id="temperature_value", classes="monitor-value")
                        yield Static("等待数据...", id="temperature_chart", classes="sim-chart", markup=False)
                        yield Static("")  # 空栏位激活滚动条
                    
                    # 压强图
                    with Vertical():
                        yield Static("压强 (Pressure)", classes="monitor-title")
                        yield Label("N/A", id="pressure_value", classes="monitor-value")
                        yield Static("等待数据...", id="pressure_chart", classes="sim-chart", markup=False)
                        yield Static("")  # 空栏位激活滚动条

        yield Footer()

    def on_mount(self) -> None:
        """启动时开始监控资源"""
        # 只监控系统资源，不监控模拟数据
        self.set_interval(1, self.update_monitor)
        self.col_positions = []  # 存储每列的起始位置
        self.col_names = []  # 存储列名
        if not PLOTEXT_AVAILABLE:
            for chart_id in ["cpu_chart", "mem_chart", "gpu_chart", "vram_chart", "potential_chart", "temperature_chart", "pressure_chart"]:
                chart_widget = self.query_one(f"#{chart_id}", Static)
                chart_widget.update(self.chart_fallback_text)

    def render_plotext_chart(self, data, title: str, width: int, height: int, x_labels=None) -> str:
        """用 plotext 渲染折线图，返回文本图形。data 可以是数值列表或 (x, y) 数据。"""
        if not data or len(data) == 0:
            return "等待数据..."
        if not PLOTEXT_AVAILABLE:
            return self.chart_fallback_text
        try:
            if hasattr(plt, "clear_plot"):
                plt.clear_plot()
            elif hasattr(plt, "clear_figure"):
                plt.clear_figure()
            elif hasattr(plt, "clf"):
                plt.clf()
            
            # 设置图表大小以提高分辨率
            if hasattr(plt, "plot_size"):
                plt.plot_size(width, height)
            elif hasattr(plt, "plotsize"):
                plt.plotsize(width, height)
            
            # 绘制线图
            if x_labels:
                # 使用自定义 X 标签（step）
                x_data = list(range(len(data)))
                y_data = list(data)
            else:
                x_data = list(range(len(data)))
                y_data = list(data)
            
            # 使用 plot 绘制，marker 参数设为 'fhd' 获得更高分辨率
            plt.plot(x_data, y_data, marker='fhd')
            
            # 设置标题
            if hasattr(plt, "title"):
                plt.title(title)
            
            # 设置网格
            if hasattr(plt, "grid"):
                plt.grid(True, True)
            
            # 设置 X 轴范围
            if hasattr(plt, "xlim") and len(data) > 1:
                plt.xlim(0, len(data) - 1)
            
            # 如果有 step 标签，设置 X 轴标签
            if x_labels and hasattr(plt, "xticks"):
                try:
                    # 显示部分标签以避免拥挤
                    step_interval = max(1, len(x_labels) // 5)
                    tick_positions = [i for i in range(0, len(x_labels), step_interval)]
                    tick_labels = [str(x_labels[i]) for i in tick_positions]
                    plt.xticks(tick_positions, tick_labels)
                except:
                    pass
            
            # 启用 Y 轴自动缩放以显示更多细节
            if hasattr(plt, "yscale"):
                try:
                    plt.yscale('linear')
                except:
                    pass
            
            # 构建图表，处理编码问题
            if hasattr(plt, "build"):
                chart_output = plt.build()
                return chart_output
            return "plotext 版本过旧，缺少 build()"
        except UnicodeEncodeError:
            # Windows GBK 编码问题 - 尝试简化图表
            try:
                plt.clf()
                plt.plot_size(width, height)
                plt.plot(x_data, y_data)
                if hasattr(plt, "title"):
                    plt.title(title)
                return plt.build()
            except:
                return "图表编码错误，请检查 Windows 区域设置"
        except Exception as exc:
            return f"plotext 绘制失败: {exc}"

    def update_chart_widget(self, widget_id: str, data, title: str, size: tuple[int, int], x_labels=None) -> None:
        """更新指定 Static 的图表文本。"""
        width, height = size
        chart_text = self.render_plotext_chart(list(data), title, width, height, x_labels)
        chart_widget = self.query_one(f"#{widget_id}", Static)
        chart_widget.update(Text.from_ansi(chart_text))
    
    def update_simulation_data(self) -> None:
        """从 mdout.txt 读取并更新模拟数据"""
        if not os.path.exists(self.current_mdout_file):
            return
        
        try:
            with open(self.current_mdout_file, 'r') as f:
                # 从上次读取的位置继续读取
                f.seek(self.mdout_last_pos)
                new_lines = f.readlines()
                self.mdout_last_pos = f.tell()
                
                for line in new_lines:
                    if not line.strip() or '---' in line:
                        continue
                    
                    # 解析表头（第一次遇到，包含 "step" 关键字）
                    if not self.col_names:
                        if 'step' in line.lower():
                            # 找出每列的起始位置
                            col_starts = []
                            in_word = False
                            for i, c in enumerate(line):
                                if c != ' ' and not in_word:
                                    col_starts.append(i)
                                    in_word = True
                                elif c == ' ' and in_word:
                                    in_word = False
                            
                            # 提取列名
                            for i in range(len(col_starts)):
                                start = col_starts[i]
                                end = col_starts[i+1] if i+1 < len(col_starts) else len(line)
                                col_name = line[start:end].strip().lower()
                                self.col_names.append(col_name)
                            
                            self.col_positions = col_starts
                            continue
                    
                    # 解析数据行（必须已有表头）
                    if self.col_names and self.col_positions:
                        # 用正则表达式提取所有数值
                        numbers = re.findall(r'-?\d+\.?\d*', line)
                        
                        # 根据列名找到 step, temperature, potential 和 pressure 的索引
                        step_idx = None
                        temp_idx = None
                        pot_idx = None
                        press_idx = None
                        
                        for i, col_name in enumerate(self.col_names):
                            if 'step' in col_name:
                                step_idx = i
                            elif 'temperature' in col_name:
                                temp_idx = i
                            elif 'potential' in col_name:
                                pot_idx = i
                            elif 'pressure' in col_name:
                                press_idx = i
                        
                        # 提取 step 值
                        step_value = None
                        if step_idx is not None and step_idx < len(numbers):
                            try:
                                step_value = int(float(numbers[step_idx]))
                                self.step_history.append(step_value)
                            except (ValueError, IndexError):
                                pass
                        
                        # 提取温度和势能
                        if temp_idx is not None and temp_idx < len(numbers):
                            try:
                                temp_value = float(numbers[temp_idx])
                                self.temperature_history.append(temp_value)
                                temperature_value = self.query_one("#temperature_value", Label)
                                temperature_value.update(f"{temp_value:.1f} K")
                                self.update_chart_widget(
                                    "temperature_chart",
                                    self.temperature_history,
                                    "Temperature",
                                    self.sim_chart_size,
                                    list(self.step_history),
                                )
                            except (ValueError, IndexError):
                                pass
                        
                        if pot_idx is not None and pot_idx < len(numbers):
                            try:
                                pot_value = float(numbers[pot_idx])
                                self.potential_history.append(pot_value)
                                potential_value = self.query_one("#potential_value", Label)
                                potential_value.update(f"{pot_value:.1f}")
                                self.update_chart_widget(
                                    "potential_chart",
                                    self.potential_history,
                                    "Potential",
                                    self.sim_chart_size,
                                    list(self.step_history),
                                )
                            except (ValueError, IndexError):
                                pass
                        
                        if press_idx is not None and press_idx < len(numbers):
                            try:
                                press_value = float(numbers[press_idx])
                                self.pressure_history.append(press_value)
                                pressure_value = self.query_one("#pressure_value", Label)
                                pressure_value.update(f"{press_value:.1f}")
                                self.update_chart_widget(
                                    "pressure_chart",
                                    self.pressure_history,
                                    "Pressure",
                                    self.sim_chart_size,
                                    list(self.step_history),
                                )
                            except (ValueError, IndexError):
                                pass
                        
        except Exception as e:
            pass
    
    def update_monitor(self) -> None:
        """更新资源监控信息"""
        try:
            # CPU 使用率
            cpu_percent = psutil.cpu_percent(interval=0.1)
            self.cpu_history.append(cpu_percent)
            
            cpu_value = self.query_one("#cpu_value", Label)
            cpu_value.update(f"{cpu_percent:.1f}%")
            self.update_chart_widget("cpu_chart", self.cpu_history, "CPU %", self.monitor_chart_size)
            
            # 内存使用率
            mem = psutil.virtual_memory()
            self.mem_history.append(mem.percent)
            
            mem_value = self.query_one("#mem_value", Label)
            mem_value.update(f"{mem.percent:.1f}%")
            self.update_chart_widget("mem_chart", self.mem_history, "Memory %", self.monitor_chart_size)
            
            # GPU 使用率 (尝试使用 nvidia-smi)
            gpu_util = 0.0
            try:
                result = subprocess.run(
                    ["nvidia-smi", "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"],
                    capture_output=True, text=True, timeout=1
                )
                if result.returncode == 0:
                    gpu_util = float(result.stdout.strip())
            except (FileNotFoundError, subprocess.TimeoutExpired, ValueError):
                pass
            
            self.gpu_history.append(gpu_util)
            
            gpu_value = self.query_one("#gpu_value", Label)
            gpu_value.update(f"{gpu_util:.1f}%" if gpu_util > 0 else "N/A")
            self.update_chart_widget("gpu_chart", self.gpu_history, "GPU %", self.monitor_chart_size)
            
            # 显存使用率 (尝试使用 nvidia-smi)
            vram_util = 0.0
            try:
                result = subprocess.run(
                    ["nvidia-smi", "--query-gpu=memory.used,memory.total", "--format=csv,noheader,nounits"],
                    capture_output=True, text=True, timeout=1
                )
                if result.returncode == 0:
                    used, total = map(float, result.stdout.strip().split(','))
                    if total > 0:
                        vram_util = (used / total) * 100
            except (FileNotFoundError, subprocess.TimeoutExpired, ValueError):
                pass
            
            self.vram_history.append(vram_util)
            
            vram_value = self.query_one("#vram_value", Label)
            vram_value.update(f"{vram_util:.1f}%" if vram_util > 0 else "N/A")
            self.update_chart_widget("vram_chart", self.vram_history, "VRAM %", self.monitor_chart_size)
        except Exception as e:
            pass

    # 按键事件
    def on_button_pressed(self, event: Button.Pressed):
        if event.button.id == "run":
            self.run_sponge()

    # 执行 SPONGE
    def run_sponge(self):
        log = self.query_one("#log", Log)
        params = self.query_one("#params", Input).value.strip()
        
        # 从输入框获取 SPONGE 路径
        sponge_path_input = self.query_one("#sponge_path", Input)
        sponge_exec = sponge_path_input.value.strip()
        
        if not sponge_exec:
            sponge_exec = SPONGE_EXEC
            sponge_path_input.value = sponge_exec
        
        # 从输入框获取输出文件路径
        output_path_input = self.query_one("#output_path", Input)
        output_path = output_path_input.value.strip()
        
        # 动态设置 MDOUT_FILE
        if output_path:
            mdout_file = f"{output_path}.out"
            # 添加参数到命令中
            params = f"-default_out_file_prefix {output_path} {params}".strip()
        else:
            mdout_file = MDOUT_FILE
        
        # 检查可执行文件是否存在
        if not os.path.exists(sponge_exec):
            log.write_line("[red]错误:[/] 找不到 SPONGE 可执行文件")
            log.write_line(f"[red]路径: {os.path.abspath(sponge_exec)}[/]")
            return

        cmd = f"{sponge_exec} {params}" if params else sponge_exec
        log.write_line("[green]执行命令:[/] " + cmd)
        
        # 重置模拟数据和状态
        self.mdout_last_pos = 0
        self.sponge_running = True
        self.col_names = []
        self.col_positions = []
        self.current_mdout_file = mdout_file  # 保存当前的 MDOUT_FILE
        
        # 重置势能、温度和压强数据
        self.step_history.clear()
        self.potential_history.clear()
        self.temperature_history.clear()
        self.pressure_history.clear()
        
        # 清空图表显示
        potential_value = self.query_one("#potential_value", Label)
        potential_value.update("N/A")
        temperature_value = self.query_one("#temperature_value", Label)
        temperature_value.update("N/A")
        pressure_value = self.query_one("#pressure_value", Label)
        pressure_value.update("N/A")
        
        potential_chart = self.query_one("#potential_chart", Static)
        potential_chart.update("等待数据...")
        temperature_chart = self.query_one("#temperature_chart", Static)
        temperature_chart.update("等待数据...")
        pressure_chart = self.query_one("#pressure_chart", Static)
        pressure_chart.update("等待数据...")
        
        # 开始监控模拟数据
        if self.sim_update_handle:
            self.sim_update_handle.stop()
            self.sim_update_handle = None
        self.sim_update_handle = self.set_interval(0.5, self.update_simulation_data)

        def reader():
            try:
                proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                for line in proc.stdout:
                    log.write_line(line.rstrip())
            except Exception as e:
                log.write_line(f"[red]运行出错: {e}[/]")
            finally:
                # 程序运行结束后，最后读取一次mdout.txt
                self.sponge_running = False
                self.update_simulation_data()
                
                # 停止更新定时器
                if self.sim_update_handle:
                    self.sim_update_handle.stop()
                    self.sim_update_handle = None
                
                log.write_line("[yellow]SPONGE 运行完成[/]")

        threading.Thread(target=reader, daemon=True).start()


def main():
    """Entry point for the CLI"""
    app = SpongeCLI()
    app.run()


if __name__ == "__main__":
    main()
