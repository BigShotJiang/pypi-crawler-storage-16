#!/usr/bin/env python3
"""
版本更新辅助脚本

用法：
    python update_version.py 0.2.0
"""

import sys
import re
from pathlib import Path

def update_version(new_version):
    """更新所有版本号文件"""
    
    if not re.match(r'^\d+\.\d+\.\d+', new_version):
        print(f"错误：版本号格式不正确: {new_version}")
        print("正确格式: X.Y.Z (如 0.2.0)")
        return False
    
    base_dir = Path(__file__).parent / 'sponge_cli_pkg'
    files_to_update = [
        {
            'path': base_dir / 'setup.py',
            'pattern': r'version=[\'"][\d\.]+[\'"]',
            'replacement': f'version=\'{new_version}\''
        },
        {
            'path': base_dir / 'pyproject.toml',
            'pattern': r'version = "[^"]+"',
            'replacement': f'version = "{new_version}"'
        },
        {
            'path': base_dir / 'sponge_cli' / '__init__.py',
            'pattern': r'__version__ = [\'"][\d\.]+[\'"]',
            'replacement': f'__version__ = \'{new_version}\''
        },
    ]
    
    updated = []
    
    for file_info in files_to_update:
        path = file_info['path']
        
        if not path.exists():
            print(f"⚠️  文件不存在: {path}")
            continue
        
        try:
            content = path.read_text(encoding='utf-8')
            
            if re.search(file_info['pattern'], content):
                new_content = re.sub(
                    file_info['pattern'],
                    file_info['replacement'],
                    content
                )
                
                path.write_text(new_content, encoding='utf-8')
                print(f"✓ 已更新: {path.relative_to(Path.cwd())}")
                updated.append(str(path))
            else:
                print(f"⚠️  找不到版本字段: {path}")
        
        except Exception as e:
            print(f"✗ 错误更新 {path}: {e}")
            return False
    
    if updated:
        print(f"\n✓ 成功更新 {len(updated)} 个文件")
        print(f"新版本: {new_version}")
        return True
    else:
        return False

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    
    new_version = sys.argv[1]
    success = update_version(new_version)
    sys.exit(0 if success else 1)
