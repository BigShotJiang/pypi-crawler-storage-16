#!/usr/bin/env python3
"""Spork CLI entry point."""

from spork.cli import main

if __name__ == "__main__":
    main()
