#!/usr/bin/env python3
"""
Spritz CLI (spx) - Agent Management Tool
Installation: pip install -e .
"""

import click

# Import all commands
from src.commands.configure import configure
from src.commands.login import login
from src.commands.whoami import whoami
from src.commands.profiles import list_profiles, validate
from src.commands.agent import agent_onboarding, agent_update
from src.commands.organization import assign_agents


@click.group()
def cli():
    """Spritz CLI (spx) - Agent Management Tool"""
    pass


# Register all commands
cli.add_command(configure)
cli.add_command(login)
cli.add_command(whoami)
cli.add_command(list_profiles)
cli.add_command(validate)
cli.add_command(agent_onboarding)
cli.add_command(agent_update)
cli.add_command(assign_agents)


if __name__ == '__main__':
    cli()
