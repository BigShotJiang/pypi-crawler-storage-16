"""
Configure command - Set up Spritz CLI profiles
"""

import click
from ..config import SpritzConfig
from ..auth import authenticate_user
from ..constants import DEFAULT_SPRITZ_URL, DEFAULT_API_URL


@click.command()
@click.option('--profile', default='default', help='Profile name (default, dev, prod)')
def configure(profile):
    """Configure Spritz CLI with environment URLs"""
    click.echo(click.style("\n╔═══════════════════════════════════════════════════════════╗", fg='cyan', bold=True))
    click.echo(click.style("║              ⚙️  SPRITZ CONFIGURATION                     ║", fg='cyan', bold=True))
    click.echo(click.style("╚═══════════════════════════════════════════════════════════╝", fg='cyan', bold=True))
    
    click.echo(click.style(f"\n📋 Configuring profile: ", fg='cyan', bold=True) + click.style(profile, fg='magenta', bold=True))
    
    # Suggest URLs based on profile
    if profile == 'dev':
        default_spritz_url = 'https://app.dev.spritz.activate.bar'
        default_api_url = 'https://api.dev.spritz.activate.bar'
    elif profile == 'prod':
        default_spritz_url = 'https://spritz.activate.bar'
        default_api_url = 'https://api.spritz.activate.bar'
    else:
        default_spritz_url = DEFAULT_SPRITZ_URL
        default_api_url = DEFAULT_API_URL
    
    click.echo()
    spritz_url = click.prompt(click.style('🌐 Spritz Web URL', fg='cyan', bold=True), default=default_spritz_url)
    api_url = click.prompt(click.style('🔌 Spritz API URL', fg='cyan', bold=True), default=default_api_url)
    
    config = SpritzConfig()
    config.set_profile(profile, spritz_url, api_url)
    
    # Ask if user wants to login now
    if click.confirm(click.style('\n🔐 Do you want to login now?', fg='yellow', bold=True), default=True):
        try:
            authenticate_user(profile, spritz_url)
        except Exception as e:
            click.echo(click.style(f"❌ Authentication failed: {str(e)}", fg='red', bold=True), err=True)
