"""
Organization management commands
"""

import click
import sys
import requests
import math
from ..config import SpritzConfig
from ..utils import make_authenticated_request, load_agents_from_url


@click.command('assign-agents')
@click.option('--profile', default='default', help='Profile to use (default, dev, prod)')
@click.option('--url', required=True, help='URL to fetch agent configuration JSON')
def assign_agents(profile, url):
    """Assign agents to an organization.
    
    Steps:
    1. Fetch list of organizations from Spritz
    2. Display organizations in a multi-column layout
    3. Ask user to select an organization
    4. Fetch agent IDs from the provided URL
    5. Assign agents to the selected organization
    """
    config = SpritzConfig()
    try:
        profile_config = config.get_profile(profile)
    except click.ClickException as e:
        click.echo(click.style(f"❌ {str(e)}", fg='red', bold=True), err=True)
        sys.exit(1)

    spritz_url = profile_config['spritz_url']
    api_url = profile_config['api_url']

    click.echo(click.style("\n╔═══════════════════════════════════════════════════════════╗", fg='cyan', bold=True))
    click.echo(click.style("║           🏢 ASSIGN AGENTS TO ORGANIZATION                ║", fg='cyan', bold=True))
    click.echo(click.style("╚═══════════════════════════════════════════════════════════╝", fg='cyan', bold=True))
    click.echo(click.style(f"\n📋 Profile: ", fg='cyan', bold=True) + click.style(profile, fg='magenta', bold=True))
    click.echo(click.style(f"🌐 Spritz Web: ", fg='cyan') + click.style(spritz_url, fg='blue'))
    click.echo(click.style(f"🔌 Spritz API: ", fg='cyan') + click.style(api_url, fg='blue'))

    # Step 1: Fetch organizations
    click.echo(click.style("\n📥 Fetching organizations...", fg='cyan', bold=True))
    # Fetch all organizations with a high limit (per request: 999) and only fetch name/logo to keep output compact
    org_url = f"{api_url}/v1/organization?$limit=999&$skip=0&$sort=_id|-1&$select=profile"
    
    try:
        response = make_authenticated_request('GET', org_url, profile, profile_config, spritz_url)
        
        if response.status_code != 200:
            click.echo(click.style(f"❌ Failed to fetch organizations: HTTP {response.status_code}", fg='red', bold=True))
            click.echo(click.style(f"   Response: {response.text}", fg='red'))
            sys.exit(1)

        org_data = response.json()
        
        # Handle different response formats
        if isinstance(org_data, dict):
            if 'data' in org_data:
                data_field = org_data['data']
                if isinstance(data_field, dict) and 'docs' in data_field:
                    organizations = data_field['docs']
                elif isinstance(data_field, list):
                    organizations = data_field
                else:
                    organizations = [data_field]
            else:
                organizations = [org_data]
        elif isinstance(org_data, list):
            organizations = org_data
        else:
            click.echo(click.style("❌ Unexpected API response format", fg='red', bold=True))
            sys.exit(1)

        if not organizations or len(organizations) == 0:
            click.echo(click.style("❌ No organizations found", fg='red', bold=True))
            sys.exit(1)

        click.echo(click.style(f"✅ Found {len(organizations)} organization(s)", fg='green', bold=True))

    except Exception as e:
        click.echo(click.style(f"❌ Error fetching organizations: {str(e)}", fg='red', bold=True))
        sys.exit(1)

    # Step 2: Display organizations in multi-column layout
    click.echo(click.style("\n📋 Available Organizations:", fg='cyan', bold=True))
    click.echo(click.style("─" * 80, fg='cyan'))
    
    # Calculate layout: prefer 3-4 columns with up to 10 rows per column
    total_orgs = len(organizations)
    max_rows_per_column = 10
    # Keep at least 3 columns when we have more than one org (requested 3-4 columns)
    base_columns = 1 if total_orgs == 1 else 3
    num_columns = min(4, max(base_columns, math.ceil(total_orgs / max_rows_per_column)))
    rows_per_column = max(1, math.ceil(total_orgs / num_columns))
    
    # Create a grid layout
    for row in range(rows_per_column):
        row_items = []
        for col in range(num_columns):
            idx = col * rows_per_column + row
            if idx < total_orgs:
                org = organizations[idx]
                org_profile = org.get('profile', {}) or {}
                org_name = org_profile.get('name', 'Unnamed Organization')
                # Truncate long names to fit fixed width (35 chars)
                if len(org_name) > 35:
                    org_name = org_name[:32] + "..."
                
                # Format: [1] Org Name
                item = click.style(f"[{idx + 1:2d}] ", fg='yellow', bold=True) + \
                       click.style(f"{org_name:35s}", fg='magenta')
                row_items.append(item)
        
        if row_items:
            click.echo("  ".join(row_items))
    
    click.echo(click.style("─" * 80, fg='cyan'))

    # Step 3: Ask user to select organization
    click.echo()
    while True:
        try:
            selection = click.prompt(
                click.style("🔢 Enter organization number", fg='cyan', bold=True),
                type=int
            )
            
            if 1 <= selection <= len(organizations):
                selected_org = organizations[selection - 1]
                org_id = selected_org.get('_id') or selected_org.get('id')
                org_name = selected_org.get('profile', {}).get('name', 'Unnamed Organization')
                
                if not org_id:
                    click.echo(click.style("❌ Could not determine organization ID", fg='red', bold=True))
                    sys.exit(1)
                
                click.echo(click.style(f"\n✅ Selected: ", fg='green', bold=True) +
                          click.style(org_name, fg='magenta', bold=True))
                click.echo(click.style(f"   Organization ID: ", fg='cyan') +
                          click.style(org_id, fg='yellow', bold=True))
                break
            else:
                click.echo(click.style(f"❌ Please enter a number between 1 and {len(organizations)}", fg='red'))
        except (ValueError, click.Abort):
            click.echo(click.style("\n❌ Operation cancelled", fg='red', bold=True))
            sys.exit(1)

    # Step 4: Fetch agent IDs from URL
    click.echo(click.style("\n📥 Loading agent configuration...", fg='cyan', bold=True))
    click.echo(click.style(f"   Source: {url}", fg='blue'))

    try:
        agents_data = load_agents_from_url(url)
    except click.ClickException as e:
        click.echo(click.style(f"❌ Error loading agent config: {str(e)}", fg='red', bold=True), err=True)
        sys.exit(1)

    # Handle single agent or array
    if isinstance(agents_data, dict):
        agents_data = [agents_data]

    if not agents_data:
        click.echo(click.style("❌ No agent data found at the URL", fg='red', bold=True))
        sys.exit(1)

    click.echo(click.style(f"✅ Found {len(agents_data)} agent(s) in configuration", fg='green', bold=True))

    # Extract agent IDs by searching for each agent by URL
    agent_ids = []
    click.echo(click.style("\n🔍 Resolving agent IDs...", fg='cyan', bold=True))
    
    for idx, agent_config in enumerate(agents_data, 1):
        agent_url_field = agent_config.get('url')
        agent_name = agent_config.get('name', f'Agent {idx}')
        
        if not agent_url_field:
            click.echo(click.style(f"  ⚠️  [{idx}] {agent_name}: No 'url' field found, skipping", fg='yellow'))
            continue

        # Search for agent by URL
        search_url = f"{api_url}/v1/agent?url={agent_url_field}"
        
        try:
            search_response = make_authenticated_request('GET', search_url, profile, profile_config, spritz_url)
            
            if search_response.status_code != 200:
                click.echo(click.style(f"  ❌ [{idx}] {agent_name}: Failed to search (HTTP {search_response.status_code})", fg='red'))
                continue

            results = search_response.json()
            
            # Handle response format
            if isinstance(results, dict):
                if 'data' in results:
                    data_field = results['data']
                    if isinstance(data_field, dict) and 'docs' in data_field:
                        agents_list = data_field['docs']
                    elif isinstance(data_field, list):
                        agents_list = data_field
                    else:
                        agents_list = [data_field]
                else:
                    agents_list = [results]
            elif isinstance(results, list):
                agents_list = results
            else:
                click.echo(click.style(f"  ❌ [{idx}] {agent_name}: Unexpected response format", fg='red'))
                continue

            if not agents_list or len(agents_list) == 0:
                click.echo(click.style(f"  ⚠️  [{idx}] {agent_name}: Not found in Spritz", fg='yellow'))
                continue

            found_agent = agents_list[0]
            agent_id = found_agent.get('_id') or found_agent.get('id')
            
            if agent_id:
                agent_ids.append(agent_id)
                click.echo(click.style(f"  ✅ [{idx}] ", fg='green', bold=True) +
                          click.style(agent_name, fg='magenta', bold=True) +
                          click.style(f" → {agent_id}", fg='yellow'))
            else:
                click.echo(click.style(f"  ❌ [{idx}] {agent_name}: Could not extract ID", fg='red'))

        except Exception as e:
            click.echo(click.style(f"  ❌ [{idx}] {agent_name}: Error - {str(e)}", fg='red'))

    if not agent_ids:
        click.echo(click.style("\n❌ No valid agent IDs found. Cannot proceed with assignment.", fg='red', bold=True))
        sys.exit(1)

    click.echo(click.style(f"\n✅ Resolved {len(agent_ids)} agent ID(s)", fg='green', bold=True))

    # Step 5: Assign agents to organization
    patch_url = f"{api_url}/v1/organization/{org_id}"
    payload = {"agents": agent_ids}

    click.echo(click.style("\n⚙️  Assigning agents to organization...", fg='cyan', bold=True))
    click.echo(click.style(f"   Organization: ", fg='cyan') + click.style(org_name, fg='magenta', bold=True))
    click.echo(click.style(f"   Agent IDs: ", fg='cyan') + click.style(str(agent_ids), fg='yellow'))

    try:
        assign_response = make_authenticated_request(
            'PATCH',
            patch_url,
            profile,
            profile_config,
            spritz_url,
            json=payload,
            headers={'Content-Type': 'application/json'},
            timeout=30
        )

        if assign_response.status_code in (200, 201):
            click.echo(click.style("\n✅ Agents assigned successfully!", fg='green', bold=True))
            
            try:
                result_json = assign_response.json()
                click.echo(click.style("\n📝 Assignment Details:", fg='cyan', bold=True))
                click.echo(click.style(f"   Organization: ", fg='cyan') +
                          click.style(org_name, fg='magenta', bold=True))
                click.echo(click.style(f"   Agents Assigned: ", fg='cyan') +
                          click.style(str(len(agent_ids)), fg='yellow', bold=True))
            except Exception:
                pass
        else:
            click.echo(click.style(f"\n❌ Failed to assign agents: HTTP {assign_response.status_code}", fg='red', bold=True))
            try:
                err = assign_response.json()
                error_msg = err.get('message', err.get('error', str(err)))
                click.echo(click.style(f"   {error_msg}", fg='red'))
            except Exception:
                click.echo(click.style(f"   {assign_response.text}", fg='red'))
            sys.exit(1)

    except Exception as e:
        click.echo(click.style(f"\n❌ Error assigning agents: {str(e)}", fg='red', bold=True))
        sys.exit(1)

    click.echo(click.style("\n╔═══════════════════════════════════════════════════════════╗", fg='cyan', bold=True))
    click.echo(click.style("║                    ✨ COMPLETE                            ║", fg='cyan', bold=True))
    click.echo(click.style("╚═══════════════════════════════════════════════════════════╝", fg='cyan', bold=True))
