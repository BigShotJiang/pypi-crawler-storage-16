"""
Authentication handling for Spritz CLI
"""

import click
import time
import webbrowser
import sys
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import json

from .config import SpritzConfig
from .constants import CALLBACK_PORT


class CallbackHandler(BaseHTTPRequestHandler):
    """Handle token callback from browser"""
    token = None
    user_info = None
    
    def do_GET(self):
        """Receive token from browser via GET (query parameter)"""
        
        # Parse URL and extract token and user info from query parameters
        parsed_url = urlparse(self.path)
        query_params = parse_qs(parsed_url.query)
        
        if 'token' in query_params:
            CallbackHandler.token = query_params['token'][0]
            
            # Extract user info from query parameters
            CallbackHandler.user_info = {
                'userId': query_params.get('userId', [None])[0],
                'email': query_params.get('email', [None])[0],
                'username': query_params.get('username', [None])[0]
            }
            
            # Send success response with HTML
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()
            
            success_html = """
            <!DOCTYPE html>
            <html>
            <head>
                <title>Spritz CLI Authentication</title>
                <style>
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        margin: 0;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    }
                    .container {
                        background: white;
                        padding: 50px;
                        border-radius: 16px;
                        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                        text-align: center;
                        max-width: 450px;
                        animation: slideIn 0.3s ease-out;
                    }
                    @keyframes slideIn {
                        from {
                            opacity: 0;
                            transform: translateY(-20px);
                        }
                        to {
                            opacity: 1;
                            transform: translateY(0);
                        }
                    }
                    .icon {
                        font-size: 72px;
                        margin-bottom: 20px;
                    }
                    h2 {
                        margin: 0 0 15px 0;
                        color: #333;
                        font-size: 24px;
                        font-weight: 600;
                    }
                    p {
                        margin: 0;
                        color: #10b981;
                        font-size: 16px;
                        line-height: 1.5;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="icon">✓</div>
                    <h2>Authentication Complete!</h2>
                    <p>You can now close this window and return to the terminal.</p>
                </div>
                <script>
                    // Auto-close after 2 seconds
                    setTimeout(() => {
                        window.close();
                    }, 2000);
                </script>
            </body>
            </html>
            """
            self.wfile.write(success_html.encode())
        else:
            # No token found
            self.send_response(400)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()
            
            error_html = """
            <!DOCTYPE html>
            <html>
            <head>
                <title>Spritz CLI Authentication</title>
                <style>
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        margin: 0;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    }
                    .container {
                        background: white;
                        padding: 50px;
                        border-radius: 16px;
                        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                        text-align: center;
                        max-width: 450px;
                    }
                    .icon {
                        font-size: 72px;
                        margin-bottom: 20px;
                    }
                    h2 {
                        margin: 0 0 15px 0;
                        color: #333;
                        font-size: 24px;
                        font-weight: 600;
                    }
                    p {
                        margin: 0;
                        color: #ef4444;
                        font-size: 16px;
                        line-height: 1.5;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="icon">✗</div>
                    <h2>Authentication Failed</h2>
                    <p>No token received. Please try again.</p>
                </div>
            </body>
            </html>
            """
            self.wfile.write(error_html.encode())
    
    def do_POST(self):
        """Also support POST method for compatibility"""
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length)
        
        try:
            data = json.loads(post_data.decode())
            if 'token' in data:
                CallbackHandler.token = data['token']
                CallbackHandler.user_info = {
                    'userId': data.get('userId'),
                    'email': data.get('email'),
                    'username': data.get('username')
                }
                
                # Send success response
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(json.dumps({'success': True}).encode())
            else:
                self.send_error(400, "No token in request")
        except Exception as e:
            self.send_error(500, str(e))
    
    def do_OPTIONS(self):
        """Handle CORS preflight"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
    
    def log_message(self, format, *args):
        """Suppress log messages"""
        pass


def authenticate_user(profile, spritz_url):
    """Open browser for login and wait for token - Uses Spritz Web URL"""
    click.echo(click.style("\n🌐 Opening browser for authentication...", fg='cyan', bold=True))
    click.echo(click.style(f"   Spritz Web: ", fg='cyan') + click.style(spritz_url, fg='blue'))
    
    # Start local server to receive token
    server = HTTPServer(('localhost', CALLBACK_PORT), CallbackHandler)
    
    # Open browser with CLI auth endpoint - Uses Spritz Web URL
    callback_url = f"http://localhost:{CALLBACK_PORT}/token"
    auth_url = f"{spritz_url}/cli-auth?callback={callback_url}"
    
    webbrowser.open(auth_url)
    
    click.echo(click.style("   ⏳ Waiting for authentication...", fg='yellow'))
    click.echo(click.style("   💡 Please login in the browser window.", fg='cyan'))
    
    # Wait for token (with timeout)
    timeout = 300  # 5 minutes
    start_time = time.time()
    
    while CallbackHandler.token is None:
        server.handle_request()
        if time.time() - start_time > timeout:
            raise click.ClickException("Authentication timeout. Please try again.")
    
    # Ring bell to bring attention back to terminal
    sys.stdout.write('\a')
    sys.stdout.flush()
    
    token = CallbackHandler.token
    user_info = CallbackHandler.user_info
    
    # Reset for next use
    CallbackHandler.token = None
    CallbackHandler.user_info = None
    
    # Save token and user info
    config = SpritzConfig()
    config.save_auth_data(profile, token, user_info)
    
    click.echo(click.style("\n✅ Authentication successful!", fg='green', bold=True))
    if user_info and user_info.get('email'):
        click.echo(click.style("   👤 Logged in as: ", fg='cyan') + 
                  click.style(user_info.get('email'), fg='green', bold=True))
    else:
        click.echo(click.style("   🔑 Token saved!", fg='green', bold=True))
    
    return token
