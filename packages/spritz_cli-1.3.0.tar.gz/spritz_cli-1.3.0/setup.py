from setuptools import setup, find_packages
import os

# Read version from __version__.py
version = {}
here = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(here, 'src', '__init__.py')) as f:
    exec(f.read(), version)

# Read long description from README
with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='spritz-cli',
    version=version['__version__'],
    description='Spritz CLI (spx) - Deploy and manage AI agents',
    long_description=long_description,
    long_description_content_type="text/markdown",
    author='Activate Intelligence',
    author_email='pradeep@incaendo.com',
    url='https://github.com/Activate-Intelligence/spritz-cli',
    py_modules=['spritz'],
    packages=find_packages(),
    install_requires=[
        'click>=8.0.0',
        'requests>=2.25.0',
        "pyyaml>=6.0",
    ],
    entry_points={
        'console_scripts': [
            'spx=spritz:cli',
        ],
    },
    python_requires='>=3.7',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Build Tools',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
    ],
    keywords='cli agent deployment ai spritz management spx',
    project_urls={
        'Bug Reports': 'https://github.com/Activate-Intelligence/spritz-cli/issues',
        'Source': 'https://github.com/Activate-Intelligence/spritz-cli',
        'Documentation': 'https://github.com/Activate-Intelligence/spritz-cli#readme',
    },
)
