"""
Spritz CLI - Agent Management Tool
"""

__version__ = "1.3.0"