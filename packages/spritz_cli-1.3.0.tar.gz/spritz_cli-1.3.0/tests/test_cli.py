"""Tests for Spritz CLI"""

import pytest
from click.testing import CliRunner
from spritz import cli


def test_cli_help():
    """Test that CLI help command works"""
    runner = CliRunner()
    result = runner.invoke(cli, ['--help'])
    assert result.exit_code == 0
    assert 'Spritz CLI' in result.output or 'spx' in result.output


def test_cli_version():
    """Test that version command works"""
    runner = CliRunner()
    result = runner.invoke(cli, ['--version'])
    assert result.exit_code == 0
    assert '1.0.0' in result.output


def test_agent_list_without_auth():
    """Test that agent list requires authentication"""
    runner = CliRunner()
    result = runner.invoke(cli, ['agent', 'list'])
    # Should fail without authentication
    assert result.exit_code != 0 or 'login' in result.output.lower()