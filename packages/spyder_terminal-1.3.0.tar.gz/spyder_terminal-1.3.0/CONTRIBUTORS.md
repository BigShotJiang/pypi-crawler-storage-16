Spyder Project Contributors (@spyder-ide)
