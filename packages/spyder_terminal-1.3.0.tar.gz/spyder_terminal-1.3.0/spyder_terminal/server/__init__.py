"""
This packages contains and implements a simple terminal server.

Creates virtual terminals via pexpect and websockets.
"""
