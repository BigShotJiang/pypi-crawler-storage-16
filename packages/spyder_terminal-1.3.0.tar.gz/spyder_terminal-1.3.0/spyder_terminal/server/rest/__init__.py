# -*- coding: utf-8 -*-

"""
rest module.

=========

Provides:
    1. Asynchronous execution of JSON services

How to use the documentation
----------------------------
Documentation is available in one form: docstrings provided
with the code

Copyright (c) 2016, Edgar A. Margffoy.
MIT, see LICENSE for more details.
"""

from . import term_rest
term_rest
