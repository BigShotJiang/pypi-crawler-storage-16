{\rtf1\ansi\ansicpg1252\cocoartf2709
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fmodern\fcharset0 CourierNewPS-BoldMT;\f1\fmodern\fcharset0 CourierNewPSMT;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue109;\red246\green246\blue246;\red0\green0\blue0;
\red246\green246\blue246;\red151\green0\blue255;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c50196;\cssrgb\c97255\c97255\c97255;\cssrgb\c0\c0\c0;
\cssrgb\c97255\c97255\c97255;\cssrgb\c66667\c13333\c100000;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\b\fs24 \AppleTypeServices\AppleTypeServicesF65539 \cf2 \cb3 \expnd0\expndtw0\kerning0
SPyEEG
\f1\b0 \AppleTypeServices\AppleTypeServicesF65539 \cf0 \

\f0\b \AppleTypeServices\AppleTypeServicesF65539 \cf2 =======
\f1\b0 \AppleTypeServices\AppleTypeServicesF65539 \cf0 \
\
\pard\pardeftab720\partightenfactor0

\f0\b \AppleTypeServices\AppleTypeServicesF65539 \cf0 **SPyEEG**
\f1\b0 \AppleTypeServices\AppleTypeServicesF65539  is a Python library for relating neural signal and stimuli. You can find the code there: <https://github.com/phg17/sPyEEG>\
\
\pard\pardeftab720\partightenfactor0
\AppleTypeServices\AppleTypeServicesF65539 \cf0 \cb5 \outl0\strokewidth0 \strokec4 .. 
\f0\b \AppleTypeServices\AppleTypeServicesF65539 \cf6 \strokec6 note
\f1\b0 \AppleTypeServices\AppleTypeServicesF65539 \cf0 \strokec4 ::\
\
   This project is under active development.\
}