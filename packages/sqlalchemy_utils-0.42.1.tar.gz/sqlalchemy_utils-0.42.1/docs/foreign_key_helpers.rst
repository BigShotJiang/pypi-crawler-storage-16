Foreign key helpers
===================


dependent_objects
-----------------

.. autofunction:: sqlalchemy_utils.functions.dependent_objects


get_referencing_foreign_keys
----------------------------

.. autofunction:: sqlalchemy_utils.functions.get_referencing_foreign_keys


group_foreign_keys
------------------

.. autofunction:: sqlalchemy_utils.functions.group_foreign_keys


merge_references
----------------

.. autofunction:: sqlalchemy_utils.functions.merge_references


non_indexed_foreign_keys
------------------------

.. autofunction:: sqlalchemy_utils.functions.non_indexed_foreign_keys
