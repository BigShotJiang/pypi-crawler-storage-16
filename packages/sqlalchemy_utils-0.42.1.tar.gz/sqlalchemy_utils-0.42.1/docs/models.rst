Model mixins
============


Timestamp
---------

.. autoclass:: sqlalchemy_utils.models.Timestamp


generic_repr
------------

.. autofunction:: sqlalchemy_utils.models.generic_repr
