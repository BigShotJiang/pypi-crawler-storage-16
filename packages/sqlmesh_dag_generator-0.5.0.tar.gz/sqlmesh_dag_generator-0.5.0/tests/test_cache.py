"""
Test cache directory handling
"""
import os
import pytest
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock
from sqlmesh_dag_generator import SQLMeshDAGGenerator


def test_cache_dir_from_env_variable(tmp_path):
    """Test that SQLMESH_CACHE_DIR is respected"""
    cache_dir = tmp_path / "custom_cache"

    # Create minimal project structure
    project_path = tmp_path / "project"
    project_path.mkdir()
    (project_path / "config.yaml").write_text("gateways: {}")
    (project_path / "models").mkdir()
    (project_path / "models" / "test.sql").write_text("SELECT 1")

    with patch.dict(os.environ, {'SQLMESH_CACHE_DIR': str(cache_dir)}):
        # Mock SQLMesh Context to avoid loading real project
        with patch('sqlmesh_dag_generator.generator.Context') as mock_context:
            mock_context.return_value._models = {}

            generator = SQLMeshDAGGenerator(
                sqlmesh_project_path=str(project_path),
            )

            # Load context - should create cache directory
            generator.load_sqlmesh_context()

            # Verify cache directory was created
            assert cache_dir.exists()
            assert cache_dir.is_dir()


def test_cache_symlink_creation(tmp_path):
    """Test that symlink is created from project/.cache to SQLMESH_CACHE_DIR"""
    cache_dir = tmp_path / "cache"
    project_path = tmp_path / "project"
    project_path.mkdir()
    (project_path / "config.yaml").write_text("gateways: {}")
    (project_path / "models").mkdir()
    (project_path / "models" / "test.sql").write_text("SELECT 1")

    with patch.dict(os.environ, {'SQLMESH_CACHE_DIR': str(cache_dir)}):
        with patch('sqlmesh_dag_generator.generator.Context') as mock_context:
            mock_context.return_value._models = {}

            generator = SQLMeshDAGGenerator(
                sqlmesh_project_path=str(project_path),
            )

            generator.load_sqlmesh_context()

            project_cache = project_path / ".cache"

            # Verify symlink was created
            assert project_cache.exists()
            assert project_cache.is_symlink()
            assert project_cache.resolve() == cache_dir.resolve()


def test_cache_readonly_filesystem_fallback(tmp_path):
    """Test fallback to TMPDIR when symlink creation fails"""
    cache_dir = tmp_path / "cache"
    project_path = tmp_path / "project"
    project_path.mkdir()
    (project_path / "config.yaml").write_text("gateways: {}")
    (project_path / "models").mkdir()
    (project_path / "models" / "test.sql").write_text("SELECT 1")

    with patch.dict(os.environ, {'SQLMESH_CACHE_DIR': str(cache_dir)}):
        # Mock Path.exists to return False so symlink is attempted
        # Mock symlink_to to raise OSError (simulating read-only filesystem)
        original_exists = Path.exists
        def mock_exists(self):
            if str(self).endswith('.cache'):
                return False  # Pretend .cache doesn't exist
            return original_exists(self)

        with patch.object(Path, 'exists', mock_exists):
            with patch.object(Path, 'symlink_to', side_effect=OSError("Read-only file system")):
                with patch('sqlmesh_dag_generator.generator.Context') as mock_context:
                    mock_context.return_value._models = {}

                    generator = SQLMeshDAGGenerator(
                        sqlmesh_project_path=str(project_path),
                    )

                    generator.load_sqlmesh_context()

                    # Verify TMPDIR was set as fallback
                    assert os.environ.get('TMPDIR') == str(cache_dir)
                    assert os.environ.get('TEMP') == str(cache_dir)
                    assert os.environ.get('TMP') == str(cache_dir)


def test_cache_existing_writable_directory(tmp_path):
    """Test that existing writable .cache directory is used"""
    project_path = tmp_path / "project"
    project_path.mkdir()
    (project_path / "config.yaml").write_text("gateways: {}")
    (project_path / "models").mkdir()
    (project_path / "models" / "test.sql").write_text("SELECT 1")

    # Create existing writable .cache
    project_cache = project_path / ".cache"
    project_cache.mkdir()
    (project_cache / "existing.txt").write_text("test")

    cache_dir = tmp_path / "external_cache"

    with patch.dict(os.environ, {'SQLMESH_CACHE_DIR': str(cache_dir)}):
        with patch('sqlmesh_dag_generator.generator.Context') as mock_context:
            mock_context.return_value._models = {}

            generator = SQLMeshDAGGenerator(
                sqlmesh_project_path=str(project_path),
            )

            generator.load_sqlmesh_context()

            # Verify existing cache directory is still there
            assert project_cache.is_dir()
            assert not project_cache.is_symlink()
            assert (project_cache / "existing.txt").exists()


def test_no_cache_dir_env_variable(tmp_path):
    """Test that code works when SQLMESH_CACHE_DIR is not set"""
    project_path = tmp_path / "project"
    project_path.mkdir()
    (project_path / "config.yaml").write_text("gateways: {}")
    (project_path / "models").mkdir()
    (project_path / "models" / "test.sql").write_text("SELECT 1")

    # Ensure SQLMESH_CACHE_DIR is not set
    with patch.dict(os.environ, {}, clear=False):
        if 'SQLMESH_CACHE_DIR' in os.environ:
            del os.environ['SQLMESH_CACHE_DIR']

        with patch('sqlmesh_dag_generator.generator.Context') as mock_context:
            mock_context.return_value._models = {}

            generator = SQLMeshDAGGenerator(
                sqlmesh_project_path=str(project_path),
            )

            # Should not raise an error
            generator.load_sqlmesh_context()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

