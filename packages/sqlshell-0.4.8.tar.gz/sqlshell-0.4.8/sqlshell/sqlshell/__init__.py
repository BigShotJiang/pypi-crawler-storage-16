"""
SQLShell - A powerful SQL shell with GUI interface for data analysis
"""

__version__ = "0.1.1" 