"""
SQLStream CLI

Command-line interface for querying data files with SQL.
"""

from sqlstream.cli.main import cli

__all__ = ["cli"]
