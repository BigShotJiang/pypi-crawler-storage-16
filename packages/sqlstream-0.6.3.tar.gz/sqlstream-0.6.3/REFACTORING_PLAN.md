# SQLStream Refactoring & Improvement Plan

## Executive Summary
Based on codebase analysis, here's a prioritized improvement plan addressing code quality, tests, documentation, UI bugs, and new features.

---

## 1. CODE REDUNDANCY & REFACTORING

### High Priority Issues

#### 1.1 QueryInline Class Still Exists (CRITICAL)
- **Location**: `sqlstream/core/query.py:595-700`
- **Issue**: `QueryInline` class still exists despite being replaced by unified `Query` class
- **Impact**: Code duplication, confusion, ~200 lines of redundant code
- **Action**:
  - Remove `QueryInline` class entirely
  - Update any remaining references in tests (`test_query_inline.py`)
  - Verify shell.py and main.py fully migrated to `Query()`

#### 1.2 Duplicate `_create_reader` Method
- **Locations**: 
  - `Query._create_reader` (line ~120)
  - `QueryInline._create_reader` (line ~613)
- **Issue**: Exact same logic duplicated
- **Action**: Remove with QueryInline cleanup

#### 1.3 Fragment Parser Integration
- **Issue**: `parse_source_fragment` called in multiple places
- **Locations**: query.py, readers/http_reader.py, etc.
- **Action**: Centralize fragment parsing logic

### Medium Priority

#### 1.4 Reader Factory Pattern
- **Issue**: Reader creation logic scattered across Query._create_reader
- **Action**: Consider Factory pattern or registry for cleaner reader instantiation

#### 1.5 Backend Selection Logic
- **Issue**: Complex conditions spread across _select_backend and Query.sql
- **Action**: Consolidate into strategy pattern

---

## 2. TESTS - GAPS & OUTDATED

### Critical Missing Tests

#### 2.1 Core Functionality
- ✅ query() with optional source
- ✅ _discover_sources with unquoted paths  
- ✅ _replace_sources_in_sql with quoted table names
- ❌ **MISSING**: Smart backend selection edge cases
- ❌ **MISSING**: DuckDB explain() integration
- ❌ **MISSING**: Error handling for missing DuckDB/Pandas

#### 2.2 Integration Tests
- ❌ **MISSING**: End-to-end tests with real files
- ❌ **MISSING**: CLI integration tests with new query() signature
- ❌ **MISSING**: Shell state persistence tests

#### 2.3 Outdated Tests
- `tests/test_core/test_query_inline.py` - **NEEDS UPDATE** (143 lines)
  - Should be removed or migrated to test_query.py
- Several tests still reference old API patterns

### Test Coverage Analysis
```
Current: 57% (3585 statements, 1541 missed)
Goal: 80%+ for core modules

Low coverage areas:
- cli/shell.py: 0% (687 statements untested)
- readers/parquet_reader.py: 0% (260 statements)
- readers/html_reader.py: 0% (98 statements)
- optimizers/cost_based.py: 41%
```

### Actions Required
1. Remove `test_query_inline.py` or convert to `Query()` tests
2. Add DuckDB backend integration tests
3. Add shell component tests (mocking Textual)
4. Increase reader coverage (especially Parquet, HTML, Markdown)

---

## 3. INTERACTIVE UI BUGS & IMPROVEMENTS

### P0 - Critical Bugs

#### 3.1 F2 Toggle Text Shift Bug
- **Symptom**: When toggling left panel with F2, editor text shifts right without wrap
- **Location**: `sqlstream/cli/shell.py`
- **Root Cause**: Likely TextArea width not recalculating on panel toggle
- **Fix**: Force TextArea reflow/redraw on sidebar toggle

#### 3.2 Ctrl+Del / Ctrl+Backspace Not Working
- **Symptom**: Word deletion shortcuts don't work in editor
- **Location**: Key binding in shell.py
- **Fix**: Add key bindings for `ctrl+delete` and `ctrl+backspace`

### P1 - UX Improvements

#### 3.3 Intelligent Filter UX
- **Current**: Poor discoverability, basic text filtering only
- **Insight**: Schema and data are available post-query execution
- **Improvements Needed**:
  - **Schema-Based Filtering**: Generate filter UI based on column data type (e.g., numeric ranges, date pickers)
  - **Data-Driven Inputs**: Use actual column values for categorical dropdowns/autocomplete
  - Visual indicator for active filters
  - Live result count (e.g., "Filtered: 45/100 rows")

#### 3.4 Export UX Overhaul
- **Current**: Unclear workflow, poor modal aesthetics
- **Improvements Needed**:
  - **TUI File Saver**: Replace modals with a native file browser interface (similar to "Open File"?)
  - **Integrated Workflow**:
    - Format selection (CSV/JSON/Parquet)
    - Path selection via file browser
  - Success/failure notification

### P2 - Nice to Have

#### 3.5 Editor Enhancements
- Query formatting (Ctrl+Shift+F)

---

## 4. DOCUMENTATION UPDATES

### Outdated Content

#### 4.1 API Documentation
- **File**: `README.md`, `docs/api/overview.md`
- **Issues**:
  - Still shows `query(source)` as required parameter
  - No mention of optional source
  - Missing DuckDB backend examples
- **Action**: Update with new signature and examples

#### 4.2 Missing Documentation
- Smart backend selection logic
- Fragment parser syntax (`#format:table`)
- DuckDB integration guide
- Source discovery mechanism

### Actions
1. Update README.md with optional source examples
2. Add "Advanced Usage" doc covering:
   - Smart backend selection
   - Fragment syntax
   - Multi-table queries
3. Update CLI reference for new query syntax
4. Add troubleshooting guide

---

## 5. NEW FEATURE: JSONL SUPPORT

### Requirements
- Read JSONL (JSON Lines) files
- Support for streaming large JSONL files
- Schema inference from first N lines
- Integration with existing Query API

### Implementation Plan

#### 5.1 Create JSONLReader
```python
# sqlstream/readers/jsonl_reader.py
class JSONLReader(BaseReader):
    """
    Reader for JSONL (JSON Lines) files
    
    Supports:
    - Line-by-line JSON parsing
    - Schema inference
    - Lazy iteration
    """
```

#### 5.2 Update Query._create_reader
- Add `.jsonl` extension detection
- Add fragment hint support: `data.txt#jsonl`

#### 5.3 Tests
- `tests/test_readers/test_jsonl_reader.py`
- Schema inference
- Large file handling
- Malformed JSON handling

---

## IMPLEMENTATION PRIORITY

### Phase 1: Critical Cleanup ✅ **COMPLETE**
1. ✅ Remove QueryInline class and migrate tests
2. ✅ Fix F2 toggle text shift bug  
3. ✅ Fix Ctrl+Del/Backspace shortcuts
4. ✅ Update README.md with new API
5. ✅ Update docs/ directory with API changes

### Phase 2: UX Improvements ✅ **COMPLETE**
5. ✅ Improve filter UX (schema-aware column selection, visual indicators, counts)
6. ✅ Improve export UX (format selection dialog, better notifications, data type preservation)
7. ✅ Query Editor enhancements (line numbers enabled, schema-aware auto-completion)

### Phase 3: Test Coverage (Next)
8. Add missing DuckDB tests
9. Add smart backend selection tests
10. Increase reader test coverage to 70%+

### Phase 4: New Features
11. Implement JSONL support
12. Add CLI integration tests
13. Performance optimizations

---

## METRICS

### Before
- Lines of code: ~6,000
- Test coverage: 57%
- Duplicate code: ~200 lines
- Known UI bugs: 4
- Supported formats: CSV, Parquet, HTML, Markdown

### After (Target)
- Lines of code: ~5,500 (remove duplication)
- Test coverage: 80%+
- Duplicate code: 0
- Known UI bugs: 0
- Supported formats: +JSONL

---

## NEXT STEPS

Would you like me to:
1. Start with Phase 1 (QueryInline removal + critical UI bugs)?
2. Focus on a specific area (tests, docs, UI, or JSONL)?
3. Create detailed implementation specs for any phase?

Let me know your preference and I'll begin execution!
