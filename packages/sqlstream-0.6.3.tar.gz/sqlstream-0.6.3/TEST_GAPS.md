# Test Coverage Gaps Analysis

**Current Overall Coverage: 61%** (643 tests passing, updated after all improvements)

## 🎉 Recent Session Achievements

In this session, we significantly improved test coverage across multiple critical components:

| Component | Before | After | Improvement | Tests Added |
|-----------|--------|-------|-------------|-------------|
| **CSV Reader** | 17% | 88% | **+71%** | 40 tests (already existed) |
| **Parquet Reader** | 13% | 87% | **+74%** | +22 tests (new) |
| **HTTP Reader** | 32% | 74% | **+42%** | +17 tests (new) |
| **Pandas Executor** | 40% | 77% | **+37%** | 18 tests (JSON/JSONL/XML) |
| **Overall Project** | 28%* | 61% | **+33%** | **643 total tests** |

*Started session at 28% (from initial 15% before pandas backend work)

### Key Test Additions:
- **Parquet**: Arrow type mapping (int/float/string/bool/date/timestamp/decimal), complex types (list/struct), compression (snappy/gzip), large file handling, error handling
- **HTTP**: Error codes (404/500/403), redirects, streaming, multi-format support (JSON/JSONL/HTML/Markdown), cache key generation
- **CSV**: Comprehensive existing tests covering delimiters, encoding, malformed data, edge cases

## Recently Completed ✅

### ✅ **CSV Reader - NOW 88% Coverage** (Previously 17%)
Comprehensive tests added for:
- ✅ Delimiter auto-detection (tab, pipe, semicolon)
- ✅ Encoding handling (UTF-8, Latin-1, Windows-1252, BOM)
- ✅ Malformed CSV handling (missing columns, extra columns, null values)
- ✅ Empty files and files with only headers
- ✅ Special characters and quoting
- ✅ Type inference edge cases (mixed types, nulls, scientific notation)
- ✅ 40 comprehensive tests covering all major scenarios

**Status**: Excellent coverage achieved ✅

---

### ✅ **Parquet Reader - NOW 87% Coverage** (Previously 13%)
Added 22 new comprehensive tests for:
- ✅ Arrow type to SQLStream type mapping (`_arrow_type_to_dtype`)
- ✅ All Arrow data types (int8/16/32/64, float32/64, string, bool, date, timestamp, decimal)
- ✅ Schema reading and inference
- ✅ Complex data types (list, struct, nested lists)
- ✅ Compression codecs (snappy, gzip, uncompressed)
- ✅ Large file handling (many row groups, many columns, wide rows)
- ✅ Error handling (corrupted files, empty files, type mismatches, invalid columns)
- ✅ Row group filtering and column selection optimization

**Status**: Excellent coverage achieved ✅

---

### ✅ **HTTP Reader - NOW 74% Coverage** (Previously 32%, then 63%)
Added 17 new comprehensive tests for:
- ✅ HTTP error codes (404, 500, 403)
- ✅ Network errors (timeout, connection refused)
- ✅ Redirect handling (single and multiple redirects with follow_redirects=True)
- ✅ Chunked streaming download
- ✅ Additional formats (JSON, JSONL, HTML, Markdown)
- ✅ Cache key generation with query parameters
- ✅ Empty response handling
- ✅ Format detection from URL extension
- ✅ Caching behavior (cache hit/miss scenarios already tested)

**Status**: Good coverage achieved ✅

---

## Critical Coverage Issues (Priority 1)

### Remaining High Priority Items:

### 4. **SQL Parser - 13% Coverage**
Missing tests for:
- ✗ Complex expressions (arithmetic, logical)
- ✗ Operator precedence
- ✗ String literals (single quotes, escaping)
- ✗ Numeric literals (integers, floats, scientific notation)
- ✗ NULL handling
- ✗ Aliases with AS keyword
- ✗ Table aliases in JOINs
- ✗ Column qualifiers (table.column)
- ✗ Multiple tables in FROM
- ✗ Nested expressions
- ✗ Function calls with multiple arguments
- ✗ CASE expressions (when implemented)
- ✗ Subqueries (when implemented)
- ✗ Error messages for invalid SQL
- ✗ Edge cases (trailing semicolon, extra whitespace, comments)

**Impact**: Parser is foundation - bugs here affect everything

---

### 5. **Join Operator - 14% Coverage**
Missing tests for:
- ✗ LEFT JOIN (mentioned in docs but not tested)
- ✗ RIGHT JOIN (mentioned in docs but not tested)
- ✗ FULL OUTER JOIN
- ✗ CROSS JOIN
- ✗ Semi/Anti joins
- ✗ Multiple join conditions (AND)
- ✗ Join with NULL values (NULL = NULL behavior)
- ✗ Join on different types
- ✗ Large dataset joins (performance)
- ✗ Self-joins
- ✗ Multiple joins in one query
- ✗ Join with WHERE clause
- ✗ Join with GROUP BY

**Impact**: JOINs are documented as supported but minimally tested

---

### 6. **OrderBy Operator - 29% Coverage**
Missing tests for:
- ✗ Multiple columns sorting
- ✗ DESC ordering
- ✗ Mixed ASC/DESC (e.g., `ORDER BY a ASC, b DESC`)
- ✗ NULL handling (NULLS FIRST/LAST if supported)
- ✗ Sorting with different data types
- ✗ Sorting with expressions
- ✗ Sorting large datasets
- ✗ Stability of sort
- ✗ ORDER BY with LIMIT

**Impact**: Basic feature needs comprehensive testing

---

### 7. **Project Operator - 29% Coverage**
Missing tests for:
- ✗ Expression evaluation
- ✗ Column aliasing
- ✗ Computed columns
- ✗ Type conversions in projections
- ✗ Aggregate projections
- ✗ Complex expressions

---

### 8. **Limit Operator - 38% Coverage**
Missing tests for:
- ✗ LIMIT 0
- ✗ LIMIT larger than dataset
- ✗ LIMIT with streaming
- ✗ LIMIT with different backends

---

### 9. **Aggregates - 33% Coverage**
Missing tests for:
- ✗ COUNT(DISTINCT column)
- ✗ Multiple aggregates in one query
- ✗ Aggregates on different types (string, date)
- ✗ NULL handling in aggregates
- ✗ Empty groups
- ✗ Aggregates without GROUP BY
- ✗ GROUP BY with multiple columns
- ✗ GROUP BY with expressions
- ✗ HAVING clause (when implemented)
- ✗ Window functions (when implemented)

**Impact**: Aggregations are complex - needs thorough testing

---

### 10. **Interactive Shell - Minimal Coverage**
The shell tests in test_shell_components.py test basic logic, but missing:

**Auto-completion (SQLSuggester)**:
- ✗ Keyword completion edge cases
- ✗ Table name completion from multiple files
- ✗ Column completion from multiple tables
- ✗ Completion with partial matches
- ✗ Case sensitivity
- ✗ Completion priority (keywords vs tables vs columns)

**Modal Dialogs**:
- ✗ FilterDialog interaction
- ✗ ExplainDialog rendering
- ✗ SaveFileDialog validation
- ✗ OpenFileDialog navigation
- ✗ Dialog cancellation
- ✗ Dialog input validation

**File Operations**:
- ✗ File browser navigation
- ✗ Directory traversal
- ✗ File filtering by extension
- ✗ Permission handling

**Query History**:
- ✗ History persistence
- ✗ Multiline query preservation (delimiter: \n===\n)
- ✗ History navigation edge cases
- ✗ History size limits (100 queries)
- ✗ Corrupted history file handling

**Export Functionality**:
- ✗ CSV export with special characters
- ✗ JSON export formatting
- ✗ Parquet export (with/without pyarrow)
- ✗ Export error handling
- ✗ Custom filename validation

**Display/UI**:
- ✗ Pagination boundary cases (page 1, last page)
- ✗ Sorting stability
- ✗ Filter with no matches
- ✗ Large result sets (1M+ rows)
- ✗ Column width calculation
- ✗ Unicode handling
- ✗ Error message display

**Schema Browser**:
- ✗ Async schema loading
- ✗ Multiple file schemas
- ✗ Schema load errors
- ✗ Schema updates

**Explain Plan**:
- ✗ Plan formatting
- ✗ Optimization display
- ✗ Complex query plans

**Impact**: Shell is user-facing - bugs are immediately visible

---

### 11. **Formatters - Limited Coverage**
Missing tests for:
- ✗ Table formatter with very long text
- ✗ Table formatter with special characters
- ✗ Table formatter with Unicode
- ✗ Table formatter with empty results
- ✗ JSON formatter pretty printing
- ✗ JSON formatter with date/time types
- ✗ CSV formatter with quoting
- ✗ CSV formatter with special characters
- ✗ All formatters with NULL values

**New formatters needing tests:**
- ✗ **Markdown formatter** (new in `sqlstream/cli/formatters/markdown.py`)
  - ✗ GFM table generation
  - ✗ Alignment options (left, center, right)
  - ✗ Pipe character escaping
  - ✗ NULL value handling
  - ✗ Footer with row count
  - ✗ Special characters and Unicode
  - ✗ Empty results
  - ✗ Very wide tables

---

### 11a. **HTML Reader - New Feature**
**Status**: ⚠️ **NEEDS TESTS**

Newly created `HTMLReader` using pandas `read_html()`. Missing tests for:
- ✗ Basic table extraction
- ✗ Multiple tables in HTML (table parameter)
- ✗ Table selection by index (positive/negative)
- ✗ Table selection with `match` parameter
- ✗ Empty HTML (no tables)
- ✗ Malformed HTML
- ✗ Tables with rowspan/colspan
- ✗ Tables with nested elements
- ✗ Unicode in table cells
- ✗ Very large HTML tables
- ✗ Filter pushdown
- ✗ Column selection
- ✗ Schema inference from HTML tables
- ✗ `list_tables()` functionality
- ✗ Error messages for out-of-range table index
- ✗ Integration with query engine
- ✗ URL fragment parsing (`page.html#html:1`)

**Impact**: New user-facing feature - needs comprehensive testing

---

### 11b. **Markdown Reader - New Feature**
**Status**: ⚠️ **NEEDS TESTS**

Newly created `MarkdownReader` with custom GFM parser. Missing tests for:
- ✗ Basic table parsing (pipe tables)
- ✗ Header and separator row parsing
- ✗ Multiple tables in markdown file
- ✗ Table selection by index (positive/negative)
- ✗ Empty markdown (no tables)
- ✗ Malformed tables (missing columns)
- ✗ Alignment indicators (:---,  :---:, ---:)
- ✗ Escaped pipe characters (\|)
- ✗ NULL value recognition (null, NULL, N/A, -)
- ✗ Type inference (int, float, bool, string)
- ✗ Mixed type columns
- ✗ Very long table rows
- ✗ Unicode in cells
- ✗ Filter pushdown
- ✗ Column selection
- ✗ Schema inference accuracy
- ✗ `list_tables()` functionality
- ✗ Error messages for invalid tables
- ✗ Integration with query engine
- ✗ URL fragment parsing (`README.md#markdown:0`)

**Impact**: New parser implementation - needs thorough testing

---

### 11c. **URL Fragment Parser - New Feature**
**Status**: ⚠️ **BASIC TESTS EXIST**

Created `fragment_parser.py` module. Has basic tests in `test_fragment_parser.py` but needs:
- ✅ Basic parsing (format, table, both)
- ✅ Negative table indices
- ✅ Error cases (invalid format, invalid table)
- ✗ Edge cases:
  - ✗ Empty fragments (#)
  - ✗ Multiple # in URL handling
  - ✗ Query strings with fragments
  - ✗ Very long format/table values
  - ✗ Whitespace handling
- ✗ Integration tests:
  - ✗ Fragment in FROM clause
  - ✗ Fragment with JOIN
  - ✗ Fragment with HTTP URLs
  - ✗ Fragment parsing in pandas executor
  - ✗ Fragment parsing in python executor
- ✗ `build_source_fragment()` comprehensive tests

**Impact**: Core new feature - needs robust testing

---

### 11d. **HTTPReader Format Detection - Enhanced**
**Status**: ⚠️ **PARTIALLY TESTED**

Enhanced `HTTPReader` with explicit `format` parameter and better detection. Missing tests for:
- ✗ Explicit format parameter (`format="csv"`)
- ✗ Format parameter with table parameter
- ✗ Content-Type header detection (when implemented)
- ✗ Detection priority: explicit > extension > content-type > magic bytes
- ✗ Format detection for HTML
- ✗ Format detection for Markdown
- ✗ Pastebin-style URLs (no extension) with format parameter
- ✗ Format mismatch (extension says .csv but content is HTML)
- ✗ Unknown format fallback to CSV

**Impact**: Enhancement to existing feature - needs verification

---

### 12. **Type System - Needs Expansion**
Missing tests for:
- ✗ Type coercion rules
- ✗ Type validation
- ✗ DateTime parsing (multiple formats)
- ✗ Date parsing
- ✗ NULL type handling
- ✗ Type inference from mixed data
- ✗ Type errors and recovery
- ✗ Type conversion edge cases

---

### 13. **Pandas Backend - Enhanced with New Format Support**
**Status**: ⚠️ **RECENTLY ENHANCED - NEEDS COMPREHENSIVE TESTS**

**What was done:**
- ✅ Added JSON file support via `JSONReader.to_dataframe()`
- ✅ Added JSONL file support via `JSONLReader.to_dataframe()`
- ✅ Added XML file support via `XMLReader.to_dataframe()`
- ✅ Updated HTTP URL format detection for JSON/JSONL/XML
- ✅ Now supports all SQLStream formats: CSV, Parquet, JSON, JSONL, XML, HTML, Markdown

**Critical missing tests for new format support:**
- ✗ **JSON file loading with pandas backend**
  - ✗ Simple JSON arrays
  - ✗ Nested JSON with records_key parameter
  - ✗ JSON with table_hint/fragment syntax
  - ✗ Query execution (SELECT, WHERE, JOIN) on JSON
  - ✗ Error handling for malformed JSON
  - ✗ Type inference from JSON data
- ✗ **JSONL file loading with pandas backend**
  - ✗ Basic JSONL reading
  - ✗ Query execution on JSONL
  - ✗ Large JSONL files
  - ✗ Malformed lines handling
- ✗ **XML file loading with pandas backend**
  - ✗ Basic XML parsing with element selection
  - ✗ XML with fragments (#xml:element)
  - ✗ Query execution on XML data
  - ✗ Nested element handling
  - ✗ Attribute vs element column names
- ✗ **Format detection for HTTP URLs**
  - ✗ JSON URL detection from reader type
  - ✗ JSONL URL detection
  - ✗ XML URL detection
  - ✗ Format precedence (explicit > fragment > extension)
- ✗ **Integration tests**
  - ✗ CLI queries on JSON files without --backend flag
  - ✗ CLI queries on XML files without --backend flag
  - ✗ Joins between JSON and CSV with pandas backend
  - ✗ Joins between XML and Parquet with pandas backend
  - ✗ Multi-format queries with auto backend selection

**Existing missing tests (from before):**
- ✗ Large dataset handling
- ✗ Memory efficiency comparison
- ✗ Type mapping correctness
- ✗ Performance benchmarks vs Python backend
- ✗ Error handling for all formats
- ✗ Feature parity verification with Python backend

**Priority**: **HIGH** - New functionality needs verification before release

---

### 14. **S3 Support - Basic Tests Only**
Missing tests for:
- ✗ Authentication methods (env vars, config file, IAM)
- ✗ Bucket access permissions
- ✗ Different regions
- ✗ Partitioned files (Hive-style, custom)
- ✗ Error handling (access denied, not found)
- ✗ Performance with large files
- ✗ Multipart downloads
- ✗ Path resolution (s3://, s3a://)

**Impact**: S3 is a major feature - needs production-ready testing

---

### 15. **Core Executor - Needs Integration Tests**
Missing tests for:
- ✗ Full query execution pipelines
- ✗ Error propagation
- ✗ Operator chaining
- ✗ Memory management
- ✗ Cancellation
- ✗ Progress reporting

---

### 16. **Optimizers Module**
**Status**: ✅ **RESOLVED**

**What was done:**
- ✅ Created modular optimizer architecture with base classes
- ✅ Moved QueryPlanner from `core/planner.py` to `optimizers/planner.py`
- ✅ Created individual optimizer rule classes:
  - `PredicatePushdownOptimizer` (97% coverage)
  - `ColumnPruningOptimizer` (78% coverage)
  - `LimitPushdownOptimizer` (81% coverage)
  - `ProjectionPushdownOptimizer` (80% coverage - placeholder)
- ✅ All 19 optimizer tests passing
- ✅ Overall test coverage increased from 18% to 32%
- ✅ Comprehensive documentation added

**New structure:**
```
sqlstream/optimizers/
├── base.py                    (92% coverage)
├── planner.py                 (90% coverage)
├── predicate_pushdown.py      (97% coverage)
├── column_pruning.py          (78% coverage)
├── limit_pushdown.py          (81% coverage)
└── projection_pushdown.py     (80% coverage)
```

---

## Test Organization Issues

1. **Integration Tests Missing**
   - No end-to-end tests for complex queries
   - No tests for real-world scenarios
   - No performance regression tests
   - No stress tests

2. **Error Path Testing**
   - Most tests only cover happy paths
   - Need systematic error injection tests
   - Need invalid input tests
   - Need edge case tests

3. **Backend Coverage**
   - Most tests use Python backend
   - Pandas backend needs equal coverage
   - Backend switching needs testing

4. **File Format Testing**
   - Need tests with various CSV dialects
   - Need tests with different parquet schemas
   - Need tests with real-world messy data

---

## Recommended Test Priorities

### Priority 1 (Critical - Production Blockers)
1. **Pandas Backend JSON/JSONL/XML support** ⚠️ **NEW** - Recently added, needs comprehensive testing
2. CSV Reader edge cases (encoding, malformed data)
3. Parquet Reader type mapping
4. HTTP Reader error handling
5. SQL Parser error messages
6. Join operator (LEFT/RIGHT joins documented but not tested)
7. S3 authentication and error handling

### Priority 2 (High - User-Facing Features)
1. **CLI JSON/XML queries without --backend flag** ⚠️ **NEW** - Integration tests for new pandas backend formats
2. Interactive Shell modal dialogs
3. Query history persistence
4. Export functionality
5. Auto-completion
6. Formatters with special characters

### Priority 3 (Medium - Quality & Robustness)
1. OrderBy multiple columns
2. Aggregates NULL handling
3. Type system edge cases
4. Pandas backend parity
5. Integration tests

### Priority 4 (Low - Nice to Have)
1. Performance benchmarks
2. Stress tests
3. ~~Optimizer module implementation~~ ✅ **DONE**
4. Advanced S3 features

---

## Testing Infrastructure Needs

1. **Test Data**
   - Need diverse test datasets
   - Need large test files for performance
   - Need malformed data for error handling
   - Need real-world sample data

2. **Test Fixtures**
   - Reusable CSV/Parquet generators
   - Mock HTTP servers
   - Mock S3 (moto library?)
   - Sample schemas

3. **Test Utilities**
   - Coverage reporting in CI
   - Performance regression detection
   - Test data generators
   - Assertion helpers

4. **CI/CD**
   - Run tests on multiple Python versions
   - Platform-specific tests (Windows, Linux, Mac)
   - Coverage thresholds
   - Performance benchmarks

---

## Coverage Goals

**Target Coverage by Module:**
- Readers: 80%+ (currently 13-32%)
- Operators: 80%+ (currently 14-38%)
- SQL Parser: 90%+ (currently 13%)
- CLI/Shell: 70%+ (currently ~40%)
- Core: 85%+ (currently varies)
- Overall: 75%+ (currently 18%)

**Timeline Estimate:**
- Priority 1: 40-50 new tests (~2-3 weeks)
- Priority 2: 30-40 new tests (~2 weeks)
- Priority 3: 50+ new tests (~3 weeks)
- Priority 4: Ongoing

**Total**: ~120-140 additional tests needed to reach 75% coverage
