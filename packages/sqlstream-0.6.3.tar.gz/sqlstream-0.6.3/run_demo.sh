#!/bin/bash
# SQLStream Demo Runner
# Creates demo directory with all required files and runs VHS

set -e

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}Setting up SQLStream demo...${NC}"

# Create demo directory
mkdir -p demo
cd demo

# Create query_json.sh
if [ ! -f query_json.sh ]; then
    cat > query_json.sh << 'EOF'
sqlstream query --backend duckdb --format json \
  "SELECT * FROM './examples/api_response.json'" | \
  jq '.[0].result.users[] | select(.id <= 2)'
EOF
    echo -e "${GREEN}✓ Created query_json.sh${NC}"
fi

# Create query_xml.py
if [ ! -f query_xml.py ]; then
    cat > query_xml.py << 'EOF'
from sqlstream.readers.xml_reader import XMLReader
reader = XMLReader('./examples/demo_data.xml', element='record')
results = list(reader.read_lazy())[:3]
print('\n'.join(str(r) for r in results))
EOF
    echo -e "${GREEN}✓ Created query_xml.py${NC}"
fi

# Create query_join.sql
if [ ! -f query_join.sql ]; then
    cat > query_join.sql << 'EOF'
SELECT e.name, e.salary, d.dept_name
FROM './examples/employees.csv' e
JOIN './examples/departments.csv' d
ON e.dept_id = d.dept_id
LIMIT 3
EOF
    echo -e "${GREEN}✓ Created query_join.sql${NC}"
fi

# Create query_groupby.sql
if [ ! -f query_groupby.sql ]; then
    cat > query_groupby.sql << 'EOF'
SELECT d.dept_name,
  COUNT(*) as emp_count,
  AVG(e.salary) as avg_salary
FROM './examples/employees.csv' e
JOIN './examples/departments.csv' d
ON e.dept_id = d.dept_id
GROUP BY d.dept_name
EOF
    echo -e "${GREEN}✓ Created query_groupby.sql${NC}"
fi

# Create query_python.py
if [ ! -f query_python.py ]; then
    cat > query_python.py << 'EOF'
from sqlstream import query

results = query('./examples/employees.csv').sql(
    'SELECT name, salary FROM employees WHERE salary > 100000 LIMIT 3'
)
print('\n'.join(str(r) for r in results))
EOF
    echo -e "${GREEN}✓ Created query_python.py${NC}"
fi

# Go back to parent directory
cd ..

echo -e "${BLUE}Running VHS to generate demo...${NC}"

# Run VHS (assuming vhs and other tools are in PATH)
export PATH="$HOME/bin:$PATH"
vhs demo.tape

echo -e "${GREEN}✓ Demo generated successfully!${NC}"

# Clean up temporary query files (keep demo.gif)
echo -e "${BLUE}Cleaning up temporary files...${NC}"
rm -f demo/query_json.sh demo/query_xml.py demo/query_join.sql demo/query_groupby.sql demo/query_python.py demo/result.json

echo -e "${GREEN}✓ Demo complete! Check demo.gif${NC}"
