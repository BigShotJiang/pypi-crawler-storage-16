#!/bin/bash
# SQLStream Demo Runner - Generates 3 separate demos
# Creates demo directory with all required files and runs VHS for each demo

set -e

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}Setting up SQLStream demos...${NC}"

# Create demo directory
mkdir -p demo
cd demo

# ============================================
# Common files used across multiple demos
# ============================================

# Create query_json.sh (used in query_cli demo)
if [ ! -f query_json.sh ]; then
    cat > query_json.sh << 'EOF'
sqlstream query --backend duckdb --format json \
  "SELECT * FROM './examples/api_response.json'" | \
  jq '.[0].result.users[] | select(.id <= 2)'
EOF
    echo -e "${GREEN}✓ Created query_json.sh${NC}"
fi

# Create query_xml.py (used in python_api demo)
if [ ! -f query_xml.py ]; then
    cat > query_xml.py << 'EOF'
from sqlstream.readers.xml_reader import XMLReader
reader = XMLReader('./examples/demo_data.xml', element='record')
results = list(reader.read_lazy())[:3]
print('\n'.join(str(r) for r in results))
EOF
    echo -e "${GREEN}✓ Created query_xml.py${NC}"
fi

# Create query_join.sql (used in query_cli demo)
if [ ! -f query_join.sql ]; then
    cat > query_join.sql << 'EOF'
SELECT e.name, e.salary, d.dept_name
FROM './examples/employees.csv' e
JOIN './examples/departments.csv' d
ON e.dept_id = d.dept_id
LIMIT 3
EOF
    echo -e "${GREEN}✓ Created query_join.sql${NC}"
fi

# Create query_groupby.sql (used in query_cli demo)
if [ ! -f query_groupby.sql ]; then
    cat > query_groupby.sql << 'EOF'
SELECT d.dept_name,
  COUNT(*) as emp_count,
  AVG(e.salary) as avg_salary
FROM './examples/employees.csv' e
JOIN './examples/departments.csv' d
ON e.dept_id = d.dept_id
GROUP BY d.dept_name
EOF
    echo -e "${GREEN}✓ Created query_groupby.sql${NC}"
fi

# ============================================
# Python API demo files
# ============================================

# Basic query
if [ ! -f query_python.py ]; then
    cat > query_python.py << 'EOF'
from sqlstream import query

results = query('./examples/employees.csv').sql(
    'SELECT name, salary FROM employees WHERE salary > 100000 LIMIT 3'
)
print('\n'.join(str(r) for r in results))
EOF
    echo -e "${GREEN}✓ Created query_python.py${NC}"
fi

# Filter query
if [ ! -f filter_query.py ]; then
    cat > filter_query.py << 'EOF'
from sqlstream import query

results = query('./examples/employees.csv').sql(
    "SELECT name, dept_id, salary FROM employees WHERE dept_id = 1"
).to_list()

for row in results:
    print(f"{row['name']:15} Dept: {row['dept_id']}  Salary: ${row['salary']:,}")
EOF
    echo -e "${GREEN}✓ Created filter_query.py${NC}"
fi

# JOIN query
if [ ! -f join_query.py ]; then
    cat > join_query.py << 'EOF'
from sqlstream import query

sql = """
SELECT e.name, e.salary, d.dept_name
FROM './examples/employees.csv' e
JOIN './examples/departments.csv' d ON e.dept_id = d.dept_id
LIMIT 5
"""

results = query().sql(sql).to_list()
for row in results:
    print(f"{row['name']:15} {row['dept_name']:20} ${row['salary']:,}")
EOF
    echo -e "${GREEN}✓ Created join_query.py${NC}"
fi

# Aggregation query
if [ ! -f agg_query.py ]; then
    cat > agg_query.py << 'EOF'
from sqlstream import query

sql = """
SELECT d.dept_name,
       COUNT(*) as emp_count,
       AVG(e.salary) as avg_salary,
       MAX(e.salary) as max_salary
FROM './examples/employees.csv' e
JOIN './examples/departments.csv' d ON e.dept_id = d.dept_id
GROUP BY d.dept_name
ORDER BY avg_salary DESC
"""

for row in query().sql(sql):
    print(f"{row['dept_name']:20} Employees: {row['emp_count']}  "
          f"Avg: ${row['avg_salary']:,.0f}  Max: ${row['max_salary']:,}")
EOF
    echo -e "${GREEN}✓ Created agg_query.py${NC}"
fi

# JSON query
if [ ! -f json_query.py ]; then
    cat > json_query.py << 'EOF'
from sqlstream import query

# Query nested JSON structure
results = query('./examples/api_response.json#json:result.users').sql(
    'SELECT name, age, city FROM users WHERE age > 25 LIMIT 3'
).to_list()

for row in results:
    print(f"{row['name']:15} Age: {row['age']:2}  City: {row['city']}")
EOF
    echo -e "${GREEN}✓ Created json_query.py${NC}"
fi

# Parquet query
if [ ! -f parquet_query.py ]; then
    cat > parquet_query.py << 'EOF'
from sqlstream import query

results = query('./examples/employees.parquet').sql(
    'SELECT name, salary FROM employees WHERE salary > 100000 ORDER BY salary DESC'
).to_list()

print(f"Found {len(results)} high-salary employees:\n")
for row in results[:5]:
    print(f"  {row['name']:20} ${row['salary']:,}")
EOF
    echo -e "${GREEN}✓ Created parquet_query.py${NC}"
fi

# Lazy evaluation query
if [ ! -f lazy_query.py ]; then
    cat > lazy_query.py << 'EOF'
from sqlstream import query

# Process results lazily without loading all into memory
result = query('./examples/employees.csv').sql(
    'SELECT name, salary FROM employees WHERE salary > 80000'
)

print("Processing results one by one:")
for i, row in enumerate(result, 1):
    print(f"  {i}. {row['name']:15} ${row['salary']:,}")
    if i >= 5:  # Process only first 5
        break
EOF
    echo -e "${GREEN}✓ Created lazy_query.py${NC}"
fi

# Go back to parent directory
cd ..

echo -e "${BLUE}Running VHS to generate demos...${NC}"

# Set PATH for VHS
export PATH="$HOME/bin:$PATH"

# Generate Python API demo
echo -e "${YELLOW}Generating Python API demo...${NC}"
vhs demo/python_api.tape
echo -e "${GREEN}✓ Python API demo complete!${NC}"

# Generate Query CLI demo
echo -e "${YELLOW}Generating Query CLI demo...${NC}"
vhs demo/query_cli.tape
echo -e "${GREEN}✓ Query CLI demo complete!${NC}"

# Generate Shell TUI demo
echo -e "${YELLOW}Generating Interactive Shell demo...${NC}"
vhs demo/shell_tui.tape
echo -e "${GREEN}✓ Interactive Shell demo complete!${NC}"

echo -e "${GREEN}✓ All demos generated successfully!${NC}"
echo -e "${BLUE}Demo files:${NC}"
echo -e "  - demo/python_api.mp4"
echo -e "  - demo/query_cli.mp4"
echo -e "  - demo/shell_tui.mp4"
