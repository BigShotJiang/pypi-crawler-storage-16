"""
sqtab package initializer.
"""
