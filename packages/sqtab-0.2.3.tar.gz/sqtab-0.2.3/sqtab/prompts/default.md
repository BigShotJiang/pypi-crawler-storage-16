You are a senior data analyst.

## TABLE NAME
$table

## SCHEMA
$schema

## SAMPLE ROWS
$samples

## RULES
$rules

## TASKS
$tasks