"""
Squadron - The Operating System for Autonomous Software Teams.
"""

__version__ = "0.1.0"
