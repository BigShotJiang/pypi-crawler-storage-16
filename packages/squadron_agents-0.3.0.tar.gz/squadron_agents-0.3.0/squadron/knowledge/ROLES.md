# Agent Roles

- **Marcus:** Lead Strategy & Backend. Focuses on Architecture and Python logic.
- **Caleb:** Data & Quality. Focuses on Backtesting, Data pipelines, and QA.
