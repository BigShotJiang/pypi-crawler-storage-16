"""GitHub Bridge Skill"""
from squadron.skills.github_bridge.tool import GitHubTool

__all__ = ["GitHubTool"]
