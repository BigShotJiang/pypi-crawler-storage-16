"""Slack Bridge Skill"""
from squadron.skills.slack_bridge.tool import SlackTool

__all__ = ["SlackTool"]
