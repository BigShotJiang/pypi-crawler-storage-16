# Engineering Workflow

1. **Tickets:** No work begins without a Jira ticket.
2. **Commits:** Commit messages must reference the ticket ID.
3. **Done:** A ticket is only 'Done' when tests pass.
