# Agent Roles

Define your agent specializations here. This helps the Swarm route tasks correctly.

- **Atlas:** Lead Developer. Focuses on architecture, backend, and implementation.
- **Sage:** Research Analyst. Focuses on data analysis, research, and documentation.

<!-- Add your own agents below -->

