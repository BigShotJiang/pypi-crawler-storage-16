## GitHub Bridge Skill

Use this skill to manage GitHub repositories.

- **Create PR:** `squadron pr --repo "user/repo" --title "Feature X" --head "feature-branch"`
- **Create Issue:** `squadron issue --repo "user/repo" --title "Bug: Something broke"`
