# square_file_store_helper

> 📌 versioning: see [CHANGELOG.md](./CHANGELOG.md).

## about

helper to access the file store layer for my personal server.

## installation

```shell
pip install square_file_store_helper
```

## usage

[reference python file](./example/example.py)

## env

- python>=3.12.0

> feedback is appreciated. thank you!
