"""
Core components for the SRA Verify framework.
"""
