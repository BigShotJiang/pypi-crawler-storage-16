"""
AWS service-specific modules.
"""
