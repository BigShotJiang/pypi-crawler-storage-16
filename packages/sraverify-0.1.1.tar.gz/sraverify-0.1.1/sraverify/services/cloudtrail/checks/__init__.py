"""CloudTrail security checks."""
