"""EC2 security checks."""
