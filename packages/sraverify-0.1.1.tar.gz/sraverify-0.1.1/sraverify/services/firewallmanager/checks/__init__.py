# Firewall Manager checks
