"""
GuardDuty security check implementations.
"""
