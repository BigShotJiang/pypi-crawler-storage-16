"""
Inspector security checks.
"""
