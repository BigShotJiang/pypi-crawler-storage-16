"""Security Lake checks."""
