"""
Utility functions for the SRA Verify framework.
"""
