"""
Srcly FastAPI application package.

This file marks the `app` directory as a Python package so that the
`app.run:main` console script entry point works correctly when the
project is built and installed from its wheel.
"""


