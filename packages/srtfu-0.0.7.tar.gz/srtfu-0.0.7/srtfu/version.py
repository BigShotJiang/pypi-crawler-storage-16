MAJOR = 0
MINOR = 0
MINI =  7

version = f"{MAJOR}.{MINOR}.{MINI}"
