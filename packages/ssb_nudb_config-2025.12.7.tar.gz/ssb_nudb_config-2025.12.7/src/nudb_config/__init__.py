"""Config of metadata for functions used in ssb-nudb-use."""

from .config import settings

__all__ = ["settings"]
