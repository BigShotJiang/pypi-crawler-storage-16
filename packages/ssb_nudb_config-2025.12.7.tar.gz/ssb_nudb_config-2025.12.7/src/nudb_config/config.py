from nudb_config.pydantic.load import load_pydantic_settings

settings = load_pydantic_settings()
