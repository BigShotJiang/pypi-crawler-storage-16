"""Helpers for working with specific NUDB variable validations."""
