# Ssebidethon

A lightweight interpreted programming language built in Python, featuring arithmetic operations, variables, conditionals, and loops.

## Installation

### From PyPI (once published)
```bash
pip install ssebidethon
```

### From Source
```bash
git clone https://github.com/yourusername/ssebidethon.git
cd ssebidethon
pip install -e .
```

### Standalone Executable
Download the latest release from the [Releases](https://github.com/yourusername/ssebidethon/releases) page.

## Usage

### Interactive Shell
```bash
# If installed via pip
ssebidethon

# Or run as module
python -m ssebidethon

# Or run directly from source
python shell.py
```

### Example Session
```
Ssebidethon v0.1.0
Type 'exit' to quit.

>>> 5 + 3
8
>>> make x = 10
{'x': 10}
>>> x * 2
20
>>> exit
Goodbye!
```

## Language Features

### Arithmetic
```
5 + 3          # 8
10 - 4         # 6
6 * 7          # 42
20 / 4         # 5.0
(2 + 3) * 4    # 20
```

### Variables
```
make x = 10
make y = x * 2
x + y          # 30
```

### Comparisons
```
5 > 3          # 1 (true)
5 < 3          # 0 (false)
5 ?= 5         # 1 (equality check)
5 >= 5         # 1
5 <= 3         # 0
```

### Boolean Logic
```
1 and 1        # 1
1 and 0        # 0
1 or 0         # 1
not 0          # 1
```

### Conditionals
```
if x > 5 do x * 2
if x > 10 do 100 elif x > 5 do 50 else do 0
```

### Loops
```
while x > 0 do make x = x - 1
```

## Development

### Project Structure
```
ssebidethon/
├── __init__.py      # Package exports
├── __main__.py      # Module entry point
├── shell.py         # Interactive REPL
├── lexer.py         # Tokenizer
├── tokens.py        # Token definitions
├── parse.py         # Parser (AST generation)
├── interpreter.py   # Tree-walking interpreter
└── data.py          # Variable storage
```

### Building from Source
```bash
# Install build tools
pip install build

# Build the package
python -m build

# Install locally
pip install dist/ssebidethon-0.1.0-py3-none-any.whl
```

### Creating Standalone Executable
```bash
pip install pyinstaller
pyinstaller --onefile --name ssebidethon ssebidethon/__main__.py
```
The executable will be in the `dist/` folder.

### Publishing to PyPI
```bash
pip install twine
python -m build
twine upload dist/*
```

## License

MIT
