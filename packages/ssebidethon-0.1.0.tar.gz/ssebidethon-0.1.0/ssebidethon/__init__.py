"""Ssebidethon - A lightweight interpreted programming language."""

__version__ = "0.1.0"

from ssebidethon.lexer import Lexer
from ssebidethon.parse import Parser
from ssebidethon.interpreter import Interpreter
from ssebidethon.data import Data

__all__ = ["Lexer", "Parser", "Interpreter", "Data"]
