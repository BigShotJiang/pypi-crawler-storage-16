#!/usr/bin/env python3
"""Entry point for running Ssebidethon as a module: python -m ssebidethon"""

from ssebidethon.shell import main

if __name__ == "__main__":
    main()
