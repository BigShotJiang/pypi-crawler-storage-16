#!/usr/bin/env python3
"""Interactive shell for Ssebidethon."""

from ssebidethon.lexer import Lexer
from ssebidethon.parse import Parser
from ssebidethon.interpreter import Interpreter
from ssebidethon.data import Data


def main():
    """Run the interactive Ssebidethon shell."""
    print("Ssebidethon v0.1.0")
    print("Type 'exit' to quit.\n")
    
    base = Data()

    while True:
        try:
            text = input(">>> ")
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not text.strip():
            continue
        if text.strip().lower() == "exit":
            print("Goodbye!")
            break

        try:
            tokenizer = Lexer(text)
            tokens = tokenizer.tokenize()

            parser = Parser(tokens)
            tree = parser.parse()

            interpreter = Interpreter(tree, base)
            result = interpreter.interpret()
            if result is not None:
                print(result)
        except Exception as e:
            print(f"Error: {e}")


if __name__ == "__main__":
    main()
