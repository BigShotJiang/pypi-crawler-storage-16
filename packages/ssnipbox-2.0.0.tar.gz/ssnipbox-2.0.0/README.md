# ssnipbox

**ssnipbox** is a lightweight Python package that provides ready-to-use code snippets for questions Q1–Q13.  
Each snippet is returned as plain text through simple function calls.

---

## 📦 Installation

Install ssnipbox from PyPI:

```bash
pip install ssnipbox
