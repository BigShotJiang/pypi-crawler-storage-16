"""Non-core functionality for SSSOM."""
