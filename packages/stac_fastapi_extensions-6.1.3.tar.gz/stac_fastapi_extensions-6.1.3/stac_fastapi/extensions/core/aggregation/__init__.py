"""Aggregation extension module."""

from .aggregation import AggregationConformanceClasses, AggregationExtension

__all__ = ["AggregationExtension", "AggregationConformanceClasses"]
