"""Fields extension module."""

from .fields import FieldsConformanceClasses, FieldsExtension

__all__ = ["FieldsExtension", "FieldsConformanceClasses"]
