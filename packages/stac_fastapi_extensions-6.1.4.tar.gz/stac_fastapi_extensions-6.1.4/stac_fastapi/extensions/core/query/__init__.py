"""Query extension module."""

from .query import QueryConformanceClasses, QueryExtension

__all__ = ["QueryExtension", "QueryConformanceClasses"]
