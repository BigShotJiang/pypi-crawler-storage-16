---
name: Bug report
about: Bug reports only please! 💛
labels: [bug]
---

<!--

Please use issues ONLY for BUGS.

For questions, please use <https://github.com/hynek/stamina/discussions/categories/q-a>

For feature requests, please use <https://github.com/hynek/stamina/discussions/categories/ideas>

Thank you!

-->
