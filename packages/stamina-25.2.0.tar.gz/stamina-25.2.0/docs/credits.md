# Credits

```{include} ../README.md
:start-after: "## Credits"
```
