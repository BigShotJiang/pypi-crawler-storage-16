from django.dispatch import Signal



notifire = Signal()
send_sms = Signal()
send_mail = Signal()
