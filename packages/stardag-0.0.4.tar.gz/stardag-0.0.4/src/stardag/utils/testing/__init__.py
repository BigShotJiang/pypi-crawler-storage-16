from stardag._base import auto_namespace

auto_namespace(__name__)  # set the namespace for this module to the module import path
