# STARK
STARK: Spatial Transcriptomics via Adaptive Regularization and Kernels
