from .stark import *


# Define version here
__version__ = '0.1.0'

# Command reminder for building the package
# Need: pip install build twine
# For upload with twine, username and passord are already stored in ~/.pypirc
# python3 -m build
# python3 -m twine upload --skip-existing dist/*
