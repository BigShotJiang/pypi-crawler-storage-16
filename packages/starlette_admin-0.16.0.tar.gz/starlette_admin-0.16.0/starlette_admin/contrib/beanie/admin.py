from starlette_admin.base import BaseAdmin


class Admin(BaseAdmin):
    pass
