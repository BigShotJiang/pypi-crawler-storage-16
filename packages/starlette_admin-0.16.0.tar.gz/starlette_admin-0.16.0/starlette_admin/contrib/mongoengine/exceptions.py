from starlette_admin.exceptions import StarletteAdminException


class NotSupportedField(StarletteAdminException):
    pass
