from starlette_admin.exceptions import StarletteAdminException


class NotSupportedAnnotation(StarletteAdminException):
    pass
