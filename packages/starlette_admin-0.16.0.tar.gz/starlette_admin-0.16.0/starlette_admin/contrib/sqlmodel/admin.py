from starlette_admin.contrib.sqla.admin import Admin as BaseAdmin


class Admin(BaseAdmin):
    pass
