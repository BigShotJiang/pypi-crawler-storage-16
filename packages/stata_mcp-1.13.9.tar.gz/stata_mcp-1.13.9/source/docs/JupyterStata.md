# Jupyter Stata

If you want to use jupyter for coding Stata, you can use a extension named [`nbstata`](https://github.com/hugetim/nbstata).

First, you need to install `nbstata` in VScode or whatever IDE you want to use.

Then, config it and use it.

More information you can find in the listed links:
- [docs by the author](https://hugetim.github.io/nbstata)
- [lianxh blog (连享会)](https://www.lianxh.cn/details/1309.html)
