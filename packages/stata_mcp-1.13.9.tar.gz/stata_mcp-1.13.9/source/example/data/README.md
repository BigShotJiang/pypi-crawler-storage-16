If you want to find the example data, you can visit the follow URL to fetch data.

## Example Data URL LIST

| ID | File Name                | URL                                                           |
|----|--------------------------|---------------------------------------------------------------|
| 01 | OLS.dta                  | https://example-data.statamcp.com/01_OLS.dta                  |
| 02 | Tax_Reform_std_DID.dta   | https://example-data.statamcp.com/02_Tax_Reform_std_DID.dta   |
| 03 | Tax_SDID.dta             | https://example-data.statamcp.com/03_Tax_SDID.dta             |
| 04 | Education_Wage_RDD.dta   | https://example-data.statamcp.com/04_Education_Wage_RDD.dta   |
| 05 | Education_Returns_IV.dta | https://example-data.statamcp.com/05_Education_Returns_IV.dta |