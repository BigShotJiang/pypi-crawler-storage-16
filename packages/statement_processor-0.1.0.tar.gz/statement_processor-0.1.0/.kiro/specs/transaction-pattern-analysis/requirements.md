# Requirements Document

## Introduction

This feature provides a framework for analyzing vendor transactions using pluggable strategies. Given a set of transactions from a single vendor (output from vendor-analysis), it applies multiple analysis strategies and combines their results using configurable weights to produce an overall probability score. The framework is designed to be extensible so new analysis techniques can be added over time.

## Glossary

- **Vendor_Transactions**: A pandas DataFrame containing all transactions for a single vendor/description
- **Strategy_Runner**: The main component that orchestrates analysis strategies and combines results
- **Detection_Strategy**: A pluggable algorithm that analyzes transactions and returns a probability score
- **Strategy_Result**: The output from a single strategy containing probability (0.0-1.0), matching transaction indices, and metadata
- **Combined_Result**: The weighted combination of all strategy results into a final probability score

## Requirements

### Requirement 1

**User Story:** As a user, I want a framework for analyzing vendor transactions with multiple strategies, so that I can identify patterns with high confidence.

#### Acceptance Criteria

1. WHEN vendor transactions are provided to the Strategy_Runner THEN the Strategy_Runner SHALL apply all registered analysis strategies
2. WHEN a strategy is registered THEN the Strategy_Runner SHALL store the strategy with its associated weight
3. WHEN all strategies have been applied THEN the Strategy_Runner SHALL combine results using the configured weights
4. WHEN combining results THEN the Strategy_Runner SHALL produce a final probability score between 0.0 and 1.0

### Requirement 2

**User Story:** As a user, I want to configure weights for each strategy, so that I can tune the importance of different techniques.

#### Acceptance Criteria

1. WHEN registering a strategy THEN the Strategy_Runner SHALL accept an optional weight parameter (default 1.0)
2. WHEN combining strategy results THEN the Strategy_Runner SHALL apply weighted averaging based on configured weights
3. WHEN a strategy returns no result THEN the Strategy_Runner SHALL exclude that strategy from the weighted calculation
4. WHEN all strategies return no result THEN the Strategy_Runner SHALL return a probability of 0.0

### Requirement 3

**User Story:** As a user, I want strategies to follow a common interface, so that new techniques can be easily added.

#### Acceptance Criteria

1. WHEN implementing a strategy THEN the Detection_Strategy SHALL implement a detect method accepting a DataFrame of transactions
2. WHEN a strategy analyzes transactions THEN the Detection_Strategy SHALL return a Strategy_Result with probability, matching transaction indices, and optional metadata
3. WHEN a strategy cannot determine a pattern THEN the Detection_Strategy SHALL return None to indicate no opinion
4. WHEN a strategy encounters an error THEN the Detection_Strategy SHALL log the error and return None

### Requirement 4

**User Story:** As a user, I want the combined result to include details from contributing strategies, so that I can understand why a pattern was detected.

#### Acceptance Criteria

1. WHEN returning the combined result THEN the Strategy_Runner SHALL include the final weighted probability score
2. WHEN returning the combined result THEN the Strategy_Runner SHALL include individual strategy results with their weights
3. WHEN a strategy returns a result THEN the Strategy_Result SHALL include the indices of transactions that matched the pattern

