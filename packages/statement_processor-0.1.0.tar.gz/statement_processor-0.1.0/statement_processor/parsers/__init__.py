"""Built-in statement parsers.

This package contains the built-in parsers that ship with statement-processor.
Additional parsers can be installed as plugins.
"""

from statement_processor.parsers.markdown_table import MarkdownTableParser

__all__ = ["MarkdownTableParser"]
