"""Deprecated shim for ``stateset_agents.api.dependencies``."""

from stateset_agents.api.dependencies import *  # noqa: F401, F403

