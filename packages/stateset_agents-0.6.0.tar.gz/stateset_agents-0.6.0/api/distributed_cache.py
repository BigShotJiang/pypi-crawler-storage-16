"""Deprecated shim for ``stateset_agents.api.distributed_cache``."""

from stateset_agents.api.distributed_cache import *  # noqa: F401, F403

