"""Deprecated shim for ``stateset_agents.api.grpo``."""

from stateset_agents.api.grpo import *  # noqa: F401, F403

