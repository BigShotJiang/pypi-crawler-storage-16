"""Deprecated shim for ``stateset_agents.api.grpo.config``."""

from stateset_agents.api.grpo.config import *  # noqa: F401, F403

