"""Deprecated shim for ``stateset_agents.api.grpo.handlers``."""

from stateset_agents.api.grpo.handlers import *  # noqa: F401, F403

