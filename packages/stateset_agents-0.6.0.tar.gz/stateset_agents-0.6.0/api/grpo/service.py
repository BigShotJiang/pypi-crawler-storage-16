"""Deprecated shim for ``stateset_agents.api.grpo.service``."""

from stateset_agents.api.grpo.service import *  # noqa: F401, F403

