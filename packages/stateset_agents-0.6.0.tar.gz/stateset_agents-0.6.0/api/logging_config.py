"""Deprecated shim for ``stateset_agents.api.logging_config``."""

from stateset_agents.api.logging_config import *  # noqa: F401, F403

