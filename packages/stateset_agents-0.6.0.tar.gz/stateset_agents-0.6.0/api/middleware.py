"""Deprecated shim for ``stateset_agents.api.middleware``."""

from stateset_agents.api.middleware import *  # noqa: F401, F403

