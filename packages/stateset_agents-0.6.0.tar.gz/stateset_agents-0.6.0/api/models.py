"""Deprecated shim for ``stateset_agents.api.models``."""

from stateset_agents.api.models import *  # noqa: F401, F403

