"""Deprecated shim for ``stateset_agents.api.observability``."""

from stateset_agents.api.observability import *  # noqa: F401, F403

