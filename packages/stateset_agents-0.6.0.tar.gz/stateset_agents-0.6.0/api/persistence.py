"""Deprecated shim for ``stateset_agents.api.persistence``."""

from stateset_agents.api.persistence import *  # noqa: F401, F403

