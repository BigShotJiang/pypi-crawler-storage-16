"""Deprecated shim for ``stateset_agents.api.resilience``."""

from stateset_agents.api.resilience import *  # noqa: F401, F403

