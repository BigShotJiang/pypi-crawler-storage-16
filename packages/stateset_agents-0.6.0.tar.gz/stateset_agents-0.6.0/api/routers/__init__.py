"""Deprecated shim for ``stateset_agents.api.routers``."""

from stateset_agents.api.routers import *  # noqa: F401, F403

