"""Deprecated shim for ``stateset_agents.api.routers.agents``."""

from stateset_agents.api.routers.agents import *  # noqa: F401, F403

