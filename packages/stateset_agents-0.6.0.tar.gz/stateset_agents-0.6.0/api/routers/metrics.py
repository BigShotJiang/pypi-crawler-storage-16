"""Deprecated shim for ``stateset_agents.api.routers.metrics``."""

from stateset_agents.api.routers.metrics import *  # noqa: F401, F403

