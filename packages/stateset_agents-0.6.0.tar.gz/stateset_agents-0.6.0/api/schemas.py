"""Deprecated shim for ``stateset_agents.api.schemas``."""

from stateset_agents.api.schemas import *  # noqa: F401, F403

