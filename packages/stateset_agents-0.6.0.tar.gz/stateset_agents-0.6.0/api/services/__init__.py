"""Deprecated shim for ``stateset_agents.api.services``."""

from stateset_agents.api.services import *  # noqa: F401, F403

