"""Deprecated shim for ``stateset_agents.api.services.auth_service``."""

from stateset_agents.api.services.auth_service import *  # noqa: F401, F403

