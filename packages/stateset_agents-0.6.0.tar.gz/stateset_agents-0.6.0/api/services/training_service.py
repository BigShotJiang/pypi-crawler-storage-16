"""Deprecated shim for ``stateset_agents.api.services.training_service``."""

from stateset_agents.api.services.training_service import *  # noqa: F401, F403

