"""Deprecated shim for ``stateset_agents.core.agent``."""

from stateset_agents.core.agent import *  # noqa: F401, F403

