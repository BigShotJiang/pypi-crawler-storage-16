"""Deprecated shim for ``stateset_agents.core.basic_rewards``."""

from stateset_agents.core.basic_rewards import *  # noqa: F401, F403

