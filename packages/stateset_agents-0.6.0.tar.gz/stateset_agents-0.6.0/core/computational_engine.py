"""Deprecated shim for ``stateset_agents.core.computational_engine``."""

from stateset_agents.core.computational_engine import *  # noqa: F401, F403

