"""Deprecated shim for ``stateset_agents.core.enhanced.enhanced_agent``."""

from stateset_agents.core.enhanced.enhanced_agent import *  # noqa: F401, F403

