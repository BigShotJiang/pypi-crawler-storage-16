"""Deprecated shim for ``stateset_agents.core.error_handling``."""

from stateset_agents.core.error_handling import *  # noqa: F401, F403

