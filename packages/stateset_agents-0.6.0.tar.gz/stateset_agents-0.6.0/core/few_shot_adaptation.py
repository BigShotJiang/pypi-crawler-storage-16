"""Deprecated shim for ``stateset_agents.core.few_shot_adaptation``."""

from stateset_agents.core.few_shot_adaptation import *  # noqa: F401, F403

