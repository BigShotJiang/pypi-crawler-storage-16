"""Deprecated shim for ``stateset_agents.core.function_calling``."""

from stateset_agents.core.function_calling import *  # noqa: F401, F403

