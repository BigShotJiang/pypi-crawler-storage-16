"""Deprecated shim for ``stateset_agents.core.gym.adapter``."""

from stateset_agents.core.gym.adapter import *  # noqa: F401, F403

