"""Deprecated shim for ``stateset_agents.core.gym.mappers``."""

from stateset_agents.core.gym.mappers import *  # noqa: F401, F403

