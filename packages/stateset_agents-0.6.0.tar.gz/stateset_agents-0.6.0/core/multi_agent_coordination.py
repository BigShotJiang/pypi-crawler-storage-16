"""Deprecated shim for ``stateset_agents.core.multi_agent_coordination``."""

from stateset_agents.core.multi_agent_coordination import *  # noqa: F401, F403

