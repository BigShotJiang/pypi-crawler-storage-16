"""Deprecated shim for ``stateset_agents.core.multiturn_agent``."""

from stateset_agents.core.multiturn_agent import *  # noqa: F401, F403

