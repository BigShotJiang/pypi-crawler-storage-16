"""Deprecated shim for ``stateset_agents.core.neural_architecture_search``."""

from stateset_agents.core.neural_architecture_search import *  # noqa: F401, F403

