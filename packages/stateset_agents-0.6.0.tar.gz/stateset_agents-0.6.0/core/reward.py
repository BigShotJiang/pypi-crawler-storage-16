"""Deprecated shim for ``stateset_agents.core.reward``."""

from stateset_agents.core.reward import *  # noqa: F401, F403

