"""Deprecated shim for ``stateset_agents.core.reward_base``."""

from stateset_agents.core.reward_base import *  # noqa: F401, F403

