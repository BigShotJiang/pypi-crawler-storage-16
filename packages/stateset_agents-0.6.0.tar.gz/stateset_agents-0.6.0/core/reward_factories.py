"""Deprecated shim for ``stateset_agents.core.reward_factories``."""

from stateset_agents.core.reward_factories import *  # noqa: F401, F403

