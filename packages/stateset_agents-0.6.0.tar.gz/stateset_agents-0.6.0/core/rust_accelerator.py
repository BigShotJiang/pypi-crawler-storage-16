"""Deprecated shim for ``stateset_agents.core.rust_accelerator``."""

from stateset_agents.core.rust_accelerator import *  # noqa: F401, F403

