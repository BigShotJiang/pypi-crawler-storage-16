"""Deprecated shim for ``stateset_agents.core.structured_output``."""

from stateset_agents.core.structured_output import *  # noqa: F401, F403

