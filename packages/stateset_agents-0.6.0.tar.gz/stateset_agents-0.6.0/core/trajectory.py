"""Deprecated shim for ``stateset_agents.core.trajectory``."""

from stateset_agents.core.trajectory import *  # noqa: F401, F403

