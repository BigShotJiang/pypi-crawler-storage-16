"""Deprecated shim for ``stateset_agents.core.type_system``."""

from stateset_agents.core.type_system import *  # noqa: F401, F403

