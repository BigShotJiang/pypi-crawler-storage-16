"""Deprecated shim for ``stateset_agents.rewards.bayesian_reward_model``."""

from stateset_agents.rewards.bayesian_reward_model import *  # noqa: F401, F403

