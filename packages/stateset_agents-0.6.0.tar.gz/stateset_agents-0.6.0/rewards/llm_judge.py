"""Deprecated shim for ``stateset_agents.rewards.llm_judge``."""

from stateset_agents.rewards.llm_judge import *  # noqa: F401, F403

