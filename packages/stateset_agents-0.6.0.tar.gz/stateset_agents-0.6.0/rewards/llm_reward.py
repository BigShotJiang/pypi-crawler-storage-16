"""Deprecated shim for ``stateset_agents.rewards.llm_reward``."""

from stateset_agents.rewards.llm_reward import *  # noqa: F401, F403

