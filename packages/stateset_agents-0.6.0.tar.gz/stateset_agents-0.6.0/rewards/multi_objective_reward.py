"""Deprecated shim for ``stateset_agents.rewards.multi_objective_reward``."""

from stateset_agents.rewards.multi_objective_reward import *  # noqa: F401, F403

