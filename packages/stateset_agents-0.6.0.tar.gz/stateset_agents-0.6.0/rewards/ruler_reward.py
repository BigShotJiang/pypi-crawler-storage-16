"""Deprecated shim for ``stateset_agents.rewards.ruler_reward``."""

from stateset_agents.rewards.ruler_reward import *  # noqa: F401, F403

