"""Deprecated shim for ``stateset_agents.training.diagnostics``."""

from stateset_agents.training.diagnostics import *  # noqa: F401, F403

