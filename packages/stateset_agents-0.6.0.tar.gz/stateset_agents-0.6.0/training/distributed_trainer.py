"""Deprecated shim for ``stateset_agents.training.distributed_trainer``."""

from stateset_agents.training.distributed_trainer import *  # noqa: F401, F403

