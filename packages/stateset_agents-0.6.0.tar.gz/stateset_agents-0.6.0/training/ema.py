"""Deprecated shim for ``stateset_agents.training.ema``."""

from stateset_agents.training.ema import *  # noqa: F401, F403

