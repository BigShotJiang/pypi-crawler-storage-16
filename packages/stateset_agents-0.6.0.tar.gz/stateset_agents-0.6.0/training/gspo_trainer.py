"""Deprecated shim for ``stateset_agents.training.gspo_trainer``."""

from stateset_agents.training.gspo_trainer import *  # noqa: F401, F403

