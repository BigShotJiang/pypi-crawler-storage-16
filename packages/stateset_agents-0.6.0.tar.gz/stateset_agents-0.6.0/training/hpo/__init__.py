"""Deprecated shim for ``stateset_agents.training.hpo``."""

from stateset_agents.training.hpo import *  # noqa: F401, F403

