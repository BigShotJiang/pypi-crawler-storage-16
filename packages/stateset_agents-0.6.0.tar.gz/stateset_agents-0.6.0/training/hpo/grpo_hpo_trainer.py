"""Deprecated shim for ``stateset_agents.training.hpo.grpo_hpo_trainer``."""

from stateset_agents.training.hpo.grpo_hpo_trainer import *  # noqa: F401, F403

