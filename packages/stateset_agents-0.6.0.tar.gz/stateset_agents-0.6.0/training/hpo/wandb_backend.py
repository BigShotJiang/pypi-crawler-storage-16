"""Deprecated shim for ``stateset_agents.training.hpo.wandb_backend``."""

from stateset_agents.training.hpo.wandb_backend import *  # noqa: F401, F403

