"""Deprecated shim for ``stateset_agents.training.kl_controllers``."""

from stateset_agents.training.kl_controllers import *  # noqa: F401, F403

