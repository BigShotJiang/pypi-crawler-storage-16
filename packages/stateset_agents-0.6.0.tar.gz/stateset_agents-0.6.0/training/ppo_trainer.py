"""Deprecated shim for ``stateset_agents.training.ppo_trainer``."""

from stateset_agents.training.ppo_trainer import *  # noqa: F401, F403

