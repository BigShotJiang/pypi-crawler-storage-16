"""Deprecated shim for ``stateset_agents.training.reward_calibration``."""

from stateset_agents.training.reward_calibration import *  # noqa: F401, F403

