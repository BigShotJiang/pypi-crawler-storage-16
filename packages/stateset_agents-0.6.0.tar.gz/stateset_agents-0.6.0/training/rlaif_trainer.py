"""Deprecated shim for ``stateset_agents.training.rlaif_trainer``."""

from stateset_agents.training.rlaif_trainer import *  # noqa: F401, F403

