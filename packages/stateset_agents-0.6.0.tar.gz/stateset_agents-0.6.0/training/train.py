"""Deprecated shim for ``stateset_agents.training.train``."""

from stateset_agents.training.train import *  # noqa: F401, F403

