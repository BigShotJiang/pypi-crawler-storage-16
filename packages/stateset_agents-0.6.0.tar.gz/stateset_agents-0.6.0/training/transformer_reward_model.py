"""Deprecated shim for ``stateset_agents.training.transformer_reward_model``."""

from stateset_agents.training.transformer_reward_model import *  # noqa: F401, F403

