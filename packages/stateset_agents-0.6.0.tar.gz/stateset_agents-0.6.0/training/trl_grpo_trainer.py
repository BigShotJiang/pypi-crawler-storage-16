"""Deprecated shim for ``stateset_agents.training.trl_grpo_trainer``."""

from stateset_agents.training.trl_grpo_trainer import *  # noqa: F401, F403

