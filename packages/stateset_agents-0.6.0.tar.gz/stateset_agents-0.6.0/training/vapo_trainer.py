"""Deprecated shim for ``stateset_agents.training.vapo_trainer``."""

from stateset_agents.training.vapo_trainer import *  # noqa: F401, F403

