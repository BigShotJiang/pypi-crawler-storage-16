"""Deprecated shim for ``stateset_agents.training.vllm_backend``."""

from stateset_agents.training.vllm_backend import *  # noqa: F401, F403

