"""Deprecated shim for ``stateset_agents.utils.advanced_dashboard``."""

from stateset_agents.utils.advanced_dashboard import *  # noqa: F401, F403

