"""Deprecated shim for ``stateset_agents.utils.logging``."""

from stateset_agents.utils.logging import *  # noqa: F401, F403

