"""Deprecated shim for ``stateset_agents.utils.observability``."""

from stateset_agents.utils.observability import *  # noqa: F401, F403

