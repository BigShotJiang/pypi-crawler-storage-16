"""Deprecated shim for ``stateset_agents.utils.performance_monitor``."""

from stateset_agents.utils.performance_monitor import *  # noqa: F401, F403

