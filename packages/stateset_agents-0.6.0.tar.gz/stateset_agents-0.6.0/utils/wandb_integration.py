"""Deprecated shim for ``stateset_agents.utils.wandb_integration``."""

from stateset_agents.utils.wandb_integration import *  # noqa: F401, F403

