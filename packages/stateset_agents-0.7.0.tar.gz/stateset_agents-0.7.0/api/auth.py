"""Deprecated shim for ``stateset_agents.api.auth``."""

from stateset_agents.api.auth import *  # noqa: F401, F403

