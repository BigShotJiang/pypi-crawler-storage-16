"""Deprecated shim for ``stateset_agents.api.cache``."""

from stateset_agents.api.cache import *  # noqa: F401, F403

