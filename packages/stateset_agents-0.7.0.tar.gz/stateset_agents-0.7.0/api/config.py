"""Deprecated shim for ``stateset_agents.api.config``."""

from stateset_agents.api.config import *  # noqa: F401, F403

