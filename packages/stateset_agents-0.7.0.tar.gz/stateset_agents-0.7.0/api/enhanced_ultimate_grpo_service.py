"""Deprecated shim for ``stateset_agents.api.enhanced_ultimate_grpo_service``."""

from stateset_agents.api.enhanced_ultimate_grpo_service import *  # noqa: F401, F403

