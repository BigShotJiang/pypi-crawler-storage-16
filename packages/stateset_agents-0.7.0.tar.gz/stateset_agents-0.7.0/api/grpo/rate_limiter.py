"""Deprecated shim for ``stateset_agents.api.grpo.rate_limiter``."""

from stateset_agents.api.grpo.rate_limiter import *  # noqa: F401, F403

