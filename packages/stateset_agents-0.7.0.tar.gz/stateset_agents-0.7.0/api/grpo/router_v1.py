"""Deprecated shim for ``stateset_agents.api.grpo.router_v1``."""

from stateset_agents.api.grpo.router_v1 import *  # noqa: F401, F403

