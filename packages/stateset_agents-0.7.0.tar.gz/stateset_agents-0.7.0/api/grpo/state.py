"""Deprecated shim for ``stateset_agents.api.grpo.state``."""

from stateset_agents.api.grpo.state import *  # noqa: F401, F403

