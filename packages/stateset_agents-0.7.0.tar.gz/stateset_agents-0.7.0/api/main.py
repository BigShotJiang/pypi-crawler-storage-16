"""Deprecated shim for ``stateset_agents.api.main``."""

from stateset_agents.api.main import *  # noqa: F401, F403

