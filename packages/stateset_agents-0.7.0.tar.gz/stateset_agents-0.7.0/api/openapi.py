"""Deprecated shim for ``stateset_agents.api.openapi``."""

from stateset_agents.api.openapi import *  # noqa: F401, F403

