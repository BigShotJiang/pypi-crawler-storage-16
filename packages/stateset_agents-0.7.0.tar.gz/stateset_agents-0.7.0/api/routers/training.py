"""Deprecated shim for ``stateset_agents.api.routers.training``."""

from stateset_agents.api.routers.training import *  # noqa: F401, F403

