"""Deprecated shim for ``stateset_agents.api.services.agent_service``."""

from stateset_agents.api.services.agent_service import *  # noqa: F401, F403

