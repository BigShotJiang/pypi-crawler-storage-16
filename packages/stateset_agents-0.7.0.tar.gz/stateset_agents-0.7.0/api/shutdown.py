"""Deprecated shim for ``stateset_agents.api.shutdown``."""

from stateset_agents.api.shutdown import *  # noqa: F401, F403

