"""Deprecated shim for ``stateset_agents.api.streaming``."""

from stateset_agents.api.streaming import *  # noqa: F401, F403

