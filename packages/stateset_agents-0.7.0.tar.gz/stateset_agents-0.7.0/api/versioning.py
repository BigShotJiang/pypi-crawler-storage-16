"""Deprecated shim for ``stateset_agents.api.versioning``."""

from stateset_agents.api.versioning import *  # noqa: F401, F403

