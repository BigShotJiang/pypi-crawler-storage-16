"""Deprecated shim for ``stateset_agents.core.async_pool``."""

from stateset_agents.core.async_pool import *  # noqa: F401, F403

