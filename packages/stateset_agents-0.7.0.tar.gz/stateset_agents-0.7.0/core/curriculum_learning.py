"""Deprecated shim for ``stateset_agents.core.curriculum_learning``."""

from stateset_agents.core.curriculum_learning import *  # noqa: F401, F403

