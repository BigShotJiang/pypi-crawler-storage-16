"""Deprecated shim for ``stateset_agents.core.data_processing``."""

from stateset_agents.core.data_processing import *  # noqa: F401, F403

