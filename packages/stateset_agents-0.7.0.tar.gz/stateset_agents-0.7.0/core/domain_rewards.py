"""Deprecated shim for ``stateset_agents.core.domain_rewards``."""

from stateset_agents.core.domain_rewards import *  # noqa: F401, F403

