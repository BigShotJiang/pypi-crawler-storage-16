"""Deprecated shim for ``stateset_agents.core.environment``."""

from stateset_agents.core.environment import *  # noqa: F401, F403

