"""Deprecated shim for ``stateset_agents.core.evaluation``."""

from stateset_agents.core.evaluation import *  # noqa: F401, F403

