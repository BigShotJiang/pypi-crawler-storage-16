"""Deprecated shim for ``stateset_agents.core.gym``."""

from stateset_agents.core.gym import *  # noqa: F401, F403

