"""Deprecated shim for ``stateset_agents.core.input_validation``."""

from stateset_agents.core.input_validation import *  # noqa: F401, F403

