"""Deprecated shim for ``stateset_agents.core.intelligent_orchestrator``."""

from stateset_agents.core.intelligent_orchestrator import *  # noqa: F401, F403

