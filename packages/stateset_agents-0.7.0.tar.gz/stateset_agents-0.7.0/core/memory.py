"""Deprecated shim for ``stateset_agents.core.memory``."""

from stateset_agents.core.memory import *  # noqa: F401, F403

