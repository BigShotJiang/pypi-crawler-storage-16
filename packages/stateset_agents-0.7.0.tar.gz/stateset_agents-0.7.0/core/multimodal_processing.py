"""Deprecated shim for ``stateset_agents.core.multimodal_processing``."""

from stateset_agents.core.multimodal_processing import *  # noqa: F401, F403

