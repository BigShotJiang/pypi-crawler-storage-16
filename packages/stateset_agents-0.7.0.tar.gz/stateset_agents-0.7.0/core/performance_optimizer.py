"""Deprecated shim for ``stateset_agents.core.performance_optimizer``."""

from stateset_agents.core.performance_optimizer import *  # noqa: F401, F403

