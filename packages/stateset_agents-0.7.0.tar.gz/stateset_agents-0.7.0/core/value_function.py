"""Deprecated shim for ``stateset_agents.core.value_function``."""

from stateset_agents.core.value_function import *  # noqa: F401, F403

