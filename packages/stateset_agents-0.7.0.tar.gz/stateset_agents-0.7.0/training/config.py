"""Deprecated shim for ``stateset_agents.training.config``."""

from stateset_agents.training.config import *  # noqa: F401, F403

