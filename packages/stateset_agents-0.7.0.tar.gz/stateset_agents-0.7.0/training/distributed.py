"""Deprecated shim for ``stateset_agents.training.distributed``."""

from stateset_agents.training.distributed import *  # noqa: F401, F403

