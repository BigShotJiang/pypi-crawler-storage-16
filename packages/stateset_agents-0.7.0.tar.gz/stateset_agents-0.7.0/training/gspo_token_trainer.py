"""Deprecated shim for ``stateset_agents.training.gspo_token_trainer``."""

from stateset_agents.training.gspo_token_trainer import *  # noqa: F401, F403

