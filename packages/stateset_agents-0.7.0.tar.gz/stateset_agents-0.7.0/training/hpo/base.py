"""Deprecated shim for ``stateset_agents.training.hpo.base``."""

from stateset_agents.training.hpo.base import *  # noqa: F401, F403

