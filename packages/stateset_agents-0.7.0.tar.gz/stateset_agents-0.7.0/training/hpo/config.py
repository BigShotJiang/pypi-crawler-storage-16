"""Deprecated shim for ``stateset_agents.training.hpo.config``."""

from stateset_agents.training.hpo.config import *  # noqa: F401, F403

