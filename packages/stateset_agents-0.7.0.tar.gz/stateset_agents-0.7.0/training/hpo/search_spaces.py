"""Deprecated shim for ``stateset_agents.training.hpo.search_spaces``."""

from stateset_agents.training.hpo.search_spaces import *  # noqa: F401, F403

