"""Deprecated shim for ``stateset_agents.training.loss_computation``."""

from stateset_agents.training.loss_computation import *  # noqa: F401, F403

