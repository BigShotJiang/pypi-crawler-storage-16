"""Deprecated shim for ``stateset_agents.training.multi_turn_trainer``."""

from stateset_agents.training.multi_turn_trainer import *  # noqa: F401, F403

