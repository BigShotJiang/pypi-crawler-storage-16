"""Deprecated shim for ``stateset_agents.utils.alerts``."""

from stateset_agents.utils.alerts import *  # noqa: F401, F403

