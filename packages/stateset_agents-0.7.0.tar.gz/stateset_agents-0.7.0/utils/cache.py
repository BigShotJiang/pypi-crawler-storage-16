"""Deprecated shim for ``stateset_agents.utils.cache``."""

from stateset_agents.utils.cache import *  # noqa: F401, F403

