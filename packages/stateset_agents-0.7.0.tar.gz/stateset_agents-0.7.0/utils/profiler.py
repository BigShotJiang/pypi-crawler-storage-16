"""Deprecated shim for ``stateset_agents.utils.profiler``."""

from stateset_agents.utils.profiler import *  # noqa: F401, F403

