class StatsigValueError(ValueError):
    pass


class StatsigRuntimeError(RuntimeError):
    pass


class StatsigNameError(NameError):
    pass


class StatsigTimeoutError(TimeoutError):
    pass
