# 如何发布到PyPI

本指南说明如何将SteinFS包发布到PyPI。

## 前置要求

1. 安装发布工具：

```bash
pip install build twine
```

2. 注册PyPI账号：
   - 生产环境：https://pypi.org/account/register/
   - 测试环境：https://test.pypi.org/account/register/

3. 配置API Token（推荐）：
   - 登录PyPI
   - 进入Account settings -> API tokens
   - 创建新token
   - 保存token（只显示一次）

## 发布步骤

### 1. 更新版本号

编辑以下文件中的版本号：
- `steinfs/__init__.py`
- `setup.py`
- `pyproject.toml`

### 2. 清理旧的构建文件

```bash
rm -rf build/ dist/ *.egg-info
```

### 3. 构建包

```bash
python -m build
```

这会在`dist/`目录创建两个文件：
- `.tar.gz` (源代码分发)
- `.whl` (wheel分发)

### 4. 测试包安装（可选）

```bash
pip install dist/steinfs-0.1.0-py3-none-any.whl
```

### 5. 上传到TestPyPI（推荐先测试）

```bash
python -m twine upload --repository testpypi dist/*
```

输入TestPyPI的用户名和密码（或使用token）。

测试安装：

```bash
pip install --index-url https://test.pypi.org/simple/ steinfs
```

### 6. 上传到正式PyPI

确认测试无误后：

```bash
python -m twine upload dist/*
```

### 7. 验证发布

```bash
pip install steinfs
```

## 使用配置文件简化发布

创建 `~/.pypirc` 文件：

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-your-api-token-here

[testpypi]
username = __token__
password = pypi-your-test-api-token-here
```

之后可以直接运行：

```bash
twine upload --repository testpypi dist/*  # 测试环境
twine upload dist/*                         # 正式环境
```

## 版本管理建议

遵循语义化版本（Semantic Versioning）：

- **主版本号(MAJOR)**: 不兼容的API变更
- **次版本号(MINOR)**: 向后兼容的功能新增
- **修订号(PATCH)**: 向后兼容的问题修正

例如：
- `0.1.0` - 初始版本
- `0.1.1` - Bug修复
- `0.2.0` - 新增功能
- `1.0.0` - 稳定版本

## 发布前检查清单

- [ ] 所有测试通过：`pytest tests/`
- [ ] 文档已更新
- [ ] CHANGELOG已更新
- [ ] 版本号已更新
- [ ] README示例可运行
- [ ] 在TestPyPI测试过
- [ ] Git已提交并打tag

## 创建Git标签

```bash
git tag -a v0.1.0 -m "Release version 0.1.0"
git push origin v0.1.0
```

## 常见问题

### 问题1: "File already exists"
**原因**: PyPI不允许重新上传相同版本
**解决**: 增加版本号后重新构建

### 问题2: 包描述显示错误
**原因**: README.md格式问题
**解决**: 
```bash
# 检查README
twine check dist/*
```

### 问题3: 依赖包版本冲突
**解决**: 在`setup.py`中明确指定依赖版本范围

### 问题4: 包大小过大
**解决**: 确保`.gitignore`和`MANIFEST.in`正确配置

## 自动化发布（GitHub Actions）

创建 `.github/workflows/publish.yml`：

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.x'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install build twine
    - name: Build package
      run: python -m build
    - name: Publish to PyPI
      env:
        TWINE_USERNAME: __token__
        TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
      run: twine upload dist/*
```

在GitHub仓库设置中添加`PYPI_API_TOKEN` secret。

## 维护建议

1. **定期更新依赖**: 保持依赖包的安全性
2. **收集用户反馈**: 通过GitHub Issues
3. **持续集成**: 使用GitHub Actions自动测试
4. **文档维护**: 保持文档与代码同步
5. **版本规划**: 维护CHANGELOG记录变更

## 资源链接

- PyPI官方文档: https://packaging.python.org/
- Twine文档: https://twine.readthedocs.io/
- Semantic Versioning: https://semver.org/
- Python打包指南: https://packaging.python.org/tutorials/packaging-projects/

