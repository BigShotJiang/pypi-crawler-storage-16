# SteinFS 快速开始指南

## 安装

```bash
pip install steinfs
```

或从源码安装：

```bash
git clone https://github.com/yourusername/steinfs.git
cd steinfs
pip install -e .
```

## 最简单的例子

```python
import numpy as np
from steinfs import SteinSelector

# 生成数据
X = np.random.randn(100, 50)  # 100个样本，50个特征
y = X[:, 0]**2 + X[:, 1]**2 + np.random.randn(100) * 0.1

# 特征选择
selector = SteinSelector(num_features=5)
X_selected = selector.fit_transform(X, y)

print(f"Selected features: {selector.selected_features_}")
print(f"Shape: {X.shape} -> {X_selected.shape}")
```

## 场景1: 低维数据 (d < 1000)

使用基础Stein方法：

```python
selector = SteinSelector(
    num_features=5,
    use_screening=False,  # 不使用screening
    distribution='gaussian'
)
X_selected = selector.fit_transform(X, y)
```

## 场景2: 高维数据 (d > 1000)

使用带screening的Stein方法：

```python
selector = SteinSelector(
    num_features=5,
    use_screening=True,  # 使用screening
    m=10,                # screening迭代次数
    delta=0.9           # 每次保留90%特征
)
X_selected = selector.fit_transform(X, y)
```

## 场景3: 重尾分布数据

使用t分布：

```python
selector = SteinSelector(
    num_features=5,
    distribution='t',
    nu=5.0  # 自由度
)
X_selected = selector.fit_transform(X, y)
```

## 场景4: 已知协方差结构

```python
# 如果知道数据有特定的相关结构
selector = SteinSelector(
    num_features=5,
    rho=0.3  # Toeplitz协方差参数
)
X_selected = selector.fit_transform(X, y)

# 或者提供自定义协方差矩阵
sigma = np.eye(50)  # 示例：单位矩阵
selector.fit(X, y, sigma=sigma)
```

## 运行示例

包含三个示例脚本：

```bash
# 基础示例
python examples/basic_example.py

# 高维数据示例
python examples/high_dimensional_example.py

# t分布示例
python examples/t_distribution_example.py
```

## 参数选择建议

### `num_features`
- 要选择的特征数量
- 建议：根据领域知识或通过交叉验证选择

### `use_screening`
- 是否使用screening
- 建议：d > 1000 时设为 True

### `m` (screening迭代次数)
- 更多迭代 = 更慢但可能更准确
- 建议：5-15之间

### `delta` (screening保留比例)
- 每次screening保留的特征比例
- 建议：0.85-0.95之间
- 更大的delta = 更保守的筛选

### `distribution`
- 数据分布类型
- 建议：默认用'gaussian'，重尾数据用't'

### `nu` (t分布自由度)
- 仅用于t分布
- 建议：3-10之间，更小的nu表示更重的尾部

## 与scikit-learn集成

```python
from sklearn.pipeline import Pipeline
from sklearn.linear_model import Ridge
from steinfs import SteinSelector

# 创建pipeline
pipeline = Pipeline([
    ('feature_selection', SteinSelector(num_features=10)),
    ('regression', Ridge())
])

# 训练
pipeline.fit(X_train, y_train)

# 预测
y_pred = pipeline.predict(X_test)
```

## 获取选中的特征

```python
# 方法1: 获取特征索引
indices = selector.selected_features_
print(f"Selected indices: {indices}")

# 方法2: 使用get_support
indices = selector.get_support(indices=True)

# 方法3: 获取布尔mask
mask = selector.get_support(indices=False)
```

## 计算时间

```python
selector.fit(X, y)
print(f"Computation time: {selector.computation_time_:.4f}s")
```

## 疑难解答

### 问题1: 内存不足
**解决方案**: 使用screening减少维度

```python
selector = SteinSelector(use_screening=True, m=10, delta=0.8)
```

### 问题2: 计算太慢
**解决方案**: 
- 减少screening迭代次数 `m`
- 增大delta值（更激进的筛选）
- 确保使用了screening（高维数据）

### 问题3: 选择结果不稳定
**解决方案**: 设置random_state

```python
selector = SteinSelector(num_features=5, random_state=42)
```

### 问题4: 协方差矩阵奇异
**解决方案**: 
- 使用screening预先降维
- 设置rho参数使用结构化协方差
- 增加样本数量

## 下一步

- 阅读完整文档：[README.md](README.md)
- 查看示例代码：`examples/`目录
- 运行测试：`pytest tests/`
- 查看论文了解理论：参见README中的引用

## 获得帮助

- GitHub Issues: https://github.com/yourusername/steinfs/issues
- Email: junyedu@connect.hku.hk

