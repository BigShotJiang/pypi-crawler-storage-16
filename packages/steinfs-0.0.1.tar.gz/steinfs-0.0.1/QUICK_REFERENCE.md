# SteinFS 快速参考卡片

## 🚀 安装
```bash
pip install steinfs
```

## 💻 基础使用（3行代码）

```python
from steinfs import SteinSelector
selector = SteinSelector(num_features=5)
X_selected = selector.fit_transform(X, y)
```

## 📋 完整示例

```python
import numpy as np
from steinfs import SteinSelector

# 1. 准备数据
X = np.random.randn(100, 50)  # (n_samples, n_features)
y = np.random.randn(100)      # (n_samples,)

# 2. 创建选择器
selector = SteinSelector(num_features=10)

# 3. 选择特征
X_selected = selector.fit_transform(X, y)

# 4. 查看结果
print(f"选中的特征: {selector.selected_features_}")
print(f"计算时间: {selector.computation_time_:.4f}s")
```

## 🎛️ 常用参数

### 基础参数
```python
SteinSelector(
    num_features=10,        # 要选择的特征数
    distribution='gaussian' # 'gaussian' 或 't'
)
```

### Screening参数（高维数据）
```python
SteinSelector(
    num_features=10,
    use_screening=True,    # 启用screening
    m=10,                  # screening迭代次数
    delta=0.9              # 每次保留比例
)
```

### t分布参数
```python
SteinSelector(
    num_features=10,
    distribution='t',      # 使用t分布
    nu=5.0                 # 自由度
)
```

### 自定义协方差
```python
SteinSelector(
    num_features=10,
    rho=0.5               # Toeplitz相关系数
)
```

## 🔧 主要方法

```python
# 方法1: 分步操作
selector.fit(X, y)           # 拟合
X_new = selector.transform(X) # 转换

# 方法2: 一步完成
X_new = selector.fit_transform(X, y)

# 获取选中的特征
indices = selector.selected_features_           # 直接访问
indices = selector.get_support(indices=True)    # 获取索引
mask = selector.get_support(indices=False)      # 获取布尔mask
```

## 📊 使用场景速查

| 场景 | 推荐配置 |
|------|---------|
| 标准数据 | `use_screening=False` |
| 高维数据 (d>1000) | `use_screening=True, m=10, delta=0.9` |
| 重尾分布/异常值 | `distribution='t', nu=5.0` |
| 相关特征 | `rho=0.3~0.7` |

## 🎯 参数选择指南

### num_features
- **含义**: 要选择的特征数
- **建议**: 根据实际需求或交叉验证确定
- **范围**: 1 到 总特征数

### use_screening
- **含义**: 是否使用screening降维
- **建议**: d > 1000 设为 True
- **影响**: True可加速但可能略降精度

### m (screening迭代次数)
- **含义**: screening的迭代轮数
- **建议**: 5-15
- **影响**: 越大越慢但筛选越细致

### delta (保留比例)
- **含义**: 每轮screening保留的特征比例
- **建议**: 0.85-0.95
- **影响**: 越小筛选越激进

### distribution
- **选择**:
  - `'gaussian'`: 标准正态数据（默认）
  - `'t'`: 重尾分布/有异常值

### nu (t分布自由度)
- **含义**: t分布的自由度参数
- **建议**: 3-10
- **影响**: 越小表示尾部越重

## 🔗 集成scikit-learn

```python
from sklearn.pipeline import Pipeline
from sklearn.linear_model import Ridge
from steinfs import SteinSelector

# 创建pipeline
pipe = Pipeline([
    ('selector', SteinSelector(num_features=20)),
    ('model', Ridge())
])

# 训练
pipe.fit(X_train, y_train)

# 预测
y_pred = pipe.predict(X_test)
```

## 🐛 常见问题

### Q: 内存不足
```python
# A: 使用screening
selector = SteinSelector(use_screening=True, delta=0.8)
```

### Q: 太慢
```python
# A: 减少screening参数或增大delta
selector = SteinSelector(use_screening=True, m=5, delta=0.95)
```

### Q: 结果不稳定
```python
# A: 设置随机种子
selector = SteinSelector(num_features=10, random_state=42)
```

### Q: 协方差矩阵奇异
```python
# A: 使用screening或设置rho
selector = SteinSelector(use_screening=True, rho=0.1)
```

## 📈 性能参考

| 数据规模 | 建议配置 | 预期时间 |
|---------|---------|---------|
| 100×50 | 默认 | <0.1s |
| 100×500 | 默认或screening | 0.5s |
| 100×2000 | screening | 1-2s |
| 1000×2000 | screening | 5-10s |

## 📚 更多帮助

- **详细文档**: README.md
- **快速上手**: QUICKSTART.md
- **示例代码**: examples/
- **GitHub**: https://github.com/yourusername/steinfs
- **Email**: junyedu@connect.hku.hk

---

**提示**: 所有参数都有合理的默认值，通常只需指定 `num_features` 即可！

