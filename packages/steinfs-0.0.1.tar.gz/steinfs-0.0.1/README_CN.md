# SteinFS: 基于Stein公式的特征选择

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

一个基于Stein公式的非参数特征选择Python包，专为高维数据设计。

## 🚀 快速安装

```bash
pip install steinfs
```

## 💡 5分钟上手

```python
import numpy as np
from steinfs import SteinSelector

# 生成示例数据
X = np.random.randn(100, 50)  # 100个样本，50个特征
y = X[:, 0]**2 + X[:, 1]**2 + np.random.randn(100) * 0.1

# 选择前5个最重要的特征
selector = SteinSelector(num_features=5)
X_selected = selector.fit_transform(X, y)

print(f"选中的特征: {selector.selected_features_}")
print(f"原始维度: {X.shape} -> 选择后: {X_selected.shape}")
```

## ✨ 核心优势

- ✅ **理论保证**: 基于严格数学理论的非参数方法
- ✅ **高维数据**: 支持screening技术，高效处理超高维数据
- ✅ **非线性**: 能够识别非线性关系中的重要特征
- ✅ **多分布**: 支持Gaussian和t分布
- ✅ **易用**: scikit-learn风格API，3行代码搞定

## 📊 适用场景

### 场景1: 标准特征选择
```python
selector = SteinSelector(num_features=10)
X_new = selector.fit_transform(X, y)
```

### 场景2: 超高维数据 (推荐使用screening)
```python
# 对于d>1000的高维数据
selector = SteinSelector(
    num_features=10,
    use_screening=True,  # 开启screening加速
    m=10,                # screening迭代次数
    delta=0.9            # 每次保留90%特征
)
X_new = selector.fit_transform(X, y)
```

### 场景3: 重尾分布数据
```python
# 使用t分布（适合有异常值的数据）
selector = SteinSelector(
    num_features=10,
    distribution='t',
    nu=5.0  # 自由度
)
X_new = selector.fit_transform(X, y)
```

## 📖 方法说明

本包实现了两个算法：

**Algorithm 1: 基础Stein选择法**
- 基于Stein公式计算特征重要性
- 适用于中低维数据 (d < 1000)

**Algorithm 2: Screening + Stein**
- 迭代式降维 + Stein选择
- 适用于超高维数据 (d > 1000)

详见论文：*A Nonparametric Statistics Approach to Feature Selection in Deep Neural Networks with Theoretical Guarantees*

## 🔧 主要参数

| 参数 | 说明 | 推荐值 |
|------|------|--------|
| `num_features` | 要选择的特征数 | 根据需求 |
| `use_screening` | 是否使用screening | d>1000时用True |
| `m` | screening迭代次数 | 5-15 |
| `delta` | 每次保留的比例 | 0.85-0.95 |
| `distribution` | 数据分布类型 | 'gaussian'或't' |
| `nu` | t分布自由度 | 3-10 |

## 📦 与scikit-learn集成

```python
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor
from steinfs import SteinSelector

# 创建pipeline
pipeline = Pipeline([
    ('feature_selection', SteinSelector(num_features=20)),
    ('regression', RandomForestRegressor())
])

# 训练和预测
pipeline.fit(X_train, y_train)
y_pred = pipeline.predict(X_test)
```

## 🧪 运行示例

包含完整示例代码：

```bash
# 基础使用
python examples/basic_example.py

# 高维数据处理
python examples/high_dimensional_example.py

# t分布数据
python examples/t_distribution_example.py
```

## 📚 完整文档

- **快速开始**: [QUICKSTART.md](QUICKSTART.md)
- **发布指南**: [HOW_TO_PUBLISH.md](HOW_TO_PUBLISH.md)
- **项目总结**: [PACKAGE_SUMMARY.md](PACKAGE_SUMMARY.md)

## 🔬 引用

如果在研究中使用本包，请引用：

```bibtex
@article{du2025nonparametric,
  title={A Nonparametric Statistics Approach to Feature Selection in Deep Neural Networks with Theoretical Guarantees},
  author={Du, Junye and Li, Zhenghao and Gu, Zhutong and Feng, Long},
  year={2025},
  publisher={Oxford University Press}
}
```

## 💬 获得帮助

- **Issues**: https://github.com/yourusername/steinfs/issues
- **Email**: junyedu@connect.hku.hk
- **文档**: [README.md](README.md)

## 📄 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

## 👥 作者

- **Junye Du** - 香港大学
- **Zhenghao Li** - 香港大学

---

**关键词**: 特征选择, Stein公式, 高维数据, 非参数统计, 机器学习

