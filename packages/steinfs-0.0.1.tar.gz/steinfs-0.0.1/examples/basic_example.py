"""
Basic example of using SteinFS for feature selection
"""

import numpy as np
import sys
import os

# Add parent directory to path for import
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from steinfs import SteinSelector


def main():
    print("=" * 70)
    print("SteinFS Basic Example")
    print("=" * 70)
    
    # Set random seed for reproducibility
    np.random.seed(42)
    
    # Generate synthetic data
    n_samples = 2000
    n_features = 200
    n_informative = 5
    
    print(f"\nGenerating synthetic data:")
    print(f"  - Samples: {n_samples}")
    print(f"  - Features: {n_features}")
    print(f"  - Informative features: {n_informative}")
    
    X = np.random.randn(n_samples, n_features)
    
    # Create target: y depends on first 5 features in a nonlinear way
    true_features = [0, 1, 2, 3, 4]
    y = (X[:, 0]**2 + X[:, 1]**2 + 0.5 * X[:, 2]**2 + X[:, 3]**2 +  X[:, 4]**2 + np.random.randn(n_samples) * 0.1)
    
    print(f"  - True informative features: {true_features}")
    
    # Method 1: Basic Stein selector
    print("\n" + "-" * 70)
    print("Method 1: Basic Stein Feature Selection (Gaussian)")
    print("-" * 70)
    
    selector = SteinSelector(num_features=5, distribution='gaussian')
    selector.fit(X, y)
    
    selected = selector.selected_features_
    print(f"Selected features: {sorted(selected)}")
    print(f"Computation time: {selector.computation_time_:.4f}s")
    
    # Calculate overlap with true features
    overlap = len(set(selected) & set(true_features))
    print(f"Overlap with true features: {overlap}/{n_informative}")
    
    # Transform data
    X_selected = selector.transform(X)
    print(f"Transformed data shape: {X_selected.shape}")
    
    
    # Method 3: Using fit_transform
    print("\n" + "-" * 70)
    print("Method 3: Using fit_transform")
    print("-" * 70)
    
    selector_ft = SteinSelector(num_features=5)
    X_selected_ft = selector_ft.fit_transform(X, y)
    
    print(f"Selected features: {sorted(selector_ft.selected_features_)}")
    print(f"Output shape: {X_selected_ft.shape}")
    
    # Method 4: Get support mask
    print("\n" + "-" * 70)
    print("Method 4: Using get_support")
    print("-" * 70)
    
    mask = selector.get_support(indices=False)
    indices = selector.get_support(indices=True)
    
    print(f"Support mask shape: {mask.shape}")
    print(f"Number of True values in mask: {mask.sum()}")
    print(f"Support indices: {indices}")
    
    print("\n" + "=" * 70)
    print("Example completed successfully!")
    print("=" * 70)


if __name__ == "__main__":
    main()

