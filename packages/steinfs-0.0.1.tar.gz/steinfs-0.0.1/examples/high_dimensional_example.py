"""
Example of using SteinFS with screening for high-dimensional data
"""

import numpy as np
import sys
import os
import time

# Add parent directory to path for import
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from steinfs import SteinSelector


def main():
    print("=" * 70)
    print("SteinFS High-Dimensional Example with Screening")
    print("=" * 70)
    
    # Set random seed for reproducibility
    np.random.seed(42)
    
    # Generate high-dimensional data
    n_samples = 2500
    n_features = 2000  # High-dimensional
    n_informative = 5
    
    print(f"\nGenerating high-dimensional synthetic data:")
    print(f"  - Samples: {n_samples}")
    print(f"  - Features: {n_features} (high-dimensional!)")
    print(f"  - Informative features: {n_informative}")
    
    X = np.random.randn(n_samples, n_features)
    
    # Create target: y depends on features [0, 5, 100, 500, 1000]
    true_features = [0, 1, 2, 3, 4]
    y = (X[:, 0]**2 + X[:, 1]**2 + X[:, 2]**2 + X[:, 3]**2 +  X[:, 4]**2 )
    
    print(f"  - True informative features: {true_features}")
    
    # Method 1: Basic Stein without screening (may be slow)
    print("\n" + "-" * 70)
    print("Method 1: Basic Stein without Screening")
    print("-" * 70)
    
    start = time.time()
    selector_basic = SteinSelector(num_features=5, use_screening=False)
    selector_basic.fit(X, y)
    time_basic = time.time() - start
    
    selected_basic = selector_basic.selected_features_
    print(f"Selected features: {sorted(selected_basic)}")
    print(f"Computation time: {time_basic:.4f}s")
    
    overlap_basic = len(set(selected_basic) & set(true_features))
    print(f"Overlap with true features: {overlap_basic}/{n_informative}")
    
    # Method 2: Stein with screening (recommended for high-dimensional data)
    print("\n" + "-" * 70)
    print("Method 2: Stein WITH Screening (Recommended)")
    print("-" * 70)
    
    start = time.time()
    selector_screening = SteinSelector(
        num_features=5,
        use_screening=True,
        m=15,        # 10 screening iterations
        delta=0.9    # Keep 90% features in each iteration
    )
    selector_screening.fit(X, y)
    time_screening = time.time() - start
    
    selected_screening = selector_screening.selected_features_
    print(f"Selected features: {sorted(selected_screening)}")
    print(f"Computation time: {time_screening:.4f}s")
    
    overlap_screening = len(set(selected_screening) & set(true_features))
    print(f"Overlap with true features: {overlap_screening}/{n_informative}")
    
    # Speed comparison
    print("\n" + "-" * 70)
    print("Performance Comparison")
    print("-" * 70)
    print(f"Without screening: {time_basic:.4f}s")
    print(f"With screening:    {time_screening:.4f}s")
    print(f"Speedup factor:    {time_basic/time_screening:.2f}x")
    
    # Method 3: Different screening parameters
    print("\n" + "-" * 70)
    print("Method 3: Experimenting with Screening Parameters")
    print("-" * 70)
    
    screening_configs = [
        {'m': 5, 'delta': 0.8},
        {'m': 10, 'delta': 0.9},
        {'m': 15, 'delta': 0.95},
    ]
    
    for config in screening_configs:
        start = time.time()
        selector = SteinSelector(
            num_features=5,
            use_screening=True,
            m=config['m'],
            delta=config['delta']
        )
        selector.fit(X, y)
        elapsed = time.time() - start
        
        selected = selector.selected_features_
        overlap = len(set(selected) & set(true_features))
        
        print(f"\nm={config['m']}, delta={config['delta']}:")
        print(f"  Selected: {sorted(selected)}")
        print(f"  Overlap: {overlap}/{n_informative}")
        print(f"  Time: {elapsed:.4f}s")
    
    # Dimension reduction visualization
    print("\n" + "-" * 70)
    print("Screening Dimension Reduction Path")
    print("-" * 70)
    
    m = 10
    delta = 0.9
    current_d = n_features
    
    print(f"Starting dimension: {current_d}")
    for i in range(m):
        next_d = int(np.ceil(current_d * delta))
        print(f"  Iteration {i+1}: {current_d} -> {next_d} features")
        current_d = next_d
    print(f"Final dimension: {current_d}")
    print(f"Dimension reduction: {n_features} -> {current_d} ({current_d/n_features*100:.1f}%)")
    
    print("\n" + "=" * 70)
    print("Example completed successfully!")
    print("=" * 70)


if __name__ == "__main__":
    main()

