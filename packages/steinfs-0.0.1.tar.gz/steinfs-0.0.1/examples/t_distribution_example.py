"""
Example of using SteinFS with t-distribution data
"""

import numpy as np
from scipy.stats import multivariate_t
import sys
import os

# Add parent directory to path for import
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from steinfs import SteinSelector


def main():
    print("=" * 70)
    print("SteinFS t-Distribution Example")
    print("=" * 70)
    
    # Set random seed for reproducibility
    np.random.seed(42)
    
    # Generate t-distribution data
    n_samples = 100
    n_features = 50
    nu = 5.0  # Degrees of freedom
    
    print(f"\nGenerating t-distribution data:")
    print(f"  - Samples: {n_samples}")
    print(f"  - Features: {n_features}")
    print(f"  - Degrees of freedom (nu): {nu}")
    
    # Generate multivariate t-distribution samples
    loc = np.zeros(n_features)
    shape = np.eye(n_features)
    X = multivariate_t.rvs(loc=loc, shape=shape, df=nu, size=n_samples)
    
    # Create target: y depends on first 5 features
    true_features = [0, 1, 2, 3, 4]
    y = (X[:, 0]**2 + X[:, 1]**2 + 0.5 * X[:, 2]**3 + 
         0.3 * np.sin(X[:, 3]) + 0.2 * X[:, 4] + 
         np.random.randn(n_samples) * 0.1)
    
    print(f"  - True informative features: {true_features}")
    
    # Method 1: Stein for t-distribution
    print("\n" + "-" * 70)
    print("Method 1: Stein Feature Selection for t-Distribution")
    print("-" * 70)
    
    selector_t = SteinSelector(
        num_features=5,
        distribution='t',
        nu=nu
    )
    selector_t.fit(X, y)
    
    selected_t = selector_t.selected_features_
    print(f"Selected features: {sorted(selected_t)}")
    print(f"Computation time: {selector_t.computation_time_:.4f}s")
    
    overlap_t = len(set(selected_t) & set(true_features))
    print(f"Overlap with true features: {overlap_t}/{len(true_features)}")
    
    # Method 2: Compare with Gaussian assumption (incorrect distribution)
    print("\n" + "-" * 70)
    print("Method 2: Comparison with Gaussian Assumption")
    print("-" * 70)
    
    selector_gaussian = SteinSelector(
        num_features=5,
        distribution='gaussian'
    )
    selector_gaussian.fit(X, y)
    
    selected_gaussian = selector_gaussian.selected_features_
    print(f"Selected features: {sorted(selected_gaussian)}")
    print(f"Computation time: {selector_gaussian.computation_time_:.4f}s")
    
    overlap_gaussian = len(set(selected_gaussian) & set(true_features))
    print(f"Overlap with true features: {overlap_gaussian}/{len(true_features)}")
    
    # Compare results
    print("\n" + "-" * 70)
    print("Comparison Summary")
    print("-" * 70)
    print(f"t-distribution selector overlap: {overlap_t}/{len(true_features)}")
    print(f"Gaussian selector overlap:       {overlap_gaussian}/{len(true_features)}")
    
    if overlap_t > overlap_gaussian:
        print("\n✓ Using correct distribution (t) gives better results!")
    elif overlap_t < overlap_gaussian:
        print("\n⚠ Gaussian assumption performed better in this case")
    else:
        print("\n= Both methods achieved same performance")
    
    # Method 3: Different degrees of freedom
    print("\n" + "-" * 70)
    print("Method 3: Effect of Different Degrees of Freedom")
    print("-" * 70)
    
    nu_values = [3.0, 5.0, 10.0, 30.0]
    
    for nu_test in nu_values:
        selector = SteinSelector(
            num_features=5,
            distribution='t',
            nu=nu_test
        )
        selector.fit(X, y)
        
        selected = selector.selected_features_
        overlap = len(set(selected) & set(true_features))
        
        print(f"\nnu={nu_test}:")
        print(f"  Selected: {sorted(selected)}")
        print(f"  Overlap: {overlap}/{len(true_features)}")
        print(f"  Time: {selector.computation_time_:.4f}s")
    
    # Method 4: High-dimensional t-distribution with screening
    print("\n" + "-" * 70)
    print("Method 4: High-Dimensional t-Distribution with Screening")
    print("-" * 70)
    
    n_features_high = 500
    print(f"\nGenerating high-dimensional t-distribution data:")
    print(f"  - Features: {n_features_high}")
    
    X_high = multivariate_t.rvs(
        loc=np.zeros(n_features_high), 
        shape=np.eye(n_features_high), 
        df=nu, 
        size=n_samples
    )
    
    true_features_high = [0, 5, 50, 100, 200]
    y_high = (X_high[:, 0]**2 + X_high[:, 5]**2 + 
              X_high[:, 50] + X_high[:, 100]**2 + 
              0.5 * X_high[:, 200] + 
              np.random.randn(n_samples) * 0.1)
    
    selector_t_screening = SteinSelector(
        num_features=5,
        distribution='t',
        nu=nu,
        use_screening=True,
        m=10,
        delta=0.9
    )
    selector_t_screening.fit(X_high, y_high)
    
    selected_t_screening = selector_t_screening.selected_features_
    print(f"Selected features: {sorted(selected_t_screening)}")
    print(f"Computation time: {selector_t_screening.computation_time_:.4f}s")
    
    overlap_t_screening = len(set(selected_t_screening) & set(true_features_high))
    print(f"Overlap with true features: {overlap_t_screening}/{len(true_features_high)}")
    
    print("\n" + "=" * 70)
    print("Example completed successfully!")
    print("=" * 70)


if __name__ == "__main__":
    main()

