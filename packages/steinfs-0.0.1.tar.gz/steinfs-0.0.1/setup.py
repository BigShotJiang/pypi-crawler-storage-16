"""
Setup script for SteinFS package
"""

from setuptools import setup, find_packages
import os

# Read the contents of README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='steinfs',
    version='0.0.1',
    author='Junye Du',
    author_email='junyedu@connect.hku.hk',
    description='Feature Selection based on Stein\'s Formula for High-Dimensional Data',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/yourusername/steinfs',
    packages=find_packages(),
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Science/Research',
        'Intended Audience :: Developers',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'Topic :: Scientific/Engineering :: Mathematics',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.8',
    install_requires=[
        'numpy>=1.20.0',
        'scipy>=1.7.0',
    ],
    extras_require={
        'dev': [
            'pytest>=6.0',
            'pytest-cov>=2.12',
            'black>=21.0',
            'flake8>=3.9',
            'mypy>=0.910',
        ],
        'examples': [
            'matplotlib>=3.3.0',
            'scikit-learn>=0.24.0',
        ],
    },
    keywords='feature-selection machine-learning statistics stein-formula high-dimensional-data',
    project_urls={
        'Bug Reports': 'https://github.com/yourusername/steinfs/issues',
        'Source': 'https://github.com/yourusername/steinfs',
        'Documentation': 'https://github.com/yourusername/steinfs/blob/main/README.md',
    },
)

