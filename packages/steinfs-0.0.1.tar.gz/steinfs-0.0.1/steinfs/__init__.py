"""
SteinFS: Feature Selection based on Stein's Formula
===================================================

A Python package for nonparametric feature selection using Stein's formula
with optional screening for high-dimensional data.

Basic Usage:
-----------
>>> from steinfs import SteinSelector
>>> selector = SteinSelector(use_screening=False)
>>> selected_features = selector.fit_transform(X, y)

With Screening:
--------------
>>> selector = SteinSelector(use_screening=True, m=10, delta=0.9)
>>> selected_features = selector.fit_transform(X, y)

For more information, see the documentation at: https://github.com/yourusername/steinfs
"""

__version__ = "0.0.1"
__author__ = "Junye Du"
__email__ = "junyedu@connect.hku.hk"

from .selector import SteinSelector
from .core import (
    stein_feature_selection,
    stein_screening_feature_selection
)

__all__ = [
    'SteinSelector',
    'stein_feature_selection',
    'stein_screening_feature_selection',
    '__version__',
    '__author__',
    '__email__',
]

