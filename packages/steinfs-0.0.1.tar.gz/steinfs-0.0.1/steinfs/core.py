"""
Core algorithms for Stein-based feature selection
"""

import numpy as np
from typing import Tuple, Optional
from .utils import largest_abs_eigenvectors, top_k_indices, validate_inputs


# ============================================================================
# Gaussian Distribution Methods
# ============================================================================

def stein_score_function(sigma: np.ndarray, x: np.ndarray) -> np.ndarray:
    """
    Compute Stein score function S(x) = ∇log p(x) for Gaussian distribution.
    
    Parameters
    ----------
    sigma : np.ndarray
        Covariance matrix
    x : np.ndarray
        Data matrix (n_samples, d)
        
    Returns
    -------
    np.ndarray
        Score function values
    """
    sigma_inv = np.linalg.inv(sigma)
    result = sigma_inv @ x.T
    return result.T


def stein_divergence_operator(sigma: np.ndarray) -> np.ndarray:
    """
    Compute divergence operator ∇·S(x) for Gaussian distribution.
    
    Parameters
    ----------
    sigma : np.ndarray
        Covariance matrix
        
    Returns
    -------
    np.ndarray
        Divergence operator (inverse of sigma)
    """
    return np.linalg.inv(sigma)


def compute_stein_matrix_gaussian(X: np.ndarray, y: np.ndarray, 
                                  sigma: np.ndarray) -> np.ndarray:
    """
    Compute Stein matrix for Gaussian distribution: E[y·S(X)·S(X)^T] - E[y]·∇·S
    
    This is the core of Algorithm 1 in the paper.
    
    Parameters
    ----------
    X : np.ndarray
        Feature matrix (n_samples, d)
    y : np.ndarray
        Target vector (n_samples,)
    sigma : np.ndarray
        Covariance matrix (d, d)
        
    Returns
    -------
    np.ndarray
        Stein matrix (d, d)
    """
    n_samples = X.shape[0]
    
    # Compute S(X) = Σ^{-1} X^T
    S_X = stein_score_function(sigma, X)
    
    # Compute E[y·S(X)·S(X)^T] = (1/n)·Σ_i y_i·S(x_i)·S(x_i)^T
    yS_outer = ((S_X.T * y.T) @ S_X) / n_samples
    
    # Compute E[y]·∇·S = (mean(y))·Σ^{-1}
    div_S = stein_divergence_operator(sigma)
    mean_y = y.sum() / n_samples
    
    # Stein matrix
    stein_matrix = yS_outer - mean_y * div_S
    
    return stein_matrix


def stein_feature_selection(X: np.ndarray, y: np.ndarray, 
                           num_features: int = 5,
                           sigma: Optional[np.ndarray] = None,
                           rho: Optional[float] = None) -> Tuple[np.ndarray, float]:
    """
    Stein-based feature selection for Gaussian distribution (Algorithm 1).
    
    Parameters
    ----------
    X : np.ndarray
        Feature matrix of shape (n_samples, n_features)
    y : np.ndarray
        Target vector of shape (n_samples,)
    num_features : int, default=5
        Number of features to select
    sigma : np.ndarray, optional
        Covariance matrix. If None, will be estimated from data or rho.
    rho : float, optional
        Correlation parameter for Toeplitz covariance. Ignored if sigma is provided.
        
    Returns
    -------
    selected_indices : np.ndarray
        Indices of selected features
    computation_time : float
        Time taken for computation (currently 0.0, can be extended)
        
    Examples
    --------
    >>> from steinfs import stein_feature_selection
    >>> import numpy as np
    >>> X = np.random.randn(100, 50)
    >>> y = X[:, 0] ** 2 + X[:, 1] ** 2 + np.random.randn(100) * 0.1
    >>> indices = stein_feature_selection(X, y, num_features=5)
    """
    import time
    start_time = time.time()
    
    # Validate inputs
    validate_inputs(X, y, num_features, sigma)
    
    # Estimate or use provided covariance
    if sigma is None:
        from .utils import estimate_covariance
        sigma = estimate_covariance(X, rho)
    
    # Compute Stein matrix
    stein_matrix = compute_stein_matrix_gaussian(X, y, sigma)
    
    # Extract top eigenvectors
    top_eigenvectors = largest_abs_eigenvectors(stein_matrix, k=num_features)
    
    # Select features with largest norms in eigenvector space
    feature_importance = np.linalg.norm(top_eigenvectors, axis=1)
    selected_indices = top_k_indices(feature_importance, num_features)
    
    computation_time = time.time() - start_time
    
    return selected_indices, computation_time


# ============================================================================
# t-Distribution Methods
# ============================================================================

def compute_stein_matrix_t(X: np.ndarray, y: np.ndarray, nu: float,
                          sigma: Optional[np.ndarray] = None) -> np.ndarray:
    """
    Compute Stein matrix for t-distribution.
    
    Parameters
    ----------
    X : np.ndarray
        Feature matrix (n_samples, d)
    y : np.ndarray
        Target vector (n_samples,)
    nu : float
        Degrees of freedom for t-distribution
    sigma : np.ndarray, optional
        Scale matrix (covariance). If None, uses identity.
        
    Returns
    -------
    np.ndarray
        Stein matrix (d, d)
    """
    n_samples, d = X.shape
    
    if sigma is None:
        sigma = np.eye(d)
    
    mu = np.zeros(d)
    
    # Compute Σ^{-1}
    Sigma_inv = np.linalg.pinv(sigma)
    
    # Center data
    X_centered = X - mu
    
    # Compute quadratic form for each sample: (x-μ)^T Σ^{-1} (x-μ)
    quad_form = np.sum((X_centered @ Sigma_inv) * X_centered, axis=1)  # (n_samples,)
    
    denom = nu + quad_form  # (n_samples,)
    
    # Compute coefficients
    c1 = (nu + d) * (2 + nu + d) / denom**2  # (n_samples,)
    c2 = (nu + d) / denom  # (n_samples,)
    
    # Compute V = Σ^{-1} (X-μ)^T, shape: (d, n_samples)
    V = Sigma_inv @ X_centered.T
    
    # Compute sum terms using einsum
    # sum_term1 = Σ_i y_i c1_i V_i V_i^T
    sum_term1 = np.einsum('ai,i,bi->ab', V, y * c1, V)  # (d, d)
    
    # sum_term2 = (Σ_i y_i c2_i) Σ^{-1}
    sum_term2 = np.sum(y * c2) * Sigma_inv  # (d, d)
    
    # Stein matrix
    sum_yT = sum_term1 - sum_term2
    mean_yT = sum_yT / n_samples
    
    return mean_yT


def stein_feature_selection_t(X: np.ndarray, y: np.ndarray,
                              num_features: int = 5,
                              nu: float = 5.0,
                              sigma: Optional[np.ndarray] = None,
                              rho: Optional[float] = None) -> Tuple[np.ndarray, float]:
    """
    Stein-based feature selection for t-distribution.
    
    Parameters
    ----------
    X : np.ndarray
        Feature matrix of shape (n_samples, n_features)
    y : np.ndarray
        Target vector of shape (n_samples,)
    num_features : int, default=5
        Number of features to select
    nu : float, default=5.0
        Degrees of freedom for t-distribution
    sigma : np.ndarray, optional
        Scale matrix. If None, will be estimated from data or rho.
    rho : float, optional
        Correlation parameter for Toeplitz covariance.
        
    Returns
    -------
    selected_indices : np.ndarray
        Indices of selected features
    computation_time : float
        Time taken for computation
    """
    import time
    start_time = time.time()
    
    # Validate inputs
    validate_inputs(X, y, num_features, sigma)
    
    # Estimate or use provided covariance
    if sigma is None:
        from .utils import estimate_covariance
        sigma = estimate_covariance(X, rho)
    
    # Compute Stein matrix for t-distribution
    stein_matrix = compute_stein_matrix_t(X, y, nu, sigma)
    
    # Extract top eigenvectors
    top_eigenvectors = largest_abs_eigenvectors(stein_matrix, k=num_features)
    
    # Select features with largest norms in eigenvector space
    feature_importance = np.linalg.norm(top_eigenvectors, axis=1)
    selected_indices = top_k_indices(feature_importance, num_features)
    
    computation_time = time.time() - start_time
    
    return selected_indices, computation_time


# ============================================================================
# Screening Methods (Algorithm 2)
# ============================================================================

def stein_screening_feature_selection(X: np.ndarray, y: np.ndarray,
                                     num_features: int = 5,
                                     m: int = 10,
                                     delta: float = 0.9,
                                     sigma: Optional[np.ndarray] = None,
                                     rho: Optional[float] = None,
                                     distribution: str = 'gaussian',
                                     nu: float = 5.0) -> Tuple[np.ndarray, float]:
    """
    Stein-based feature selection with screening for high-dimensional data (Algorithm 2).
    
    This implements iterative screening to reduce dimensionality before final selection.
    In each iteration, we keep top delta*d features based on diagonal importance.
    
    Parameters
    ----------
    X : np.ndarray
        Feature matrix of shape (n_samples, n_features)
    y : np.ndarray
        Target vector of shape (n_samples,)
    num_features : int, default=5
        Number of features to select in final step
    m : int, default=10
        Number of screening iterations
    delta : float, default=0.9
        Proportion of features to keep in each screening iteration (0 < delta < 1)
    sigma : np.ndarray, optional
        Covariance matrix. If None, will be estimated.
    rho : float, optional
        Correlation parameter for Toeplitz covariance.
    distribution : str, default='gaussian'
        Distribution type: 'gaussian' or 't'
    nu : float, default=5.0
        Degrees of freedom (only used for t-distribution)
        
    Returns
    -------
    selected_indices : np.ndarray
        Indices of selected features (in original feature space)
    computation_time : float
        Time taken for computation
        
    Examples
    --------
    >>> from steinfs import stein_screening_feature_selection
    >>> import numpy as np
    >>> X = np.random.randn(100, 1000)  # High-dimensional data
    >>> y = X[:, 0] ** 2 + X[:, 1] ** 2 + np.random.randn(100) * 0.1
    >>> indices = stein_screening_feature_selection(X, y, num_features=5, m=10)
    """
    import time
    start_time = time.time()
    
    # Validate inputs
    validate_inputs(X, y, num_features, sigma)
    
    if delta <= 0 or delta >= 1:
        raise ValueError(f"delta must be between 0 and 1, got {delta}")
    
    if m < 1:
        raise ValueError(f"m must be at least 1, got {m}")
    
    # Estimate or use provided covariance
    if sigma is None:
        from .utils import estimate_covariance
        sigma = estimate_covariance(X, rho)
    
    # Initialize
    current_X = X.copy()
    current_sigma = sigma.copy()
    current_indices = np.arange(X.shape[1])
    current_d = X.shape[1]
    
    # Screening iterations
    for i in range(m):
        # Compute Stein matrix for current subset
        if distribution == 'gaussian':
            stein_matrix = compute_stein_matrix_gaussian(current_X, y, current_sigma)
        elif distribution == 't':
            stein_matrix = compute_stein_matrix_t(current_X, y, nu, current_sigma)
        else:
            raise ValueError(f"Unsupported distribution: {distribution}")
        
        # Use diagonal elements as feature importance
        diag_abs = np.abs(np.diag(stein_matrix))
        
        # Keep top delta*d features
        next_d = int(np.ceil(current_d * delta))
        top_indices = np.argsort(diag_abs)[-next_d:]
        
        # Update current state
        current_X = current_X[:, top_indices]
        current_sigma = current_sigma[top_indices][:, top_indices]
        current_indices = current_indices[top_indices]
        current_d = next_d
    
    # Final selection on screened features
    if distribution == 'gaussian':
        stein_matrix = compute_stein_matrix_gaussian(current_X, y, current_sigma)
    elif distribution == 't':
        stein_matrix = compute_stein_matrix_t(current_X, y, nu, current_sigma)
    else:
        raise ValueError(f"Unsupported distribution: {distribution}")
    
    # Extract top eigenvectors
    top_eigenvectors = largest_abs_eigenvectors(stein_matrix, k=num_features)
    
    # Select features in screened space
    feature_importance = np.linalg.norm(top_eigenvectors, axis=1)
    selected_indices_in_current = top_k_indices(feature_importance, num_features)
    
    # Map back to original feature space
    original_selected_indices = current_indices[selected_indices_in_current]
    
    computation_time = time.time() - start_time
    
    return original_selected_indices, computation_time

