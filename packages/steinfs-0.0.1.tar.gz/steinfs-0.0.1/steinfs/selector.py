"""
Main selector class for SteinFS package
"""

import numpy as np
from typing import Optional, Tuple, Literal
from .core import (
    stein_feature_selection,
    stein_feature_selection_t,
    stein_screening_feature_selection
)
from .utils import estimate_covariance, validate_inputs


class SteinSelector:
    """
    Feature selector based on Stein's formula.
    
    This class implements feature selection using Stein's formula with optional
    screening for high-dimensional data. It supports both Gaussian and t-distributions.
    
    Parameters
    ----------
    num_features : int, default=5
        Number of features to select
    use_screening : bool, default=False
        Whether to use iterative screening (Algorithm 2)
    m : int, default=10
        Number of screening iterations (only used if use_screening=True)
    delta : float, default=0.9
        Proportion of features to keep in each screening iteration (0 < delta < 1)
        (only used if use_screening=True)
    distribution : {'gaussian', 't'}, default='gaussian'
        Distribution type to assume
    nu : float, default=5.0
        Degrees of freedom for t-distribution (only used if distribution='t')
    rho : float, optional
        Correlation parameter for Toeplitz covariance structure.
        If None, covariance is estimated from data.
    random_state : int, optional
        Random seed for reproducibility
        
    Attributes
    ----------
    selected_features_ : np.ndarray
        Indices of selected features after fitting
    computation_time_ : float
        Time taken for feature selection
    sigma_ : np.ndarray
        Covariance matrix used for selection
        
    Examples
    --------
    Basic usage with Gaussian distribution:
    
    >>> from steinfs import SteinSelector
    >>> import numpy as np
    >>> X = np.random.randn(100, 50)
    >>> y = X[:, 0] ** 2 + X[:, 1] ** 2 + np.random.randn(100) * 0.1
    >>> selector = SteinSelector(num_features=5)
    >>> selector.fit(X, y)
    >>> selected_features = selector.selected_features_
    >>> X_selected = selector.transform(X)
    
    With screening for high-dimensional data:
    
    >>> X_high = np.random.randn(100, 2000)
    >>> y = X_high[:, 0] ** 2 + X_high[:, 1] ** 2 + np.random.randn(100) * 0.1
    >>> selector = SteinSelector(num_features=5, use_screening=True, m=10, delta=0.9)
    >>> X_selected = selector.fit_transform(X_high, y)
    
    With t-distribution:
    
    >>> selector = SteinSelector(num_features=5, distribution='t', nu=5.0)
    >>> X_selected = selector.fit_transform(X, y)
    """
    
    def __init__(self,
                 num_features: int = 5,
                 use_screening: bool = False,
                 m: int = 10,
                 delta: float = 0.9,
                 distribution: Literal['gaussian', 't'] = 'gaussian',
                 nu: float = 5.0,
                 rho: Optional[float] = None,
                 random_state: Optional[int] = None):
        
        self.num_features = num_features
        self.use_screening = use_screening
        self.m = m
        self.delta = delta
        self.distribution = distribution
        self.nu = nu
        self.rho = rho
        self.random_state = random_state
        
        # Attributes set during fit
        self.selected_features_ = None
        self.computation_time_ = None
        self.sigma_ = None
        self.n_features_in_ = None
        
    def fit(self, X: np.ndarray, y: np.ndarray, 
            sigma: Optional[np.ndarray] = None) -> 'SteinSelector':
        """
        Fit the selector to data and identify important features.
        
        Parameters
        ----------
        X : np.ndarray
            Feature matrix of shape (n_samples, n_features)
        y : np.ndarray
            Target vector of shape (n_samples,)
        sigma : np.ndarray, optional
            Covariance matrix. If None, will be estimated from data.
            
        Returns
        -------
        self : SteinSelector
            Fitted selector
        """
        # Set random seed if provided
        if self.random_state is not None:
            np.random.seed(self.random_state)
        
        # Validate inputs
        validate_inputs(X, y, self.num_features, sigma)
        
        # Store number of features
        self.n_features_in_ = X.shape[1]
        
        # Estimate covariance if not provided
        if sigma is None:
            self.sigma_ = estimate_covariance(X, self.rho)
        else:
            self.sigma_ = sigma
        
        # Perform feature selection
        if self.use_screening:
            # Use screening algorithm (Algorithm 2)
            selected_indices, comp_time = stein_screening_feature_selection(
                X=X,
                y=y,
                num_features=self.num_features,
                m=self.m,
                delta=self.delta,
                sigma=self.sigma_,
                rho=self.rho,
                distribution=self.distribution,
                nu=self.nu
            )
        else:
            # Use basic Stein selection (Algorithm 1)
            if self.distribution == 'gaussian':
                selected_indices, comp_time = stein_feature_selection(
                    X=X,
                    y=y,
                    num_features=self.num_features,
                    sigma=self.sigma_,
                    rho=self.rho
                )
            elif self.distribution == 't':
                selected_indices, comp_time = stein_feature_selection_t(
                    X=X,
                    y=y,
                    num_features=self.num_features,
                    nu=self.nu,
                    sigma=self.sigma_,
                    rho=self.rho
                )
            else:
                raise ValueError(f"Unsupported distribution: {self.distribution}")
        
        self.selected_features_ = selected_indices
        self.computation_time_ = comp_time
        
        return self
    
    def transform(self, X: np.ndarray) -> np.ndarray:
        """
        Transform data by selecting only the important features.
        
        Parameters
        ----------
        X : np.ndarray
            Feature matrix of shape (n_samples, n_features)
            
        Returns
        -------
        X_selected : np.ndarray
            Transformed data with only selected features,
            shape (n_samples, num_features)
        """
        if self.selected_features_ is None:
            raise ValueError("Selector has not been fitted yet. Call fit() first.")
        
        return X[:, self.selected_features_]
    
    def fit_transform(self, X: np.ndarray, y: np.ndarray,
                     sigma: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Fit the selector and transform data in one step.
        
        Parameters
        ----------
        X : np.ndarray
            Feature matrix of shape (n_samples, n_features)
        y : np.ndarray
            Target vector of shape (n_samples,)
        sigma : np.ndarray, optional
            Covariance matrix
            
        Returns
        -------
        X_selected : np.ndarray
            Transformed data with only selected features
        """
        self.fit(X, y, sigma)
        return self.transform(X)
    
    def get_support(self, indices: bool = True) -> np.ndarray:
        """
        Get a mask or indices of selected features.
        
        Parameters
        ----------
        indices : bool, default=True
            If True, return feature indices.
            If False, return a boolean mask.
            
        Returns
        -------
        support : np.ndarray
            Feature indices or boolean mask
        """
        if self.selected_features_ is None:
            raise ValueError("Selector has not been fitted yet. Call fit() first.")
        
        if indices:
            return self.selected_features_
        else:
            # Return boolean mask
            mask = np.zeros(self.n_features_in_, dtype=bool)
            mask[self.selected_features_] = True
            return mask
    
    def get_feature_importance(self) -> np.ndarray:
        """
        Get feature importance scores (placeholder for future extension).
        
        Returns
        -------
        importance : np.ndarray
            Feature importance scores
            
        Notes
        -----
        Currently returns indices as importance proxy. Can be extended
        to return actual importance scores from eigenvector norms.
        """
        if self.selected_features_ is None:
            raise ValueError("Selector has not been fitted yet. Call fit() first.")
        
        # For now, return selected indices
        # Can be extended to store actual importance scores
        return self.selected_features_
    
    def __repr__(self) -> str:
        """String representation of the selector."""
        screening_str = " with screening" if self.use_screening else ""
        return (f"SteinSelector(num_features={self.num_features}, "
                f"distribution='{self.distribution}'{screening_str})")

