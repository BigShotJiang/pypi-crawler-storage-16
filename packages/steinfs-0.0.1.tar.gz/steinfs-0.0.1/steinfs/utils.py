"""
Utility functions for SteinFS package
"""

import numpy as np
from scipy.linalg import eigh
from scipy.stats import multivariate_t
from typing import Tuple, Optional


def create_sigma_matrix(size: int, rho: float) -> np.ndarray:
    """
    Create a Toeplitz covariance matrix with correlation rho.
    
    Parameters
    ----------
    size : int
        Size of the matrix
    rho : float
        Correlation parameter (0 <= rho < 1)
        
    Returns
    -------
    np.ndarray
        Covariance matrix of shape (size, size)
    """
    sigma = np.zeros((size, size))
    for i in range(size):
        for j in range(size):
            sigma[i, j] = rho ** abs(i - j)
    return sigma


def estimate_covariance(X: np.ndarray, rho: Optional[float] = None) -> np.ndarray:
    """
    Estimate or construct covariance matrix.
    
    Parameters
    ----------
    X : np.ndarray
        Data matrix of shape (n_samples, n_features)
    rho : float, optional
        If provided, construct Toeplitz matrix with this correlation.
        Otherwise, estimate from data.
        
    Returns
    -------
    np.ndarray
        Covariance matrix
    """
    d = X.shape[1]
    
    if rho is not None:
        return create_sigma_matrix(d, rho)
    else:
        # Estimate from data
        return np.cov(X.T)


def largest_abs_eigenvectors(matrix: np.ndarray, k: int) -> np.ndarray:
    """
    Extract eigenvectors corresponding to k largest absolute eigenvalues.
    
    Parameters
    ----------
    matrix : np.ndarray
        Square matrix
    k : int
        Number of eigenvectors to extract
        
    Returns
    -------
    np.ndarray
        Matrix of eigenvectors with shape (d, k)
    """
    eigenvalues, eigenvectors = eigh(matrix)
    indices = np.argsort(np.abs(eigenvalues))[-k:]
    largest_eigenvectors = eigenvectors[:, indices]
    return largest_eigenvectors


def top_k_indices(arr: np.ndarray, k: int = 5) -> np.ndarray:
    """
    Get indices of k largest absolute values in array.
    
    Parameters
    ----------
    arr : np.ndarray
        1D array
    k : int
        Number of indices to return
        
    Returns
    -------
    np.ndarray
        Indices of k largest absolute values, sorted in descending order
    """
    abs_arr = np.abs(arr)
    indices = np.argpartition(abs_arr, -k)[-k:]
    top_k_indices_sorted = indices[np.argsort(abs_arr[indices])[::-1]]
    return top_k_indices_sorted


def validate_inputs(X: np.ndarray, y: np.ndarray, 
                   num_features: int, sigma: Optional[np.ndarray] = None) -> None:
    """
    Validate input data and parameters.
    
    Parameters
    ----------
    X : np.ndarray
        Feature matrix
    y : np.ndarray
        Target vector
    num_features : int
        Number of features to select
    sigma : np.ndarray, optional
        Covariance matrix
        
    Raises
    ------
    ValueError
        If inputs are invalid
    """
    if not isinstance(X, np.ndarray):
        raise ValueError("X must be a numpy array")
    
    if not isinstance(y, np.ndarray):
        raise ValueError("y must be a numpy array")
    
    if X.ndim != 2:
        raise ValueError(f"X must be 2-dimensional, got shape {X.shape}")
    
    if y.ndim != 1:
        y = y.flatten()
        if y.ndim != 1:
            raise ValueError("y must be 1-dimensional")
    
    if X.shape[0] != y.shape[0]:
        raise ValueError(f"X and y must have same number of samples. "
                        f"Got X.shape[0]={X.shape[0]}, y.shape[0]={y.shape[0]}")
    
    if num_features <= 0 or num_features > X.shape[1]:
        raise ValueError(f"num_features must be between 1 and {X.shape[1]}, "
                        f"got {num_features}")
    
    if sigma is not None:
        if sigma.shape != (X.shape[1], X.shape[1]):
            raise ValueError(f"sigma must be square matrix of size {X.shape[1]}, "
                           f"got shape {sigma.shape}")


def generate_t_samples(d: int, n_samples: int, nu: float, 
                      iid: bool = True) -> Tuple[np.ndarray, np.ndarray]:
    """
    Generate samples from multivariate t-distribution.
    
    Parameters
    ----------
    d : int
        Dimension
    n_samples : int
        Number of samples
    nu : float
        Degrees of freedom
    iid : bool
        Whether to use identity covariance (IID samples)
        
    Returns
    -------
    samples : np.ndarray
        Generated samples
    sigma : np.ndarray
        Covariance matrix used
    """
    if iid:
        sigma = np.eye(d)
    else:
        sigma = create_sigma_matrix(d, 0.5)
    
    samples = multivariate_t.rvs(loc=np.zeros(d), shape=sigma, df=nu, size=n_samples)
    return samples, sigma

