"""
Tests for SteinFS package
"""

