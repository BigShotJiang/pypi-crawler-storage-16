"""
Tests for core module
"""

import pytest
import numpy as np
from steinfs.core import (
    stein_feature_selection,
    stein_feature_selection_t,
    stein_screening_feature_selection,
    compute_stein_matrix_gaussian,
    compute_stein_matrix_t,
)


class TestSteinFeatureSelection:
    """Test basic Stein feature selection"""
    
    def test_basic_gaussian(self):
        """Test basic feature selection with Gaussian data"""
        np.random.seed(42)
        X = np.random.randn(100, 20)
        y = X[:, 0]**2 + X[:, 1]**2 + np.random.randn(100) * 0.1
        
        indices, time = stein_feature_selection(X, y, num_features=5)
        
        assert len(indices) == 5
        assert all(0 <= i < 20 for i in indices)
        assert time >= 0
    
    def test_with_custom_sigma(self):
        """Test with custom covariance matrix"""
        np.random.seed(42)
        X = np.random.randn(100, 20)
        sigma = np.eye(20)
        y = X[:, 0]**2 + np.random.randn(100) * 0.1
        
        indices, time = stein_feature_selection(X, y, num_features=3, sigma=sigma)
        
        assert len(indices) == 3
    
    def test_with_rho(self):
        """Test with Toeplitz covariance"""
        np.random.seed(42)
        X = np.random.randn(100, 20)
        y = X[:, 0] + np.random.randn(100) * 0.1
        
        indices, time = stein_feature_selection(X, y, num_features=5, rho=0.5)
        
        assert len(indices) == 5


class TestSteinTDistribution:
    """Test Stein feature selection for t-distribution"""
    
    def test_basic_t(self):
        """Test with t-distribution data"""
        np.random.seed(42)
        X = np.random.randn(100, 20)
        y = X[:, 0]**2 + X[:, 1]**2 + np.random.randn(100) * 0.1
        
        indices, time = stein_feature_selection_t(X, y, num_features=5, nu=5.0)
        
        assert len(indices) == 5
        assert all(0 <= i < 20 for i in indices)
    
    def test_different_nu(self):
        """Test with different degrees of freedom"""
        np.random.seed(42)
        X = np.random.randn(100, 20)
        y = X[:, 0] + np.random.randn(100) * 0.1
        
        for nu in [3.0, 5.0, 10.0]:
            indices, time = stein_feature_selection_t(X, y, num_features=3, nu=nu)
            assert len(indices) == 3


class TestScreening:
    """Test screening feature selection"""
    
    def test_basic_screening(self):
        """Test basic screening"""
        np.random.seed(42)
        X = np.random.randn(100, 100)
        y = X[:, 0]**2 + X[:, 5]**2 + np.random.randn(100) * 0.1
        
        indices, time = stein_screening_feature_selection(
            X, y, num_features=5, m=5, delta=0.9
        )
        
        assert len(indices) == 5
        assert all(0 <= i < 100 for i in indices)
    
    def test_screening_t_distribution(self):
        """Test screening with t-distribution"""
        np.random.seed(42)
        X = np.random.randn(100, 100)
        y = X[:, 0]**2 + np.random.randn(100) * 0.1
        
        indices, time = stein_screening_feature_selection(
            X, y, num_features=5, m=5, delta=0.9, 
            distribution='t', nu=5.0
        )
        
        assert len(indices) == 5
    
    def test_screening_parameters(self):
        """Test different screening parameters"""
        np.random.seed(42)
        X = np.random.randn(50, 50)
        y = X[:, 0] + np.random.randn(50) * 0.1
        
        # Test different m values
        for m in [1, 5, 10]:
            indices, time = stein_screening_feature_selection(
                X, y, num_features=3, m=m, delta=0.9
            )
            assert len(indices) == 3
        
        # Test different delta values
        for delta in [0.7, 0.8, 0.9]:
            indices, time = stein_screening_feature_selection(
                X, y, num_features=3, m=5, delta=delta
            )
            assert len(indices) == 3


class TestSteinMatrix:
    """Test Stein matrix computation"""
    
    def test_gaussian_matrix_shape(self):
        """Test Gaussian Stein matrix has correct shape"""
        np.random.seed(42)
        X = np.random.randn(50, 20)
        y = np.random.randn(50)
        sigma = np.eye(20)
        
        matrix = compute_stein_matrix_gaussian(X, y, sigma)
        
        assert matrix.shape == (20, 20)
    
    def test_t_matrix_shape(self):
        """Test t-distribution Stein matrix has correct shape"""
        np.random.seed(42)
        X = np.random.randn(50, 20)
        y = np.random.randn(50)
        
        matrix = compute_stein_matrix_t(X, y, nu=5.0)
        
        assert matrix.shape == (20, 20)


class TestInputValidation:
    """Test input validation"""
    
    def test_invalid_num_features(self):
        """Test with invalid number of features"""
        X = np.random.randn(50, 20)
        y = np.random.randn(50)
        
        with pytest.raises(ValueError):
            stein_feature_selection(X, y, num_features=0)
        
        with pytest.raises(ValueError):
            stein_feature_selection(X, y, num_features=25)
    
    def test_mismatched_shapes(self):
        """Test with mismatched X and y shapes"""
        X = np.random.randn(50, 20)
        y = np.random.randn(40)
        
        with pytest.raises(ValueError):
            stein_feature_selection(X, y, num_features=5)
    
    def test_invalid_delta(self):
        """Test screening with invalid delta"""
        X = np.random.randn(50, 20)
        y = np.random.randn(50)
        
        with pytest.raises(ValueError):
            stein_screening_feature_selection(X, y, num_features=5, delta=1.5)
        
        with pytest.raises(ValueError):
            stein_screening_feature_selection(X, y, num_features=5, delta=0)


if __name__ == '__main__':
    pytest.main([__file__])

