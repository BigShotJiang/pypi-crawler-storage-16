"""
Tests for selector module
"""

import pytest
import numpy as np
from steinfs import SteinSelector


class TestSteinSelector:
    """Test SteinSelector class"""
    
    def test_basic_fit_transform(self):
        """Test basic fit and transform"""
        np.random.seed(42)
        X = np.random.randn(100, 20)
        y = X[:, 0]**2 + X[:, 1]**2 + np.random.randn(100) * 0.1
        
        selector = SteinSelector(num_features=5)
        X_selected = selector.fit_transform(X, y)
        
        assert X_selected.shape == (100, 5)
        assert selector.selected_features_ is not None
        assert len(selector.selected_features_) == 5
    
    def test_separate_fit_transform(self):
        """Test fit and transform separately"""
        np.random.seed(42)
        X = np.random.randn(100, 20)
        y = X[:, 0]**2 + np.random.randn(100) * 0.1
        
        selector = SteinSelector(num_features=5)
        selector.fit(X, y)
        X_selected = selector.transform(X)
        
        assert X_selected.shape == (100, 5)
    
    def test_with_screening(self):
        """Test with screening enabled"""
        np.random.seed(42)
        X = np.random.randn(100, 100)
        y = X[:, 0]**2 + X[:, 5]**2 + np.random.randn(100) * 0.1
        
        selector = SteinSelector(
            num_features=5,
            use_screening=True,
            m=5,
            delta=0.9
        )
        X_selected = selector.fit_transform(X, y)
        
        assert X_selected.shape == (100, 5)
    
    def test_t_distribution(self):
        """Test with t-distribution"""
        np.random.seed(42)
        X = np.random.randn(100, 20)
        y = X[:, 0]**2 + np.random.randn(100) * 0.1
        
        selector = SteinSelector(
            num_features=5,
            distribution='t',
            nu=5.0
        )
        X_selected = selector.fit_transform(X, y)
        
        assert X_selected.shape == (100, 5)
    
    def test_get_support_indices(self):
        """Test get_support with indices"""
        np.random.seed(42)
        X = np.random.randn(50, 20)
        y = X[:, 0] + np.random.randn(50) * 0.1
        
        selector = SteinSelector(num_features=5)
        selector.fit(X, y)
        
        support = selector.get_support(indices=True)
        
        assert len(support) == 5
        assert all(0 <= i < 20 for i in support)
    
    def test_get_support_mask(self):
        """Test get_support with mask"""
        np.random.seed(42)
        X = np.random.randn(50, 20)
        y = X[:, 0] + np.random.randn(50) * 0.1
        
        selector = SteinSelector(num_features=5)
        selector.fit(X, y)
        
        # First need to set n_features_in_
        selector.n_features_in_ = 20
        mask = selector.get_support(indices=False)
        
        assert len(mask) == 20
        assert mask.sum() == 5
        assert mask.dtype == bool
    
    def test_random_state(self):
        """Test random state reproducibility"""
        X = np.random.randn(50, 20)
        y = X[:, 0]**2 + np.random.randn(50) * 0.1
        
        selector1 = SteinSelector(num_features=5, random_state=42)
        selector1.fit(X, y)
        
        selector2 = SteinSelector(num_features=5, random_state=42)
        selector2.fit(X, y)
        
        assert np.array_equal(selector1.selected_features_, selector2.selected_features_)
    
    def test_transform_before_fit(self):
        """Test that transform before fit raises error"""
        X = np.random.randn(50, 20)
        
        selector = SteinSelector(num_features=5)
        
        with pytest.raises(ValueError):
            selector.transform(X)
    
    def test_get_support_before_fit(self):
        """Test that get_support before fit raises error"""
        selector = SteinSelector(num_features=5)
        
        with pytest.raises(ValueError):
            selector.get_support()
    
    def test_repr(self):
        """Test string representation"""
        selector = SteinSelector(num_features=5)
        repr_str = repr(selector)
        
        assert 'SteinSelector' in repr_str
        assert 'num_features=5' in repr_str
    
    def test_repr_with_screening(self):
        """Test string representation with screening"""
        selector = SteinSelector(num_features=5, use_screening=True)
        repr_str = repr(selector)
        
        assert 'with screening' in repr_str


class TestSteinSelectorParameters:
    """Test parameter combinations"""
    
    def test_different_num_features(self):
        """Test with different number of features to select"""
        np.random.seed(42)
        X = np.random.randn(50, 20)
        y = X[:, 0] + np.random.randn(50) * 0.1
        
        for k in [3, 5, 10]:
            selector = SteinSelector(num_features=k)
            X_selected = selector.fit_transform(X, y)
            assert X_selected.shape == (50, k)
    
    def test_screening_parameters(self):
        """Test different screening parameters"""
        np.random.seed(42)
        X = np.random.randn(50, 50)
        y = X[:, 0] + np.random.randn(50) * 0.1
        
        configs = [
            {'m': 3, 'delta': 0.8},
            {'m': 5, 'delta': 0.9},
            {'m': 10, 'delta': 0.95},
        ]
        
        for config in configs:
            selector = SteinSelector(
                num_features=5,
                use_screening=True,
                **config
            )
            X_selected = selector.fit_transform(X, y)
            assert X_selected.shape == (50, 5)
    
    def test_with_rho(self):
        """Test with custom rho parameter"""
        np.random.seed(42)
        X = np.random.randn(50, 20)
        y = X[:, 0] + np.random.randn(50) * 0.1
        
        selector = SteinSelector(num_features=5, rho=0.5)
        X_selected = selector.fit_transform(X, y)
        
        assert X_selected.shape == (50, 5)


if __name__ == '__main__':
    pytest.main([__file__])

