# Internal errors placeholder (extend when needed).
