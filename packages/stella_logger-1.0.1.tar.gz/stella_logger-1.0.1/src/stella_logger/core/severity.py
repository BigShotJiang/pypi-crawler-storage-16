from __future__ import annotations

import logging
from enum import Enum


class StellaSeverity(str, Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"

    def to_logging_level(self) -> int:
        level_map = {
            StellaSeverity.DEBUG: logging.DEBUG,
            StellaSeverity.INFO: logging.INFO,
            StellaSeverity.WARNING: logging.WARNING,
            StellaSeverity.ERROR: logging.ERROR,
            StellaSeverity.CRITICAL: logging.CRITICAL,
        }
        return level_map[self]
