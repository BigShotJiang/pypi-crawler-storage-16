from .app_error import LogEventError

__all__ = ["LogEventError"]
