# Internal compatibility helpers placeholder (extend when needed).
