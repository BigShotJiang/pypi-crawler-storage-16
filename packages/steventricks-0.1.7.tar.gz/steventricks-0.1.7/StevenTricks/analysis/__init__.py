# analysis/__init__.py
"""Analysis tools: driver_tree, algorithms."""