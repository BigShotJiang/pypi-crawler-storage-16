# core/__init__.py
"""Core data utilities for StevenTricks."""
