# dev/__init__.py
"""Developer helpers: code templates, control flow utilities."""