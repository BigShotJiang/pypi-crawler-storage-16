# io/__init__.py
"""IO helpers: filesystem, logs, networking, staging paths."""
