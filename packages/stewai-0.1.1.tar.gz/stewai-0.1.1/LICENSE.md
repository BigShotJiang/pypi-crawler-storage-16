StewAI Commercial License
Version 0.0.0 – June 2025
Copyright © 2025 Christian Mueller. All rights reserved.

1. Grant of License
   You are granted a non-exclusive, non-transferable, revocable license to
   (a) view and modify the source code in this repository,
   (b) run the Software for your internal evaluation or development purposes only.

2. Restrictions
   • No distribution, sublicensing, or SaaS offering of the Software or
   Derivative Works is permitted without a separate commercial agreement.
   • You may not remove or alter any proprietary notices.
   • Reverse engineering of any binary distribution is prohibited unless
   required by law.

3. Termination
   This License terminates automatically if you breach any term. Upon
   termination you must destroy all copies and cease all use.

4. DISCLAIMER
   THE SOFTWARE IS PROVIDED “AS IS” WITHOUT WARRANTY OF ANY KIND. THE AUTHOR
   DISCLAIMS ALL LIABILITY FOR DAMAGES, DIRECT OR INDIRECT, ARISING FROM USE
   OF THE SOFTWARE.

For a production or redistribution license, contact:
Christian Mueller · christian.mueller@camueller.org
