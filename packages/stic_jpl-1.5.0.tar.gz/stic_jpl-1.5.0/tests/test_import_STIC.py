def test_import_STIC_JPL():
    import STIC_JPL
