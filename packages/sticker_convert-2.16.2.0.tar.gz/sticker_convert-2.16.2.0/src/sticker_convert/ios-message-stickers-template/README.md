# ios-message-stickers-template

I have also created an Figma file with the templates for creating the stickers & iMessage App Icon.  
You can find it here: https://www.figma.com/community/file/894284318358585629/iOS-iMessage-Stickers-Template


## Links
Video tutorial: https://developer.apple.com/videos/play/tutorials/building-sticker-packs/  
Documentation: https://developer.apple.com/documentation/messages  
General info: https://developer.apple.com/imessage/
