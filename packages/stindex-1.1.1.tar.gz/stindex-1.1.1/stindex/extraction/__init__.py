"""Core extraction functionality."""

from stindex.extraction.dimensional_extraction import DimensionalExtractor

__all__ = ["DimensionalExtractor"]
