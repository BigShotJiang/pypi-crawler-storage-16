.. _basic2d:

**************************
basic2d
**************************

.. currentmodule:: stistools.basic2d

.. automodule:: stistools.basic2d
   :members:
   :undoc-members:
