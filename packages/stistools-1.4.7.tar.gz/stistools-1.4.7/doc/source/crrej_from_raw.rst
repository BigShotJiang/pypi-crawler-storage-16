.. _crrej_from_raw:

**************
crrej_from_raw
**************

.. currentmodule:: stistools.crrej_from_raw

.. automodule:: stistools.crrej_from_raw
   :members:
