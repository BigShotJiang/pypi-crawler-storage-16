.. _inttag:

**************************
inttag
**************************

.. currentmodule:: stistools.inttag

.. automodule:: stistools.inttag
   :members:
   :undoc-members: