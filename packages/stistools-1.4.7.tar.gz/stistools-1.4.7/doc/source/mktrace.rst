.. _mktrace:

**************************
mktrace
**************************

.. currentmodule:: stistools.mktrace

.. automodule:: stistools.mktrace
   :members:



