.. _ocrreject:

**************************
ocrreject
**************************

.. currentmodule:: stistools.ocrreject

.. automodule:: stistools.ocrreject
   :members:
   :undoc-members:
