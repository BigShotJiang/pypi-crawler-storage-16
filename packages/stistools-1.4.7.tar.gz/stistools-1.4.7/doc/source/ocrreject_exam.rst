.. _ocrreject_exam:

**************************
ocrreject_exam
**************************

.. currentmodule:: stistools.ocrreject_exam

.. automodule:: stistools.ocrreject_exam
   :members:
   :undoc-members:
