.. _poisson_err:

**************************
poisson_err
**************************

.. currentmodule:: stistools.poisson_err

.. automodule:: stistools.poisson_err
   :members:
   :undoc-members:
