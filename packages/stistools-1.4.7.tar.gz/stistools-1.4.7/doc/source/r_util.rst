.. _r_util:

**************************
r_util
**************************

.. currentmodule:: stistools.r_util

.. automodule:: stistools.r_util
   :members:
   :undoc-members:

