.. _stisnoise:

**************************
stisnoise
**************************

.. currentmodule:: stistools.stisnoise

.. automodule:: stistools.stisnoise
   :members:
   :undoc-members:

