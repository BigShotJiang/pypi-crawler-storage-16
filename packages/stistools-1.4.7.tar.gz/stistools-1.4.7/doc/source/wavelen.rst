.. _wavelen:

**************************
wavelen
**************************

.. currentmodule:: stistools.wavelen

.. automodule:: stistools.wavelen
   :members:
   :undoc-members:

