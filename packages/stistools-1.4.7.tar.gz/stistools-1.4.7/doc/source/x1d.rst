.. _x1d:

**************************
x1d
**************************

.. currentmodule:: stistools.x1d

.. automodule:: stistools.x1d
   :members:
   :undoc-members:
