KEY_ALIAS_MAP = '_stock_aliases_map'
KEY_COLUMNS_INFO_MAP = '_stock_columns_info_map'

KEY_CUMULATOR = '_stock_cumulator'
