from stollen import StollenObject

from ..client import TelegramBot


class TelegramObject(StollenObject[TelegramBot]):
    pass
