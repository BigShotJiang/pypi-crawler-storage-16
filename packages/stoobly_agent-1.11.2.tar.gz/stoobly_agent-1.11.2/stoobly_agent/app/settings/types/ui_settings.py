from typing import TypedDict

class UISettings(TypedDict):
  active: bool
  url: str