COMMAND = 'stoobly-agent'
VERSION = '1.11.3'
