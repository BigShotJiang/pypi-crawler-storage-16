from typing import TypedDict

class RemoteSettings(TypedDict):
  api_url: str
  api_key: str