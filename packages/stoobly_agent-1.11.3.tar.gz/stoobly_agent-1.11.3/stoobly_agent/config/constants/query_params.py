ENDPOINT_PROMISE = 'endpoint_promise'
SESSION_ID = 'session_id'