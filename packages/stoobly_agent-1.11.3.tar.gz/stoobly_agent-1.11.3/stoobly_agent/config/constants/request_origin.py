CLI = 'cli'
PROXY = 'proxy'
WEB = 'web'