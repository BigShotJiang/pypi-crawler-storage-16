from typing import Literal


type OpenBinaryModeWriting = Literal['wb', 'bw', 'ab', 'ba', 'xb', 'bx']
