"""
CLI interface for StrandKit.

Provides command-line tools:
- strandkit init: Scaffold a new agent project
- strandkit run: Run an agent interactively
"""
