from django.apps import AppConfig


class StrawberryDjangoConfig(AppConfig):
    name = "strawberry_django"
    verbose_name = "Strawberry django"
