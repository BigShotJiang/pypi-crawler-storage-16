Thank you
---------

.. card::
    :link: https://github.com/
    :class-card: acknowledgements

    .. |GitHub-logo-dark| image:: _static/github-lockup-dark.svg
        :alt: GitHub logo lockup-dark
        :class: only-light

    .. |GitHub-logo-light| image:: _static/github-lockup-light.svg
        :alt: GitHub logo lockup-light
        :class: only-dark

    |GitHub-logo-dark| |GitHub-logo-light|

    **GitHub**,
    for hosting the git repo, docs, release assets, and for providing CI tools

.. card::
    :link: https://jetbrains.com/
    :class-card: acknowledgements

    .. |JetBrains-logo-dark| image:: _static/jetbrains-mono-black.svg
        :alt: JetBrains logo mono-black
        :class: only-light

    .. |JetBrains-logo-light| image:: _static/jetbrains-mono-white.svg
        :alt: JetBrains logo mono-white
        :class: only-dark

    |JetBrains-logo-dark| |JetBrains-logo-light|

    **JetBrains**,
    for sponsoring an open-source license for their IDEs

.. card::
    :link: https://whatismybrowser.com/
    :class-card: acknowledgements

    **Whatismybrowser**,
    for the access to their user-agents API in our CI workflows
