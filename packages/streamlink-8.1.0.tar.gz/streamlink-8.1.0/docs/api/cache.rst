Cache
-----

.. module:: streamlink.cache

.. autoclass:: Cache
