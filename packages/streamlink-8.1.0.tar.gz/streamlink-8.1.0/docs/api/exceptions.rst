Exceptions
----------

.. autoexception:: streamlink.exceptions.StreamlinkError
.. autoexception:: streamlink.exceptions.PluginError
.. autoexception:: streamlink.exceptions.FatalPluginError
.. autoexception:: streamlink.exceptions.NoPluginError
.. autoexception:: streamlink.exceptions.NoStreamsError
.. autoexception:: streamlink.exceptions.StreamError
.. autoexception:: streamlink.webbrowser.exceptions.WebbrowserError
.. autoexception:: streamlink.webbrowser.cdp.exceptions.CDPError
