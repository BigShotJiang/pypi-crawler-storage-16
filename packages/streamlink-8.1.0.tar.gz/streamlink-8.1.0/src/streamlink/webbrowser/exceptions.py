from streamlink.exceptions import StreamlinkError


class WebbrowserError(StreamlinkError):
    pass
