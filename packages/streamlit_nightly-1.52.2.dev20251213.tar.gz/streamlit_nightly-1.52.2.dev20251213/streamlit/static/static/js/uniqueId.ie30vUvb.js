import{J as i}from"./index.BN4Hj9cC.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
