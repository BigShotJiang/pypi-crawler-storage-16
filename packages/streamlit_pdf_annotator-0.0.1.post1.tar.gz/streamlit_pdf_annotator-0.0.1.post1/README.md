# Streamlit PDF Annotator

Streamlit component that allows you to annotate PDFs easily, built with Vue3 and Vite.

## Setup

Install the latest version with

```sh
pip install streamlit-pdf-annotator
```

## Usage

```python
import streamlit as st
from streamlit_pdf_annotator import annotator

st.title('PDF Annotator Example')

# Upload a PDF file
uploaded_file = st.file_uploader('Upload a PDF', type='pdf')

if uploaded_file:
    # Display the PDF annotator
    annotations = pdf_annotator(uploaded_file.read(), height=600)

    # Display the annotations
    if annotations:
        st.subheader('Annotations:')
        for i, annotation in enumerate(annotations, 1):
            st.write(f'Annotation {i}:')
            st.write(f'  - Page: {annotation.get('page')}')
            st.write(f'  - Position (x, y): ({annotation.get('x')}, {annotation.get('y')})')
            st.write(f'  - Selected Content: {annotation.get('content')}')
            st.write('---')
```

