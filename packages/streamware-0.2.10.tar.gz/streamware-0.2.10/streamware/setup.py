"""
Streamware Setup Wizard

Detects environment and configures Streamware automatically.
"""

import os
import sys
import requests
import asyncio
from typing import Dict, List, Optional, Tuple
from .config import config

def check_ollama() -> Tuple[bool, List[str], str]:
    """
    Check if Ollama is running and get available models.
    Returns (is_running, models, url)
    """
    url = config.get("SQ_OLLAMA_URL", "http://localhost:11434")
    try:
        response = requests.get(f"{url}/api/tags", timeout=2)
        if response.status_code == 200:
            data = response.json()
            models = [m["name"] for m in data.get("models", [])]
            return True, models, url
    except Exception:
        pass
    return False, [], url

def check_openai() -> bool:
    """Check if OpenAI API key is present"""
    return bool(os.environ.get("OPENAI_API_KEY") or config.get("SQ_OPENAI_API_KEY"))

def check_anthropic() -> bool:
    """Check if Anthropic API key is present"""
    return bool(os.environ.get("ANTHROPIC_API_KEY") or config.get("SQ_ANTHROPIC_API_KEY"))

def run_setup(interactive: bool = True):
    """
    Run the setup wizard.
    
    If interactive is True, asks for confirmation.
    If interactive is False, applies best defaults automatically.
    """
    print("🔍 Detecting environment...")
    
    changes = {}
    
    # 1. Check Ollama
    ollama_running, ollama_models, ollama_url = check_ollama()
    
    if ollama_running:
        print(f"✅ Ollama detected at {ollama_url}")
        changes["SQ_LLM_PROVIDER"] = "ollama"
        changes["SQ_OLLAMA_URL"] = ollama_url
        
        # Select best model
        vision_models = [m for m in ollama_models if "vision" in m or "llava" in m]
        chat_models = [m for m in ollama_models if m not in vision_models]
        
        if vision_models:
            best_model = vision_models[0]
            print(f"   Found vision model: {best_model}")
            changes["SQ_MODEL"] = best_model
        elif chat_models:
            best_model = chat_models[0]
            print(f"   Found chat model: {best_model}")
            changes["SQ_MODEL"] = best_model
        else:
            print("   Ollama running but no models found.")
    else:
        print("❌ Ollama not detected")
    
    # 2. Check OpenAI
    openai_key = check_openai()
    if openai_key:
        print("✅ OpenAI API Key detected")
        if not ollama_running:
            changes["SQ_LLM_PROVIDER"] = "openai"
            changes["SQ_MODEL"] = "gpt-4-vision-preview" # Default vision model
    
    # 3. Check Anthropic
    anthropic_key = check_anthropic()
    if anthropic_key:
        print("✅ Anthropic API Key detected")
        if not ollama_running and not openai_key:
            changes["SQ_LLM_PROVIDER"] = "anthropic"
            changes["SQ_MODEL"] = "claude-3-opus-20240229"

    # 4. Summary and Apply
    if not changes:
        print("\n⚠️ No AI providers detected.")
        print("   Please install Ollama or set OPENAI_API_KEY/ANTHROPIC_API_KEY.")
        return

    print("\nProposed Configuration:")
    for key, value in changes.items():
        print(f"   {key} = {value}")

    if interactive:
        response = input("\nApply these changes? [Y/n] ").strip().lower()
        if response in ("n", "no"):
            print("Setup cancelled.")
            return

    # Apply changes
    for key, value in changes.items():
        config.set(key, value)
    
    config.save()
    print("\n✅ Configuration saved to .env")

if __name__ == "__main__":
    run_setup()
