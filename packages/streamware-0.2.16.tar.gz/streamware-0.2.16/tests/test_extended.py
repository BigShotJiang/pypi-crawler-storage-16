
import pytest
from unittest.mock import Mock, patch, MagicMock
from streamware import flow, Pipeline
from streamware.core import registry
from streamware.config import config


class TestExtendedPatterns:
    """Tests for additional patterns and components"""

    def test_branch_pattern(self):
        """Test branching logic"""
        pipeline = flow("split://") 
        assert pipeline is not None

    def test_aggregate_pattern(self):
        """Test aggregation logic"""
        pipeline = flow("aggregate://function=sum")
        assert pipeline is not None

    def test_filter_pattern(self):
        """Test filter pattern"""
        pipeline = flow("filter://predicate=x>10")
        assert pipeline is not None


class TestSetupModes:
    """Tests for setup wizard modes"""
    
    def setup_method(self):
        """Save original config before each test"""
        self.original_config = config.to_dict()
    
    def teardown_method(self):
        """Restore original config after each test"""
        for key, value in self.original_config.items():
            config.set(key, value)

    @patch("streamware.setup.verify_environment")
    def test_setup_eco_mode_whisper_tiny(self, mock_verify):
        """Test that eco mode sets whisper to tiny"""
        from streamware.setup import run_setup
        
        mock_verify.return_value = {
            "ollama": False,
            "ollama_url": "",
            "ollama_models": [],
            "api_keys": {"openai": True}
        }
        
        run_setup(interactive=False, mode="eco")
        
        assert config.get("SQ_WHISPER_MODEL") == "tiny"
        assert config.get("SQ_STT_PROVIDER") == "whisper_local"

    @patch("streamware.setup.verify_environment")
    def test_setup_balance_mode_whisper_base(self, mock_verify):
        """Test that balance mode sets whisper to base"""
        from streamware.setup import run_setup
        
        mock_verify.return_value = {
            "ollama": False,
            "ollama_url": "",
            "ollama_models": [],
            "api_keys": {"openai": True}
        }
        
        run_setup(interactive=False, mode="balance")
        
        assert config.get("SQ_WHISPER_MODEL") == "base"

    @patch("streamware.setup.verify_environment")
    def test_setup_performance_mode_whisper_large(self, mock_verify):
        """Test that performance mode sets whisper to large"""
        from streamware.setup import run_setup
        
        mock_verify.return_value = {
            "ollama": False,
            "ollama_url": "",
            "ollama_models": [],
            "api_keys": {"openai": True}
        }
        
        run_setup(interactive=False, mode="performance")
        
        assert config.get("SQ_WHISPER_MODEL") == "large"


class TestVoiceConfig:
    """Tests for voice configuration"""
    
    def test_stt_provider_in_defaults(self):
        """Test that STT provider is in config defaults"""
        from streamware.config import DEFAULTS
        assert "SQ_STT_PROVIDER" in DEFAULTS
        assert "SQ_WHISPER_MODEL" in DEFAULTS

    def test_voice_component_uses_config(self):
        """Test that VoiceComponent reads config values"""
        from streamware.uri import StreamwareURI
        from streamware.components.voice import VoiceComponent
        
        # Set config
        config.set("SQ_STT_PROVIDER", "whisper_local")
        config.set("SQ_WHISPER_MODEL", "small")
        
        uri = StreamwareURI.parse("voice://listen")
        component = VoiceComponent(uri)
        
        assert component.stt_provider == "whisper_local"
        assert component.whisper_model == "small"


class TestLiveNarratorValidation:
    """Tests for live narrator URL validation"""
    
    def test_empty_url_raises_error(self):
        """Test that empty URL raises ComponentError"""
        from streamware.uri import StreamwareURI
        from streamware.components.live_narrator import LiveNarratorComponent
        from streamware.exceptions import ComponentError
        
        uri = StreamwareURI.parse("live://narrator?source=")
        component = LiveNarratorComponent(uri)
        
        with pytest.raises(ComponentError):
            component.process(None)

    def test_valid_url_accepted(self):
        """Test that valid URL is accepted (will fail on ffmpeg but not validation)"""
        from streamware.uri import StreamwareURI
        from streamware.components.live_narrator import LiveNarratorComponent
        
        uri = StreamwareURI.parse("live://narrator?source=rtsp://test/stream&duration=1")
        component = LiveNarratorComponent(uri)
        
        # Should not raise on validation, only on actual capture
        assert component.source == "rtsp://test/stream"


class TestLiveNarratorFramesDir:
    """Tests for live narrator frame persistence to directory"""
    
    def test_frames_dir_initialized_and_directory_created(self, tmp_path, monkeypatch):
        """Test that frames_dir from URI is prepared in process()"""
        from streamware.uri import StreamwareURI
        from streamware.components.live_narrator import LiveNarratorComponent

        frames_dir = tmp_path / "frames_out"
        uri = StreamwareURI.parse(f"live://narrator?source=rtsp://test/stream&duration=1&frames_dir={frames_dir}")

        # Avoid running real narrator loop and ffmpeg
        def fake_run_narrator(self):
            return {"success": True}

        monkeypatch.setattr(LiveNarratorComponent, "_run_narrator", fake_run_narrator)
        monkeypatch.setattr(
            "streamware.components.live_narrator.tempfile.mkdtemp",
            lambda: str(tmp_path / "tmp_frames"),
        )

        component = LiveNarratorComponent(uri)
        result = component.process(None)

        assert result["success"] is True
        assert component._frames_output_dir is not None
        assert component._frames_output_dir.exists()
        assert str(component._frames_output_dir) == str(frames_dir)

    def test_capture_frame_saves_copy_to_frames_dir(self, tmp_path, monkeypatch):
        """Test that _capture_frame writes a copy into frames_dir when configured"""
        from streamware.uri import StreamwareURI
        from streamware.components.live_narrator import LiveNarratorComponent

        frames_dir = tmp_path / "frames_out"
        temp_dir = tmp_path / "tmp"
        temp_dir.mkdir()
        frames_dir.mkdir()

        uri = StreamwareURI.parse("live://narrator?source=rtsp://test/stream&duration=1")
        component = LiveNarratorComponent(uri)

        # Inject directories used by _capture_frame
        component._temp_dir = temp_dir
        component._frames_output_dir = frames_dir

        expected_output = temp_dir / "frame_00001.jpg"

        def fake_run(cmd, check, capture_output, timeout):  # noqa: ARG001
            expected_output.write_bytes(b"testframe")

        monkeypatch.setattr("streamware.components.live_narrator.subprocess.run", fake_run)

        frame_path = component._capture_frame(1)

        assert frame_path == expected_output
        assert expected_output.exists()

        copied_path = frames_dir / expected_output.name
        assert copied_path.exists()
        assert copied_path.read_bytes() == expected_output.read_bytes()


class TestQuickCLILLM:
    """Tests for quick CLI LLM command configuration"""
    
    @patch("streamware.quick_cli.flow")
    def test_llm_no_provider_uses_config(self, mock_flow):
        """Test that sq llm uses config when no provider specified"""
        from streamware.quick_cli import handle_llm
        
        mock_flow.return_value.run.return_value = "Result"
        
        args = MagicMock()
        args.prompt = "test prompt"
        args.provider = None
        args.model = None
        args.to_sql = False
        args.to_sq = False
        args.to_bash = False
        args.analyze = False
        args.summarize = False
        args.input = None
        args.execute = False
        args.quiet = False
        
        handle_llm(args)
        
        # URI should NOT contain provider param
        call_args = mock_flow.call_args[0][0]
        assert "&provider=" not in call_args

    @patch("streamware.quick_cli.flow")
    def test_llm_explicit_provider_override(self, mock_flow):
        """Test that explicit --provider overrides config"""
        from streamware.quick_cli import handle_llm
        
        mock_flow.return_value.run.return_value = "Result"
        
        args = MagicMock()
        args.prompt = "test"
        args.provider = "anthropic"
        args.model = None
        args.to_sql = False
        args.to_sq = False
        args.to_bash = False
        args.analyze = False
        args.summarize = False
        args.input = None
        args.execute = False
        args.quiet = False
        
        handle_llm(args)
        
        call_args = mock_flow.call_args[0][0]
        assert "&provider=anthropic" in call_args


class TestLiveCLIValidation:
    """Tests for quick CLI live narrator validation"""

    @patch("streamware.quick_cli.flow")
    def test_live_empty_url_returns_error_and_skips_flow(self, mock_flow, capsys):
        """Test that sq live narrator with empty --url returns error before running flow"""
        from streamware.quick_cli import handle_live

        args = MagicMock()
        args.operation = "narrator"
        args.url = ""  # Simulate: --url "" (empty)

        # Other args are not used when URL is empty but define them defensively
        args.mode = "full"
        args.tts = False
        args.duration = 1
        args.analysis = "normal"
        args.motion = "significant"
        args.frames = "changed"
        args.interval = None
        args.threshold = None
        args.trigger = None
        args.focus = None
        args.webhook = None
        args.model = None
        args.quiet = False

        rc = handle_live(args)
        captured = capsys.readouterr()

        assert rc == 1
        assert "Error: --url parameter is required" in captured.err
        mock_flow.assert_not_called()

