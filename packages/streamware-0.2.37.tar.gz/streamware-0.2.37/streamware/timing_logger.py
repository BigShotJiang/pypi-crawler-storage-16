"""
Timing Logger for Streamware

Logs chronological events with timing information for performance analysis.
Outputs to both Markdown and CSV for easy analysis.

Usage:
    from streamware.timing_logger import TimingLogger, get_logger

    logger = get_logger("logs.md")  # Also creates logs.csv
    logger.start("frame_capture")
    # ... do work ...
    logger.end("frame_capture")
    
    # Or use context manager
    with logger.timed("llm_call"):
        result = call_llm(...)
"""

import csv
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import Dict, List, Optional


@dataclass
class TimingEvent:
    """Single timing event."""
    name: str
    start_time: float
    end_time: Optional[float] = None
    duration_ms: Optional[float] = None
    details: str = ""
    timestamp: str = ""  # ISO timestamp
    
    def complete(self, end_time: float = None):
        self.end_time = end_time or time.time()
        self.duration_ms = (self.end_time - self.start_time) * 1000
        self.timestamp = datetime.now().isoformat(timespec='milliseconds')


@dataclass
class FrameLog:
    """Log for a single frame analysis."""
    frame_num: int
    timestamp: datetime
    events: List[TimingEvent] = field(default_factory=list)
    total_ms: float = 0
    result: str = ""
    
    def add_event(self, event: TimingEvent):
        self.events.append(event)
        if event.duration_ms:
            self.total_ms += event.duration_ms


class TimingLogger:
    """Logger that tracks timing of operations."""
    
    _instance: Optional["TimingLogger"] = None
    _lock = Lock()
    
    def __init__(self, log_file: Optional[str] = None):
        self.log_file = Path(log_file) if log_file else None
        self.csv_file = None
        if self.log_file:
            # Create CSV file alongside MD file
            self.csv_file = self.log_file.with_suffix('.csv')
        
        self.frames: List[FrameLog] = []
        self.current_frame: Optional[FrameLog] = None
        self.active_events: Dict[str, TimingEvent] = {}
        self.enabled = log_file is not None
        self._file_lock = Lock()
        self._csv_writer = None
        self._csv_handle = None
        
        if self.log_file:
            self._init_file()
            self._init_csv()
    
    def _init_file(self):
        """Initialize log file with header."""
        with self._file_lock:
            with open(self.log_file, "w") as f:
                f.write("# Streamware Timing Log\n\n")
                f.write(f"Started: {datetime.now().isoformat()}\n\n")
                f.write("---\n\n")
    
    def _init_csv(self):
        """Initialize CSV file with header."""
        self._csv_handle = open(self.csv_file, "w", newline='')
        self._csv_writer = csv.writer(self._csv_handle)
        self._csv_writer.writerow([
            "timestamp", "frame", "step", "duration_ms", "details", "result"
        ])
        self._csv_handle.flush()
    
    def start_frame(self, frame_num: int):
        """Start logging a new frame."""
        if not self.enabled:
            return
        
        self.current_frame = FrameLog(
            frame_num=frame_num,
            timestamp=datetime.now()
        )
    
    def end_frame(self, result: str = ""):
        """End current frame logging."""
        if not self.enabled or not self.current_frame:
            return
        
        self.current_frame.result = result
        self.frames.append(self.current_frame)
        self._write_frame(self.current_frame)
        self.current_frame = None
    
    def start(self, name: str, details: str = ""):
        """Start timing an operation."""
        if not self.enabled:
            return
        
        event = TimingEvent(
            name=name,
            start_time=time.time(),
            details=details
        )
        self.active_events[name] = event
    
    def end(self, name: str, details: str = ""):
        """End timing an operation."""
        if not self.enabled:
            return
        
        if name in self.active_events:
            event = self.active_events.pop(name)
            event.complete()
            if details:
                event.details = details
            
            if self.current_frame:
                self.current_frame.add_event(event)
            else:
                # Standalone event
                self._write_event(event)
    
    @contextmanager
    def timed(self, name: str, details: str = ""):
        """Context manager for timing."""
        self.start(name, details)
        try:
            yield
        finally:
            self.end(name)
    
    def log(self, message: str):
        """Log a simple message."""
        if not self.enabled:
            return
        
        ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        with self._file_lock:
            with open(self.log_file, "a") as f:
                f.write(f"[{ts}] {message}\n")
    
    def _write_frame(self, frame: FrameLog):
        """Write frame log to file."""
        with self._file_lock:
            # Write to Markdown
            with open(self.log_file, "a") as f:
                f.write(f"## Frame {frame.frame_num}\n\n")
                f.write(f"**Time:** {frame.timestamp.strftime('%H:%M:%S.%f')[:-3]}\n")
                f.write(f"**Total:** {frame.total_ms:.0f}ms\n\n")
                
                if frame.events:
                    f.write("| Timestamp | Step | Duration | Details |\n")
                    f.write("|-----------|------|----------|----------|\n")
                    for event in frame.events:
                        ts = event.timestamp if event.timestamp else "-"
                        duration = f"{event.duration_ms:.0f}ms" if event.duration_ms else "-"
                        details = event.details[:50] if event.details else "-"
                        f.write(f"| {ts} | {event.name} | {duration} | {details} |\n")
                    f.write("\n")
                
                if frame.result:
                    f.write(f"**Result:** {frame.result}\n\n")
                
                f.write("---\n\n")
            
            # Write to CSV
            if self._csv_writer:
                for event in frame.events:
                    self._csv_writer.writerow([
                        event.timestamp or frame.timestamp.isoformat(),
                        frame.frame_num,
                        event.name,
                        f"{event.duration_ms:.1f}" if event.duration_ms else "",
                        event.details,
                        frame.result if event == frame.events[-1] else ""
                    ])
                self._csv_handle.flush()
    
    def _write_event(self, event: TimingEvent):
        """Write standalone event to file."""
        ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        with self._file_lock:
            with open(self.log_file, "a") as f:
                duration = f"{event.duration_ms:.0f}ms" if event.duration_ms else "-"
                f.write(f"[{ts}] **{event.name}**: {duration}")
                if event.details:
                    f.write(f" - {event.details}")
                f.write("\n")
    
    def write_summary(self):
        """Write summary statistics."""
        if not self.enabled or not self.frames:
            return
        
        total_frames = len(self.frames)
        avg_time = sum(f.total_ms for f in self.frames) / total_frames if total_frames else 0
        
        # Aggregate by step
        step_times: Dict[str, List[float]] = {}
        for frame in self.frames:
            for event in frame.events:
                if event.duration_ms:
                    if event.name not in step_times:
                        step_times[event.name] = []
                    step_times[event.name].append(event.duration_ms)
        
        with self._file_lock:
            with open(self.log_file, "a") as f:
                f.write("# Summary\n\n")
                f.write(f"**Total Frames:** {total_frames}\n")
                f.write(f"**Avg Frame Time:** {avg_time:.0f}ms\n\n")
                
                if step_times:
                    f.write("## Step Breakdown\n\n")
                    f.write("| Step | Avg | Min | Max | Count |\n")
                    f.write("|------|-----|-----|-----|-------|\n")
                    
                    for step, times in sorted(step_times.items()):
                        avg = sum(times) / len(times)
                        min_t = min(times)
                        max_t = max(times)
                        f.write(f"| {step} | {avg:.0f}ms | {min_t:.0f}ms | {max_t:.0f}ms | {len(times)} |\n")
                    f.write("\n")
                
                f.write(f"\nEnded: {datetime.now().isoformat()}\n")


# Global logger instance
_logger: Optional[TimingLogger] = None


def get_logger(log_file: Optional[str] = None) -> TimingLogger:
    """Get or create timing logger."""
    global _logger
    
    if log_file:
        _logger = TimingLogger(log_file)
    elif _logger is None:
        _logger = TimingLogger(None)  # Disabled logger
    
    return _logger


def set_log_file(log_file: str):
    """Set log file for global logger."""
    global _logger
    _logger = TimingLogger(log_file)
    return _logger
