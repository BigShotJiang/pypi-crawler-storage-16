"""Strix Sandbox MCP Server - Sandboxed security testing tools for Claude Code."""

__version__ = "0.1.0"
