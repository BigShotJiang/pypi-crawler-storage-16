from .st2d import eig_special_2d, structure_tensor_2d
from .st3d import eig_special_3d, structure_tensor_3d
