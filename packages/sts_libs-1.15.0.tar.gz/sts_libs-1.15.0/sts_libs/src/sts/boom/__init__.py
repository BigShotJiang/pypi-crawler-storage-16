# Copyright: Contributors to the sts project
# SPDX-License-Identifier: GPL-3.0-or-later

"""Boom boot manager.

This package provides functionality for managing Boom boot entries and profiles.
"""

from __future__ import annotations
