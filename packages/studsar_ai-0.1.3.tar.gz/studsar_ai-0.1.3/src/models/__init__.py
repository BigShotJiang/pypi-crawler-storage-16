"""
Models module: contains the neural network implementations of StudSar.
"""