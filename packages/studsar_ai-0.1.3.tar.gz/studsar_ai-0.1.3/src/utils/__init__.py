"""
Utils module: contains utility functions for studsar.
"""
from .text import segment_text, SPACY_AVAILABLE