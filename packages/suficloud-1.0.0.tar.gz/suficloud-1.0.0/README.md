# SufiCloud ☁️

Securely backup your files with one line of code.

## Installation

```bash
pip install suficloud
