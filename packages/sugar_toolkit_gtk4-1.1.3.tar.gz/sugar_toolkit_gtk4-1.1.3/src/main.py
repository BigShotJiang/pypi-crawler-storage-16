from sugar4.debug import debug_print


def main(argv):
    """This statement prints Hello, World to your console"""
    debug_print("Hello, World")
