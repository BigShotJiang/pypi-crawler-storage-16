# AUTHORS

- [Jules BOMPARD](jules.bompard.etu@univ-lille.fr)
- [Philippe MATHIEU](philippe.mathieu@univ-lille.fr)
- [Antoine NONGAILLARD](antoine.nongaillard@univ-lille.fr)
