.. _sunpy-soar-dev-guide-index:

***************
Developer Guide
***************

This guide will explain the internals of ``sunpy-soar`` and how it interacts with `sunpy.net.Fido`.

.. toctree::
   :maxdepth: 1

   working
   tables
   query
