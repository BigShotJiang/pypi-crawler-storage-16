.. _sunpy-soar-how-to-index:

*************
How-To Guides
*************

These how-to guides provide examples of how to perform specific tasks with sunpy-soar.

.. toctree::
   :maxdepth: 1

   wavelength
