.. _whatsnew:

***************
Release History
***************

This page documents the releases for sunpy-soar

.. toctree::
   :maxdepth: 1

   changelog
