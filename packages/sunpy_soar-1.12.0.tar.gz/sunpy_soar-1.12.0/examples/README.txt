***************
Example Gallery
***************

This gallery contains examples of how to use ``sunpy-soar``.

