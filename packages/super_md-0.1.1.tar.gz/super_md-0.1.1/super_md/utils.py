import os
import json
from typing import Optional

def load_config() -> dict:
    config_path = os.path.expanduser("~/.super_md_config.json")
    
    if os.path.exists(config_path):
        with open(config_path, 'r') as f:
            return json.load(f)
    return {}

def save_config(config: dict):
    config_path = os.path.expanduser("~/.super_md_config.json")
    
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)

def get_auth_token() -> Optional[str]:
    config = load_config()
    return config.get("token")

def save_auth_token(token: str):
    config = load_config()
    config["token"] = token
    save_config(config)