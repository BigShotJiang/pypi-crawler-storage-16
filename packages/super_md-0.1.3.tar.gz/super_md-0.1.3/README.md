# Super markdown CLI

command line project for super markdown plateform

## Installation

```bash
pip install super-md
```

## Login Command
```bash
super_md login
```

Enter your username and password to log in to your account on the Super Markdown platform.


## Show Command
```bash
super_md show
```
This command lists your files stored on the platform


```bash
super_md show --folder "default"
```
This command will display the subfolders and publications stored on the platform.


## Publish Command

```bash
super_md publish readme.md
super_md publish readme.smd

```

This command aims to transform your markdown files into online publications accessible from anywhere and at any time, using the features offered by the Super Markdown platform.



https://pypi.org/project/super-md/