"""
Supertape CLI Interface

Command-line interface for the Supertape application.
"""
