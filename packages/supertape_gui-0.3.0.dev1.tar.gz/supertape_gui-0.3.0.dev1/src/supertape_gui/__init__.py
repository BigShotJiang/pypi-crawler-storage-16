"""Supertape GUI - Multi-platform graphical interface for supertape."""

__version__ = "0.1.0"
