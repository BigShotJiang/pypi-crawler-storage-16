from .wrapper import SupertonicTTS

__all__ = ["SupertonicTTS"]
