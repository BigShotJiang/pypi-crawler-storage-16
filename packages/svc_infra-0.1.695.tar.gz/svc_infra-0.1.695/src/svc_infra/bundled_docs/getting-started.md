# Getting Started

Welcome to svc-infra docs. Use `svc-infra docs list` to see topics.

- This content is bundled with the package.
- If your project doesn't have a local `docs/` folder, you'll still see this.
