"""
Export main functions from SVG2tikz to be easily accessible from the package
"""

from .tikz_export import convert_file, convert_svg
