"""Mark font_tools as a package.

:author: Shay Hill
:created: 2025-06-04
"""
