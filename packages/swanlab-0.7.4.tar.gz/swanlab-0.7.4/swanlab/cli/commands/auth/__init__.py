#!/usr/bin/env python
# -*- coding: utf-8 -*-
r"""
@DATE: 2024/6/12 21:10
@File: __init__.py
@IDE: pycharm
@Description:
    cli认证模块
"""
from .login import login
from .logout import logout
from .verify import verify
