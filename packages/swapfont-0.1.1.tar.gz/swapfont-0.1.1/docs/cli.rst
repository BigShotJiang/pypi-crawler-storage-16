Command Line Interface
======================

.. click:: swapfont.cli:main
   :prog: swapfont
   :nested: full
