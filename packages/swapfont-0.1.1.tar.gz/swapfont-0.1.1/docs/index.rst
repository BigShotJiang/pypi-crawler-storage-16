Welcome to swapfont
===================

.. include:: ../README.md
   :parser: myst_parser.sphinx_

User Guide
----------

.. toctree::
   :maxdepth: 2
   :caption: Commands

   cli
   examples
