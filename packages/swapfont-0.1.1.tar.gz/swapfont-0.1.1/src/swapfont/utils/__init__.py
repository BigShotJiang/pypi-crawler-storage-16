# src/swapfont/utils/__init__.py
from .pdf_resources import find_resource_recursive

__all__ = [
    "find_resource_recursive",
]
