# SwarmKit Python SDK

SwarmKit lets you run and orchestrate terminal-based AI agents in secure sandboxes with built-in observability.

## Get Started

1. Get your **SwarmKit API key** at [dashboard.swarmlink.ai](https://dashboard.swarmlink.ai/) (new users: [request access](https://dashboard.swarmlink.ai/request-access) first)

2. Get an **E2B API key** at [e2b.dev](https://e2b.dev) for sandbox execution

3. Install the SDK:
   ```bash
   pip install swarmkit
   ```
   **Note:** Requires [Node.js 18+](https://nodejs.org/) (the SDK uses a lightweight Node.js bridge).

4. Check out the [official documentation](https://github.com/brandomagnani/swarmkit/tree/main/docs) and [cookbooks](https://github.com/brandomagnani/swarmkit/tree/main/cookbooks) to start shipping with SwarmKit!

## Reporting Bugs

We welcome your feedback. File a [GitHub issue](https://github.com/brandomagnani/swarmkit/issues) to report bugs or request features.

## Connect on Discord

Join the [SwarmKit Developers Discord](https://discord.gg/Q36D8dGyNF) to connect with other developers using SwarmKit. Get help, share feedback, and discuss your projects with the community.

## License

See [LICENSE](https://github.com/brandomagnani/swarmkit/blob/main/LICENSE) for details.
