.. _swh-objstorage:

.. include:: README.rst


Reference Documentation
-----------------------

.. toctree::
   :maxdepth: 2

   cli
   winery

.. only:: standalone_package_doc

   Indices and tables
   ------------------

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
