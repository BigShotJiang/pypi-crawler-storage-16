from .objstorage import SeaweedFilerObjStorage  # noqa: F401
