//
// Created by omar.iskandarani on 8/12/2025.
//
// field_kernels.cpp — implementations are header-inlined for performance.
// This TU keeps the project structure consistent.
#include "field_kernels.h"
