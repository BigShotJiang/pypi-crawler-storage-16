// src/sst_gravity.cpp
// Implementations are header-inlined for performance (SST Kernel Optimization).
// This Translation Unit (TU) exists to ensure CMake/Project consistency.

#include "sst_gravity.h"