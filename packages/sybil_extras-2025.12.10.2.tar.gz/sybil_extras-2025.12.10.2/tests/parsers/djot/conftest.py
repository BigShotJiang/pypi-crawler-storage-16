"""
Djot parser test configuration.
"""
