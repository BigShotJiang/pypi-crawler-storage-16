"""
Tests for Norg parsers.
"""
