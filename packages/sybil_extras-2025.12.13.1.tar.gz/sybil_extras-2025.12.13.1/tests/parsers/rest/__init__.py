"""
Tests for custom reST parsers.
"""
