symbolic-compartmental-model
============================

[![PyPI version fury.io](https://badge.fury.io/py/symbolic-compartmental-model.svg)](https://pypi.python.org/pypi/symbolic-compartmental-model/)
[![Python version](https://img.shields.io/pypi/pyversions/symbolic-compartmental-model.svg)](https://www.python.org/downloads)
[![MIT license](https://img.shields.io/pypi/l/symbolic-compartmental-model.svg)](https://mit-license.org/)
[![codecov](https://codecov.io/gl/elad.noor/symbolic-compartmental-model/graph/badge.svg?token=0MEGJMPWVS)](https://codecov.io/gl/elad.noor/symbolic-compartmental-model)
[![ReadTheDocs](https://readthedocs.org/projects/symbolic-compartmental-model/badge/?version=latest)](https://symbolic-compartmental-model.readthedocs.io/en/latest/)

A symbolic package based on SymPy for simulating and fitting Compartmental Models (CMs).

Overview
--------
Symbolic Compartmental Model is a python package for constructing, simulating, and fitting
compartmental models. It is based on the symbolic calculations package ``sympy`` but can
also perform numerical calculations.

Current Features
----------------

* Defining a CM based on the contributed turnovers (*M*-matrix) and observed pool sizes
* Optionally include symbolic parameters and set their bounds for later fitting
* Several fitting functions, including single/multiple pools and mass balance constraints (optional)
* Both numerical and symbolic outputs for dynamic parameters: age, residence time, decay rate, etc.
* Plotting of simulated data

Getting started
---------------

* For installing the package in your current python environment, can simply `pip install symbolic-compartmental-model`.
* The package documentation can be found on [ReadTheDocs](https://symbolic-compartmental-model.readthedocs.io).
* For all newcommers using the package for the first time, we recommend reading the [Tutorial](https://symbolic-compartmental-model.readthedocs.io/en/latest/tutorial.html).
* If you want to learn more about the theoretical aspects of Compartmental Models, try reading: [A quick guide to Compartmental Models](https://symbolic-compartmental-model.readthedocs.io/en/latest/cm.html)
* For quick reference, you can see a list of the existing methods here: [List of methods](https://symbolic-compartmental-model.readthedocs.io/en/latest/list_of_methods.html).

Examples using Binder
---------------------

* Fitting predefined Compartmental Models to your data: [![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gl/elad.noor%2Fsymbolic-compartmental-model/main?urlpath=%2Fdoc%2Ftree%2Fscript%2Fbinder_compartmental_model_fitting.ipynb)
