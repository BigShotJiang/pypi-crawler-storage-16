from agentica_internal.internal_errors import *

__all__ = [
    'AgenticaError',
    'ConnectionError',
    'WebSocketConnectionError',
    'WebSocketTimeoutError',
    'ServerError',
    'APIConnectionError',
    'APITimeoutError',
    'BadRequestError',
    'ConflictError',
    'ContentFilteringError',
    'DeadlineExceededError',
    'GenerationError',
    'InferenceError',
    'InternalServerError',
    'UsageError',
    'MaxTokensError',
    'MaxRoundsError',
    'NotFoundError',
    'OverloadedError',
    'PermissionDeniedError',
    'InsufficientCreditsError',
    'RateLimitError',
    'RequestTooLargeError',
    'ServiceUnavailableError',
    'UnauthorizedError',
    'UnprocessableEntityError',
    'InvocationError',
    'TooManyInvocationsError',
    'NotRunningError',
    'ThisIsABug',
]


class InvalidAPIKey(AgenticaError):
    """Local invalid API key exception."""
