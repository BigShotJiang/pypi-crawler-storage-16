r"""

- `CaptionFormatter`: responsible for formatting/printing captions.
- `Captioner`: does captioning logic, iterates, attaches to formatter.
- `CaptionLogger`: AgentLogger which pumps chunks to Captioner.
- `CaptionedAgent`: looks like an agent (wraps one) but does __call__ and echo through a CaptionLogger.
- `caption()`: wraps an agent in CaptionedAgent or decorates an agentic function so all calls go through CaptionLogger.

```
agent1 = spawn(...)
agent2 = spawn(...)

# Without this will use global caption formatter.
with CaptionLogger():
    asyncio.gather(
        agent1("Do task 1"),
        agent2("Do task 2"),
    )
```
prints animated blocks like so:
```
[/] Doing task 1...
[\] Doing task 2...
```

"""

import asyncio
from abc import ABC, abstractmethod
from textwrap import dedent
from types import FunctionType
from typing import Any, Callable, overload, override

from agentica_internal.core.log import LogBase
from agentica_internal.core.utils import copy_signature

from agentica.agent import Agent
from agentica.common import ModelStrings
from agentica.logging.agent_listener import NoopListener
from agentica.logging.agent_logger import NoLogging
from agentica.logging.loggers import StreamLogger
from agentica.std.utils import spoof_signature


class CaptionFormatter(ABC):
    """Configurable formatter/printer for captions."""

    @abstractmethod
    async def send(self, local_id: int, summary: str) -> None:
        """Take a summary and do something with it."""
        ...

    @abstractmethod
    def enter(self, local_id: int) -> None:
        """Signal that an agent is starting."""
        ...

    @abstractmethod
    def done(self, local_id: int) -> None:
        """Signal that an agent is done."""
        ...


class CaptionPrintFormatter(CaptionFormatter):
    """Prints captions to stdout."""

    summaries: dict[int, str]
    _task: asyncio.Task[None] | None
    _stop_event: asyncio.Event
    _refresh_per_second: float

    def __init__(self) -> None:
        super().__init__()
        self.summaries = dict()
        self._task = None
        self._stop_event = asyncio.Event()
        self._refresh_per_second = 8.0

    @override
    async def send(self, local_id: int, summary: str) -> None:
        MAX_LEN = 100
        SUFFIX = ' [...]'
        summary = summary.strip()
        if '\n' in summary:
            summary = summary.split('\n')[0]
        if len(summary) > MAX_LEN:
            summary = summary[: MAX_LEN - len(SUFFIX)] + SUFFIX

        self.summaries[local_id] = summary

        self._ensure_started()

    @override
    def enter(self, local_id: int) -> None:
        self.summaries[local_id] = ''
        self._ensure_started()

    @override
    def done(self, local_id: int) -> None:
        _ = self.summaries.pop(local_id, None)

    def _ensure_started(self) -> None:
        if self._task is None or self._task.done():
            if self._stop_event.is_set():
                self._stop_event = asyncio.Event()
            self._task = asyncio.create_task(self._run_live())

    async def _run_live(self) -> None:
        from rich.live import Live
        from rich.spinner import Spinner
        from rich.table import Table

        def render_table_from_items(items: list[tuple[int, str]]) -> Table:
            table = Table.grid(padding=(0, 1))
            table.add_column(no_wrap=True)
            table.add_column()
            for _local_id, _summary in sorted(items, key=lambda kv: kv[0]):
                display = _summary
                if not display:
                    prefix = f"Agent {_local_id}. "
                else:
                    prefix = f"Agent {_local_id}: "
                table.add_row(
                    Spinner("dots", style="bold blue"),
                    f"[bold]{prefix}[/][grey53]{display}[/]",
                )
            return table

        try:
            with Live(
                render_table_from_items([]),
                refresh_per_second=self._refresh_per_second,
                transient=True,
            ) as live:
                sleep_s = 1.0 / self._refresh_per_second
                while not self._stop_event.is_set():
                    await asyncio.sleep(sleep_s)

                    items = list(self.summaries.items())
                    if items:
                        live.update(render_table_from_items(items), refresh=False)
                    else:
                        live.update(render_table_from_items([]), refresh=False)
                        break
        finally:
            self._task = None
            if self._stop_event.is_set():
                self._stop_event = asyncio.Event()

    async def aclose(self) -> None:
        self._stop_event.set()
        task = self._task
        self._task = None
        if task is not None and not task.done():
            try:
                await task
            except Exception:
                pass

    def close(self) -> None:
        self._stop_event.set()
        if self._task is not None and not self._task.done():
            self._task.cancel()
        self._task = None

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass


_default_caption_formatter = CaptionPrintFormatter()


class Captioner(LogBase):
    """Dispatches captions to captioning agent."""

    caption_formatter: CaptionFormatter
    _captioning_agents: dict[int, Agent]
    _per_summary_prompt: str
    _ignore_keyword: str
    _system: str
    _model: ModelStrings
    _every_n: int
    _locks: dict[int, asyncio.Lock]
    _stops: dict[int, asyncio.Event]

    def __init__(
        self,
        *,
        caption_formatter: CaptionFormatter,
        system: str | None = None,
        model: ModelStrings = 'openai:gpt-3.5-turbo',
        per_summary_prompt: str | None = None,
        ignore_keyword: str | None = None,
        every_n_tokens: int = 45,
        logging: bool = False,
    ) -> None:
        super().__init__(logging=logging)
        self.caption_formatter = caption_formatter
        self._captioning_agents = {}
        self._locks = {}
        self._stops = {}

        if (per_summary_prompt is None) != (ignore_keyword is None) != (system is None):
            raise ValueError("per_summary_prompt and ignore_keyword and premise must set in tandem")

        if system is None:
            system = """
            Your job is to summarize chunks of text of another agent's live thought process.
            Start you sentences with present participle verbs (-ing endings) of the agent's thoughts/actions, such as:
            - "Thinking about ...";
            - "Implementing ...";
            - "Exploring ...";
            - "Explaining ...";
            - "Analyzing ...";
            - "Evaluating ...";
            - "Justifying ...";
            - "Defending ...";
            - "Investigating ...";
            - "Doing ...";
            - "Formulating ..."; and
            - so on and so forth.
            NEVER start you summary by referring to "the agent" or by referring to "the agent" in any way.
            Keep it short and concise. A single sentence is enough, no more than 10 words.

            You will receive from the user ONLY the THOUGHTS of the agent enclosed in <THOUGHTS></THOUGHTS> tags.
            If you believe your previously given summary is still relevant reply NO_UPDATE;
            otherwise, provide a brief <10 word summary of the THOUGHTS using the above criteria.

            **For example**, if the snippet of the agent's current THOUGHTS are:
                <THOUGHTS>
                There are three main criteria to consider for XYZ:
                1. The need for [...]
                2. The availability of [...]
                3. Having precisely [...]
                </THOUGHTS>

            Then, your assistant response message would be ONLY:
                Listing the three main criteria for XYZ.

            **End of explainer**: You will now receive the real thoughts of the agent.
            """
            system = dedent(system).strip()

        self._system = system
        self._model = model

        if per_summary_prompt is None:
            per_summary_prompt = '''
            <THOUGHTS>
            {}
            </THOUGHTS>
            '''
            per_summary_prompt = dedent(per_summary_prompt).strip()

        self._per_summary_prompt = per_summary_prompt

        if ignore_keyword is None:
            ignore_keyword = 'NO_UPDATE'

        self._ignore_keyword = ignore_keyword
        self._every_n = every_n_tokens

    async def consume(self, local_id: int, stream: StreamLogger) -> None:
        summary: str = ""
        collated = ""
        n = 1
        role = None

        try:
            async for chunk in stream:
                if self._is_stopped(local_id):
                    break
                if role != chunk.role:
                    collated += f'\n\n[{chunk.role}]\n'
                    role = chunk.role

                if n % self._every_n == 0:
                    try:
                        maybe_summary = await self.make_summary(local_id, collated)
                        if maybe_summary:
                            summary = maybe_summary
                            await self.caption_formatter.send(local_id, summary)
                    except Exception as e:
                        self.dump_exception(
                            e,
                            f"Captioner failed to generate summary for local_id {local_id}",
                        )
                        try:
                            await self.caption_formatter.send(local_id, "[Caption error]")
                        except:
                            pass
                    collated = ""

                collated += chunk.content
                n += 1

            if not self._is_stopped(local_id) and len(collated.split()) > self._every_n // 2:
                try:
                    if rem := await self.make_summary(local_id, collated):
                        await self.caption_formatter.send(local_id, rem)
                except Exception as e:
                    self.dump_exception(
                        e,
                        f"Captioner failed to generate final summary for local_id {local_id}",
                    )
                    try:
                        await self.caption_formatter.send(local_id, "[Caption error]")
                    except:
                        pass
        except Exception as e:
            self.dump_exception(
                e,
                f"Captioner task encountered unexpected error for local_id {local_id}",
            )
        finally:
            self.done(local_id)

    def consume_task(self, local_id: int, stream: StreamLogger) -> asyncio.Task[None]:
        return asyncio.create_task(self.consume(local_id, stream))

    def _get_agent(self, local_id: int) -> Agent:
        agent = self._captioning_agents.get(local_id)
        if agent is None:
            agent = Agent(
                system=self._system,
                model=self._model,
                listener=NoopListener,
            )
            self._captioning_agents[local_id] = agent
        return agent

    def _get_lock(self, local_id: int) -> asyncio.Lock:
        lock = self._locks.get(local_id)
        if lock is None:
            lock = asyncio.Lock()
            self._locks[local_id] = lock
        return lock

    def _get_stop_event(self, local_id: int) -> asyncio.Event:
        ev = self._stops.get(local_id)
        if ev is None:
            ev = asyncio.Event()
            self._stops[local_id] = ev
        return ev

    def _is_stopped(self, local_id: int) -> bool:
        ev = self._stops.get(local_id)
        return ev.is_set() if ev is not None else False

    def stop(self, local_id: int) -> None:
        self._get_stop_event(local_id).set()

    async def make_summary(self, local_id: int, collated: str) -> str | None:
        summary: str

        lock = self._get_lock(local_id)
        async with lock:
            if self._is_stopped(local_id):
                return None
            with NoLogging():
                collated = collated.strip()
                agent = self._get_agent(local_id)
                summary = await agent.call(self._per_summary_prompt.format(collated))

            if self._is_stopped(local_id):
                return None

        if self._ignore_keyword in summary:
            return None

        return summary

    def enter(self, local_id: int) -> None:
        self.caption_formatter.enter(local_id)

    def done(self, local_id: int) -> None:
        self.caption_formatter.done(local_id)
        agent = self._captioning_agents.pop(local_id, None)
        if agent is not None:
            try:
                agent.sync_close()
            except Exception:
                pass
        _ = self._locks.pop(local_id, None)
        _ = self._stops.pop(local_id, None)


class CaptionLogger(StreamLogger):
    captioner: Captioner
    _task: asyncio.Task[None] | None

    def __init__(self, caption_formatter: CaptionFormatter = _default_caption_formatter) -> None:
        super().__init__()
        self.captioner = Captioner(caption_formatter=caption_formatter)

    @override
    def on_call_enter(self, user_prompt: str, parent_local_id: int | None = None) -> None:
        super().on_call_enter(user_prompt, parent_local_id)
        assert self.local_id is not None
        self._task = self.captioner.consume_task(self.local_id, self)
        self.captioner.enter(self.local_id)

    @override
    def on_call_exit(self, result: object) -> None:
        assert self.local_id is not None

        self.captioner.stop(self.local_id)
        super().on_call_exit(result)

    async def __aenter__(self) -> None:
        return self.__enter__()

    @override
    def __exit__(self, exc_type, exc_value, traceback) -> None:
        if self.local_id is not None:
            self.captioner.stop(self.local_id)
        e = super().__exit__(exc_type, exc_value, traceback)

        return e

    async def __aexit__(self, exc_type, exc_value, traceback) -> None:
        if self.local_id is not None:
            self.captioner.stop(self.local_id)
        if self._task is not None:
            try:
                await self._task
            except Exception as e:
                self.captioner.dump_exception(e, "Caption task raised exception during cleanup")
        return self.__exit__(exc_type, exc_value, traceback)

    def __del__(self) -> None:
        self._task = None


class CaptionedAgent:
    _captioned_agent: Agent
    _captione_formatter: CaptionFormatter

    def __init__(
        self,
        agent: Agent,
        *,
        caption_formatter: CaptionFormatter,
    ) -> None:
        self._captioned_agent = agent
        self._captione_formatter = caption_formatter

    @copy_signature(Agent.call)
    def __call__(self, *args, **kwargs) -> Any:
        """See ``Agent.__call__``."""
        with CaptionLogger(self._captione_formatter):
            return self._captioned_agent.call(*args, **kwargs)


@overload
def caption(
    agent: Agent,
    /,
    caption_formatter: CaptionFormatter,
) -> CaptionedAgent: ...


@overload
def caption[F: FunctionType](
    agentic_function: Callable[[F], F],  # noqa: F841
    /,
    caption_formatter: CaptionFormatter,
) -> Callable[[F], F]: ...


def caption[F: FunctionType](
    magician: Agent | Callable[[F], F],
    /,
    caption_formatter: CaptionFormatter,
) -> CaptionedAgent | Callable[[F], F]:
    """
    Wrap an agent or agentic function in way that captures its echo stream and summarizes it.
    """
    if isinstance(magician, Agent):
        return CaptionedAgent(magician, caption_formatter=caption_formatter)
    else:
        caption_logger = CaptionLogger(caption_formatter=caption_formatter)

        def wrapped_captioned(*args, **kwargs) -> Any:
            with caption_logger:
                return magician(*args, **kwargs)

        spoof_signature(wrapped_captioned, magician)
        return wrapped_captioned
