"""
Standard library functions for web search and content retrieval using Exa.ai.
"""

import os
from dataclasses import dataclass

from exa_py import AsyncExa
from exa_py.api import ResultWithText

_exa = AsyncExa(api_key=os.getenv("EXA_API_KEY") or "")

__all__ = ["web_search", "web_fetch", "SearchResult"]


class MarkdownPage:
    """
    Represents a markdown page with content from Exa search results.
    Provides helper functions for accessing and searching within the text.
    """

    def __init__(self, content: str, url: str | None = None, title: str | None = None):
        self.content = content
        self.url = url
        self.title = title

    def __getitem__(self, index: slice) -> str:
        return self.content[index]

    def __len__(self) -> int:
        return len(self.content)

    def __str__(self) -> str:
        return self.content

    def search(self, query: str) -> list[str]:
        """
        Simple text search within the content.
        Returns lines containing the query.
        """
        lines = self.content.split('\n')
        matching_lines = [line for line in lines if query.lower() in line.lower()]
        return matching_lines

    async def semantic_search(self, query: str) -> list[str]:
        """
        Legacy method for backward compatibility.
        Since Exa provides high-quality search results, we can do simple text matching
        within the already relevant content.

        Args:
            query: The search query to find relevant content

        Returns:
            A list of relevant text chunks
        """

        paragraphs = [p.strip() for p in self.content.split('\n\n') if p.strip()]

        query_terms = query.lower().split()
        scored_paragraphs = []

        for paragraph in paragraphs:
            paragraph_lower = paragraph.lower()
            score = sum(1 for term in query_terms if term in paragraph_lower)
            if score > 0:
                scored_paragraphs.append((score, paragraph))

        scored_paragraphs.sort(key=lambda x: x[0], reverse=True)
        return [paragraph for score, paragraph in scored_paragraphs[:5]]


@dataclass
class SearchResult:
    """
    Represents a single search result from the search engine.
    """

    title: str
    url: str
    content: str
    score: float | None = None


async def web_search(query: str) -> list[SearchResult]:
    """
    Search the web and return structured results.

    Returns:
        List of SearchResult objects containing titles, URLs, and content
    """
    num_results = 5
    include_content = True

    if include_content:
        response = await _exa.search_and_contents(
            query=query,
            num_results=num_results,
            text=True,
        )
    else:
        response = await _exa.search(query=query, num_results=num_results)

    results = []
    for result in response.results:
        content = (
            getattr(result, 'text', '<content missing/>')
            if include_content
            else '<content omitted/>'
        )

        search_result = SearchResult(
            title=result.title or "<title missing/>",
            url=result.url,
            content=content,
            score=getattr(result, 'score', None),
        )
        results.append(search_result)
    return results


async def web_fetch(url: str) -> ResultWithText:
    """
    Fetch content from a URL or search query using Exa.ai.

    Returns:
        MarkdownPage object with the content
    """
    response = await _exa.get_contents([url], text=True)
    if response.results:
        return response.results[0]
    else:
        raise Exception(f"No content found for URL: {url}")
