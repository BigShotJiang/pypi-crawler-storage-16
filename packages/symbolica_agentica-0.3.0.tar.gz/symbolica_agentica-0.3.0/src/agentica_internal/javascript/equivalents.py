# fmt: off

__all__ = [
    'Number'
]


                                                                                

Number = int | float
