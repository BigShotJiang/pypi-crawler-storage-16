# fmt: off

from contextlib import contextmanager
from typing import Literal


__all__ = ['with_flags']


                                                                                

                                                                
INLINE_DEFINITIONS: bool = True

                                                         
CLASS_OPEN_KEYS: bool = False

                                                                               
DEFAULT_ASYNC_MODE: Literal['coro', 'future', 'sync'] = 'future'

                                                         
OBJECT_OPEN_KEYS: bool = True

                                                              
VIRTUAL_LAMBDAS: bool = False

                                                                                
VIRTUAL_FUNCTION_DEFAULTS: Literal['all', 'atoms', None] = 'atoms'

                                           
VIRTUAL_MODULES: bool = True

                                                                                  
VIRTUAL_ITERATORS: bool = False

                                               
VIRTUAL_FUTURES: bool = True

                                              
VIRTUAL_COROUTINES: bool = True

                                                         
VIRTUAL_OBJECT_MUTATION: bool = True
VIRTUAL_OBJECT_DUNDER_DICT: bool = True

                                                                            
VIRTUAL_CLASS_ATTRIBUTES: bool = True

                                                                               
VIRTUAL_RESOURCE_REQUEST_HOOKS: bool = True

                                                                                                 
RESPECT_WARP_AS: bool = True

                                                          
OMIT_PRIVATE_FIELDS: bool = True

                                                       
OMIT_PRIVATE_ANNOS: bool = True

                                                         
ALLOW_KNOWN_DUNDER_METHODS: bool = True

                
REALIZE_SYSTEM_ITERATORS: bool = True

                
ITERTOOLS_REDUCE_OBJ: bool = True

                
TYPE_ERASE_ENUMS: bool = True

                                               
INLINE_ATOMS: list[type] = []


                                                                                

def get_flags():
    g = globals()
    dct = {}
    for k, v in g.items():
        if '_' in k and k[0].isupper():
            dct[k] = v
    return dct

def set_flags(flags: dict):
    g = globals()
    for k, v in flags.items():
        g[k] = v

@contextmanager
def with_flags(**kwargs):
    old = get_flags()
    set_flags(kwargs)
    yield
    set_flags(old)
