from ...core.log import LogFlag
from ...core.print import MEDIUM

__all__ = [
    'LOG_VIRT',
    'LOG_ENCR',
    'LOG_DECR',
    'ICON_I',
    'ICON_M',
    'ICON_O',
    'ICON_E',
    'ICON_A',
    'ICON_C0',
    'ICON_C1',
]


LOG_VIRT = LogFlag('VIRT')
LOG_ENCR = LogFlag('ENCR')
LOG_DECR = LogFlag('DECR')


color = MEDIUM.R
ICON_I = color @ '-->'
ICON_M = color @ '---'
ICON_O = color @ '<--'
ICON_E = color @ '!!!'

color = MEDIUM.O
ICON_A = color @ '...'

color = MEDIUM.P
ICON_C0 = color @ '@@@'
ICON_C1 = color @ '^^^'
