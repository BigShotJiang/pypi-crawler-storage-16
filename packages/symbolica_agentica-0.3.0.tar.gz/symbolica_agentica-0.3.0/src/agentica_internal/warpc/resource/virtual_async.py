# fmt: off

import asyncio

from .__ import *
from .base import *

__all__ = [
    'FutureData',
    'unregister_virtual_future'
]
from ...core.futures import HookableFuture


                                                                                

type FutureHandler = Callable[[FutureT], Any]

class FutureData(ResourceData):
    __slots__ = 'future', 'result'

    future: FutureT                                                                      
    result: Result                                                                     

                                                                           
                                                                               
                                                                        
                                              
     
                                                                             
                                                                            
                                                                  
     
                                                                                     
                                                                                   
                                                                                     
                     
     
                                                                                 

    @classmethod
    def describe_resource(cls, future: asyncio.Future) -> 'FutureData':
        data = FutureData()
        data.future = future
        data.result = Result.from_future(future)
        return data

    def create_resource(self, handle: ResourceHandle) -> FutureT:
                                                                            
                                                                                
                                                                                 
                                                                                
                            
        future = self.future
        result = self.result
        handle.kind = Kind.Future
        setattr(future, VHDL, handle)
        result.into_future(future)                                  
        register_virtual_future(future)
        return future

                                                                                

                                               
def register_virtual_future(future: FutureT) -> None:

    if isinstance(future, HookableFuture):
        future.___set_hooks___(
            cancel_hook=send_future_cancel,
            set_result_hook=send_future_result,
            set_exception_hook=send_future_exception,
        )

                                                                              
                                                                                 
                                                                             
                                                                                
def unregister_virtual_future(future: FutureT) -> None:

    if isinstance(future, HookableFuture):
        future.___del_hooks___()

                                                                               
                                                                             
                                                                            
            
def send_future_cancel(future: asyncio.Future, _: None) -> None:

    unregister_virtual_future(future)

    if handle := get_handle(future):
        event = CancelFuture(future)
        handle.hdlr(handle, event)


def send_future_result(future: asyncio.Future, result: Any) -> None:

    unregister_virtual_future(future)

    if handle := get_handle(future):
        event = CompleteFuture(future, Result.good(result))
        handle.hdlr(handle, event)


def send_future_exception(future: asyncio.Future, exception: BaseException) -> None:

    unregister_virtual_future(future)

    if handle := get_handle(future):
        event = CompleteFuture(future, Result.bad(exception))
        handle.hdlr(handle, event)
