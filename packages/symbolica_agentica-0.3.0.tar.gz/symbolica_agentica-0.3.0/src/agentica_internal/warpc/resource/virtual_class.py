# fmt: off

import typing
from dataclasses import KW_ONLY
from enum import EnumType
from typing import _TypedDictMeta  # type: ignore
from typing import _ProtocolMeta

from ..msg.term_exception import EXC_NEW_ARGS
from .__ import *
from .base import *
from .handle import is_virtual_class
from .stub_methods import V_CLASS_GETITEM, V_OBJECT_METHODS

__all__ = [
    'ClassData',
]


                                                                                

class ClassData(ResourceData):
    __slots__ = (
        'name', 'qname', 'module', 'doc', 'cls', 'bases', 'methods', 'attrs',
        'sattrs', 'params', 'keys', 'annos',
    )

    FORBIDDEN_FORM = forbidden_class

    name:     str
    qname:    optstr
    module:   optstr
    doc:      optstr
    cls:      ClassT
    bases:    ClassesTupleT
    methods:  MethodsT
    attrs:    AttributesT
    sattrs:   strtup
    params:   Tup[TypeT]
    annos:    AnnotationsT
    keys:     strtup

                                                                            
                                                                                              
                                                                                           

                                                                                                      
                                                                                             
                                                                                               

                                                                                                    
                                                                                              
                                                                                                 

                                   
    @classmethod
    def describe_resource(cls, cls_obj: ClassT) -> 'ClassData': ...  # noqa: F841

                                   
    def create_resource(self, handle: ResourceHandle) -> ClassT: ...


                                                                                

                                                       
def is_private_field(ckey: str) -> bool:
    return ckey.startswith('_')

def describe_real_class(cls: type) -> ClassData:
    data = ClassData()

    assert isinstance(cls, type), f"{f_object_id(cls)} is not a class"

    bases, cdict, name, qname, module, doc = get_cls_attrs(cls)

    qname = qname if type(qname) is str else None
    doc = doc if type(doc) is str else None
    module = module if type(module) is str else None

    if not is_str(name):
        raise E.WarpEncodingError(f"class {cls!r} name {f_object_id(name)} is not a string")

    if not is_tup(bases):
        raise E.WarpEncodingError(f"class {cls!r} bases {f_object_id(bases)} is not a tuple")

    if is_forbidden(cls, module):
        raise E.WarpEncodingForbiddenError(f"<class {cls.__module__}.{cls.__qualname__}'>")

    data.name = name
    data.qname = qname
    data.module = module
    data.doc = doc

    mcls = type(cls)
    data.cls = mcls
    data.bases = bases

    no_priv_fields = flags.OMIT_PRIVATE_FIELDS
    no_priv_annos = flags.OMIT_PRIVATE_ANNOS
    allow_dunders = flags.ALLOW_KNOWN_DUNDER_METHODS

    data.methods, add_meth = mkdict()
    data.attrs, add_attr = mkdict()
    keys = []
    for ckey, cval in cdict.items():
        if ckey in CLS_IGNORE:
            continue
        if ckey.startswith('___'):
            continue
        if no_priv_fields and is_private_field(ckey) and ckey != '__init__':
            if not allow_cls_attr(ckey, allow_dunders):
                continue
                                                                                                            
                                                                                                  
        if is_property_t(cval):
            continue
        elif is_method_t(cval):
            add_meth(ckey, cval)
        elif ckey in CLASS_ATTR_WHITELIST:
            add_attr(ckey, cval)
        else:
            keys.append(ckey)

    data.keys = tuple(keys)
    data.params = getattr(cls, TPARAMS, ())

    sattrs, annos = multi_get_raw(cls, SATTRS, ANNOS)

    if not is_strtup(sattrs):
        sattrs = ()

    if not is_rec(annos):
        annos = {}

    if sattrs and no_priv_fields:
        sattrs = tuple(s for s in sattrs if not is_private_field(s))

    if annos and no_priv_annos:
        annos = {k: v for k, v in annos.items() if not is_private_field(k) or v is KW_ONLY}

    data.sattrs = sattrs
    data.annos = annos

    return data


                                                                                

def allow_cls_attr(ckey: str, allow_dunders: bool) -> bool:
    if not ckey.startswith('_'):
        return True
    elif ckey in CLASS_ATTR_WHITELIST:
        return True
    elif allow_dunders and ckey.endswith('__') and ckey in KNOWN_DUNDER_METHODS:
        return True
    else:
        return False

                                                                                

def create_virtual_class(data: ClassData, handle: ResourceHandle) -> ClassT:

    handle.kind = Kind.Class

    name = data.name
    qname = data.qname
    bases = data.bases

    cdict, add = mkdict()

                                                                                

                                                                                       

                                                                                              
             
    keys = set(data.keys)

    any_virtual_bases = False
    for base in bases:
        if is_virtual_class(base):
            any_virtual_bases = True

            if base.__flags__ & HEAP_CLASS:
                keys |= cls_handle(base).keys

    if not any_virtual_bases:
                                                               
                                                                                            
                                                                                     
                                    
        cdict.update(V_OBJECT_METHODS)

                                                                       
    handle.keys = keys
    handle.open = flags.CLASS_OPEN_KEYS
    handle.name = name

                                                                                

                                                                                              
                                                                                                   
                                                                                    
                                                                                               
                    

                                                                                         
                                                                                          
                                                                                          
                                                                                             
                                                                                              

    def __new__(cls, *args, **kwargs):
        if len(args) == 1 and type(args[0]) is ResourceHandle:
            base = object
            if issubclass(cls, Exception):
                base = Exception
            elif issubclass(cls, BaseException):
                base = BaseException
            v_obj = base.__new__(cls)
            obj_set(v_obj, VHDL, args[0])
            return v_obj
        v_obj = handle.hdlr(handle, ResourceNew(cls, args, kwargs))
        if issubclass(cls, (BaseException, Exception)):
            object.__setattr__(v_obj, EXC_NEW_ARGS, tuple(args))
        return v_obj

                                                                                

                 
    for k, m in data.methods.items():
        add(k, m)

    add('__new__', __new__)

                                                                                

                                      
    for k, a in data.attrs.items():
        add(k, a)

                                                                                

                  
    add(VHDL, handle)
    add(QUALNAME, qname)
    add(MODULE, data.module)
    add(DOC, data.doc)
    add(SATTRS, data.sattrs)
    add(ANNOS, data.annos)
    add(TPARAMS, data.params)

                                                                                

    bases = tuple(b for b in data.bases if b not in EXCLUDE_BASES)

    if data.params:
                                                                                         
        add('__class_getitem__', V_CLASS_GETITEM)

    mcls = data.cls

                                                                                

    error: TypeError | None = None
    try:
        if mcls is _ProtocolMeta:
            cdict['_is_protocol'] = True
            cdict['_is_runtime_protocol'] = True

        if typing.Protocol in bases and any(not issubclass(b, typing.Protocol) for b in bases):
            bases = tuple(b for b in bases if b is not typing.Protocol)

        if mcls is EnumType:
            raise E.WarpDecodingError('enums not supported')
        elif mcls is _TypedDictMeta:
            bases = tuple(b for b in bases if b is not dict)
                                                                 
            total = data.attrs.get('__total__', True)
            v_cls = mcls(name, bases, cdict, total=total)
        else:
            v_cls = mcls(name, bases, cdict)

    except Exception as exc:
        error = exc
        v_cls = type

    if error:
        f_error = D.fmt_exception(error)
        problem = f"Error creating virtual class {name!r} with bases {bases!r} and mcls {mcls!r}:\n"
        raise E.WarpDecodingError(problem + f_error)

                                                                                

                                                                                 
                                                 
    if flags.VIRTUAL_CLASS_ATTRIBUTES:
                                                                                 
                                                                                                      
                                                                      
        for key in keys:
            if key in cdict:
                                                                                   
                                          
                continue
            v_attr = class_attribute(handle)
            cls_set(v_cls, key, v_attr)
            v_attr.__set_name__(v_cls, key)

    return v_cls


                                                                               

class class_attribute:
                                                   
    __slots__ = 'name', '__objclass__', VHDL

    def __init__(self, handle: ResourceHandle) -> None:
        self.___vhdl___ = handle
        self.__objclass__ = object
        self.name = '<unset>'

    def __set_name__(self, owner: type, name: str) -> None:
        self.__objclass__ = owner
        self.name = name

    def __get__(self, _, owner: Any = None):
        handle = self.___vhdl___
        request = ResourceGetAttr(self.__objclass__, self.name)
        return handle.hdlr(handle, request)

    def __repr__(self):
        return f'<attribute {self.name!r}>'

    __str__ = __repr__


                                                                               

HEAP_CLASS = 1 << 9

get_cls_attrs = O.attrgetter(BASES, DICT, NAME, QUALNAME, MODULE, DOC)

CLS_REQUIRED = (
    BASES,
    DICT,
    NAME,
    QUALNAME,
    MODULE,
    DOC,
)
CLS_OPTIONAL = SATTRS, ANNOS
CLS_INTERNAL = WEAKREF, FSTLINE, SLOTS
CLS_HOOKED = '__str__', '__repr__', '__hash__', '__getattr__', '__setattr__', '__delattr__'
CLS_IGNORE = CLS_REQUIRED + CLS_OPTIONAL + CLS_INTERNAL + CLS_HOOKED

EXCLUDE_BASES = [T.Generic]

                                                                                

                                 
ClassData.describe_resource = staticmethod(describe_real_class)
ClassData.create_resource = create_virtual_class
