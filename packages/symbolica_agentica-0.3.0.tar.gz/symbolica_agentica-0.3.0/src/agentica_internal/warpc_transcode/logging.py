# fmt: off

from ..core.log import LogFlag

                                                                                

LOG_TS = LogFlag('TS')
