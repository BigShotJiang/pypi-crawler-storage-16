SUPPORTED_CHAT_MODELS: list[str] = [
    "cerebras:qwen-3-235b-a22b-instruct-2507",
]

SUPPORTED_REASONING_MODELS: list[str] = [
    "cerebras:zai-glm-4.6",
    "cerebras:gpt-oss-120b",
    "cerebras:qwen-3-32b",
]
