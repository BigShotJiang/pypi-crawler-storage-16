"""Version number."""

version = "2025.12.0"
