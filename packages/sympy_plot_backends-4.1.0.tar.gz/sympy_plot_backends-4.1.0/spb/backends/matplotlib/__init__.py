from spb.backends.matplotlib.matplotlib import (
    MatplotlibBackend, MB, unset_show
)

__all__ = ["MatplotlibBackend", "MB", "unset_show"]
