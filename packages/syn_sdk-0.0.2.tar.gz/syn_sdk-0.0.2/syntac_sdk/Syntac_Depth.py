
if 0:
    import warnings
    warnings.filterwarnings("ignore", message="Failed to load image Python extension")
    warnings.filterwarnings("ignore", message="xFormers is available")
    warnings.filterwarnings("ignore", message="pkg_resources is deprecated")
    import pyudev
    import os
    import re
    import math
    import os
    import cv2
    import numpy as np
    from scipy import fftpack
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    import re
    import matplotlib.pyplot as plt
    import struct
    import serial
    import time


    class BGRXYMLPNet(nn.Module):
        """
        The Neural Network architecture for GelSight calibration.
        """

        def __init__(self):
            super(BGRXYMLPNet, self).__init__()
            input_size = 21
            self.fc1 = nn.Linear(input_size, 32)
            self.fc2 = nn.Linear(32, 32)
            self.fc3 = nn.Linear(32, 32)
            self.fc4 = nn.Linear(32, 32)
            self.fc5 = nn.Linear(32, 32)
            self.fc6 = nn.Linear(32, 2)

        def forward(self, x):
            x = F.relu_(self.fc1(x))
            x = F.relu_(self.fc2(x))
            x = F.relu_(self.fc3(x))
            x = F.relu_(self.fc4(x))
            x = F.relu_(self.fc5(x))
            x = self.fc6(x)
            return x

    class Reconstructor:

        def __init__(self, model_path, contact_mode="standard", device="cpu"):

            self.model_path = model_path
            self.contact_mode = contact_mode
            self.device = device
            self.bg_image = None

            if not os.path.isfile(model_path):
                raise ValueError("Error opening %s, file does not exist" % model_path)
            self.gxy_net = BGRXYMLPNet()
            self.gxy_net.load_state_dict(torch.load(model_path), self.device)
            self.gxy_net.to(self.device)
            self.gxy_net.eval()

        def load_bg(self, bg_image):
            self.bg_image = bg_image
            bgrxys = image2bgrxys(bg_image, n_freq=4).reshape(-1,21)
            features = torch.from_numpy(bgrxys).float().to(self.device)
            with torch.no_grad():
                gxyangles = self.gxy_net(features)
                gxyangles = gxyangles.cpu().detach().numpy()
                self.bg_G = np.tan(
                    gxyangles.reshape(bg_image.shape[0], bg_image.shape[1], 2)
                )

        def get_surface_info(
            self, image, ppmm, color_dist_threshold=15, height_threshold=0.2
        ):

            bgrxys = image2bgrxys(image, n_freq=4).reshape(-1,21)
            features = torch.from_numpy(bgrxys).float().to(self.device)
            with torch.no_grad():
                gxyangles = self.gxy_net(features)
                gxyangles = gxyangles.cpu().detach().numpy()
                G = np.tan(gxyangles.reshape(image.shape[0], image.shape[1], 2))
                if self.bg_image is not None:
                    G = G - self.bg_G
                else:
                    raise ValueError("Background image is not loaded.")

 
            H = poisson_dct_neumaan(G[:, :, 0], G[:, :, 1]).astype(np.float32)


            if self.contact_mode == "standard":
                diff_image = image.astype(np.float32) - self.bg_image.astype(np.float32)
                color_mask = np.linalg.norm(diff_image, axis=-1) > color_dist_threshold
                color_mask = cv2.dilate(
                    color_mask.astype(np.uint8), np.ones((7, 7), np.uint8)
                )
                color_mask = cv2.erode(
                    color_mask.astype(np.uint8), np.ones((15, 15), np.uint8)
                )
                cutoff = np.percentile(H, 85) - height_threshold / ppmm
                height_mask = H < cutoff
                C = np.logical_and(color_mask, height_mask)
                C = cv2.dilate(C.astype(np.uint8), np.ones((15, 15), np.uint8))
                C = cv2.erode(C.astype(np.uint8), np.ones((25, 25), np.uint8))
                C = cv2.dilate(C.astype(np.uint8), np.ones((7, 7), np.uint8))
                C = C.astype(np.bool_)


            elif self.contact_mode == "flat":

                diff_image = image.astype(np.float32) - self.bg_image.astype(np.float32)
                color_mask = np.linalg.norm(diff_image, axis=-1) > 10
                color_mask = cv2.dilate(
                    color_mask.astype(np.uint8), np.ones((15, 15), np.uint8)
                )
                C = cv2.erode(
                    color_mask.astype(np.uint8), np.ones((25, 25), np.uint8)
                ).astype(np.bool_)
            return G, H, C


    def fourier_encode(x, y, n_freq):
        H, W = x.shape
        feats = []
        for k in range(n_freq):
            freq = 2 ** k * np.pi
            feats.append(np.sin(freq * x))
            feats.append(np.cos(freq * x))
            feats.append(np.sin(freq * y))
            feats.append(np.cos(freq * y))
        return np.stack(feats, axis=2)  

    def image2bgrxys(image, n_freq=4):
        H, W, _ = image.shape
        ys = np.linspace(0, 1, H, endpoint=False, dtype=np.float32)
        xs = np.linspace(0, 1, W, endpoint=False, dtype=np.float32)
        xx, yy = np.meshgrid(xs, ys, indexing="xy")
        BGR = image.astype(np.float32)/255.0
        bgrxy = np.concatenate([BGR, xx[...,None], yy[...,None]], axis=2)
        pos_feats = fourier_encode(xx, yy, n_freq) 

        return np.concatenate([bgrxy, pos_feats], axis=2)

    def poisson_dct_neumaan(gx, gy):

        gxx = 1 * (
            gx[:, (list(range(1, gx.shape[1])) + [gx.shape[1] - 1])]
            - gx[:, ([0] + list(range(gx.shape[1] - 1)))]
        )
        gyy = 1 * (
            gy[(list(range(1, gx.shape[0])) + [gx.shape[0] - 1]), :]
            - gy[([0] + list(range(gx.shape[0] - 1))), :]
        )
        f = gxx + gyy

        b = np.zeros(gx.shape)
        b[0, 1:-2] = -gy[0, 1:-2]
        b[-1, 1:-2] = gy[-1, 1:-2]
        b[1:-2, 0] = -gx[1:-2, 0]
        b[1:-2, -1] = gx[1:-2, -1]
        b[0, 0] = (1 / np.sqrt(2)) * (-gy[0, 0] - gx[0, 0])
        b[0, -1] = (1 / np.sqrt(2)) * (-gy[0, -1] + gx[0, -1])
        b[-1, -1] = (1 / np.sqrt(2)) * (gy[-1, -1] + gx[-1, -1])
        b[-1, 0] = (1 / np.sqrt(2)) * (gy[-1, 0] - gx[-1, 0])

        f[0, 1:-2] = f[0, 1:-2] - b[0, 1:-2]
        f[-1, 1:-2] = f[-1, 1:-2] - b[-1, 1:-2]
        f[1:-2, 0] = f[1:-2, 0] - b[1:-2, 0]
        f[1:-2, -1] = f[1:-2, -1] - b[1:-2, -1]

        f[0, -1] = f[0, -1] - np.sqrt(2) * b[0, -1]
        f[-1, -1] = f[-1, -1] - np.sqrt(2) * b[-1, -1]
        f[-1, 0] = f[-1, 0] - np.sqrt(2) * b[-1, 0]
        f[0, 0] = f[0, 0] - np.sqrt(2) * b[0, 0]

        tt = fftpack.dct(f, norm="ortho")
        fcos = fftpack.dct(tt.T, norm="ortho").T

        (x, y) = np.meshgrid(range(1, f.shape[1] + 1), range(1, f.shape[0] + 1), copy=True)
        denom = 4 * (
            (np.sin(0.5 * math.pi * x / (f.shape[1]))) ** 2
            + (np.sin(0.5 * math.pi * y / (f.shape[0]))) ** 2
        ).astype(np.float32)

        f = -fcos / denom
        tt = fftpack.idct(f, norm="ortho")
        img_tt = fftpack.idct(tt.T, norm="ortho").T
        img_tt = img_tt.mean() + img_tt

        return img_tt


    pts_src = np.float32([
        [172. , 3.],
        [442. , 3.],
        [429. ,413.],
        [185. ,413.]
    ])

    width, height = 270, 410
    pts_dst = np.float32([
        [0, 0],
        [width - 1, 0],
        [width - 1, height - 1],
        [0, height - 1]
    ])

    M = cv2.getPerspectiveTransform(pts_src, pts_dst)

    class Camera:

        def __init__(self, ID, imgh=480, imgw=640):

            self.dev_type = ID
            self.dev_id = get_camera_id(self.dev_type)
            self.imgh = imgh
            self.imgw = imgw
            self.cam = None
            self.data = None
            self.camera_matrix, self.dist_coeffs, self.new_camera_matrix ,self.roi = self.load_camera_params()
            self.background_frame = None


        def Undistortion(self, frame, camera_matrix, dist_coeffs, new_camera_matrix, roi=None):

            undistorted = cv2.undistort(frame, camera_matrix, dist_coeffs, None, new_camera_matrix)
            if roi is not None:
                x, y, w, h = roi
                if w > 0 and h > 0:
                    undistorted = undistorted[y:y+h, x:x+w]
            return undistorted
        


        def load_camera_params(self):

            camera_matrix = np.array([
                [471.27097, 0.0, 301.10844],
                [0.0, 471.63526, 199.18465],
                [0.0, 0.0, 1.0]
            ])
            dist_coeffs = np.array([-0.254406, 0.029868, 0.002644, -0.000091, 0.0])
            image_width = 640
            image_height = 480

            new_camera_matrix, roi = cv2.getOptimalNewCameraMatrix(
                camera_matrix, dist_coeffs, (image_width, image_height), alpha=1, centerPrincipalPoint=True
            )

            return camera_matrix, dist_coeffs, new_camera_matrix, roi
        


        def connect(self):

            self.cam = cv2.VideoCapture(self.dev_id)
            self.cam.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
            self.cam.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

            self.cam.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            
            if self.cam is None or not self.cam.isOpened():
                print("Warning: unable to open video source %d" % (self.dev_id))
                return False
            else:
                print("Connect to %s at video source %d" % (self.dev_type, self.dev_id))
                
            num_frames = 10
            frame_sum = None
            frames_captured = 0

            for _ in range(30): 
                self.cam.read()

            for i in range(num_frames):
                ret, f0 = self.cam.read()
                if ret:
                    processed_frame = self._process_frame(f0)
                    
                    if frame_sum is None:
                        frame_sum = processed_frame.astype(np.float64)
                    else:
                        frame_sum += processed_frame.astype(np.float64)
                    frames_captured += 1
                else:
                    print(f"Warning: Failed to read frame {i+1} during background capture.")
            
            if frames_captured > 0:
                self.background_frame = (frame_sum / frames_captured).astype(np.float32)
            else:
                print("ERROR! Failed to capture any frames for background. Background will be None.")
                self.background_frame = None

            return True
        
        def _process_frame(self, frame):

            undistorted_frame = self.Undistortion(frame, self.camera_matrix, self.dist_coeffs, self.new_camera_matrix, self.roi)

            undistorted_frame = cv2.resize(undistorted_frame, (self.imgw, self.imgh))

            undistorted_frame  = cv2.warpPerspective(undistorted_frame, M, (width, height))
            return undistorted_frame


        def get_image(self, flush=False):

            if self.background_frame is None:
                    print("ERROR! Background image is not set. Cannot compute difference.")
                    return None
            
            if flush:

                for i in range(20):
                    ret, f0 = self.cam.read()
            ret, f0 = self.cam.read()
            if ret:

                current_frame = self._process_frame(f0)

                current_frame = current_frame.astype(np.float32)  
                self.background_frame = self.background_frame.astype(np.float32)

                diff_frame = current_frame - self.background_frame
                diff_frame = (diff_frame*2 + 255)  
                diff_frame = diff_frame / 2
                self.data = diff_frame.astype(np.uint8)
            else:
                print("ERROR! reading image from video source %d" % (self.dev_id))
            return self.data

        def release(self):

            if self.cam is not None:
                self.cam.release()
                print("Video source %d released." % (self.dev_id))
            else:
                print("No camera to release.")

    def get_camera_id(camera_name, verbose=True):

        min_cam_id = None
        context = pyudev.Context()
        

        for device in context.list_devices(subsystem='video4linux'):
            dev_node = device.device_node

            file_name = os.path.basename(dev_node)
            match = re.search(r'\d+$', file_name)
            
            if not match:
                continue
                
            cam_id = int(match.group(0)) 
            current_serial = "N/A"
            found = "      "
            
            current_device = device
            while current_device:
                if 'ID_SERIAL_SHORT' in current_device:
                    current_serial = current_device['ID_SERIAL_SHORT']
                    break
                if 'ID_SERIAL' in current_device:
                    current_serial = current_device['ID_SERIAL']
                    break
                
                current_device = current_device.parent 
            

            if camera_name in current_serial:
                found = "FOUND!"
                

                if min_cam_id is None or cam_id < min_cam_id:
                    min_cam_id = cam_id

            
            if verbose:
                print(f"{found} {dev_node} (V4L2 Index: {cam_id}) -> Serial: {current_serial}")


        return min_cam_id





    config = {
        "ppmm": 0.058,
        "imgh": 410,
        "imgw": 270,
        "raw_imgh": 480,
        "raw_imgw": 640,
        "framerate": 30,
    }


    class Surface:
        def __init__(self, Camera):
            
            self.raw_imgh = config["raw_imgh"]
            self.raw_imgw = config["raw_imgw"]
            self.ppmm = config["ppmm"]

            self.device = Camera
            self.device.connect()
            self.model_path = "syntac_sdk/models/nnmodel.pth"
            self.recon = Reconstructor(self.model_path, device="cuda")


            print("Collecting bg, please wait ...")
            self.device.get_image(flush=True)
            self.bg_images = [self.device.get_image() for _ in range(2)]
            self.bg_image = np.mean(self.bg_images, axis=0).astype(np.uint8)
            self.recon.load_bg(self.bg_image)

        def SurfaceDepth(self):
        
            image = self.device.get_image()

            G, H, C = self.recon.get_surface_info(image, self.ppmm)


            red = G[:, :, 0] * 255 / 3.0 + 127
            red = np.clip(red, 0, 255)
            blue = G[:, :, 1] * 255 / 3.0 + 127
            blue = np.clip(blue, 0, 255)
            grad_image = np.stack((blue, np.zeros_like(blue), red), axis=-1).astype(np.uint8)


            H_min = -120
            H_max = 0
            gamma = 4

            H_clipped = np.clip(H, H_min, H_max)
            H_norm = (H_clipped - H_min) / (H_max - H_min)

            depth = np.power(H_norm, gamma)

            cmap_mpl = plt.get_cmap("jet_r")
            H_vis = cmap_mpl(depth)[:, :, :3]  
            H_vis = (H_vis * 255).astype(np.uint8)
            depth_visualization = cv2.cvtColor(H_vis, cv2.COLOR_RGB2BGR)


            C = (C.astype(np.uint8)) * 255 

            return depth, depth_visualization,C,image
        
        def release(self):
            self.device.release()




    class KalmanFilter:
        def __init__(self, process_variance=1e-3, measurement_variance=1e-1):
            self.x = 0.0
            self.P = 1.0
            self.Q = process_variance
            self.R = measurement_variance
            self.initialized = False

        def update(self, measurement):
            if not self.initialized:
                self.x = measurement
                self.initialized = True
                return self.x

            self.P += self.Q
            K = self.P / (self.P + self.R)
            self.x = self.x + K * (measurement - self.x)
            self.P = (1 - K) * self.P
            return self.x



    class DistaceAndTempratureData:
        def __init__(self, SERIAL_PORT = "/dev/ttyACM0"):

            self.FRAME_HEAD = b'\xAA\x55' 
            self.DATA_LEN_FIELD = 0x08
            self.FRAME_LEN = 2 + 1 + 8 + 1 
            self.BAUD_RATE = 115200 
            
            self.kf_dist1 = KalmanFilter(process_variance=1e-1, measurement_variance=3)
            self.kf_dist2 = KalmanFilter(process_variance=1e-1, measurement_variance=3)
            self.start_time = time.time()
            
            try:
                self.ser = serial.Serial(SERIAL_PORT, self.BAUD_RATE, timeout=0.01) 
                print(f"接口打开成功：{SERIAL_PORT}, {self.BAUD_RATE}")
            except Exception as e:
                print(f"接口打开失败: {e}")
                exit(1)

        def _calculate_checksum(self, data: bytes) -> int:
            total_sum = sum(data)
            checksum = total_sum & 0xFF 
            return checksum

        def read_sensor_frame(self, ser):
            while True:
                byte = ser.read(1) 
                if not byte:
                    return None
                if byte == self.FRAME_HEAD[0:1]:
                    next_byte = ser.read(1)
                    if next_byte == self.FRAME_HEAD[1:2]:
                        break
                    else:
                        continue 

            remaining_data = ser.read(self.FRAME_LEN - len(self.FRAME_HEAD)) 
            
            if len(remaining_data) != (self.FRAME_LEN - len(self.FRAME_HEAD)):
                return None

            data_len_field = remaining_data[0] 
            if data_len_field != self.DATA_LEN_FIELD:
                return None
            
            sensor_data = remaining_data[1:-1] 
            received_checksum = remaining_data[-1]
            
            calculated_checksum = self._calculate_checksum(sensor_data)
            if received_checksum != calculated_checksum:

                return None

            try:
                dist1, dist2, tem_env_raw, tem_obj_raw = struct.unpack(">hhhh", sensor_data)
            except struct.error as e:

                return None

            dist1_filtered = self.kf_dist1.update(dist1)
            dist2_filtered = self.kf_dist2.update(dist2)

            tem_env = tem_env_raw / 10.0
            tem_obj = tem_obj_raw / 10.0

            return dist1_filtered, dist2_filtered, tem_env, tem_obj

        def get_data(self):
            
            self.frame = self.read_sensor_frame(self.ser)
            if self.frame is not None:

                dist1, dist2, tem_env, tem_obj = self.frame

                
                return dist1, dist2, tem_env, tem_obj

        def close_serial(self):
            if hasattr(self, 'ser') and self.ser.is_open:
                self.ser.close()
                print("接口已关闭。")

        def __del__(self):
            self.close_serial()

if 1:
    import warnings
    warnings.filterwarnings("ignore", message="Failed to load image Python extension")
    warnings.filterwarnings("ignore", message="xFormers is available")
    warnings.filterwarnings("ignore", message="pkg_resources is deprecated")
    import pyudev
    import os
    import re
    import math
    import os
    import cv2
    import numpy as np
    from scipy import fftpack
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    import re
    import matplotlib.pyplot as plt
    import struct
    import serial
    import time

    '''
    MLP net + Fourier positional encoding
    '''
    class BGRXYMLPNet(nn.Module):
        """
        The Neural Network architecture for GelSight calibration.
        """

        def __init__(self):
            super(BGRXYMLPNet, self).__init__()
            input_size = 21
            self.fc1 = nn.Linear(input_size, 32)
            self.fc2 = nn.Linear(32, 32)
            self.fc3 = nn.Linear(32, 32)
            self.fc4 = nn.Linear(32, 32)
            self.fc5 = nn.Linear(32, 32)
            self.fc6 = nn.Linear(32, 2)

        def forward(self, x):
            x = F.relu_(self.fc1(x))
            x = F.relu_(self.fc2(x))
            x = F.relu_(self.fc3(x))
            x = F.relu_(self.fc4(x))
            x = F.relu_(self.fc5(x))
            x = self.fc6(x)
            return x

    class Reconstructor:

        def __init__(self, model_path, contact_mode="standard", device="cpu"):

            self.model_path = model_path
            self.contact_mode = contact_mode
            self.device = device
            self.bg_image = None

            if not os.path.isfile(model_path):
                raise ValueError("Error opening %s, file does not exist" % model_path)
            self.gxy_net = BGRXYMLPNet()
            self.gxy_net.load_state_dict(torch.load(model_path), self.device)
            self.gxy_net.to(self.device)
            self.gxy_net.eval()

        def load_bg(self, bg_image):
            self.bg_image = bg_image
            bgrxys = image2bgrxys(bg_image, n_freq=4).reshape(-1,21)
            features = torch.from_numpy(bgrxys).float().to(self.device)
            with torch.no_grad():
                gxyangles = self.gxy_net(features)
                gxyangles = gxyangles.cpu().detach().numpy()
                self.bg_G = np.tan(
                    gxyangles.reshape(bg_image.shape[0], bg_image.shape[1], 2)
                )

        def get_surface_info(
            self, image, ppmm, color_dist_threshold=15, height_threshold=0.2
        ):

            bgrxys = image2bgrxys(image, n_freq=4).reshape(-1,21)
            features = torch.from_numpy(bgrxys).float().to(self.device)
            with torch.no_grad():
                gxyangles = self.gxy_net(features)
                gxyangles = gxyangles.cpu().detach().numpy()
                G = np.tan(gxyangles.reshape(image.shape[0], image.shape[1], 2))
                if self.bg_image is not None:
                    G = G - self.bg_G
                else:
                    raise ValueError("Background image is not loaded.")

            H = poisson_dct_neumaan(G[:, :, 0], G[:, :, 1]).astype(np.float32)

            if self.contact_mode == "standard":
                diff_image = image.astype(np.float32) - self.bg_image.astype(np.float32)
                color_mask = np.linalg.norm(diff_image, axis=-1) > color_dist_threshold
                color_mask = cv2.dilate(
                    color_mask.astype(np.uint8), np.ones((7, 7), np.uint8)
                )
                color_mask = cv2.erode(
                    color_mask.astype(np.uint8), np.ones((15, 15), np.uint8)
                )

                cutoff = np.percentile(H, 85) - height_threshold / ppmm
                height_mask = H < cutoff

                C = np.logical_and(color_mask, height_mask)
                C = cv2.dilate(C.astype(np.uint8), np.ones((15, 15), np.uint8))
                C = cv2.erode(C.astype(np.uint8), np.ones((25, 25), np.uint8))
                C = cv2.dilate(C.astype(np.uint8), np.ones((7, 7), np.uint8))
                C = C.astype(np.bool_)

            elif self.contact_mode == "flat":

                diff_image = image.astype(np.float32) - self.bg_image.astype(np.float32)
                color_mask = np.linalg.norm(diff_image, axis=-1) > 10
                color_mask = cv2.dilate(
                    color_mask.astype(np.uint8), np.ones((15, 15), np.uint8)
                )
                C = cv2.erode(
                    color_mask.astype(np.uint8), np.ones((25, 25), np.uint8)
                ).astype(np.bool_)
            return G, H, C

    def fourier_encode(x, y, n_freq):
        H, W = x.shape
        feats = []
        for k in range(n_freq):
            freq = 2 ** k * np.pi
            feats.append(np.sin(freq * x))
            feats.append(np.cos(freq * x))
            feats.append(np.sin(freq * y))
            feats.append(np.cos(freq * y))
        return np.stack(feats, axis=2)  

    def image2bgrxys(image, n_freq=4):
        H, W, _ = image.shape
        ys = np.linspace(0, 1, H, endpoint=False, dtype=np.float32)
        xs = np.linspace(0, 1, W, endpoint=False, dtype=np.float32)
        xx, yy = np.meshgrid(xs, ys, indexing="xy")

        BGR = image.astype(np.float32)/255.0
        bgrxy = np.concatenate([BGR, xx[...,None], yy[...,None]], axis=2)
        pos_feats = fourier_encode(xx, yy, n_freq) 
        return np.concatenate([bgrxy, pos_feats], axis=2)

    def poisson_dct_neumaan(gx, gy):

        gxx = 1 * (
            gx[:, (list(range(1, gx.shape[1])) + [gx.shape[1] - 1])]
            - gx[:, ([0] + list(range(gx.shape[1] - 1)))]
        )
        gyy = 1 * (
            gy[(list(range(1, gx.shape[0])) + [gx.shape[0] - 1]), :]
            - gy[([0] + list(range(gx.shape[0] - 1))), :]
        )
        f = gxx + gyy

        b = np.zeros(gx.shape)
        b[0, 1:-2] = -gy[0, 1:-2]
        b[-1, 1:-2] = gy[-1, 1:-2]
        b[1:-2, 0] = -gx[1:-2, 0]
        b[1:-2, -1] = gx[1:-2, -1]
        b[0, 0] = (1 / np.sqrt(2)) * (-gy[0, 0] - gx[0, 0])
        b[0, -1] = (1 / np.sqrt(2)) * (-gy[0, -1] + gx[0, -1])
        b[-1, -1] = (1 / np.sqrt(2)) * (gy[-1, -1] + gx[-1, -1])
        b[-1, 0] = (1 / np.sqrt(2)) * (gy[-1, 0] - gx[-1, 0])

        f[0, 1:-2] = f[0, 1:-2] - b[0, 1:-2]
        f[-1, 1:-2] = f[-1, 1:-2] - b[-1, 1:-2]
        f[1:-2, 0] = f[1:-2, 0] - b[1:-2, 0]
        f[1:-2, -1] = f[1:-2, -1] - b[1:-2, -1]

        f[0, -1] = f[0, -1] - np.sqrt(2) * b[0, -1]
        f[-1, -1] = f[-1, -1] - np.sqrt(2) * b[-1, -1]
        f[-1, 0] = f[-1, 0] - np.sqrt(2) * b[-1, 0]
        f[0, 0] = f[0, 0] - np.sqrt(2) * b[0, 0]

        tt = fftpack.dct(f, norm="ortho")
        fcos = fftpack.dct(tt.T, norm="ortho").T

        (x, y) = np.meshgrid(range(1, f.shape[1] + 1), range(1, f.shape[0] + 1), copy=True)
        denom = 4 * (
            (np.sin(0.5 * math.pi * x / (f.shape[1]))) ** 2
            + (np.sin(0.5 * math.pi * y / (f.shape[0]))) ** 2
        ).astype(np.float32)

        f = -fcos / denom
        tt = fftpack.idct(f, norm="ortho")
        img_tt = fftpack.idct(tt.T, norm="ortho").T
        img_tt = img_tt.mean() + img_tt

        return img_tt


    '''
    Camera Class
    '''
    pts_src = np.float32([
        [172. , 3.],
        [442. , 3.],
        [429. ,413.],
        [185. ,413.]
    ])

    width, height = 270, 410
    pts_dst = np.float32([
        [0, 0],
        [width - 1, 0],
        [width - 1, height - 1],
        [0, height - 1]
    ])

    M = cv2.getPerspectiveTransform(pts_src, pts_dst)


    class Camera:

        def __init__(self, ID, imgh=480, imgw=640):
            """
            Initialize the camera.
            """
            self.dev_type = ID
            self.dev_id = get_camera_id(self.dev_type)
            self.imgh = imgh
            self.imgw = imgw
            self.cam = None
            self.data = None
            self.camera_matrix, self.dist_coeffs, self.new_camera_matrix ,self.roi = self.load_camera_params()
            self.background_frame = None

        def Undistortion(self, frame, camera_matrix, dist_coeffs, new_camera_matrix, roi=None):
            undistorted = cv2.undistort(frame, camera_matrix, dist_coeffs, None, new_camera_matrix)
            if roi is not None:
                x, y, w, h = roi
                if w > 0 and h > 0:
                    undistorted = undistorted[y:y+h, x:x+w]
            return undistorted
        
        def load_camera_params(self):
            camera_matrix = np.array([
                [471.27097, 0.0, 301.10844],
                [0.0, 471.63526, 199.18465],
                [0.0, 0.0, 1.0]
            ])
            dist_coeffs = np.array([-0.254406, 0.029868, 0.002644, -0.000091, 0.0])
            image_width = 640
            image_height = 480

            new_camera_matrix, roi = cv2.getOptimalNewCameraMatrix(
                camera_matrix, dist_coeffs, (image_width, image_height), alpha=1, centerPrincipalPoint=True
            )

            return camera_matrix, dist_coeffs, new_camera_matrix, roi
        
        def connect(self):
            self.cam = cv2.VideoCapture(self.dev_id)
            self.cam.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
            self.cam.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            self.cam.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            
            if self.cam is None or not self.cam.isOpened():
                print("Warning: unable to open video source %d" % (self.dev_id))
                return False
            else:
                print("Connect to %s at video source %d" % (self.dev_type, self.dev_id))
                
            num_frames = 10
            frame_sum = None
            frames_captured = 0
            for _ in range(20): 
                self.cam.read()

            for i in range(num_frames):
                ret, f0 = self.cam.read()
                if ret:
                    processed_frame = self._process_frame(f0)
                    
                    if frame_sum is None:
                        frame_sum = processed_frame.astype(np.float64)
                    else:
                        frame_sum += processed_frame.astype(np.float64)
                    frames_captured += 1
                else:
                    print(f"Warning: Failed to read frame {i+1} during background capture.")
            
            if frames_captured > 0:
                self.background_frame = (frame_sum / frames_captured).astype(np.float32)
            else:
                print("ERROR! Failed to capture any frames for background. Background will be None.")
                self.background_frame = None

            return True
        
        def _process_frame(self, frame):

            undistorted_frame = self.Undistortion(frame, self.camera_matrix, self.dist_coeffs, self.new_camera_matrix, self.roi)
            undistorted_frame = cv2.resize(undistorted_frame, (self.imgw, self.imgh))
            undistorted_frame  = cv2.warpPerspective(undistorted_frame, M, (width, height))
            return undistorted_frame


        def get_image(self, flush=False):

            if self.background_frame is None:
                    print("ERROR! Background image is not set. Cannot compute difference.")
                    return None
            
            if flush:
                for i in range(20):
                    ret, f0 = self.cam.read()
            ret, f0 = self.cam.read()
            if ret:

                current_frame = self._process_frame(f0)
                current_frame = current_frame.astype(np.float32)  
                self.background_frame = self.background_frame.astype(np.float32)

                diff_frame = current_frame - self.background_frame
                diff_frame = (diff_frame*2 + 255)  
                diff_frame = diff_frame / 2
                self.data = diff_frame.astype(np.uint8)
            else:
                print("ERROR! reading image from video source %d" % (self.dev_id))
            return self.data
        
        def get_bg(self):
            bg_images = []
            self.get_image(flush=True)
            for _ in range(5):
                bg_images.append(self.get_image(flush=False))
            bg_image = np.mean(bg_images, axis=0).astype(np.uint8)
            return bg_image

        def release(self):

            if self.cam is not None:
                self.cam.release()
                print("Video source %d released." % (self.dev_id))
            else:
                print("No camera to release.")

    def get_camera_id(camera_name, verbose=True):

        min_cam_id = None
        context = pyudev.Context()
        
        for device in context.list_devices(subsystem='video4linux'):
            dev_node = device.device_node
            
            file_name = os.path.basename(dev_node)
            match = re.search(r'\d+$', file_name)
            
            if not match:
                continue
                
            cam_id = int(match.group(0)) 
            
            current_serial = "N/A"
            found = "      "
            
            current_device = device
            while current_device:
                if 'ID_SERIAL_SHORT' in current_device:
                    current_serial = current_device['ID_SERIAL_SHORT']
                    break
                if 'ID_SERIAL' in current_device:
                    current_serial = current_device['ID_SERIAL']
                    break
                
                current_device = current_device.parent 
            
            if camera_name in current_serial:
                found = "FOUND!"
                
                if min_cam_id is None or cam_id < min_cam_id:
                    min_cam_id = cam_id

            
            if verbose:
                print(f"{found} {dev_node} (V4L2 Index: {cam_id}) -> Serial: {current_serial}")

        return min_cam_id


    '''
    depth class
    '''
    config = {
        "ppmm": 0.058,
        "imgh": 410,
        "imgw": 270,
        "raw_imgh": 480,
        "raw_imgw": 640,
        "framerate": 30,
    }


    class Surface:
        def __init__(self, bg, model_path):
            
            self.raw_imgh = config["raw_imgh"]
            self.raw_imgw = config["raw_imgw"]
            self.ppmm = config["ppmm"]
            self.model_path = model_path + "/depth.pth"
            self.recon = Reconstructor(self.model_path, device="cuda")

            print("Collecting bg, please wait ...")
            self.bg_image = bg
            
            self.recon.load_bg(self.bg_image)
        
        def SurfaceDepth(self, input_img):
        
            image = input_img

            G, H, C = self.recon.get_surface_info(image, self.ppmm)

            red = G[:, :, 0] * 255 / 3.0 + 127
            red = np.clip(red, 0, 255)
            blue = G[:, :, 1] * 255 / 3.0 + 127
            blue = np.clip(blue, 0, 255)
            grad_image = np.stack((blue, np.zeros_like(blue), red), axis=-1).astype(np.uint8)

            H_min = -120
            H_max = 0
            gamma = 4
            H_clipped = np.clip(H, H_min, H_max)
            H_norm = (H_clipped - H_min) / (H_max - H_min)
            depth = np.power(H_norm, gamma)

            cmap_mpl = plt.get_cmap("jet_r")
            H_vis = cmap_mpl(depth)[:, :, :3]  
            H_vis = (H_vis * 255).astype(np.uint8)
            depth_visualization = cv2.cvtColor(H_vis, cv2.COLOR_RGB2BGR)


            C = (C.astype(np.uint8)) * 255 

            
            return depth_visualization, H, image #depth,C
        
    class KalmanFilter:
        def __init__(self, process_variance=1e-3, measurement_variance=1e-1):
            self.x = 0.0
            self.P = 1.0
            self.Q = process_variance
            self.R = measurement_variance
            self.initialized = False

        def update(self, measurement):
            if not self.initialized:
                self.x = measurement
                self.initialized = True
                return self.x

            self.P += self.Q
            K = self.P / (self.P + self.R)
            self.x = self.x + K * (measurement - self.x)
            self.P = (1 - K) * self.P
            return self.x

    class DistaceAndTempratureData:
        def __init__(self, SERIAL_PORT = "/dev/ttyACM0"):

            self.FRAME_HEAD = b'\xAA\x55' 
            self.DATA_LEN_FIELD = 0x08
            self.FRAME_LEN = 2 + 1 + 8 + 1 
            self.BAUD_RATE = 115200 
            
            self.kf_dist1 = KalmanFilter(process_variance=1e-1, measurement_variance=3)
            self.kf_dist2 = KalmanFilter(process_variance=1e-1, measurement_variance=3)
            self.start_time = time.time()
            
            try:
                self.ser = serial.Serial(SERIAL_PORT, self.BAUD_RATE, timeout=0.01) 
                print(f"串口打开成功：{SERIAL_PORT}, {self.BAUD_RATE}")
            except Exception as e:
                print(f"串口打开成功：: {e}")
                exit(1)

        def _calculate_checksum(self, data: bytes) -> int:
            total_sum = sum(data)
            checksum = total_sum & 0xFF 
            return checksum

        def read_sensor_frame(self, ser):
            while True:
                byte = ser.read(1) 
                if not byte:
                    return None
                if byte == self.FRAME_HEAD[0:1]:
                    next_byte = ser.read(1)
                    if next_byte == self.FRAME_HEAD[1:2]:
                        break
                    else:
                        continue 

            remaining_data = ser.read(self.FRAME_LEN - len(self.FRAME_HEAD)) 
            
            if len(remaining_data) != (self.FRAME_LEN - len(self.FRAME_HEAD)):
                return None

            data_len_field = remaining_data[0] 
            if data_len_field != self.DATA_LEN_FIELD:
                return None
            
            sensor_data = remaining_data[1:-1] 
            received_checksum = remaining_data[-1]
            
            calculated_checksum = self._calculate_checksum(sensor_data)
            if received_checksum != calculated_checksum:
                return None

            try:
                dist1, dist2, tem_env_raw, tem_obj_raw = struct.unpack(">hhhh", sensor_data)
            except struct.error as e:
                return None

            dist1_filtered = self.kf_dist1.update(dist1)
            dist2_filtered = self.kf_dist2.update(dist2)

            tem_env = tem_env_raw / 10.0
            tem_obj = tem_obj_raw / 10.0

            return dist1_filtered, dist2_filtered, tem_env, tem_obj

        def get_data(self):
            
            self.frame = self.read_sensor_frame(self.ser)
            if self.frame is not None:

                dist1, dist2, tem_env, tem_obj = self.frame
                return dist1, dist2, tem_env, tem_obj

        def close_serial(self):
            if hasattr(self, 'ser') and self.ser.is_open:
                self.ser.close()
                print("串口已关闭。")

        def __del__(self):
            self.close_serial()
