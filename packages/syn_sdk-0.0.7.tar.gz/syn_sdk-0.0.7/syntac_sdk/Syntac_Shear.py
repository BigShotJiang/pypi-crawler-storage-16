if 0:
    import warnings
    warnings.filterwarnings("ignore", message="Failed to load image Python extension")
    warnings.filterwarnings("ignore", message="xFormers is available")
    warnings.filterwarnings("ignore", message="pkg_resources is deprecated")

    import os
    import sys
    import numpy as np
    import torch
    from omegaconf import OmegaConf, DictConfig
    from typing import Optional, Any, Dict, Tuple
    import cv2
    from syntac_sdk.tactile_ssl.downstream_task.forcefield_sl import ForceFieldModule, ForceFieldDecoder
    from syntac_sdk.tactile_ssl.model import vit_base
    from syntac_sdk.tactile_ssl.test import DemoForceField
    from syntac_sdk.Syntac_Depth import Camera

    class ShearForceField:
        def __init__(self, camera: Optional[Camera] = None):
            """
            初始化 Syntac ForceField 演示应用。
            设置随机种子、检测设备、加载配置、初始化摄像头及模型。
            """
            torch.set_float32_matmul_precision("medium")
            self.cfg = self._create_config()
            self._set_seed(self.cfg.seed)
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            print(f"Running on device: {self.device}")
            print("Initializing Camera...")
            self.cam = camera # Camera(ID="USB Camera")
            self.model = self._build_model()
            self.demo_runner = self._build_demo_runner()

        def _set_seed(self, seed: int):
            np.random.seed(seed)
            torch.manual_seed(seed)
            torch.backends.cudnn.benchmark = True

        def _create_config(self) -> DictConfig:
            OUTPUT_CHECKPOINTS_DIR = "syntac_sdk/models/forcefield.pth"
            ENCODER_CHECKPOINT_PATH = "syntac_sdk/models/syntac.ckpt"
            GELSIGHT_DEVICE_ID = 0
            
            ssl_config_hardcoded = OmegaConf.create({
                'img_sz': [224, 224], 
                'pose_estimator': {'num_encoder_layers': 18}, 
                'loss': {
                    'with_mask_supervision': False, 
                    'with_sl_supervision': False, 
                    'with_ssim': True, 
                    'disparity_smoothness': 0.001, 
                    'min_depth': 0.1, 
                    'max_depth': 100.0
                }
            })
            
            optim_cfg_hardcoded = OmegaConf.create({
                '_partial_': True, 
                '_target_': 'torch.optim.Adam', 
                'lr': 0.0001
            })

            cfg = OmegaConf.create({
                "seed": 42,
                "experiment_name": "gelsight_dino_demo",
                "sensor": "gelsight",
                "paths": {
                    "output_dir": OUTPUT_CHECKPOINTS_DIR,
                },
                "data": OmegaConf.create({
                    "train_val_split": None,
                    "train_data_budget": 1.0,
                    "val_data_budget": 1.0,
                    "max_train_data": None,
                    "sensor": "gelsight_mini",
                    "dataset": {
                        "_target_": "tactile_ssl.data.vision_tactile_forcefield.VisionTactileForceFieldDataset",
                        "config": {
                            "sensor": "gelsight_mini",
                            "remove_bg": True,
                            "out_format": "concat_ch_img",
                            "num_frames": 2,
                            "frame_stride": 5,
                            "path_dataset": None,
                            "path_bgs": None,
                            "look_in_folder": False,
                            "transforms": {
                                "with_augmentation": False,
                                "resize": [224, 224],
                                "p_flip": 0.0,
                                "p_crop": 0.0,
                                "p_rot": 0.0,
                            }
                        }
                    },
                    "train_dataloader": {
                        "batch_size": 30, "num_workers": 1, "drop_last": True,
                        "pin_memory": True, "persistent_workers": True, "shuffle": True
                    },
                    "val_dataloader": {
                        "batch_size": 30, "num_workers": 1, "drop_last": True,
                        "pin_memory": True, "persistent_workers": True
                    }
                }),
                "test": {
                    "path_outputs": os.path.join(OUTPUT_CHECKPOINTS_DIR, "demo_results"), 
                    "demo": {
                        "gelsight_device_id": GELSIGHT_DEVICE_ID
                    }
                },
                "task": {
                    "_target_": "tactile_ssl.downstream_task.ForceFieldModule",
                    "model_encoder": OmegaConf.create({"_target_": "tactile_ssl.model.vit_base"}),
                    "model_task": OmegaConf.create({"_target_": "tactile_ssl.downstream_task.ForceFieldDecoder"}),
                    "checkpoint_encoder": ENCODER_CHECKPOINT_PATH, 
                    "checkpoint_task": None, 
                    "train_encoder": False,
                    "encoder_type": "dino",
                    "optim_cfg": optim_cfg_hardcoded,
                    "scheduler_cfg": None,
                },
                "ssl_config": ssl_config_hardcoded
            })
            return cfg

        def _build_model(self) -> ForceFieldModule:

            path_checkpoints = self.cfg.paths.output_dir
            if not os.path.exists(path_checkpoints):
                raise FileNotFoundError(f"Checkpoint path does not exist: {path_checkpoints}")
            
            self.cfg.task.checkpoint_task = f"{path_checkpoints}"

            model_encoder = vit_base(in_chans=6) 
            model_task = ForceFieldDecoder()

            module_kwargs = {
                "model_encoder": model_encoder,
                "model_task": model_task,
                "optim_cfg": self.cfg.task.optim_cfg,
                "scheduler_cfg": self.cfg.task.scheduler_cfg,
                "checkpoint_encoder": self.cfg.task.checkpoint_encoder,
                "checkpoint_task": self.cfg.task.checkpoint_task,
                "train_encoder": self.cfg.task.train_encoder,
                "ssl_config": self.cfg.ssl_config, 
                "encoder_type": self.cfg.task.encoder_type,
            }

            model = ForceFieldModule(**module_kwargs)
            return model

        def _build_demo_runner(self) -> DemoForceField:
            demo_device_id = self.cfg.test.demo.gelsight_device_id
            digit_serial = self.cfg.test.demo.get("digit_serial", None)

            demo_runner = DemoForceField(
                device=self.device, 
                module=self.model,
                digit_serial=digit_serial,           
                gelsight_device_id=demo_device_id,    
                cam=self.cam 
            )

            demo_runner.set_test_params(
                task=self.cfg.experiment_name,
                sensor=self.cfg.sensor,
                ckpt=None,
                dataset_name=None,
                path_outputs=self.cfg.test.path_outputs,
                config=self.cfg,
            )
            
            return demo_runner

        def start(self):
            self.demo_runner.init()

        def get_shear(self) -> Tuple[Any, Any]:
            tactile_img, shear_img, shear_x, shear_y  = self.demo_runner.process_single_frame()
            shear_img_flipped = cv2.flip(shear_img, 0) 
            shear_img_flipped = cv2.flip(shear_img_flipped, 1) 
            return shear_img_flipped , shear_x, shear_y

        def close(self):
            """资源清理"""
            print("Closing resources...")
            if hasattr(self, 'demo_runner'):
                try:
                    self.demo_runner.close()
                except Exception as e:
                    print(f"Error closing demo runner: {e}")

if 1:
    import warnings
    warnings.filterwarnings("ignore", message="Failed to load image Python extension")
    warnings.filterwarnings("ignore", message="xFormers is available")
    warnings.filterwarnings("ignore", message="pkg_resources is deprecated")

    import os
    import sys
    import numpy as np
    import torch
    from omegaconf import OmegaConf, DictConfig
    from typing import Optional, Any, Dict, Tuple
    import cv2

    from syntac_sdk.tactile_ssl.downstream_task.forcefield_sl import ForceFieldModule, ForceFieldDecoder
    from syntac_sdk.tactile_ssl.model import vit_base
    from syntac_sdk.tactile_ssl.test import DemoForceField
    from syntac_sdk.Syntac_Depth import Camera

    class ShearForceField:
        def __init__(self, model_path):
            self.model_path = model_path
            torch.set_float32_matmul_precision("medium")
            self.cfg = self._create_config()
            self._set_seed(self.cfg.seed)
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            print(f"Running on device: {self.device}")
            self.model = self._build_model()
            self.demo_runner = self._build_demo_runner()
           

        def _set_seed(self, seed: int):
            np.random.seed(seed)
            torch.manual_seed(seed)
            torch.backends.cudnn.benchmark = True

        def _create_config(self) -> DictConfig:
            OUTPUT_CHECKPOINTS_DIR = self.model_path + "/forcefield.pth"
            ENCODER_CHECKPOINT_PATH = self.model_path + "/syntac.ckpt"
            GELSIGHT_DEVICE_ID = 0
            
            ssl_config_hardcoded = OmegaConf.create({
                'img_sz': [224, 224], 
                'pose_estimator': {'num_encoder_layers': 18}, 
                'loss': {
                    'with_mask_supervision': False, 
                    'with_sl_supervision': False, 
                    'with_ssim': True, 
                    'disparity_smoothness': 0.001, 
                    'min_depth': 0.1, 
                    'max_depth': 100.0
                }
            })
            
            optim_cfg_hardcoded = OmegaConf.create({
                '_partial_': True, 
                '_target_': 'torch.optim.Adam', 
                'lr': 0.0001
            })

            cfg = OmegaConf.create({
                "seed": 42,
                "experiment_name": "gelsight_dino_demo",
                "sensor": "gelsight",
                "paths": {
                    "output_dir": OUTPUT_CHECKPOINTS_DIR,
                },
                "data": OmegaConf.create({
                    "train_val_split": None,
                    "train_data_budget": 1.0,
                    "val_data_budget": 1.0,
                    "max_train_data": None,
                    "sensor": "gelsight_mini",
                    "dataset": {
                        "_target_": "tactile_ssl.data.vision_tactile_forcefield.VisionTactileForceFieldDataset",
                        "config": {
                            "sensor": "gelsight_mini",
                            "remove_bg": True,
                            "out_format": "concat_ch_img",
                            "num_frames": 2,
                            "frame_stride": 5,
                            "path_dataset": None,
                            "path_bgs": None,
                            "look_in_folder": False,
                            "transforms": {
                                "with_augmentation": False,
                                "resize": [224, 224],
                                "p_flip": 0.0,
                                "p_crop": 0.0,
                                "p_rot": 0.0,
                            }
                        }
                    },
                    "train_dataloader": {
                        "batch_size": 30, "num_workers": 1, "drop_last": True,
                        "pin_memory": True, "persistent_workers": True, "shuffle": True
                    },
                    "val_dataloader": {
                        "batch_size": 30, "num_workers": 1, "drop_last": True,
                        "pin_memory": True, "persistent_workers": True
                    }
                }),
                "test": {
                    "path_outputs": os.path.join(OUTPUT_CHECKPOINTS_DIR, "demo_results"), 
                    "demo": {
                        "gelsight_device_id": GELSIGHT_DEVICE_ID
                    }
                },
                "task": {
                    "_target_": "tactile_ssl.downstream_task.ForceFieldModule",
                    "model_encoder": OmegaConf.create({"_target_": "tactile_ssl.model.vit_base"}),
                    "model_task": OmegaConf.create({"_target_": "tactile_ssl.downstream_task.ForceFieldDecoder"}),
                    "checkpoint_encoder": ENCODER_CHECKPOINT_PATH, 
                    "checkpoint_task": None, 
                    "train_encoder": False,
                    "encoder_type": "dino",
                    "optim_cfg": optim_cfg_hardcoded,
                    "scheduler_cfg": None,
                },
                "ssl_config": ssl_config_hardcoded
            })
            return cfg

        def _build_model(self) -> ForceFieldModule:
            path_checkpoints = self.cfg.paths.output_dir
            if not os.path.exists(path_checkpoints):
                raise FileNotFoundError(f"Checkpoint path does not exist: {path_checkpoints}")
            
            self.cfg.task.checkpoint_task = f"{path_checkpoints}"
            model_encoder = vit_base(in_chans=6) 
            model_task = ForceFieldDecoder()

            module_kwargs = {
                "model_encoder": model_encoder,
                "model_task": model_task,
                "optim_cfg": self.cfg.task.optim_cfg,
                "scheduler_cfg": self.cfg.task.scheduler_cfg,
                "checkpoint_encoder": self.cfg.task.checkpoint_encoder,
                "checkpoint_task": self.cfg.task.checkpoint_task,
                "train_encoder": self.cfg.task.train_encoder,
                "ssl_config": self.cfg.ssl_config, 
                "encoder_type": self.cfg.task.encoder_type,
            }

            model = ForceFieldModule(**module_kwargs)
            return model

        def _build_demo_runner(self) -> DemoForceField:

            demo_runner = DemoForceField(
                device=self.device, 
                module=self.model,
            )

            demo_runner.set_test_params(
                task=self.cfg.experiment_name,
                sensor=self.cfg.sensor,
                ckpt=None,
                dataset_name=None,
                path_outputs=self.cfg.test.path_outputs,
                config=self.cfg,
            )
            
            return demo_runner

        def start(self, bg):
            self.demo_runner.init(bg)

        def get_shear(self, camera_img):
            tactile_img, shear_img, shear_x, shear_y  = self.demo_runner.process_single_frame(camera_img)
            shear_img_flipped = cv2.flip(shear_img, 0)  
            shear_img_flipped = cv2.flip(shear_img_flipped, 1)  
            return shear_img_flipped , shear_x, shear_y

        def close(self):
            print("Closing resources...")
            if hasattr(self, 'demo_runner'):
                try:
                    self.demo_runner.close()
                except Exception as e:
                    print(f"Error closing demo runner: {e}")