if 0:
    import io
    import os
    import time
    import cv2
    import numpy as np
    import matplotlib.pyplot as plt
    import sys
    import torch
    import torch.nn.functional as F
    from collections import deque
    from PIL import Image
    from typing import Optional


    sys.path.append(".")
    from syntac_sdk.tactile_ssl import algorithm
    from .test_task import TestTaskSL
    from syntac_sdk.tactile_ssl.data.vision_based_interactive import DemoForceFieldData
    from syntac_sdk.tactile_ssl.data.digit.utils import compute_diff
    from syntac_sdk.Syntac_Depth import Camera

    class DemoForceField(TestTaskSL):
        def __init__(
            self,
            digit_serial: Optional[str],
            gelsight_device_id: Optional[int],
            device,
            module: algorithm.Module,
            cam: Camera = None,
        ):
            super().__init__(
                device=device,
                module=module,
            )
            self.digit_serial = digit_serial
            self.gelsight_device_id = gelsight_device_id
            self.cam = cam

            self.plot_initialized = False 
            self.fig = None
            self.ax = None
            self.ax_shear = None

        def init(self):
            self.sensor = self.config.sensor
            self.th_no_contact = 0.03

            self.sensor_handler = DemoForceFieldData(
                config=self.config.data.dataset.config,
                digit_serial=self.digit_serial,
                gelsight_device_id=self.gelsight_device_id,
                cam=self.cam,
            )
            self.img_buffer = deque(maxlen=5)
            self._set_bg_template()

            for _ in range(5):
                sample = self.sensor_handler.get_model_inputs()

                img_fg = sample["image"][0:3].permute(1, 2, 0).cpu().numpy()
                img_fg = cv2.GaussianBlur(img_fg, (5, 5), 0)
                self.img_buffer.append(img_fg)
                time.sleep(0.05)


        def process_single_frame(self,camera_img):

            border, ratio, clip = 15, 1.0, 50


            sample = self.sensor_handler.get_model_inputs()
            current_tactile_image = sample["current_image_color"]
            
            outputs_forces = {'normal': None, 'shear': None}

            x_bg = sample["image_bg"].unsqueeze(0).to(self.device)
            outputs_normal = self.module(x_bg, mode="normal")
            outputs_forces['normal'] = outputs_normal['normal']

            x_fg = sample["image"].unsqueeze(0).to(self.device)
            
            img_fg_np = sample["image"][0:3].permute(1, 2, 0).cpu().numpy()
            img_fg_np = cv2.GaussianBlur(img_fg_np, (5, 5), 0)
            self.img_buffer.append(img_fg_np)

            outputs_shear = self.module(x_fg, mode="shear")
            outputs_forces['shear'] = outputs_shear['shear']

            normal_unmask = outputs_forces["normal"]
            normal_unmask = self._normalize_image(normal_unmask)

            if normal_unmask.mean() > 0.4:
                normal_unmask = 1.0 - normal_unmask

            mask = self._normal2mask(
                normal_unmask, self.bg_template, border, ratio, clip
            )

            avg_img = np.mean(np.array(self.img_buffer), axis=0)
            if avg_img.std() <= self.th_no_contact:
                mask = torch.zeros_like(mask)

            normal = (normal_unmask * mask).cpu().numpy().squeeze()

            dilate = cv2.dilate(normal, np.ones((5, 5), np.uint8), iterations=3)
            normal = cv2.erode(dilate, np.ones((5, 5), np.uint8), iterations=2)
            normal = cv2.GaussianBlur(normal, (15, 15), 0)

            shear = (
                outputs_forces["shear"]
                .cpu()
                .detach()
                .squeeze()
                .permute(1, 2, 0)
                .numpy()
            )
            shear_x = shear[:, :, 0]
            shear_y = shear[:, :, 1]

            if not self.plot_initialized:
                self._init_shear(shear, normal)
                self.plot_initialized = True
            
            im_shear = self.update_shear(shear, normal)

            img_size_tactile = (270, 410)
            current_tactile_image = cv2.cvtColor(current_tactile_image, cv2.COLOR_BGR2RGB)
            current_tactile_image = (cv2.resize(current_tactile_image, img_size_tactile)).astype(np.uint8)
            
            img_size_shear = (270, 410)
            im_shear_resized = cv2.resize(im_shear[:,:,0:3], img_size_shear)
            im_shear_bgr = cv2.cvtColor(im_shear_resized, cv2.COLOR_RGB2BGR)
            return current_tactile_image, im_shear_bgr , shear_x, shear_y

        def _normalize_image(self, x):
            ma = float(x.max().cpu().data)
            mi = float(x.min().cpu().data)
            d = ma - mi if ma != mi else 1e5
            return torch.clip((x - mi) / d, 0.0, 1.0)
        
        def _normal2mask(self, heightmap, bg_template, b, r, clip):
            heightmap = heightmap.squeeze()
            heightmap = heightmap[b:-b, b:-b]

            heightmap = heightmap * 255
            bg_template = bg_template * 255

            diff_heights = heightmap
            diff_heights[diff_heights < clip] = 0
            threshold = torch.quantile(diff_heights, 0.9) * r
            threshold = torch.clip(threshold, 0, 240)
            contact_mask = diff_heights > threshold

            padded_contact_mask = torch.zeros_like(bg_template, dtype=bool)
            padded_contact_mask[b:-b, b:-b] = contact_mask

            return padded_contact_mask
        
        def _set_bg_template(self):
            bg = self.sensor_handler.bg
            bg = compute_diff(bg, bg)
            bg = Image.fromarray(bg)
            bg = self.sensor_handler.transform_resize(bg).unsqueeze(0).to(self.device)
            bg = torch.cat([bg, bg], dim=1)
            outputs_forces = self.module(bg)
            self.bg_template = self._normalize_image(outputs_forces["normal"]).squeeze()
        
        def _init_shear(self, shear, normal, margin=0, spacing=12):
            self.fig, self.ax = plt.subplots()
            self.fig.patch.set_facecolor("black")
            h, w, *_ = shear.shape

            nx = int((w - 2 * margin) / spacing)
            ny = int((h - 2 * margin) / spacing)

            x = np.linspace(margin, w - margin - 1, nx, dtype=np.int64)
            y = np.linspace(margin, h - margin - 1, ny, dtype=np.int64)

            shear = shear[np.ix_(y, x)]
            u = shear[:, :, 0]
            v = shear[:, :, 1]
            m = normal[np.ix_(y, x)]

            rad_max = 20.0
            epsilon = 1e-5
            u = u / (rad_max + epsilon)
            v = v / (rad_max + epsilon)

            u = np.clip(u, -1.0, 1.0)
            v = np.clip(v, -1.0, 1.0)
            uu = u.copy()
            vv = v.copy()
            r = np.sqrt(u**2 + v**2)
            idx_clip = np.where(r < 0.01)
            uu[idx_clip] = 0.0
            vv[idx_clip] = 0.0

            uu = uu / (np.abs(uu).max() + epsilon)
            vv = vv / (np.abs(vv).max() + epsilon)

            kwargs = {
                **dict(
                    angles="uv",
                    scale_units="dots",
                    scale=0.025,
                    width=0.007,
                    cmap="inferno",
                    edgecolor="face",
                ),
            }
            self.ax_shear = self.ax.quiver(y, x, uu, -vv, m, **kwargs)
            self.ax.set_ylim(sorted(self.ax.get_ylim(), reverse=True))
            self.ax.set_facecolor("black")
            self.ax.set_xticks([])
            self.ax.set_yticks([])

            self.ax.spines["top"].set_visible(False)
            self.ax.spines["right"].set_visible(False)
            self.ax.spines["bottom"].set_visible(False)
            self.ax.spines["left"].set_visible(False)

        
        def update_shear(self, shear, normal, margin=0, spacing=12):
            if self.ax_shear is None:
                return np.zeros((224, 224, 3), dtype=np.uint8)

            h, w, *_ = shear.shape
            nx = int((w - 2 * margin) / spacing)
            ny = int((h - 2 * margin) / spacing)

            x = np.linspace(margin, w - margin - 1, nx, dtype=np.int64)
            y = np.linspace(margin, h - margin - 1, ny, dtype=np.int64)

            shear = shear[np.ix_(y, x)]
            u = shear[:, :, 0]
            v = shear[:, :, 1]
            m = normal[np.ix_(y, x)]

            rad_max = 20.0
            epsilon = 1e-5
            u = u / (rad_max + epsilon)
            v = v / (rad_max + epsilon)

            u = np.clip(u, -1.0, 1.0)
            v = np.clip(v, -1.0, 1.0)
            uu = u.copy()
            vv = v.copy()
            r = np.sqrt(u**2 + v**2)
            idx_clip = np.where(r < 0.01)
            uu[idx_clip] = 0.0
            vv[idx_clip] = 0.0

            uu = uu / (np.abs(uu).max() + epsilon)
            vv = vv / (np.abs(vv).max() + epsilon)

            self.ax_shear.set_UVC(uu, -vv, m)
            self.ax_shear.set_clim(0.0, 1.0)

            self.fig.canvas.draw()

            with io.BytesIO() as buff:
                self.fig.savefig(
                    buff, format="png", bbox_inches="tight", pad_inches=0, transparent=False, dpi=150
                )
                buff.seek(0)
                img = Image.open(io.BytesIO(buff.read()))
            return np.array(img)
        
        def close(self):
            if self.fig:
                plt.close(self.fig)

if 1:
    import io
    import os
    import time
    import cv2
    import numpy as np
    import matplotlib.pyplot as plt
    import sys
    import torch
    import torch.nn.functional as F
    from collections import deque
    from PIL import Image
    from typing import Optional

    sys.path.append(".")
    from syntac_sdk.tactile_ssl import algorithm
    from .test_task import TestTaskSL
    from syntac_sdk.tactile_ssl.data.vision_based_interactive import DemoForceFieldData
    from syntac_sdk.tactile_ssl.data.digit.utils import compute_diff
    from syntac_sdk.Syntac_Depth import Camera

    class DemoForceField(TestTaskSL):
        def __init__(
            self,
            device,
            module: algorithm.Module,
        ):
            super().__init__(
                device=device,
                module=module,
            )

            self.plot_initialized = False 
            self.fig = None
            self.ax = None
            self.ax_shear = None

        def init(self, input_bg):
            self.sensor = self.config.sensor
            self.th_no_contact = 0.03
            input_bg = cv2.resize(input_bg, (320, 240))
            self.sensor_handler = DemoForceFieldData(
                config=self.config.data.dataset.config,
                bg = input_bg
            )
            self.img_buffer = deque(maxlen=5)
            self._set_bg_template(input_bg)

            for _ in range(5):
                input_bg224 = cv2.resize(input_bg, (224, 224))
                input_tensor = torch.from_numpy(input_bg224).float()
                img_fg = input_tensor.permute(0, 1, 2).cpu().numpy()
                img_fg = cv2.GaussianBlur(img_fg, (5, 5), 0)
                self.img_buffer.append(img_fg)
                time.sleep(0.05)
            

        def process_single_frame(self, camera_img):

            border, ratio, clip = 15, 1.0, 50

            sample = self.sensor_handler.get_model_inputs(camera_img)
            current_tactile_image = sample["current_image_color"]
            
            outputs_forces = {'normal': None, 'shear': None}

            x_bg = sample["image_bg"].unsqueeze(0).to(self.device)
            outputs_normal = self.module(x_bg, mode="normal")
            outputs_forces['normal'] = outputs_normal['normal']

            x_fg = sample["image"].unsqueeze(0).to(self.device)
            
            img_fg_np = sample["image"][0:3].permute(1, 2, 0).cpu().numpy()
            img_fg_np = cv2.GaussianBlur(img_fg_np, (5, 5), 0)
            self.img_buffer.append(img_fg_np)

            outputs_shear = self.module(x_fg, mode="shear")
            outputs_forces['shear'] = outputs_shear['shear']

            normal_unmask = outputs_forces["normal"]
            normal_unmask = self._normalize_image(normal_unmask)

            if normal_unmask.mean() > 0.4:
                normal_unmask = 1.0 - normal_unmask

            mask = self._normal2mask(
                normal_unmask, self.bg_template, border, ratio, clip
            )

            avg_img = np.mean(np.array(self.img_buffer), axis=0)
            if avg_img.std() <= self.th_no_contact:
                mask = torch.zeros_like(mask)

            normal = (normal_unmask * mask).cpu().numpy().squeeze()

            dilate = cv2.dilate(normal, np.ones((5, 5), np.uint8), iterations=3)
            normal = cv2.erode(dilate, np.ones((5, 5), np.uint8), iterations=2)
            normal = cv2.GaussianBlur(normal, (15, 15), 0)

            shear = (
                outputs_forces["shear"]
                .cpu()
                .detach()
                .squeeze()
                .permute(1, 2, 0)
                .numpy()
            )
            shear_x = shear[:, :, 0]
            shear_y = shear[:, :, 1]

            if not self.plot_initialized:
                self._init_shear(shear, normal)
                self.plot_initialized = True
            
            im_shear = self.update_shear(shear, normal)
            
            img_size_tactile = (270, 410)
            current_tactile_image = cv2.cvtColor(current_tactile_image, cv2.COLOR_BGR2RGB)
            current_tactile_image = (cv2.resize(current_tactile_image, img_size_tactile)).astype(np.uint8)

            img_size_shear = (270, 410)
            im_shear_resized = cv2.resize(im_shear[:,:,0:3], img_size_shear)
            im_shear_bgr = cv2.cvtColor(im_shear_resized, cv2.COLOR_RGB2BGR)
            return current_tactile_image, im_shear_bgr , shear_x, shear_y

        def _normalize_image(self, x):
            ma = float(x.max().cpu().data)
            mi = float(x.min().cpu().data)
            d = ma - mi if ma != mi else 1e5
            return torch.clip((x - mi) / d, 0.0, 1.0)
        
        def _normal2mask(self, heightmap, bg_template, b, r, clip):
            heightmap = heightmap.squeeze()
            heightmap = heightmap[b:-b, b:-b]

            heightmap = heightmap * 255
            bg_template = bg_template * 255

            diff_heights = heightmap
            diff_heights[diff_heights < clip] = 0
            threshold = torch.quantile(diff_heights, 0.9) * r
            threshold = torch.clip(threshold, 0, 240)
            contact_mask = diff_heights > threshold

            padded_contact_mask = torch.zeros_like(bg_template, dtype=bool)
            padded_contact_mask[b:-b, b:-b] = contact_mask

            return padded_contact_mask
        
        def _set_bg_template(self, input_bg):
            bg = input_bg
            bg = compute_diff(bg, bg)
            bg = Image.fromarray(bg)
            bg = self.sensor_handler.transform_resize(bg).unsqueeze(0).to(self.device)
            bg = torch.cat([bg, bg], dim=1)
            outputs_forces = self.module(bg)
            self.bg_template = self._normalize_image(outputs_forces["normal"]).squeeze()
        
        def _init_shear(self, shear, normal, margin=0, spacing=12):
            self.fig, self.ax = plt.subplots()
            self.fig.patch.set_facecolor("black")
            h, w, *_ = shear.shape

            nx = int((w - 2 * margin) / spacing)
            ny = int((h - 2 * margin) / spacing)

            x = np.linspace(margin, w - margin - 1, nx, dtype=np.int64)
            y = np.linspace(margin, h - margin - 1, ny, dtype=np.int64)

            shear = shear[np.ix_(y, x)]
            u = shear[:, :, 0]
            v = shear[:, :, 1]
            m = normal[np.ix_(y, x)]

            rad_max = 20.0
            epsilon = 1e-5
            u = u / (rad_max + epsilon)
            v = v / (rad_max + epsilon)

            u = np.clip(u, -1.0, 1.0)
            v = np.clip(v, -1.0, 1.0)
            uu = u.copy()
            vv = v.copy()
            r = np.sqrt(u**2 + v**2)
            idx_clip = np.where(r < 0.01)
            uu[idx_clip] = 0.0
            vv[idx_clip] = 0.0

            uu = uu / (np.abs(uu).max() + epsilon)
            vv = vv / (np.abs(vv).max() + epsilon)

            kwargs = {
                **dict(
                    angles="uv",
                    scale_units="dots",
                    scale=0.025,
                    width=0.007,
                    cmap="inferno",
                    edgecolor="face",
                ),
            }
            self.ax_shear = self.ax.quiver(y, x, uu, -vv, m, **kwargs)
            self.ax.set_ylim(sorted(self.ax.get_ylim(), reverse=True))
            self.ax.set_facecolor("black")
            self.ax.set_xticks([])
            self.ax.set_yticks([])

            self.ax.spines["top"].set_visible(False)
            self.ax.spines["right"].set_visible(False)
            self.ax.spines["bottom"].set_visible(False)
            self.ax.spines["left"].set_visible(False)

        
        def update_shear(self, shear, normal, margin=0, spacing=12):
            if self.ax_shear is None:
                return np.zeros((224, 224, 3), dtype=np.uint8)

            h, w, *_ = shear.shape
            nx = int((w - 2 * margin) / spacing)
            ny = int((h - 2 * margin) / spacing)

            x = np.linspace(margin, w - margin - 1, nx, dtype=np.int64)
            y = np.linspace(margin, h - margin - 1, ny, dtype=np.int64)

            shear = shear[np.ix_(y, x)]
            u = shear[:, :, 0]
            v = shear[:, :, 1]
            m = normal[np.ix_(y, x)]

            rad_max = 20.0
            epsilon = 1e-5
            u = u / (rad_max + epsilon)
            v = v / (rad_max + epsilon)

            u = np.clip(u, -1.0, 1.0)
            v = np.clip(v, -1.0, 1.0)
            uu = u.copy()
            vv = v.copy()
            r = np.sqrt(u**2 + v**2)
            idx_clip = np.where(r < 0.01)
            uu[idx_clip] = 0.0
            vv[idx_clip] = 0.0

            uu = uu / (np.abs(uu).max() + epsilon)
            vv = vv / (np.abs(vv).max() + epsilon)

            self.ax_shear.set_UVC(uu, -vv, m)
            self.ax_shear.set_clim(0.0, 1.0)

            self.fig.canvas.draw()

            with io.BytesIO() as buff:
                self.fig.savefig(
                    buff, format="png", bbox_inches="tight", pad_inches=0, transparent=False, dpi=150
                )
                buff.seek(0)
                img = Image.open(io.BytesIO(buff.read()))
            return np.array(img)
        
        def close(self):
            if self.fig:
                plt.close(self.fig)