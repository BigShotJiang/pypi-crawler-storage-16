# Pyarmor 8.5.12 (trial), 000000, 2025-12-11T16:39:04.367176
from .pyarmor_runtime import __pyarmor__
