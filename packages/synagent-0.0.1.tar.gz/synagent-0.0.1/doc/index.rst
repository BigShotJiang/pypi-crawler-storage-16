Welcome to template documentation!
=================================
This is documentation for template version |version| (release |release|).

.. toctree::
   :caption: Contents
   :maxdepth: 1

   Getting Started <getting_started>
   Tutorials and Examples <tutorial>
   API Reference <api>
   References <reference>
