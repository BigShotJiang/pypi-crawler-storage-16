SynAgent
========

SynAgent is a proof-of-concept agent that orchestrates multiple Syn™ ecosystem
packages: **SynKit**, **SynRBL**, **SynTemp**, **SynCat**, **SynRFP**, and
**SynRXN**.  It wraps each package into a standard tool interface and
provides a simple agent core that sequences these tools for end-to-end
reaction informatics workflows.

Features
--------

- **SynRBL**: Rule- and MCS-based reaction rebalancing【474936165384266†L16-L20】.
- **SynKit**: Reaction canonicalization and mechanistic transition graphs【709868904968378†L73-L111】.
- **SynTemp**: High-accuracy reaction template extraction with consensus atom mapping【300636505376941†L21-L33】.
- **SynCat**: Graph-based reaction classification via cross-attention models【380996113532396†L88-L111】.
- **SynRFP**: Mapping-free, permutation-invariant reaction fingerprints【181653318257788†L46-L56】.
- **SynRXN**: Reproducible reaction datasets and splits【159188765579154†L100-L111】.

Structure
---------

- ``synagent/``: Core package providing the agent (``agent.py``), registry
  (``registry.py``) and tool wrappers.
  - ``tools/``: Implementations of each tool wrapper and a base protocol.
- ``README.md``: This document describing the package.

Usage
-----

1. **Register tools**: Instantiate a :class:`~synagent.registry.ToolRegistry`
   and register imported tool instances from :mod:`synagent.tools`.
2. **Create an agent**: Instantiate :class:`~synagent.agent.AgentCore`
   with the registry.
3. **Build a plan**: Create a list of
   :class:`~synagent.agent.PlanStep` objects specifying tool names and
   their parameters.
4. **Run the plan**: Call ``agent.run(plan)`` to execute tool calls
   sequentially.

Example
~~~~~~~

```python
from synagent import ToolRegistry, AgentCore, PlanStep
from synagent.tools import synrbl_balance, synkit_canonicalize

# 1. Register tools
registry = ToolRegistry()
registry.register(synrbl_balance)
registry.register(synkit_canonicalize)

# 2. Initialize agent
agent = AgentCore(registry)

# 3. Build plan
plan = [
    PlanStep("synrbl.balance", {"reaction": "CC=O>>CC(=O)O"}),
    PlanStep("synkit.canonicalize", {"reaction": "CC=O>>CC(=O)O", "with_mt_graph": False}),
]

# 4. Run
result = agent.run(plan)
print(result)
```

Notes
-----

- The actual Syn™ packages must be installed in your environment for the
  wrappers to work.
- Each tool uses lazy imports to avoid unnecessary dependencies until
  invoked.
- Error handling is basic; real-world agents should implement more
  robust failure recovery and logging.

License
-------

This repository is released under the Apache 2.0 License, consistent
with the licensing of the underlying Syn packages.