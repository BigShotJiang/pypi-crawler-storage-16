"""SynAgent Package

This package provides an agent framework to orchestrate SynKit, SynRBL,
SynTemp, SynCat, SynRFP, and SynRXN modules. It defines a registry,
core agent classes, routing logic, and wrappers for each Syn library.

The agent components are structured so that each Syn library is exposed
as a `SynTool` with a name, description, input schema, and `run` method.
The agent uses a simple rule-based planner to sequence tool invocations.
"""

from .registry import ToolRegistry  # noqa: F401
from .agent import AgentCore, PlanStep  # noqa: F401
