"""Core agent implementation for SynAgent.

This module defines the :class:`AgentCore` class, which coordinates the
execution of SynAgent tools according to a user-defined plan. A plan is
represented by a sequence of :class:`PlanStep` instances specifying which
tool to invoke, the arguments to supply, and whether to halt execution if
that step fails.
"""

from dataclasses import dataclass
from typing import Any, Dict, List

from .registry import ToolRegistry
from .tools.base import SynTool


@dataclass
class PlanStep:
    """Represents a single step in an execution plan.

    Attributes
    ----------
    tool_name: str
        The name of the tool to execute.
    kwargs: Dict[str, Any]
        A dictionary of keyword arguments to pass to the tool's ``run`` method.
    fail_fast: bool, optional
        Whether to stop executing subsequent steps if this step fails. Defaults
        to ``True``.
    """

    tool_name: str
    kwargs: Dict[str, Any]
    fail_fast: bool = True


class AgentCore:
    """Execute a sequence of tools as defined by a plan.

    The agent uses a :class:`ToolRegistry` to look up tools by name. It
    iterates through the provided plan, invoking each tool with the given
    arguments. Results from each step are collected into a list. If a tool
    indicates failure (``ok`` is ``False``) and the corresponding plan step
    has ``fail_fast`` set to ``True``, execution stops immediately.
    """

    def __init__(self, registry: ToolRegistry) -> None:
        self.registry = registry

    def run(self, plan: List[PlanStep]) -> Dict[str, Any]:
        """Execute a sequence of plan steps using registered tools.

        Parameters
        ----------
        plan: List[PlanStep]
            The ordered list of tool invocations to perform.

        Returns
        -------
        Dict[str, Any]
            A dictionary containing a list of results for each step under
            the key ``results``. Each entry includes the tool name, the
            success flag, a summary message, and the data returned by the tool.
        """
        results = []
        for step in plan:
            tool: SynTool = self.registry.get(step.tool_name)
            res = tool.run(**step.kwargs)
            results.append(
                {
                    "tool": step.tool_name,
                    "ok": res.ok,
                    "summary": res.summary,
                    "data": res.data,
                }
            )
            if not res.ok and step.fail_fast:
                break
        return {"results": results}
