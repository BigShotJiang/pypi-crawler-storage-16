"""Tool registry for SynAgent.

The registry maps tool names to callable tool classes. Each tool must implement
a name, description, input_schema, and run() method. The registry can be
extended with additional tools as needed.
"""

from typing import Dict

from .tools.base import SynTool


class ToolRegistry:
    """Registry of tools used by the SynAgent.

    This class provides methods to register tools, retrieve tools by name,
    and list available tools. Each tool is expected to implement the
    ``SynTool`` protocol defined in ``synagent.tools.base``.
    """

    def __init__(self) -> None:
        # Internal dictionary mapping tool names to tool instances
        self._registry: Dict[str, SynTool] = {}

    def register(self, tool: SynTool) -> None:
        """Register a tool with the registry.

        Parameters
        ----------
        tool: SynTool
            The tool instance to register. Its ``name`` attribute is used
            as the key in the internal registry dictionary.
        """
        self._registry[tool.name] = tool

    def get(self, name: str) -> SynTool:
        """Retrieve a tool by name.

        Parameters
        ----------
        name: str
            The name of the tool to retrieve.

        Returns
        -------
        SynTool
            The registered tool instance associated with ``name``.

        Raises
        ------
        KeyError
            If the tool name is not present in the registry.
        """
        return self._registry[name]

    def list_tools(self) -> Dict[str, SynTool]:
        """Return a list of registered tool names.

        Returns
        -------
        List[str]
            A list of tool names currently registered in the registry.
        """
        return list(self._registry.keys())
