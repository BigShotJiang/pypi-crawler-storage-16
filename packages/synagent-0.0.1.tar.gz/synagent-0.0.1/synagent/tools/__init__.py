"""Expose individual tool instances for SynAgent.

This module imports each tool wrapper and re-exports a public instance
under a human-friendly name. Users can register these tool instances with
a :class:`~synagent.registry.ToolRegistry` to make them available to the
agent.
"""

from .synrbl import Tool as synrbl_balance  # type: ignore
from .synkit import Tool as synkit_canonicalize  # type: ignore
from .syntemp import Tool as syntemp_extract  # type: ignore
from .syncat import Tool as syncat_classify  # type: ignore
from .synrfp import Tool as synrfp_fingerprint  # type: ignore
from .synrxn import Tool as synrxn_load_dataset  # type: ignore

__all__ = [
    "synrbl_balance",
    "synkit_canonicalize",
    "syntemp_extract",
    "syncat_classify",
    "synrfp_fingerprint",
    "synrxn_load_dataset",
]
