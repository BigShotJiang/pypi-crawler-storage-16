"""Definitions for tool protocols and result types.

Tools used by the SynAgent must adhere to a common interface to enable
composition into workflows. The :class:`ToolResult` dataclass captures
the outcome of running a tool, while the :class:`SynTool` protocol
specifies the required attributes and method a tool must implement.
"""

from dataclasses import dataclass
from typing import Any, Dict, Protocol


@dataclass
class ToolResult:
    """Outcome of running a SynAgent tool.

    Attributes
    ----------
    ok: bool
        Indicates whether the tool ran successfully.
    data: Dict[str, Any]
        Arbitrary structured data returned by the tool.
    summary: str
        A human-readable summary of what the tool did or what went wrong.
    """

    ok: bool
    data: Dict[str, Any]
    summary: str


class SynTool(Protocol):
    """Protocol specifying the interface for SynAgent tools.

    Tools must define:

    - ``name``: a unique identifier used when constructing plans.
    - ``description``: a human-readable description of what the tool does.
    - ``input_schema``: a JSON-like schema describing expected arguments.
    - ``run``: a method accepting keyword arguments and returning a
      :class:`ToolResult` instance.
    """

    # Name used to reference this tool in a plan
    name: str

    # Short description of the tool's purpose
    description: str

    # Input argument schema (JSON-schema compatible)
    input_schema: Dict[str, Any]

    def run(self, **kwargs: Any) -> ToolResult:
        """Execute the tool with the given arguments.

        Parameters
        ----------
        **kwargs: Any
            Arguments defined by the ``input_schema``.

        Returns
        -------
        ToolResult
            The result of executing the tool.
        """
        ...
