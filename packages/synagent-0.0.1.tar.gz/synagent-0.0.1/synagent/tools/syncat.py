"""Wrapper for SynCat reaction classification.

This module provides a tool to classify reactions into named categories
using a pretrained SynCat model. It leverages cross-attention to handle
reagents and ensure permutation invariance.
"""

from .base import ToolResult, SynTool


class SynCatClassifyTool:
    """Classify reactions using the SynCat model."""

    name = "syncat.classify"
    description = (
        "Classify a reaction into its named class using SynCat. "
        "Leverages cross-attention to handle reagents and ensure permutation invariance."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "reaction": {"type": "string"},
        },
        "required": ["reaction"],
    }

    def __init__(self) -> None:
        self._model = None

    def run(self, reaction: str) -> ToolResult:
        """Classify a reaction into a named class.

        Parameters
        ----------
        reaction: str
            The reaction SMILES to classify.

        Returns
        -------
        ToolResult
            The predicted class label and confidence.
        """
        try:
            if self._model is None:
                from syncat import SynCatModel

                self._model = SynCatModel.load_pretrained()
            prediction = self._model.predict([reaction])[0]
            label = prediction.get("label")
            confidence = prediction.get("confidence")
            return ToolResult(
                ok=True,
                data={"label": label, "confidence": confidence},
                summary=(
                    f"Classified reaction as {label}"
                    + f" with confidence {confidence:.2f}."
                ),
            )
        except Exception as e:
            return ToolResult(
                ok=False,
                data={},
                summary=f"SynCat error: {e}",
            )


Tool: SynTool = SynCatClassifyTool()  # type: ignore
