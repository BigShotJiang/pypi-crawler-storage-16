"""Wrapper for SynKit canonicalization and MTG construction.

This tool canonicalizes reaction SMILES strings and can optionally
generate a mechanistic transition graph (MTG) for the reaction using
the SynKit package.
"""

from .base import ToolResult, SynTool


class SynKitCanonicalizeTool:
    """Canonicalize reactions using SynKit."""

    name = "synkit.canonicalize"
    description = (
        "Canonicalize a reaction SMILES using SynKit and optionally generate "
        "a mechanistic transition graph (MTG)."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "reaction": {"type": "string"},
            "with_mt_graph": {"type": "boolean", "default": False},
        },
        "required": ["reaction"],
    }

    def run(self, reaction: str, with_mt_graph: bool = False) -> ToolResult:
        """Canonicalize a reaction SMILES and optionally build an MTG.

        Parameters
        ----------
        reaction: str
            The reaction SMILES to canonicalize.
        with_mt_graph: bool, optional
            If True, also construct and return the mechanistic transition graph.

        Returns
        -------
        ToolResult
            Canonical SMILES string and optional MTG.
        """
        try:
            from synkit.io import Reaction
            from synkit.graph import build_mt_graph

            rxn = Reaction.from_string(reaction)
            canonical = rxn.canonical_smiles()
            data = {"canonical_smiles": canonical}
            if with_mt_graph:
                mtg = build_mt_graph(rxn)
                data["mt_graph"] = mtg
            return ToolResult(
                ok=True,
                data=data,
                summary="Canonicalization successful.",
            )
        except Exception as e:
            return ToolResult(
                ok=False,
                data={},
                summary=f"SynKit error: {e}",
            )


Tool: SynTool = SynKitCanonicalizeTool()  # type: ignore
