"""Wrapper for the SynRBL library.

This module exposes reaction rebalancing functionality via the SynRBL
package. It defines a tool that can rebalance stoichiometrically
imbalanced reaction SMILES strings by correcting non-carbon and carbon
imbalances.
"""

from .base import ToolResult, SynTool


class SynRBLBalanceTool:
    """Rebalance a reaction SMILES using SynRBL."""

    # Unique identifier for the tool
    name = "synrbl.balance"

    # Human-readable description of the tool's purpose
    description = (
        "Balance a stoichiometrically unbalanced reaction SMILES. "
        "This tool uses the SynRBL library to correct non-carbon and carbon imbalances."
    )

    # JSON-like schema describing the expected arguments
    input_schema = {
        "type": "object",
        "properties": {
            "reaction": {"type": "string"},
            "output_dict": {"type": "boolean", "default": False},
        },
        "required": ["reaction"],
    }

    def run(self, reaction: str, output_dict: bool = False) -> ToolResult:
        """Rebalance a reaction SMILES string.

        Parameters
        ----------
        reaction: str
            The reaction SMILES to rebalance.
        output_dict: bool, optional
            If True, return a detailed dictionary; otherwise return a string.

        Returns
        -------
        ToolResult
            The balanced reaction or an error summary.
        """
        try:
            # Import inside the method to avoid hard dependency when unused
            from synrbl import Balancer

            balancer = Balancer()
            result = balancer.rebalance(reaction, output_dict=output_dict)
            return ToolResult(
                ok=True,
                data={"balanced": result},
                summary="Rebalanced reaction successfully.",
            )
        except Exception as e:
            return ToolResult(
                ok=False,
                data={},
                summary=f"SynRBL error: {e}",
            )


# Expose a single instance for easy registration
Tool: SynTool = SynRBLBalanceTool()  # type: ignore
