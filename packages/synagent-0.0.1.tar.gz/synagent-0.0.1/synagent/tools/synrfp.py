"""Wrapper for SynRFP fingerprint generation.

This module defines a tool to generate mapping-free, permutation-invariant
reaction fingerprints using the SynRFP package. It produces fixed-length
binary vectors for similarity search or machine-learning applications.
"""

from .base import ToolResult, SynTool


class SynRFPTool:
    """Generate reaction fingerprints using SynRFP."""

    name = "synrfp.fingerprint"
    description = (
        "Generate a binary reaction fingerprint using SynRFP. "
        "This mapping-free method extracts tokens, computes net changes,"
        " and sketches them into fixed-length vectors."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "reaction": {"type": "string"},
            "fp_length": {"type": "integer", "default": 2048},
        },
        "required": ["reaction"],
    }

    def run(self, reaction: str, fp_length: int = 2048) -> ToolResult:
        """Generate a fingerprint for a reaction.

        Parameters
        ----------
        reaction: str
            The reaction SMILES to featurize.
        fp_length: int, optional
            The length of the fingerprint vector. Defaults to 2048.

        Returns
        -------
        ToolResult
            A dictionary containing the fingerprint vector.
        """
        try:
            import synrfp

            fingerprint = synrfp.synrfp(reaction, fp_length=fp_length)
            return ToolResult(
                ok=True,
                data={"fingerprint": fingerprint},
                summary="Fingerprint generated successfully.",
            )
        except Exception as e:
            return ToolResult(
                ok=False,
                data={},
                summary=f"SynRFP error: {e}",
            )


Tool: SynTool = SynRFPTool()  # type: ignore
