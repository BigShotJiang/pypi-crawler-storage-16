"""Wrapper for SynRXN dataset loading.

This module exposes a tool that loads curated reaction datasets from the
SynRXN registry. The datasets provide reproducible splits for benchmarking
reaction informatics tasks.
"""

from .base import ToolResult, SynTool


class SynRXNDatasetTool:
    """Load reaction datasets from SynRXN."""

    name = "synrxn.load_dataset"
    description = (
        "Load a reaction dataset from the SynRXN registry with reproducible splits."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "split": {"type": "string", "default": "train"},
        },
        "required": ["name"],
    }

    def run(self, name: str, split: str = "train") -> ToolResult:
        """Load a named dataset from SynRXN.

        Parameters
        ----------
        name: str
            The name of the dataset to load.
        split: str, optional
            The dataset split to retrieve (e.g. ``"train"``, ``"test"``).

        Returns
        -------
        ToolResult
            A dictionary containing the dataset object.
        """
        try:
            from synrxn import load_dataset

            dataset = load_dataset(name, split=split)
            return ToolResult(
                ok=True,
                data={"dataset": dataset},
                summary=f"Loaded {name} dataset (split={split}).",
            )
        except Exception as e:
            return ToolResult(
                ok=False,
                data={},
                summary=f"SynRXN error: {e}",
            )


Tool: SynTool = SynRXNDatasetTool()  # type: ignore
