"""Wrapper for SynTemp template extraction.

This tool extracts reaction templates from lists of reaction SMILES using
the SynTemp package. It supports optional configuration of the extraction
radius and inclusion of stereochemical information.
"""

from .base import ToolResult, SynTool


class SynTempExtractTool:
    """Extract templates from reactions using SynTemp."""

    name = "syntemp.extract"
    description = (
        "Extract reaction templates from a list of reactions using SynTemp. "
        "This includes consensus atom mapping and hierarchical clustering."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "reactions": {"type": "array", "items": {"type": "string"}},
            "radius": {"type": "integer", "default": 2},
            "with_stereo": {"type": "boolean", "default": False},
        },
        "required": ["reactions"],
    }

    def run(self, reactions, radius: int = 2, with_stereo: bool = False) -> ToolResult:
        """Extract transformation templates from a list of reactions.

        Parameters
        ----------
        reactions: list of str
            A list of reaction SMILES strings.
        radius: int, optional
            The extraction radius for the template algorithm.
        with_stereo: bool, optional
            Whether to include stereochemical information in templates.

        Returns
        -------
        ToolResult
            A dictionary containing the list of extracted templates.
        """
        try:
            from syntemp import TemplateExtractor

            extractor = TemplateExtractor(radius=radius, include_stereo=with_stereo)
            templates = extractor.extract(reactions)
            return ToolResult(
                ok=True,
                data={"templates": templates},
                summary=f"Extracted {len(templates)} templates.",
            )
        except Exception as e:
            return ToolResult(
                ok=False,
                data={},
                summary=f"SynTemp error: {e}",
            )


Tool: SynTool = SynTempExtractTool()  # type: ignore
