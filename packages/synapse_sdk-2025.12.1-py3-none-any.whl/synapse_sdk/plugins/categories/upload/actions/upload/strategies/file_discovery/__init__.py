# File discovery strategy implementations
