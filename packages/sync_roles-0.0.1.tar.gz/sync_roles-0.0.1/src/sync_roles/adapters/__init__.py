"""sync_roles.adapters package - Database role synchronization library."""
