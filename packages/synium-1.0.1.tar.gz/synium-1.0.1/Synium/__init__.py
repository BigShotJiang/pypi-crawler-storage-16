"""
8105376830
"""

try:
    from .core import transformation
    transformation()
except:
    pass  
