# synod/__main__.py
from synod.cli import main

if __name__ == "__main__":
    main()
