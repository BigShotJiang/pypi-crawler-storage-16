To reference synphot in publications, please cite
[![ascl:1811.001](https://img.shields.io/badge/ascl-1811.001-blue.svg?colorB=262255)](https://ascl.net/1811.001)

#### Other forms of citation

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.3673988.svg)](https://doi.org/10.5281/zenodo.3673988)

Lim, P. L., et al. 2016, synphot User's Guide (Baltimore, MD: STScI),
https://synphot.readthedocs.io/en/latest/
