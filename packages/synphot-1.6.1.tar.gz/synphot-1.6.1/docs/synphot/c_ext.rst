.. _synphot-c-ext:

calcbinflux
===========

.. autofunction:: synphot.synphot_utils.calcbinflux
