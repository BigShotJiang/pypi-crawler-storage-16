.. _synphot_config_file:

synphot's Default Configuration File
************************************

To customize this, copy it to your ``$HOME/.astropy/config/synphot.cfg``,
uncomment the relevant configuration item(s), and insert your desired value(s).

.. generate_config:: synphot
