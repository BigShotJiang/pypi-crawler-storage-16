Licenses
========

This directory holds license and credit information for works the ``synphot``
package is derived from or distributes, and/or datasets.

The license file for the ``synphot`` package itself is located in the root of
this repository.
