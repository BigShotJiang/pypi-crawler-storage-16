
string_navbar_items = [
        "Dashboard",     
        "Admin",      
    ]