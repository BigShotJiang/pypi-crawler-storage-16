"""MCP module for Synth AI setup tools."""

from synth_ai.core.integrations.mcp.main import main

__all__ = ["main"]

