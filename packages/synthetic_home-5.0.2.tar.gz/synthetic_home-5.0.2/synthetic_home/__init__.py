"""
.. include:: ../README.md
"""

__all__ = [
    "inventory",
    "device_types",
    "exceptions",
    "synthetic_home",
    "registry",
    "tool",
]
