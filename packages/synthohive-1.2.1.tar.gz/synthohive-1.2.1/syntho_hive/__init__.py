from .interface.config import Metadata, PrivacyConfig

__version__ = "1.2.1"
