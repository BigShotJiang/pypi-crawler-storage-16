"""Test the base module."""

from systembridgeconnector.base import Base


def test_base():
    """Test the base module."""
    base = Base()
    assert base is not None
