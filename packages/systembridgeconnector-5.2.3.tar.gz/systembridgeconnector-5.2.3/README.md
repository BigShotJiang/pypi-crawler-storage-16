# System Bridge - Connector

This is the connector package for the [System Bridge](https://github.com/timmo001/system-bridge) project.

Used in the System Bridge [Home Assistant](https://www.home-assistant.io/integrations/system_bridge) integration.
