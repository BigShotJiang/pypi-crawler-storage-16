# CHANGELOG

## DEPRECATED

 This changelog is no longer maintained and will not be updated in future releases. Please refer to the [release notes](https://github.com/miaucl/systemctl2mqtt/releases/latest) on GitHub for the latest changes.

## 1.3.1

* Fix parsing of memory values with suffixes from top

## 1.3.0

* Add option to group all entities into a single device in home assistant

## 1.2.0

* Update version package identifier and bump setuptools
* Fix mypy setup

## 1.1.2

* Update the discovery jsons for home assistant

## 1.1.1

* Refresh child PIDs every interval data is reported (see README.md for limitations of this behaviour)

## 1.1.0

* Add child pids to metrics

## 1.0.0

* Initial version.
