"""systemctl2mqtt main entry."""

from .systemctl2mqtt import main

if __name__ == "__main__":
    main()
