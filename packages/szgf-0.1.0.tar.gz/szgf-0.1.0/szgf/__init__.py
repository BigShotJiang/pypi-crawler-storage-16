from __future__ import annotations

from .client import SZGFClient
from .schemas.original import OriginalGuide
from .validator import validate_original_guide
