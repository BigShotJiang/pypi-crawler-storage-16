# szn-fulltext-robot-charon-api

This is a security placeholder package created to prevent dependency confusion attacks.