# szn-fulltext-robot-dolores-proto

This is a security placeholder package created to prevent dependency confusion attacks.