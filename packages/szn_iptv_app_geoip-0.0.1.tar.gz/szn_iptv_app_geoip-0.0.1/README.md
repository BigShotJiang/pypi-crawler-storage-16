# szn-iptv-app-geoip

This is a security placeholder package created to prevent dependency confusion attacks.