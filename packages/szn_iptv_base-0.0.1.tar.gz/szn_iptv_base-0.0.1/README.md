# szn-iptv-base

This is a security placeholder package created to prevent dependency confusion attacks.