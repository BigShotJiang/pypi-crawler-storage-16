# szn-iptv-django-softdelete

This is a security placeholder package created to prevent dependency confusion attacks.