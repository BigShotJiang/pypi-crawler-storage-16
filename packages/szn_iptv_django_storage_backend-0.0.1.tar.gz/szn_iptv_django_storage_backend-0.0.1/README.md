# szn-iptv-django-storage-backend

This is a security placeholder package created to prevent dependency confusion attacks.