# szn-iva-checker

This is a security placeholder package created to prevent dependency confusion attacks.