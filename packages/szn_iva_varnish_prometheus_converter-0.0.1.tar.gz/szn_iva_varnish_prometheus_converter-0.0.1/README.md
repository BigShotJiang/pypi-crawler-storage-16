# szn-iva-varnish-prometheus-converter

This is a security placeholder package created to prevent dependency confusion attacks.