from datetime import datetime
from typing import Tuple

DatetimeRange = Tuple[datetime, datetime]
