__version__ = "1.0.0"
__author__ = "Alina"
__license__ = "GNU General Public License v3.0"

from .core import main, TabFix, GitignoreMatcher, Colors

__all__ = ["main", "TabFix", "GitignoreMatcher", "Colors", "__version__"]
