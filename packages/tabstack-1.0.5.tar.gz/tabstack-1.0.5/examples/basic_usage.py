"""Example usage of Tabstack SDK."""

import asyncio
import os

from tabstack import Tabstack


async def main():
    """Run all examples."""
    # Initialize the client with connection pooling
    async with Tabstack(
        api_key=os.getenv("TABSTACK_API_KEY", "your-api-key-here"),
        max_connections=50,
        max_keepalive_connections=10,
    ) as tabs:
        # Example 1: Extract markdown from a URL
        print("Example 1: Extract Markdown")
        print("-" * 50)
        try:
            result = await tabs.extract.markdown(
                url="https://example.com/blog/article", metadata=True
            )
            print(f"URL: {result.url}")
            print(f"Title: {result.metadata.title if result.metadata else 'N/A'}")
            print(f"Content preview: {result.content[:100]}...")
        except Exception as e:
            print(f"Error: {e}")

        print("\n")

        # Example 2: Extract structured JSON data
        print("Example 2: Extract Structured JSON")
        print("-" * 50)
        try:
            schema = {
                "type": "object",
                "properties": {
                    "stories": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "title": {"type": "string"},
                                "points": {"type": "number"},
                                "author": {"type": "string"},
                            },
                        },
                    }
                },
            }

            result = await tabs.extract.json(url="https://news.ycombinator.com", schema=schema)
            print(f"Extracted data: {result.data}")
        except Exception as e:
            print(f"Error: {e}")

        print("\n")

        # Example 3: Generate transformed content with AI
        print("Example 3: Generate Transformed Content")
        print("-" * 50)
        try:
            summary_schema = {
                "type": "object",
                "properties": {
                    "summaries": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "title": {"type": "string"},
                                "category": {"type": "string"},
                                "summary": {"type": "string"},
                            },
                        },
                    }
                },
            }

            result = await tabs.generate.json(
                url="https://news.ycombinator.com",
                schema=summary_schema,
                instructions="For each story, categorize it (tech/business/science/other) "
                "and write a one-sentence summary",
            )
            print(f"Generated summaries: {result.data}")
        except Exception as e:
            print(f"Error: {e}")

        print("\n")

        # Example 4: Automate web tasks (streaming)
        print("Example 4: Web Automation (Streaming)")
        print("-" * 50)
        try:
            async for event in tabs.agent.automate(
                task="Find the top 3 trending repositories and extract their details",
                url="https://github.com/trending",
            ):
                if event.type == "task:completed":
                    print(f"✓ Task completed: {event.data.get('finalAnswer', 'N/A')}")
                elif event.type == "agent:extracted":
                    print(f"→ Extracted data: {event.data.get('extractedData', 'N/A')}")
                elif event.type == "agent:status":
                    print(f"→ Status: {event.data.get('message', 'N/A')}")
                elif event.type == "error":
                    print(f"✗ Error: {event.data.get('error', 'N/A')}")
                elif event.type == "done":
                    print("✓ Stream completed")
                    break
        except Exception as e:
            print(f"Error: {e}")


if __name__ == "__main__":
    # Run the async main function
    asyncio.run(main())
