"""
Tachyon CLI - Command Line Interface

NestJS-style CLI for scaffolding, code generation, and quality tools.
"""

from .main import app

__all__ = ["app"]
