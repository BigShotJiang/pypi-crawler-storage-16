"""
Entry point for `python -m tachyon_api.cli`
"""

from .main import main

if __name__ == "__main__":
    main()
