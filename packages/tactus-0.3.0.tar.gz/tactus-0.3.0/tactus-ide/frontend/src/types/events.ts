/**
 * Event type definitions for IDE structured output.
 * 
 * These match the Pydantic models in tactus-ide/backend/events.py
 */

export interface BaseEvent {
  event_type: string;
  timestamp: string;
  procedure_id?: string;
}

export interface LogEvent extends BaseEvent {
  event_type: 'log';
  level: string;
  message: string;
  context?: Record<string, any>;
  logger_name?: string;
}

export interface ExecutionEvent extends BaseEvent {
  event_type: 'execution';
  lifecycle_stage: 'start' | 'complete' | 'error' | 'waiting';
  details?: Record<string, any>;
  exit_code?: number;
}

export interface OutputEvent extends BaseEvent {
  event_type: 'output';
  stream: 'stdout' | 'stderr';
  content: string;
}

export interface ValidationEvent extends BaseEvent {
  event_type: 'validation';
  valid: boolean;
  errors: Array<{
    message: string;
    line?: number;
    column?: number;
    severity: string;
  }>;
}

export interface ExecutionSummaryEvent extends BaseEvent {
  event_type: 'execution_summary';
  result: any;
  final_state: Record<string, any>;
  iterations: number;
  tools_used: string[];
}

export interface TestStartedEvent extends BaseEvent {
  event_type: 'test_started';
  procedure_file: string;
  total_scenarios: number;
}

export interface TestCompletedEvent extends BaseEvent {
  event_type: 'test_completed';
  result: {
    total_scenarios: number;
    passed_scenarios: number;
    failed_scenarios: number;
    features: Array<{
      name: string;
      scenarios: Array<{
        name: string;
        status: string;
        duration: number;
        steps: Array<{
          keyword: string;
          text: string;
          status: string;
          error_message?: string;
        }>;
      }>;
    }>;
  };
}

export interface TestScenarioStartedEvent extends BaseEvent {
  event_type: 'test_scenario_started';
  scenario_name: string;
}

export interface TestScenarioCompletedEvent extends BaseEvent {
  event_type: 'test_scenario_completed';
  scenario_name: string;
  status: string;
  duration: number;
}

export interface EvaluationStartedEvent extends BaseEvent {
  event_type: 'evaluation_started';
  procedure_file: string;
  total_scenarios: number;
  runs_per_scenario: number;
}

export interface EvaluationCompletedEvent extends BaseEvent {
  event_type: 'evaluation_completed';
  results: Array<{
    scenario_name: string;
    total_runs: number;
    successful_runs: number;
    failed_runs: number;
    success_rate: number;
    consistency_score: number;
    is_flaky: boolean;
    avg_duration: number;
    std_duration: number;
  }>;
}

export interface EvaluationProgressEvent extends BaseEvent {
  event_type: 'evaluation_progress';
  scenario_name: string;
  completed_runs: number;
  total_runs: number;
}

export type AnyEvent = 
  | LogEvent 
  | ExecutionEvent 
  | OutputEvent 
  | ValidationEvent 
  | ExecutionSummaryEvent
  | TestStartedEvent
  | TestCompletedEvent
  | TestScenarioStartedEvent
  | TestScenarioCompletedEvent
  | EvaluationStartedEvent
  | EvaluationCompletedEvent
  | EvaluationProgressEvent;



