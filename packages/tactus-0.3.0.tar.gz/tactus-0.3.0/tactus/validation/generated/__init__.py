"""
Generated ANTLR parsers for Lua DSL.

These files are generated from the Lua.g4 grammar using ANTLR4.
Do not edit manually - regenerate using:
    make generate-parsers
"""
