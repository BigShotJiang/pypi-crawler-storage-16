**Attachment Type**
===================

.. _ArchiveFile:

ArchiveFile
------------

    **Attributes:**

        **name**: str

        **content**: Base64: str

        **type**: str



