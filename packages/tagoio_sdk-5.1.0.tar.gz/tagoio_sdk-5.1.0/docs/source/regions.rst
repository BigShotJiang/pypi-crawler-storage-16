.. _Regions:

Regions
----------------

    | **Regions**: Literal["us-e1", "eu-w1", "env"]
    | Supported TagoIO regions
