class Polarity:
    POS = "POS"
    NEG = "NEG"
