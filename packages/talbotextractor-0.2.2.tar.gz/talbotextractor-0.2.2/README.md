# TalbotExtractor

This package enables you to extract data from the Talbot experiment.

## Installation
