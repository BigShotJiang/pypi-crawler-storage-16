const e = {};
throw new Error('Could not resolve "geotiff" imported by "weatherlayers-gl".');
export {
  e as default
};
//# sourceMappingURL=__vite-optional-peer-dep_geotiff_weatherlayers-gl_false-Cjw5BclT.js.map
