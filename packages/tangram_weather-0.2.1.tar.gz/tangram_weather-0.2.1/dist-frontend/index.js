import { defineComponent as yl, inject as bl, ref as Yn, watch as vl, onMounted as xl, onUnmounted as wl, createElementBlock as Il, openBlock as _l, withModifiers as Ss, createElementVNode as Ls, withDirectives as Cl, toDisplayString as Ms, vModelText as El } from "vue";
import { CompositeLayer as je, COORDINATE_SYSTEM as jn } from "@deck.gl/core";
import { BitmapLayer as Xi, TextLayer as In, PathLayer as Qs, IconLayer as Ki, LineLayer as kl } from "@deck.gl/layers";
import { CollisionFilterExtension as Jr, PathStyleExtension as Tl } from "@deck.gl/extensions";
function is(a) {
  return a && a.__esModule && Object.prototype.hasOwnProperty.call(a, "default") ? a.default : a;
}
var er, Ds;
function Yi() {
  return Ds || (Ds = 1, er = (a, e = 0, t = 1) => a < e ? e : a > t ? t : a), er;
}
var tr, Ps;
function Bl() {
  if (Ps) return tr;
  Ps = 1;
  const a = Yi();
  return tr = (e) => {
    e._clipped = !1, e._unclipped = e.slice(0);
    for (let t = 0; t <= 3; t++)
      t < 3 ? ((e[t] < 0 || e[t] > 255) && (e._clipped = !0), e[t] = a(e[t], 0, 255)) : t === 3 && (e[t] = a(e[t], 0, 1));
    return e;
  }, tr;
}
var nr, Os;
function os() {
  if (Os) return nr;
  Os = 1;
  const a = {};
  for (let e of ["Boolean", "Number", "String", "Function", "Array", "Date", "RegExp", "Undefined", "Null"])
    a[`[object ${e}]`] = e.toLowerCase();
  return nr = function(e) {
    return a[Object.prototype.toString.call(e)] || "object";
  }, nr;
}
var rr, Ns;
function Sl() {
  if (Ns) return rr;
  Ns = 1;
  const a = os();
  return rr = (e, t = null) => e.length >= 3 ? Array.prototype.slice.call(e) : a(e[0]) == "object" && t ? t.split("").filter((n) => e[0][n] !== void 0).map((n) => e[0][n]) : e[0], rr;
}
var sr, Us;
function Ll() {
  if (Us) return sr;
  Us = 1;
  const a = os();
  return sr = (e) => {
    if (e.length < 2) return null;
    const t = e.length - 1;
    return a(e[t]) == "string" ? e[t].toLowerCase() : null;
  }, sr;
}
var ar, Vs;
function be() {
  if (Vs) return ar;
  Vs = 1;
  const a = Math.PI;
  return ar = {
    clip_rgb: Bl(),
    limit: Yi(),
    type: os(),
    unpack: Sl(),
    last: Ll(),
    PI: a,
    TWOPI: a * 2,
    PITHIRD: a / 3,
    DEG2RAD: a / 180,
    RAD2DEG: 180 / a
  }, ar;
}
var ir, Fs;
function rt() {
  return Fs || (Fs = 1, ir = {
    format: {},
    autodetect: []
  }), ir;
}
var or, Rs;
function De() {
  if (Rs) return or;
  Rs = 1;
  const { last: a, clip_rgb: e, type: t } = be(), n = rt();
  class r {
    constructor(...o) {
      const i = this;
      if (t(o[0]) === "object" && o[0].constructor && o[0].constructor === this.constructor)
        return o[0];
      let l = a(o), u = !1;
      if (!l) {
        u = !0, n.sorted || (n.autodetect = n.autodetect.sort((c, f) => f.p - c.p), n.sorted = !0);
        for (let c of n.autodetect)
          if (l = c.test(...o), l) break;
      }
      if (n.format[l]) {
        const c = n.format[l].apply(null, u ? o : o.slice(0, -1));
        i._rgb = e(c);
      } else
        throw new Error("unknown format: " + o);
      i._rgb.length === 3 && i._rgb.push(1);
    }
    toString() {
      return t(this.hex) == "function" ? this.hex() : `[${this._rgb.join(",")}]`;
    }
  }
  return or = r, or;
}
var lr, Ws;
function ft() {
  if (Ws) return lr;
  Ws = 1;
  const a = (...e) => new a.Color(...e);
  return a.Color = De(), a.version = "@@version", lr = a, lr;
}
var Ml = ft(), _n = /* @__PURE__ */ is(Ml), qs = {}, cr, Gs;
function Ql() {
  if (Gs) return cr;
  Gs = 1;
  const { unpack: a, last: e } = be(), t = (r) => Math.round(r * 100) / 100;
  return cr = (...r) => {
    const s = a(r, "hsla");
    let o = e(r) || "lsa";
    return s[0] = t(s[0] || 0), s[1] = t(s[1] * 100) + "%", s[2] = t(s[2] * 100) + "%", o === "hsla" || s.length > 3 && s[3] < 1 ? (s[3] = s.length > 3 ? s[3] : 1, o = "hsla") : s.length = 3, `${o}(${s.join(",")})`;
  }, cr;
}
var ur, Js;
function eo() {
  if (Js) return ur;
  Js = 1;
  const { unpack: a } = be();
  return ur = (...t) => {
    t = a(t, "rgba");
    let [n, r, s] = t;
    n /= 255, r /= 255, s /= 255;
    const o = Math.min(n, r, s), i = Math.max(n, r, s), l = (i + o) / 2;
    let u, c;
    return i === o ? (u = 0, c = Number.NaN) : u = l < 0.5 ? (i - o) / (i + o) : (i - o) / (2 - i - o), n == i ? c = (r - s) / (i - o) : r == i ? c = 2 + (s - n) / (i - o) : s == i && (c = 4 + (n - r) / (i - o)), c *= 60, c < 0 && (c += 360), t.length > 3 && t[3] !== void 0 ? [c, u, l, t[3]] : [c, u, l];
  }, ur;
}
var fr, zs;
function Dl() {
  if (zs) return fr;
  zs = 1;
  const { unpack: a, last: e } = be(), t = Ql(), n = eo(), { round: r } = Math;
  return fr = (...o) => {
    const i = a(o, "rgba");
    let l = e(o) || "rgb";
    return l.substr(0, 3) == "hsl" ? t(n(i), l) : (i[0] = r(i[0]), i[1] = r(i[1]), i[2] = r(i[2]), (l === "rgba" || i.length > 3 && i[3] < 1) && (i[3] = i.length > 3 ? i[3] : 1, l = "rgba"), `${l}(${i.slice(0, l === "rgb" ? 3 : 4).join(",")})`);
  }, fr;
}
var hr, Hs;
function to() {
  if (Hs) return hr;
  Hs = 1;
  const { unpack: a } = be(), { round: e } = Math;
  return hr = (...n) => {
    n = a(n, "hsl");
    const [r, s, o] = n;
    let i, l, u;
    if (s === 0)
      i = l = u = o * 255;
    else {
      const c = [0, 0, 0], f = [0, 0, 0], h = o < 0.5 ? o * (1 + s) : o + s - o * s, p = 2 * o - h, v = r / 360;
      c[0] = v + 1 / 3, c[1] = v, c[2] = v - 1 / 3;
      for (let I = 0; I < 3; I++)
        c[I] < 0 && (c[I] += 1), c[I] > 1 && (c[I] -= 1), 6 * c[I] < 1 ? f[I] = p + (h - p) * 6 * c[I] : 2 * c[I] < 1 ? f[I] = h : 3 * c[I] < 2 ? f[I] = p + (h - p) * (2 / 3 - c[I]) * 6 : f[I] = p;
      [i, l, u] = [e(f[0] * 255), e(f[1] * 255), e(f[2] * 255)];
    }
    return n.length > 3 ? [i, l, u, n[3]] : [i, l, u, 1];
  }, hr;
}
var dr, Zs;
function Pl() {
  if (Zs) return dr;
  Zs = 1;
  const a = to(), e = rt(), t = /^rgb\(\s*(-?\d+),\s*(-?\d+)\s*,\s*(-?\d+)\s*\)$/, n = /^rgba\(\s*(-?\d+),\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*([01]|[01]?\.\d+)\)$/, r = /^rgb\(\s*(-?\d+(?:\.\d+)?)%,\s*(-?\d+(?:\.\d+)?)%\s*,\s*(-?\d+(?:\.\d+)?)%\s*\)$/, s = /^rgba\(\s*(-?\d+(?:\.\d+)?)%,\s*(-?\d+(?:\.\d+)?)%\s*,\s*(-?\d+(?:\.\d+)?)%\s*,\s*([01]|[01]?\.\d+)\)$/, o = /^hsl\(\s*(-?\d+(?:\.\d+)?),\s*(-?\d+(?:\.\d+)?)%\s*,\s*(-?\d+(?:\.\d+)?)%\s*\)$/, i = /^hsla\(\s*(-?\d+(?:\.\d+)?),\s*(-?\d+(?:\.\d+)?)%\s*,\s*(-?\d+(?:\.\d+)?)%\s*,\s*([01]|[01]?\.\d+)\)$/, { round: l } = Math, u = (c) => {
    c = c.toLowerCase().trim();
    let f;
    if (e.format.named)
      try {
        return e.format.named(c);
      } catch {
      }
    if (f = c.match(t)) {
      const h = f.slice(1, 4);
      for (let p = 0; p < 3; p++)
        h[p] = +h[p];
      return h[3] = 1, h;
    }
    if (f = c.match(n)) {
      const h = f.slice(1, 5);
      for (let p = 0; p < 4; p++)
        h[p] = +h[p];
      return h;
    }
    if (f = c.match(r)) {
      const h = f.slice(1, 4);
      for (let p = 0; p < 3; p++)
        h[p] = l(h[p] * 2.55);
      return h[3] = 1, h;
    }
    if (f = c.match(s)) {
      const h = f.slice(1, 5);
      for (let p = 0; p < 3; p++)
        h[p] = l(h[p] * 2.55);
      return h[3] = +h[3], h;
    }
    if (f = c.match(o)) {
      const h = f.slice(1, 4);
      h[1] *= 0.01, h[2] *= 0.01;
      const p = a(h);
      return p[3] = 1, p;
    }
    if (f = c.match(i)) {
      const h = f.slice(1, 4);
      h[1] *= 0.01, h[2] *= 0.01;
      const p = a(h);
      return p[3] = +f[4], p;
    }
  };
  return u.test = (c) => t.test(c) || n.test(c) || r.test(c) || s.test(c) || o.test(c) || i.test(c), dr = u, dr;
}
var js;
function Ol() {
  if (js) return qs;
  js = 1;
  const a = ft(), e = De(), t = rt(), { type: n } = be(), r = Dl(), s = Pl();
  return e.prototype.css = function(o) {
    return r(this._rgb, o);
  }, a.css = (...o) => new e(...o, "css"), t.format.css = s, t.autodetect.push({
    p: 5,
    test: (o, ...i) => {
      if (!i.length && n(o) === "string" && s.test(o))
        return "css";
    }
  }), qs;
}
Ol();
var $s = {}, pr, Xs;
function no() {
  if (Xs) return pr;
  Xs = 1;
  const { unpack: a, last: e } = be(), { round: t } = Math;
  return pr = (...r) => {
    let [s, o, i, l] = a(r, "rgba"), u = e(r) || "auto";
    l === void 0 && (l = 1), u === "auto" && (u = l < 1 ? "rgba" : "rgb"), s = t(s), o = t(o), i = t(i);
    let f = "000000" + (s << 16 | o << 8 | i).toString(16);
    f = f.substr(f.length - 6);
    let h = "0" + t(l * 255).toString(16);
    switch (h = h.substr(h.length - 2), u.toLowerCase()) {
      case "rgba":
        return `#${f}${h}`;
      case "argb":
        return `#${h}${f}`;
      default:
        return `#${f}`;
    }
  }, pr;
}
var mr, Ks;
function ro() {
  if (Ks) return mr;
  Ks = 1;
  const a = /^#?([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/, e = /^#?([A-Fa-f0-9]{8}|[A-Fa-f0-9]{4})$/;
  return mr = (n) => {
    if (n.match(a)) {
      (n.length === 4 || n.length === 7) && (n = n.substr(1)), n.length === 3 && (n = n.split(""), n = n[0] + n[0] + n[1] + n[1] + n[2] + n[2]);
      const r = parseInt(n, 16), s = r >> 16, o = r >> 8 & 255, i = r & 255;
      return [s, o, i, 1];
    }
    if (n.match(e)) {
      (n.length === 5 || n.length === 9) && (n = n.substr(1)), n.length === 4 && (n = n.split(""), n = n[0] + n[0] + n[1] + n[1] + n[2] + n[2] + n[3] + n[3]);
      const r = parseInt(n, 16), s = r >> 24 & 255, o = r >> 16 & 255, i = r >> 8 & 255, l = Math.round((r & 255) / 255 * 100) / 100;
      return [s, o, i, l];
    }
    throw new Error(`unknown hex color: ${n}`);
  }, mr;
}
var Ys;
function Nl() {
  if (Ys) return $s;
  Ys = 1;
  const a = ft(), e = De(), { type: t } = be(), n = rt(), r = no();
  return e.prototype.hex = function(s) {
    return r(this._rgb, s);
  }, a.hex = (...s) => new e(...s, "hex"), n.format.hex = ro(), n.autodetect.push({
    p: 4,
    test: (s, ...o) => {
      if (!o.length && t(s) === "string" && [3, 4, 5, 6, 7, 8, 9].indexOf(s.length) >= 0)
        return "hex";
    }
  }), $s;
}
Nl();
var ea = {}, ta;
function so() {
  if (ta) return ea;
  ta = 1;
  const { unpack: a, type: e } = be(), t = ft(), n = De(), r = rt(), s = eo();
  return n.prototype.hsl = function() {
    return s(this._rgb);
  }, t.hsl = (...o) => new n(...o, "hsl"), r.format.hsl = to(), r.autodetect.push({
    p: 2,
    test: (...o) => {
      if (o = a(o, "hsl"), e(o) === "array" && o.length === 3)
        return "hsl";
    }
  }), ea;
}
so();
var na = {}, gr, ra;
function Ul() {
  if (ra) return gr;
  ra = 1;
  const { unpack: a } = be(), { min: e, max: t } = Math;
  return gr = (...r) => {
    r = a(r, "rgb");
    let [s, o, i] = r;
    const l = e(s, o, i), u = t(s, o, i), c = u - l;
    let f, h, p;
    return p = u / 255, u === 0 ? (f = Number.NaN, h = 0) : (h = c / u, s === u && (f = (o - i) / c), o === u && (f = 2 + (i - s) / c), i === u && (f = 4 + (s - o) / c), f *= 60, f < 0 && (f += 360)), [f, h, p];
  }, gr;
}
var Ar, sa;
function Vl() {
  if (sa) return Ar;
  sa = 1;
  const { unpack: a } = be(), { floor: e } = Math;
  return Ar = (...n) => {
    n = a(n, "hsv");
    let [r, s, o] = n, i, l, u;
    if (o *= 255, s === 0)
      i = l = u = o;
    else {
      r === 360 && (r = 0), r > 360 && (r -= 360), r < 0 && (r += 360), r /= 60;
      const c = e(r), f = r - c, h = o * (1 - s), p = o * (1 - s * f), v = o * (1 - s * (1 - f));
      switch (c) {
        case 0:
          [i, l, u] = [o, v, h];
          break;
        case 1:
          [i, l, u] = [p, o, h];
          break;
        case 2:
          [i, l, u] = [h, o, v];
          break;
        case 3:
          [i, l, u] = [h, p, o];
          break;
        case 4:
          [i, l, u] = [v, h, o];
          break;
        case 5:
          [i, l, u] = [o, h, p];
          break;
      }
    }
    return [i, l, u, n.length > 3 ? n[3] : 1];
  }, Ar;
}
var aa;
function ao() {
  if (aa) return na;
  aa = 1;
  const { unpack: a, type: e } = be(), t = ft(), n = De(), r = rt(), s = Ul();
  return n.prototype.hsv = function() {
    return s(this._rgb);
  }, t.hsv = (...o) => new n(...o, "hsv"), r.format.hsv = Vl(), r.autodetect.push({
    p: 2,
    test: (...o) => {
      if (o = a(o, "hsv"), e(o) === "array" && o.length === 3)
        return "hsv";
    }
  }), na;
}
ao();
var ia = {}, yr, oa;
function Fl() {
  return oa || (oa = 1, yr = {
    aliceblue: "#f0f8ff",
    antiquewhite: "#faebd7",
    aqua: "#00ffff",
    aquamarine: "#7fffd4",
    azure: "#f0ffff",
    beige: "#f5f5dc",
    bisque: "#ffe4c4",
    black: "#000000",
    blanchedalmond: "#ffebcd",
    blue: "#0000ff",
    blueviolet: "#8a2be2",
    brown: "#a52a2a",
    burlywood: "#deb887",
    cadetblue: "#5f9ea0",
    chartreuse: "#7fff00",
    chocolate: "#d2691e",
    coral: "#ff7f50",
    cornflower: "#6495ed",
    cornflowerblue: "#6495ed",
    cornsilk: "#fff8dc",
    crimson: "#dc143c",
    cyan: "#00ffff",
    darkblue: "#00008b",
    darkcyan: "#008b8b",
    darkgoldenrod: "#b8860b",
    darkgray: "#a9a9a9",
    darkgreen: "#006400",
    darkgrey: "#a9a9a9",
    darkkhaki: "#bdb76b",
    darkmagenta: "#8b008b",
    darkolivegreen: "#556b2f",
    darkorange: "#ff8c00",
    darkorchid: "#9932cc",
    darkred: "#8b0000",
    darksalmon: "#e9967a",
    darkseagreen: "#8fbc8f",
    darkslateblue: "#483d8b",
    darkslategray: "#2f4f4f",
    darkslategrey: "#2f4f4f",
    darkturquoise: "#00ced1",
    darkviolet: "#9400d3",
    deeppink: "#ff1493",
    deepskyblue: "#00bfff",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1e90ff",
    firebrick: "#b22222",
    floralwhite: "#fffaf0",
    forestgreen: "#228b22",
    fuchsia: "#ff00ff",
    gainsboro: "#dcdcdc",
    ghostwhite: "#f8f8ff",
    gold: "#ffd700",
    goldenrod: "#daa520",
    gray: "#808080",
    green: "#008000",
    greenyellow: "#adff2f",
    grey: "#808080",
    honeydew: "#f0fff0",
    hotpink: "#ff69b4",
    indianred: "#cd5c5c",
    indigo: "#4b0082",
    ivory: "#fffff0",
    khaki: "#f0e68c",
    laserlemon: "#ffff54",
    lavender: "#e6e6fa",
    lavenderblush: "#fff0f5",
    lawngreen: "#7cfc00",
    lemonchiffon: "#fffacd",
    lightblue: "#add8e6",
    lightcoral: "#f08080",
    lightcyan: "#e0ffff",
    lightgoldenrod: "#fafad2",
    lightgoldenrodyellow: "#fafad2",
    lightgray: "#d3d3d3",
    lightgreen: "#90ee90",
    lightgrey: "#d3d3d3",
    lightpink: "#ffb6c1",
    lightsalmon: "#ffa07a",
    lightseagreen: "#20b2aa",
    lightskyblue: "#87cefa",
    lightslategray: "#778899",
    lightslategrey: "#778899",
    lightsteelblue: "#b0c4de",
    lightyellow: "#ffffe0",
    lime: "#00ff00",
    limegreen: "#32cd32",
    linen: "#faf0e6",
    magenta: "#ff00ff",
    maroon: "#800000",
    maroon2: "#7f0000",
    maroon3: "#b03060",
    mediumaquamarine: "#66cdaa",
    mediumblue: "#0000cd",
    mediumorchid: "#ba55d3",
    mediumpurple: "#9370db",
    mediumseagreen: "#3cb371",
    mediumslateblue: "#7b68ee",
    mediumspringgreen: "#00fa9a",
    mediumturquoise: "#48d1cc",
    mediumvioletred: "#c71585",
    midnightblue: "#191970",
    mintcream: "#f5fffa",
    mistyrose: "#ffe4e1",
    moccasin: "#ffe4b5",
    navajowhite: "#ffdead",
    navy: "#000080",
    oldlace: "#fdf5e6",
    olive: "#808000",
    olivedrab: "#6b8e23",
    orange: "#ffa500",
    orangered: "#ff4500",
    orchid: "#da70d6",
    palegoldenrod: "#eee8aa",
    palegreen: "#98fb98",
    paleturquoise: "#afeeee",
    palevioletred: "#db7093",
    papayawhip: "#ffefd5",
    peachpuff: "#ffdab9",
    peru: "#cd853f",
    pink: "#ffc0cb",
    plum: "#dda0dd",
    powderblue: "#b0e0e6",
    purple: "#800080",
    purple2: "#7f007f",
    purple3: "#a020f0",
    rebeccapurple: "#663399",
    red: "#ff0000",
    rosybrown: "#bc8f8f",
    royalblue: "#4169e1",
    saddlebrown: "#8b4513",
    salmon: "#fa8072",
    sandybrown: "#f4a460",
    seagreen: "#2e8b57",
    seashell: "#fff5ee",
    sienna: "#a0522d",
    silver: "#c0c0c0",
    skyblue: "#87ceeb",
    slateblue: "#6a5acd",
    slategray: "#708090",
    slategrey: "#708090",
    snow: "#fffafa",
    springgreen: "#00ff7f",
    steelblue: "#4682b4",
    tan: "#d2b48c",
    teal: "#008080",
    thistle: "#d8bfd8",
    tomato: "#ff6347",
    turquoise: "#40e0d0",
    violet: "#ee82ee",
    wheat: "#f5deb3",
    white: "#ffffff",
    whitesmoke: "#f5f5f5",
    yellow: "#ffff00",
    yellowgreen: "#9acd32"
  }), yr;
}
var la;
function Rl() {
  if (la) return ia;
  la = 1;
  const a = De(), e = rt(), { type: t } = be(), n = Fl(), r = ro(), s = no();
  return a.prototype.name = function() {
    const o = s(this._rgb, "rgb");
    for (let i of Object.keys(n))
      if (n[i] === o) return i.toLowerCase();
    return o;
  }, e.format.named = (o) => {
    if (o = o.toLowerCase(), n[o]) return r(n[o]);
    throw new Error("unknown color name: " + o);
  }, e.autodetect.push({
    p: 5,
    test: (o, ...i) => {
      if (!i.length && t(o) === "string" && n[o.toLowerCase()])
        return "named";
    }
  }), ia;
}
Rl();
var ca = {}, ua;
function Wl() {
  if (ua) return ca;
  ua = 1;
  const a = ft(), e = De(), t = rt(), { unpack: n, type: r } = be(), { round: s } = Math;
  return e.prototype.rgb = function(o = !0) {
    return o === !1 ? this._rgb.slice(0, 3) : this._rgb.slice(0, 3).map(s);
  }, e.prototype.rgba = function(o = !0) {
    return this._rgb.slice(0, 4).map((i, l) => l < 3 ? o === !1 ? i : s(i) : i);
  }, a.rgb = (...o) => new e(...o, "rgb"), t.format.rgb = (...o) => {
    const i = n(o, "rgba");
    return i[3] === void 0 && (i[3] = 1), i;
  }, t.autodetect.push({
    p: 3,
    test: (...o) => {
      if (o = n(o, "rgba"), r(o) === "array" && (o.length === 3 || o.length === 4 && r(o[3]) == "number" && o[3] >= 0 && o[3] <= 1))
        return "rgb";
    }
  }), ca;
}
Wl();
var fa = {}, ha;
function ql() {
  if (ha) return fa;
  ha = 1;
  const a = De(), { type: e } = be();
  return a.prototype.alpha = function(t, n = !1) {
    return t !== void 0 && e(t) === "number" ? n ? (this._rgb[3] = t, this) : new a([this._rgb[0], this._rgb[1], this._rgb[2], t], "rgb") : this._rgb[3];
  }, fa;
}
ql();
var br, da;
function io() {
  if (da) return br;
  da = 1;
  const a = De();
  return br = (e, t, n, r) => {
    let s, o;
    r === "hsl" ? (s = e.hsl(), o = t.hsl()) : r === "hsv" ? (s = e.hsv(), o = t.hsv()) : r === "hcg" ? (s = e.hcg(), o = t.hcg()) : r === "hsi" ? (s = e.hsi(), o = t.hsi()) : r === "lch" || r === "hcl" ? (r = "hcl", s = e.hcl(), o = t.hcl()) : r === "oklch" && (s = e.oklch().reverse(), o = t.oklch().reverse());
    let i, l, u, c, f, h;
    (r.substr(0, 1) === "h" || r === "oklch") && ([i, u, f] = s, [l, c, h] = o);
    let p, v, I, y;
    return !isNaN(i) && !isNaN(l) ? (l > i && l - i > 180 ? y = l - (i + 360) : l < i && i - l > 180 ? y = l + 360 - i : y = l - i, v = i + n * y) : isNaN(i) ? isNaN(l) ? v = Number.NaN : (v = l, (f == 1 || f == 0) && r != "hsv" && (p = c)) : (v = i, (h == 1 || h == 0) && r != "hsv" && (p = u)), p === void 0 && (p = u + n * (c - u)), I = f + n * (h - f), r === "oklch" ? new a([I, p, v], r) : new a([v, p, I], r);
  }, br;
}
var vr, pa;
function $n() {
  return pa || (pa = 1, vr = {}), vr;
}
var xr, ma;
function Gl() {
  if (ma) return xr;
  ma = 1, so();
  const a = io(), e = (t, n, r) => a(t, n, r, "hsl");
  return $n().hsl = e, xr = e, xr;
}
Gl();
var wr, ga;
function Jl() {
  if (ga) return wr;
  ga = 1, ao();
  const a = io(), e = (t, n, r) => a(t, n, r, "hsv");
  return $n().hsv = e, wr = e, wr;
}
Jl();
var Ir, Aa;
function zl() {
  if (Aa) return Ir;
  Aa = 1;
  const a = De(), e = (t, n, r) => {
    const s = t._rgb, o = n._rgb;
    return new a(
      s[0] + r * (o[0] - s[0]),
      s[1] + r * (o[1] - s[1]),
      s[2] + r * (o[2] - s[2]),
      "rgb"
    );
  };
  return $n().rgb = e, Ir = e, Ir;
}
zl();
var _r, ya;
function Hl() {
  if (ya) return _r;
  ya = 1;
  const a = De(), { type: e } = be(), t = $n();
  return _r = (n, r, s = 0.5, ...o) => {
    let i = o[0] || "lrgb";
    if (!t[i] && !o.length && (i = Object.keys(t)[0]), !t[i])
      throw new Error(`interpolation mode ${i} is not defined`);
    return e(n) !== "object" && (n = new a(n)), e(r) !== "object" && (r = new a(r)), t[i](n, r, s).alpha(n.alpha() + s * (r.alpha() - n.alpha()));
  }, _r;
}
var Zl = Hl(), jl = /* @__PURE__ */ is(Zl), Cr, ba;
function $l() {
  if (ba) return Cr;
  ba = 1;
  const a = ft(), { type: e } = be(), { pow: t } = Math;
  Cr = function(r) {
    let s = "rgb", o = a("#ccc"), i = 0, l = [0, 1], u = [], c = [0, 0], f = !1, h = [], p = !1, v = 0, I = 1, y = !1, T = {}, L = !0, E = 1;
    const C = function(S) {
      if (S = S || ["#fff", "#000"], S && e(S) === "string" && a.brewer && a.brewer[S.toLowerCase()] && (S = a.brewer[S.toLowerCase()]), e(S) === "array") {
        S.length === 1 && (S = [S[0], S[0]]), S = S.slice(0);
        for (let q = 0; q < S.length; q++)
          S[q] = a(S[q]);
        u.length = 0;
        for (let q = 0; q < S.length; q++)
          u.push(q / (S.length - 1));
      }
      return N(), h = S;
    }, Q = function(S) {
      if (f != null) {
        const q = f.length - 1;
        let Y = 0;
        for (; Y < q && S >= f[Y]; )
          Y++;
        return Y - 1;
      }
      return 0;
    };
    let M = (S) => S, Z = (S) => S;
    const z = function(S, q) {
      let Y, j;
      if (q == null && (q = !1), isNaN(S) || S === null)
        return o;
      q ? j = S : f && f.length > 2 ? j = Q(S) / (f.length - 2) : I !== v ? j = (S - v) / (I - v) : j = 1, j = Z(j), q || (j = M(j)), E !== 1 && (j = t(j, E)), j = c[0] + j * (1 - c[0] - c[1]), j = Math.min(1, Math.max(0, j));
      const se = Math.floor(j * 1e4);
      if (L && T[se])
        Y = T[se];
      else {
        if (e(h) === "array")
          for (let ne = 0; ne < u.length; ne++) {
            const ye = u[ne];
            if (j <= ye) {
              Y = h[ne];
              break;
            }
            if (j >= ye && ne === u.length - 1) {
              Y = h[ne];
              break;
            }
            if (j > ye && j < u[ne + 1]) {
              j = (j - ye) / (u[ne + 1] - ye), Y = a.interpolate(h[ne], h[ne + 1], j, s);
              break;
            }
          }
        else e(h) === "function" && (Y = h(j));
        L && (T[se] = Y);
      }
      return Y;
    };
    var N = () => T = {};
    C(r);
    const G = function(S) {
      const q = a(z(S));
      return p && q[p] ? q[p]() : q;
    };
    return G.classes = function(S) {
      if (S != null) {
        if (e(S) === "array")
          f = S, l = [S[0], S[S.length - 1]];
        else {
          const q = a.analyze(l);
          S === 0 ? f = [q.min, q.max] : f = a.limits(q, "e", S);
        }
        return G;
      }
      return f;
    }, G.domain = function(S) {
      if (!arguments.length)
        return l;
      v = S[0], I = S[S.length - 1], u = [];
      const q = h.length;
      if (S.length === q && v !== I)
        for (let Y of Array.from(S))
          u.push((Y - v) / (I - v));
      else {
        for (let Y = 0; Y < q; Y++)
          u.push(Y / (q - 1));
        if (S.length > 2) {
          const Y = S.map((se, ne) => ne / (S.length - 1)), j = S.map((se) => (se - v) / (I - v));
          j.every((se, ne) => Y[ne] === se) || (Z = (se) => {
            if (se <= 0 || se >= 1) return se;
            let ne = 0;
            for (; se >= j[ne + 1]; ) ne++;
            const ye = (se - j[ne]) / (j[ne + 1] - j[ne]);
            return Y[ne] + ye * (Y[ne + 1] - Y[ne]);
          });
        }
      }
      return l = [v, I], G;
    }, G.mode = function(S) {
      return arguments.length ? (s = S, N(), G) : s;
    }, G.range = function(S, q) {
      return C(S), G;
    }, G.out = function(S) {
      return p = S, G;
    }, G.spread = function(S) {
      return arguments.length ? (i = S, G) : i;
    }, G.correctLightness = function(S) {
      return S == null && (S = !0), y = S, N(), y ? M = function(q) {
        const Y = z(0, !0).lab()[0], j = z(1, !0).lab()[0], se = Y > j;
        let ne = z(q, !0).lab()[0];
        const ye = Y + (j - Y) * q;
        let Ge = ne - ye, le = 0, Oe = 1, ht = 20;
        for (; Math.abs(Ge) > 0.01 && ht-- > 0; )
          (function() {
            return se && (Ge *= -1), Ge < 0 ? (le = q, q += (Oe - q) * 0.5) : (Oe = q, q += (le - q) * 0.5), ne = z(q, !0).lab()[0], Ge = ne - ye;
          })();
        return q;
      } : M = (q) => q, G;
    }, G.padding = function(S) {
      return S != null ? (e(S) === "number" && (S = [S, S]), c = S, G) : c;
    }, G.colors = function(S, q) {
      arguments.length < 2 && (q = "hex");
      let Y = [];
      if (arguments.length === 0)
        Y = h.slice(0);
      else if (S === 1)
        Y = [G(0.5)];
      else if (S > 1) {
        const j = l[0], se = l[1] - j;
        Y = n(0, S).map((ne) => G(j + ne / (S - 1) * se));
      } else {
        r = [];
        let j = [];
        if (f && f.length > 2)
          for (let se = 1, ne = f.length, ye = 1 <= ne; ye ? se < ne : se > ne; ye ? se++ : se--)
            j.push((f[se - 1] + f[se]) * 0.5);
        else
          j = l;
        Y = j.map((se) => G(se));
      }
      return a[q] && (Y = Y.map((j) => j[q]())), Y;
    }, G.cache = function(S) {
      return S != null ? (L = S, G) : L;
    }, G.gamma = function(S) {
      return S != null ? (E = S, G) : E;
    }, G.nodata = function(S) {
      return S != null ? (o = a(S), G) : o;
    }, G;
  };
  function n(r, s, o) {
    let i = [], l = r < s, u = s;
    for (let c = r; l ? c < u : c > u; l ? c++ : c--)
      i.push(c);
    return i;
  }
  return Cr;
}
var Xl = $l(), Kl = /* @__PURE__ */ is(Xl);
_n.mix = _n.interpolate = jl;
_n.scale = Kl;
const oo = /[ ,\t:]+/g, Yl = /[\-\/]/g;
function ls(a) {
  return a.startsWith("#");
}
function ec(a) {
  return a.some((e) => !ls(e) && e.split(oo).length >= 8);
}
function tc(a) {
  return a.some((e) => !!(!ls(e) && (e.match(/\d+\-\d+\-\d+/) || e.match(/\d+\/\d+\/\d+/))));
}
function nc(a) {
  const e = a.find((t) => ls(t) && t.includes("COLOR_MODEL = "));
  if (e) {
    const t = e.match(/COLOR_MODEL = ([a-zA-Z]+)/);
    if (t)
      return t[1].toLowerCase();
  }
}
function Er(a) {
  const e = a.split(Yl);
  return e.length === 1 ? e[0] : e;
}
function rc(a) {
  const e = a.trim().split(`
`), t = ec(e), n = tc(e), r = nc(e), s = e.filter((i) => !!i && !i.startsWith("#")), o = [];
  for (let i of s) {
    const l = i.split(oo);
    t ? l.length === 8 || l.length === 9 ? (o.push([l[0], [l[1], l[2], l[3]]]), o.push([l[4], [l[5], l[6], l[7]]])) : (l.length === 4 || l.length === 5) && o.push([l[0], [l[1], l[2], l[3]]]) : n ? l.length === 4 || l.length === 5 ? (o.push([l[0], Er(l[1])]), o.push([l[2], Er(l[3])])) : (l.length === 2 || l.length === 3) && o.push([l[0], Er(l[1])]) : l.length === 5 ? o.push([l[0], [l[1], l[2], l[3], l[4]]]) : l.length === 4 ? o.push([l[0], [l[1], l[2], l[3]]]) : l.length === 2 && o.push([l[0], l[1]]);
  }
  return { paletteArray: o, mode: r };
}
const sc = "rgb";
function ac(a, e) {
  if (typeof a == "string")
    if (a[a.length - 1] === "%") {
      const t = parseFloat(a) / 100;
      if (t < 0 || t > 1)
        throw new Error(`Invalid value for a percentage ${a}`);
      return e[0] + (e[1] - e[0]) * t;
    } else return a === "N" ? null : a === "B" || a === "F" ? void 0 : a === "nv" ? null : a === "default" ? void 0 : a === "null" || a === "nodata" ? null : parseFloat(a);
  else {
    if (typeof a == "number")
      return a;
    throw new Error("Invalid state");
  }
}
function ic(a, e) {
  if (Array.isArray(a)) {
    if (a.length === 4)
      return {
        [e[0]]: parseFloat(a[0].toString()),
        [e[1]]: parseFloat(a[1].toString()),
        [e[2]]: parseFloat(a[2].toString()),
        a: parseFloat(a[3].toString()) / 255
      };
    if (a.length === 3)
      return {
        [e[0]]: parseFloat(a[0].toString()),
        [e[1]]: parseFloat(a[1].toString()),
        [e[2]]: parseFloat(a[2].toString())
      };
    throw new Error(`Invalid color ${a}`);
  } else {
    if (typeof a == "string" || typeof a == "number")
      return a.toString().match(/^\d+$/) || typeof a == "number" ? {
        [e[0]]: parseFloat(a.toString()),
        [e[1]]: parseFloat(a.toString()),
        [e[2]]: parseFloat(a.toString())
      } : a;
    throw new Error(`Invalid color ${a}`);
  }
}
function lo(a, { bounds: e = [0, 1], mode: t = sc } = {}) {
  const n = [], r = [];
  let s;
  for (let [i, l] of a) {
    const u = ac(i, e), c = ic(l, t);
    u != null ? (n.push(c), r.push(u)) : u === null && (s = c);
  }
  let o = _n.scale(n).domain(r).mode(t);
  return typeof s < "u" && (o = o.nodata(s)), o;
}
function oc(a, { bounds: e = [0, 1] } = {}) {
  const { paletteArray: t, mode: n } = rc(a);
  return lo(t, { bounds: e, mode: n });
}
function $t(a, { bounds: e = [0, 1] } = {}) {
  if (typeof a == "string")
    return oc(a, { bounds: e });
  if (Array.isArray(a))
    return lo(a, { bounds: e });
  throw new Error("Invalid format");
}
function lc(a, { width: e = 256, height: t = 1 } = {}) {
  const n = a.colors(e, "css"), r = document.createElement("canvas");
  r.width = e, r.height = t, r.style.imageRendering = "-moz-crisp-edges", r.style.imageRendering = "pixelated";
  const s = r.getContext("2d");
  for (let o = 0; o < e; o++)
    s.fillStyle = n[o], s.fillRect(o, 0, 1, t);
  return r;
}
const co = 6371e3;
function cc(a, e) {
  return !(Math.abs(a[0] - e[0]) > Number.EPSILON || Math.abs(a[1] - e[1]) > Number.EPSILON);
}
function Fe(a) {
  return a / 180 * Math.PI;
}
function zr(a) {
  return a / Math.PI * 180;
}
function uc(a) {
  return (a + 360) % 360;
}
function fc(a, e, t = co) {
  const n = t, r = Fe(a[1]), s = Fe(a[0]), o = Fe(e[1]), i = Fe(e[0]), l = o - r, u = i - s, c = Math.sin(l / 2) * Math.sin(l / 2) + Math.cos(r) * Math.cos(o) * Math.sin(u / 2) * Math.sin(u / 2), f = 2 * Math.atan2(Math.sqrt(c), Math.sqrt(1 - c));
  return n * f;
}
function hc(a, e) {
  if (cc(a, e))
    return NaN;
  const t = Fe(a[1]), n = Fe(e[1]), r = Fe(e[0] - a[0]), s = Math.cos(t) * Math.sin(n) - Math.sin(t) * Math.cos(n) * Math.cos(r), o = Math.sin(r) * Math.cos(n), i = Math.atan2(o, s), l = zr(i);
  return uc(l);
}
function dc(a, e, t, n = co) {
  const r = e / n, s = Fe(t), o = Fe(a[1]), i = Fe(a[0]), l = Math.sin(o) * Math.cos(r) + Math.cos(o) * Math.sin(r) * Math.cos(s), u = Math.asin(l), c = Math.sin(s) * Math.sin(r) * Math.cos(o), f = Math.cos(r) - Math.sin(o) * l, h = i + Math.atan2(c, f), p = zr(u);
  return [zr(h), p];
}
const uo = Symbol("Comlink.proxy"), pc = Symbol("Comlink.endpoint"), mc = Symbol("Comlink.releaseProxy"), kr = Symbol("Comlink.finalizer"), dn = Symbol("Comlink.thrown"), fo = (a) => typeof a == "object" && a !== null || typeof a == "function", gc = {
  canHandle: (a) => fo(a) && a[uo],
  serialize(a) {
    const { port1: e, port2: t } = new MessageChannel();
    return po(a, e), [t, [t]];
  },
  deserialize(a) {
    return a.start(), go(a);
  }
}, Ac = {
  canHandle: (a) => fo(a) && dn in a,
  serialize({ value: a }) {
    let e;
    return a instanceof Error ? e = {
      isError: !0,
      value: {
        message: a.message,
        name: a.name,
        stack: a.stack
      }
    } : e = { isError: !1, value: a }, [e, []];
  },
  deserialize(a) {
    throw a.isError ? Object.assign(new Error(a.value.message), a.value) : a.value;
  }
}, ho = /* @__PURE__ */ new Map([
  ["proxy", gc],
  ["throw", Ac]
]);
function yc(a, e) {
  for (const t of a)
    if (e === t || t === "*" || t instanceof RegExp && t.test(e))
      return !0;
  return !1;
}
function po(a, e = globalThis, t = ["*"]) {
  e.addEventListener("message", function n(r) {
    if (!r || !r.data)
      return;
    if (!yc(t, r.origin)) {
      console.warn(`Invalid origin '${r.origin}' for comlink proxy`);
      return;
    }
    const { id: s, type: o, path: i } = Object.assign({ path: [] }, r.data), l = (r.data.argumentList || []).map(ot);
    let u;
    try {
      const c = i.slice(0, -1).reduce((h, p) => h[p], a), f = i.reduce((h, p) => h[p], a);
      switch (o) {
        case "GET":
          u = f;
          break;
        case "SET":
          c[i.slice(-1)[0]] = ot(r.data.value), u = !0;
          break;
        case "APPLY":
          u = f.apply(c, l);
          break;
        case "CONSTRUCT":
          {
            const h = new f(...l);
            u = Ic(h);
          }
          break;
        case "ENDPOINT":
          {
            const { port1: h, port2: p } = new MessageChannel();
            po(a, p), u = Zr(h, [h]);
          }
          break;
        case "RELEASE":
          u = void 0;
          break;
        default:
          return;
      }
    } catch (c) {
      u = { value: c, [dn]: 0 };
    }
    Promise.resolve(u).catch((c) => ({ value: c, [dn]: 0 })).then((c) => {
      const [f, h] = kn(c);
      e.postMessage(Object.assign(Object.assign({}, f), { id: s }), h), o === "RELEASE" && (e.removeEventListener("message", n), mo(e), kr in a && typeof a[kr] == "function" && a[kr]());
    }).catch((c) => {
      const [f, h] = kn({
        value: new TypeError("Unserializable return value"),
        [dn]: 0
      });
      e.postMessage(Object.assign(Object.assign({}, f), { id: s }), h);
    });
  }), e.start && e.start();
}
function bc(a) {
  return a.constructor.name === "MessagePort";
}
function mo(a) {
  bc(a) && a.close();
}
function go(a, e) {
  const t = /* @__PURE__ */ new Map();
  return a.addEventListener("message", function(r) {
    const { data: s } = r;
    if (!s || !s.id)
      return;
    const o = t.get(s.id);
    if (o)
      try {
        o(s);
      } finally {
        t.delete(s.id);
      }
  }), Hr(a, t, [], e);
}
function Yt(a) {
  if (a)
    throw new Error("Proxy has been released and is not useable");
}
function Ao(a) {
  return yt(a, /* @__PURE__ */ new Map(), {
    type: "RELEASE"
  }).then(() => {
    mo(a);
  });
}
const Cn = /* @__PURE__ */ new WeakMap(), En = "FinalizationRegistry" in globalThis && new FinalizationRegistry((a) => {
  const e = (Cn.get(a) || 0) - 1;
  Cn.set(a, e), e === 0 && Ao(a);
});
function vc(a, e) {
  const t = (Cn.get(e) || 0) + 1;
  Cn.set(e, t), En && En.register(a, e, a);
}
function xc(a) {
  En && En.unregister(a);
}
function Hr(a, e, t = [], n = function() {
}) {
  let r = !1;
  const s = new Proxy(n, {
    get(o, i) {
      if (Yt(r), i === mc)
        return () => {
          xc(s), Ao(a), e.clear(), r = !0;
        };
      if (i === "then") {
        if (t.length === 0)
          return { then: () => s };
        const l = yt(a, e, {
          type: "GET",
          path: t.map((u) => u.toString())
        }).then(ot);
        return l.then.bind(l);
      }
      return Hr(a, e, [...t, i]);
    },
    set(o, i, l) {
      Yt(r);
      const [u, c] = kn(l);
      return yt(a, e, {
        type: "SET",
        path: [...t, i].map((f) => f.toString()),
        value: u
      }, c).then(ot);
    },
    apply(o, i, l) {
      Yt(r);
      const u = t[t.length - 1];
      if (u === pc)
        return yt(a, e, {
          type: "ENDPOINT"
        }).then(ot);
      if (u === "bind")
        return Hr(a, e, t.slice(0, -1));
      const [c, f] = va(l);
      return yt(a, e, {
        type: "APPLY",
        path: t.map((h) => h.toString()),
        argumentList: c
      }, f).then(ot);
    },
    construct(o, i) {
      Yt(r);
      const [l, u] = va(i);
      return yt(a, e, {
        type: "CONSTRUCT",
        path: t.map((c) => c.toString()),
        argumentList: l
      }, u).then(ot);
    }
  });
  return vc(s, a), s;
}
function wc(a) {
  return Array.prototype.concat.apply([], a);
}
function va(a) {
  const e = a.map(kn);
  return [e.map((t) => t[0]), wc(e.map((t) => t[1]))];
}
const yo = /* @__PURE__ */ new WeakMap();
function Zr(a, e) {
  return yo.set(a, e), a;
}
function Ic(a) {
  return Object.assign(a, { [uo]: !0 });
}
function kn(a) {
  for (const [e, t] of ho)
    if (t.canHandle(a)) {
      const [n, r] = t.serialize(a);
      return [
        {
          type: "HANDLER",
          name: e,
          value: n
        },
        r
      ];
    }
  return [
    {
      type: "RAW",
      value: a
    },
    yo.get(a) || []
  ];
}
function ot(a) {
  switch (a.type) {
    case "HANDLER":
      return ho.get(a.name).deserialize(a.value);
    case "RAW":
      return a.value;
  }
}
function yt(a, e, t, n) {
  return new Promise((r) => {
    const s = _c();
    e.set(s, r), a.start && a.start(), a.postMessage(Object.assign({ id: s }, t), n);
  });
}
function _c() {
  return new Array(4).fill(0).map(() => Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16)).join("-");
}
const bo = function(a) {
  return a.on = a.addEventListener, a.off = a.removeEventListener, a;
}, Cc = function(a) {
  try {
    return URL.createObjectURL(new Blob([a], { type: "application/javascript" }));
  } catch {
    const t = new BlobBuilder();
    return t.append(a), URL.createObjectURL(t.getBlob());
  }
}, Ec = function(a) {
  return function() {
    const e = Cc(a), t = bo(new Worker(e));
    t.objURL = e;
    const n = t.terminate;
    return t.on = t.addEventListener, t.off = t.removeEventListener, t.terminate = function() {
      return URL.revokeObjectURL(e), n.call(this);
    }, t;
  };
}, kc = function(a) {
  return `var browserWorkerPolyFill = ${bo.toString()};
browserWorkerPolyFill(self);
` + a;
}, en = Math.PI / 180, tn = 180 / Math.PI, nn = 6378137, $e = 20037508342789244e-9, rn = "900913", Tc = "WGS84", dt = {};
function xa(a) {
  return Number(a) === a && a % 1 !== 0;
}
class Bc {
  #e;
  #t;
  #s;
  #a;
  #r;
  #n;
  constructor(e = {}) {
    if (this.#e = e.size || 256, this.#t = e.antimeridian ? 2 : 1, !dt[this.#e]) {
      let t = this.#e;
      const n = dt[this.#e] = {};
      n.Bc = [], n.Cc = [], n.zc = [], n.Ac = [];
      for (let r = 0; r < 30; r++)
        n.Bc.push(t / 360), n.Cc.push(t / (2 * Math.PI)), n.zc.push(t / 2), n.Ac.push(t), t *= 2;
    }
    this.#s = dt[this.#e].Bc, this.#a = dt[this.#e].Cc, this.#r = dt[this.#e].zc, this.#n = dt[this.#e].Ac;
  }
  px(e, t) {
    if (xa(t)) {
      const n = this.#e * Math.pow(2, t), r = n / 2, s = n / 360, o = n / (2 * Math.PI), i = n, l = Math.min(Math.max(Math.sin(en * e[1]), -0.9999), 0.9999);
      let u = r + e[0] * s, c = r + 0.5 * Math.log((1 + l) / (1 - l)) * -o;
      return u > i * this.#t && (u = i * this.#t), c > i && (c = i), [u, c];
    } else {
      const n = this.#r[t], r = Math.min(Math.max(Math.sin(en * e[1]), -0.9999), 0.9999);
      let s = Math.round(n + e[0] * this.#s[t]), o = Math.round(n + 0.5 * Math.log((1 + r) / (1 - r)) * -this.#a[t]);
      return s > this.#n[t] * this.#t && (s = this.#n[t] * this.#t), o > this.#n[t] && (o = this.#n[t]), [s, o];
    }
  }
  ll(e, t) {
    if (xa(t)) {
      const n = this.#e * Math.pow(2, t), r = n / 360, s = n / (2 * Math.PI), o = n / 2, i = (e[1] - o) / -s, l = (e[0] - o) / r, u = tn * (2 * Math.atan(Math.exp(i)) - 0.5 * Math.PI);
      return [l, u];
    } else {
      const n = (e[1] - this.#r[t]) / -this.#a[t], r = (e[0] - this.#r[t]) / this.#s[t], s = tn * (2 * Math.atan(Math.exp(n)) - 0.5 * Math.PI);
      return [r, s];
    }
  }
  convert(e, t) {
    return t === rn ? [
      ...this.forward(e.slice(0, 2)),
      ...this.forward(e.slice(2, 4))
    ] : [
      ...this.inverse(e.slice(0, 2)),
      ...this.inverse(e.slice(2, 4))
    ];
  }
  inverse(e) {
    return [
      e[0] * tn / nn,
      (Math.PI * 0.5 - 2 * Math.atan(Math.exp(-e[1] / nn))) * tn
    ];
  }
  forward(e) {
    const t = [
      nn * e[0] * en,
      nn * Math.log(Math.tan(Math.PI * 0.25 + 0.5 * e[1] * en))
    ];
    return t[0] > $e && (t[0] = $e), t[0] < -$e && (t[0] = -$e), t[1] > $e && (t[1] = $e), t[1] < -$e && (t[1] = -$e), t;
  }
  bbox(e, t, n, r, s) {
    r && (t = Math.pow(2, n) - 1 - t);
    const o = [e * this.#e, (+t + 1) * this.#e], i = [(+e + 1) * this.#e, t * this.#e], l = [...this.ll(o, n), ...this.ll(i, n)];
    return s === rn ? this.convert(l, rn) : l;
  }
  xyz(e, t, n, r) {
    const s = r === rn ? this.convert(e, Tc) : e, o = [s[0], s[1]], i = [s[2], s[3]], l = this.px(o, t), u = this.px(i, t), c = [
      Math.floor(l[0] / this.#e),
      Math.floor((u[0] - 1) / this.#e)
    ], f = [
      Math.floor(u[1] / this.#e),
      Math.floor((l[1] - 1) / this.#e)
    ], h = {
      minX: Math.min.apply(Math, c) < 0 ? 0 : Math.min.apply(Math, c),
      minY: Math.min.apply(Math, f) < 0 ? 0 : Math.min.apply(Math, f),
      maxX: Math.max.apply(Math, c),
      maxY: Math.max.apply(Math, f)
    };
    if (n) {
      const p = {
        minY: Math.pow(2, t) - 1 - h.maxY,
        maxY: Math.pow(2, t) - 1 - h.minY
      };
      h.minY = p.minY, h.maxY = p.maxY;
    }
    return h;
  }
}
function Sc(a = 4, e = !1) {
  if (a > 10) throw new Error(`Max order is 10, but given ${a}.`);
  const t = (1 + Math.sqrt(5)) / 2, r = 10 * Math.pow(4, a) + 2, s = e ? a === 0 ? 3 : Math.pow(2, a) * 3 + 9 : 0, o = new Float32Array((r + s) * 3);
  o.set(Float32Array.of(
    -1,
    t,
    0,
    1,
    t,
    0,
    -1,
    -t,
    0,
    1,
    -t,
    0,
    0,
    -1,
    t,
    0,
    1,
    t,
    0,
    -1,
    -t,
    0,
    1,
    -t,
    t,
    0,
    -1,
    t,
    0,
    1,
    -t,
    0,
    -1,
    -t,
    0,
    1
  ));
  let i = Uint16Array.of(
    0,
    11,
    5,
    0,
    5,
    1,
    0,
    1,
    7,
    0,
    7,
    10,
    0,
    10,
    11,
    11,
    10,
    2,
    5,
    11,
    4,
    1,
    5,
    9,
    7,
    1,
    8,
    10,
    7,
    6,
    3,
    9,
    4,
    3,
    4,
    2,
    3,
    2,
    6,
    3,
    6,
    8,
    3,
    8,
    9,
    9,
    8,
    1,
    4,
    9,
    5,
    2,
    4,
    11,
    6,
    2,
    10,
    8,
    6,
    7
  ), l = 12;
  const u = a ? /* @__PURE__ */ new Map() : null;
  function c(y, T) {
    const L = Math.floor((y + T) * (y + T + 1) / 2 + Math.min(y, T)), E = u.get(L);
    return E !== void 0 ? (u.delete(L), E) : (u.set(L, l), o[3 * l + 0] = (o[3 * y + 0] + o[3 * T + 0]) * 0.5, o[3 * l + 1] = (o[3 * y + 1] + o[3 * T + 1]) * 0.5, o[3 * l + 2] = (o[3 * y + 2] + o[3 * T + 2]) * 0.5, l++);
  }
  let f = i;
  const h = a > 5 ? Uint32Array : Uint16Array;
  for (let y = 0; y < a; y++) {
    const T = f.length;
    i = new h(T * 4);
    for (let L = 0; L < T; L += 3) {
      const E = f[L + 0], C = f[L + 1], Q = f[L + 2], M = c(E, C), Z = c(C, Q), z = c(Q, E);
      let N = L * 4;
      i[N++] = E, i[N++] = M, i[N++] = z, i[N++] = C, i[N++] = Z, i[N++] = M, i[N++] = Q, i[N++] = z, i[N++] = Z, i[N++] = M, i[N++] = Z, i[N++] = z;
    }
    f = i;
  }
  for (let y = 0; y < r * 3; y += 3) {
    const T = o[y + 0], L = o[y + 1], E = o[y + 2], C = 1 / Math.sqrt(T * T + L * L + E * E);
    o[y + 0] *= C, o[y + 1] *= C, o[y + 2] *= C;
  }
  if (!e) return { vertices: o, triangles: i };
  const p = new Float32Array((r + s) * 2);
  for (let y = 0; y < r; y++)
    p[2 * y + 0] = Math.atan2(o[3 * y + 2], o[3 * y]) / (2 * Math.PI) + 0.5, p[2 * y + 1] = Math.asin(o[3 * y + 1]) / Math.PI + 0.5;
  const v = /* @__PURE__ */ new Map();
  function I(y, T, L, E) {
    if (E) {
      const C = v.get(y);
      if (C !== void 0) return C;
    }
    return o[3 * l + 0] = o[3 * y + 0], o[3 * l + 1] = o[3 * y + 1], o[3 * l + 2] = o[3 * y + 2], p[2 * l + 0] = T, p[2 * l + 1] = L, E && v.set(y, l), l++;
  }
  for (let y = 0; y < i.length; y += 3) {
    const T = i[y + 0], L = i[y + 1], E = i[y + 2];
    let C = p[2 * T], Q = p[2 * L], M = p[2 * E];
    const Z = p[2 * T + 1], z = p[2 * L + 1], N = p[2 * E + 1];
    Q - C >= 0.5 && Z !== 1 && (Q -= 1), M - Q > 0.5 && (M -= 1), (C > 0.5 && C - M > 0.5 || C === 1 && N === 0) && (C -= 1), Q > 0.5 && Q - C > 0.5 && (Q -= 1), Z === 0 || Z === 1 ? (C = (Q + M) / 2, Z === Q ? p[2 * T] = C : i[y + 0] = I(T, C, Z, !1)) : z === 0 || z === 1 ? (Q = (C + M) / 2, z === C ? p[2 * L] = Q : i[y + 1] = I(L, Q, z, !1)) : (N === 0 || N === 1) && (M = (C + Q) / 2, N === C ? p[2 * E] = M : i[y + 2] = I(E, M, N, !1)), C !== p[2 * T] && Z !== 0 && Z !== 1 && (i[y + 0] = I(T, C, Z, !0)), Q !== p[2 * L] && z !== 0 && z !== 1 && (i[y + 1] = I(L, Q, z, !0)), M !== p[2 * E] && N !== 0 && N !== 1 && (i[y + 2] = I(E, M, N, !0));
  }
  return { vertices: o, triangles: i, uv: p };
}
const wa = [
  Int8Array,
  Uint8Array,
  Uint8ClampedArray,
  Int16Array,
  Uint16Array,
  Int32Array,
  Uint32Array,
  Float32Array,
  Float64Array
], Tr = 1, Mt = 8;
class cs {
  /**
   * Creates an index from raw `ArrayBuffer` data.
   * @param {ArrayBuffer} data
   */
  static from(e) {
    if (!(e instanceof ArrayBuffer))
      throw new Error("Data must be an instance of ArrayBuffer.");
    const [t, n] = new Uint8Array(e, 0, 2);
    if (t !== 219)
      throw new Error("Data does not appear to be in a KDBush format.");
    const r = n >> 4;
    if (r !== Tr)
      throw new Error(`Got v${r} data when expected v${Tr}.`);
    const s = wa[n & 15];
    if (!s)
      throw new Error("Unrecognized array type.");
    const [o] = new Uint16Array(e, 2, 1), [i] = new Uint32Array(e, 4, 1);
    return new cs(i, o, s, e);
  }
  /**
   * Creates an index that will hold a given number of items.
   * @param {number} numItems
   * @param {number} [nodeSize=64] Size of the KD-tree node (64 by default).
   * @param {TypedArrayConstructor} [ArrayType=Float64Array] The array type used for coordinates storage (`Float64Array` by default).
   * @param {ArrayBuffer} [data] (For internal use only)
   */
  constructor(e, t = 64, n = Float64Array, r) {
    if (isNaN(e) || e < 0) throw new Error(`Unpexpected numItems value: ${e}.`);
    this.numItems = +e, this.nodeSize = Math.min(Math.max(+t, 2), 65535), this.ArrayType = n, this.IndexArrayType = e < 65536 ? Uint16Array : Uint32Array;
    const s = wa.indexOf(this.ArrayType), o = e * 2 * this.ArrayType.BYTES_PER_ELEMENT, i = e * this.IndexArrayType.BYTES_PER_ELEMENT, l = (8 - i % 8) % 8;
    if (s < 0)
      throw new Error(`Unexpected typed array class: ${n}.`);
    r && r instanceof ArrayBuffer ? (this.data = r, this.ids = new this.IndexArrayType(this.data, Mt, e), this.coords = new this.ArrayType(this.data, Mt + i + l, e * 2), this._pos = e * 2, this._finished = !0) : (this.data = new ArrayBuffer(Mt + o + i + l), this.ids = new this.IndexArrayType(this.data, Mt, e), this.coords = new this.ArrayType(this.data, Mt + i + l, e * 2), this._pos = 0, this._finished = !1, new Uint8Array(this.data, 0, 2).set([219, (Tr << 4) + s]), new Uint16Array(this.data, 2, 1)[0] = t, new Uint32Array(this.data, 4, 1)[0] = e);
  }
  /**
   * Add a point to the index.
   * @param {number} x
   * @param {number} y
   * @returns {number} An incremental index associated with the added item (starting from `0`).
   */
  add(e, t) {
    const n = this._pos >> 1;
    return this.ids[n] = n, this.coords[this._pos++] = e, this.coords[this._pos++] = t, n;
  }
  /**
   * Perform indexing of the added points.
   */
  finish() {
    const e = this._pos >> 1;
    if (e !== this.numItems)
      throw new Error(`Added ${e} items when expected ${this.numItems}.`);
    return jr(this.ids, this.coords, this.nodeSize, 0, this.numItems - 1, 0), this._finished = !0, this;
  }
  /**
   * Search the index for items within a given bounding box.
   * @param {number} minX
   * @param {number} minY
   * @param {number} maxX
   * @param {number} maxY
   * @returns {number[]} An array of indices correponding to the found items.
   */
  range(e, t, n, r) {
    if (!this._finished) throw new Error("Data not yet indexed - call index.finish().");
    const { ids: s, coords: o, nodeSize: i } = this, l = [0, s.length - 1, 0], u = [];
    for (; l.length; ) {
      const c = l.pop() || 0, f = l.pop() || 0, h = l.pop() || 0;
      if (f - h <= i) {
        for (let y = h; y <= f; y++) {
          const T = o[2 * y], L = o[2 * y + 1];
          T >= e && T <= n && L >= t && L <= r && u.push(s[y]);
        }
        continue;
      }
      const p = h + f >> 1, v = o[2 * p], I = o[2 * p + 1];
      v >= e && v <= n && I >= t && I <= r && u.push(s[p]), (c === 0 ? e <= v : t <= I) && (l.push(h), l.push(p - 1), l.push(1 - c)), (c === 0 ? n >= v : r >= I) && (l.push(p + 1), l.push(f), l.push(1 - c));
    }
    return u;
  }
  /**
   * Search the index for items within a given radius.
   * @param {number} qx
   * @param {number} qy
   * @param {number} r Query radius.
   * @returns {number[]} An array of indices correponding to the found items.
   */
  within(e, t, n) {
    if (!this._finished) throw new Error("Data not yet indexed - call index.finish().");
    const { ids: r, coords: s, nodeSize: o } = this, i = [0, r.length - 1, 0], l = [], u = n * n;
    for (; i.length; ) {
      const c = i.pop() || 0, f = i.pop() || 0, h = i.pop() || 0;
      if (f - h <= o) {
        for (let y = h; y <= f; y++)
          Ia(s[2 * y], s[2 * y + 1], e, t) <= u && l.push(r[y]);
        continue;
      }
      const p = h + f >> 1, v = s[2 * p], I = s[2 * p + 1];
      Ia(v, I, e, t) <= u && l.push(r[p]), (c === 0 ? e - n <= v : t - n <= I) && (i.push(h), i.push(p - 1), i.push(1 - c)), (c === 0 ? e + n >= v : t + n >= I) && (i.push(p + 1), i.push(f), i.push(1 - c));
    }
    return l;
  }
}
function jr(a, e, t, n, r, s) {
  if (r - n <= t) return;
  const o = n + r >> 1;
  vo(a, e, o, n, r, s), jr(a, e, t, n, o - 1, 1 - s), jr(a, e, t, o + 1, r, 1 - s);
}
function vo(a, e, t, n, r, s) {
  for (; r > n; ) {
    if (r - n > 600) {
      const u = r - n + 1, c = t - n + 1, f = Math.log(u), h = 0.5 * Math.exp(2 * f / 3), p = 0.5 * Math.sqrt(f * h * (u - h) / u) * (c - u / 2 < 0 ? -1 : 1), v = Math.max(n, Math.floor(t - c * h / u + p)), I = Math.min(r, Math.floor(t + (u - c) * h / u + p));
      vo(a, e, t, v, I, s);
    }
    const o = e[2 * t + s];
    let i = n, l = r;
    for (Qt(a, e, n, t), e[2 * r + s] > o && Qt(a, e, n, r); i < l; ) {
      for (Qt(a, e, i, l), i++, l--; e[2 * i + s] < o; ) i++;
      for (; e[2 * l + s] > o; ) l--;
    }
    e[2 * n + s] === o ? Qt(a, e, n, l) : (l++, Qt(a, e, l, r)), l <= t && (n = l + 1), t <= l && (r = l - 1);
  }
}
function Qt(a, e, t, n) {
  Br(a, t, n), Br(e, 2 * t, 2 * n), Br(e, 2 * t + 1, 2 * n + 1);
}
function Br(a, e, t) {
  const n = a[e];
  a[e] = a[t], a[t] = n;
}
function Ia(a, e, t, n) {
  const r = a - t, s = e - n;
  return r * r + s * s;
}
class Lc {
  constructor(e = [], t = Mc) {
    if (this.data = e, this.length = this.data.length, this.compare = t, this.length > 0)
      for (let n = (this.length >> 1) - 1; n >= 0; n--) this._down(n);
  }
  push(e) {
    this.data.push(e), this.length++, this._up(this.length - 1);
  }
  pop() {
    if (this.length === 0) return;
    const e = this.data[0], t = this.data.pop();
    return this.length--, this.length > 0 && (this.data[0] = t, this._down(0)), e;
  }
  peek() {
    return this.data[0];
  }
  _up(e) {
    const { data: t, compare: n } = this, r = t[e];
    for (; e > 0; ) {
      const s = e - 1 >> 1, o = t[s];
      if (n(r, o) >= 0) break;
      t[e] = o, e = s;
    }
    t[e] = r;
  }
  _down(e) {
    const { data: t, compare: n } = this, r = this.length >> 1, s = t[e];
    for (; e < r; ) {
      let o = (e << 1) + 1, i = t[o];
      const l = o + 1;
      if (l < this.length && n(t[l], i) < 0 && (o = l, i = t[l]), n(i, s) >= 0) break;
      t[e] = i, e = o;
    }
    t[e] = s;
  }
}
function Mc(a, e) {
  return a < e ? -1 : a > e ? 1 : 0;
}
const Qc = 6371, Re = Math.PI / 180;
function Dc(a, e, t, n = 1 / 0, r = 1 / 0, s) {
  let o = 1;
  const i = [];
  n === void 0 && (n = 1 / 0), r !== void 0 && (o = lt(r / Qc));
  const l = new Lc([], Pc);
  let u = {
    left: 0,
    // left index in the kd-tree array
    right: a.ids.length - 1,
    // right index
    axis: 0,
    // 0 for longitude axis and 1 for latitude axis
    minLng: -180,
    // bounding box of the node
    minLat: -90,
    maxLng: 180,
    maxLat: 90
  };
  const c = Math.cos(t * Re);
  for (; u; ) {
    const f = u.right, h = u.left;
    if (f - h <= a.nodeSize)
      for (let p = h; p <= f; p++) {
        const v = a.ids[p];
        {
          const I = Ca(e, t, a.coords[2 * p], a.coords[2 * p + 1], c);
          l.push({ id: v, dist: I });
        }
      }
    else {
      const p = h + f >> 1, v = a.coords[2 * p], I = a.coords[2 * p + 1], y = a.ids[p];
      {
        const C = Ca(e, t, v, I, c);
        l.push({ id: y, dist: C });
      }
      const T = (u.axis + 1) % 2, L = {
        left: h,
        right: p - 1,
        axis: T,
        minLng: u.minLng,
        minLat: u.minLat,
        maxLng: u.axis === 0 ? v : u.maxLng,
        maxLat: u.axis === 1 ? I : u.maxLat,
        dist: 0
      }, E = {
        left: p + 1,
        right: f,
        axis: T,
        minLng: u.axis === 0 ? v : u.minLng,
        minLat: u.axis === 1 ? I : u.minLat,
        maxLng: u.maxLng,
        maxLat: u.maxLat,
        dist: 0
      };
      L.dist = _a(e, t, c, L), E.dist = _a(e, t, c, E), l.push(L), l.push(E);
    }
    for (; l.length && l.peek().id != null; ) {
      const p = l.pop();
      if (p.dist > o || (i.push(p.id), i.length === n)) return i;
    }
    u = l.pop();
  }
  return i;
}
function _a(a, e, t, n) {
  const r = n.minLng, s = n.maxLng, o = n.minLat, i = n.maxLat;
  if (a >= r && a <= s)
    return e < o ? lt((e - o) * Re) : e > i ? lt((e - i) * Re) : 0;
  const l = Math.min(lt((a - r) * Re), lt((a - s) * Re)), u = Oc(e, l);
  return u > o && u < i ? pn(l, t, e, u) : Math.min(
    pn(l, t, e, o),
    pn(l, t, e, i)
  );
}
function Pc(a, e) {
  return a.dist - e.dist;
}
function lt(a) {
  const e = Math.sin(a / 2);
  return e * e;
}
function pn(a, e, t, n) {
  return e * Math.cos(n * Re) * a + lt((t - n) * Re);
}
function Ca(a, e, t, n, r) {
  const s = lt((a - t) * Re);
  return pn(s, r, e, n);
}
function Oc(a, e) {
  const t = 1 - 2 * e;
  return t <= 0 ? a > 0 ? 90 : -90 : Math.atan(Math.tan(a * Re) / t) / Re;
}
const Ea = globalThis, ka = globalThis.process || {};
function Nc(a) {
  if (typeof window < "u" && window.process?.type === "renderer" || typeof process < "u" && process.versions?.electron)
    return !0;
  const t = typeof navigator < "u" && navigator.userAgent;
  return !!(t && t.indexOf("Electron") >= 0);
}
function us() {
  return !// @ts-expect-error
  (typeof process == "object" && String(process) === "[object process]" && !process?.browser) || Nc();
}
const xo = "4.1.0";
function Uc(a) {
  try {
    const e = window[a], t = "__storage_test__";
    return e.setItem(t, t), e.removeItem(t), e;
  } catch {
    return null;
  }
}
class Vc {
  constructor(e, t, n = "sessionStorage") {
    this.storage = Uc(n), this.id = e, this.config = t, this._loadConfiguration();
  }
  getConfiguration() {
    return this.config;
  }
  setConfiguration(e) {
    if (Object.assign(this.config, e), this.storage) {
      const t = JSON.stringify(this.config);
      this.storage.setItem(this.id, t);
    }
  }
  // Get config from persistent store, if available
  _loadConfiguration() {
    let e = {};
    if (this.storage) {
      const t = this.storage.getItem(this.id);
      e = t ? JSON.parse(t) : {};
    }
    return Object.assign(this.config, e), this;
  }
}
function Fc(a) {
  let e;
  return a < 10 ? e = `${a.toFixed(2)}ms` : a < 100 ? e = `${a.toFixed(1)}ms` : a < 1e3 ? e = `${a.toFixed(0)}ms` : e = `${(a / 1e3).toFixed(2)}s`, e;
}
function Rc(a, e = 8) {
  const t = Math.max(e - a.length, 0);
  return `${" ".repeat(t)}${a}`;
}
var Tn;
(function(a) {
  a[a.BLACK = 30] = "BLACK", a[a.RED = 31] = "RED", a[a.GREEN = 32] = "GREEN", a[a.YELLOW = 33] = "YELLOW", a[a.BLUE = 34] = "BLUE", a[a.MAGENTA = 35] = "MAGENTA", a[a.CYAN = 36] = "CYAN", a[a.WHITE = 37] = "WHITE", a[a.BRIGHT_BLACK = 90] = "BRIGHT_BLACK", a[a.BRIGHT_RED = 91] = "BRIGHT_RED", a[a.BRIGHT_GREEN = 92] = "BRIGHT_GREEN", a[a.BRIGHT_YELLOW = 93] = "BRIGHT_YELLOW", a[a.BRIGHT_BLUE = 94] = "BRIGHT_BLUE", a[a.BRIGHT_MAGENTA = 95] = "BRIGHT_MAGENTA", a[a.BRIGHT_CYAN = 96] = "BRIGHT_CYAN", a[a.BRIGHT_WHITE = 97] = "BRIGHT_WHITE";
})(Tn || (Tn = {}));
const Wc = 10;
function Ta(a) {
  return typeof a != "string" ? a : (a = a.toUpperCase(), Tn[a] || Tn.WHITE);
}
function qc(a, e, t) {
  return !us && typeof a == "string" && (e && (a = `\x1B[${Ta(e)}m${a}\x1B[39m`), t && (a = `\x1B[${Ta(t) + Wc}m${a}\x1B[49m`)), a;
}
function Gc(a, e = ["constructor"]) {
  const t = Object.getPrototypeOf(a), n = Object.getOwnPropertyNames(t), r = a;
  for (const s of n) {
    const o = r[s];
    typeof o == "function" && (e.find((i) => s === i) || (r[s] = o.bind(a)));
  }
}
function fs(a, e) {
  if (!a)
    throw new Error("Assertion failed");
}
function pt() {
  let a;
  if (us() && Ea.performance)
    a = Ea?.performance?.now?.();
  else if ("hrtime" in ka) {
    const e = ka?.hrtime?.();
    a = e[0] * 1e3 + e[1] / 1e6;
  } else
    a = Date.now();
  return a;
}
const mt = {
  debug: us() && console.debug || console.log,
  log: console.log,
  info: console.info,
  warn: console.warn,
  error: console.error
}, Jc = {
  enabled: !0,
  level: 0
};
function gt() {
}
const Ba = {}, Sa = { once: !0 };
class wo {
  constructor({ id: e } = { id: "" }) {
    this.VERSION = xo, this._startTs = pt(), this._deltaTs = pt(), this.userData = {}, this.LOG_THROTTLE_TIMEOUT = 0, this.id = e, this.userData = {}, this._storage = new Vc(`__probe-${this.id}__`, Jc), this.timeStamp(`${this.id} started`), Gc(this), Object.seal(this);
  }
  set level(e) {
    this.setLevel(e);
  }
  get level() {
    return this.getLevel();
  }
  isEnabled() {
    return this._storage.config.enabled;
  }
  getLevel() {
    return this._storage.config.level;
  }
  /** @return milliseconds, with fractions */
  getTotal() {
    return Number((pt() - this._startTs).toPrecision(10));
  }
  /** @return milliseconds, with fractions */
  getDelta() {
    return Number((pt() - this._deltaTs).toPrecision(10));
  }
  /** @deprecated use logLevel */
  set priority(e) {
    this.level = e;
  }
  /** @deprecated use logLevel */
  get priority() {
    return this.level;
  }
  /** @deprecated use logLevel */
  getPriority() {
    return this.level;
  }
  // Configure
  enable(e = !0) {
    return this._storage.setConfiguration({ enabled: e }), this;
  }
  setLevel(e) {
    return this._storage.setConfiguration({ level: e }), this;
  }
  /** return the current status of the setting */
  get(e) {
    return this._storage.config[e];
  }
  // update the status of the setting
  set(e, t) {
    this._storage.setConfiguration({ [e]: t });
  }
  /** Logs the current settings as a table */
  settings() {
    console.table ? console.table(this._storage.config) : console.log(this._storage.config);
  }
  // Unconditional logging
  assert(e, t) {
    if (!e)
      throw new Error(t || "Assertion failed");
  }
  warn(e) {
    return this._getLogFunction(0, e, mt.warn, arguments, Sa);
  }
  error(e) {
    return this._getLogFunction(0, e, mt.error, arguments);
  }
  /** Print a deprecation warning */
  deprecated(e, t) {
    return this.warn(`\`${e}\` is deprecated and will be removed in a later version. Use \`${t}\` instead`);
  }
  /** Print a removal warning */
  removed(e, t) {
    return this.error(`\`${e}\` has been removed. Use \`${t}\` instead`);
  }
  probe(e, t) {
    return this._getLogFunction(e, t, mt.log, arguments, {
      time: !0,
      once: !0
    });
  }
  log(e, t) {
    return this._getLogFunction(e, t, mt.debug, arguments);
  }
  info(e, t) {
    return this._getLogFunction(e, t, console.info, arguments);
  }
  once(e, t) {
    return this._getLogFunction(e, t, mt.debug || mt.info, arguments, Sa);
  }
  /** Logs an object as a table */
  table(e, t, n) {
    return t ? this._getLogFunction(e, t, console.table || gt, n && [n], {
      tag: Hc(t)
    }) : gt;
  }
  time(e, t) {
    return this._getLogFunction(e, t, console.time ? console.time : console.info);
  }
  timeEnd(e, t) {
    return this._getLogFunction(e, t, console.timeEnd ? console.timeEnd : console.info);
  }
  timeStamp(e, t) {
    return this._getLogFunction(e, t, console.timeStamp || gt);
  }
  group(e, t, n = { collapsed: !1 }) {
    const r = La({ logLevel: e, message: t, opts: n }), { collapsed: s } = n;
    return r.method = (s ? console.groupCollapsed : console.group) || console.info, this._getLogFunction(r);
  }
  groupCollapsed(e, t, n = {}) {
    return this.group(e, t, Object.assign({}, n, { collapsed: !0 }));
  }
  groupEnd(e) {
    return this._getLogFunction(e, "", console.groupEnd || gt);
  }
  // EXPERIMENTAL
  withGroup(e, t, n) {
    this.group(e, t)();
    try {
      n();
    } finally {
      this.groupEnd(e)();
    }
  }
  trace() {
    console.trace && console.trace();
  }
  // PRIVATE METHODS
  /** Deduces log level from a variety of arguments */
  _shouldLog(e) {
    return this.isEnabled() && this.getLevel() >= Io(e);
  }
  _getLogFunction(e, t, n, r, s) {
    if (this._shouldLog(e)) {
      s = La({ logLevel: e, message: t, args: r, opts: s }), n = n || s.method, fs(n), s.total = this.getTotal(), s.delta = this.getDelta(), this._deltaTs = pt();
      const o = s.tag || s.message;
      if (s.once && o)
        if (!Ba[o])
          Ba[o] = pt();
        else
          return gt;
      return t = zc(this.id, s.message, s), n.bind(console, t, ...s.args);
    }
    return gt;
  }
}
wo.VERSION = xo;
function Io(a) {
  if (!a)
    return 0;
  let e;
  switch (typeof a) {
    case "number":
      e = a;
      break;
    case "object":
      e = a.logLevel || a.priority || 0;
      break;
    default:
      return 0;
  }
  return fs(Number.isFinite(e) && e >= 0), e;
}
function La(a) {
  const { logLevel: e, message: t } = a;
  a.logLevel = Io(e);
  const n = a.args ? Array.from(a.args) : [];
  for (; n.length && n.shift() !== t; )
    ;
  switch (typeof e) {
    case "string":
    case "function":
      t !== void 0 && n.unshift(t), a.message = e;
      break;
    case "object":
      Object.assign(a, e);
      break;
  }
  typeof a.message == "function" && (a.message = a.message());
  const r = typeof a.message;
  return fs(r === "string" || r === "object"), Object.assign(a, { args: n }, a.opts);
}
function zc(a, e, t) {
  if (typeof e == "string") {
    const n = t.time ? Rc(Fc(t.total)) : "";
    e = t.time ? `${a}: ${n}  ${e}` : `${a}: ${e}`, e = qc(e, t.color, t.background);
  }
  return e;
}
function Hc(a) {
  for (const e in a)
    for (const t in a[e])
      return t || "untitled";
  return "empty";
}
const te = new wo({ id: "luma.gl" }), Sr = {};
function _o(a = "id") {
  Sr[a] = Sr[a] || 1;
  const e = Sr[a]++;
  return `${a}-${e}`;
}
class Ce {
  /** Default properties for resource */
  static defaultProps = {
    id: "undefined",
    handle: void 0,
    userData: void 0
  };
  toString() {
    return `${this[Symbol.toStringTag] || this.constructor.name}:"${this.id}"`;
  }
  /** props.id, for debugging. */
  id;
  props;
  userData = {};
  _device;
  /** Whether this resource has been destroyed */
  destroyed = !1;
  /** For resources that allocate GPU memory */
  allocatedBytes = 0;
  /** Attached resources will be destroyed when this resource is destroyed. Tracks auto-created "sub" resources. */
  _attachedResources = /* @__PURE__ */ new Set();
  /**
   * Create a new Resource. Called from Subclass
   */
  constructor(e, t, n) {
    if (!e)
      throw new Error("no device");
    this._device = e, this.props = Zc(t, n);
    const r = this.props.id !== "undefined" ? this.props.id : _o(this[Symbol.toStringTag]);
    this.props.id = r, this.id = r, this.userData = this.props.userData || {}, this.addStats();
  }
  /**
   * destroy can be called on any resource to release it before it is garbage collected.
   */
  destroy() {
    this.destroyResource();
  }
  /** @deprecated Use destroy() */
  delete() {
    return this.destroy(), this;
  }
  /**
   * Combines a map of user props and default props, only including props from defaultProps
   * @returns returns a map of overridden default props
   */
  getProps() {
    return this.props;
  }
  // ATTACHED RESOURCES
  /**
   * Attaches a resource. Attached resources are auto destroyed when this resource is destroyed
   * Called automatically when sub resources are auto created but can be called by application
   */
  attachResource(e) {
    this._attachedResources.add(e);
  }
  /**
   * Detach an attached resource. The resource will no longer be auto-destroyed when this resource is destroyed.
   */
  detachResource(e) {
    this._attachedResources.delete(e);
  }
  /**
   * Destroys a resource (only if owned), and removes from the owned (auto-destroy) list for this resource.
   */
  destroyAttachedResource(e) {
    this._attachedResources.delete(e) && e.destroy();
  }
  /** Destroy all owned resources. Make sure the resources are no longer needed before calling. */
  destroyAttachedResources() {
    for (const e of Object.values(this._attachedResources))
      e.destroy();
    this._attachedResources = /* @__PURE__ */ new Set();
  }
  // PROTECTED METHODS
  /** Perform all destroy steps. Can be called by derived resources when overriding destroy() */
  destroyResource() {
    this.destroyAttachedResources(), this.removeStats(), this.destroyed = !0;
  }
  /** Called by .destroy() to track object destruction. Subclass must call if overriding destroy() */
  removeStats() {
    const e = this._device.statsManager.getStats("Resource Counts"), t = this[Symbol.toStringTag];
    e.get(`${t}s Active`).decrementCount();
  }
  /** Called by subclass to track memory allocations */
  trackAllocatedMemory(e, t = this[Symbol.toStringTag]) {
    const n = this._device.statsManager.getStats("Resource Counts");
    n.get("GPU Memory").addCount(e), n.get(`${t} Memory`).addCount(e), this.allocatedBytes = e;
  }
  /** Called by subclass to track memory deallocations */
  trackDeallocatedMemory(e = this[Symbol.toStringTag]) {
    const t = this._device.statsManager.getStats("Resource Counts");
    t.get("GPU Memory").subtractCount(this.allocatedBytes), t.get(`${e} Memory`).subtractCount(this.allocatedBytes), this.allocatedBytes = 0;
  }
  /** Called by resource constructor to track object creation */
  addStats() {
    const e = this._device.statsManager.getStats("Resource Counts"), t = this[Symbol.toStringTag];
    e.get("Resources Created").incrementCount(), e.get(`${t}s Created`).incrementCount(), e.get(`${t}s Active`).incrementCount();
  }
}
function Zc(a, e) {
  const t = { ...e };
  for (const n in a)
    a[n] !== void 0 && (t[n] = a[n]);
  return t;
}
class Te extends Ce {
  /** Index buffer */
  static INDEX = 16;
  /** Vertex buffer */
  static VERTEX = 32;
  /** Uniform buffer */
  static UNIFORM = 64;
  /** Storage buffer */
  static STORAGE = 128;
  static INDIRECT = 256;
  static QUERY_RESOLVE = 512;
  // Usage Flags
  static MAP_READ = 1;
  static MAP_WRITE = 2;
  static COPY_SRC = 4;
  static COPY_DST = 8;
  get [Symbol.toStringTag]() {
    return "Buffer";
  }
  /** The usage with which this buffer was created */
  usage;
  /** For index buffers, whether indices are 16 or 32 bit */
  indexType;
  /** "Time" of last update, can be used to check if redraw is needed */
  updateTimestamp;
  constructor(e, t) {
    const n = { ...t };
    (t.usage || 0) & Te.INDEX && !t.indexType && (t.data instanceof Uint32Array ? n.indexType = "uint32" : t.data instanceof Uint16Array && (n.indexType = "uint16")), delete n.data, super(e, n, Te.defaultProps), this.usage = n.usage || 0, this.indexType = n.indexType, this.updateTimestamp = e.incrementTimestamp();
  }
  /**
   * Create a copy of this Buffer with new byteLength, with same props but of the specified size.
   * @note Does not copy contents of the cloned Buffer.
   */
  clone(e) {
    return this.device.createBuffer({ ...this.props, ...e });
  }
  // PROTECTED METHODS (INTENDED FOR USE BY OTHER FRAMEWORK CODE ONLY)
  /** Max amount of debug data saved. Two vec4's */
  static DEBUG_DATA_MAX_LENGTH = 32;
  /** A partial CPU-side copy of the data in this buffer, for debugging purposes */
  debugData = new ArrayBuffer(0);
  /** This doesn't handle partial non-zero offset updates correctly */
  _setDebugData(e, t, n) {
    const r = ArrayBuffer.isView(e) ? e.buffer : e, s = Math.min(e ? e.byteLength : n, Te.DEBUG_DATA_MAX_LENGTH);
    r === null ? this.debugData = new ArrayBuffer(s) : t === 0 && n === r.byteLength ? this.debugData = r.slice(0, s) : this.debugData = r.slice(t, t + s);
  }
  static defaultProps = {
    ...Ce.defaultProps,
    usage: 0,
    // Buffer.COPY_DST | Buffer.COPY_SRC
    byteLength: 0,
    byteOffset: 0,
    data: null,
    indexType: "uint16",
    onMapped: void 0
  };
}
function jc(a) {
  const [e, t, n] = hs[a], r = a.includes("norm"), s = !r && !a.startsWith("float"), o = a.startsWith("s");
  return {
    signedType: e,
    primitiveType: t,
    byteLength: n,
    normalized: r,
    integer: s,
    signed: o
  };
}
function $c(a) {
  const e = a;
  switch (e) {
    case "uint8":
      return "unorm8";
    case "sint8":
      return "snorm8";
    case "uint16":
      return "unorm16";
    case "sint16":
      return "snorm16";
    default:
      return e;
  }
}
function Xc(a, e) {
  switch (e) {
    case 1:
      return a;
    // Pad upwards to even multiple of 2
    case 2:
      return a + a % 2;
    // Pad upwards to even multiple of 2
    default:
      return a + (4 - a % 4) % 4;
  }
}
function Kc(a) {
  const e = ArrayBuffer.isView(a) ? a.constructor : a;
  if (e === Uint8ClampedArray)
    return "uint8";
  const t = Object.values(hs).find((n) => e === n[4]);
  if (!t)
    throw new Error(e.name);
  return t[0];
}
function Yc(a) {
  const [, , , , e] = hs[a];
  return e;
}
const hs = {
  uint8: ["uint8", "u32", 1, !1, Uint8Array],
  sint8: ["sint8", "i32", 1, !1, Int8Array],
  unorm8: ["uint8", "f32", 1, !0, Uint8Array],
  snorm8: ["sint8", "f32", 1, !0, Int8Array],
  uint16: ["uint16", "u32", 2, !1, Uint16Array],
  sint16: ["sint16", "i32", 2, !1, Int16Array],
  unorm16: ["uint16", "u32", 2, !0, Uint16Array],
  snorm16: ["sint16", "i32", 2, !0, Int16Array],
  float16: ["float16", "f16", 2, !1, Uint16Array],
  float32: ["float32", "f32", 4, !1, Float32Array],
  uint32: ["uint32", "u32", 4, !1, Uint32Array],
  sint32: ["sint32", "i32", 4, !1, Int32Array]
};
function Co(a) {
  let e;
  a.endsWith("-webgl") && (a.replace("-webgl", ""), e = !0);
  const [t, n] = a.split("x"), r = t, s = n ? parseInt(n) : 1, o = jc(r), i = {
    type: r,
    components: s,
    byteLength: o.byteLength * s,
    integer: o.integer,
    signed: o.signed,
    normalized: o.normalized
  };
  return e && (i.webglOnly = !0), i;
}
function eu(a, e, t) {
  const n = t ? $c(a) : a;
  switch (n) {
    // TODO - Special cases for WebGL (not supported on WebGPU), overrides the check below
    case "unorm8":
      return e === 1 ? "unorm8" : e === 3 ? "unorm8x3-webgl" : `${n}x${e}`;
    case "snorm8":
    case "uint8":
    case "sint8":
    // WebGPU 8 bit formats must be aligned to 16 bit boundaries');
    // fall through
    case "uint16":
    case "sint16":
    case "unorm16":
    case "snorm16":
    case "float16":
      if (e === 1 || e === 3)
        throw new Error(`size: ${e}`);
      return `${n}x${e}`;
    default:
      return e === 1 ? n : `${n}x${e}`;
  }
}
function tu(a, e, t) {
  if (!e || e > 4)
    throw new Error(`size ${e}`);
  const n = e, r = Kc(a);
  return eu(r, n, t);
}
function nu(a) {
  let e;
  switch (a.primitiveType) {
    case "f32":
      e = "float32";
      break;
    case "i32":
      e = "sint32";
      break;
    case "u32":
      e = "uint32";
      break;
    case "f16":
      return a.components <= 2 ? "float16x2" : "float16x4";
  }
  return a.components === 1 ? e : `${e}x${a.components}`;
}
class It extends Ce {
  static defaultProps = {
    ...Ce.defaultProps,
    type: "color-sampler",
    addressModeU: "clamp-to-edge",
    addressModeV: "clamp-to-edge",
    addressModeW: "clamp-to-edge",
    magFilter: "nearest",
    minFilter: "nearest",
    mipmapFilter: "none",
    lodMinClamp: 0,
    lodMaxClamp: 32,
    // Per WebGPU spec
    compare: "less-equal",
    maxAnisotropy: 1
  };
  get [Symbol.toStringTag]() {
    return "Sampler";
  }
  constructor(e, t) {
    t = It.normalizeProps(e, t), super(e, t, It.defaultProps);
  }
  static normalizeProps(e, t) {
    return t;
  }
}
const ru = {
  "1d": "1d",
  "2d": "2d",
  "2d-array": "2d",
  cube: "2d",
  "cube-array": "2d",
  "3d": "3d"
};
class Ue extends Ce {
  /** The texture can be bound for use as a sampled texture in a shader */
  static SAMPLE = 4;
  /** The texture can be bound for use as a storage texture in a shader */
  static STORAGE = 8;
  /** The texture can be used as a color or depth/stencil attachment in a render pass */
  static RENDER = 16;
  /** The texture can be used as the source of a copy operation */
  static COPY_SRC = 1;
  /** he texture can be used as the destination of a copy or write operation */
  static COPY_DST = 2;
  /** @deprecated Use Texture.SAMPLE */
  static TEXTURE = 4;
  /** @deprecated Use Texture.RENDER */
  static RENDER_ATTACHMENT = 16;
  /** dimension of this texture */
  dimension;
  /** base dimension of this texture */
  baseDimension;
  /** format of this texture */
  format;
  /** width in pixels of this texture */
  width;
  /** height in pixels of this texture */
  height;
  /** depth of this texture */
  depth;
  /** mip levels in this texture */
  mipLevels;
  /** "Time" of last update. Monotonically increasing timestamp. TODO move to AsyncTexture? */
  updateTimestamp;
  get [Symbol.toStringTag]() {
    return "Texture";
  }
  toString() {
    return `Texture(${this.id},${this.format},${this.width}x${this.height})`;
  }
  /** Do not use directly. Create with device.createTexture() */
  constructor(e, t) {
    if (t = Ue.normalizeProps(e, t), super(e, t, Ue.defaultProps), this.dimension = this.props.dimension, this.baseDimension = ru[this.dimension], this.format = this.props.format, this.width = this.props.width, this.height = this.props.height, this.depth = this.props.depth, this.mipLevels = this.props.mipLevels, this.props.width === void 0 || this.props.height === void 0)
      if (e.isExternalImage(t.data)) {
        const n = e.getExternalImageSize(t.data);
        this.width = n?.width || 1, this.height = n?.height || 1;
      } else
        this.width = 1, this.height = 1, (this.props.width === void 0 || this.props.height === void 0) && te.warn(`${this} created with undefined width or height. This is deprecated. Use AsyncTexture instead.`)();
    this.updateTimestamp = e.incrementTimestamp();
  }
  /** Set sampler props associated with this texture */
  setSampler(e) {
    this.sampler = e instanceof It ? e : this.device.createSampler(e);
  }
  /**
   * Create a new texture with the same parameters and optionally a different size
   * @note Textures are immutable and cannot be resized after creation, but we can create a similar texture with the same parameters but a new size.
   * @note Does not copy contents of the texture
   */
  clone(e) {
    return this.device.createTexture({ ...this.props, ...e });
  }
  /** Ensure we have integer coordinates */
  static normalizeProps(e, t) {
    const n = { ...t }, { width: r, height: s } = n;
    return typeof r == "number" && (n.width = Math.max(1, Math.ceil(r))), typeof s == "number" && (n.height = Math.max(1, Math.ceil(s))), n;
  }
  // HELPERS
  /** Initialize texture with supplied props */
  // eslint-disable-next-line max-statements
  _initializeData(e) {
    this.device.isExternalImage(e) ? this.copyExternalImage({
      image: e,
      width: this.width,
      height: this.height,
      depth: this.depth,
      mipLevel: 0,
      x: 0,
      y: 0,
      z: 0,
      aspect: "all",
      colorSpace: "srgb",
      premultipliedAlpha: !1,
      flipY: !1
    }) : e && this.copyImageData({
      data: e,
      // width: this.width,
      // height: this.height,
      // depth: this.depth,
      mipLevel: 0,
      x: 0,
      y: 0,
      z: 0,
      aspect: "all"
    });
  }
  _normalizeCopyImageDataOptions(e) {
    const { width: t, height: n, depth: r } = this, s = { ...Ue.defaultCopyDataOptions, width: t, height: n, depth: r, ...e }, o = this.device.getTextureFormatInfo(this.format);
    if (!e.bytesPerRow && !o.bytesPerPixel)
      throw new Error(`bytesPerRow must be provided for texture format ${this.format}`);
    return s.bytesPerRow = e.bytesPerRow || t * (o.bytesPerPixel || 4), s.rowsPerImage = e.rowsPerImage || n, s;
  }
  _normalizeCopyExternalImageOptions(e) {
    const t = this.device.getExternalImageSize(e.image), n = { ...Ue.defaultCopyExternalImageOptions, ...t, ...e };
    return n.width = Math.min(n.width, this.width - n.x), n.height = Math.min(n.height, this.height - n.y), n;
  }
  /** Default options */
  static defaultProps = {
    ...Ce.defaultProps,
    data: null,
    dimension: "2d",
    format: "rgba8unorm",
    usage: Ue.TEXTURE | Ue.RENDER_ATTACHMENT | Ue.COPY_DST,
    width: void 0,
    height: void 0,
    depth: 1,
    mipLevels: 1,
    samples: void 0,
    sampler: {},
    view: void 0
  };
  static defaultCopyDataOptions = {
    data: void 0,
    byteOffset: 0,
    bytesPerRow: void 0,
    rowsPerImage: void 0,
    mipLevel: 0,
    x: 0,
    y: 0,
    z: 0,
    aspect: "all"
  };
  /** Default options */
  static defaultCopyExternalImageOptions = {
    image: void 0,
    sourceX: 0,
    sourceY: 0,
    width: void 0,
    height: void 0,
    depth: 1,
    mipLevel: 0,
    x: 0,
    y: 0,
    z: 0,
    aspect: "all",
    colorSpace: "srgb",
    premultipliedAlpha: !1,
    flipY: !1
  };
}
class ds extends Ce {
  get [Symbol.toStringTag]() {
    return "TextureView";
  }
  /** Should not be constructed directly. Use `texture.createView(props)` */
  constructor(e, t) {
    super(e, t, ds.defaultProps);
  }
  static defaultProps = {
    ...Ce.defaultProps,
    format: void 0,
    dimension: void 0,
    aspect: "all",
    baseMipLevel: 0,
    mipLevelCount: void 0,
    baseArrayLayer: 0,
    arrayLayerCount: void 0
  };
}
function su(a, e, t) {
  let n = "";
  const r = e.split(/\r?\n/), s = a.slice().sort((o, i) => o.lineNum - i.lineNum);
  switch (t?.showSourceCode || "no") {
    case "all":
      let o = 0;
      for (let i = 1; i <= r.length; i++)
        for (n += Eo(r[i - 1], i, t); s.length > o && s[o].lineNum === i; ) {
          const l = s[o++];
          n += Lr(l, r, l.lineNum, {
            ...t,
            inlineSource: !1
          });
        }
      for (; s.length > o; ) {
        const i = s[o++];
        n += Lr(i, [], 0, {
          ...t,
          inlineSource: !1
        });
      }
      return n;
    case "issues":
    case "no":
      for (const i of a)
        n += Lr(i, r, i.lineNum, {
          inlineSource: t?.showSourceCode !== "no"
        });
      return n;
  }
}
function Lr(a, e, t, n) {
  if (n?.inlineSource) {
    const s = au(e, t), o = a.linePos > 0 ? `${" ".repeat(a.linePos + 5)}^^^
` : "";
    return `
${s}${o}${a.type.toUpperCase()}: ${a.message}

`;
  }
  const r = a.type === "error" ? "red" : "#8B4000";
  return n?.html ? `<div class='luma-compiler-log-error' style="color:${r};"><b> ${a.type.toUpperCase()}: ${a.message}</b></div>` : `${a.type.toUpperCase()}: ${a.message}`;
}
function au(a, e, t) {
  let n = "";
  for (let r = e - 2; r <= e; r++) {
    const s = a[r - 1];
    s !== void 0 && (n += Eo(s, e, t));
  }
  return n;
}
function Eo(a, e, t) {
  const n = t?.html ? ou(a) : a;
  return `${iu(String(e), 4)}: ${n}${t?.html ? "<br/>" : `
`}`;
}
function iu(a, e) {
  let t = "";
  for (let n = a.length; n < e; ++n)
    t += " ";
  return t + a;
}
function ou(a) {
  return a.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;");
}
class ps extends Ce {
  get [Symbol.toStringTag]() {
    return "Shader";
  }
  /** The stage of this shader */
  stage;
  /** The source code of this shader */
  source;
  /** The compilation status of the shader. 'pending' if compilation is asynchronous, and on production */
  compilationStatus = "pending";
  /** Create a new Shader instance */
  constructor(e, t) {
    t = { ...t, debugShaders: t.debugShaders || e.props.debugShaders || "errors" }, super(e, { id: lu(t), ...t }, ps.defaultProps), this.stage = this.props.stage, this.source = this.props.source;
  }
  /** Get compiler log synchronously (WebGL only) */
  getCompilationInfoSync() {
    return null;
  }
  /** Get translated shader source in host platform's native language (HLSL, GLSL, and even GLSL ES), if available */
  getTranslatedSource() {
    return null;
  }
  // PORTABLE HELPERS
  /** In browser logging of errors */
  async debugShader() {
    const e = this.props.debugShaders;
    switch (e) {
      case "never":
        return;
      case "errors":
        if (this.compilationStatus === "success")
          return;
        break;
    }
    const t = await this.getCompilationInfo();
    e === "warnings" && t?.length === 0 || this._displayShaderLog(t, this.id);
  }
  // PRIVATE
  /**
   * In-browser UI logging of errors
   * TODO - this HTML formatting code should not be in Device, should be pluggable
   */
  _displayShaderLog(e, t) {
    if (typeof document > "u" || !document?.createElement)
      return;
    const n = t, r = `${this.stage} shader "${n}"`;
    let s = su(e, this.source, { showSourceCode: "all", html: !0 });
    const o = this.getTranslatedSource();
    o && (s += `<br /><br /><h1>Translated Source</h1><br /><br /><code style="user-select:text;"><pre>${o}</pre></code>`);
    const i = document.createElement("Button");
    i.innerHTML = `
<h1>Compilation error in ${r}</h1><br /><br />
<code style="user-select:text;"><pre>
${s}
</pre></code>`, i.style.top = "10px", i.style.left = "10px", i.style.position = "absolute", i.style.zIndex = "9999", i.style.width = "100%", i.style.textAlign = "left", document.body.appendChild(i), document.getElementsByClassName("luma-compiler-log-error")[0]?.scrollIntoView(), i.onclick = () => {
      const u = `data:text/plain,${encodeURIComponent(this.source)}`;
      navigator.clipboard.writeText(u);
    };
  }
  static defaultProps = {
    ...Ce.defaultProps,
    language: "auto",
    stage: void 0,
    source: "",
    sourceMap: null,
    entryPoint: "main",
    debugShaders: void 0
  };
}
function lu(a) {
  return cu(a.source) || a.id || _o(`unnamed ${a.stage}-shader`);
}
function cu(a, e = "unnamed") {
  const n = /#define[\s*]SHADER_NAME[\s*]([A-Za-z0-9_-]+)[\s*]/.exec(a);
  return n ? n[1] : e;
}
class wt extends Ce {
  get [Symbol.toStringTag]() {
    return "RenderPipeline";
  }
  /** The merged layout */
  shaderLayout;
  /** Buffer map describing buffer interleaving etc */
  bufferLayout;
  /** The linking status of the pipeline. 'pending' if linking is asynchronous, and on production */
  linkStatus = "pending";
  /** The hash of the pipeline */
  hash = "";
  constructor(e, t) {
    super(e, t, wt.defaultProps), this.shaderLayout = this.props.shaderLayout, this.bufferLayout = this.props.bufferLayout || [];
  }
  static defaultProps = {
    ...Ce.defaultProps,
    vs: null,
    vertexEntryPoint: "vertexMain",
    vsConstants: {},
    fs: null,
    fragmentEntryPoint: "fragmentMain",
    fsConstants: {},
    shaderLayout: null,
    bufferLayout: [],
    topology: "triangle-list",
    colorAttachmentFormats: void 0,
    depthStencilAttachmentFormat: void 0,
    parameters: {},
    bindings: {},
    uniforms: {}
  };
}
class Bn extends Ce {
  get [Symbol.toStringTag]() {
    return "ComputePipeline";
  }
  hash = "";
  /** The merged shader layout */
  shaderLayout;
  constructor(e, t) {
    super(e, t, Bn.defaultProps), this.shaderLayout = t.shaderLayout;
  }
  static defaultProps = {
    ...Ce.defaultProps,
    shader: void 0,
    entryPoint: void 0,
    constants: {},
    shaderLayout: void 0
  };
}
function uu(a) {
  return pu[a];
}
function fu(a) {
  const [e, t] = du[a], n = e === "i32" || e === "u32", r = e !== "u32", s = hu[e] * t;
  return {
    primitiveType: e,
    components: t,
    byteLength: s,
    integer: n,
    signed: r
  };
}
const hu = {
  f32: 4,
  f16: 2,
  i32: 4,
  u32: 4
  // 'bool-webgl': 4,
}, du = {
  f32: ["f32", 1],
  "vec2<f32>": ["f32", 2],
  "vec3<f32>": ["f32", 3],
  "vec4<f32>": ["f32", 4],
  f16: ["f16", 1],
  "vec2<f16>": ["f16", 2],
  "vec3<f16>": ["f16", 3],
  "vec4<f16>": ["f16", 4],
  i32: ["i32", 1],
  "vec2<i32>": ["i32", 2],
  "vec3<i32>": ["i32", 3],
  "vec4<i32>": ["i32", 4],
  u32: ["u32", 1],
  "vec2<u32>": ["u32", 2],
  "vec3<u32>": ["u32", 3],
  "vec4<u32>": ["u32", 4]
}, pu = {
  f32: { type: "f32", components: 1 },
  f16: { type: "f16", components: 1 },
  i32: { type: "i32", components: 1 },
  u32: { type: "u32", components: 1 },
  // 'bool-webgl': {type: 'bool-webgl', components: 1},
  "vec2<f32>": { type: "f32", components: 2 },
  "vec3<f32>": { type: "f32", components: 3 },
  "vec4<f32>": { type: "f32", components: 4 },
  "vec2<f16>": { type: "f16", components: 2 },
  "vec3<f16>": { type: "f16", components: 3 },
  "vec4<f16>": { type: "f16", components: 4 },
  "vec2<i32>": { type: "i32", components: 2 },
  "vec3<i32>": { type: "i32", components: 3 },
  "vec4<i32>": { type: "i32", components: 4 },
  "vec2<u32>": { type: "u32", components: 2 },
  "vec3<u32>": { type: "u32", components: 3 },
  "vec4<u32>": { type: "u32", components: 4 },
  "mat2x2<f32>": { type: "f32", components: 4 },
  "mat2x3<f32>": { type: "f32", components: 6 },
  "mat2x4<f32>": { type: "f32", components: 8 },
  "mat3x2<f32>": { type: "f32", components: 6 },
  "mat3x3<f32>": { type: "f32", components: 9 },
  "mat3x4<f32>": { type: "f32", components: 12 },
  "mat4x2<f32>": { type: "f32", components: 8 },
  "mat4x3<f32>": { type: "f32", components: 12 },
  "mat4x4<f32>": { type: "f32", components: 16 },
  "mat2x2<f16>": { type: "f16", components: 4 },
  "mat2x3<f16>": { type: "f16", components: 6 },
  "mat2x4<f16>": { type: "f16", components: 8 },
  "mat3x2<f16>": { type: "f16", components: 6 },
  "mat3x3<f16>": { type: "f16", components: 9 },
  "mat3x4<f16>": { type: "f16", components: 12 },
  "mat4x2<f16>": { type: "f16", components: 8 },
  "mat4x3<f16>": { type: "f16", components: 12 },
  "mat4x4<f16>": { type: "f16", components: 16 },
  "mat2x2<i32>": { type: "i32", components: 4 },
  "mat2x3<i32>": { type: "i32", components: 6 },
  "mat2x4<i32>": { type: "i32", components: 8 },
  "mat3x2<i32>": { type: "i32", components: 6 },
  "mat3x3<i32>": { type: "i32", components: 9 },
  "mat3x4<i32>": { type: "i32", components: 12 },
  "mat4x2<i32>": { type: "i32", components: 8 },
  "mat4x3<i32>": { type: "i32", components: 12 },
  "mat4x4<i32>": { type: "i32", components: 16 },
  "mat2x2<u32>": { type: "u32", components: 4 },
  "mat2x3<u32>": { type: "u32", components: 6 },
  "mat2x4<u32>": { type: "u32", components: 8 },
  "mat3x2<u32>": { type: "u32", components: 6 },
  "mat3x3<u32>": { type: "u32", components: 9 },
  "mat3x4<u32>": { type: "u32", components: 12 },
  "mat4x2<u32>": { type: "u32", components: 8 },
  "mat4x3<u32>": { type: "u32", components: 12 },
  "mat4x4<u32>": { type: "u32", components: 16 }
};
function mu(a, e) {
  const t = {};
  for (const n of a.attributes) {
    const r = gu(a, e, n.name);
    r && (t[n.name] = r);
  }
  return t;
}
function gu(a, e, t) {
  const n = Au(a, t), r = yu(e, t);
  if (!n)
    return null;
  const s = fu(n.type), o = nu(s), i = r?.vertexFormat || o, l = Co(i);
  return {
    attributeName: r?.attributeName || n.name,
    bufferName: r?.bufferName || n.name,
    location: n.location,
    shaderType: n.type,
    primitiveType: s.primitiveType,
    shaderComponents: s.components,
    vertexFormat: i,
    bufferDataType: l.type,
    bufferComponents: l.components,
    // normalized is a property of the buffer's vertex format
    normalized: l.normalized,
    // integer is a property of the shader declaration
    integer: s.integer,
    stepMode: r?.stepMode || n.stepMode || "vertex",
    byteOffset: r?.byteOffset || 0,
    byteStride: r?.byteStride || 0
  };
}
function Au(a, e) {
  const t = a.attributes.find((n) => n.name === e);
  return t || te.warn(`shader layout attribute "${e}" not present in shader`), t || null;
}
function yu(a, e) {
  bu(a);
  let t = vu(a, e);
  return t || (t = xu(a, e), t) ? t : (te.warn(`layout for attribute "${e}" not present in buffer layout`), null);
}
function bu(a) {
  for (const e of a)
    (e.attributes && e.format || !e.attributes && !e.format) && te.warn(`BufferLayout ${name} must have either 'attributes' or 'format' field`);
}
function vu(a, e) {
  for (const t of a)
    if (t.format && t.name === e)
      return {
        attributeName: t.name,
        bufferName: e,
        stepMode: t.stepMode,
        vertexFormat: t.format,
        // If offset is needed, use `attributes` field.
        byteOffset: 0,
        byteStride: t.byteStride || 0
      };
  return null;
}
function xu(a, e) {
  for (const t of a) {
    let n = t.byteStride;
    if (typeof t.byteStride != "number")
      for (const s of t.attributes || []) {
        const o = Co(s.format);
        n += o.byteLength;
      }
    const r = t.attributes?.find((s) => s.attribute === e);
    if (r)
      return {
        attributeName: r.attribute,
        bufferName: t.name,
        stepMode: t.stepMode,
        vertexFormat: r.format,
        byteOffset: r.byteOffset,
        // @ts-ignore
        byteStride: n
      };
  }
  return null;
}
let sn;
function wu(a) {
  return (!sn || sn.byteLength < a) && (sn = new ArrayBuffer(a)), sn;
}
function Iu(a) {
  return ArrayBuffer.isView(a) && !(a instanceof DataView);
}
function Sn(a) {
  return Array.isArray(a) ? a.length === 0 || typeof a[0] == "number" : Iu(a);
}
const _u = 1024;
class Cu {
  layout = {};
  /** number of bytes needed for buffer allocation */
  byteLength;
  /** Create a new UniformBufferLayout given a map of attributes. */
  constructor(e, t = {}) {
    let n = 0;
    for (const [s, o] of Object.entries(e)) {
      const i = uu(o), { type: l, components: u } = i, c = u * (t?.[s] ?? 1);
      n = Xc(n, c);
      const f = n;
      n += c, this.layout[s] = { type: l, size: c, offset: f };
    }
    n += (4 - n % 4) % 4;
    const r = n * 4;
    this.byteLength = Math.max(r, _u);
  }
  /** Get the data for the complete buffer */
  getData(e) {
    const t = wu(this.byteLength), n = {
      i32: new Int32Array(t),
      u32: new Uint32Array(t),
      f32: new Float32Array(t),
      // TODO not implemented
      f16: new Uint16Array(t)
    };
    for (const [r, s] of Object.entries(e)) {
      const o = this.layout[r];
      if (!o) {
        te.warn(`Supplied uniform value ${r} not present in uniform block layout`)();
        continue;
      }
      const { type: i, size: l, offset: u } = o, c = n[i];
      if (l === 1) {
        if (typeof s != "number" && typeof s != "boolean") {
          te.warn(`Supplied value for single component uniform ${r} is not a number: ${s}`)();
          continue;
        }
        c[u] = Number(s);
      } else {
        if (!Sn(s)) {
          te.warn(`Supplied value for multi component / array uniform ${r} is not a numeric array: ${s}`)();
          continue;
        }
        c.set(s, u);
      }
    }
    return new Uint8Array(t, 0, this.byteLength);
  }
  /** Does this layout have a field with specified name */
  has(e) {
    return !!this.layout[e];
  }
  /** Get offset and size for a field with specified name */
  get(e) {
    return this.layout[e];
  }
}
function Eu(a, e, t = 16) {
  if (a !== e)
    return !1;
  const n = a, r = e;
  if (!Sn(n))
    return !1;
  if (Sn(r) && n.length === r.length) {
    for (let s = 0; s < n.length; ++s)
      if (r[s] !== n[s])
        return !1;
  }
  return !0;
}
function ku(a) {
  return Sn(a) ? a.slice() : a;
}
class Tu {
  name;
  uniforms = {};
  modifiedUniforms = {};
  modified = !0;
  bindingLayout = {};
  needsRedraw = "initialized";
  constructor(e) {
    if (this.name = e?.name || "unnamed", e?.name && e?.shaderLayout) {
      const t = e?.shaderLayout.bindings?.find((r) => r.type === "uniform" && r.name === e?.name);
      if (!t)
        throw new Error(e?.name);
      const n = t;
      for (const r of n.uniforms || [])
        this.bindingLayout[r.name] = r;
    }
  }
  /** Set a map of uniforms */
  setUniforms(e) {
    for (const [t, n] of Object.entries(e))
      this._setUniform(t, n), this.needsRedraw || this.setNeedsRedraw(`${this.name}.${t}=${n}`);
  }
  setNeedsRedraw(e) {
    this.needsRedraw = this.needsRedraw || e;
  }
  /** Returns all uniforms */
  getAllUniforms() {
    return this.modifiedUniforms = {}, this.needsRedraw = !1, this.uniforms || {};
  }
  /** Set a single uniform */
  _setUniform(e, t) {
    Eu(this.uniforms[e], t) || (this.uniforms[e] = ku(t), this.modifiedUniforms[e] = !0, this.modified = !0);
  }
}
class Bu {
  /** Stores the uniform values for each uniform block */
  uniformBlocks = /* @__PURE__ */ new Map();
  /** Can generate data for a uniform buffer for each block from data */
  uniformBufferLayouts = /* @__PURE__ */ new Map();
  /** Actual buffer for the blocks */
  uniformBuffers = /* @__PURE__ */ new Map();
  /**
   * Create a new UniformStore instance
   * @param blocks
   */
  constructor(e) {
    for (const [t, n] of Object.entries(e)) {
      const r = t, s = new Cu(n.uniformTypes ?? {}, n.uniformSizes ?? {});
      this.uniformBufferLayouts.set(r, s);
      const o = new Tu({ name: t });
      o.setUniforms(n.defaultUniforms || {}), this.uniformBlocks.set(r, o);
    }
  }
  /** Destroy any managed uniform buffers */
  destroy() {
    for (const e of this.uniformBuffers.values())
      e.destroy();
  }
  /**
   * Set uniforms
   * Makes all properties partial
   */
  setUniforms(e) {
    for (const [t, n] of Object.entries(e))
      this.uniformBlocks.get(t)?.setUniforms(n);
    this.updateUniformBuffers();
  }
  /** Get the required minimum length of the uniform buffer */
  getUniformBufferByteLength(e) {
    return this.uniformBufferLayouts.get(e)?.byteLength || 0;
  }
  /** Get formatted binary memory that can be uploaded to a buffer */
  getUniformBufferData(e) {
    const t = this.uniformBlocks.get(e)?.getAllUniforms() || {};
    return this.uniformBufferLayouts.get(e)?.getData(t);
  }
  /**
   * Creates an unmanaged uniform buffer (umnanaged means that application is responsible for destroying it)
   * The new buffer is initialized with current / supplied values
   */
  createUniformBuffer(e, t, n) {
    n && this.setUniforms(n);
    const r = this.getUniformBufferByteLength(t), s = e.createBuffer({
      usage: Te.UNIFORM | Te.COPY_DST,
      byteLength: r
    }), o = this.getUniformBufferData(t);
    return s.write(o), s;
  }
  /** Get the managed uniform buffer. "managed" resources are destroyed when the uniformStore is destroyed. */
  getManagedUniformBuffer(e, t) {
    if (!this.uniformBuffers.get(t)) {
      const n = this.getUniformBufferByteLength(t), r = e.createBuffer({
        usage: Te.UNIFORM | Te.COPY_DST,
        byteLength: n
      });
      this.uniformBuffers.set(t, r);
    }
    return this.uniformBuffers.get(t);
  }
  /** Updates all uniform buffers where values have changed */
  updateUniformBuffers() {
    let e = !1;
    for (const t of this.uniformBlocks.keys()) {
      const n = this.updateUniformBuffer(t);
      e ||= n;
    }
    return e && te.log(3, `UniformStore.updateUniformBuffers(): ${e}`)(), e;
  }
  /** Update one uniform buffer. Only updates if values have changed */
  updateUniformBuffer(e) {
    const t = this.uniformBlocks.get(e);
    let n = this.uniformBuffers.get(e), r = !1;
    if (n && t?.needsRedraw) {
      r ||= t.needsRedraw;
      const s = this.getUniformBufferData(e);
      n = this.uniformBuffers.get(e), n?.write(s);
      const o = this.uniformBlocks.get(e)?.getAllUniforms();
      te.log(4, `Writing to uniform buffer ${String(e)}`, s, o)();
    }
    return r;
  }
}
function ms(a, e) {
  if (!a)
    throw new Error(e || "shadertools: assertion failed.");
}
const Mr = {
  number: {
    type: "number",
    validate(a, e) {
      return Number.isFinite(a) && typeof e == "object" && (e.max === void 0 || a <= e.max) && (e.min === void 0 || a >= e.min);
    }
  },
  array: {
    type: "array",
    validate(a, e) {
      return Array.isArray(a) || ArrayBuffer.isView(a);
    }
  }
};
function Su(a) {
  const e = {};
  for (const [t, n] of Object.entries(a))
    e[t] = Lu(n);
  return e;
}
function Lu(a) {
  let e = Ma(a);
  if (e !== "object")
    return { value: a, ...Mr[e], type: e };
  if (typeof a == "object")
    return a ? a.type !== void 0 ? { ...a, ...Mr[a.type], type: a.type } : a.value === void 0 ? { type: "object", value: a } : (e = Ma(a.value), { ...a, ...Mr[e], type: e }) : { type: "object", value: null };
  throw new Error("props");
}
function Ma(a) {
  return Array.isArray(a) || ArrayBuffer.isView(a) ? "array" : typeof a;
}
const Mu = (
  /* glsl */
  `#ifdef MODULE_LOGDEPTH
  logdepth_adjustPosition(gl_Position);
#endif
`
), Qu = (
  /* glsl */
  `#ifdef MODULE_MATERIAL
  fragColor = material_filterColor(fragColor);
#endif

#ifdef MODULE_LIGHTING
  fragColor = lighting_filterColor(fragColor);
#endif

#ifdef MODULE_FOG
  fragColor = fog_filterColor(fragColor);
#endif

#ifdef MODULE_PICKING
  fragColor = picking_filterHighlightColor(fragColor);
  fragColor = picking_filterPickingColor(fragColor);
#endif

#ifdef MODULE_LOGDEPTH
  logdepth_setFragDepth();
#endif
`
), Du = {
  vertex: Mu,
  fragment: Qu
}, Qa = /void\s+main\s*\([^)]*\)\s*\{\n?/, Da = /}\n?[^{}]*$/, Qr = [], mn = "__LUMA_INJECT_DECLARATIONS__";
function Pu(a) {
  const e = { vertex: {}, fragment: {} };
  for (const t in a) {
    let n = a[t];
    const r = Ou(t);
    typeof n == "string" && (n = {
      order: 0,
      injection: n
    }), e[r][t] = n;
  }
  return e;
}
function Ou(a) {
  const e = a.slice(0, 2);
  switch (e) {
    case "vs":
      return "vertex";
    case "fs":
      return "fragment";
    default:
      throw new Error(e);
  }
}
function Ln(a, e, t, n = !1) {
  const r = e === "vertex";
  for (const s in t) {
    const o = t[s];
    o.sort((l, u) => l.order - u.order), Qr.length = o.length;
    for (let l = 0, u = o.length; l < u; ++l)
      Qr[l] = o[l].injection;
    const i = `${Qr.join(`
`)}
`;
    switch (s) {
      // declarations are injected before the main function
      case "vs:#decl":
        r && (a = a.replace(mn, i));
        break;
      // inject code at the beginning of the main function
      case "vs:#main-start":
        r && (a = a.replace(Qa, (l) => l + i));
        break;
      // inject code at the end of main function
      case "vs:#main-end":
        r && (a = a.replace(Da, (l) => i + l));
        break;
      // declarations are injected before the main function
      case "fs:#decl":
        r || (a = a.replace(mn, i));
        break;
      // inject code at the beginning of the main function
      case "fs:#main-start":
        r || (a = a.replace(Qa, (l) => l + i));
        break;
      // inject code at the end of main function
      case "fs:#main-end":
        r || (a = a.replace(Da, (l) => i + l));
        break;
      default:
        a = a.replace(s, (l) => l + i);
    }
  }
  return a = a.replace(mn, ""), n && (a = a.replace(/\}\s*$/, (s) => s + Du[e])), a;
}
function Mn(a) {
  a.map((e) => Nu(e));
}
function Nu(a) {
  if (a.instance)
    return;
  Mn(a.dependencies || []);
  const {
    propTypes: e = {},
    deprecations: t = [],
    // defines = {},
    inject: n = {}
  } = a, r = {
    normalizedInjections: Pu(n),
    parsedDeprecations: Uu(t)
  };
  e && (r.propValidators = Su(e)), a.instance = r;
  let s = {};
  e && (s = Object.entries(e).reduce((o, [i, l]) => {
    const u = l?.value;
    return u && (o[i] = u), o;
  }, {})), a.defaultUniforms = { ...a.defaultUniforms, ...s };
}
function ko(a, e, t) {
  a.deprecations?.forEach((n) => {
    n.regex?.test(e) && (n.deprecated ? t.deprecated(n.old, n.new)() : t.removed(n.old, n.new)());
  });
}
function Uu(a) {
  return a.forEach((e) => {
    switch (e.type) {
      case "function":
        e.regex = new RegExp(`\\b${e.old}\\(`);
        break;
      default:
        e.regex = new RegExp(`${e.type} ${e.old};`);
    }
  }), a;
}
function gs(a) {
  Mn(a);
  const e = {}, t = {};
  To({ modules: a, level: 0, moduleMap: e, moduleDepth: t });
  const n = Object.keys(t).sort((r, s) => t[s] - t[r]).map((r) => e[r]);
  return Mn(n), n;
}
function To(a) {
  const { modules: e, level: t, moduleMap: n, moduleDepth: r } = a;
  if (t >= 5)
    throw new Error("Possible loop in shader dependency graph");
  for (const s of e)
    n[s.name] = s, (r[s.name] === void 0 || r[s.name] < t) && (r[s.name] = t);
  for (const s of e)
    s.dependencies && To({ modules: s.dependencies, level: t + 1, moduleMap: n, moduleDepth: r });
}
function Vu(a) {
  switch (a?.gpu.toLowerCase()) {
    case "apple":
      return (
        /* glsl */
        `#define APPLE_GPU
// Apple optimizes away the calculation necessary for emulated fp64
#define LUMA_FP64_CODE_ELIMINATION_WORKAROUND 1
#define LUMA_FP32_TAN_PRECISION_WORKAROUND 1
// Intel GPU doesn't have full 32 bits precision in same cases, causes overflow
#define LUMA_FP64_HIGH_BITS_OVERFLOW_WORKAROUND 1
`
      );
    case "nvidia":
      return (
        /* glsl */
        `#define NVIDIA_GPU
// Nvidia optimizes away the calculation necessary for emulated fp64
#define LUMA_FP64_CODE_ELIMINATION_WORKAROUND 1
`
      );
    case "intel":
      return (
        /* glsl */
        `#define INTEL_GPU
// Intel optimizes away the calculation necessary for emulated fp64
#define LUMA_FP64_CODE_ELIMINATION_WORKAROUND 1
// Intel's built-in 'tan' function doesn't have acceptable precision
#define LUMA_FP32_TAN_PRECISION_WORKAROUND 1
// Intel GPU doesn't have full 32 bits precision in same cases, causes overflow
#define LUMA_FP64_HIGH_BITS_OVERFLOW_WORKAROUND 1
`
      );
    case "amd":
      return (
        /* glsl */
        `#define AMD_GPU
`
      );
    default:
      return (
        /* glsl */
        `#define DEFAULT_GPU
// Prevent driver from optimizing away the calculation necessary for emulated fp64
#define LUMA_FP64_CODE_ELIMINATION_WORKAROUND 1
// Headless Chrome's software shader 'tan' function doesn't have acceptable precision
#define LUMA_FP32_TAN_PRECISION_WORKAROUND 1
// If the GPU doesn't have full 32 bits precision, will causes overflow
#define LUMA_FP64_HIGH_BITS_OVERFLOW_WORKAROUND 1
`
      );
  }
}
function Fu(a, e) {
  if (Number(a.match(/^#version[ \t]+(\d+)/m)?.[1] || 100) !== 300)
    throw new Error("luma.gl v9 only supports GLSL 3.00 shader sources");
  switch (e) {
    case "vertex":
      return a = Pa(a, Ru), a;
    case "fragment":
      return a = Pa(a, Wu), a;
    default:
      throw new Error(e);
  }
}
const Bo = [
  // Fix poorly formatted version directive
  [/^(#version[ \t]+(100|300[ \t]+es))?[ \t]*\n/, `#version 300 es
`],
  // The individual `texture...()` functions were replaced with `texture()` overloads
  [/\btexture(2D|2DProj|Cube)Lod(EXT)?\(/g, "textureLod("],
  [/\btexture(2D|2DProj|Cube)(EXT)?\(/g, "texture("]
], Ru = [
  ...Bo,
  // `attribute` keyword replaced with `in`
  [$r("attribute"), "in $1"],
  // `varying` keyword replaced with `out`
  [$r("varying"), "out $1"]
], Wu = [
  ...Bo,
  // `varying` keyword replaced with `in`
  [$r("varying"), "in $1"]
];
function Pa(a, e) {
  for (const [t, n] of e)
    a = a.replace(t, n);
  return a;
}
function $r(a) {
  return new RegExp(`\\b${a}[ \\t]+(\\w+[ \\t]+\\w+(\\[\\w+\\])?;)`, "g");
}
function So(a, e) {
  let t = "";
  for (const n in a) {
    const r = a[n];
    if (t += `void ${r.signature} {
`, r.header && (t += `  ${r.header}`), e[n]) {
      const s = e[n];
      s.sort((o, i) => o.order - i.order);
      for (const o of s)
        t += `  ${o.injection}
`;
    }
    r.footer && (t += `  ${r.footer}`), t += `}
`;
  }
  return t;
}
function Lo(a) {
  const e = { vertex: {}, fragment: {} };
  for (const t of a) {
    let n, r;
    typeof t != "string" ? (n = t, r = n.hook) : (n = {}, r = t), r = r.trim();
    const [s, o] = r.split(":"), i = r.replace(/\(.+/, ""), l = Object.assign(n, { signature: o });
    switch (s) {
      case "vs":
        e.vertex[i] = l;
        break;
      case "fs":
        e.fragment[i] = l;
        break;
      default:
        throw new Error(s);
    }
  }
  return e;
}
function qu(a, e) {
  return {
    name: Gu(a, e),
    language: "glsl",
    version: Ju(a)
  };
}
function Gu(a, e = "unnamed") {
  const n = /#define[^\S\r\n]*SHADER_NAME[^\S\r\n]*([A-Za-z0-9_-]+)\s*/.exec(a);
  return n ? n[1] : e;
}
function Ju(a) {
  let e = 100;
  const t = a.match(/[^\s]+/g);
  if (t && t.length >= 2 && t[0] === "#version") {
    const n = parseInt(t[1], 10);
    Number.isFinite(n) && (e = n);
  }
  if (e !== 100 && e !== 300)
    throw new Error(`Invalid GLSL version ${e}`);
  return e;
}
const Mo = `

${mn}
`, zu = (
  /* glsl */
  `precision highp float;
`
);
function Hu(a) {
  const e = gs(a.modules || []);
  return {
    source: ju(a.platformInfo, {
      ...a,
      source: a.source,
      stage: "vertex",
      modules: e
    }),
    getUniforms: Qo(e)
  };
}
function Zu(a) {
  const { vs: e, fs: t } = a, n = gs(a.modules || []);
  return {
    vs: Oa(a.platformInfo, {
      ...a,
      source: e,
      stage: "vertex",
      modules: n
    }),
    fs: Oa(a.platformInfo, {
      ...a,
      // @ts-expect-error
      source: t,
      stage: "fragment",
      modules: n
    }),
    getUniforms: Qo(n)
  };
}
function ju(a, e) {
  const {
    // id,
    source: t,
    stage: n,
    modules: r,
    // defines = {},
    hookFunctions: s = [],
    inject: o = {},
    log: i
  } = e;
  ms(typeof t == "string", "shader source must be a string");
  const l = t;
  let u = "";
  const c = Lo(s), f = {}, h = {}, p = {};
  for (const I in o) {
    const y = typeof o[I] == "string" ? { injection: o[I], order: 0 } : o[I], T = /^(v|f)s:(#)?([\w-]+)$/.exec(I);
    if (T) {
      const L = T[2], E = T[3];
      L ? E === "decl" ? h[I] = [y] : p[I] = [y] : f[I] = [y];
    } else
      p[I] = [y];
  }
  const v = r;
  for (const I of v) {
    i && ko(I, l, i);
    const y = Do(I, "wgsl");
    u += y;
    const T = I.injections?.[n] || {};
    for (const L in T) {
      const E = /^(v|f)s:#([\w-]+)$/.exec(L);
      if (E) {
        const Q = E[2] === "decl" ? h : p;
        Q[L] = Q[L] || [], Q[L].push(T[L]);
      } else
        f[L] = f[L] || [], f[L].push(T[L]);
    }
  }
  return u += Mo, u = Ln(u, n, h), u += So(c[n], f), u += l, u = Ln(u, n, p), u;
}
function Oa(a, e) {
  const { source: t, stage: n, language: r = "glsl", modules: s, defines: o = {}, hookFunctions: i = [], inject: l = {}, prologue: u = !0, log: c } = e;
  ms(typeof t == "string", "shader source must be a string");
  const f = r === "glsl" ? qu(t).version : -1, h = a.shaderLanguageVersion, p = f === 100 ? "#version 100" : "#version 300 es", I = t.split(`
`).slice(1).join(`
`), y = {};
  s.forEach((M) => {
    Object.assign(y, M.defines);
  }), Object.assign(y, o);
  let T = "";
  switch (r) {
    case "wgsl":
      break;
    case "glsl":
      T = u ? `${p}

// ----- PROLOGUE -------------------------
${`#define SHADER_TYPE_${n.toUpperCase()}`}

${Vu(a)}
${n === "fragment" ? zu : ""}

// ----- APPLICATION DEFINES -------------------------

${$u(y)}

` : `${p}
`;
      break;
  }
  const L = Lo(i), E = {}, C = {}, Q = {};
  for (const M in l) {
    const Z = typeof l[M] == "string" ? { injection: l[M], order: 0 } : l[M], z = /^(v|f)s:(#)?([\w-]+)$/.exec(M);
    if (z) {
      const N = z[2], G = z[3];
      N ? G === "decl" ? C[M] = [Z] : Q[M] = [Z] : E[M] = [Z];
    } else
      Q[M] = [Z];
  }
  for (const M of s) {
    c && ko(M, I, c);
    const Z = Do(M, n);
    T += Z;
    const z = M.instance?.normalizedInjections[n] || {};
    for (const N in z) {
      const G = /^(v|f)s:#([\w-]+)$/.exec(N);
      if (G) {
        const q = G[2] === "decl" ? C : Q;
        q[N] = q[N] || [], q[N].push(z[N]);
      } else
        E[N] = E[N] || [], E[N].push(z[N]);
    }
  }
  return T += "// ----- MAIN SHADER SOURCE -------------------------", T += Mo, T = Ln(T, n, C), T += So(L[n], E), T += I, T = Ln(T, n, Q), r === "glsl" && f !== h && (T = Fu(T, n)), T.trim();
}
function Qo(a) {
  return function(t) {
    const n = {};
    for (const r of a) {
      const s = r.getUniforms?.(t, n);
      Object.assign(n, s);
    }
    return n;
  };
}
function $u(a = {}) {
  let e = "";
  for (const t in a) {
    const n = a[t];
    (n || Number.isFinite(n)) && (e += `#define ${t.toUpperCase()} ${a[t]}
`);
  }
  return e;
}
function Do(a, e) {
  let t;
  switch (e) {
    case "vertex":
      t = a.vs || "";
      break;
    case "fragment":
      t = a.fs || "";
      break;
    case "wgsl":
      t = a.source || "";
      break;
    default:
      ms(!1);
  }
  if (!a.name)
    throw new Error("Shader module must have a name");
  const n = a.name.toUpperCase().replace(/[^0-9a-z]/gi, "_");
  let r = `// ----- MODULE ${a.name} ---------------

`;
  return e !== "wgsl" && (r += `#define MODULE_${n}
`), r += `${t}
`, r;
}
const Xu = /^\s*\#\s*ifdef\s*([a-zA-Z_]+)\s*$/, Ku = /^\s*\#\s*endif\s*$/;
function Yu(a, e) {
  const t = a.split(`
`), n = [];
  let r = !0, s = null;
  for (const o of t) {
    const i = o.match(Xu), l = o.match(Ku);
    i ? (s = i[1], r = !!e?.defines?.[s]) : l ? r = !0 : r && n.push(o);
  }
  return n.join(`
`);
}
class bt {
  /** Default ShaderAssembler instance */
  static defaultShaderAssembler;
  /** Hook functions */
  _hookFunctions = [];
  /** Shader modules */
  _defaultModules = [];
  /**
   * A default shader assembler instance - the natural place to register default modules and hooks
   * @returns
   */
  static getDefaultShaderAssembler() {
    return bt.defaultShaderAssembler = bt.defaultShaderAssembler || new bt(), bt.defaultShaderAssembler;
  }
  /**
   * Add a default module that does not have to be provided with every call to assembleShaders()
   */
  addDefaultModule(e) {
    this._defaultModules.find((t) => t.name === (typeof e == "string" ? e : e.name)) || this._defaultModules.push(e);
  }
  /**
   * Remove a default module
   */
  removeDefaultModule(e) {
    const t = typeof e == "string" ? e : e.name;
    this._defaultModules = this._defaultModules.filter((n) => n.name !== t);
  }
  /**
   * Register a shader hook
   * @param hook
   * @param opts
   */
  addShaderHook(e, t) {
    t && (e = Object.assign(t, { hook: e })), this._hookFunctions.push(e);
  }
  /**
   * Assemble a WGSL unified shader
   * @param platformInfo
   * @param props
   * @returns
   */
  assembleWGSLShader(e) {
    const t = this._getModuleList(e.modules), n = this._hookFunctions, { source: r, getUniforms: s } = Hu({
      ...e,
      // @ts-expect-error
      source: e.source,
      modules: t,
      hookFunctions: n
    });
    return { source: e.platformInfo.shaderLanguage === "wgsl" ? Yu(r) : r, getUniforms: s, modules: t };
  }
  /**
   * Assemble a pair of shaders into a single shader program
   * @param platformInfo
   * @param props
   * @returns
   */
  assembleGLSLShaderPair(e) {
    const t = this._getModuleList(e.modules), n = this._hookFunctions;
    return { ...Zu({
      ...e,
      // @ts-expect-error
      vs: e.vs,
      // @ts-expect-error
      fs: e.fs,
      modules: t,
      hookFunctions: n
    }), modules: t };
  }
  /**
   * Dedupe and combine with default modules
   */
  _getModuleList(e = []) {
    const t = new Array(this._defaultModules.length + e.length), n = {};
    let r = 0;
    for (let s = 0, o = this._defaultModules.length; s < o; ++s) {
      const i = this._defaultModules[s], l = i.name;
      t[r++] = i, n[l] = !0;
    }
    for (let s = 0, o = e.length; s < o; ++s) {
      const i = e[s], l = i.name;
      n[l] || (t[r++] = i, n[l] = !0);
    }
    return t.length = r, Mn(t), t;
  }
}
const ef = (
  /* glsl */
  `out vec4 transform_output;
void main() {
  transform_output = vec4(0);
}`
), tf = `#version 300 es
${ef}`;
function nf(a) {
  const { input: e, inputChannels: t, output: n } = {};
  if (!e)
    return tf;
  if (!t)
    throw new Error("inputChannels");
  const r = rf(t), s = sf(e, t);
  return `#version 300 es
in ${r} ${e};
out vec4 ${n};
void main() {
  ${n} = ${s};
}`;
}
function rf(a) {
  switch (a) {
    case 1:
      return "float";
    case 2:
      return "vec2";
    case 3:
      return "vec3";
    case 4:
      return "vec4";
    default:
      throw new Error(`invalid channels: ${a}`);
  }
}
function sf(a, e) {
  switch (e) {
    case 1:
      return `vec4(${a}, 0.0, 0.0, 1.0)`;
    case 2:
      return `vec4(${a}, 0.0, 1.0)`;
    case 3:
      return `vec4(${a}, 1.0)`;
    case 4:
      return a;
    default:
      throw new Error(`invalid channels: ${e}`);
  }
}
class Se {
  constructor(e, t) {
    this.name = e, this.attributes = t, this.size = 0;
  }
  get isArray() {
    return !1;
  }
  get isStruct() {
    return !1;
  }
  get isTemplate() {
    return !1;
  }
  get isPointer() {
    return !1;
  }
  getTypeName() {
    return this.name;
  }
}
class Na {
  constructor(e, t, n) {
    this.name = e, this.type = t, this.attributes = n, this.offset = 0, this.size = 0;
  }
  get isArray() {
    return this.type.isArray;
  }
  get isStruct() {
    return this.type.isStruct;
  }
  get isTemplate() {
    return this.type.isTemplate;
  }
  get align() {
    return this.type.isStruct ? this.type.align : 0;
  }
  get members() {
    return this.type.isStruct ? this.type.members : null;
  }
  get format() {
    return this.type.isArray || this.type.isTemplate ? this.type.format : null;
  }
  get count() {
    return this.type.isArray ? this.type.count : 0;
  }
  get stride() {
    return this.type.isArray ? this.type.stride : this.size;
  }
}
class Ke extends Se {
  constructor(e, t) {
    super(e, t), this.members = [], this.align = 0, this.startLine = -1, this.endLine = -1, this.inUse = !1;
  }
  get isStruct() {
    return !0;
  }
}
class et extends Se {
  constructor(e, t) {
    super(e, t), this.count = 0, this.stride = 0;
  }
  get isArray() {
    return !0;
  }
  getTypeName() {
    return `array<${this.format.getTypeName()}, ${this.count}>`;
  }
}
class Xr extends Se {
  constructor(e, t, n) {
    super(e, n), this.format = t;
  }
  get isPointer() {
    return !0;
  }
  getTypeName() {
    return `&${this.format.getTypeName()}`;
  }
}
class ct extends Se {
  constructor(e, t, n, r) {
    super(e, n), this.format = t, this.access = r;
  }
  get isTemplate() {
    return !0;
  }
  getTypeName() {
    let e = this.name;
    if (this.format !== null) {
      if (e === "vec2" || e === "vec3" || e === "vec4" || e === "mat2x2" || e === "mat2x3" || e === "mat2x4" || e === "mat3x2" || e === "mat3x3" || e === "mat3x4" || e === "mat4x2" || e === "mat4x3" || e === "mat4x4") {
        if (this.format.name === "f32") return e += "f", e;
        if (this.format.name === "i32") return e += "i", e;
        if (this.format.name === "u32") return e += "u", e;
        if (this.format.name === "bool") return e += "b", e;
        if (this.format.name === "f16") return e += "h", e;
      }
      e += `<${this.format.name}>`;
    } else if (e === "vec2" || e === "vec3" || e === "vec4") return e;
    return e;
  }
}
var Xe;
((a) => {
  a[a.Uniform = 0] = "Uniform", a[a.Storage = 1] = "Storage", a[a.Texture = 2] = "Texture", a[a.Sampler = 3] = "Sampler", a[a.StorageTexture = 4] = "StorageTexture";
})(Xe || (Xe = {}));
class an {
  constructor(e, t, n, r, s, o, i) {
    this.name = e, this.type = t, this.group = n, this.binding = r, this.attributes = s, this.resourceType = o, this.access = i;
  }
  get isArray() {
    return this.type.isArray;
  }
  get isStruct() {
    return this.type.isStruct;
  }
  get isTemplate() {
    return this.type.isTemplate;
  }
  get size() {
    return this.type.size;
  }
  get align() {
    return this.type.isStruct ? this.type.align : 0;
  }
  get members() {
    return this.type.isStruct ? this.type.members : null;
  }
  get format() {
    return this.type.isArray || this.type.isTemplate ? this.type.format : null;
  }
  get count() {
    return this.type.isArray ? this.type.count : 0;
  }
  get stride() {
    return this.type.isArray ? this.type.stride : this.size;
  }
}
class af {
  constructor(e, t) {
    this.name = e, this.type = t;
  }
}
class of {
  constructor(e, t, n, r) {
    this.name = e, this.type = t, this.locationType = n, this.location = r, this.interpolation = null;
  }
}
class Ua {
  constructor(e, t, n, r) {
    this.name = e, this.type = t, this.locationType = n, this.location = r;
  }
}
class lf {
  constructor(e, t, n, r) {
    this.name = e, this.type = t, this.attributes = n, this.id = r;
  }
}
class cf {
  constructor(e, t, n) {
    this.name = e, this.type = t, this.attributes = n;
  }
}
class uf {
  constructor(e, t = null, n) {
    this.stage = null, this.inputs = [], this.outputs = [], this.arguments = [], this.returnType = null, this.resources = [], this.overrides = [], this.startLine = -1, this.endLine = -1, this.inUse = !1, this.calls = /* @__PURE__ */ new Set(), this.name = e, this.stage = t, this.attributes = n;
  }
}
class ff {
  constructor() {
    this.vertex = [], this.fragment = [], this.compute = [];
  }
}
function hf(a) {
  var e = (32768 & a) >> 15, t = (31744 & a) >> 10, n = 1023 & a;
  return t == 0 ? (e ? -1 : 1) * Math.pow(2, -14) * (n / Math.pow(2, 10)) : t == 31 ? n ? NaN : 1 / 0 * (e ? -1 : 1) : (e ? -1 : 1) * Math.pow(2, t - 15) * (1 + n / Math.pow(2, 10));
}
const Po = new Float32Array(1), df = new Int32Array(Po.buffer), ve = new Uint16Array(1);
function pf(a) {
  Po[0] = a;
  const e = df[0], t = e >> 31 & 1;
  let n = e >> 23 & 255, r = 8388607 & e;
  if (n === 255) return ve[0] = t << 15 | 31744 | (r !== 0 ? 512 : 0), ve[0];
  if (n === 0) {
    if (r === 0) return ve[0] = t << 15, ve[0];
    r |= 8388608;
    let s = 113;
    for (; !(8388608 & r); ) r <<= 1, s--;
    return n = 127 - s, r &= 8388607, n > 0 ? (r = (r >> 126 - n) + (r >> 127 - n & 1), ve[0] = t << 15 | n << 10 | r >> 13, ve[0]) : (ve[0] = t << 15, ve[0]);
  }
  return n = n - 127 + 15, n >= 31 ? (ve[0] = t << 15 | 31744, ve[0]) : n <= 0 ? n < -10 ? (ve[0] = t << 15, ve[0]) : (r = (8388608 | r) >> 1 - n, ve[0] = t << 15 | r >> 13, ve[0]) : (r >>= 13, ve[0] = t << 15 | n << 10 | r, ve[0]);
}
const As = new Uint32Array(1), Oo = new Float32Array(As.buffer, 0, 1);
function Va(a) {
  const e = 112 + (a >> 6 & 31) << 23 | (63 & a) << 17;
  return As[0] = e, Oo[0];
}
function mf(a, e, t, n, r, s, o, i, l) {
  const u = n * (o >>= r) * (s >>= r) + t * o + e * i;
  switch (l) {
    case "r8unorm":
      return [ae(a, u, "8unorm", 1)[0]];
    case "r8snorm":
      return [ae(a, u, "8snorm", 1)[0]];
    case "r8uint":
      return [ae(a, u, "8uint", 1)[0]];
    case "r8sint":
      return [ae(a, u, "8sint", 1)[0]];
    case "rg8unorm": {
      const c = ae(a, u, "8unorm", 2);
      return [c[0], c[1]];
    }
    case "rg8snorm": {
      const c = ae(a, u, "8snorm", 2);
      return [c[0], c[1]];
    }
    case "rg8uint": {
      const c = ae(a, u, "8uint", 2);
      return [c[0], c[1]];
    }
    case "rg8sint": {
      const c = ae(a, u, "8sint", 2);
      return [c[0], c[1]];
    }
    case "rgba8unorm-srgb":
    case "rgba8unorm": {
      const c = ae(a, u, "8unorm", 4);
      return [c[0], c[1], c[2], c[3]];
    }
    case "rgba8snorm": {
      const c = ae(a, u, "8snorm", 4);
      return [c[0], c[1], c[2], c[3]];
    }
    case "rgba8uint": {
      const c = ae(a, u, "8uint", 4);
      return [c[0], c[1], c[2], c[3]];
    }
    case "rgba8sint": {
      const c = ae(a, u, "8sint", 4);
      return [c[0], c[1], c[2], c[3]];
    }
    case "bgra8unorm-srgb":
    case "bgra8unorm": {
      const c = ae(a, u, "8unorm", 4);
      return [c[2], c[1], c[0], c[3]];
    }
    case "r16uint":
      return [ae(a, u, "16uint", 1)[0]];
    case "r16sint":
      return [ae(a, u, "16sint", 1)[0]];
    case "r16float":
      return [ae(a, u, "16float", 1)[0]];
    case "rg16uint": {
      const c = ae(a, u, "16uint", 2);
      return [c[0], c[1]];
    }
    case "rg16sint": {
      const c = ae(a, u, "16sint", 2);
      return [c[0], c[1]];
    }
    case "rg16float": {
      const c = ae(a, u, "16float", 2);
      return [c[0], c[1]];
    }
    case "rgba16uint": {
      const c = ae(a, u, "16uint", 4);
      return [c[0], c[1], c[2], c[3]];
    }
    case "rgba16sint": {
      const c = ae(a, u, "16sint", 4);
      return [c[0], c[1], c[2], c[3]];
    }
    case "rgba16float": {
      const c = ae(a, u, "16float", 4);
      return [c[0], c[1], c[2], c[3]];
    }
    case "r32uint":
      return [ae(a, u, "32uint", 1)[0]];
    case "r32sint":
      return [ae(a, u, "32sint", 1)[0]];
    case "depth16unorm":
    case "depth24plus":
    case "depth24plus-stencil8":
    case "depth32float":
    case "depth32float-stencil8":
    case "r32float":
      return [ae(a, u, "32float", 1)[0]];
    case "rg32uint": {
      const c = ae(a, u, "32uint", 2);
      return [c[0], c[1]];
    }
    case "rg32sint": {
      const c = ae(a, u, "32sint", 2);
      return [c[0], c[1]];
    }
    case "rg32float": {
      const c = ae(a, u, "32float", 2);
      return [c[0], c[1]];
    }
    case "rgba32uint": {
      const c = ae(a, u, "32uint", 4);
      return [c[0], c[1], c[2], c[3]];
    }
    case "rgba32sint": {
      const c = ae(a, u, "32sint", 4);
      return [c[0], c[1], c[2], c[3]];
    }
    case "rgba32float": {
      const c = ae(a, u, "32float", 4);
      return [c[0], c[1], c[2], c[3]];
    }
    case "rg11b10ufloat": {
      const c = new Uint32Array(a.buffer, u, 1)[0], f = (4192256 & c) >> 11, h = (4290772992 & c) >> 22;
      return [Va(2047 & c), Va(f), (function(p) {
        const v = 112 + (p >> 5 & 31) << 23 | (31 & p) << 18;
        return As[0] = v, Oo[0];
      })(h), 1];
    }
  }
  return null;
}
function ae(a, e, t, n) {
  const r = [0, 0, 0, 0];
  for (let s = 0; s < n; ++s) switch (t) {
    case "8unorm":
      r[s] = a[e] / 255, e++;
      break;
    case "8snorm":
      r[s] = a[e] / 255 * 2 - 1, e++;
      break;
    case "8uint":
      r[s] = a[e], e++;
      break;
    case "8sint":
      r[s] = a[e] - 127, e++;
      break;
    case "16uint":
      r[s] = a[e] | a[e + 1] << 8, e += 2;
      break;
    case "16sint":
      r[s] = (a[e] | a[e + 1] << 8) - 32768, e += 2;
      break;
    case "16float":
      r[s] = hf(a[e] | a[e + 1] << 8), e += 2;
      break;
    case "32uint":
    case "32sint":
      r[s] = a[e] | a[e + 1] << 8 | a[e + 2] << 16 | a[e + 3] << 24, e += 4;
      break;
    case "32float":
      r[s] = new Float32Array(a.buffer, e, 1)[0], e += 4;
  }
  return r;
}
function ie(a, e, t, n, r) {
  for (let s = 0; s < n; ++s) switch (t) {
    case "8unorm":
      a[e] = 255 * r[s], e++;
      break;
    case "8snorm":
      a[e] = 0.5 * (r[s] + 1) * 255, e++;
      break;
    case "8uint":
      a[e] = r[s], e++;
      break;
    case "8sint":
      a[e] = r[s] + 127, e++;
      break;
    case "16uint":
      new Uint16Array(a.buffer, e, 1)[0] = r[s], e += 2;
      break;
    case "16sint":
      new Int16Array(a.buffer, e, 1)[0] = r[s], e += 2;
      break;
    case "16float": {
      const o = pf(r[s]);
      new Uint16Array(a.buffer, e, 1)[0] = o, e += 2;
      break;
    }
    case "32uint":
      new Uint32Array(a.buffer, e, 1)[0] = r[s], e += 4;
      break;
    case "32sint":
      new Int32Array(a.buffer, e, 1)[0] = r[s], e += 4;
      break;
    case "32float":
      new Float32Array(a.buffer, e, 1)[0] = r[s], e += 4;
  }
  return r;
}
const Dr = { r8unorm: { bytesPerBlock: 1, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 1 }, r8snorm: { bytesPerBlock: 1, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 1 }, r8uint: { bytesPerBlock: 1, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 1 }, r8sint: { bytesPerBlock: 1, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 1 }, rg8unorm: { bytesPerBlock: 2, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 2 }, rg8snorm: { bytesPerBlock: 2, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 2 }, rg8uint: { bytesPerBlock: 2, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 2 }, rg8sint: { bytesPerBlock: 2, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 2 }, rgba8unorm: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, "rgba8unorm-srgb": { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, rgba8snorm: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, rgba8uint: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, rgba8sint: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, bgra8unorm: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, "bgra8unorm-srgb": { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, r16uint: { bytesPerBlock: 2, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 1 }, r16sint: { bytesPerBlock: 2, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 1 }, r16float: { bytesPerBlock: 2, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 1 }, rg16uint: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 2 }, rg16sint: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 2 }, rg16float: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 2 }, rgba16uint: { bytesPerBlock: 8, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, rgba16sint: { bytesPerBlock: 8, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, rgba16float: { bytesPerBlock: 8, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, r32uint: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 1 }, r32sint: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 1 }, r32float: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 1 }, rg32uint: { bytesPerBlock: 8, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 2 }, rg32sint: { bytesPerBlock: 8, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 2 }, rg32float: { bytesPerBlock: 8, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 2 }, rgba32uint: { bytesPerBlock: 16, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, rgba32sint: { bytesPerBlock: 16, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, rgba32float: { bytesPerBlock: 16, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, rgb10a2uint: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, rgb10a2unorm: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, rg11b10ufloat: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, stencil8: { bytesPerBlock: 1, blockWidth: 1, blockHeight: 1, isCompressed: !1, isDepthStencil: !0, hasDepth: !1, hasStencil: !0, channels: 1 }, depth16unorm: { bytesPerBlock: 2, blockWidth: 1, blockHeight: 1, isCompressed: !1, isDepthStencil: !0, hasDepth: !0, hasStencil: !1, channels: 1 }, depth24plus: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, isDepthStencil: !0, hasDepth: !0, hasStencil: !1, depthOnlyFormat: "depth32float", channels: 1 }, "depth24plus-stencil8": { bytesPerBlock: 8, blockWidth: 1, blockHeight: 1, isCompressed: !1, isDepthStencil: !0, hasDepth: !0, hasStencil: !0, depthOnlyFormat: "depth32float", channels: 1 }, depth32float: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, isDepthStencil: !0, hasDepth: !0, hasStencil: !1, channels: 1 }, "depth32float-stencil8": { bytesPerBlock: 8, blockWidth: 1, blockHeight: 1, isCompressed: !1, isDepthStencil: !0, hasDepth: !0, hasStencil: !0, stencilOnlyFormat: "depth32float", channels: 1 }, rgb9e5ufloat: { bytesPerBlock: 4, blockWidth: 1, blockHeight: 1, isCompressed: !1, channels: 4 }, "bc1-rgba-unorm": { bytesPerBlock: 8, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "bc1-rgba-unorm-srgb": { bytesPerBlock: 8, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "bc2-rgba-unorm": { bytesPerBlock: 16, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "bc2-rgba-unorm-srgb": { bytesPerBlock: 16, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "bc3-rgba-unorm": { bytesPerBlock: 16, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "bc3-rgba-unorm-srgb": { bytesPerBlock: 16, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "bc4-r-unorm": { bytesPerBlock: 8, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 1 }, "bc4-r-snorm": { bytesPerBlock: 8, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 1 }, "bc5-rg-unorm": { bytesPerBlock: 16, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 2 }, "bc5-rg-snorm": { bytesPerBlock: 16, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 2 }, "bc6h-rgb-ufloat": { bytesPerBlock: 16, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "bc6h-rgb-float": { bytesPerBlock: 16, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "bc7-rgba-unorm": { bytesPerBlock: 16, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "bc7-rgba-unorm-srgb": { bytesPerBlock: 16, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "etc2-rgb8unorm": { bytesPerBlock: 8, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "etc2-rgb8unorm-srgb": { bytesPerBlock: 8, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "etc2-rgb8a1unorm": { bytesPerBlock: 8, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "etc2-rgb8a1unorm-srgb": { bytesPerBlock: 8, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "etc2-rgba8unorm": { bytesPerBlock: 16, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "etc2-rgba8unorm-srgb": { bytesPerBlock: 16, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "eac-r11unorm": { bytesPerBlock: 8, blockWidth: 1, blockHeight: 1, isCompressed: !0, channels: 1 }, "eac-r11snorm": { bytesPerBlock: 8, blockWidth: 1, blockHeight: 1, isCompressed: !0, channels: 1 }, "eac-rg11unorm": { bytesPerBlock: 16, blockWidth: 1, blockHeight: 1, isCompressed: !0, channels: 2 }, "eac-rg11snorm": { bytesPerBlock: 16, blockWidth: 1, blockHeight: 1, isCompressed: !0, channels: 2 }, "astc-4x4-unorm": { bytesPerBlock: 16, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "astc-4x4-unorm-srgb": { bytesPerBlock: 16, blockWidth: 4, blockHeight: 4, isCompressed: !0, channels: 4 }, "astc-5x4-unorm": { bytesPerBlock: 16, blockWidth: 5, blockHeight: 4, isCompressed: !0, channels: 4 }, "astc-5x4-unorm-srgb": { bytesPerBlock: 16, blockWidth: 5, blockHeight: 4, isCompressed: !0, channels: 4 }, "astc-5x5-unorm": { bytesPerBlock: 16, blockWidth: 5, blockHeight: 5, isCompressed: !0, channels: 4 }, "astc-5x5-unorm-srgb": { bytesPerBlock: 16, blockWidth: 5, blockHeight: 5, isCompressed: !0, channels: 4 }, "astc-6x5-unorm": { bytesPerBlock: 16, blockWidth: 6, blockHeight: 5, isCompressed: !0, channels: 4 }, "astc-6x5-unorm-srgb": { bytesPerBlock: 16, blockWidth: 6, blockHeight: 5, isCompressed: !0, channels: 4 }, "astc-6x6-unorm": { bytesPerBlock: 16, blockWidth: 6, blockHeight: 6, isCompressed: !0, channels: 4 }, "astc-6x6-unorm-srgb": { bytesPerBlock: 16, blockWidth: 6, blockHeight: 6, isCompressed: !0, channels: 4 }, "astc-8x5-unorm": { bytesPerBlock: 16, blockWidth: 8, blockHeight: 5, isCompressed: !0, channels: 4 }, "astc-8x5-unorm-srgb": { bytesPerBlock: 16, blockWidth: 8, blockHeight: 5, isCompressed: !0, channels: 4 }, "astc-8x6-unorm": { bytesPerBlock: 16, blockWidth: 8, blockHeight: 6, isCompressed: !0, channels: 4 }, "astc-8x6-unorm-srgb": { bytesPerBlock: 16, blockWidth: 8, blockHeight: 6, isCompressed: !0, channels: 4 }, "astc-8x8-unorm": { bytesPerBlock: 16, blockWidth: 8, blockHeight: 8, isCompressed: !0, channels: 4 }, "astc-8x8-unorm-srgb": { bytesPerBlock: 16, blockWidth: 8, blockHeight: 8, isCompressed: !0, channels: 4 }, "astc-10x5-unorm": { bytesPerBlock: 16, blockWidth: 10, blockHeight: 5, isCompressed: !0, channels: 4 }, "astc-10x5-unorm-srgb": { bytesPerBlock: 16, blockWidth: 10, blockHeight: 5, isCompressed: !0, channels: 4 }, "astc-10x6-unorm": { bytesPerBlock: 16, blockWidth: 10, blockHeight: 6, isCompressed: !0, channels: 4 }, "astc-10x6-unorm-srgb": { bytesPerBlock: 16, blockWidth: 10, blockHeight: 6, isCompressed: !0, channels: 4 }, "astc-10x8-unorm": { bytesPerBlock: 16, blockWidth: 10, blockHeight: 8, isCompressed: !0, channels: 4 }, "astc-10x8-unorm-srgb": { bytesPerBlock: 16, blockWidth: 10, blockHeight: 8, isCompressed: !0, channels: 4 }, "astc-10x10-unorm": { bytesPerBlock: 16, blockWidth: 10, blockHeight: 10, isCompressed: !0, channels: 4 }, "astc-10x10-unorm-srgb": { bytesPerBlock: 16, blockWidth: 10, blockHeight: 10, isCompressed: !0, channels: 4 }, "astc-12x10-unorm": { bytesPerBlock: 16, blockWidth: 12, blockHeight: 10, isCompressed: !0, channels: 4 }, "astc-12x10-unorm-srgb": { bytesPerBlock: 16, blockWidth: 12, blockHeight: 10, isCompressed: !0, channels: 4 }, "astc-12x12-unorm": { bytesPerBlock: 16, blockWidth: 12, blockHeight: 12, isCompressed: !0, channels: 4 }, "astc-12x12-unorm-srgb": { bytesPerBlock: 16, blockWidth: 12, blockHeight: 12, isCompressed: !0, channels: 4 } };
class Le {
  constructor() {
    this.id = Le._id++, this.line = 0;
  }
  get isAstNode() {
    return !0;
  }
  get astNodeType() {
    return "";
  }
  search(e) {
    e(this);
  }
  searchBlock(e, t) {
    if (e) {
      t(Qn.instance);
      for (const n of e) n instanceof Array ? this.searchBlock(n, t) : n.search(t);
      t(Dn.instance);
    }
  }
  constEvaluate(e, t) {
    throw new Error("Cannot evaluate node");
  }
  constEvaluateString(e) {
    return this.constEvaluate(e).toString();
  }
}
Le._id = 0;
class Qn extends Le {
}
Qn.instance = new Qn();
class Dn extends Le {
}
Dn.instance = new Dn();
const No = /* @__PURE__ */ new Set(["all", "all", "any", "select", "arrayLength", "abs", "acos", "acosh", "asin", "asinh", "atan", "atanh", "atan2", "ceil", "clamp", "cos", "cosh", "countLeadingZeros", "countOneBits", "countTrailingZeros", "cross", "degrees", "determinant", "distance", "dot", "dot4U8Packed", "dot4I8Packed", "exp", "exp2", "extractBits", "faceForward", "firstLeadingBit", "firstTrailingBit", "floor", "fma", "fract", "frexp", "insertBits", "inverseSqrt", "ldexp", "length", "log", "log2", "max", "min", "mix", "modf", "normalize", "pow", "quantizeToF16", "radians", "reflect", "refract", "reverseBits", "round", "saturate", "sign", "sin", "sinh", "smoothStep", "sqrt", "step", "tan", "tanh", "transpose", "trunc", "dpdx", "dpdxCoarse", "dpdxFine", "dpdy", "dpdyCoarse", "dpdyFine", "fwidth", "fwidthCoarse", "fwidthFine", "textureDimensions", "textureGather", "textureGatherCompare", "textureLoad", "textureNumLayers", "textureNumLevels", "textureNumSamples", "textureSample", "textureSampleBias", "textureSampleCompare", "textureSampleCompareLevel", "textureSampleGrad", "textureSampleLevel", "textureSampleBaseClampToEdge", "textureStore", "atomicLoad", "atomicStore", "atomicAdd", "atomicSub", "atomicMax", "atomicMin", "atomicAnd", "atomicOr", "atomicXor", "atomicExchange", "atomicCompareExchangeWeak", "pack4x8snorm", "pack4x8unorm", "pack4xI8", "pack4xU8", "pack4x8Clamp", "pack4xU8Clamp", "pack2x16snorm", "pack2x16unorm", "pack2x16float", "unpack4x8snorm", "unpack4x8unorm", "unpack4xI8", "unpack4xU8", "unpack2x16snorm", "unpack2x16unorm", "unpack2x16float", "storageBarrier", "textureBarrier", "workgroupBarrier", "workgroupUniformLoad", "subgroupAdd", "subgroupExclusiveAdd", "subgroupInclusiveAdd", "subgroupAll", "subgroupAnd", "subgroupAny", "subgroupBallot", "subgroupBroadcast", "subgroupBroadcastFirst", "subgroupElect", "subgroupMax", "subgroupMin", "subgroupMul", "subgroupExclusiveMul", "subgroupInclusiveMul", "subgroupOr", "subgroupShuffle", "subgroupShuffleDown", "subgroupShuffleUp", "subgroupShuffleXor", "subgroupXor", "quadBroadcast", "quadSwapDiagonal", "quadSwapX", "quadSwapY"]);
class ce extends Le {
  constructor() {
    super();
  }
}
let jt = class extends ce {
  constructor(e, t, n, r, s, o) {
    super(), this.calls = /* @__PURE__ */ new Set(), this.name = e, this.args = t, this.returnType = n, this.body = r, this.startLine = s, this.endLine = o;
  }
  get astNodeType() {
    return "function";
  }
  search(e) {
    if (this.attributes) for (const t of this.attributes) e(t);
    e(this);
    for (const t of this.args) e(t);
    this.searchBlock(this.body, e);
  }
}, gf = class extends ce {
  constructor(e) {
    super(), this.expression = e;
  }
  get astNodeType() {
    return "staticAssert";
  }
  search(e) {
    this.expression.search(e);
  }
};
class Uo extends ce {
  constructor(e, t) {
    super(), this.condition = e, this.body = t;
  }
  get astNodeType() {
    return "while";
  }
  search(e) {
    this.condition.search(e), this.searchBlock(this.body, e);
  }
}
let Kr = class extends ce {
  constructor(e, t) {
    super(), this.body = e, this.loopId = t;
  }
  get astNodeType() {
    return "continuing";
  }
  search(e) {
    this.searchBlock(this.body, e);
  }
};
class Vo extends ce {
  constructor(e, t, n, r) {
    super(), this.init = e, this.condition = t, this.increment = n, this.body = r;
  }
  get astNodeType() {
    return "for";
  }
  search(e) {
    var t, n, r;
    (t = this.init) === null || t === void 0 || t.search(e), (n = this.condition) === null || n === void 0 || n.search(e), (r = this.increment) === null || r === void 0 || r.search(e), this.searchBlock(this.body, e);
  }
}
class He extends ce {
  constructor(e, t, n, r, s) {
    super(), this.attributes = null, this.name = e, this.type = t, this.storage = n, this.access = r, this.value = s;
  }
  get astNodeType() {
    return "var";
  }
  search(e) {
    var t;
    e(this), (t = this.value) === null || t === void 0 || t.search(e);
  }
}
class ys extends ce {
  constructor(e, t, n) {
    super(), this.attributes = null, this.name = e, this.type = t, this.value = n;
  }
  get astNodeType() {
    return "override";
  }
  search(e) {
    var t;
    (t = this.value) === null || t === void 0 || t.search(e);
  }
}
class Gt extends ce {
  constructor(e, t, n, r, s) {
    super(), this.attributes = null, this.name = e, this.type = t, this.storage = n, this.access = r, this.value = s;
  }
  get astNodeType() {
    return "let";
  }
  search(e) {
    var t;
    e(this), (t = this.value) === null || t === void 0 || t.search(e);
  }
}
class gn extends ce {
  constructor(e, t, n, r, s) {
    super(), this.attributes = null, this.name = e, this.type = t, this.storage = n, this.access = r, this.value = s;
  }
  get astNodeType() {
    return "const";
  }
  constEvaluate(e, t) {
    return this.value.constEvaluate(e, t);
  }
  search(e) {
    var t;
    e(this), (t = this.value) === null || t === void 0 || t.search(e);
  }
}
var vt, Ot, w, g;
((a) => {
  a.increment = "++", a.decrement = "--";
})(vt || (vt = {})), ((a) => {
  a.parse = function(e) {
    const t = e;
    if (t == "parse") throw new Error("Invalid value for IncrementOperator");
    return a[t];
  };
})(vt || (vt = {}));
let Fo = class extends ce {
  constructor(e, t) {
    super(), this.operator = e, this.variable = t;
  }
  get astNodeType() {
    return "increment";
  }
  search(e) {
    this.variable.search(e);
  }
};
((a) => {
  a.assign = "=", a.addAssign = "+=", a.subtractAssin = "-=", a.multiplyAssign = "*=", a.divideAssign = "/=", a.moduloAssign = "%=", a.andAssign = "&=", a.orAssign = "|=", a.xorAssign = "^=", a.shiftLeftAssign = "<<=", a.shiftRightAssign = ">>=";
})(Ot || (Ot = {})), ((a) => {
  a.parse = function(e) {
    const t = e;
    if (t == "parse") throw new Error("Invalid value for AssignOperator");
    return t;
  };
})(Ot || (Ot = {}));
class Ro extends ce {
  constructor(e, t, n) {
    super(), this.operator = e, this.variable = t, this.value = n;
  }
  get astNodeType() {
    return "assign";
  }
  search(e) {
    this.variable.search(e), this.value.search(e);
  }
}
let bs = class extends ce {
  constructor(e, t) {
    super(), this.name = e, this.args = t;
  }
  get astNodeType() {
    return "call";
  }
  isBuiltin() {
    return No.has(this.name);
  }
  search(e) {
    for (const t of this.args) t.search(e);
    e(this);
  }
}, Wo = class extends ce {
  constructor(e, t) {
    super(), this.body = e, this.continuing = t;
  }
  get astNodeType() {
    return "loop";
  }
  search(e) {
    var t;
    this.searchBlock(this.body, e), (t = this.continuing) === null || t === void 0 || t.search(e);
  }
}, qo = class extends ce {
  constructor(e, t) {
    super(), this.condition = e, this.cases = t;
  }
  get astNodeType() {
    return "switch";
  }
  search(e) {
    e(this);
    for (const t of this.cases) t.search(e);
  }
};
class Go extends ce {
  constructor(e, t, n, r) {
    super(), this.condition = e, this.body = t, this.elseif = n, this.else = r;
  }
  get astNodeType() {
    return "if";
  }
  search(e) {
    this.condition.search(e), this.searchBlock(this.body, e), this.searchBlock(this.elseif, e), this.searchBlock(this.else, e);
  }
}
class Jo extends ce {
  constructor(e) {
    super(), this.value = e;
  }
  get astNodeType() {
    return "return";
  }
  search(e) {
    var t;
    (t = this.value) === null || t === void 0 || t.search(e);
  }
}
let Af = class extends ce {
  constructor(e) {
    super(), this.name = e;
  }
  get astNodeType() {
    return "enable";
  }
};
class yf extends ce {
  constructor(e) {
    super(), this.extensions = e;
  }
  get astNodeType() {
    return "requires";
  }
}
class zo extends ce {
  constructor(e, t) {
    super(), this.severity = e, this.rule = t;
  }
  get astNodeType() {
    return "diagnostic";
  }
}
class vs extends ce {
  constructor(e, t) {
    super(), this.name = e, this.type = t;
  }
  get astNodeType() {
    return "alias";
  }
}
class bf extends ce {
  constructor() {
    super();
  }
  get astNodeType() {
    return "discard";
  }
}
class Ho extends ce {
  constructor() {
    super(), this.condition = null, this.loopId = -1;
  }
  get astNodeType() {
    return "break";
  }
}
let Zo = class extends ce {
  constructor() {
    super(), this.loopId = -1;
  }
  get astNodeType() {
    return "continue";
  }
};
class k extends ce {
  constructor(e) {
    super(), this.attributes = null, this.name = e;
  }
  get astNodeType() {
    return "type";
  }
  get isStruct() {
    return !1;
  }
  get isArray() {
    return !1;
  }
  static maxFormatType(e) {
    let t = e[0];
    if (t.name === "f32") return t;
    for (let n = 1; n < e.length; ++n) {
      const r = k._priority.get(t.name);
      k._priority.get(e[n].name) < r && (t = e[n]);
    }
    return t.name === "x32" ? k.i32 : t;
  }
  getTypeName() {
    return this.name;
  }
}
k.x32 = new k("x32"), k.f32 = new k("f32"), k.i32 = new k("i32"), k.u32 = new k("u32"), k.f16 = new k("f16"), k.bool = new k("bool"), k.void = new k("void"), k._priority = /* @__PURE__ */ new Map([["f32", 0], ["f16", 1], ["u32", 2], ["i32", 3], ["x32", 3]]);
class Fa extends k {
  constructor(e) {
    super(e);
  }
}
let ze = class extends k {
  constructor(e, t, n, r) {
    super(e), this.members = t, this.startLine = n, this.endLine = r;
  }
  get astNodeType() {
    return "struct";
  }
  get isStruct() {
    return !0;
  }
  getMemberIndex(e) {
    for (let t = 0; t < this.members.length; t++) if (this.members[t].name == e) return t;
    return -1;
  }
  search(e) {
    for (const t of this.members) e(t);
  }
}, x = class extends k {
  constructor(e, t, n) {
    super(e), this.format = t, this.access = n;
  }
  get astNodeType() {
    return "template";
  }
  getTypeName() {
    let e = this.name;
    if (this.format !== null) {
      if (e === "vec2" || e === "vec3" || e === "vec4" || e === "mat2x2" || e === "mat2x3" || e === "mat2x4" || e === "mat3x2" || e === "mat3x3" || e === "mat3x4" || e === "mat4x2" || e === "mat4x3" || e === "mat4x4") {
        if (this.format.name === "f32") return e += "f", e;
        if (this.format.name === "i32") return e += "i", e;
        if (this.format.name === "u32") return e += "u", e;
        if (this.format.name === "bool") return e += "b", e;
        if (this.format.name === "f16") return e += "h", e;
      }
      e += `<${this.format.name}>`;
    } else if (e === "vec2" || e === "vec3" || e === "vec4") return e;
    return e;
  }
};
x.vec2f = new x("vec2", k.f32, null), x.vec3f = new x("vec3", k.f32, null), x.vec4f = new x("vec4", k.f32, null), x.vec2i = new x("vec2", k.i32, null), x.vec3i = new x("vec3", k.i32, null), x.vec4i = new x("vec4", k.i32, null), x.vec2u = new x("vec2", k.u32, null), x.vec3u = new x("vec3", k.u32, null), x.vec4u = new x("vec4", k.u32, null), x.vec2h = new x("vec2", k.f16, null), x.vec3h = new x("vec3", k.f16, null), x.vec4h = new x("vec4", k.f16, null), x.vec2b = new x("vec2", k.bool, null), x.vec3b = new x("vec3", k.bool, null), x.vec4b = new x("vec4", k.bool, null), x.mat2x2f = new x("mat2x2", k.f32, null), x.mat2x3f = new x("mat2x3", k.f32, null), x.mat2x4f = new x("mat2x4", k.f32, null), x.mat3x2f = new x("mat3x2", k.f32, null), x.mat3x3f = new x("mat3x3", k.f32, null), x.mat3x4f = new x("mat3x4", k.f32, null), x.mat4x2f = new x("mat4x2", k.f32, null), x.mat4x3f = new x("mat4x3", k.f32, null), x.mat4x4f = new x("mat4x4", k.f32, null), x.mat2x2h = new x("mat2x2", k.f16, null), x.mat2x3h = new x("mat2x3", k.f16, null), x.mat2x4h = new x("mat2x4", k.f16, null), x.mat3x2h = new x("mat3x2", k.f16, null), x.mat3x3h = new x("mat3x3", k.f16, null), x.mat3x4h = new x("mat3x4", k.f16, null), x.mat4x2h = new x("mat4x2", k.f16, null), x.mat4x3h = new x("mat4x3", k.f16, null), x.mat4x4h = new x("mat4x4", k.f16, null), x.mat2x2i = new x("mat2x2", k.i32, null), x.mat2x3i = new x("mat2x3", k.i32, null), x.mat2x4i = new x("mat2x4", k.i32, null), x.mat3x2i = new x("mat3x2", k.i32, null), x.mat3x3i = new x("mat3x3", k.i32, null), x.mat3x4i = new x("mat3x4", k.i32, null), x.mat4x2i = new x("mat4x2", k.i32, null), x.mat4x3i = new x("mat4x3", k.i32, null), x.mat4x4i = new x("mat4x4", k.i32, null), x.mat2x2u = new x("mat2x2", k.u32, null), x.mat2x3u = new x("mat2x3", k.u32, null), x.mat2x4u = new x("mat2x4", k.u32, null), x.mat3x2u = new x("mat3x2", k.u32, null), x.mat3x3u = new x("mat3x3", k.u32, null), x.mat3x4u = new x("mat3x4", k.u32, null), x.mat4x2u = new x("mat4x2", k.u32, null), x.mat4x3u = new x("mat4x3", k.u32, null), x.mat4x4u = new x("mat4x4", k.u32, null);
let An = class extends k {
  constructor(e, t, n, r) {
    super(e), this.storage = t, this.type = n, this.access = r;
  }
  get astNodeType() {
    return "pointer";
  }
}, Jt = class extends k {
  constructor(e, t, n, r) {
    super(e), this.attributes = t, this.format = n, this.count = r;
  }
  get astNodeType() {
    return "array";
  }
  get isArray() {
    return !0;
  }
}, Nt = class extends k {
  constructor(e, t, n) {
    super(e), this.format = t, this.access = n;
  }
  get astNodeType() {
    return "sampler";
  }
}, Pe = class extends Le {
  constructor() {
    super(), this.postfix = null;
  }
}, ut = class extends Pe {
  constructor(e) {
    super(), this.value = e;
  }
  get astNodeType() {
    return "stringExpr";
  }
  toString() {
    return this.value;
  }
  constEvaluateString() {
    return this.value;
  }
}, Ve = class extends Pe {
  constructor(e, t) {
    super(), this.type = e, this.args = t;
  }
  get astNodeType() {
    return "createExpr";
  }
  search(e) {
    if (e(this), this.args) for (const t of this.args) t.search(e);
  }
  constEvaluate(e, t) {
    return t && (t[0] = this.type), e.evalExpression(this, e.context);
  }
}, xs = class extends Pe {
  constructor(e, t) {
    super(), this.cachedReturnValue = null, this.name = e, this.args = t;
  }
  get astNodeType() {
    return "callExpr";
  }
  setCachedReturnValue(e) {
    this.cachedReturnValue = e;
  }
  get isBuiltin() {
    return No.has(this.name);
  }
  constEvaluate(e, t) {
    return e.evalExpression(this, e.context);
  }
  search(e) {
    for (const t of this.args) t.search(e);
    e(this);
  }
}, ke = class extends Pe {
  constructor(e) {
    super(), this.name = e;
  }
  get astNodeType() {
    return "varExpr";
  }
  search(e) {
    e(this), this.postfix && this.postfix.search(e);
  }
  constEvaluate(e, t) {
    return e.evalExpression(this, e.context);
  }
}, jo = class extends Pe {
  constructor(e, t) {
    super(), this.name = e, this.initializer = t;
  }
  get astNodeType() {
    return "constExpr";
  }
  constEvaluate(e, t) {
    if (this.initializer) {
      const n = e.evalExpression(this.initializer, e.context);
      return n !== null && this.postfix ? n.getSubData(e, this.postfix, e.context) : n;
    }
    return null;
  }
  search(e) {
    this.initializer.search(e);
  }
}, me = class extends Pe {
  constructor(e, t) {
    super(), this.value = e, this.type = t;
  }
  get astNodeType() {
    return "literalExpr";
  }
  constEvaluate(e, t) {
    return t !== void 0 && (t[0] = this.type), this.value;
  }
  get isScalar() {
    return this.value instanceof b;
  }
  get isVector() {
    return this.value instanceof m || this.value instanceof H;
  }
  get scalarValue() {
    return this.value instanceof b ? this.value.value : (console.error("Value is not scalar."), 0);
  }
  get vectorValue() {
    return this.value instanceof m || this.value instanceof H ? this.value.data : (console.error("Value is not a vector or matrix."), new Float32Array(0));
  }
}, $o = class extends Pe {
  constructor(e, t) {
    super(), this.type = e, this.value = t;
  }
  get astNodeType() {
    return "bitcastExpr";
  }
  search(e) {
    this.value.search(e);
  }
}, _t = class extends Pe {
  constructor(e) {
    super(), this.index = e;
  }
  search(e) {
    this.index.search(e);
  }
}, Xo = class extends Pe {
  constructor() {
    super();
  }
}, pe = class extends Xo {
  constructor(e, t) {
    super(), this.operator = e, this.right = t;
  }
  get astNodeType() {
    return "unaryOp";
  }
  constEvaluate(e, t) {
    return e.evalExpression(this, e.context);
  }
  search(e) {
    this.right.search(e);
  }
}, Me = class extends Xo {
  constructor(e, t, n) {
    super(), this.operator = e, this.left = t, this.right = n;
  }
  get astNodeType() {
    return "binaryOp";
  }
  _getPromotedType(e, t) {
    return e.name === t.name ? e : e.name === "f32" || t.name === "f32" ? k.f32 : e.name === "u32" || t.name === "u32" ? k.u32 : k.i32;
  }
  constEvaluate(e, t) {
    return e.evalExpression(this, e.context);
  }
  search(e) {
    this.left.search(e), this.right.search(e);
  }
}, Ko = class extends Le {
  constructor(e) {
    super(), this.body = e;
  }
  search(e) {
    e(this), this.searchBlock(this.body, e);
  }
}, yn = class extends Pe {
  constructor() {
    super();
  }
  get astNodeType() {
    return "default";
  }
};
class Yo extends Ko {
  constructor(e, t) {
    super(t), this.selectors = e;
  }
  get astNodeType() {
    return "case";
  }
  search(e) {
    this.searchBlock(this.body, e);
  }
}
let el = class extends Ko {
  constructor(e) {
    super(e);
  }
  get astNodeType() {
    return "default";
  }
  search(e) {
    this.searchBlock(this.body, e);
  }
}, Ra = class extends Le {
  constructor(e, t, n) {
    super(), this.name = e, this.type = t, this.attributes = n;
  }
  get astNodeType() {
    return "argument";
  }
}, vf = class extends Le {
  constructor(e, t) {
    super(), this.condition = e, this.body = t;
  }
  get astNodeType() {
    return "elseif";
  }
  search(e) {
    this.condition.search(e), this.searchBlock(this.body, e);
  }
}, Wa = class extends Le {
  constructor(e, t, n) {
    super(), this.name = e, this.type = t, this.attributes = n;
  }
  get astNodeType() {
    return "member";
  }
}, tl = class extends Le {
  constructor(e, t) {
    super(), this.name = e, this.value = t;
  }
  get astNodeType() {
    return "attribute";
  }
}, qe = class nl {
  constructor(e, t) {
    this.parent = null, this.typeInfo = e, this.parent = t, this.id = nl._id++;
  }
  clone() {
    throw `Clone: Not implemented for ${this.constructor.name}`;
  }
  setDataValue(e, t, n, r) {
    console.error(`SetDataValue: Not implemented for ${this.constructor.name}`);
  }
  getSubData(e, t, n) {
    return console.error(`GetDataValue: Not implemented for ${this.constructor.name}`), null;
  }
  toString() {
    return `<${this.typeInfo.getTypeName()}>`;
  }
};
qe._id = 0;
let Yr = class extends qe {
  constructor() {
    super(new Se("void", null), null);
  }
  toString() {
    return "void";
  }
};
Yr.void = new Yr();
let At = class extends qe {
  constructor(e) {
    super(new Xr("pointer", e.typeInfo, null), null), this.reference = e;
  }
  clone() {
    return this;
  }
  setDataValue(e, t, n, r) {
    this.reference.setDataValue(e, t, n, r);
  }
  getSubData(e, t, n) {
    return t ? this.reference.getSubData(e, t, n) : this;
  }
  toString() {
    return `&${this.reference.toString()}`;
  }
}, b = class Ut extends qe {
  constructor(e, t, n = null) {
    super(t, n), e instanceof Int32Array || e instanceof Uint32Array || e instanceof Float32Array ? this.data = e : this.typeInfo.name === "x32" ? e - Math.floor(e) !== 0 ? this.data = new Float32Array([e]) : this.data = e >= 0 ? new Uint32Array([e]) : new Int32Array([e]) : this.typeInfo.name === "i32" || this.typeInfo.name === "bool" ? this.data = new Int32Array([e]) : this.typeInfo.name === "u32" ? this.data = new Uint32Array([e]) : this.typeInfo.name === "f32" || this.typeInfo.name === "f16" ? this.data = new Float32Array([e]) : console.error("ScalarData2: Invalid type", t);
  }
  clone() {
    if (this.data instanceof Float32Array) return new Ut(new Float32Array(this.data), this.typeInfo, null);
    if (this.data instanceof Int32Array) return new Ut(new Int32Array(this.data), this.typeInfo, null);
    if (this.data instanceof Uint32Array) return new Ut(new Uint32Array(this.data), this.typeInfo, null);
    throw "ScalarData: Invalid data type";
  }
  get value() {
    return this.data[0];
  }
  set value(e) {
    this.data[0] = e;
  }
  setDataValue(e, t, n, r) {
    if (n) return void console.error("SetDataValue: Scalar data does not support postfix", n);
    if (!(t instanceof Ut)) return void console.error("SetDataValue: Invalid value", t);
    let s = t.data[0];
    this.typeInfo.name === "i32" || this.typeInfo.name === "u32" ? s = Math.floor(s) : this.typeInfo.name === "bool" && (s = s ? 1 : 0), this.data[0] = s;
  }
  getSubData(e, t, n) {
    return t ? (console.error("getSubData: Scalar data does not support postfix", t), null) : this;
  }
  toString() {
    return `${this.value}`;
  }
};
function xf(a, e, t) {
  const n = e.length;
  return n === 2 ? t === "f32" ? new m(new Float32Array(e), a.getTypeInfo("vec2f")) : t === "i32" || t === "bool" ? new m(new Int32Array(e), a.getTypeInfo("vec2i")) : t === "u32" ? new m(new Uint32Array(e), a.getTypeInfo("vec2u")) : t === "f16" ? new m(new Float32Array(e), a.getTypeInfo("vec2h")) : (console.error(`getSubData: Unknown format ${t}`), null) : n === 3 ? t === "f32" ? new m(new Float32Array(e), a.getTypeInfo("vec3f")) : t === "i32" || t === "bool" ? new m(new Int32Array(e), a.getTypeInfo("vec3i")) : t === "u32" ? new m(new Uint32Array(e), a.getTypeInfo("vec3u")) : t === "f16" ? new m(new Float32Array(e), a.getTypeInfo("vec3h")) : (console.error(`getSubData: Unknown format ${t}`), null) : n === 4 ? t === "f32" ? new m(new Float32Array(e), a.getTypeInfo("vec4f")) : t === "i32" || t === "bool" ? new m(new Int32Array(e), a.getTypeInfo("vec4i")) : t === "u32" ? new m(new Uint32Array(e), a.getTypeInfo("vec4u")) : t === "f16" ? new m(new Float32Array(e), a.getTypeInfo("vec4h")) : (console.error(`getSubData: Unknown format ${t}`), null) : (console.error(`getSubData: Invalid vector size ${e.length}`), null);
}
let m = class Vt extends qe {
  constructor(e, t, n = null) {
    if (super(t, n), e instanceof Float32Array || e instanceof Uint32Array || e instanceof Int32Array) this.data = e;
    else {
      const r = this.typeInfo.name;
      r === "vec2f" || r === "vec3f" || r === "vec4f" ? this.data = new Float32Array(e) : r === "vec2i" || r === "vec3i" || r === "vec4i" ? this.data = new Int32Array(e) : r === "vec2u" || r === "vec3u" || r === "vec4u" ? this.data = new Uint32Array(e) : r === "vec2h" || r === "vec3h" || r === "vec4h" ? this.data = new Float32Array(e) : r === "vec2b" || r === "vec3b" || r === "vec4b" ? this.data = new Int32Array(e) : r === "vec2" || r === "vec3" || r === "vec4" ? this.data = new Float32Array(e) : console.error(`VectorData: Invalid type ${r}`);
    }
  }
  clone() {
    if (this.data instanceof Float32Array) return new Vt(new Float32Array(this.data), this.typeInfo, null);
    if (this.data instanceof Int32Array) return new Vt(new Int32Array(this.data), this.typeInfo, null);
    if (this.data instanceof Uint32Array) return new Vt(new Uint32Array(this.data), this.typeInfo, null);
    throw "VectorData: Invalid data type";
  }
  setDataValue(e, t, n, r) {
    n instanceof ut ? console.error("TODO: Set vector postfix") : t instanceof Vt ? this.data = t.data : console.error("SetDataValue: Invalid value", t);
  }
  getSubData(e, t, n) {
    if (t === null) return this;
    let r = e.getTypeInfo("f32");
    if (this.typeInfo instanceof ct) r = this.typeInfo.format || r;
    else {
      const o = this.typeInfo.name;
      o === "vec2f" || o === "vec3f" || o === "vec4f" ? r = e.getTypeInfo("f32") : o === "vec2i" || o === "vec3i" || o === "vec4i" ? r = e.getTypeInfo("i32") : o === "vec2b" || o === "vec3b" || o === "vec4b" ? r = e.getTypeInfo("bool") : o === "vec2u" || o === "vec3u" || o === "vec4u" ? r = e.getTypeInfo("u32") : o === "vec2h" || o === "vec3h" || o === "vec4h" ? r = e.getTypeInfo("f16") : console.error(`GetSubData: Unknown type ${o}`);
    }
    let s = this;
    for (; t !== null && s !== null; ) {
      if (t instanceof _t) {
        const o = t.index;
        let i = -1;
        if (o instanceof me) {
          if (!(o.value instanceof b)) return console.error(`GetSubData: Invalid array index ${o.value}`), null;
          i = o.value.value;
        } else {
          const l = e.evalExpression(o, n);
          if (!(l instanceof b)) return console.error("GetSubData: Unknown index type", o), null;
          i = l.value;
        }
        if (i < 0 || i >= s.data.length) return console.error("GetSubData: Index out of range", i), null;
        if (s.data instanceof Float32Array) {
          const l = new Float32Array(s.data.buffer, s.data.byteOffset + 4 * i, 1);
          return new b(l, r);
        }
        if (s.data instanceof Int32Array) {
          const l = new Int32Array(s.data.buffer, s.data.byteOffset + 4 * i, 1);
          return new b(l, r);
        }
        if (s.data instanceof Uint32Array) {
          const l = new Uint32Array(s.data.buffer, s.data.byteOffset + 4 * i, 1);
          return new b(l, r);
        }
        throw "GetSubData: Invalid data type";
      }
      if (!(t instanceof ut)) return console.error("GetSubData: Unknown postfix", t), null;
      {
        const o = t.value.toLowerCase();
        if (o.length === 1) {
          let l = 0;
          if (o === "x" || o === "r") l = 0;
          else if (o === "y" || o === "g") l = 1;
          else if (o === "z" || o === "b") l = 2;
          else {
            if (o !== "w" && o !== "a") return console.error(`GetSubData: Unknown member ${o}`), null;
            l = 3;
          }
          if (this.data instanceof Float32Array) {
            let u = new Float32Array(this.data.buffer, this.data.byteOffset + 4 * l, 1);
            return new b(u, r, this);
          }
          if (this.data instanceof Int32Array) {
            let u = new Int32Array(this.data.buffer, this.data.byteOffset + 4 * l, 1);
            return new b(u, r, this);
          }
          if (this.data instanceof Uint32Array) {
            let u = new Uint32Array(this.data.buffer, this.data.byteOffset + 4 * l, 1);
            return new b(u, r, this);
          }
        }
        const i = [];
        for (const l of o) l === "x" || l === "r" ? i.push(this.data[0]) : l === "y" || l === "g" ? i.push(this.data[1]) : l === "z" || l === "b" ? i.push(this.data[2]) : l === "w" || l === "a" ? i.push(this.data[3]) : console.error(`GetDataValue: Unknown member ${l}`);
        s = xf(e, i, r.name);
      }
      t = t.postfix;
    }
    return s;
  }
  toString() {
    let e = `${this.data[0]}`;
    for (let t = 1; t < this.data.length; ++t) e += `, ${this.data[t]}`;
    return e;
  }
};
class H extends qe {
  constructor(e, t, n = null) {
    super(t, n), e instanceof Float32Array ? this.data = e : this.data = new Float32Array(e);
  }
  clone() {
    return new H(new Float32Array(this.data), this.typeInfo, null);
  }
  setDataValue(e, t, n, r) {
    n instanceof ut ? console.error("TODO: Set matrix postfix") : t instanceof H ? this.data = t.data : console.error("SetDataValue: Invalid value", t);
  }
  getSubData(e, t, n) {
    if (t === null) return this;
    const r = this.typeInfo.name;
    if (e.getTypeInfo("f32"), this.typeInfo instanceof ct) this.typeInfo.format;
    else if (r.endsWith("f")) e.getTypeInfo("f32");
    else if (r.endsWith("i")) e.getTypeInfo("i32");
    else if (r.endsWith("u")) e.getTypeInfo("u32");
    else {
      if (!r.endsWith("h")) return console.error(`GetDataValue: Unknown type ${r}`), null;
      e.getTypeInfo("f16");
    }
    if (t instanceof _t) {
      const s = t.index;
      let o = -1;
      if (s instanceof me) {
        if (!(s.value instanceof b)) return console.error(`GetDataValue: Invalid array index ${s.value}`), null;
        o = s.value.value;
      } else {
        const u = e.evalExpression(s, n);
        if (!(u instanceof b)) return console.error("GetDataValue: Unknown index type", s), null;
        o = u.value;
      }
      if (o < 0 || o >= this.data.length) return console.error("GetDataValue: Index out of range", o), null;
      const i = r.endsWith("h") ? "h" : "f";
      let l;
      if (r === "mat2x2" || r === "mat2x2f" || r === "mat2x2h" || r === "mat3x2" || r === "mat3x2f" || r === "mat3x2h" || r === "mat4x2" || r === "mat4x2f" || r === "mat4x2h") l = new m(new Float32Array(this.data.buffer, this.data.byteOffset + 2 * o * 4, 2), e.getTypeInfo(`vec2${i}`));
      else if (r === "mat2x3" || r === "mat2x3f" || r === "mat2x3h" || r === "mat3x3" || r === "mat3x3f" || r === "mat3x3h" || r === "mat4x3" || r === "mat4x3f" || r === "mat4x3h") l = new m(new Float32Array(this.data.buffer, this.data.byteOffset + 3 * o * 4, 3), e.getTypeInfo(`vec3${i}`));
      else {
        if (r !== "mat2x4" && r !== "mat2x4f" && r !== "mat2x4h" && r !== "mat3x4" && r !== "mat3x4f" && r !== "mat3x4h" && r !== "mat4x4" && r !== "mat4x4f" && r !== "mat4x4h") return console.error(`GetDataValue: Unknown type ${r}`), null;
        l = new m(new Float32Array(this.data.buffer, this.data.byteOffset + 4 * o * 4, 4), e.getTypeInfo(`vec4${i}`));
      }
      return t.postfix ? l.getSubData(e, t.postfix, n) : l;
    }
    return console.error("GetDataValue: Invalid postfix", t), null;
  }
  toString() {
    let e = `${this.data[0]}`;
    for (let t = 1; t < this.data.length; ++t) e += `, ${this.data[t]}`;
    return e;
  }
}
let Ae = class bn extends qe {
  constructor(e, t, n = 0, r = null) {
    super(t, r), this.buffer = e instanceof ArrayBuffer ? e : e.buffer, this.offset = n;
  }
  clone() {
    const e = new Uint8Array(new Uint8Array(this.buffer, this.offset, this.typeInfo.size));
    return new bn(e.buffer, this.typeInfo, 0, null);
  }
  setDataValue(e, t, n, r) {
    if (t === null) return void console.log("setDataValue: NULL data.");
    let s = this.offset, o = this.typeInfo;
    for (; n; ) {
      if (n instanceof _t) if (o instanceof et) {
        const i = n.index;
        if (i instanceof me) {
          if (!(i.value instanceof b)) return void console.error(`SetDataValue: Invalid index type ${i.value}`);
          s += i.value.value * o.stride;
        } else {
          const l = e.evalExpression(i, r);
          if (!(l instanceof b)) return void console.error("SetDataValue: Unknown index type", i);
          s += l.value * o.stride;
        }
        o = o.format;
      } else console.error(`SetDataValue: Type ${o.getTypeName()} is not an array`);
      else {
        if (!(n instanceof ut)) return void console.error("SetDataValue: Unknown postfix type", n);
        {
          const i = n.value;
          if (o instanceof Ke) {
            let l = !1;
            for (const u of o.members) if (u.name === i) {
              s += u.offset, o = u.type, l = !0;
              break;
            }
            if (!l) return void console.error(`SetDataValue: Member ${i} not found`);
          } else if (o instanceof Se) {
            const l = o.getTypeName();
            let u = 0;
            if (i === "x" || i === "r") u = 0;
            else if (i === "y" || i === "g") u = 1;
            else if (i === "z" || i === "b") u = 2;
            else {
              if (i !== "w" && i !== "a") return void console.error(`SetDataValue: Unknown member ${i}`);
              u = 3;
            }
            if (!(t instanceof b)) return void console.error("SetDataValue: Invalid value", t);
            const c = t.value;
            return l === "vec2f" ? void (new Float32Array(this.buffer, s, 2)[u] = c) : l === "vec3f" ? void (new Float32Array(this.buffer, s, 3)[u] = c) : l === "vec4f" ? void (new Float32Array(this.buffer, s, 4)[u] = c) : l === "vec2i" ? void (new Int32Array(this.buffer, s, 2)[u] = c) : l === "vec3i" ? void (new Int32Array(this.buffer, s, 3)[u] = c) : l === "vec4i" ? void (new Int32Array(this.buffer, s, 4)[u] = c) : l === "vec2u" ? void (new Uint32Array(this.buffer, s, 2)[u] = c) : l === "vec3u" ? void (new Uint32Array(this.buffer, s, 3)[u] = c) : l === "vec4u" ? void (new Uint32Array(this.buffer, s, 4)[u] = c) : void console.error(`SetDataValue: Type ${l} is not a struct`);
          }
        }
      }
      n = n.postfix;
    }
    this.setData(e, t, o, s, r);
  }
  setData(e, t, n, r, s) {
    const o = n.getTypeName();
    if (o !== "f32" && o !== "f16") if (o !== "i32" && o !== "atomic<i32>" && o !== "x32") if (o !== "u32" && o !== "atomic<u32>") if (o !== "bool") {
      if (o === "vec2f" || o === "vec2h") {
        const i = new Float32Array(this.buffer, r, 2);
        return void (t instanceof m ? (i[0] = t.data[0], i[1] = t.data[1]) : (i[0] = t[0], i[1] = t[1]));
      }
      if (o === "vec3f" || o === "vec3h") {
        const i = new Float32Array(this.buffer, r, 3);
        return void (t instanceof m ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2]));
      }
      if (o === "vec4f" || o === "vec4h") {
        const i = new Float32Array(this.buffer, r, 4);
        return void (t instanceof m ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2], i[3] = t.data[3]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2], i[3] = t[3]));
      }
      if (o === "vec2i") {
        const i = new Int32Array(this.buffer, r, 2);
        return void (t instanceof m ? (i[0] = t.data[0], i[1] = t.data[1]) : (i[0] = t[0], i[1] = t[1]));
      }
      if (o === "vec3i") {
        const i = new Int32Array(this.buffer, r, 3);
        return void (t instanceof m ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2]));
      }
      if (o === "vec4i") {
        const i = new Int32Array(this.buffer, r, 4);
        return void (t instanceof m ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2], i[3] = t.data[3]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2], i[3] = t[3]));
      }
      if (o === "vec2u") {
        const i = new Uint32Array(this.buffer, r, 2);
        return void (t instanceof m ? (i[0] = t.data[0], i[1] = t.data[1]) : (i[0] = t[0], i[1] = t[1]));
      }
      if (o === "vec3u") {
        const i = new Uint32Array(this.buffer, r, 3);
        return void (t instanceof m ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2]));
      }
      if (o === "vec4u") {
        const i = new Uint32Array(this.buffer, r, 4);
        return void (t instanceof m ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2], i[3] = t.data[3]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2], i[3] = t[3]));
      }
      if (o === "vec2b") {
        const i = new Uint32Array(this.buffer, r, 2);
        return void (t instanceof m ? (i[0] = t.data[0], i[1] = t.data[1]) : (i[0] = t[0], i[1] = t[1]));
      }
      if (o === "vec3b") {
        const i = new Uint32Array(this.buffer, r, 3);
        return void (t instanceof m ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2]));
      }
      if (o === "vec4b") {
        const i = new Uint32Array(this.buffer, r, 4);
        return void (t instanceof m ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2], i[3] = t.data[3]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2], i[3] = t[3]));
      }
      if (o === "mat2x2f" || o === "mat2x2h") {
        const i = new Float32Array(this.buffer, r, 4);
        return void (t instanceof H ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2], i[3] = t.data[3]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2], i[3] = t[3]));
      }
      if (o === "mat2x3f" || o === "mat2x3h") {
        const i = new Float32Array(this.buffer, r, 6);
        return void (t instanceof H ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2], i[3] = t.data[3], i[4] = t.data[4], i[5] = t.data[5]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2], i[3] = t[3], i[4] = t[4], i[5] = t[5]));
      }
      if (o === "mat2x4f" || o === "mat2x4h") {
        const i = new Float32Array(this.buffer, r, 8);
        return void (t instanceof H ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2], i[3] = t.data[3], i[4] = t.data[4], i[5] = t.data[5], i[6] = t.data[6], i[7] = t.data[7]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2], i[3] = t[3], i[4] = t[4], i[5] = t[5], i[6] = t[6], i[7] = t[7]));
      }
      if (o === "mat3x2f" || o === "mat3x2h") {
        const i = new Float32Array(this.buffer, r, 6);
        return void (t instanceof H ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2], i[3] = t.data[3], i[4] = t.data[4], i[5] = t.data[5]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2], i[3] = t[3], i[4] = t[4], i[5] = t[5]));
      }
      if (o === "mat3x3f" || o === "mat3x3h") {
        const i = new Float32Array(this.buffer, r, 9);
        return void (t instanceof H ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2], i[3] = t.data[3], i[4] = t.data[4], i[5] = t.data[5], i[6] = t.data[6], i[7] = t.data[7], i[8] = t.data[8]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2], i[3] = t[3], i[4] = t[4], i[5] = t[5], i[6] = t[6], i[7] = t[7], i[8] = t[8]));
      }
      if (o === "mat3x4f" || o === "mat3x4h") {
        const i = new Float32Array(this.buffer, r, 12);
        return void (t instanceof H ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2], i[3] = t.data[3], i[4] = t.data[4], i[5] = t.data[5], i[6] = t.data[6], i[7] = t.data[7], i[8] = t.data[8], i[9] = t.data[9], i[10] = t.data[10], i[11] = t.data[11]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2], i[3] = t[3], i[4] = t[4], i[5] = t[5], i[6] = t[6], i[7] = t[7], i[8] = t[8], i[9] = t[9], i[10] = t[10], i[11] = t[11]));
      }
      if (o === "mat4x2f" || o === "mat4x2h") {
        const i = new Float32Array(this.buffer, r, 8);
        return void (t instanceof H ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2], i[3] = t.data[3], i[4] = t.data[4], i[5] = t.data[5], i[6] = t.data[6], i[7] = t.data[7]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2], i[3] = t[3], i[4] = t[4], i[5] = t[5], i[6] = t[6], i[7] = t[7]));
      }
      if (o === "mat4x3f" || o === "mat4x3h") {
        const i = new Float32Array(this.buffer, r, 12);
        return void (t instanceof H ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2], i[3] = t.data[3], i[4] = t.data[4], i[5] = t.data[5], i[6] = t.data[6], i[7] = t.data[7], i[8] = t.data[8], i[9] = t.data[9], i[10] = t.data[10], i[11] = t.data[11]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2], i[3] = t[3], i[4] = t[4], i[5] = t[5], i[6] = t[6], i[7] = t[7], i[8] = t[8], i[9] = t[9], i[10] = t[10], i[11] = t[11]));
      }
      if (o === "mat4x4f" || o === "mat4x4h") {
        const i = new Float32Array(this.buffer, r, 16);
        return void (t instanceof H ? (i[0] = t.data[0], i[1] = t.data[1], i[2] = t.data[2], i[3] = t.data[3], i[4] = t.data[4], i[5] = t.data[5], i[6] = t.data[6], i[7] = t.data[7], i[8] = t.data[8], i[9] = t.data[9], i[10] = t.data[10], i[11] = t.data[11], i[12] = t.data[12], i[13] = t.data[13], i[14] = t.data[14], i[15] = t.data[15]) : (i[0] = t[0], i[1] = t[1], i[2] = t[2], i[3] = t[3], i[4] = t[4], i[5] = t[5], i[6] = t[6], i[7] = t[7], i[8] = t[8], i[9] = t[9], i[10] = t[10], i[11] = t[11], i[12] = t[12], i[13] = t[13], i[14] = t[14], i[15] = t[15]));
      }
      if (t instanceof bn) {
        if (n === t.typeInfo)
          return void new Uint8Array(this.buffer, r, t.buffer.byteLength).set(new Uint8Array(t.buffer));
        console.error("SetDataValue: Type mismatch", o, t.typeInfo.getTypeName());
      } else console.error(`SetData: Unknown type ${o}`);
    } else t instanceof b && (new Int32Array(this.buffer, r, 1)[0] = t.value);
    else t instanceof b && (new Uint32Array(this.buffer, r, 1)[0] = t.value);
    else t instanceof b && (new Int32Array(this.buffer, r, 1)[0] = t.value);
    else t instanceof b && (new Float32Array(this.buffer, r, 1)[0] = t.value);
  }
  getSubData(e, t, n) {
    var r, s, o;
    if (t === null) return this;
    let i = this.offset, l = this.typeInfo;
    for (; t; ) {
      if (t instanceof _t) {
        const c = t.index, f = c instanceof Pe ? e.evalExpression(c, n) : c;
        let h = 0;
        if (f instanceof b ? h = f.value : typeof f == "number" ? h = f : console.error("GetDataValue: Invalid index type", c), l instanceof et) i += h * l.stride, l = l.format;
        else {
          const p = l.getTypeName();
          p === "mat4x4" || p === "mat4x4f" || p === "mat4x4h" ? (i += 16 * h, l = e.getTypeInfo("vec4f")) : console.error(`getDataValue: Type ${l.getTypeName()} is not an array`);
        }
      } else {
        if (!(t instanceof ut)) return console.error("GetDataValue: Unknown postfix type", t), null;
        {
          const c = t.value;
          if (l instanceof Ke) {
            let f = !1;
            for (const h of l.members) if (h.name === c) {
              i += h.offset, l = h.type, f = !0;
              break;
            }
            if (!f) return console.error(`GetDataValue: Member ${c} not found`), null;
          } else if (l instanceof Se) {
            const f = l.getTypeName();
            if (f === "vec2f" || f === "vec3f" || f === "vec4f" || f === "vec2i" || f === "vec3i" || f === "vec4i" || f === "vec2u" || f === "vec3u" || f === "vec4u" || f === "vec2b" || f === "vec3b" || f === "vec4b" || f === "vec2h" || f === "vec3h" || f === "vec4h" || f === "vec2" || f === "vec3" || f === "vec4") {
              if (c.length > 0 && c.length < 5) {
                let h = "f";
                const p = [];
                for (let v = 0; v < c.length; ++v) {
                  const I = c[v].toLowerCase();
                  let y = 0;
                  if (I === "x" || I === "r") y = 0;
                  else if (I === "y" || I === "g") y = 1;
                  else if (I === "z" || I === "b") y = 2;
                  else {
                    if (I !== "w" && I !== "a") return console.error(`Unknown member ${c}`), null;
                    y = 3;
                  }
                  if (c.length === 1) {
                    if (f.endsWith("f")) return this.buffer.byteLength < i + 4 * y + 4 ? (console.log("Insufficient buffer data"), null) : new b(new Float32Array(this.buffer, i + 4 * y, 1), e.getTypeInfo("f32"), this);
                    if (f.endsWith("h")) return new b(new Float32Array(this.buffer, i + 4 * y, 1), e.getTypeInfo("f16"), this);
                    if (f.endsWith("i")) return new b(new Int32Array(this.buffer, i + 4 * y, 1), e.getTypeInfo("i32"), this);
                    if (f.endsWith("b")) return new b(new Int32Array(this.buffer, i + 4 * y, 1), e.getTypeInfo("bool"), this);
                    if (f.endsWith("u")) return new b(new Uint32Array(this.buffer, i + 4 * y, 1), e.getTypeInfo("i32"), this);
                  }
                  if (f === "vec2f") p.push(new Float32Array(this.buffer, i, 2)[y]);
                  else if (f === "vec3f") {
                    if (i + 12 >= this.buffer.byteLength) return console.log("Insufficient buffer data"), null;
                    const T = new Float32Array(this.buffer, i, 3);
                    p.push(T[y]);
                  } else if (f === "vec4f") p.push(new Float32Array(this.buffer, i, 4)[y]);
                  else if (f === "vec2i") h = "i", p.push(new Int32Array(this.buffer, i, 2)[y]);
                  else if (f === "vec3i") h = "i", p.push(new Int32Array(this.buffer, i, 3)[y]);
                  else if (f === "vec4i") h = "i", p.push(new Int32Array(this.buffer, i, 4)[y]);
                  else if (f === "vec2u") {
                    h = "u";
                    const T = new Uint32Array(this.buffer, i, 2);
                    p.push(T[y]);
                  } else f === "vec3u" ? (h = "u", p.push(new Uint32Array(this.buffer, i, 3)[y])) : f === "vec4u" && (h = "u", p.push(new Uint32Array(this.buffer, i, 4)[y]));
                }
                return p.length === 2 ? l = e.getTypeInfo(`vec2${h}`) : p.length === 3 ? l = e.getTypeInfo(`vec3${h}`) : p.length === 4 ? l = e.getTypeInfo(`vec4${h}`) : console.error(`GetDataValue: Invalid vector length ${p.length}`), new m(p, l, null);
              }
              return console.error(`GetDataValue: Unknown member ${c}`), null;
            }
            return console.error(`GetDataValue: Type ${f} is not a struct`), null;
          }
        }
      }
      t = t.postfix;
    }
    const u = l.getTypeName();
    return u === "f32" ? new b(new Float32Array(this.buffer, i, 1), l, this) : u === "i32" ? new b(new Int32Array(this.buffer, i, 1), l, this) : u === "u32" ? new b(new Uint32Array(this.buffer, i, 1), l, this) : u === "vec2f" ? new m(new Float32Array(this.buffer, i, 2), l, this) : u === "vec3f" ? new m(new Float32Array(this.buffer, i, 3), l, this) : u === "vec4f" ? new m(new Float32Array(this.buffer, i, 4), l, this) : u === "vec2i" ? new m(new Int32Array(this.buffer, i, 2), l, this) : u === "vec3i" ? new m(new Int32Array(this.buffer, i, 3), l, this) : u === "vec4i" ? new m(new Int32Array(this.buffer, i, 4), l, this) : u === "vec2u" ? new m(new Uint32Array(this.buffer, i, 2), l, this) : u === "vec3u" ? new m(new Uint32Array(this.buffer, i, 3), l, this) : u === "vec4u" ? new m(new Uint32Array(this.buffer, i, 4), l, this) : l instanceof ct && l.name === "atomic" ? ((r = l.format) === null || r === void 0 ? void 0 : r.name) === "u32" ? new b(new Uint32Array(this.buffer, i, 1)[0], l.format, this) : ((s = l.format) === null || s === void 0 ? void 0 : s.name) === "i32" ? new b(new Int32Array(this.buffer, i, 1)[0], l.format, this) : (console.error(`GetDataValue: Invalid atomic format ${(o = l.format) === null || o === void 0 ? void 0 : o.name}`), null) : new bn(this.buffer, l, i, this);
  }
  toString() {
    let e = "";
    if (this.typeInfo instanceof et) if (this.typeInfo.format.name === "f32") {
      const t = new Float32Array(this.buffer, this.offset);
      e = `[${t[0]}`;
      for (let n = 1; n < t.length; ++n) e += `, ${t[n]}`;
    } else if (this.typeInfo.format.name === "i32") {
      const t = new Int32Array(this.buffer, this.offset);
      e = `[${t[0]}`;
      for (let n = 1; n < t.length; ++n) e += `, ${t[n]}`;
    } else if (this.typeInfo.format.name === "u32") {
      const t = new Uint32Array(this.buffer, this.offset);
      e = `[${t[0]}`;
      for (let n = 1; n < t.length; ++n) e += `, ${t[n]}`;
    } else if (this.typeInfo.format.name === "vec2f") {
      const t = new Float32Array(this.buffer, this.offset);
      e = `[${t[0]}, ${t[1]}]`;
      for (let n = 1; n < t.length / 2; ++n) e += `, [${t[2 * n]}, ${t[2 * n + 1]}]`;
    } else if (this.typeInfo.format.name === "vec3f") {
      const t = new Float32Array(this.buffer, this.offset);
      e = `[${t[0]}, ${t[1]}, ${t[2]}]`;
      for (let n = 4; n < t.length; n += 4) e += `, [${t[n]}, ${t[n + 1]}, ${t[n + 2]}]`;
    } else if (this.typeInfo.format.name === "vec4f") {
      const t = new Float32Array(this.buffer, this.offset);
      e = `[${t[0]}, ${t[1]}, ${t[2]}, ${t[3]}]`;
      for (let n = 4; n < t.length; n += 4) e += `, [${t[n]}, ${t[n + 1]}, ${t[n + 2]}, ${t[n + 3]}]`;
    } else e = "[...]";
    else this.typeInfo instanceof Ke ? e += "{...}" : e = "[...]";
    return e;
  }
}, at = class rl extends qe {
  constructor(e, t, n, r) {
    super(t, null), this.data = e, this.descriptor = n, this.view = r;
  }
  clone() {
    return new rl(this.data, this.typeInfo, this.descriptor, this.view);
  }
  get width() {
    var e, t;
    const n = this.descriptor.size;
    return n instanceof Array && n.length > 0 ? (e = n[0]) !== null && e !== void 0 ? e : 0 : n instanceof Object && (t = n.width) !== null && t !== void 0 ? t : 0;
  }
  get height() {
    var e, t;
    const n = this.descriptor.size;
    return n instanceof Array && n.length > 1 ? (e = n[1]) !== null && e !== void 0 ? e : 0 : n instanceof Object && (t = n.height) !== null && t !== void 0 ? t : 0;
  }
  get depthOrArrayLayers() {
    var e, t;
    const n = this.descriptor.size;
    return n instanceof Array && n.length > 2 ? (e = n[2]) !== null && e !== void 0 ? e : 0 : n instanceof Object && (t = n.depthOrArrayLayers) !== null && t !== void 0 ? t : 0;
  }
  get format() {
    var e;
    return this.descriptor && (e = this.descriptor.format) !== null && e !== void 0 ? e : "rgba8unorm";
  }
  get sampleCount() {
    var e;
    return this.descriptor && (e = this.descriptor.sampleCount) !== null && e !== void 0 ? e : 1;
  }
  get mipLevelCount() {
    var e;
    return this.descriptor && (e = this.descriptor.mipLevelCount) !== null && e !== void 0 ? e : 1;
  }
  get dimension() {
    var e;
    return this.descriptor && (e = this.descriptor.dimension) !== null && e !== void 0 ? e : "2d";
  }
  getMipLevelSize(e) {
    if (e >= this.mipLevelCount) return [0, 0, 0];
    const t = [this.width, this.height, this.depthOrArrayLayers];
    for (let n = 0; n < t.length; ++n) t[n] = Math.max(1, t[n] >> e);
    return t;
  }
  get texelByteSize() {
    const e = this.format, t = Dr[e];
    return t ? t.isDepthStencil ? 4 : t.bytesPerBlock : 0;
  }
  get bytesPerRow() {
    return this.width * this.texelByteSize;
  }
  get isDepthStencil() {
    const e = this.format, t = Dr[e];
    return !!t && t.isDepthStencil;
  }
  getGpuSize() {
    const e = this.format, t = Dr[e], n = this.width;
    if (!e || n <= 0 || !t) return -1;
    const r = this.height, s = this.depthOrArrayLayers, o = this.dimension;
    return n / t.blockWidth * (o === "1d" ? 1 : r / t.blockHeight) * t.bytesPerBlock * s;
  }
  getPixel(e, t, n = 0, r = 0) {
    const s = this.texelByteSize, o = this.bytesPerRow, i = this.height, l = this.data[r];
    return mf(new Uint8Array(l), e, t, n, r, i, o, s, this.format);
  }
  setPixel(e, t, n, r, s) {
    const o = this.texelByteSize, i = this.bytesPerRow, l = this.height, u = this.data[r];
    (function(c, f, h, p, v, I, y, T, L, E) {
      const C = p * (y >>= v) * (I >>= v) + h * y + f * T;
      switch (L) {
        case "r8unorm":
          return void ie(c, C, "8unorm", 1, E);
        case "r8snorm":
          return void ie(c, C, "8snorm", 1, E);
        case "r8uint":
          return void ie(c, C, "8uint", 1, E);
        case "r8sint":
          return void ie(c, C, "8sint", 1, E);
        case "rg8unorm":
          return void ie(c, C, "8unorm", 2, E);
        case "rg8snorm":
          return void ie(c, C, "8snorm", 2, E);
        case "rg8uint":
          return void ie(c, C, "8uint", 2, E);
        case "rg8sint":
          return void ie(c, C, "8sint", 2, E);
        case "rgba8unorm-srgb":
        case "rgba8unorm":
        case "bgra8unorm-srgb":
        case "bgra8unorm":
          return void ie(c, C, "8unorm", 4, E);
        case "rgba8snorm":
          return void ie(c, C, "8snorm", 4, E);
        case "rgba8uint":
          return void ie(c, C, "8uint", 4, E);
        case "rgba8sint":
          return void ie(c, C, "8sint", 4, E);
        case "r16uint":
          return void ie(c, C, "16uint", 1, E);
        case "r16sint":
          return void ie(c, C, "16sint", 1, E);
        case "r16float":
          return void ie(c, C, "16float", 1, E);
        case "rg16uint":
          return void ie(c, C, "16uint", 2, E);
        case "rg16sint":
          return void ie(c, C, "16sint", 2, E);
        case "rg16float":
          return void ie(c, C, "16float", 2, E);
        case "rgba16uint":
          return void ie(c, C, "16uint", 4, E);
        case "rgba16sint":
          return void ie(c, C, "16sint", 4, E);
        case "rgba16float":
          return void ie(c, C, "16float", 4, E);
        case "r32uint":
          return void ie(c, C, "32uint", 1, E);
        case "r32sint":
          return void ie(c, C, "32sint", 1, E);
        case "depth16unorm":
        case "depth24plus":
        case "depth24plus-stencil8":
        case "depth32float":
        case "depth32float-stencil8":
        case "r32float":
          return void ie(c, C, "32float", 1, E);
        case "rg32uint":
          return void ie(c, C, "32uint", 2, E);
        case "rg32sint":
          return void ie(c, C, "32sint", 2, E);
        case "rg32float":
          return void ie(c, C, "32float", 2, E);
        case "rgba32uint":
          return void ie(c, C, "32uint", 4, E);
        case "rgba32sint":
          return void ie(c, C, "32sint", 4, E);
        case "rgba32float":
          return void ie(c, C, "32float", 4, E);
        case "rg11b10ufloat":
          console.error("TODO: rg11b10ufloat not supported for writing");
      }
    })(new Uint8Array(u), e, t, n, r, l, i, o, this.format, s);
  }
};
((a) => {
  a[a.token = 0] = "token", a[a.keyword = 1] = "keyword", a[a.reserved = 2] = "reserved";
})(g || (g = {}));
let A = class {
  constructor(e, t, n) {
    this.name = e, this.type = t, this.rule = n;
  }
  toString() {
    return this.name;
  }
}, d = class {
};
w = d, d.none = new A("", g.reserved, ""), d.eof = new A("EOF", g.token, ""), d.reserved = { asm: new A("asm", g.reserved, "asm"), bf16: new A("bf16", g.reserved, "bf16"), do: new A("do", g.reserved, "do"), enum: new A("enum", g.reserved, "enum"), f16: new A("f16", g.reserved, "f16"), f64: new A("f64", g.reserved, "f64"), handle: new A("handle", g.reserved, "handle"), i8: new A("i8", g.reserved, "i8"), i16: new A("i16", g.reserved, "i16"), i64: new A("i64", g.reserved, "i64"), mat: new A("mat", g.reserved, "mat"), premerge: new A("premerge", g.reserved, "premerge"), regardless: new A("regardless", g.reserved, "regardless"), typedef: new A("typedef", g.reserved, "typedef"), u8: new A("u8", g.reserved, "u8"), u16: new A("u16", g.reserved, "u16"), u64: new A("u64", g.reserved, "u64"), unless: new A("unless", g.reserved, "unless"), using: new A("using", g.reserved, "using"), vec: new A("vec", g.reserved, "vec"), void: new A("void", g.reserved, "void") }, d.keywords = { array: new A("array", g.keyword, "array"), atomic: new A("atomic", g.keyword, "atomic"), bool: new A("bool", g.keyword, "bool"), f32: new A("f32", g.keyword, "f32"), i32: new A("i32", g.keyword, "i32"), mat2x2: new A("mat2x2", g.keyword, "mat2x2"), mat2x3: new A("mat2x3", g.keyword, "mat2x3"), mat2x4: new A("mat2x4", g.keyword, "mat2x4"), mat3x2: new A("mat3x2", g.keyword, "mat3x2"), mat3x3: new A("mat3x3", g.keyword, "mat3x3"), mat3x4: new A("mat3x4", g.keyword, "mat3x4"), mat4x2: new A("mat4x2", g.keyword, "mat4x2"), mat4x3: new A("mat4x3", g.keyword, "mat4x3"), mat4x4: new A("mat4x4", g.keyword, "mat4x4"), ptr: new A("ptr", g.keyword, "ptr"), sampler: new A("sampler", g.keyword, "sampler"), sampler_comparison: new A("sampler_comparison", g.keyword, "sampler_comparison"), struct: new A("struct", g.keyword, "struct"), texture_1d: new A("texture_1d", g.keyword, "texture_1d"), texture_2d: new A("texture_2d", g.keyword, "texture_2d"), texture_2d_array: new A("texture_2d_array", g.keyword, "texture_2d_array"), texture_3d: new A("texture_3d", g.keyword, "texture_3d"), texture_cube: new A("texture_cube", g.keyword, "texture_cube"), texture_cube_array: new A("texture_cube_array", g.keyword, "texture_cube_array"), texture_multisampled_2d: new A("texture_multisampled_2d", g.keyword, "texture_multisampled_2d"), texture_storage_1d: new A("texture_storage_1d", g.keyword, "texture_storage_1d"), texture_storage_2d: new A("texture_storage_2d", g.keyword, "texture_storage_2d"), texture_storage_2d_array: new A("texture_storage_2d_array", g.keyword, "texture_storage_2d_array"), texture_storage_3d: new A("texture_storage_3d", g.keyword, "texture_storage_3d"), texture_depth_2d: new A("texture_depth_2d", g.keyword, "texture_depth_2d"), texture_depth_2d_array: new A("texture_depth_2d_array", g.keyword, "texture_depth_2d_array"), texture_depth_cube: new A("texture_depth_cube", g.keyword, "texture_depth_cube"), texture_depth_cube_array: new A("texture_depth_cube_array", g.keyword, "texture_depth_cube_array"), texture_depth_multisampled_2d: new A("texture_depth_multisampled_2d", g.keyword, "texture_depth_multisampled_2d"), texture_external: new A("texture_external", g.keyword, "texture_external"), u32: new A("u32", g.keyword, "u32"), vec2: new A("vec2", g.keyword, "vec2"), vec3: new A("vec3", g.keyword, "vec3"), vec4: new A("vec4", g.keyword, "vec4"), bitcast: new A("bitcast", g.keyword, "bitcast"), block: new A("block", g.keyword, "block"), break: new A("break", g.keyword, "break"), case: new A("case", g.keyword, "case"), continue: new A("continue", g.keyword, "continue"), continuing: new A("continuing", g.keyword, "continuing"), default: new A("default", g.keyword, "default"), diagnostic: new A("diagnostic", g.keyword, "diagnostic"), discard: new A("discard", g.keyword, "discard"), else: new A("else", g.keyword, "else"), enable: new A("enable", g.keyword, "enable"), fallthrough: new A("fallthrough", g.keyword, "fallthrough"), false: new A("false", g.keyword, "false"), fn: new A("fn", g.keyword, "fn"), for: new A("for", g.keyword, "for"), function: new A("function", g.keyword, "function"), if: new A("if", g.keyword, "if"), let: new A("let", g.keyword, "let"), const: new A("const", g.keyword, "const"), loop: new A("loop", g.keyword, "loop"), while: new A("while", g.keyword, "while"), private: new A("private", g.keyword, "private"), read: new A("read", g.keyword, "read"), read_write: new A("read_write", g.keyword, "read_write"), return: new A("return", g.keyword, "return"), requires: new A("requires", g.keyword, "requires"), storage: new A("storage", g.keyword, "storage"), switch: new A("switch", g.keyword, "switch"), true: new A("true", g.keyword, "true"), alias: new A("alias", g.keyword, "alias"), type: new A("type", g.keyword, "type"), uniform: new A("uniform", g.keyword, "uniform"), var: new A("var", g.keyword, "var"), override: new A("override", g.keyword, "override"), workgroup: new A("workgroup", g.keyword, "workgroup"), write: new A("write", g.keyword, "write"), r8unorm: new A("r8unorm", g.keyword, "r8unorm"), r8snorm: new A("r8snorm", g.keyword, "r8snorm"), r8uint: new A("r8uint", g.keyword, "r8uint"), r8sint: new A("r8sint", g.keyword, "r8sint"), r16uint: new A("r16uint", g.keyword, "r16uint"), r16sint: new A("r16sint", g.keyword, "r16sint"), r16float: new A("r16float", g.keyword, "r16float"), rg8unorm: new A("rg8unorm", g.keyword, "rg8unorm"), rg8snorm: new A("rg8snorm", g.keyword, "rg8snorm"), rg8uint: new A("rg8uint", g.keyword, "rg8uint"), rg8sint: new A("rg8sint", g.keyword, "rg8sint"), r32uint: new A("r32uint", g.keyword, "r32uint"), r32sint: new A("r32sint", g.keyword, "r32sint"), r32float: new A("r32float", g.keyword, "r32float"), rg16uint: new A("rg16uint", g.keyword, "rg16uint"), rg16sint: new A("rg16sint", g.keyword, "rg16sint"), rg16float: new A("rg16float", g.keyword, "rg16float"), rgba8unorm: new A("rgba8unorm", g.keyword, "rgba8unorm"), rgba8unorm_srgb: new A("rgba8unorm_srgb", g.keyword, "rgba8unorm_srgb"), rgba8snorm: new A("rgba8snorm", g.keyword, "rgba8snorm"), rgba8uint: new A("rgba8uint", g.keyword, "rgba8uint"), rgba8sint: new A("rgba8sint", g.keyword, "rgba8sint"), bgra8unorm: new A("bgra8unorm", g.keyword, "bgra8unorm"), bgra8unorm_srgb: new A("bgra8unorm_srgb", g.keyword, "bgra8unorm_srgb"), rgb10a2unorm: new A("rgb10a2unorm", g.keyword, "rgb10a2unorm"), rg11b10float: new A("rg11b10float", g.keyword, "rg11b10float"), rg32uint: new A("rg32uint", g.keyword, "rg32uint"), rg32sint: new A("rg32sint", g.keyword, "rg32sint"), rg32float: new A("rg32float", g.keyword, "rg32float"), rgba16uint: new A("rgba16uint", g.keyword, "rgba16uint"), rgba16sint: new A("rgba16sint", g.keyword, "rgba16sint"), rgba16float: new A("rgba16float", g.keyword, "rgba16float"), rgba32uint: new A("rgba32uint", g.keyword, "rgba32uint"), rgba32sint: new A("rgba32sint", g.keyword, "rgba32sint"), rgba32float: new A("rgba32float", g.keyword, "rgba32float"), static_assert: new A("static_assert", g.keyword, "static_assert") }, d.tokens = { decimal_float_literal: new A("decimal_float_literal", g.token, /((-?[0-9]*\.[0-9]+|-?[0-9]+\.[0-9]*)((e|E)(\+|-)?[0-9]+)?[fh]?)|(-?[0-9]+(e|E)(\+|-)?[0-9]+[fh]?)|(-?[0-9]+[fh])/), hex_float_literal: new A("hex_float_literal", g.token, /-?0x((([0-9a-fA-F]*\.[0-9a-fA-F]+|[0-9a-fA-F]+\.[0-9a-fA-F]*)((p|P)(\+|-)?[0-9]+[fh]?)?)|([0-9a-fA-F]+(p|P)(\+|-)?[0-9]+[fh]?))/), int_literal: new A("int_literal", g.token, /-?0x[0-9a-fA-F]+|0i?|-?[1-9][0-9]*i?/), uint_literal: new A("uint_literal", g.token, /0x[0-9a-fA-F]+u|0u|[1-9][0-9]*u/), name: new A("name", g.token, /([_\p{XID_Start}][\p{XID_Continue}]+)|([\p{XID_Start}])/u), ident: new A("ident", g.token, /[_a-zA-Z][0-9a-zA-Z_]*/), and: new A("and", g.token, "&"), and_and: new A("and_and", g.token, "&&"), arrow: new A("arrow ", g.token, "->"), attr: new A("attr", g.token, "@"), forward_slash: new A("forward_slash", g.token, "/"), bang: new A("bang", g.token, "!"), bracket_left: new A("bracket_left", g.token, "["), bracket_right: new A("bracket_right", g.token, "]"), brace_left: new A("brace_left", g.token, "{"), brace_right: new A("brace_right", g.token, "}"), colon: new A("colon", g.token, ":"), comma: new A("comma", g.token, ","), equal: new A("equal", g.token, "="), equal_equal: new A("equal_equal", g.token, "=="), not_equal: new A("not_equal", g.token, "!="), greater_than: new A("greater_than", g.token, ">"), greater_than_equal: new A("greater_than_equal", g.token, ">="), shift_right: new A("shift_right", g.token, ">>"), less_than: new A("less_than", g.token, "<"), less_than_equal: new A("less_than_equal", g.token, "<="), shift_left: new A("shift_left", g.token, "<<"), modulo: new A("modulo", g.token, "%"), minus: new A("minus", g.token, "-"), minus_minus: new A("minus_minus", g.token, "--"), period: new A("period", g.token, "."), plus: new A("plus", g.token, "+"), plus_plus: new A("plus_plus", g.token, "++"), or: new A("or", g.token, "|"), or_or: new A("or_or", g.token, "||"), paren_left: new A("paren_left", g.token, "("), paren_right: new A("paren_right", g.token, ")"), semicolon: new A("semicolon", g.token, ";"), star: new A("star", g.token, "*"), tilde: new A("tilde", g.token, "~"), underscore: new A("underscore", g.token, "_"), xor: new A("xor", g.token, "^"), plus_equal: new A("plus_equal", g.token, "+="), minus_equal: new A("minus_equal", g.token, "-="), times_equal: new A("times_equal", g.token, "*="), division_equal: new A("division_equal", g.token, "/="), modulo_equal: new A("modulo_equal", g.token, "%="), and_equal: new A("and_equal", g.token, "&="), or_equal: new A("or_equal", g.token, "|="), xor_equal: new A("xor_equal", g.token, "^="), shift_right_equal: new A("shift_right_equal", g.token, ">>="), shift_left_equal: new A("shift_left_equal", g.token, "<<=") }, d.simpleTokens = { "@": w.tokens.attr, "{": w.tokens.brace_left, "}": w.tokens.brace_right, ":": w.tokens.colon, ",": w.tokens.comma, "(": w.tokens.paren_left, ")": w.tokens.paren_right, ";": w.tokens.semicolon }, d.literalTokens = { "&": w.tokens.and, "&&": w.tokens.and_and, "->": w.tokens.arrow, "/": w.tokens.forward_slash, "!": w.tokens.bang, "[": w.tokens.bracket_left, "]": w.tokens.bracket_right, "=": w.tokens.equal, "==": w.tokens.equal_equal, "!=": w.tokens.not_equal, ">": w.tokens.greater_than, ">=": w.tokens.greater_than_equal, ">>": w.tokens.shift_right, "<": w.tokens.less_than, "<=": w.tokens.less_than_equal, "<<": w.tokens.shift_left, "%": w.tokens.modulo, "-": w.tokens.minus, "--": w.tokens.minus_minus, ".": w.tokens.period, "+": w.tokens.plus, "++": w.tokens.plus_plus, "|": w.tokens.or, "||": w.tokens.or_or, "*": w.tokens.star, "~": w.tokens.tilde, _: w.tokens.underscore, "^": w.tokens.xor, "+=": w.tokens.plus_equal, "-=": w.tokens.minus_equal, "*=": w.tokens.times_equal, "/=": w.tokens.division_equal, "%=": w.tokens.modulo_equal, "&=": w.tokens.and_equal, "|=": w.tokens.or_equal, "^=": w.tokens.xor_equal, ">>=": w.tokens.shift_right_equal, "<<=": w.tokens.shift_left_equal }, d.regexTokens = { decimal_float_literal: w.tokens.decimal_float_literal, hex_float_literal: w.tokens.hex_float_literal, int_literal: w.tokens.int_literal, uint_literal: w.tokens.uint_literal, ident: w.tokens.ident }, d.storage_class = [w.keywords.function, w.keywords.private, w.keywords.workgroup, w.keywords.uniform, w.keywords.storage], d.access_mode = [w.keywords.read, w.keywords.write, w.keywords.read_write], d.sampler_type = [w.keywords.sampler, w.keywords.sampler_comparison], d.sampled_texture_type = [w.keywords.texture_1d, w.keywords.texture_2d, w.keywords.texture_2d_array, w.keywords.texture_3d, w.keywords.texture_cube, w.keywords.texture_cube_array], d.multisampled_texture_type = [w.keywords.texture_multisampled_2d], d.storage_texture_type = [w.keywords.texture_storage_1d, w.keywords.texture_storage_2d, w.keywords.texture_storage_2d_array, w.keywords.texture_storage_3d], d.depth_texture_type = [w.keywords.texture_depth_2d, w.keywords.texture_depth_2d_array, w.keywords.texture_depth_cube, w.keywords.texture_depth_cube_array, w.keywords.texture_depth_multisampled_2d], d.texture_external_type = [w.keywords.texture_external], d.any_texture_type = [...w.sampled_texture_type, ...w.multisampled_texture_type, ...w.storage_texture_type, ...w.depth_texture_type, ...w.texture_external_type], d.texel_format = [w.keywords.r8unorm, w.keywords.r8snorm, w.keywords.r8uint, w.keywords.r8sint, w.keywords.r16uint, w.keywords.r16sint, w.keywords.r16float, w.keywords.rg8unorm, w.keywords.rg8snorm, w.keywords.rg8uint, w.keywords.rg8sint, w.keywords.r32uint, w.keywords.r32sint, w.keywords.r32float, w.keywords.rg16uint, w.keywords.rg16sint, w.keywords.rg16float, w.keywords.rgba8unorm, w.keywords.rgba8unorm_srgb, w.keywords.rgba8snorm, w.keywords.rgba8uint, w.keywords.rgba8sint, w.keywords.bgra8unorm, w.keywords.bgra8unorm_srgb, w.keywords.rgb10a2unorm, w.keywords.rg11b10float, w.keywords.rg32uint, w.keywords.rg32sint, w.keywords.rg32float, w.keywords.rgba16uint, w.keywords.rgba16sint, w.keywords.rgba16float, w.keywords.rgba32uint, w.keywords.rgba32sint, w.keywords.rgba32float], d.const_literal = [w.tokens.int_literal, w.tokens.uint_literal, w.tokens.decimal_float_literal, w.tokens.hex_float_literal, w.keywords.true, w.keywords.false], d.literal_or_ident = [w.tokens.ident, w.tokens.int_literal, w.tokens.uint_literal, w.tokens.decimal_float_literal, w.tokens.hex_float_literal, w.tokens.name], d.element_count_expression = [w.tokens.int_literal, w.tokens.uint_literal, w.tokens.ident], d.template_types = [w.keywords.vec2, w.keywords.vec3, w.keywords.vec4, w.keywords.mat2x2, w.keywords.mat2x3, w.keywords.mat2x4, w.keywords.mat3x2, w.keywords.mat3x3, w.keywords.mat3x4, w.keywords.mat4x2, w.keywords.mat4x3, w.keywords.mat4x4, w.keywords.atomic, w.keywords.bitcast, ...w.any_texture_type], d.attribute_name = [w.tokens.ident, w.keywords.block, w.keywords.diagnostic], d.assignment_operators = [w.tokens.equal, w.tokens.plus_equal, w.tokens.minus_equal, w.tokens.times_equal, w.tokens.division_equal, w.tokens.modulo_equal, w.tokens.and_equal, w.tokens.or_equal, w.tokens.xor_equal, w.tokens.shift_right_equal, w.tokens.shift_left_equal], d.increment_operators = [w.tokens.plus_plus, w.tokens.minus_minus];
let qa = class {
  constructor(e, t, n, r, s) {
    this.type = e, this.lexeme = t, this.line = n, this.start = r, this.end = s;
  }
  toString() {
    return this.lexeme;
  }
  isTemplateType() {
    return d.template_types.indexOf(this.type) != -1;
  }
  isArrayType() {
    return this.type == d.keywords.array;
  }
  isArrayOrTemplateType() {
    return this.isArrayType() || this.isTemplateType();
  }
}, wf = class {
  constructor(e) {
    this._tokens = [], this._start = 0, this._current = 0, this._line = 1, this._source = e ?? "";
  }
  scanTokens() {
    for (; !this._isAtEnd(); ) if (this._start = this._current, !this.scanToken()) throw `Invalid syntax at line ${this._line}`;
    return this._tokens.push(new qa(d.eof, "", this._line, this._current, this._current)), this._tokens;
  }
  scanToken() {
    let e = this._advance();
    if (e == `
`) return this._line++, !0;
    if (this._isWhitespace(e)) return !0;
    if (e == "/") {
      if (this._peekAhead() == "/") {
        for (; e != `
`; ) {
          if (this._isAtEnd()) return !0;
          e = this._advance();
        }
        return this._line++, !0;
      }
      if (this._peekAhead() == "*") {
        this._advance();
        let o = 1;
        for (; o > 0; ) {
          if (this._isAtEnd()) return !0;
          if (e = this._advance(), e == `
`) this._line++;
          else if (e == "*") {
            if (this._peekAhead() == "/" && (this._advance(), o--, o == 0)) return !0;
          } else e == "/" && this._peekAhead() == "*" && (this._advance(), o++);
        }
        return !0;
      }
    }
    const t = d.simpleTokens[e];
    if (t) return this._addToken(t), !0;
    let n = d.none;
    const r = this._isAlpha(e), s = e === "_";
    if (this._isAlphaNumeric(e)) {
      let o = this._peekAhead();
      for (; this._isAlphaNumeric(o); ) e += this._advance(), o = this._peekAhead();
    }
    if (r) {
      const o = d.keywords[e];
      if (o) return this._addToken(o), !0;
    }
    if (r || s) return this._addToken(d.tokens.ident), !0;
    for (; ; ) {
      let o = this._findType(e);
      const i = this._peekAhead();
      if (e == "-" && this._tokens.length > 0) {
        if (i == "=") return this._current++, e += i, this._addToken(d.tokens.minus_equal), !0;
        if (i == "-") return this._current++, e += i, this._addToken(d.tokens.minus_minus), !0;
        const l = this._tokens.length - 1;
        if ((d.literal_or_ident.indexOf(this._tokens[l].type) != -1 || this._tokens[l].type == d.tokens.paren_right) && i != ">") return this._addToken(o), !0;
      }
      if (e == ">" && (i == ">" || i == "=")) {
        let l = !1, u = this._tokens.length - 1;
        for (let c = 0; c < 5 && u >= 0 && d.assignment_operators.indexOf(this._tokens[u].type) === -1; ++c, --u) if (this._tokens[u].type === d.tokens.less_than) {
          u > 0 && this._tokens[u - 1].isArrayOrTemplateType() && (l = !0);
          break;
        }
        if (l) return this._addToken(o), !0;
      }
      if (o === d.none) {
        let l = e, u = 0;
        const c = 2;
        for (let f = 0; f < c; ++f) if (l += this._peekAhead(f), o = this._findType(l), o !== d.none) {
          u = f;
          break;
        }
        if (o === d.none) return n !== d.none && (this._current--, this._addToken(n), !0);
        e = l, this._current += u + 1;
      }
      if (n = o, this._isAtEnd()) break;
      e += this._advance();
    }
    return n !== d.none && (this._addToken(n), !0);
  }
  _findType(e) {
    for (const n in d.regexTokens) {
      const r = d.regexTokens[n];
      if (this._match(e, r.rule)) return r;
    }
    return d.literalTokens[e] || d.none;
  }
  _match(e, t) {
    const n = t.exec(e);
    return n && n.index == 0 && n[0] == e;
  }
  _isAtEnd() {
    return this._current >= this._source.length;
  }
  _isAlpha(e) {
    return !this._isNumeric(e) && !this._isWhitespace(e) && e !== "_" && e !== "." && e !== "(" && e !== ")" && e !== "[" && e !== "]" && e !== "{" && e !== "}" && e !== "," && e !== ";" && e !== ":" && e !== "=" && e !== "!" && e !== "<" && e !== ">" && e !== "+" && e !== "-" && e !== "*" && e !== "/" && e !== "%" && e !== "&" && e !== "|" && e !== "^" && e !== "~" && e !== "@" && e !== "#" && e !== "?" && e !== "'" && e !== "`" && e !== '"' && e !== "\\" && e !== `
` && e !== "\r" && e !== "	" && e !== "\0";
  }
  _isNumeric(e) {
    return e >= "0" && e <= "9";
  }
  _isAlphaNumeric(e) {
    return this._isAlpha(e) || this._isNumeric(e) || e === "_";
  }
  _isWhitespace(e) {
    return e == " " || e == "	" || e == "\r";
  }
  _advance(e = 0) {
    let t = this._source[this._current];
    return e = e || 0, e++, this._current += e, t;
  }
  _peekAhead(e = 0) {
    return e = e || 0, this._current + e >= this._source.length ? "\0" : this._source[this._current + e];
  }
  _addToken(e) {
    const t = this._source.substring(this._start, this._current);
    this._tokens.push(new qa(e, t, this._line, this._start, this._current));
  }
};
function P(a) {
  return Array.isArray(a) || a?.buffer instanceof ArrayBuffer;
}
const Pn = new Float32Array(1), If = new Uint32Array(Pn.buffer), _f = new Uint32Array(Pn.buffer), On = new Int32Array(1), Cf = new Float32Array(On.buffer), Ef = new Uint32Array(On.buffer), Nn = new Uint32Array(1), kf = new Float32Array(Nn.buffer), Tf = new Int32Array(Nn.buffer);
function Ga(a, e, t) {
  if (e === t) return a;
  if (e === "f32") {
    if (t === "i32" || t === "x32") return Pn[0] = a, If[0];
    if (t === "u32") return Pn[0] = a, _f[0];
  } else if (e === "i32" || e === "x32") {
    if (t === "f32") return On[0] = a, Cf[0];
    if (t === "u32") return On[0] = a, Ef[0];
  } else if (e === "u32") {
    if (t === "f32") return Nn[0] = a, kf[0];
    if (t === "i32" || t === "x32") return Nn[0] = a, Tf[0];
  }
  return console.error(`Unsupported cast from ${e} to ${t}`), a;
}
let Bf = class {
  constructor(e) {
    this.resources = null, this.inUse = !1, this.info = null, this.node = e;
  }
}, on = class {
  constructor(e, t) {
    this.align = e, this.size = t;
  }
}, zt = class Ft {
  constructor() {
    this.uniforms = [], this.storage = [], this.textures = [], this.samplers = [], this.aliases = [], this.overrides = [], this.structs = [], this.entry = new ff(), this.functions = [], this._types = /* @__PURE__ */ new Map(), this._functions = /* @__PURE__ */ new Map();
  }
  _isStorageTexture(e) {
    return e.name == "texture_storage_1d" || e.name == "texture_storage_2d" || e.name == "texture_storage_2d_array" || e.name == "texture_storage_3d";
  }
  updateAST(e) {
    for (const t of e) t instanceof jt && this._functions.set(t.name, new Bf(t));
    for (const t of e) if (t instanceof ze) {
      const n = this.getTypeInfo(t, null);
      n instanceof Ke && this.structs.push(n);
    }
    for (const t of e) if (t instanceof vs) this.aliases.push(this._getAliasInfo(t));
    else {
      if (t instanceof ys) {
        const n = t, r = this._getAttributeNum(n.attributes, "id", 0), s = n.type != null ? this.getTypeInfo(n.type, n.attributes) : null;
        this.overrides.push(new lf(n.name, s, n.attributes, r));
        continue;
      }
      if (this._isUniformVar(t)) {
        const n = t, r = this._getAttributeNum(n.attributes, "group", 0), s = this._getAttributeNum(n.attributes, "binding", 0), o = this.getTypeInfo(n.type, n.attributes), i = new an(n.name, o, r, s, n.attributes, Xe.Uniform, n.access);
        i.access || (i.access = "read"), this.uniforms.push(i);
        continue;
      }
      if (this._isStorageVar(t)) {
        const n = t, r = this._getAttributeNum(n.attributes, "group", 0), s = this._getAttributeNum(n.attributes, "binding", 0), o = this.getTypeInfo(n.type, n.attributes), i = this._isStorageTexture(o), l = new an(n.name, o, r, s, n.attributes, i ? Xe.StorageTexture : Xe.Storage, n.access);
        l.access || (l.access = "read"), this.storage.push(l);
        continue;
      }
      if (this._isTextureVar(t)) {
        const n = t, r = this._getAttributeNum(n.attributes, "group", 0), s = this._getAttributeNum(n.attributes, "binding", 0), o = this.getTypeInfo(n.type, n.attributes), i = this._isStorageTexture(o), l = new an(n.name, o, r, s, n.attributes, i ? Xe.StorageTexture : Xe.Texture, n.access);
        l.access || (l.access = "read"), i ? this.storage.push(l) : this.textures.push(l);
        continue;
      }
      if (this._isSamplerVar(t)) {
        const n = t, r = this._getAttributeNum(n.attributes, "group", 0), s = this._getAttributeNum(n.attributes, "binding", 0), o = this.getTypeInfo(n.type, n.attributes), i = new an(n.name, o, r, s, n.attributes, Xe.Sampler, n.access);
        this.samplers.push(i);
        continue;
      }
    }
    for (const t of e) if (t instanceof jt) {
      const n = this._getAttribute(t, "vertex"), r = this._getAttribute(t, "fragment"), s = this._getAttribute(t, "compute"), o = n || r || s, i = new uf(t.name, o?.name, t.attributes);
      i.attributes = t.attributes, i.startLine = t.startLine, i.endLine = t.endLine, this.functions.push(i), this._functions.get(t.name).info = i, o && (this._functions.get(t.name).inUse = !0, i.inUse = !0, i.resources = this._findResources(t, !!o), i.inputs = this._getInputs(t.args), i.outputs = this._getOutputs(t.returnType), this.entry[o.name].push(i)), i.arguments = t.args.map((l) => new cf(l.name, this.getTypeInfo(l.type, l.attributes), l.attributes)), i.returnType = t.returnType ? this.getTypeInfo(t.returnType, t.attributes) : null;
      continue;
    }
    for (const t of this._functions.values()) t.info && (t.info.inUse = t.inUse, this._addCalls(t.node, t.info.calls));
    for (const t of this._functions.values()) t.node.search((n) => {
      var r, s, o;
      if (n instanceof tl) {
        if (n.value) if (P(n.value)) for (const i of n.value) for (const l of this.overrides) i === l.name && ((r = t.info) === null || r === void 0 || r.overrides.push(l));
        else for (const i of this.overrides) n.value === i.name && ((s = t.info) === null || s === void 0 || s.overrides.push(i));
      } else if (n instanceof ke) for (const i of this.overrides) n.name === i.name && ((o = t.info) === null || o === void 0 || o.overrides.push(i));
    });
    for (const t of this.uniforms) this._markStructsInUse(t.type);
    for (const t of this.storage) this._markStructsInUse(t.type);
  }
  getFunctionInfo(e) {
    for (const t of this.functions) if (t.name == e) return t;
    return null;
  }
  getStructInfo(e) {
    for (const t of this.structs) if (t.name == e) return t;
    return null;
  }
  getOverrideInfo(e) {
    for (const t of this.overrides) if (t.name == e) return t;
    return null;
  }
  _markStructsInUse(e) {
    if (e) if (e.isStruct) {
      if (e.inUse = !0, e.members) for (const t of e.members) this._markStructsInUse(t.type);
    } else if (e.isArray) this._markStructsInUse(e.format);
    else if (e.isTemplate) e.format && this._markStructsInUse(e.format);
    else {
      const t = this._getAlias(e.name);
      t && this._markStructsInUse(t);
    }
  }
  _addCalls(e, t) {
    var n;
    for (const r of e.calls) {
      const s = (n = this._functions.get(r.name)) === null || n === void 0 ? void 0 : n.info;
      s && t.add(s);
    }
  }
  findResource(e, t, n) {
    if (n) {
      for (const r of this.entry.compute) if (r.name === n) {
        for (const s of r.resources) if (s.group == e && s.binding == t) return s;
      }
      for (const r of this.entry.vertex) if (r.name === n) {
        for (const s of r.resources) if (s.group == e && s.binding == t) return s;
      }
      for (const r of this.entry.fragment) if (r.name === n) {
        for (const s of r.resources) if (s.group == e && s.binding == t) return s;
      }
    }
    for (const r of this.uniforms) if (r.group == e && r.binding == t) return r;
    for (const r of this.storage) if (r.group == e && r.binding == t) return r;
    for (const r of this.textures) if (r.group == e && r.binding == t) return r;
    for (const r of this.samplers) if (r.group == e && r.binding == t) return r;
    return null;
  }
  _findResource(e) {
    for (const t of this.uniforms) if (t.name == e) return t;
    for (const t of this.storage) if (t.name == e) return t;
    for (const t of this.textures) if (t.name == e) return t;
    for (const t of this.samplers) if (t.name == e) return t;
    return null;
  }
  _markStructsFromAST(e) {
    const t = this.getTypeInfo(e, null);
    this._markStructsInUse(t);
  }
  _findResources(e, t) {
    const n = [], r = this, s = [];
    return e.search((o) => {
      if (o instanceof Qn) s.push({});
      else if (o instanceof Dn) s.pop();
      else if (o instanceof He) {
        const i = o;
        t && i.type !== null && this._markStructsFromAST(i.type), s.length > 0 && (s[s.length - 1][i.name] = i);
      } else if (o instanceof Ve) {
        const i = o;
        t && i.type !== null && this._markStructsFromAST(i.type);
      } else if (o instanceof Gt) {
        const i = o;
        t && i.type !== null && this._markStructsFromAST(i.type), s.length > 0 && (s[s.length - 1][i.name] = i);
      } else if (o instanceof ke) {
        const i = o;
        if (s.length > 0 && s[s.length - 1][i.name])
          return;
        const l = r._findResource(i.name);
        l && n.push(l);
      } else if (o instanceof xs) {
        const i = o, l = r._functions.get(i.name);
        l && (t && (l.inUse = !0), e.calls.add(l.node), l.resources === null && (l.resources = r._findResources(l.node, t)), n.push(...l.resources));
      } else if (o instanceof bs) {
        const i = o, l = r._functions.get(i.name);
        l && (t && (l.inUse = !0), e.calls.add(l.node), l.resources === null && (l.resources = r._findResources(l.node, t)), n.push(...l.resources));
      }
    }), [...new Map(n.map((o) => [o.name, o])).values()];
  }
  getBindGroups() {
    const e = [];
    function t(n, r) {
      n >= e.length && (e.length = n + 1), e[n] === void 0 && (e[n] = []), r >= e[n].length && (e[n].length = r + 1);
    }
    for (const n of this.uniforms)
      t(n.group, n.binding), e[n.group][n.binding] = n;
    for (const n of this.storage)
      t(n.group, n.binding), e[n.group][n.binding] = n;
    for (const n of this.textures)
      t(n.group, n.binding), e[n.group][n.binding] = n;
    for (const n of this.samplers)
      t(n.group, n.binding), e[n.group][n.binding] = n;
    return e;
  }
  _getOutputs(e, t = void 0) {
    if (t === void 0 && (t = []), e instanceof ze) this._getStructOutputs(e, t);
    else {
      const n = this._getOutputInfo(e);
      n !== null && t.push(n);
    }
    return t;
  }
  _getStructOutputs(e, t) {
    for (const n of e.members) if (n.type instanceof ze) this._getStructOutputs(n.type, t);
    else {
      const r = this._getAttribute(n, "location") || this._getAttribute(n, "builtin");
      if (r !== null) {
        const s = this.getTypeInfo(n.type, n.type.attributes), o = this._parseInt(r.value), i = new Ua(n.name, s, r.name, o);
        t.push(i);
      }
    }
  }
  _getOutputInfo(e) {
    const t = this._getAttribute(e, "location") || this._getAttribute(e, "builtin");
    if (t !== null) {
      const n = this.getTypeInfo(e, e.attributes), r = this._parseInt(t.value);
      return new Ua("", n, t.name, r);
    }
    return null;
  }
  _getInputs(e, t = void 0) {
    t === void 0 && (t = []);
    for (const n of e) if (n.type instanceof ze) this._getStructInputs(n.type, t);
    else {
      const r = this._getInputInfo(n);
      r !== null && t.push(r);
    }
    return t;
  }
  _getStructInputs(e, t) {
    for (const n of e.members) if (n.type instanceof ze) this._getStructInputs(n.type, t);
    else {
      const r = this._getInputInfo(n);
      r !== null && t.push(r);
    }
  }
  _getInputInfo(e) {
    const t = this._getAttribute(e, "location") || this._getAttribute(e, "builtin");
    if (t !== null) {
      const n = this._getAttribute(e, "interpolation"), r = this.getTypeInfo(e.type, e.attributes), s = this._parseInt(t.value), o = new of(e.name, r, t.name, s);
      return n !== null && (o.interpolation = this._parseString(n.value)), o;
    }
    return null;
  }
  _parseString(e) {
    return e instanceof Array && (e = e[0]), e;
  }
  _parseInt(e) {
    e instanceof Array && (e = e[0]);
    const t = parseInt(e);
    return isNaN(t) ? e : t;
  }
  _getAlias(e) {
    for (const t of this.aliases) if (t.name == e) return t.type;
    return null;
  }
  _getAliasInfo(e) {
    return new af(e.name, this.getTypeInfo(e.type, null));
  }
  getTypeInfoByName(e) {
    for (const t of this.structs) if (t.name == e) return t;
    for (const t of this.aliases) if (t.name == e) return t.type;
    return null;
  }
  getTypeInfo(e, t = null) {
    if (this._types.has(e)) return this._types.get(e);
    if (e instanceof An) {
      const r = e.type ? this.getTypeInfo(e.type, e.attributes) : null, s = new Xr(e.name, r, t);
      return this._types.set(e, s), this._updateTypeInfo(s), s;
    }
    if (e instanceof Jt) {
      const r = e, s = r.format ? this.getTypeInfo(r.format, r.attributes) : null, o = new et(r.name, t);
      return o.format = s, o.count = r.count, this._types.set(e, o), this._updateTypeInfo(o), o;
    }
    if (e instanceof ze) {
      const r = e, s = new Ke(r.name, t);
      s.startLine = r.startLine, s.endLine = r.endLine;
      for (const o of r.members) {
        const i = this.getTypeInfo(o.type, o.attributes);
        s.members.push(new Na(o.name, i, o.attributes));
      }
      return this._types.set(e, s), this._updateTypeInfo(s), s;
    }
    if (e instanceof Nt) {
      const r = e, s = r.format instanceof k, o = r.format ? s ? this.getTypeInfo(r.format, null) : new Se(r.format, null) : null, i = new ct(r.name, o, t, r.access);
      return this._types.set(e, i), this._updateTypeInfo(i), i;
    }
    if (e instanceof x) {
      const r = e, s = r.format ? this.getTypeInfo(r.format, null) : null, o = new ct(r.name, s, t, r.access);
      return this._types.set(e, o), this._updateTypeInfo(o), o;
    }
    const n = new Se(e.name, t);
    return this._types.set(e, n), this._updateTypeInfo(n), n;
  }
  _updateTypeInfo(e) {
    var t, n, r;
    const s = this._getTypeSize(e);
    if (e.size = (t = s?.size) !== null && t !== void 0 ? t : 0, e instanceof et && e.format) {
      const o = this._getTypeSize(e.format);
      e.stride = Math.max((n = o?.size) !== null && n !== void 0 ? n : 0, (r = o?.align) !== null && r !== void 0 ? r : 0), this._updateTypeInfo(e.format);
    }
    e instanceof Xr && this._updateTypeInfo(e.format), e instanceof Ke && this._updateStructInfo(e);
  }
  _updateStructInfo(e) {
    var t;
    let n = 0, r = 0, s = 0, o = 0;
    for (let i = 0, l = e.members.length; i < l; ++i) {
      const u = e.members[i], c = this._getTypeSize(u);
      if (!c) continue;
      (t = this._getAlias(u.type.name)) !== null && t !== void 0 || u.type;
      const f = c.align, h = c.size;
      n = this._roundUp(f, n + r), r = h, s = n, o = Math.max(o, f), u.offset = n, u.size = h, this._updateTypeInfo(u.type);
    }
    e.size = this._roundUp(o, s + r), e.align = o;
  }
  _getTypeSize(e) {
    var t, n;
    if (e == null) return null;
    const r = this._getAttributeNum(e.attributes, "size", 0), s = this._getAttributeNum(e.attributes, "align", 0);
    if (e instanceof Na && (e = e.type), e instanceof Se) {
      const o = this._getAlias(e.name);
      o !== null && (e = o);
    }
    {
      const o = Ft._typeInfo[e.name];
      if (o !== void 0) {
        const i = ((t = e.format) === null || t === void 0 ? void 0 : t.name) === "f16" ? 2 : 1;
        return new on(Math.max(s, o.align / i), Math.max(r, o.size / i));
      }
    }
    {
      const o = Ft._typeInfo[e.name.substring(0, e.name.length - 1)];
      if (o) {
        const i = e.name[e.name.length - 1] === "h" ? 2 : 1;
        return new on(Math.max(s, o.align / i), Math.max(r, o.size / i));
      }
    }
    if (e instanceof et) {
      let o = e, i = 8, l = 8;
      const u = this._getTypeSize(o.format);
      return u !== null && (l = u.size, i = u.align), l = o.count * this._getAttributeNum((n = e?.attributes) !== null && n !== void 0 ? n : null, "stride", this._roundUp(i, l)), r && (l = r), new on(Math.max(s, i), Math.max(r, l));
    }
    if (e instanceof Ke) {
      let o = 0, i = 0, l = 0, u = 0, c = 0;
      for (const f of e.members) {
        const h = this._getTypeSize(f.type);
        h !== null && (o = Math.max(h.align, o), l = this._roundUp(h.align, l + u), u = h.size, c = l);
      }
      return i = this._roundUp(o, c + u), new on(Math.max(s, o), Math.max(r, i));
    }
    return null;
  }
  _isUniformVar(e) {
    return e instanceof He && e.storage == "uniform";
  }
  _isStorageVar(e) {
    return e instanceof He && e.storage == "storage";
  }
  _isTextureVar(e) {
    return e instanceof He && e.type !== null && Ft._textureTypes.indexOf(e.type.name) != -1;
  }
  _isSamplerVar(e) {
    return e instanceof He && e.type !== null && Ft._samplerTypes.indexOf(e.type.name) != -1;
  }
  _getAttribute(e, t) {
    const n = e;
    if (!n || !n.attributes) return null;
    const r = n.attributes;
    for (let s of r) if (s.name == t) return s;
    return null;
  }
  _getAttributeNum(e, t, n) {
    if (e === null) return n;
    for (let r of e) if (r.name == t) {
      let s = r !== null && r.value !== null ? r.value : n;
      return s instanceof Array && (s = s[0]), typeof s == "number" ? s : typeof s == "string" ? parseInt(s) : n;
    }
    return n;
  }
  _roundUp(e, t) {
    return Math.ceil(t / e) * e;
  }
};
zt._typeInfo = { f16: { align: 2, size: 2 }, i32: { align: 4, size: 4 }, u32: { align: 4, size: 4 }, f32: { align: 4, size: 4 }, atomic: { align: 4, size: 4 }, vec2: { align: 8, size: 8 }, vec3: { align: 16, size: 12 }, vec4: { align: 16, size: 16 }, mat2x2: { align: 8, size: 16 }, mat3x2: { align: 8, size: 24 }, mat4x2: { align: 8, size: 32 }, mat2x3: { align: 16, size: 32 }, mat3x3: { align: 16, size: 48 }, mat4x3: { align: 16, size: 64 }, mat2x4: { align: 16, size: 32 }, mat3x4: { align: 16, size: 48 }, mat4x4: { align: 16, size: 64 } }, zt._textureTypes = d.any_texture_type.map((a) => a.name), zt._samplerTypes = d.sampler_type.map((a) => a.name);
let ws = 0, Sf = class sl {
  constructor(e, t, n) {
    this.id = ws++, this.name = e, this.value = t, this.node = n;
  }
  clone() {
    return new sl(this.name, this.value, this.node);
  }
}, Lf = class al {
  constructor(e) {
    this.id = ws++, this.name = e.name, this.node = e;
  }
  clone() {
    return new al(this.node);
  }
}, Mf = class il {
  constructor(e) {
    this.parent = null, this.variables = /* @__PURE__ */ new Map(), this.functions = /* @__PURE__ */ new Map(), this.currentFunctionName = "", this.id = ws++, e && (this.parent = e, this.currentFunctionName = e.currentFunctionName);
  }
  getVariable(e) {
    var t;
    return this.variables.has(e) ? (t = this.variables.get(e)) !== null && t !== void 0 ? t : null : this.parent ? this.parent.getVariable(e) : null;
  }
  getFunction(e) {
    var t;
    return this.functions.has(e) ? (t = this.functions.get(e)) !== null && t !== void 0 ? t : null : this.parent ? this.parent.getFunction(e) : null;
  }
  createVariable(e, t, n) {
    this.variables.set(e, new Sf(e, t, n ?? null));
  }
  setVariable(e, t, n) {
    const r = this.getVariable(e);
    r !== null ? r.value = t : this.createVariable(e, t, n);
  }
  getVariableValue(e) {
    var t;
    const n = this.getVariable(e);
    return (t = n?.value) !== null && t !== void 0 ? t : null;
  }
  clone() {
    return new il(this);
  }
}, Qf = class {
  evalExpression(e, t) {
    return null;
  }
  getTypeInfo(e) {
    return null;
  }
  getVariableName(e, t) {
    return "";
  }
}, Df = class {
  constructor(e) {
    this.exec = e;
  }
  getTypeInfo(e) {
    return this.exec.getTypeInfo(e);
  }
  All(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    let r = !0;
    if (n instanceof m) return n.data.forEach((s) => {
      s || (r = !1);
    }), new b(r ? 1 : 0, this.getTypeInfo("bool"));
    throw new Error(`All() expects a vector argument. Line ${e.line}`);
  }
  Any(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) {
      const r = n.data.some((s) => s);
      return new b(r ? 1 : 0, this.getTypeInfo("bool"));
    }
    throw new Error(`Any() expects a vector argument. Line ${e.line}`);
  }
  Select(e, t) {
    const n = this.exec.evalExpression(e.args[2], t);
    if (!(n instanceof b)) throw new Error(`Select() expects a bool condition. Line ${e.line}`);
    return n.value ? this.exec.evalExpression(e.args[1], t) : this.exec.evalExpression(e.args[0], t);
  }
  ArrayLength(e, t) {
    let n = e.args[0];
    n instanceof pe && (n = n.right);
    const r = this.exec.evalExpression(n, t);
    if (r instanceof Ae && r.typeInfo.size === 0) {
      const s = r.typeInfo, o = r.buffer.byteLength / s.stride;
      return new b(o, this.getTypeInfo("u32"));
    }
    return new b(r.typeInfo.size, this.getTypeInfo("u32"));
  }
  Abs(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.abs(s)), n.typeInfo);
    const r = n;
    return new b(Math.abs(r.value), r.typeInfo);
  }
  Acos(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.acos(s)), n.typeInfo);
    const r = n;
    return new b(Math.acos(r.value), n.typeInfo);
  }
  Acosh(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.acosh(s)), n.typeInfo);
    const r = n;
    return new b(Math.acosh(r.value), n.typeInfo);
  }
  Asin(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.asin(s)), n.typeInfo);
    const r = n;
    return new b(Math.asin(r.value), n.typeInfo);
  }
  Asinh(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.asinh(s)), n.typeInfo);
    const r = n;
    return new b(Math.asinh(r.value), n.typeInfo);
  }
  Atan(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.atan(s)), n.typeInfo);
    const r = n;
    return new b(Math.atan(r.value), n.typeInfo);
  }
  Atanh(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.atanh(s)), n.typeInfo);
    const r = n;
    return new b(Math.atanh(r.value), n.typeInfo);
  }
  Atan2(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t);
    if (n instanceof m && r instanceof m) return new m(n.data.map((i, l) => Math.atan2(i, r.data[l])), n.typeInfo);
    const s = n, o = r;
    return new b(Math.atan2(s.value, o.value), n.typeInfo);
  }
  Ceil(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.ceil(s)), n.typeInfo);
    const r = n;
    return new b(Math.ceil(r.value), n.typeInfo);
  }
  _clamp(e, t, n) {
    return Math.min(Math.max(e, t), n);
  }
  Clamp(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t), s = this.exec.evalExpression(e.args[2], t);
    if (n instanceof m && r instanceof m && s instanceof m) return new m(n.data.map((u, c) => this._clamp(u, r.data[c], s.data[c])), n.typeInfo);
    const o = n, i = r, l = s;
    return new b(this._clamp(o.value, i.value, l.value), n.typeInfo);
  }
  Cos(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.cos(s)), n.typeInfo);
    const r = n;
    return new b(Math.cos(r.value), n.typeInfo);
  }
  Cosh(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.cosh(s)), n.typeInfo);
    const r = n;
    return new b(Math.cos(r.value), n.typeInfo);
  }
  CountLeadingZeros(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.clz32(s)), n.typeInfo);
    const r = n;
    return new b(Math.clz32(r.value), n.typeInfo);
  }
  _countOneBits(e) {
    let t = 0;
    for (; e !== 0; ) 1 & e && t++, e >>= 1;
    return t;
  }
  CountOneBits(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => this._countOneBits(s)), n.typeInfo);
    const r = n;
    return new b(this._countOneBits(r.value), n.typeInfo);
  }
  _countTrailingZeros(e) {
    if (e === 0) return 32;
    let t = 0;
    for (; !(1 & e); ) e >>= 1, t++;
    return t;
  }
  CountTrailingZeros(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => this._countTrailingZeros(s)), n.typeInfo);
    const r = n;
    return new b(this._countTrailingZeros(r.value), n.typeInfo);
  }
  Cross(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t);
    if (n instanceof m && r instanceof m) {
      if (n.data.length !== 3 || r.data.length !== 3) return console.error(`Cross() expects 3D vectors. Line ${e.line}`), null;
      const s = n.data, o = r.data;
      return new m([s[1] * o[2] - o[1] * s[2], s[2] * o[0] - o[2] * s[0], s[0] * o[1] - o[0] * s[1]], n.typeInfo);
    }
    return console.error(`Cross() expects vector arguments. Line ${e.line}`), null;
  }
  Degrees(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = 180 / Math.PI;
    return n instanceof m ? new m(n.data.map((s) => s * r), n.typeInfo) : new b(n.value * r, this.getTypeInfo("f32"));
  }
  Determinant(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof H) {
      const r = n.data, s = n.typeInfo.getTypeName(), o = s.endsWith("h") ? this.getTypeInfo("f16") : this.getTypeInfo("f32");
      if (s === "mat2x2" || s === "mat2x2f" || s === "mat2x2h") return new b(r[0] * r[3] - r[1] * r[2], o);
      if (s === "mat2x3" || s === "mat2x3f" || s === "mat2x3h") return new b(r[0] * (r[4] * r[8] - r[5] * r[7]) - r[1] * (r[3] * r[8] - r[5] * r[6]) + r[2] * (r[3] * r[7] - r[4] * r[6]), o);
      if (s === "mat2x4" || s === "mat2x4f" || s === "mat2x4h") console.error(`TODO: Determinant for ${s}`);
      else if (s === "mat3x2" || s === "mat3x2f" || s === "mat3x2h") console.error(`TODO: Determinant for ${s}`);
      else {
        if (s === "mat3x3" || s === "mat3x3f" || s === "mat3x3h") return new b(r[0] * (r[4] * r[8] - r[5] * r[7]) - r[1] * (r[3] * r[8] - r[5] * r[6]) + r[2] * (r[3] * r[7] - r[4] * r[6]), o);
        s === "mat3x4" || s === "mat3x4f" || s === "mat3x4h" || s === "mat4x2" || s === "mat4x2f" || s === "mat4x2h" || s === "mat4x3" || s === "mat4x3f" || s === "mat4x3h" ? console.error(`TODO: Determinant for ${s}`) : s !== "mat4x4" && s !== "mat4x4f" && s !== "mat4x4h" || console.error(`TODO: Determinant for ${s}`);
      }
    }
    return console.error(`Determinant expects a matrix argument. Line ${e.line}`), null;
  }
  Distance(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t);
    if (n instanceof m && r instanceof m) {
      let i = 0;
      for (let l = 0; l < n.data.length; ++l) i += (n.data[l] - r.data[l]) * (n.data[l] - r.data[l]);
      return new b(Math.sqrt(i), this.getTypeInfo("f32"));
    }
    const s = n, o = r;
    return new b(Math.abs(s.value - o.value), n.typeInfo);
  }
  _dot(e, t) {
    let n = 0;
    for (let r = 0; r < e.length; ++r) n += t[r] * e[r];
    return n;
  }
  Dot(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t);
    return n instanceof m && r instanceof m ? new b(this._dot(n.data, r.data), this.getTypeInfo("f32")) : (console.error(`Dot() expects vector arguments. Line ${e.line}`), null);
  }
  Dot4U8Packed(e, t) {
    return console.error(`TODO: dot4U8Packed. Line ${e.line}`), null;
  }
  Dot4I8Packed(e, t) {
    return console.error(`TODO: dot4I8Packed. Line ${e.line}`), null;
  }
  Exp(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.exp(s)), n.typeInfo);
    const r = n;
    return new b(Math.exp(r.value), n.typeInfo);
  }
  Exp2(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.pow(2, s)), n.typeInfo);
    const r = n;
    return new b(Math.pow(2, r.value), n.typeInfo);
  }
  ExtractBits(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t), s = this.exec.evalExpression(e.args[2], t);
    if (r.typeInfo.name !== "u32" && r.typeInfo.name !== "x32") return console.error(`ExtractBits() expects an i32 offset argument. Line ${e.line}`), null;
    if (s.typeInfo.name !== "u32" && s.typeInfo.name !== "x32") return console.error(`ExtractBits() expects an i32 count argument. Line ${e.line}`), null;
    const o = r.value, i = s.value;
    if (n instanceof m) return new m(n.data.map((u) => u >> o & (1 << i) - 1), n.typeInfo);
    if (n.typeInfo.name !== "i32" && n.typeInfo.name !== "x32") return console.error(`ExtractBits() expects an i32 argument. Line ${e.line}`), null;
    const l = n.value;
    return new b(l >> o & (1 << i) - 1, this.getTypeInfo("i32"));
  }
  FaceForward(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t), s = this.exec.evalExpression(e.args[2], t);
    if (n instanceof m && r instanceof m && s instanceof m) {
      const o = this._dot(r.data, s.data);
      return new m(o < 0 ? Array.from(n.data) : n.data.map((i) => -i), n.typeInfo);
    }
    return console.error(`FaceForward() expects vector arguments. Line ${e.line}`), null;
  }
  _firstLeadingBit(e) {
    return e === 0 ? -1 : 31 - Math.clz32(e);
  }
  FirstLeadingBit(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => this._firstLeadingBit(s)), n.typeInfo);
    const r = n;
    return new b(this._firstLeadingBit(r.value), n.typeInfo);
  }
  _firstTrailingBit(e) {
    return e === 0 ? -1 : Math.log2(e & -e);
  }
  FirstTrailingBit(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => this._firstTrailingBit(s)), n.typeInfo);
    const r = n;
    return new b(this._firstTrailingBit(r.value), n.typeInfo);
  }
  Floor(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.floor(s)), n.typeInfo);
    const r = n;
    return new b(Math.floor(r.value), n.typeInfo);
  }
  Fma(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t), s = this.exec.evalExpression(e.args[2], t);
    if (n instanceof m && r instanceof m && s instanceof m) return n.data.length !== r.data.length || n.data.length !== s.data.length ? (console.error(`Fma() expects vectors of the same length. Line ${e.line}`), null) : new m(n.data.map((u, c) => u * r.data[c] + s.data[c]), n.typeInfo);
    const o = n, i = r, l = s;
    return new b(o.value * i.value + l.value, o.typeInfo);
  }
  Fract(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => s - Math.floor(s)), n.typeInfo);
    const r = n;
    return new b(r.value - Math.floor(r.value), n.typeInfo);
  }
  Frexp(e, t) {
    return console.error(`TODO: frexp. Line ${e.line}`), null;
  }
  InsertBits(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t), s = this.exec.evalExpression(e.args[2], t), o = this.exec.evalExpression(e.args[3], t);
    if (s.typeInfo.name !== "u32" && s.typeInfo.name !== "x32") return console.error(`InsertBits() expects an i32 offset argument. Line ${e.line}`), null;
    const i = s.value, l = (1 << o.value) - 1 << i, u = ~l;
    if (n instanceof m && r instanceof m) return new m(n.data.map((h, p) => h & u | r.data[p] << i & l), n.typeInfo);
    const c = n.value, f = r.value;
    return new b(c & u | f << i & l, n.typeInfo);
  }
  InverseSqrt(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => 1 / Math.sqrt(s)), n.typeInfo);
    const r = n;
    return new b(1 / Math.sqrt(r.value), n.typeInfo);
  }
  Ldexp(e, t) {
    return console.error(`TODO: ldexp. Line ${e.line}`), null;
  }
  Length(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) {
      let s = 0;
      return n.data.forEach((o) => {
        s += o * o;
      }), new b(Math.sqrt(s), this.getTypeInfo("f32"));
    }
    const r = n;
    return new b(Math.abs(r.value), n.typeInfo);
  }
  Log(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.log(s)), n.typeInfo);
    const r = n;
    return new b(Math.log(r.value), n.typeInfo);
  }
  Log2(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.log2(s)), n.typeInfo);
    const r = n;
    return new b(Math.log2(r.value), n.typeInfo);
  }
  Max(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t);
    if (n instanceof m && r instanceof m) return new m(n.data.map((i, l) => Math.max(i, r.data[l])), n.typeInfo);
    const s = n, o = r;
    return new b(Math.max(s.value, o.value), n.typeInfo);
  }
  Min(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t);
    if (n instanceof m && r instanceof m) return new m(n.data.map((i, l) => Math.min(i, r.data[l])), n.typeInfo);
    const s = n, o = r;
    return new b(Math.min(s.value, o.value), n.typeInfo);
  }
  Mix(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t), s = this.exec.evalExpression(e.args[2], t);
    if (n instanceof m && r instanceof m && s instanceof m) return new m(n.data.map((l, u) => n.data[u] * (1 - s.data[u]) + r.data[u] * s.data[u]), n.typeInfo);
    const o = r, i = s;
    return new b(n.value * (1 - i.value) + o.value * i.value, n.typeInfo);
  }
  Modf(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t);
    if (n instanceof m && r instanceof m) return new m(n.data.map((o, i) => o % r.data[i]), n.typeInfo);
    const s = r;
    return new b(n.value % s.value, n.typeInfo);
  }
  Normalize(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) {
      const r = this.Length(e, t).value;
      return new m(n.data.map((s) => s / r), n.typeInfo);
    }
    return console.error(`Normalize() expects a vector argument. Line ${e.line}`), null;
  }
  Pow(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t);
    if (n instanceof m && r instanceof m) return new m(n.data.map((i, l) => Math.pow(i, r.data[l])), n.typeInfo);
    const s = n, o = r;
    return new b(Math.pow(s.value, o.value), n.typeInfo);
  }
  QuantizeToF16(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    return n instanceof m ? new m(n.data.map((r) => r), n.typeInfo) : new b(n.value, n.typeInfo);
  }
  Radians(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    return n instanceof m ? new m(n.data.map((r) => r * Math.PI / 180), n.typeInfo) : new b(n.value * Math.PI / 180, this.getTypeInfo("f32"));
  }
  Reflect(e, t) {
    let n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t);
    if (n instanceof m && r instanceof m) {
      const s = this._dot(n.data, r.data);
      return new m(n.data.map((o, i) => o - 2 * s * r.data[i]), n.typeInfo);
    }
    return console.error(`Reflect() expects vector arguments. Line ${e.line}`), null;
  }
  Refract(e, t) {
    let n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t), s = this.exec.evalExpression(e.args[2], t);
    if (n instanceof m && r instanceof m && s instanceof b) {
      const o = this._dot(r.data, n.data);
      return new m(n.data.map((i, l) => {
        const u = 1 - s.value * s.value * (1 - o * o);
        if (u < 0) return 0;
        const c = Math.sqrt(u);
        return s.value * i - (s.value * o + c) * r.data[l];
      }), n.typeInfo);
    }
    return console.error(`Refract() expects vector arguments and a scalar argument. Line ${e.line}`), null;
  }
  ReverseBits(e, t) {
    return console.error(`TODO: reverseBits. Line ${e.line}`), null;
  }
  Round(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.round(s)), n.typeInfo);
    const r = n;
    return new b(Math.round(r.value), n.typeInfo);
  }
  Saturate(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.min(Math.max(s, 0), 1)), n.typeInfo);
    const r = n;
    return new b(Math.min(Math.max(r.value, 0), 1), n.typeInfo);
  }
  Sign(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.sign(s)), n.typeInfo);
    const r = n;
    return new b(Math.sign(r.value), n.typeInfo);
  }
  Sin(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.sin(s)), n.typeInfo);
    const r = n;
    return new b(Math.sin(r.value), n.typeInfo);
  }
  Sinh(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.sinh(s)), n.typeInfo);
    const r = n;
    return new b(Math.sinh(r.value), n.typeInfo);
  }
  _smoothstep(e, t, n) {
    const r = Math.min(Math.max((n - e) / (t - e), 0), 1);
    return r * r * (3 - 2 * r);
  }
  SmoothStep(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t), s = this.exec.evalExpression(e.args[2], t);
    if (s instanceof m && n instanceof m && r instanceof m) return new m(s.data.map((u, c) => this._smoothstep(n.data[c], r.data[c], u)), s.typeInfo);
    const o = n, i = r, l = s;
    return new b(this._smoothstep(o.value, i.value, l.value), s.typeInfo);
  }
  Sqrt(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.sqrt(s)), n.typeInfo);
    const r = n;
    return new b(Math.sqrt(r.value), n.typeInfo);
  }
  Step(e, t) {
    const n = this.exec.evalExpression(e.args[0], t), r = this.exec.evalExpression(e.args[1], t);
    if (r instanceof m && n instanceof m) return new m(r.data.map((o, i) => o < n.data[i] ? 0 : 1), r.typeInfo);
    const s = n;
    return new b(r.value < s.value ? 0 : 1, s.typeInfo);
  }
  Tan(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.tan(s)), n.typeInfo);
    const r = n;
    return new b(Math.tan(r.value), n.typeInfo);
  }
  Tanh(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.tanh(s)), n.typeInfo);
    const r = n;
    return new b(Math.tanh(r.value), n.typeInfo);
  }
  _getTransposeType(e) {
    const t = e.getTypeName();
    return t === "mat2x2f" || t === "mat2x2h" ? e : t === "mat2x3f" ? this.getTypeInfo("mat3x2f") : t === "mat2x3h" ? this.getTypeInfo("mat3x2h") : t === "mat2x4f" ? this.getTypeInfo("mat4x2f") : t === "mat2x4h" ? this.getTypeInfo("mat4x2h") : t === "mat3x2f" ? this.getTypeInfo("mat2x3f") : t === "mat3x2h" ? this.getTypeInfo("mat2x3h") : t === "mat3x3f" || t === "mat3x3h" ? e : t === "mat3x4f" ? this.getTypeInfo("mat4x3f") : t === "mat3x4h" ? this.getTypeInfo("mat4x3h") : t === "mat4x2f" ? this.getTypeInfo("mat2x4f") : t === "mat4x2h" ? this.getTypeInfo("mat2x4h") : t === "mat4x3f" ? this.getTypeInfo("mat3x4f") : t === "mat4x3h" ? this.getTypeInfo("mat3x4h") : (t === "mat4x4f" || t === "mat4x4h" || console.error(`Invalid matrix type ${t}`), e);
  }
  Transpose(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (!(n instanceof H)) return console.error(`Transpose() expects a matrix argument. Line ${e.line}`), null;
    const r = this._getTransposeType(n.typeInfo);
    if (n.typeInfo.name === "mat2x2" || n.typeInfo.name === "mat2x2f" || n.typeInfo.name === "mat2x2h") {
      const s = n.data;
      return new H([s[0], s[2], s[1], s[3]], r);
    }
    if (n.typeInfo.name === "mat2x3" || n.typeInfo.name === "mat2x3f" || n.typeInfo.name === "mat2x3h") {
      const s = n.data;
      return new H([s[0], s[3], s[6], s[1], s[4], s[7]], r);
    }
    if (n.typeInfo.name === "mat2x4" || n.typeInfo.name === "mat2x4f" || n.typeInfo.name === "mat2x4h") {
      const s = n.data;
      return new H([s[0], s[4], s[8], s[12], s[1], s[5], s[9], s[13]], r);
    }
    if (n.typeInfo.name === "mat3x2" || n.typeInfo.name === "mat3x2f" || n.typeInfo.name === "mat3x2h") {
      const s = n.data;
      return new H([s[0], s[3], s[1], s[4], s[2], s[5]], r);
    }
    if (n.typeInfo.name === "mat3x3" || n.typeInfo.name === "mat3x3f" || n.typeInfo.name === "mat3x3h") {
      const s = n.data;
      return new H([s[0], s[3], s[6], s[1], s[4], s[7], s[2], s[5], s[8]], r);
    }
    if (n.typeInfo.name === "mat3x4" || n.typeInfo.name === "mat3x4f" || n.typeInfo.name === "mat3x4h") {
      const s = n.data;
      return new H([s[0], s[4], s[8], s[12], s[1], s[5], s[9], s[13], s[2], s[6], s[10], s[14]], r);
    }
    if (n.typeInfo.name === "mat4x2" || n.typeInfo.name === "mat4x2f" || n.typeInfo.name === "mat4x2h") {
      const s = n.data;
      return new H([s[0], s[4], s[1], s[5], s[2], s[6]], r);
    }
    if (n.typeInfo.name === "mat4x3" || n.typeInfo.name === "mat4x3f" || n.typeInfo.name === "mat4x3h") {
      const s = n.data;
      return new H([s[0], s[4], s[8], s[1], s[5], s[9], s[2], s[6], s[10]], r);
    }
    if (n.typeInfo.name === "mat4x4" || n.typeInfo.name === "mat4x4f" || n.typeInfo.name === "mat4x4h") {
      const s = n.data;
      return new H([s[0], s[4], s[8], s[12], s[1], s[5], s[9], s[13], s[2], s[6], s[10], s[14], s[3], s[7], s[11], s[15]], r);
    }
    return console.error(`Invalid matrix type ${n.typeInfo.name}`), null;
  }
  Trunc(e, t) {
    const n = this.exec.evalExpression(e.args[0], t);
    if (n instanceof m) return new m(n.data.map((s) => Math.trunc(s)), n.typeInfo);
    const r = n;
    return new b(Math.trunc(r.value), n.typeInfo);
  }
  Dpdx(e, t) {
    return console.error(`TODO: dpdx. Line ${e.line}`), null;
  }
  DpdxCoarse(e, t) {
    return console.error(`TODO: dpdxCoarse. Line ${e.line}`), null;
  }
  DpdxFine(e, t) {
    return console.error("TODO: dpdxFine"), null;
  }
  Dpdy(e, t) {
    return console.error("TODO: dpdy"), null;
  }
  DpdyCoarse(e, t) {
    return console.error("TODO: dpdyCoarse"), null;
  }
  DpdyFine(e, t) {
    return console.error("TODO: dpdyFine"), null;
  }
  Fwidth(e, t) {
    return console.error("TODO: fwidth"), null;
  }
  FwidthCoarse(e, t) {
    return console.error("TODO: fwidthCoarse"), null;
  }
  FwidthFine(e, t) {
    return console.error("TODO: fwidthFine"), null;
  }
  TextureDimensions(e, t) {
    const n = e.args[0], r = e.args.length > 1 ? this.exec.evalExpression(e.args[1], t).value : 0;
    if (n instanceof ke) {
      const s = n.name, o = t.getVariableValue(s);
      if (o instanceof at) {
        if (r < 0 || r >= o.mipLevelCount) return console.error(`Invalid mip level for textureDimensions. Line ${e.line}`), null;
        const i = o.getMipLevelSize(r), l = o.dimension;
        return l === "1d" ? new b(i[0], this.getTypeInfo("u32")) : l === "3d" ? new m(i, this.getTypeInfo("vec3u")) : l === "2d" ? new m(i.slice(0, 2), this.getTypeInfo("vec2u")) : (console.error(`Invalid texture dimension ${l} not found. Line ${e.line}`), null);
      }
      return console.error(`Texture ${s} not found. Line ${e.line}`), null;
    }
    return console.error(`Invalid texture argument for textureDimensions. Line ${e.line}`), null;
  }
  TextureGather(e, t) {
    return console.error("TODO: textureGather"), null;
  }
  TextureGatherCompare(e, t) {
    return console.error("TODO: textureGatherCompare"), null;
  }
  TextureLoad(e, t) {
    const n = e.args[0], r = this.exec.evalExpression(e.args[1], t), s = e.args.length > 2 ? this.exec.evalExpression(e.args[2], t).value : 0;
    if (!(r instanceof m) || r.data.length !== 2) return console.error(`Invalid UV argument for textureLoad. Line ${e.line}`), null;
    if (n instanceof ke) {
      const o = n.name, i = t.getVariableValue(o);
      if (i instanceof at) {
        const l = Math.floor(r.data[0]), u = Math.floor(r.data[1]);
        if (l < 0 || l >= i.width || u < 0 || u >= i.height) return console.error(`Texture ${o} out of bounds. Line ${e.line}`), null;
        const c = i.getPixel(l, u, 0, s);
        return c === null ? (console.error(`Invalid texture format for textureLoad. Line ${e.line}`), null) : new m(c, this.getTypeInfo("vec4f"));
      }
      return console.error(`Texture ${o} not found. Line ${e.line}`), null;
    }
    return console.error(`Invalid texture argument for textureLoad. Line ${e.line}`), null;
  }
  TextureNumLayers(e, t) {
    const n = e.args[0];
    if (n instanceof ke) {
      const r = n.name, s = t.getVariableValue(r);
      return s instanceof at ? new b(s.depthOrArrayLayers, this.getTypeInfo("u32")) : (console.error(`Texture ${r} not found. Line ${e.line}`), null);
    }
    return console.error(`Invalid texture argument for textureNumLayers. Line ${e.line}`), null;
  }
  TextureNumLevels(e, t) {
    const n = e.args[0];
    if (n instanceof ke) {
      const r = n.name, s = t.getVariableValue(r);
      return s instanceof at ? new b(s.mipLevelCount, this.getTypeInfo("u32")) : (console.error(`Texture ${r} not found. Line ${e.line}`), null);
    }
    return console.error(`Invalid texture argument for textureNumLevels. Line ${e.line}`), null;
  }
  TextureNumSamples(e, t) {
    const n = e.args[0];
    if (n instanceof ke) {
      const r = n.name, s = t.getVariableValue(r);
      return s instanceof at ? new b(s.sampleCount, this.getTypeInfo("u32")) : (console.error(`Texture ${r} not found. Line ${e.line}`), null);
    }
    return console.error(`Invalid texture argument for textureNumSamples. Line ${e.line}`), null;
  }
  TextureSample(e, t) {
    return console.error("TODO: textureSample"), null;
  }
  TextureSampleBias(e, t) {
    return console.error("TODO: textureSampleBias"), null;
  }
  TextureSampleCompare(e, t) {
    return console.error("TODO: textureSampleCompare"), null;
  }
  TextureSampleCompareLevel(e, t) {
    return console.error("TODO: textureSampleCompareLevel"), null;
  }
  TextureSampleGrad(e, t) {
    return console.error("TODO: textureSampleGrad"), null;
  }
  TextureSampleLevel(e, t) {
    return console.error("TODO: textureSampleLevel"), null;
  }
  TextureSampleBaseClampToEdge(e, t) {
    return console.error("TODO: textureSampleBaseClampToEdge"), null;
  }
  TextureStore(e, t) {
    const n = e.args[0], r = this.exec.evalExpression(e.args[1], t), s = e.args.length === 4 ? this.exec.evalExpression(e.args[2], t).value : 0, o = e.args.length === 4 ? this.exec.evalExpression(e.args[3], t).data : this.exec.evalExpression(e.args[2], t).data;
    if (o.length !== 4) return console.error(`Invalid value argument for textureStore. Line ${e.line}`), null;
    if (!(r instanceof m) || r.data.length !== 2) return console.error(`Invalid UV argument for textureStore. Line ${e.line}`), null;
    if (n instanceof ke) {
      const i = n.name, l = t.getVariableValue(i);
      if (l instanceof at) {
        const u = l.getMipLevelSize(0), c = Math.floor(r.data[0]), f = Math.floor(r.data[1]);
        return c < 0 || c >= u[0] || f < 0 || f >= u[1] ? (console.error(`Texture ${i} out of bounds. Line ${e.line}`), null) : (l.setPixel(c, f, 0, s, Array.from(o)), null);
      }
      return console.error(`Texture ${i} not found. Line ${e.line}`), null;
    }
    return console.error(`Invalid texture argument for textureStore. Line ${e.line}`), null;
  }
  AtomicLoad(e, t) {
    let n = e.args[0];
    n instanceof pe && (n = n.right);
    const r = this.exec.getVariableName(n, t);
    return t.getVariable(r).value.getSubData(this.exec, n.postfix, t);
  }
  AtomicStore(e, t) {
    let n = e.args[0];
    n instanceof pe && (n = n.right);
    const r = this.exec.getVariableName(n, t), s = t.getVariable(r);
    let o = e.args[1];
    const i = this.exec.evalExpression(o, t), l = s.value.getSubData(this.exec, n.postfix, t);
    return l instanceof b && i instanceof b && (l.value = i.value), s.value instanceof Ae && s.value.setDataValue(this.exec, l, n.postfix, t), null;
  }
  AtomicAdd(e, t) {
    let n = e.args[0];
    n instanceof pe && (n = n.right);
    const r = this.exec.getVariableName(n, t), s = t.getVariable(r);
    let o = e.args[1];
    const i = this.exec.evalExpression(o, t), l = s.value.getSubData(this.exec, n.postfix, t), u = new b(l.value, l.typeInfo);
    return l instanceof b && i instanceof b && (l.value += i.value), s.value instanceof Ae && s.value.setDataValue(this.exec, l, n.postfix, t), u;
  }
  AtomicSub(e, t) {
    let n = e.args[0];
    n instanceof pe && (n = n.right);
    const r = this.exec.getVariableName(n, t), s = t.getVariable(r);
    let o = e.args[1];
    const i = this.exec.evalExpression(o, t), l = s.value.getSubData(this.exec, n.postfix, t), u = new b(l.value, l.typeInfo);
    return l instanceof b && i instanceof b && (l.value -= i.value), s.value instanceof Ae && s.value.setDataValue(this.exec, l, n.postfix, t), u;
  }
  AtomicMax(e, t) {
    let n = e.args[0];
    n instanceof pe && (n = n.right);
    const r = this.exec.getVariableName(n, t), s = t.getVariable(r);
    let o = e.args[1];
    const i = this.exec.evalExpression(o, t), l = s.value.getSubData(this.exec, n.postfix, t), u = new b(l.value, l.typeInfo);
    return l instanceof b && i instanceof b && (l.value = Math.max(l.value, i.value)), s.value instanceof Ae && s.value.setDataValue(this.exec, l, n.postfix, t), u;
  }
  AtomicMin(e, t) {
    let n = e.args[0];
    n instanceof pe && (n = n.right);
    const r = this.exec.getVariableName(n, t), s = t.getVariable(r);
    let o = e.args[1];
    const i = this.exec.evalExpression(o, t), l = s.value.getSubData(this.exec, n.postfix, t), u = new b(l.value, l.typeInfo);
    return l instanceof b && i instanceof b && (l.value = Math.min(l.value, i.value)), s.value instanceof Ae && s.value.setDataValue(this.exec, l, n.postfix, t), u;
  }
  AtomicAnd(e, t) {
    let n = e.args[0];
    n instanceof pe && (n = n.right);
    const r = this.exec.getVariableName(n, t), s = t.getVariable(r);
    let o = e.args[1];
    const i = this.exec.evalExpression(o, t), l = s.value.getSubData(this.exec, n.postfix, t), u = new b(l.value, l.typeInfo);
    return l instanceof b && i instanceof b && (l.value = l.value & i.value), s.value instanceof Ae && s.value.setDataValue(this.exec, l, n.postfix, t), u;
  }
  AtomicOr(e, t) {
    let n = e.args[0];
    n instanceof pe && (n = n.right);
    const r = this.exec.getVariableName(n, t), s = t.getVariable(r);
    let o = e.args[1];
    const i = this.exec.evalExpression(o, t), l = s.value.getSubData(this.exec, n.postfix, t), u = new b(l.value, l.typeInfo);
    return l instanceof b && i instanceof b && (l.value = l.value | i.value), s.value instanceof Ae && s.value.setDataValue(this.exec, l, n.postfix, t), u;
  }
  AtomicXor(e, t) {
    let n = e.args[0];
    n instanceof pe && (n = n.right);
    const r = this.exec.getVariableName(n, t), s = t.getVariable(r);
    let o = e.args[1];
    const i = this.exec.evalExpression(o, t), l = s.value.getSubData(this.exec, n.postfix, t), u = new b(l.value, l.typeInfo);
    return l instanceof b && i instanceof b && (l.value = l.value ^ i.value), s.value instanceof Ae && s.value.setDataValue(this.exec, l, n.postfix, t), u;
  }
  AtomicExchange(e, t) {
    let n = e.args[0];
    n instanceof pe && (n = n.right);
    const r = this.exec.getVariableName(n, t), s = t.getVariable(r);
    let o = e.args[1];
    const i = this.exec.evalExpression(o, t), l = s.value.getSubData(this.exec, n.postfix, t), u = new b(l.value, l.typeInfo);
    return l instanceof b && i instanceof b && (l.value = i.value), s.value instanceof Ae && s.value.setDataValue(this.exec, l, n.postfix, t), u;
  }
  AtomicCompareExchangeWeak(e, t) {
    return console.error("TODO: atomicCompareExchangeWeak"), null;
  }
  Pack4x8snorm(e, t) {
    return console.error("TODO: pack4x8snorm"), null;
  }
  Pack4x8unorm(e, t) {
    return console.error("TODO: pack4x8unorm"), null;
  }
  Pack4xI8(e, t) {
    return console.error("TODO: pack4xI8"), null;
  }
  Pack4xU8(e, t) {
    return console.error("TODO: pack4xU8"), null;
  }
  Pack4x8Clamp(e, t) {
    return console.error("TODO: pack4x8Clamp"), null;
  }
  Pack4xU8Clamp(e, t) {
    return console.error("TODO: pack4xU8Clamp"), null;
  }
  Pack2x16snorm(e, t) {
    return console.error("TODO: pack2x16snorm"), null;
  }
  Pack2x16unorm(e, t) {
    return console.error("TODO: pack2x16unorm"), null;
  }
  Pack2x16float(e, t) {
    return console.error("TODO: pack2x16float"), null;
  }
  Unpack4x8snorm(e, t) {
    return console.error("TODO: unpack4x8snorm"), null;
  }
  Unpack4x8unorm(e, t) {
    return console.error("TODO: unpack4x8unorm"), null;
  }
  Unpack4xI8(e, t) {
    return console.error("TODO: unpack4xI8"), null;
  }
  Unpack4xU8(e, t) {
    return console.error("TODO: unpack4xU8"), null;
  }
  Unpack2x16snorm(e, t) {
    return console.error("TODO: unpack2x16snorm"), null;
  }
  Unpack2x16unorm(e, t) {
    return console.error("TODO: unpack2x16unorm"), null;
  }
  Unpack2x16float(e, t) {
    return console.error("TODO: unpack2x16float"), null;
  }
  StorageBarrier(e, t) {
    return null;
  }
  TextureBarrier(e, t) {
    return null;
  }
  WorkgroupBarrier(e, t) {
    return null;
  }
  WorkgroupUniformLoad(e, t) {
    return null;
  }
  SubgroupAdd(e, t) {
    return console.error("TODO: subgroupAdd"), null;
  }
  SubgroupExclusiveAdd(e, t) {
    return console.error("TODO: subgroupExclusiveAdd"), null;
  }
  SubgroupInclusiveAdd(e, t) {
    return console.error("TODO: subgroupInclusiveAdd"), null;
  }
  SubgroupAll(e, t) {
    return console.error("TODO: subgroupAll"), null;
  }
  SubgroupAnd(e, t) {
    return console.error("TODO: subgroupAnd"), null;
  }
  SubgroupAny(e, t) {
    return console.error("TODO: subgroupAny"), null;
  }
  SubgroupBallot(e, t) {
    return console.error("TODO: subgroupBallot"), null;
  }
  SubgroupBroadcast(e, t) {
    return console.error("TODO: subgroupBroadcast"), null;
  }
  SubgroupBroadcastFirst(e, t) {
    return console.error("TODO: subgroupBroadcastFirst"), null;
  }
  SubgroupElect(e, t) {
    return console.error("TODO: subgroupElect"), null;
  }
  SubgroupMax(e, t) {
    return console.error("TODO: subgroupMax"), null;
  }
  SubgroupMin(e, t) {
    return console.error("TODO: subgroupMin"), null;
  }
  SubgroupMul(e, t) {
    return console.error("TODO: subgroupMul"), null;
  }
  SubgroupExclusiveMul(e, t) {
    return console.error("TODO: subgroupExclusiveMul"), null;
  }
  SubgroupInclusiveMul(e, t) {
    return console.error("TODO: subgroupInclusiveMul"), null;
  }
  SubgroupOr(e, t) {
    return console.error("TODO: subgroupOr"), null;
  }
  SubgroupShuffle(e, t) {
    return console.error("TODO: subgroupShuffle"), null;
  }
  SubgroupShuffleDown(e, t) {
    return console.error("TODO: subgroupShuffleDown"), null;
  }
  SubgroupShuffleUp(e, t) {
    return console.error("TODO: subgroupShuffleUp"), null;
  }
  SubgroupShuffleXor(e, t) {
    return console.error("TODO: subgroupShuffleXor"), null;
  }
  SubgroupXor(e, t) {
    return console.error("TODO: subgroupXor"), null;
  }
  QuadBroadcast(e, t) {
    return console.error("TODO: quadBroadcast"), null;
  }
  QuadSwapDiagonal(e, t) {
    return console.error("TODO: quadSwapDiagonal"), null;
  }
  QuadSwapX(e, t) {
    return console.error("TODO: quadSwapX"), null;
  }
  QuadSwapY(e, t) {
    return console.error("TODO: quadSwapY"), null;
  }
};
const Pr = { vec2: 2, vec2f: 2, vec2i: 2, vec2u: 2, vec2b: 2, vec2h: 2, vec3: 3, vec3f: 3, vec3i: 3, vec3u: 3, vec3b: 3, vec3h: 3, vec4: 4, vec4f: 4, vec4i: 4, vec4u: 4, vec4b: 4, vec4h: 4 }, we = { mat2x2: [2, 2, 4], mat2x2f: [2, 2, 4], mat2x2h: [2, 2, 4], mat2x3: [2, 3, 6], mat2x3f: [2, 3, 6], mat2x3h: [2, 3, 6], mat2x4: [2, 4, 8], mat2x4f: [2, 4, 8], mat2x4h: [2, 4, 8], mat3x2: [3, 2, 6], mat3x2f: [3, 2, 6], mat3x2h: [3, 2, 6], mat3x3: [3, 3, 9], mat3x3f: [3, 3, 9], mat3x3h: [3, 3, 9], mat3x4: [3, 4, 12], mat3x4f: [3, 4, 12], mat3x4h: [3, 4, 12], mat4x2: [4, 2, 8], mat4x2f: [4, 2, 8], mat4x2h: [4, 2, 8], mat4x3: [4, 3, 12], mat4x3f: [4, 3, 12], mat4x3h: [4, 3, 12], mat4x4: [4, 4, 16], mat4x4f: [4, 4, 16], mat4x4h: [4, 4, 16] };
let vn = class Be extends Qf {
  constructor(e, t) {
    var n;
    super(), this.ast = e ?? [], this.reflection = new zt(), this.reflection.updateAST(this.ast), this.context = (n = t?.clone()) !== null && n !== void 0 ? n : new Mf(), this.builtins = new Df(this), this.typeInfo = { bool: this.getTypeInfo(k.bool), i32: this.getTypeInfo(k.i32), u32: this.getTypeInfo(k.u32), f32: this.getTypeInfo(k.f32), f16: this.getTypeInfo(k.f16), vec2f: this.getTypeInfo(x.vec2f), vec2u: this.getTypeInfo(x.vec2u), vec2i: this.getTypeInfo(x.vec2i), vec2h: this.getTypeInfo(x.vec2h), vec3f: this.getTypeInfo(x.vec3f), vec3u: this.getTypeInfo(x.vec3u), vec3i: this.getTypeInfo(x.vec3i), vec3h: this.getTypeInfo(x.vec3h), vec4f: this.getTypeInfo(x.vec4f), vec4u: this.getTypeInfo(x.vec4u), vec4i: this.getTypeInfo(x.vec4i), vec4h: this.getTypeInfo(x.vec4h), mat2x2f: this.getTypeInfo(x.mat2x2f), mat2x3f: this.getTypeInfo(x.mat2x3f), mat2x4f: this.getTypeInfo(x.mat2x4f), mat3x2f: this.getTypeInfo(x.mat3x2f), mat3x3f: this.getTypeInfo(x.mat3x3f), mat3x4f: this.getTypeInfo(x.mat3x4f), mat4x2f: this.getTypeInfo(x.mat4x2f), mat4x3f: this.getTypeInfo(x.mat4x3f), mat4x4f: this.getTypeInfo(x.mat4x4f) };
  }
  getVariableValue(e) {
    var t, n;
    const r = (n = (t = this.context.getVariable(e)) === null || t === void 0 ? void 0 : t.value) !== null && n !== void 0 ? n : null;
    if (r === null) return null;
    if (r instanceof b) return r.value;
    if (r instanceof m || r instanceof H) return Array.from(r.data);
    if (r instanceof Ae && r.typeInfo instanceof et) {
      if (r.typeInfo.format.name === "u32") return Array.from(new Uint32Array(r.buffer, r.offset, r.typeInfo.count));
      if (r.typeInfo.format.name === "i32") return Array.from(new Int32Array(r.buffer, r.offset, r.typeInfo.count));
      if (r.typeInfo.format.name === "f32") return Array.from(new Float32Array(r.buffer, r.offset, r.typeInfo.count));
    }
    return console.error(`Unsupported return variable type ${r.typeInfo.name}`), null;
  }
  execute(e) {
    (e = e ?? {}).constants && this._setOverrides(e.constants, this.context), this._execStatements(this.ast, this.context);
  }
  dispatchWorkgroups(e, t, n, r) {
    const s = this.context.clone();
    (r = r ?? {}).constants && this._setOverrides(r.constants, s), this._execStatements(this.ast, s);
    const o = s.getFunction(e);
    if (!o) return void console.error(`Function ${e} not found`);
    if (typeof t == "number") t = [t, 1, 1];
    else {
      if (t.length === 0) return void console.error("Invalid dispatch count");
      t.length === 1 ? t = [t[0], 1, 1] : t.length === 2 ? t = [t[0], t[1], 1] : t.length > 3 && (t = [t[0], t[1], t[2]]);
    }
    const i = t[0], l = t[1], u = t[2], c = this.getTypeInfo("vec3u");
    s.setVariable("@num_workgroups", new m(t, c));
    const f = this.reflection.getFunctionInfo(e);
    f === null && console.error(`Function ${e} not found in reflection data`);
    for (const h in n) for (const p in n[h]) {
      const v = n[h][p];
      s.variables.forEach((I) => {
        var y;
        const T = I.node;
        if (T?.attributes) {
          let L = null, E = null;
          for (const C of T.attributes) C.name === "binding" ? L = C.value : C.name === "group" && (E = C.value);
          if (p == L && h == E) {
            let C = !1;
            for (const Q of f.resources) if (Q.name === I.name && Q.group === parseInt(h) && Q.binding === parseInt(p)) {
              C = !0;
              break;
            }
            if (C) if (v.texture !== void 0 && v.descriptor !== void 0) {
              const Q = new at(v.texture, this.getTypeInfo(T.type), v.descriptor, (y = v.texture.view) !== null && y !== void 0 ? y : null);
              I.value = Q;
            } else v.uniform !== void 0 ? I.value = new Ae(v.uniform, this.getTypeInfo(T.type)) : I.value = new Ae(v, this.getTypeInfo(T.type));
          }
        }
      });
    }
    for (let h = 0; h < u; ++h) for (let p = 0; p < l; ++p) for (let v = 0; v < i; ++v) s.setVariable("@workgroup_id", new m([v, p, h], this.getTypeInfo("vec3u"))), this._dispatchWorkgroup(o, [v, p, h], s);
  }
  execStatement(e, t) {
    if (e instanceof Jo) return this.evalExpression(e.value, t);
    if (e instanceof Ho) {
      if (e.condition) {
        const n = this.evalExpression(e.condition, t);
        if (!(n instanceof b)) throw new Error("Invalid break-if condition");
        if (!n.value) return null;
      }
      return Be._breakObj;
    }
    if (e instanceof Zo) return Be._continueObj;
    if (e instanceof Gt) this._let(e, t);
    else if (e instanceof He) this._var(e, t);
    else if (e instanceof gn) this._const(e, t);
    else if (e instanceof jt) this._function(e, t);
    else {
      if (e instanceof Go) return this._if(e, t);
      if (e instanceof qo) return this._switch(e, t);
      if (e instanceof Vo) return this._for(e, t);
      if (e instanceof Uo) return this._while(e, t);
      if (e instanceof Wo) return this._loop(e, t);
      if (e instanceof Kr) {
        const n = t.clone();
        return n.currentFunctionName = t.currentFunctionName, this._execStatements(e.body, n);
      }
      if (e instanceof Ro) this._assign(e, t);
      else if (e instanceof Fo) this._increment(e, t);
      else {
        if (e instanceof ze) return null;
        if (e instanceof ys) {
          const n = e.name;
          t.getVariable(n) === null && t.setVariable(n, new b(0, this.getTypeInfo("u32")));
        } else if (e instanceof bs) this._call(e, t);
        else {
          if (e instanceof zo || e instanceof vs) return null;
          console.error("Invalid statement type.", e, `Line ${e.line}`);
        }
      }
    }
    return null;
  }
  evalExpression(e, t) {
    return e instanceof Me ? this._evalBinaryOp(e, t) : e instanceof me ? this._evalLiteral(e, t) : e instanceof ke ? this._evalVariable(e, t) : e instanceof xs ? this._evalCall(e, t) : e instanceof Ve ? this._evalCreate(e, t) : e instanceof jo ? this._evalConst(e, t) : e instanceof $o ? this._evalBitcast(e, t) : e instanceof pe ? this._evalUnaryOp(e, t) : (console.error("Invalid expression type", e, `Line ${e.line}`), null);
  }
  getTypeInfo(e) {
    var t;
    if (e instanceof k) {
      const r = this.reflection.getTypeInfo(e);
      if (r !== null) return r;
    }
    let n = (t = this.typeInfo[e]) !== null && t !== void 0 ? t : null;
    return n !== null || (n = this.reflection.getTypeInfoByName(e)), n;
  }
  _setOverrides(e, t) {
    for (const n in e) {
      const r = e[n], s = this.reflection.getOverrideInfo(n);
      s !== null ? (s.type === null && (s.type = this.getTypeInfo("u32")), s.type.name === "u32" || s.type.name === "i32" || s.type.name === "f32" || s.type.name === "f16" ? t.setVariable(n, new b(r, s.type)) : s.type.name === "bool" ? t.setVariable(n, new b(r ? 1 : 0, s.type)) : s.type.name === "vec2" || s.type.name === "vec3" || s.type.name === "vec4" || s.type.name === "vec2f" || s.type.name === "vec3f" || s.type.name === "vec4f" || s.type.name === "vec2i" || s.type.name === "vec3i" || s.type.name === "vec4i" || s.type.name === "vec2u" || s.type.name === "vec3u" || s.type.name === "vec4u" || s.type.name === "vec2h" || s.type.name === "vec3h" || s.type.name === "vec4h" ? t.setVariable(n, new m(r, s.type)) : console.error(`Invalid constant type for ${n}`)) : console.error(`Override ${n} does not exist in the shader.`);
    }
  }
  _dispatchWorkgroup(e, t, n) {
    const r = [1, 1, 1];
    for (const c of e.node.attributes) if (c.name === "workgroup_size") {
      if (c.value.length > 0) {
        const f = n.getVariableValue(c.value[0]);
        r[0] = f instanceof b ? f.value : parseInt(c.value[0]);
      }
      if (c.value.length > 1) {
        const f = n.getVariableValue(c.value[1]);
        r[1] = f instanceof b ? f.value : parseInt(c.value[1]);
      }
      if (c.value.length > 2) {
        const f = n.getVariableValue(c.value[2]);
        r[2] = f instanceof b ? f.value : parseInt(c.value[2]);
      }
    }
    const s = this.getTypeInfo("vec3u"), o = this.getTypeInfo("u32");
    n.setVariable("@workgroup_size", new m(r, s));
    const i = r[0], l = r[1], u = r[2];
    for (let c = 0, f = 0; c < u; ++c) for (let h = 0; h < l; ++h) for (let p = 0; p < i; ++p, ++f) {
      const v = [p, h, c], I = [p + t[0] * r[0], h + t[1] * r[1], c + t[2] * r[2]];
      n.setVariable("@local_invocation_id", new m(v, s)), n.setVariable("@global_invocation_id", new m(I, s)), n.setVariable("@local_invocation_index", new b(f, o)), this._dispatchExec(e, n);
    }
  }
  _dispatchExec(e, t) {
    for (const n of e.node.args) for (const r of n.attributes) if (r.name === "builtin") {
      const s = `@${r.value}`, o = t.getVariable(s);
      o !== void 0 && t.variables.set(n.name, o);
    }
    this._execStatements(e.node.body, t);
  }
  getVariableName(e, t) {
    for (; e instanceof pe; ) e = e.right;
    return e instanceof ke ? e.name : (console.error("Unknown variable type", e, "Line", e.line), null);
  }
  _execStatements(e, t) {
    for (const n of e) {
      if (n instanceof Array) {
        const s = t.clone(), o = this._execStatements(n, s);
        if (o) return o;
        continue;
      }
      const r = this.execStatement(n, t);
      if (r) return r;
    }
    return null;
  }
  _call(e, t) {
    const n = t.clone();
    n.currentFunctionName = e.name;
    const r = t.getFunction(e.name);
    if (r) {
      for (let s = 0; s < r.node.args.length; ++s) {
        const o = r.node.args[s], i = this.evalExpression(e.args[s], n);
        n.setVariable(o.name, i, o);
      }
      this._execStatements(r.node.body, n);
    } else e.isBuiltin ? this._callBuiltinFunction(e, n) : this.getTypeInfo(e.name) && this._evalCreate(e, t);
  }
  _increment(e, t) {
    const n = this.getVariableName(e.variable, t), r = t.getVariable(n);
    r ? e.operator === "++" ? r.value instanceof b ? r.value.value++ : console.error(`Variable ${n} is not a scalar. Line ${e.line}`) : e.operator === "--" ? r.value instanceof b ? r.value.value-- : console.error(`Variable ${n} is not a scalar. Line ${e.line}`) : console.error(`Unknown increment operator ${e.operator}. Line ${e.line}`) : console.error(`Variable ${n} not found. Line ${e.line}`);
  }
  _getVariableData(e, t) {
    if (e instanceof ke) {
      const n = this.getVariableName(e, t), r = t.getVariable(n);
      return r === null ? (console.error(`Variable ${n} not found. Line ${e.line}`), null) : r.value.getSubData(this, e.postfix, t);
    }
    if (e instanceof pe) {
      if (e.operator === "*") {
        const n = this._getVariableData(e.right, t);
        return n instanceof At ? n.reference.getSubData(this, e.postfix, t) : (console.error(`Variable ${e.right} is not a pointer. Line ${e.line}`), null);
      }
      if (e.operator === "&") {
        const n = this._getVariableData(e.right, t);
        return new At(n);
      }
    }
    return null;
  }
  _assign(e, t) {
    let n = null, r = "<var>", s = null;
    if (e.variable instanceof pe) {
      const l = this._getVariableData(e.variable, t), u = this.evalExpression(e.value, t), c = e.operator;
      if (c === "=") {
        if (l instanceof b || l instanceof m || l instanceof H) {
          if (u instanceof b || u instanceof m || u instanceof H && l.data.length === u.data.length) return void l.data.set(u.data);
          console.error(`Invalid assignment. Line ${e.line}`);
        } else if (l instanceof Ae && u instanceof Ae && l.buffer.byteLength - l.offset >= u.buffer.byteLength - u.offset) return void (l.buffer.byteLength % 4 == 0 ? new Uint32Array(l.buffer, l.offset, l.typeInfo.size / 4).set(new Uint32Array(u.buffer, u.offset, u.typeInfo.size / 4)) : new Uint8Array(l.buffer, l.offset, l.typeInfo.size).set(new Uint8Array(u.buffer, u.offset, u.typeInfo.size)));
        return console.error(`Invalid assignment. Line ${e.line}`), null;
      }
      if (c === "+=") return l instanceof b || l instanceof m || l instanceof H ? u instanceof b || u instanceof m || u instanceof H ? void l.data.set(u.data.map((f, h) => l.data[h] + f)) : void console.error(`Invalid assignment . Line ${e.line}`) : void console.error(`Invalid assignment. Line ${e.line}`);
      if (c === "-=") return (l instanceof b || l instanceof m || l instanceof H) && (u instanceof b || u instanceof m || u instanceof H) ? void l.data.set(u.data.map((f, h) => l.data[h] - f)) : void console.error(`Invalid assignment. Line ${e.line}`);
    }
    if (e.variable instanceof pe) {
      if (e.variable.operator === "*") {
        r = this.getVariableName(e.variable.right, t);
        const l = t.getVariable(r);
        if (!(l && l.value instanceof At)) return void console.error(`Variable ${r} is not a pointer. Line ${e.line}`);
        n = l.value.reference;
        let u = e.variable.postfix;
        if (!u) {
          let c = e.variable.right;
          for (; c instanceof pe; ) {
            if (c.postfix) {
              u = c.postfix;
              break;
            }
            c = c.right;
          }
        }
        u && (n = n.getSubData(this, u, t));
      }
    } else {
      s = e.variable.postfix, r = this.getVariableName(e.variable, t);
      const l = t.getVariable(r);
      if (l === null) return void console.error(`Variable ${r} not found. Line ${e.line}`);
      n = l.value;
    }
    if (n instanceof At && (n = n.reference), n === null) return void console.error(`Variable ${r} not found. Line ${e.line}`);
    const o = this.evalExpression(e.value, t), i = e.operator;
    if (i !== "=") {
      const l = n.getSubData(this, s, t);
      if (l instanceof m && o instanceof b) {
        const u = l.data, c = o.value;
        if (i === "+=") for (let f = 0; f < u.length; ++f) u[f] += c;
        else if (i === "-=") for (let f = 0; f < u.length; ++f) u[f] -= c;
        else if (i === "*=") for (let f = 0; f < u.length; ++f) u[f] *= c;
        else if (i === "/=") for (let f = 0; f < u.length; ++f) u[f] /= c;
        else if (i === "%=") for (let f = 0; f < u.length; ++f) u[f] %= c;
        else if (i === "&=") for (let f = 0; f < u.length; ++f) u[f] &= c;
        else if (i === "|=") for (let f = 0; f < u.length; ++f) u[f] |= c;
        else if (i === "^=") for (let f = 0; f < u.length; ++f) u[f] ^= c;
        else if (i === "<<=") for (let f = 0; f < u.length; ++f) u[f] <<= c;
        else if (i === ">>=") for (let f = 0; f < u.length; ++f) u[f] >>= c;
        else console.error(`Invalid operator ${i}. Line ${e.line}`);
      } else if (l instanceof m && o instanceof m) {
        const u = l.data, c = o.data;
        if (u.length !== c.length) return void console.error(`Vector length mismatch. Line ${e.line}`);
        if (i === "+=") for (let f = 0; f < u.length; ++f) u[f] += c[f];
        else if (i === "-=") for (let f = 0; f < u.length; ++f) u[f] -= c[f];
        else if (i === "*=") for (let f = 0; f < u.length; ++f) u[f] *= c[f];
        else if (i === "/=") for (let f = 0; f < u.length; ++f) u[f] /= c[f];
        else if (i === "%=") for (let f = 0; f < u.length; ++f) u[f] %= c[f];
        else if (i === "&=") for (let f = 0; f < u.length; ++f) u[f] &= c[f];
        else if (i === "|=") for (let f = 0; f < u.length; ++f) u[f] |= c[f];
        else if (i === "^=") for (let f = 0; f < u.length; ++f) u[f] ^= c[f];
        else if (i === "<<=") for (let f = 0; f < u.length; ++f) u[f] <<= c[f];
        else if (i === ">>=") for (let f = 0; f < u.length; ++f) u[f] >>= c[f];
        else console.error(`Invalid operator ${i}. Line ${e.line}`);
      } else {
        if (!(l instanceof b && o instanceof b)) return void console.error(`Invalid type for ${e.operator} operator. Line ${e.line}`);
        i === "+=" ? l.value += o.value : i === "-=" ? l.value -= o.value : i === "*=" ? l.value *= o.value : i === "/=" ? l.value /= o.value : i === "%=" ? l.value %= o.value : i === "&=" ? l.value &= o.value : i === "|=" ? l.value |= o.value : i === "^=" ? l.value ^= o.value : i === "<<=" ? l.value <<= o.value : i === ">>=" ? l.value >>= o.value : console.error(`Invalid operator ${i}. Line ${e.line}`);
      }
      return void (n instanceof Ae && n.setDataValue(this, l, s, t));
    }
    if (n instanceof Ae) n.setDataValue(this, o, s, t);
    else if (s) {
      if (!(n instanceof m || n instanceof H)) return void console.error(`Variable ${r} is not a vector or matrix. Line ${e.line}`);
      if (s instanceof _t) {
        const l = this.evalExpression(s.index, t).value;
        if (n instanceof m) {
          if (!(o instanceof b)) return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
          n.data[l] = o.value;
        } else {
          if (!(n instanceof H)) return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
          {
            const u = this.evalExpression(s.index, t).value;
            if (u < 0) return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
            if (!(o instanceof m)) return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
            {
              const c = n.typeInfo.getTypeName();
              if (c === "mat2x2" || c === "mat2x2f" || c === "mat2x2h") {
                if (!(u < 2 && o.data.length === 2)) return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
                n.data[2 * u] = o.data[0], n.data[2 * u + 1] = o.data[1];
              } else if (c === "mat2x3" || c === "mat2x3f" || c === "mat2x3h") {
                if (!(u < 2 && o.data.length === 3)) return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
                n.data[3 * u] = o.data[0], n.data[3 * u + 1] = o.data[1], n.data[3 * u + 2] = o.data[2];
              } else if (c === "mat2x4" || c === "mat2x4f" || c === "mat2x4h") {
                if (!(u < 2 && o.data.length === 4)) return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
                n.data[4 * u] = o.data[0], n.data[4 * u + 1] = o.data[1], n.data[4 * u + 2] = o.data[2], n.data[4 * u + 3] = o.data[3];
              } else if (c === "mat3x2" || c === "mat3x2f" || c === "mat3x2h") {
                if (!(u < 3 && o.data.length === 2)) return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
                n.data[2 * u] = o.data[0], n.data[2 * u + 1] = o.data[1];
              } else if (c === "mat3x3" || c === "mat3x3f" || c === "mat3x3h") {
                if (!(u < 3 && o.data.length === 3)) return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
                n.data[3 * u] = o.data[0], n.data[3 * u + 1] = o.data[1], n.data[3 * u + 2] = o.data[2];
              } else if (c === "mat3x4" || c === "mat3x4f" || c === "mat3x4h") {
                if (!(u < 3 && o.data.length === 4)) return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
                n.data[4 * u] = o.data[0], n.data[4 * u + 1] = o.data[1], n.data[4 * u + 2] = o.data[2], n.data[4 * u + 3] = o.data[3];
              } else if (c === "mat4x2" || c === "mat4x2f" || c === "mat4x2h") {
                if (!(u < 4 && o.data.length === 2)) return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
                n.data[2 * u] = o.data[0], n.data[2 * u + 1] = o.data[1];
              } else if (c === "mat4x3" || c === "mat4x3f" || c === "mat4x3h") {
                if (!(u < 4 && o.data.length === 3)) return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
                n.data[3 * u] = o.data[0], n.data[3 * u + 1] = o.data[1], n.data[3 * u + 2] = o.data[2];
              } else {
                if (c !== "mat4x4" && c !== "mat4x4f" && c !== "mat4x4h") return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
                if (!(u < 4 && o.data.length === 4)) return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
                n.data[4 * u] = o.data[0], n.data[4 * u + 1] = o.data[1], n.data[4 * u + 2] = o.data[2], n.data[4 * u + 3] = o.data[3];
              }
            }
          }
        }
      } else if (s instanceof ut) {
        const l = s.value;
        if (!(n instanceof m)) return void console.error(`Invalid assignment to ${l}. Variable ${r} is not a vector. Line ${e.line}`);
        if (o instanceof b) {
          if (l.length > 1) return void console.error(`Invalid assignment to ${l} for variable ${r}. Line ${e.line}`);
          if (l === "x") n.data[0] = o.value;
          else if (l === "y") {
            if (n.data.length < 2) return void console.error(`Invalid assignment to ${l} for variable ${r}. Line ${e.line}`);
            n.data[1] = o.value;
          } else if (l === "z") {
            if (n.data.length < 3) return void console.error(`Invalid assignment to ${l} for variable ${r}. Line ${e.line}`);
            n.data[2] = o.value;
          } else if (l === "w") {
            if (n.data.length < 4) return void console.error(`Invalid assignment to ${l} for variable ${r}. Line ${e.line}`);
            n.data[3] = o.value;
          }
        } else {
          if (!(o instanceof m)) return void console.error(`Invalid assignment to ${r}. Line ${e.line}`);
          if (l.length !== o.data.length) return void console.error(`Invalid assignment to ${l} for variable ${r}. Line ${e.line}`);
          for (let u = 0; u < l.length; ++u) {
            const c = l[u];
            if (c === "x" || c === "r") n.data[0] = o.data[u];
            else if (c === "y" || c === "g") {
              if (o.data.length < 2) return void console.error(`Invalid assignment to ${c} for variable ${r}. Line ${e.line}`);
              n.data[1] = o.data[u];
            } else if (c === "z" || c === "b") {
              if (o.data.length < 3) return void console.error(`Invalid assignment to ${c} for variable ${r}. Line ${e.line}`);
              n.data[2] = o.data[u];
            } else {
              if (c !== "w" && c !== "a") return void console.error(`Invalid assignment to ${c} for variable ${r}. Line ${e.line}`);
              if (o.data.length < 4) return void console.error(`Invalid assignment to ${c} for variable ${r}. Line ${e.line}`);
              n.data[3] = o.data[u];
            }
          }
        }
      }
    } else n instanceof b && o instanceof b ? n.value = o.value : n instanceof m && o instanceof m || n instanceof H && o instanceof H ? n.data.set(o.data) : console.error(`Invalid assignment to ${r}. Line ${e.line}`);
  }
  _function(e, t) {
    const n = new Lf(e);
    t.functions.set(e.name, n);
  }
  _const(e, t) {
    let n = null;
    e.value !== null && (n = this.evalExpression(e.value, t)), t.createVariable(e.name, n, e);
  }
  _let(e, t) {
    let n = null;
    if (e.value !== null) {
      if (n = this.evalExpression(e.value, t), n === null) return void console.error(`Invalid value for variable ${e.name}. Line ${e.line}`);
      e.value instanceof pe || (n = n.clone());
    } else {
      const r = e.type.name;
      if (r === "f32" || r === "i32" || r === "u32" || r === "bool" || r === "f16" || r === "vec2" || r === "vec3" || r === "vec4" || r === "vec2f" || r === "vec3f" || r === "vec4f" || r === "vec2i" || r === "vec3i" || r === "vec4i" || r === "vec2u" || r === "vec3u" || r === "vec4u" || r === "vec2h" || r === "vec3h" || r === "vec4h" || r === "vec2b" || r === "vec3b" || r === "vec4b" || r === "mat2x2" || r === "mat2x3" || r === "mat2x4" || r === "mat3x2" || r === "mat3x3" || r === "mat3x4" || r === "mat4x2" || r === "mat4x3" || r === "mat4x4" || r === "mat2x2f" || r === "mat2x3f" || r === "mat2x4f" || r === "mat3x2f" || r === "mat3x3f" || r === "mat3x4f" || r === "mat4x2f" || r === "mat4x3f" || r === "mat4x4f" || r === "mat2x2h" || r === "mat2x3h" || r === "mat2x4h" || r === "mat3x2h" || r === "mat3x3h" || r === "mat3x4h" || r === "mat4x2h" || r === "mat4x3h" || r === "mat4x4h" || r === "array") {
        const s = new Ve(e.type, []);
        n = this._evalCreate(s, t);
      }
    }
    t.createVariable(e.name, n, e);
  }
  _var(e, t) {
    let n = null;
    if (e.value !== null) {
      if (n = this.evalExpression(e.value, t), n === null) return void console.error(`Invalid value for variable ${e.name}. Line ${e.line}`);
      e.value instanceof pe || (n = n.clone());
    } else {
      if (e.type === null) return void console.error(`Variable ${e.name} has no type. Line ${e.line}`);
      const r = e.type.name;
      if (r === "f32" || r === "i32" || r === "u32" || r === "bool" || r === "f16" || r === "vec2" || r === "vec3" || r === "vec4" || r === "vec2f" || r === "vec3f" || r === "vec4f" || r === "vec2i" || r === "vec3i" || r === "vec4i" || r === "vec2u" || r === "vec3u" || r === "vec4u" || r === "vec2h" || r === "vec3h" || r === "vec4h" || r === "vec2b" || r === "vec3b" || r === "vec4b" || r === "mat2x2" || r === "mat2x3" || r === "mat2x4" || r === "mat3x2" || r === "mat3x3" || r === "mat3x4" || r === "mat4x2" || r === "mat4x3" || r === "mat4x4" || r === "mat2x2f" || r === "mat2x3f" || r === "mat2x4f" || r === "mat3x2f" || r === "mat3x3f" || r === "mat3x4f" || r === "mat4x2f" || r === "mat4x3f" || r === "mat4x4f" || r === "mat2x2h" || r === "mat2x3h" || r === "mat2x4h" || r === "mat3x2h" || r === "mat3x3h" || r === "mat3x4h" || r === "mat4x2h" || r === "mat4x3h" || r === "mat4x4h" || e.type instanceof Jt || e.type instanceof ze || e.type instanceof x) {
        const s = new Ve(e.type, []);
        n = this._evalCreate(s, t);
      }
    }
    t.createVariable(e.name, n, e);
  }
  _switch(e, t) {
    t = t.clone();
    const n = this.evalExpression(e.condition, t);
    if (!(n instanceof b)) return console.error(`Invalid if condition. Line ${e.line}`), null;
    let r = null;
    for (const s of e.cases) if (s instanceof Yo) for (const o of s.selectors) {
      if (o instanceof yn) {
        r = s;
        continue;
      }
      const i = this.evalExpression(o, t);
      if (!(i instanceof b)) return console.error(`Invalid case selector. Line ${e.line}`), null;
      if (i.value === n.value) return this._execStatements(s.body, t);
    }
    else s instanceof el && (r = s);
    return r ? this._execStatements(r.body, t) : null;
  }
  _if(e, t) {
    t = t.clone();
    const n = this.evalExpression(e.condition, t);
    if (!(n instanceof b)) return console.error(`Invalid if condition. Line ${e.line}`), null;
    if (n.value) return this._execStatements(e.body, t);
    for (const r of e.elseif) {
      const s = this.evalExpression(r.condition, t);
      if (!(s instanceof b)) return console.error(`Invalid if condition. Line ${e.line}`), null;
      if (s.value) return this._execStatements(r.body, t);
    }
    return e.else ? this._execStatements(e.else, t) : null;
  }
  _getScalarValue(e) {
    return e instanceof b ? e.value : (console.error("Expected scalar value.", e), 0);
  }
  _for(e, t) {
    for (t = t.clone(), this.execStatement(e.init, t); this._getScalarValue(this.evalExpression(e.condition, t)); ) {
      const n = this._execStatements(e.body, t);
      if (n === Be._breakObj) break;
      if (n !== null && n !== Be._continueObj) return n;
      this.execStatement(e.increment, t);
    }
    return null;
  }
  _loop(e, t) {
    for (t = t.clone(); ; ) {
      const n = this._execStatements(e.body, t);
      if (n === Be._breakObj) break;
      if (n === Be._continueObj) {
        if (e.continuing && this._execStatements(e.continuing.body, t) === Be._breakObj)
          break;
      } else if (n !== null) return n;
    }
    return null;
  }
  _while(e, t) {
    for (t = t.clone(); this._getScalarValue(this.evalExpression(e.condition, t)); ) {
      const n = this._execStatements(e.body, t);
      if (n === Be._breakObj) break;
      if (n !== Be._continueObj && n !== null) return n;
    }
    return null;
  }
  _evalBitcast(e, t) {
    const n = this.evalExpression(e.value, t), r = e.type;
    if (n instanceof b) {
      const s = Ga(n.value, n.typeInfo.name, r.name);
      return new b(s, this.getTypeInfo(r));
    }
    if (n instanceof m) {
      const s = n.typeInfo.getTypeName();
      let o = "";
      if (s.endsWith("f")) o = "f32";
      else if (s.endsWith("i")) o = "i32";
      else if (s.endsWith("u")) o = "u32";
      else if (s.endsWith("b")) o = "bool";
      else {
        if (!s.endsWith("h")) return console.error(`Unknown vector type ${s}. Line ${e.line}`), null;
        o = "f16";
      }
      const i = r.getTypeName();
      let l = "";
      if (i.endsWith("f")) l = "f32";
      else if (i.endsWith("i")) l = "i32";
      else if (i.endsWith("u")) l = "u32";
      else if (i.endsWith("b")) l = "bool";
      else {
        if (!i.endsWith("h")) return console.error(`Unknown vector type ${l}. Line ${e.line}`), null;
        l = "f16";
      }
      const u = (function(c, f, h) {
        if (f === h) return c;
        const p = new Array(c.length);
        for (let v = 0; v < c.length; v++) p[v] = Ga(c[v], f, h);
        return p;
      })(Array.from(n.data), o, l);
      return new m(u, this.getTypeInfo(r));
    }
    return console.error(`TODO: bitcast for ${n.typeInfo.name}. Line ${e.line}`), null;
  }
  _evalConst(e, t) {
    return t.getVariableValue(e.name).clone().getSubData(this, e.postfix, t);
  }
  _evalCreate(e, t) {
    var n;
    if (e instanceof Ve) {
      if (e.type === null) return Yr.void;
      switch (e.type.getTypeName()) {
        case "bool":
        case "i32":
        case "u32":
        case "f32":
        case "f16":
          return this._callConstructorValue(e, t);
        case "vec2":
        case "vec3":
        case "vec4":
        case "vec2f":
        case "vec3f":
        case "vec4f":
        case "vec2h":
        case "vec3h":
        case "vec4h":
        case "vec2i":
        case "vec3i":
        case "vec4i":
        case "vec2u":
        case "vec3u":
        case "vec4u":
        case "vec2b":
        case "vec3b":
        case "vec4b":
          return this._callConstructorVec(e, t);
        case "mat2x2":
        case "mat2x2f":
        case "mat2x2h":
        case "mat2x3":
        case "mat2x3f":
        case "mat2x3h":
        case "mat2x4":
        case "mat2x4f":
        case "mat2x4h":
        case "mat3x2":
        case "mat3x2f":
        case "mat3x2h":
        case "mat3x3":
        case "mat3x3f":
        case "mat3x3h":
        case "mat3x4":
        case "mat3x4f":
        case "mat3x4h":
        case "mat4x2":
        case "mat4x2f":
        case "mat4x2h":
        case "mat4x3":
        case "mat4x3f":
        case "mat4x3h":
        case "mat4x4":
        case "mat4x4f":
        case "mat4x4h":
          return this._callConstructorMatrix(e, t);
      }
    }
    const r = e instanceof Ve ? e.type.name : e.name, s = e instanceof Ve ? this.getTypeInfo(e.type) : this.getTypeInfo(e.name);
    if (s === null) return console.error(`Unknown type ${r}. Line ${e.line}`), null;
    if (s.size === 0) return null;
    const o = new Ae(new ArrayBuffer(s.size), s, 0);
    if (s instanceof Ke) {
      if (e.args) for (let i = 0; i < e.args.length; ++i) {
        const l = s.members[i], u = e.args[i], c = this.evalExpression(u, t);
        o.setData(this, c, l.type, l.offset, t);
      }
    } else if (s instanceof et) {
      let i = 0;
      if (e.args) for (let l = 0; l < e.args.length; ++l) {
        const u = e.args[l], c = this.evalExpression(u, t);
        s.format === null && (((n = c.typeInfo) === null || n === void 0 ? void 0 : n.name) === "x32" ? s.format = this.getTypeInfo("i32") : s.format = c.typeInfo), o.setData(this, c, s.format, i, t), i += s.stride;
      }
    } else console.error(`Unknown type "${r}". Line ${e.line}`);
    return e instanceof Ve ? o.getSubData(this, e.postfix, t) : o;
  }
  _evalLiteral(e, t) {
    const n = this.getTypeInfo(e.type), r = n.name;
    return r === "x32" || r === "u32" || r === "f32" || r === "f16" || r === "i32" || r === "bool" ? new b(e.scalarValue, n) : r === "vec2" || r === "vec3" || r === "vec4" || r === "vec2f" || r === "vec3f" || r === "vec4f" || r === "vec2h" || r === "vec3h" || r === "vec4h" || r === "vec2i" || r === "vec3i" || r === "vec4i" || r === "vec2u" || r === "vec3u" || r === "vec4u" ? this._callConstructorVec(e, t) : r === "mat2x2" || r === "mat2x3" || r === "mat2x4" || r === "mat3x2" || r === "mat3x3" || r === "mat3x4" || r === "mat4x2" || r === "mat4x3" || r === "mat4x4" || r === "mat2x2f" || r === "mat2x3f" || r === "mat2x4f" || r === "mat3x2f" || r === "mat3x3f" || r === "mat3x4f" || r === "mat4x2f" || r === "mat4x3f" || r === "mat4x4f" || r === "mat2x2h" || r === "mat2x3h" || r === "mat2x4h" || r === "mat3x2h" || r === "mat3x3h" || r === "mat3x4h" || r === "mat4x2h" || r === "mat4x3h" || r === "mat4x4h" ? this._callConstructorMatrix(e, t) : e.value;
  }
  _evalVariable(e, t) {
    const n = t.getVariableValue(e.name);
    return n === null ? n : n.getSubData(this, e.postfix, t);
  }
  _maxFormatTypeInfo(e) {
    let t = e[0];
    if (t.name === "f32") return t;
    for (let n = 1; n < e.length; ++n) {
      const r = Be._priority.get(t.name);
      Be._priority.get(e[n].name) < r && (t = e[n]);
    }
    return t.name === "x32" ? this.getTypeInfo("i32") : t;
  }
  _evalUnaryOp(e, t) {
    const n = this.evalExpression(e.right, t);
    if (e.operator === "&") return new At(n);
    if (e.operator === "*") return n instanceof At ? n.reference.getSubData(this, e.postfix, t) : (console.error(`Invalid dereference. Line ${e.line}`), null);
    const r = n instanceof b ? n.value : n instanceof m ? Array.from(n.data) : null;
    switch (e.operator) {
      case "+": {
        if (P(r)) {
          const i = r.map((l, u) => +l);
          return new m(i, n.typeInfo);
        }
        const s = r, o = this._maxFormatTypeInfo([n.typeInfo, n.typeInfo]);
        return new b(+s, o);
      }
      case "-": {
        if (P(r)) {
          const i = r.map((l, u) => -l);
          return new m(i, n.typeInfo);
        }
        const s = r, o = this._maxFormatTypeInfo([n.typeInfo, n.typeInfo]);
        return new b(-s, o);
      }
      case "!": {
        if (P(r)) {
          const i = r.map((l, u) => l ? 0 : 1);
          return new m(i, n.typeInfo);
        }
        const s = r, o = this._maxFormatTypeInfo([n.typeInfo, n.typeInfo]);
        return new b(s ? 0 : 1, o);
      }
      case "~": {
        if (P(r)) {
          const i = r.map((l, u) => ~l);
          return new m(i, n.typeInfo);
        }
        const s = r, o = this._maxFormatTypeInfo([n.typeInfo, n.typeInfo]);
        return new b(~s, o);
      }
    }
    return console.error(`Invalid unary operator ${e.operator}. Line ${e.line}`), null;
  }
  _evalBinaryOp(e, t) {
    const n = this.evalExpression(e.left, t), r = this.evalExpression(e.right, t), s = n instanceof b ? n.value : n instanceof m || n instanceof H ? Array.from(n.data) : null, o = r instanceof b ? r.value : r instanceof m || r instanceof H ? Array.from(r.data) : null;
    switch (e.operator) {
      case "+": {
        if (P(s) && P(o)) {
          const c = s, f = o;
          if (c.length !== f.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const h = c.map((p, v) => p + f[v]);
          return new m(h, n.typeInfo);
        }
        if (P(s)) {
          const c = o, f = s.map((h, p) => h + c);
          return new m(f, n.typeInfo);
        }
        if (P(o)) {
          const c = s, f = o.map((h, p) => c + h);
          return new m(f, r.typeInfo);
        }
        const i = s, l = o, u = this._maxFormatTypeInfo([n.typeInfo, r.typeInfo]);
        return new b(i + l, u);
      }
      case "-": {
        if (P(s) && P(o)) {
          const c = s, f = o;
          if (c.length !== f.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const h = c.map((p, v) => p - f[v]);
          return new m(h, n.typeInfo);
        }
        if (P(s)) {
          const c = o, f = s.map((h, p) => h - c);
          return new m(f, n.typeInfo);
        }
        if (P(o)) {
          const c = s, f = o.map((h, p) => c - h);
          return new m(f, r.typeInfo);
        }
        const i = s, l = o, u = this._maxFormatTypeInfo([n.typeInfo, r.typeInfo]);
        return new b(i - l, u);
      }
      case "*": {
        if (P(s) && P(o)) {
          const c = s, f = o;
          if (n instanceof H && r instanceof H) {
            const h = (function(y, T, L, E) {
              if (we[T.name] === void 0 || we[E.name] === void 0) return null;
              const C = we[T.name][0], Q = we[T.name][1], M = we[E.name][0];
              if (C !== we[E.name][1]) return null;
              const Z = new Array(M * Q);
              for (let z = 0; z < Q; z++) for (let N = 0; N < M; N++) {
                let G = 0;
                for (let S = 0; S < C; S++) G += y[S * Q + z] * L[N * C + S];
                Z[z * M + N] = G;
              }
              return Z;
            })(c, n.typeInfo, f, r.typeInfo);
            if (h === null) return console.error(`Matrix multiplication failed. Line ${e.line}.`), null;
            const p = we[r.typeInfo.name][0], v = we[n.typeInfo.name][1], I = this.getTypeInfo(`mat${p}x${v}f`);
            return new H(h, I);
          }
          if (n instanceof H && r instanceof m) {
            const h = (function(p, v, I, y) {
              if (we[v.name] === void 0 || Pr[y.name] === void 0) return null;
              const T = we[v.name][0], L = we[v.name][1];
              if (T !== I.length) return null;
              const E = new Array(L);
              for (let C = 0; C < L; C++) {
                let Q = 0;
                for (let M = 0; M < T; M++) Q += p[M * L + C] * I[M];
                E[C] = Q;
              }
              return E;
            })(c, n.typeInfo, f, r.typeInfo);
            return h === null ? (console.error(`Matrix vector multiplication failed. Line ${e.line}.`), null) : new m(h, r.typeInfo);
          }
          if (n instanceof m && r instanceof H) {
            const h = (function(p, v, I, y) {
              if (Pr[v.name] === void 0 || we[y.name] === void 0) return null;
              const T = we[y.name][0], L = we[y.name][1];
              if (L !== p.length) return null;
              const E = [];
              for (let C = 0; C < T; C++) {
                let Q = 0;
                for (let M = 0; M < L; M++) Q += p[M] * I[M * T + C];
                E[C] = Q;
              }
              return E;
            })(c, n.typeInfo, f, r.typeInfo);
            return h === null ? (console.error(`Matrix vector multiplication failed. Line ${e.line}.`), null) : new m(h, n.typeInfo);
          }
          {
            if (c.length !== f.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
            const h = c.map((p, v) => p * f[v]);
            return new m(h, n.typeInfo);
          }
        }
        if (P(s)) {
          const c = o, f = s.map((h, p) => h * c);
          return n instanceof H ? new H(f, n.typeInfo) : new m(f, n.typeInfo);
        }
        if (P(o)) {
          const c = s, f = o.map((h, p) => c * h);
          return r instanceof H ? new H(f, r.typeInfo) : new m(f, r.typeInfo);
        }
        const i = s, l = o, u = this._maxFormatTypeInfo([n.typeInfo, r.typeInfo]);
        return new b(i * l, u);
      }
      case "%": {
        if (P(s) && P(o)) {
          const c = s, f = o;
          if (c.length !== f.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const h = c.map((p, v) => p % f[v]);
          return new m(h, n.typeInfo);
        }
        if (P(s)) {
          const c = o, f = s.map((h, p) => h % c);
          return new m(f, n.typeInfo);
        }
        if (P(o)) {
          const c = s, f = o.map((h, p) => c % h);
          return new m(f, r.typeInfo);
        }
        const i = s, l = o, u = this._maxFormatTypeInfo([n.typeInfo, r.typeInfo]);
        return new b(i % l, u);
      }
      case "/": {
        if (P(s) && P(o)) {
          const c = s, f = o;
          if (c.length !== f.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const h = c.map((p, v) => p / f[v]);
          return new m(h, n.typeInfo);
        }
        if (P(s)) {
          const c = o, f = s.map((h, p) => h / c);
          return new m(f, n.typeInfo);
        }
        if (P(o)) {
          const c = s, f = o.map((h, p) => c / h);
          return new m(f, r.typeInfo);
        }
        const i = s, l = o, u = this._maxFormatTypeInfo([n.typeInfo, r.typeInfo]);
        return new b(i / l, u);
      }
      case "&": {
        if (P(s) && P(o)) {
          const c = s, f = o;
          if (c.length !== f.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const h = c.map((p, v) => p & f[v]);
          return new m(h, n.typeInfo);
        }
        if (P(s)) {
          const c = o, f = s.map((h, p) => h & c);
          return new m(f, n.typeInfo);
        }
        if (P(o)) {
          const c = s, f = o.map((h, p) => c & h);
          return new m(f, r.typeInfo);
        }
        const i = s, l = o, u = this._maxFormatTypeInfo([n.typeInfo, r.typeInfo]);
        return new b(i & l, u);
      }
      case "|": {
        if (P(s) && P(o)) {
          const c = s, f = o;
          if (c.length !== f.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const h = c.map((p, v) => p | f[v]);
          return new m(h, n.typeInfo);
        }
        if (P(s)) {
          const c = o, f = s.map((h, p) => h | c);
          return new m(f, n.typeInfo);
        }
        if (P(o)) {
          const c = s, f = o.map((h, p) => c | h);
          return new m(f, r.typeInfo);
        }
        const i = s, l = o, u = this._maxFormatTypeInfo([n.typeInfo, r.typeInfo]);
        return new b(i | l, u);
      }
      case "^": {
        if (P(s) && P(o)) {
          const c = s, f = o;
          if (c.length !== f.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const h = c.map((p, v) => p ^ f[v]);
          return new m(h, n.typeInfo);
        }
        if (P(s)) {
          const c = o, f = s.map((h, p) => h ^ c);
          return new m(f, n.typeInfo);
        }
        if (P(o)) {
          const c = s, f = o.map((h, p) => c ^ h);
          return new m(f, r.typeInfo);
        }
        const i = s, l = o, u = this._maxFormatTypeInfo([n.typeInfo, r.typeInfo]);
        return new b(i ^ l, u);
      }
      case "<<": {
        if (P(s) && P(o)) {
          const c = s, f = o;
          if (c.length !== f.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const h = c.map((p, v) => p << f[v]);
          return new m(h, n.typeInfo);
        }
        if (P(s)) {
          const c = o, f = s.map((h, p) => h << c);
          return new m(f, n.typeInfo);
        }
        if (P(o)) {
          const c = s, f = o.map((h, p) => c << h);
          return new m(f, r.typeInfo);
        }
        const i = s, l = o, u = this._maxFormatTypeInfo([n.typeInfo, r.typeInfo]);
        return new b(i << l, u);
      }
      case ">>": {
        if (P(s) && P(o)) {
          const c = s, f = o;
          if (c.length !== f.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const h = c.map((p, v) => p >> f[v]);
          return new m(h, n.typeInfo);
        }
        if (P(s)) {
          const c = o, f = s.map((h, p) => h >> c);
          return new m(f, n.typeInfo);
        }
        if (P(o)) {
          const c = s, f = o.map((h, p) => c >> h);
          return new m(f, r.typeInfo);
        }
        const i = s, l = o, u = this._maxFormatTypeInfo([n.typeInfo, r.typeInfo]);
        return new b(i >> l, u);
      }
      case ">":
        if (P(s) && P(o)) {
          const i = s, l = o;
          if (i.length !== l.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const u = i.map((c, f) => c > l[f] ? 1 : 0);
          return new m(u, n.typeInfo);
        }
        if (P(s)) {
          const i = o, l = s.map((u, c) => u > i ? 1 : 0);
          return new m(l, n.typeInfo);
        }
        if (P(o)) {
          const i = s, l = o.map((u, c) => i > u ? 1 : 0);
          return new m(l, r.typeInfo);
        }
        return new b(s > o ? 1 : 0, this.getTypeInfo("bool"));
      case "<":
        if (P(s) && P(o)) {
          const i = s, l = o;
          if (i.length !== l.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const u = i.map((c, f) => c < l[f] ? 1 : 0);
          return new m(u, n.typeInfo);
        }
        if (P(s)) {
          const i = o, l = s.map((u, c) => u < i ? 1 : 0);
          return new m(l, n.typeInfo);
        }
        if (P(o)) {
          const i = s, l = o.map((u, c) => i < u ? 1 : 0);
          return new m(l, r.typeInfo);
        }
        return new b(s < o ? 1 : 0, this.getTypeInfo("bool"));
      case "==":
        if (P(s) && P(o)) {
          const i = s, l = o;
          if (i.length !== l.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const u = i.map((c, f) => c === l[f] ? 1 : 0);
          return new m(u, n.typeInfo);
        }
        if (P(s)) {
          const i = o, l = s.map((u, c) => u == i ? 1 : 0);
          return new m(l, n.typeInfo);
        }
        if (P(o)) {
          const i = s, l = o.map((u, c) => i == u ? 1 : 0);
          return new m(l, r.typeInfo);
        }
        return new b(s === o ? 1 : 0, this.getTypeInfo("bool"));
      case "!=":
        if (P(s) && P(o)) {
          const i = s, l = o;
          if (i.length !== l.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const u = i.map((c, f) => c !== l[f] ? 1 : 0);
          return new m(u, n.typeInfo);
        }
        if (P(s)) {
          const i = o, l = s.map((u, c) => u !== i ? 1 : 0);
          return new m(l, n.typeInfo);
        }
        if (P(o)) {
          const i = s, l = o.map((u, c) => i !== u ? 1 : 0);
          return new m(l, r.typeInfo);
        }
        return new b(s !== o ? 1 : 0, this.getTypeInfo("bool"));
      case ">=":
        if (P(s) && P(o)) {
          const i = s, l = o;
          if (i.length !== l.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const u = i.map((c, f) => c >= l[f] ? 1 : 0);
          return new m(u, n.typeInfo);
        }
        if (P(s)) {
          const i = o, l = s.map((u, c) => u >= i ? 1 : 0);
          return new m(l, n.typeInfo);
        }
        if (P(o)) {
          const i = s, l = o.map((u, c) => i >= u ? 1 : 0);
          return new m(l, r.typeInfo);
        }
        return new b(s >= o ? 1 : 0, this.getTypeInfo("bool"));
      case "<=":
        if (P(s) && P(o)) {
          const i = s, l = o;
          if (i.length !== l.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const u = i.map((c, f) => c <= l[f] ? 1 : 0);
          return new m(u, n.typeInfo);
        }
        if (P(s)) {
          const i = o, l = s.map((u, c) => u <= i ? 1 : 0);
          return new m(l, n.typeInfo);
        }
        if (P(o)) {
          const i = s, l = o.map((u, c) => i <= u ? 1 : 0);
          return new m(l, r.typeInfo);
        }
        return new b(s <= o ? 1 : 0, this.getTypeInfo("bool"));
      case "&&":
        if (P(s) && P(o)) {
          const i = s, l = o;
          if (i.length !== l.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const u = i.map((c, f) => c && l[f] ? 1 : 0);
          return new m(u, n.typeInfo);
        }
        if (P(s)) {
          const i = o, l = s.map((u, c) => u && i ? 1 : 0);
          return new m(l, n.typeInfo);
        }
        if (P(o)) {
          const i = s, l = o.map((u, c) => i && u ? 1 : 0);
          return new m(l, r.typeInfo);
        }
        return new b(s && o ? 1 : 0, this.getTypeInfo("bool"));
      case "||":
        if (P(s) && P(o)) {
          const i = s, l = o;
          if (i.length !== l.length) return console.error(`Vector length mismatch. Line ${e.line}.`), null;
          const u = i.map((c, f) => c || l[f] ? 1 : 0);
          return new m(u, n.typeInfo);
        }
        if (P(s)) {
          const i = o, l = s.map((u, c) => u || i ? 1 : 0);
          return new m(l, n.typeInfo);
        }
        if (P(o)) {
          const i = s, l = o.map((u, c) => i || u ? 1 : 0);
          return new m(l, r.typeInfo);
        }
        return new b(s || o ? 1 : 0, this.getTypeInfo("bool"));
    }
    return console.error(`Unknown operator ${e.operator}. Line ${e.line}`), null;
  }
  _evalCall(e, t) {
    if (e.cachedReturnValue !== null) return e.cachedReturnValue;
    const n = t.clone();
    n.currentFunctionName = e.name;
    const r = t.getFunction(e.name);
    if (!r)
      return e.isBuiltin ? this._callBuiltinFunction(e, n) : this.getTypeInfo(e.name) ? this._evalCreate(e, t) : (console.error(`Unknown function "${e.name}". Line ${e.line}`), null);
    for (let s = 0; s < r.node.args.length; ++s) {
      const o = r.node.args[s], i = this.evalExpression(e.args[s], n);
      n.createVariable(o.name, i, o);
    }
    return this._execStatements(r.node.body, n);
  }
  _callBuiltinFunction(e, t) {
    switch (e.name) {
      case "all":
        return this.builtins.All(e, t);
      case "any":
        return this.builtins.Any(e, t);
      case "select":
        return this.builtins.Select(e, t);
      case "arrayLength":
        return this.builtins.ArrayLength(e, t);
      case "abs":
        return this.builtins.Abs(e, t);
      case "acos":
        return this.builtins.Acos(e, t);
      case "acosh":
        return this.builtins.Acosh(e, t);
      case "asin":
        return this.builtins.Asin(e, t);
      case "asinh":
        return this.builtins.Asinh(e, t);
      case "atan":
        return this.builtins.Atan(e, t);
      case "atanh":
        return this.builtins.Atanh(e, t);
      case "atan2":
        return this.builtins.Atan2(e, t);
      case "ceil":
        return this.builtins.Ceil(e, t);
      case "clamp":
        return this.builtins.Clamp(e, t);
      case "cos":
        return this.builtins.Cos(e, t);
      case "cosh":
        return this.builtins.Cosh(e, t);
      case "countLeadingZeros":
        return this.builtins.CountLeadingZeros(e, t);
      case "countOneBits":
        return this.builtins.CountOneBits(e, t);
      case "countTrailingZeros":
        return this.builtins.CountTrailingZeros(e, t);
      case "cross":
        return this.builtins.Cross(e, t);
      case "degrees":
        return this.builtins.Degrees(e, t);
      case "determinant":
        return this.builtins.Determinant(e, t);
      case "distance":
        return this.builtins.Distance(e, t);
      case "dot":
        return this.builtins.Dot(e, t);
      case "dot4U8Packed":
        return this.builtins.Dot4U8Packed(e, t);
      case "dot4I8Packed":
        return this.builtins.Dot4I8Packed(e, t);
      case "exp":
        return this.builtins.Exp(e, t);
      case "exp2":
        return this.builtins.Exp2(e, t);
      case "extractBits":
        return this.builtins.ExtractBits(e, t);
      case "faceForward":
        return this.builtins.FaceForward(e, t);
      case "firstLeadingBit":
        return this.builtins.FirstLeadingBit(e, t);
      case "firstTrailingBit":
        return this.builtins.FirstTrailingBit(e, t);
      case "floor":
        return this.builtins.Floor(e, t);
      case "fma":
        return this.builtins.Fma(e, t);
      case "fract":
        return this.builtins.Fract(e, t);
      case "frexp":
        return this.builtins.Frexp(e, t);
      case "insertBits":
        return this.builtins.InsertBits(e, t);
      case "inverseSqrt":
        return this.builtins.InverseSqrt(e, t);
      case "ldexp":
        return this.builtins.Ldexp(e, t);
      case "length":
        return this.builtins.Length(e, t);
      case "log":
        return this.builtins.Log(e, t);
      case "log2":
        return this.builtins.Log2(e, t);
      case "max":
        return this.builtins.Max(e, t);
      case "min":
        return this.builtins.Min(e, t);
      case "mix":
        return this.builtins.Mix(e, t);
      case "modf":
        return this.builtins.Modf(e, t);
      case "normalize":
        return this.builtins.Normalize(e, t);
      case "pow":
        return this.builtins.Pow(e, t);
      case "quantizeToF16":
        return this.builtins.QuantizeToF16(e, t);
      case "radians":
        return this.builtins.Radians(e, t);
      case "reflect":
        return this.builtins.Reflect(e, t);
      case "refract":
        return this.builtins.Refract(e, t);
      case "reverseBits":
        return this.builtins.ReverseBits(e, t);
      case "round":
        return this.builtins.Round(e, t);
      case "saturate":
        return this.builtins.Saturate(e, t);
      case "sign":
        return this.builtins.Sign(e, t);
      case "sin":
        return this.builtins.Sin(e, t);
      case "sinh":
        return this.builtins.Sinh(e, t);
      case "smoothstep":
        return this.builtins.SmoothStep(e, t);
      case "sqrt":
        return this.builtins.Sqrt(e, t);
      case "step":
        return this.builtins.Step(e, t);
      case "tan":
        return this.builtins.Tan(e, t);
      case "tanh":
        return this.builtins.Tanh(e, t);
      case "transpose":
        return this.builtins.Transpose(e, t);
      case "trunc":
        return this.builtins.Trunc(e, t);
      case "dpdx":
        return this.builtins.Dpdx(e, t);
      case "dpdxCoarse":
        return this.builtins.DpdxCoarse(e, t);
      case "dpdxFine":
        return this.builtins.DpdxFine(e, t);
      case "dpdy":
        return this.builtins.Dpdy(e, t);
      case "dpdyCoarse":
        return this.builtins.DpdyCoarse(e, t);
      case "dpdyFine":
        return this.builtins.DpdyFine(e, t);
      case "fwidth":
        return this.builtins.Fwidth(e, t);
      case "fwidthCoarse":
        return this.builtins.FwidthCoarse(e, t);
      case "fwidthFine":
        return this.builtins.FwidthFine(e, t);
      case "textureDimensions":
        return this.builtins.TextureDimensions(e, t);
      case "textureGather":
        return this.builtins.TextureGather(e, t);
      case "textureGatherCompare":
        return this.builtins.TextureGatherCompare(e, t);
      case "textureLoad":
        return this.builtins.TextureLoad(e, t);
      case "textureNumLayers":
        return this.builtins.TextureNumLayers(e, t);
      case "textureNumLevels":
        return this.builtins.TextureNumLevels(e, t);
      case "textureNumSamples":
        return this.builtins.TextureNumSamples(e, t);
      case "textureSample":
        return this.builtins.TextureSample(e, t);
      case "textureSampleBias":
        return this.builtins.TextureSampleBias(e, t);
      case "textureSampleCompare":
        return this.builtins.TextureSampleCompare(e, t);
      case "textureSampleCompareLevel":
        return this.builtins.TextureSampleCompareLevel(e, t);
      case "textureSampleGrad":
        return this.builtins.TextureSampleGrad(e, t);
      case "textureSampleLevel":
        return this.builtins.TextureSampleLevel(e, t);
      case "textureSampleBaseClampToEdge":
        return this.builtins.TextureSampleBaseClampToEdge(e, t);
      case "textureStore":
        return this.builtins.TextureStore(e, t);
      case "atomicLoad":
        return this.builtins.AtomicLoad(e, t);
      case "atomicStore":
        return this.builtins.AtomicStore(e, t);
      case "atomicAdd":
        return this.builtins.AtomicAdd(e, t);
      case "atomicSub":
        return this.builtins.AtomicSub(e, t);
      case "atomicMax":
        return this.builtins.AtomicMax(e, t);
      case "atomicMin":
        return this.builtins.AtomicMin(e, t);
      case "atomicAnd":
        return this.builtins.AtomicAnd(e, t);
      case "atomicOr":
        return this.builtins.AtomicOr(e, t);
      case "atomicXor":
        return this.builtins.AtomicXor(e, t);
      case "atomicExchange":
        return this.builtins.AtomicExchange(e, t);
      case "atomicCompareExchangeWeak":
        return this.builtins.AtomicCompareExchangeWeak(e, t);
      case "pack4x8snorm":
        return this.builtins.Pack4x8snorm(e, t);
      case "pack4x8unorm":
        return this.builtins.Pack4x8unorm(e, t);
      case "pack4xI8":
        return this.builtins.Pack4xI8(e, t);
      case "pack4xU8":
        return this.builtins.Pack4xU8(e, t);
      case "pack4x8Clamp":
        return this.builtins.Pack4x8Clamp(e, t);
      case "pack4xU8Clamp":
        return this.builtins.Pack4xU8Clamp(e, t);
      case "pack2x16snorm":
        return this.builtins.Pack2x16snorm(e, t);
      case "pack2x16unorm":
        return this.builtins.Pack2x16unorm(e, t);
      case "pack2x16float":
        return this.builtins.Pack2x16float(e, t);
      case "unpack4x8snorm":
        return this.builtins.Unpack4x8snorm(e, t);
      case "unpack4x8unorm":
        return this.builtins.Unpack4x8unorm(e, t);
      case "unpack4xI8":
        return this.builtins.Unpack4xI8(e, t);
      case "unpack4xU8":
        return this.builtins.Unpack4xU8(e, t);
      case "unpack2x16snorm":
        return this.builtins.Unpack2x16snorm(e, t);
      case "unpack2x16unorm":
        return this.builtins.Unpack2x16unorm(e, t);
      case "unpack2x16float":
        return this.builtins.Unpack2x16float(e, t);
      case "storageBarrier":
        return this.builtins.StorageBarrier(e, t);
      case "textureBarrier":
        return this.builtins.TextureBarrier(e, t);
      case "workgroupBarrier":
        return this.builtins.WorkgroupBarrier(e, t);
      case "workgroupUniformLoad":
        return this.builtins.WorkgroupUniformLoad(e, t);
      case "subgroupAdd":
        return this.builtins.SubgroupAdd(e, t);
      case "subgroupExclusiveAdd":
        return this.builtins.SubgroupExclusiveAdd(e, t);
      case "subgroupInclusiveAdd":
        return this.builtins.SubgroupInclusiveAdd(e, t);
      case "subgroupAll":
        return this.builtins.SubgroupAll(e, t);
      case "subgroupAnd":
        return this.builtins.SubgroupAnd(e, t);
      case "subgroupAny":
        return this.builtins.SubgroupAny(e, t);
      case "subgroupBallot":
        return this.builtins.SubgroupBallot(e, t);
      case "subgroupBroadcast":
        return this.builtins.SubgroupBroadcast(e, t);
      case "subgroupBroadcastFirst":
        return this.builtins.SubgroupBroadcastFirst(e, t);
      case "subgroupElect":
        return this.builtins.SubgroupElect(e, t);
      case "subgroupMax":
        return this.builtins.SubgroupMax(e, t);
      case "subgroupMin":
        return this.builtins.SubgroupMin(e, t);
      case "subgroupMul":
        return this.builtins.SubgroupMul(e, t);
      case "subgroupExclusiveMul":
        return this.builtins.SubgroupExclusiveMul(e, t);
      case "subgroupInclusiveMul":
        return this.builtins.SubgroupInclusiveMul(e, t);
      case "subgroupOr":
        return this.builtins.SubgroupOr(e, t);
      case "subgroupShuffle":
        return this.builtins.SubgroupShuffle(e, t);
      case "subgroupShuffleDown":
        return this.builtins.SubgroupShuffleDown(e, t);
      case "subgroupShuffleUp":
        return this.builtins.SubgroupShuffleUp(e, t);
      case "subgroupShuffleXor":
        return this.builtins.SubgroupShuffleXor(e, t);
      case "subgroupXor":
        return this.builtins.SubgroupXor(e, t);
      case "quadBroadcast":
        return this.builtins.QuadBroadcast(e, t);
      case "quadSwapDiagonal":
        return this.builtins.QuadSwapDiagonal(e, t);
      case "quadSwapX":
        return this.builtins.QuadSwapX(e, t);
      case "quadSwapY":
        return this.builtins.QuadSwapY(e, t);
    }
    const n = t.getFunction(e.name);
    if (n) {
      const r = t.clone();
      for (let s = 0; s < n.node.args.length; ++s) {
        const o = n.node.args[s], i = this.evalExpression(e.args[s], r);
        r.setVariable(o.name, i, o);
      }
      return this._execStatements(n.node.body, r);
    }
    return null;
  }
  _callConstructorValue(e, t) {
    if (!e.args || e.args.length === 0) return new b(0, this.getTypeInfo(e.type));
    const n = this.evalExpression(e.args[0], t);
    return n.typeInfo = this.getTypeInfo(e.type), n.getSubData(this, e.postfix, t).clone();
  }
  _callConstructorVec(e, t) {
    const n = this.getTypeInfo(e.type), r = e.type.getTypeName(), s = Pr[r];
    if (s === void 0) return console.error(`Invalid vec constructor ${r}. Line ${e.line}`), null;
    const o = [];
    if (e instanceof me) if (e.isVector) {
      const i = e.vectorValue;
      for (const l of i) o.push(l);
    } else o.push(e.scalarValue);
    else if (e.args) for (const i of e.args) {
      const l = this.evalExpression(i, t);
      if (l instanceof m) {
        const u = l.data;
        for (let c = 0; c < u.length; ++c) {
          let f = u[c];
          o.push(f);
        }
      } else if (l instanceof b) {
        let u = l.value;
        o.push(u);
      }
    }
    if (e.type instanceof x && e.type.format === null && (e.type.format = x.f32), o.length === 0) {
      const i = new Array(s).fill(0);
      return new m(i, n).getSubData(this, e.postfix, t);
    }
    if (o.length === 1) for (; o.length < s; ) o.push(o[0]);
    return o.length < s ? (console.error(`Invalid vec constructor. Line ${e.line}`), null) : new m(o.length > s ? o.slice(0, s) : o, n).getSubData(this, e.postfix, t);
  }
  _callConstructorMatrix(e, t) {
    const n = this.getTypeInfo(e.type), r = e.type.getTypeName(), s = we[r];
    if (s === void 0) return console.error(`Invalid matrix constructor ${r}. Line ${e.line}`), null;
    const o = [];
    if (e instanceof me) if (e.isVector) {
      const i = e.vectorValue;
      for (const l of i) o.push(l);
    } else o.push(e.scalarValue);
    else if (e.args) for (const i of e.args) {
      const l = this.evalExpression(i, t);
      l instanceof m ? o.push(...l.data) : l instanceof b ? o.push(l.value) : l instanceof H && o.push(...l.data);
    }
    if (n instanceof ct && n.format === null && (n.format = this.getTypeInfo("f32")), o.length === 0) {
      const i = new Array(s[2]).fill(0);
      return new H(i, n).getSubData(this, e.postfix, t);
    }
    return o.length !== s[2] ? (console.error(`Invalid matrix constructor. Line ${e.line}`), null) : new H(o, n).getSubData(this, e.postfix, t);
  }
};
vn._breakObj = new qe(new Se("BREAK", null), null), vn._continueObj = new qe(new Se("CONTINUE", null), null), vn._priority = /* @__PURE__ */ new Map([["f32", 0], ["f16", 1], ["u32", 2], ["i32", 3], ["x32", 3]]);
let Pf = class {
  constructor() {
    this.constants = /* @__PURE__ */ new Map(), this.aliases = /* @__PURE__ */ new Map(), this.structs = /* @__PURE__ */ new Map();
  }
}, Of = class {
  constructor() {
    this._tokens = [], this._current = 0, this._currentLine = 1, this._deferArrayCountEval = [], this._currentLoop = [], this._context = new Pf(), this._exec = new vn(), this._forwardTypeCount = 0;
  }
  parse(e) {
    this._initialize(e), this._deferArrayCountEval.length = 0;
    const t = [];
    for (; !this._isAtEnd(); ) {
      const n = this._global_decl_or_directive();
      if (!n) break;
      t.push(n);
    }
    if (this._deferArrayCountEval.length > 0) {
      for (const n of this._deferArrayCountEval) {
        const r = n.arrayType, s = n.countNode;
        if (s instanceof ke) {
          const o = s.name, i = this._context.constants.get(o);
          if (i) try {
            const l = i.constEvaluate(this._exec);
            r.count = l;
          } catch {
          }
        }
      }
      this._deferArrayCountEval.length = 0;
    }
    if (this._forwardTypeCount > 0) for (const n of t) n.search((r) => {
      r instanceof Wa || r instanceof An ? r.type = this._forwardType(r.type) : r instanceof Jt ? r.format = this._forwardType(r.format) : r instanceof He || r instanceof Gt || r instanceof gn ? r.type = this._forwardType(r.type) : r instanceof jt ? r.returnType = this._forwardType(r.returnType) : r instanceof Ra && (r.type = this._forwardType(r.type));
    });
    return t;
  }
  _forwardType(e) {
    if (e instanceof Fa) {
      const t = this._getType(e.name);
      if (t) return t;
    } else e instanceof An ? e.type = this._forwardType(e.type) : e instanceof Jt && (e.format = this._forwardType(e.format));
    return e;
  }
  _initialize(e) {
    if (e) if (typeof e == "string") {
      const t = new wf(e);
      this._tokens = t.scanTokens();
    } else this._tokens = e;
    else this._tokens = [];
    this._current = 0;
  }
  _updateNode(e, t) {
    return e.line = t ?? this._currentLine, e;
  }
  _error(e, t) {
    return { token: e, message: t, toString: () => `${t}` };
  }
  _isAtEnd() {
    return this._current >= this._tokens.length || this._peek().type == d.eof;
  }
  _match(e) {
    if (e instanceof A) return !!this._check(e) && (this._advance(), !0);
    for (let t = 0, n = e.length; t < n; ++t) {
      const r = e[t];
      if (this._check(r)) return this._advance(), !0;
    }
    return !1;
  }
  _consume(e, t) {
    if (this._check(e)) return this._advance();
    throw this._error(this._peek(), `${t}. Line:${this._currentLine}`);
  }
  _check(e) {
    if (this._isAtEnd()) return !1;
    const t = this._peek();
    if (e instanceof Array) {
      const n = t.type;
      let r = !1;
      for (const s of e) {
        if (n === s) return !0;
        s === d.tokens.name && (r = !0);
      }
      if (r) {
        const s = d.tokens.name.rule.exec(t.lexeme);
        if (s && s.index == 0 && s[0] == t.lexeme) return !0;
      }
      return !1;
    }
    if (t.type === e) return !0;
    if (e === d.tokens.name) {
      const n = d.tokens.name.rule.exec(t.lexeme);
      return n && n.index == 0 && n[0] == t.lexeme;
    }
    return !1;
  }
  _advance() {
    var e, t;
    return this._currentLine = (t = (e = this._peek()) === null || e === void 0 ? void 0 : e.line) !== null && t !== void 0 ? t : -1, this._isAtEnd() || this._current++, this._previous();
  }
  _peek() {
    return this._tokens[this._current];
  }
  _previous() {
    return this._tokens[this._current - 1];
  }
  _global_decl_or_directive() {
    for (; this._match(d.tokens.semicolon) && !this._isAtEnd(); ) ;
    if (this._match(d.keywords.alias)) {
      const t = this._type_alias();
      return this._consume(d.tokens.semicolon, "Expected ';'"), this._exec.reflection.updateAST([t]), t;
    }
    if (this._match(d.keywords.diagnostic)) {
      const t = this._diagnostic();
      return this._consume(d.tokens.semicolon, "Expected ';'"), this._exec.reflection.updateAST([t]), t;
    }
    if (this._match(d.keywords.requires)) {
      const t = this._requires_directive();
      return this._consume(d.tokens.semicolon, "Expected ';'"), this._exec.reflection.updateAST([t]), t;
    }
    if (this._match(d.keywords.enable)) {
      const t = this._enable_directive();
      return this._consume(d.tokens.semicolon, "Expected ';'"), this._exec.reflection.updateAST([t]), t;
    }
    const e = this._attribute();
    if (this._check(d.keywords.var)) {
      const t = this._global_variable_decl();
      return t != null && (t.attributes = e), this._consume(d.tokens.semicolon, "Expected ';'."), this._exec.reflection.updateAST([t]), t;
    }
    if (this._check(d.keywords.override)) {
      const t = this._override_variable_decl();
      return t != null && (t.attributes = e), this._consume(d.tokens.semicolon, "Expected ';'."), this._exec.reflection.updateAST([t]), t;
    }
    if (this._check(d.keywords.let)) {
      const t = this._global_let_decl();
      return t != null && (t.attributes = e), this._consume(d.tokens.semicolon, "Expected ';'."), this._exec.reflection.updateAST([t]), t;
    }
    if (this._check(d.keywords.const)) {
      const t = this._global_const_decl();
      return t != null && (t.attributes = e), this._consume(d.tokens.semicolon, "Expected ';'."), this._exec.reflection.updateAST([t]), t;
    }
    if (this._check(d.keywords.struct)) {
      const t = this._struct_decl();
      return t != null && (t.attributes = e), this._exec.reflection.updateAST([t]), t;
    }
    if (this._check(d.keywords.fn)) {
      const t = this._function_decl();
      return t != null && (t.attributes = e), this._exec.reflection.updateAST([t]), t;
    }
    return null;
  }
  _function_decl() {
    if (!this._match(d.keywords.fn)) return null;
    const e = this._currentLine, t = this._consume(d.tokens.ident, "Expected function name.").toString();
    this._consume(d.tokens.paren_left, "Expected '(' for function arguments.");
    const n = [];
    if (!this._check(d.tokens.paren_right)) do {
      if (this._check(d.tokens.paren_right)) break;
      const i = this._attribute(), l = this._consume(d.tokens.name, "Expected argument name.").toString();
      this._consume(d.tokens.colon, "Expected ':' for argument type.");
      const u = this._attribute(), c = this._type_decl();
      c != null && (c.attributes = u, n.push(this._updateNode(new Ra(l, c, i))));
    } while (this._match(d.tokens.comma));
    this._consume(d.tokens.paren_right, "Expected ')' after function arguments.");
    let r = null;
    if (this._match(d.tokens.arrow)) {
      const i = this._attribute();
      r = this._type_decl(), r != null && (r.attributes = i);
    }
    const s = this._compound_statement(), o = this._currentLine;
    return this._updateNode(new jt(t, n, r, s, e, o), e);
  }
  _compound_statement() {
    const e = [];
    for (this._consume(d.tokens.brace_left, "Expected '{' for block."); !this._check(d.tokens.brace_right); ) {
      const t = this._statement();
      t !== null && e.push(t);
    }
    return this._consume(d.tokens.brace_right, "Expected '}' for block."), e;
  }
  _statement() {
    for (; this._match(d.tokens.semicolon) && !this._isAtEnd(); ) ;
    if (this._check(d.tokens.attr) && this._attribute(), this._check(d.keywords.if)) return this._if_statement();
    if (this._check(d.keywords.switch)) return this._switch_statement();
    if (this._check(d.keywords.loop)) return this._loop_statement();
    if (this._check(d.keywords.for)) return this._for_statement();
    if (this._check(d.keywords.while)) return this._while_statement();
    if (this._check(d.keywords.continuing)) return this._continuing_statement();
    if (this._check(d.keywords.static_assert)) return this._static_assert_statement();
    if (this._check(d.tokens.brace_left)) return this._compound_statement();
    let e = null;
    if (this._check(d.keywords.return)) e = this._return_statement();
    else if (this._check([d.keywords.var, d.keywords.let, d.keywords.const])) e = this._variable_statement();
    else if (this._match(d.keywords.discard)) e = this._updateNode(new bf());
    else if (this._match(d.keywords.break)) {
      const t = this._updateNode(new Ho());
      if (this._currentLoop.length > 0) {
        const n = this._currentLoop[this._currentLoop.length - 1];
        t.loopId = n.id;
      }
      e = t, this._check(d.keywords.if) && (this._advance(), t.condition = this._optional_paren_expression());
    } else if (this._match(d.keywords.continue)) {
      const t = this._updateNode(new Zo());
      if (!(this._currentLoop.length > 0)) throw this._error(this._peek(), `Continue statement must be inside a loop. Line: ${t.line}`);
      {
        const n = this._currentLoop[this._currentLoop.length - 1];
        t.loopId = n.id;
      }
      e = t;
    } else e = this._increment_decrement_statement() || this._func_call_statement() || this._assignment_statement();
    return e != null && this._consume(d.tokens.semicolon, "Expected ';' after statement."), e;
  }
  _static_assert_statement() {
    if (!this._match(d.keywords.static_assert)) return null;
    const e = this._currentLine, t = this._optional_paren_expression();
    return this._updateNode(new gf(t), e);
  }
  _while_statement() {
    if (!this._match(d.keywords.while)) return null;
    const e = this._updateNode(new Uo(null, null));
    return this._currentLoop.push(e), e.condition = this._optional_paren_expression(), this._check(d.tokens.attr) && this._attribute(), e.body = this._compound_statement(), this._currentLoop.pop(), e;
  }
  _continuing_statement() {
    const e = this._currentLoop.length > 0 ? this._currentLoop[this._currentLoop.length - 1].id : -1;
    if (!this._match(d.keywords.continuing)) return null;
    const t = this._currentLine, n = this._compound_statement();
    return this._updateNode(new Kr(n, e), t);
  }
  _for_statement() {
    if (!this._match(d.keywords.for)) return null;
    this._consume(d.tokens.paren_left, "Expected '('.");
    const e = this._updateNode(new Vo(null, null, null, null));
    return this._currentLoop.push(e), e.init = this._check(d.tokens.semicolon) ? null : this._for_init(), this._consume(d.tokens.semicolon, "Expected ';'."), e.condition = this._check(d.tokens.semicolon) ? null : this._short_circuit_or_expression(), this._consume(d.tokens.semicolon, "Expected ';'."), e.increment = this._check(d.tokens.paren_right) ? null : this._for_increment(), this._consume(d.tokens.paren_right, "Expected ')'."), this._check(d.tokens.attr) && this._attribute(), e.body = this._compound_statement(), this._currentLoop.pop(), e;
  }
  _for_init() {
    return this._variable_statement() || this._func_call_statement() || this._assignment_statement();
  }
  _for_increment() {
    return this._func_call_statement() || this._increment_decrement_statement() || this._assignment_statement();
  }
  _variable_statement() {
    if (this._check(d.keywords.var)) {
      const e = this._variable_decl();
      if (e === null) throw this._error(this._peek(), "Variable declaration expected.");
      let t = null;
      return this._match(d.tokens.equal) && (t = this._short_circuit_or_expression()), this._updateNode(new He(e.name, e.type, e.storage, e.access, t), e.line);
    }
    if (this._match(d.keywords.let)) {
      const e = this._currentLine, t = this._consume(d.tokens.name, "Expected name for let.").toString();
      let n = null;
      if (this._match(d.tokens.colon)) {
        const s = this._attribute();
        n = this._type_decl(), n != null && (n.attributes = s);
      }
      this._consume(d.tokens.equal, "Expected '=' for let.");
      const r = this._short_circuit_or_expression();
      return this._updateNode(new Gt(t, n, null, null, r), e);
    }
    if (this._match(d.keywords.const)) {
      const e = this._currentLine, t = this._consume(d.tokens.name, "Expected name for const.").toString();
      let n = null;
      if (this._match(d.tokens.colon)) {
        const s = this._attribute();
        n = this._type_decl(), n != null && (n.attributes = s);
      }
      this._consume(d.tokens.equal, "Expected '=' for const.");
      const r = this._short_circuit_or_expression();
      return n === null && r instanceof me && (n = r.type), this._updateNode(new gn(t, n, null, null, r), e);
    }
    return null;
  }
  _increment_decrement_statement() {
    const e = this._current, t = this._unary_expression();
    if (t == null) return null;
    if (!this._check(d.increment_operators)) return this._current = e, null;
    const n = this._consume(d.increment_operators, "Expected increment operator");
    return this._updateNode(new Fo(n.type === d.tokens.plus_plus ? vt.increment : vt.decrement, t));
  }
  _assignment_statement() {
    let e = null;
    const t = this._currentLine;
    if (this._check(d.tokens.brace_right)) return null;
    let n = this._match(d.tokens.underscore);
    if (n || (e = this._unary_expression()), !n && e == null) return null;
    const r = this._consume(d.assignment_operators, "Expected assignment operator."), s = this._short_circuit_or_expression();
    return this._updateNode(new Ro(Ot.parse(r.lexeme), e, s), t);
  }
  _func_call_statement() {
    if (!this._check(d.tokens.ident)) return null;
    const e = this._currentLine, t = this._current, n = this._consume(d.tokens.ident, "Expected function name."), r = this._argument_expression_list();
    return r === null ? (this._current = t, null) : this._updateNode(new bs(n.lexeme, r), e);
  }
  _loop_statement() {
    if (!this._match(d.keywords.loop)) return null;
    this._check(d.tokens.attr) && this._attribute(), this._consume(d.tokens.brace_left, "Expected '{' for loop.");
    const e = this._updateNode(new Wo([], null));
    this._currentLoop.push(e);
    let t = this._statement();
    for (; t !== null; ) {
      if (Array.isArray(t)) for (let n of t) e.body.push(n);
      else e.body.push(t);
      if (t instanceof Kr) {
        e.continuing = t;
        break;
      }
      t = this._statement();
    }
    return this._currentLoop.pop(), this._consume(d.tokens.brace_right, "Expected '}' for loop."), e;
  }
  _switch_statement() {
    if (!this._match(d.keywords.switch)) return null;
    const e = this._updateNode(new qo(null, []));
    if (this._currentLoop.push(e), e.condition = this._optional_paren_expression(), this._check(d.tokens.attr) && this._attribute(), this._consume(d.tokens.brace_left, "Expected '{' for switch."), e.cases = this._switch_body(), e.cases == null || e.cases.length == 0) throw this._error(this._previous(), "Expected 'case' or 'default'.");
    return this._consume(d.tokens.brace_right, "Expected '}' for switch."), this._currentLoop.pop(), e;
  }
  _switch_body() {
    const e = [];
    let t = !1;
    for (; this._check([d.keywords.default, d.keywords.case]); ) {
      if (this._match(d.keywords.case)) {
        const n = this._case_selectors();
        for (const s of n) if (s instanceof yn) {
          if (t) throw this._error(this._previous(), "Multiple default cases in switch statement.");
          t = !0;
          break;
        }
        this._match(d.tokens.colon), this._check(d.tokens.attr) && this._attribute(), this._consume(d.tokens.brace_left, "Exected '{' for switch case.");
        const r = this._case_body();
        this._consume(d.tokens.brace_right, "Exected '}' for switch case."), e.push(this._updateNode(new Yo(n, r)));
      }
      if (this._match(d.keywords.default)) {
        if (t) throw this._error(this._previous(), "Multiple default cases in switch statement.");
        this._match(d.tokens.colon), this._check(d.tokens.attr) && this._attribute(), this._consume(d.tokens.brace_left, "Exected '{' for switch default.");
        const n = this._case_body();
        this._consume(d.tokens.brace_right, "Exected '}' for switch default."), e.push(this._updateNode(new el(n)));
      }
    }
    return e;
  }
  _case_selectors() {
    const e = [];
    for (this._match(d.keywords.default) ? e.push(this._updateNode(new yn())) : e.push(this._shift_expression()); this._match(d.tokens.comma); ) this._match(d.keywords.default) ? e.push(this._updateNode(new yn())) : e.push(this._shift_expression());
    return e;
  }
  _case_body() {
    if (this._match(d.keywords.fallthrough)) return this._consume(d.tokens.semicolon, "Expected ';'"), [];
    let e = this._statement();
    if (e == null) return [];
    e instanceof Array || (e = [e]);
    const t = this._case_body();
    return t.length == 0 ? e : [...e, t[0]];
  }
  _if_statement() {
    if (!this._match(d.keywords.if)) return null;
    const e = this._currentLine, t = this._optional_paren_expression();
    this._check(d.tokens.attr) && this._attribute();
    const n = this._compound_statement();
    let r = [];
    this._match_elseif() && (this._check(d.tokens.attr) && this._attribute(), r = this._elseif_statement(r));
    let s = null;
    return this._match(d.keywords.else) && (this._check(d.tokens.attr) && this._attribute(), s = this._compound_statement()), this._updateNode(new Go(t, n, r, s), e);
  }
  _match_elseif() {
    return this._tokens[this._current].type === d.keywords.else && this._tokens[this._current + 1].type === d.keywords.if && (this._advance(), this._advance(), !0);
  }
  _elseif_statement(e = []) {
    const t = this._optional_paren_expression(), n = this._compound_statement();
    return e.push(this._updateNode(new vf(t, n))), this._match_elseif() && (this._check(d.tokens.attr) && this._attribute(), this._elseif_statement(e)), e;
  }
  _return_statement() {
    if (!this._match(d.keywords.return)) return null;
    const e = this._short_circuit_or_expression();
    return this._updateNode(new Jo(e));
  }
  _short_circuit_or_expression() {
    let e = this._short_circuit_and_expr();
    for (; this._match(d.tokens.or_or); ) e = this._updateNode(new Me(this._previous().toString(), e, this._short_circuit_and_expr()));
    return e;
  }
  _short_circuit_and_expr() {
    let e = this._inclusive_or_expression();
    for (; this._match(d.tokens.and_and); ) e = this._updateNode(new Me(this._previous().toString(), e, this._inclusive_or_expression()));
    return e;
  }
  _inclusive_or_expression() {
    let e = this._exclusive_or_expression();
    for (; this._match(d.tokens.or); ) e = this._updateNode(new Me(this._previous().toString(), e, this._exclusive_or_expression()));
    return e;
  }
  _exclusive_or_expression() {
    let e = this._and_expression();
    for (; this._match(d.tokens.xor); ) e = this._updateNode(new Me(this._previous().toString(), e, this._and_expression()));
    return e;
  }
  _and_expression() {
    let e = this._equality_expression();
    for (; this._match(d.tokens.and); ) e = this._updateNode(new Me(this._previous().toString(), e, this._equality_expression()));
    return e;
  }
  _equality_expression() {
    const e = this._relational_expression();
    return this._match([d.tokens.equal_equal, d.tokens.not_equal]) ? this._updateNode(new Me(this._previous().toString(), e, this._relational_expression())) : e;
  }
  _relational_expression() {
    let e = this._shift_expression();
    for (; this._match([d.tokens.less_than, d.tokens.greater_than, d.tokens.less_than_equal, d.tokens.greater_than_equal]); ) e = this._updateNode(new Me(this._previous().toString(), e, this._shift_expression()));
    return e;
  }
  _shift_expression() {
    let e = this._additive_expression();
    for (; this._match([d.tokens.shift_left, d.tokens.shift_right]); ) e = this._updateNode(new Me(this._previous().toString(), e, this._additive_expression()));
    return e;
  }
  _additive_expression() {
    let e = this._multiplicative_expression();
    for (; this._match([d.tokens.plus, d.tokens.minus]); ) e = this._updateNode(new Me(this._previous().toString(), e, this._multiplicative_expression()));
    return e;
  }
  _multiplicative_expression() {
    let e = this._unary_expression();
    for (; this._match([d.tokens.star, d.tokens.forward_slash, d.tokens.modulo]); ) e = this._updateNode(new Me(this._previous().toString(), e, this._unary_expression()));
    return e;
  }
  _unary_expression() {
    return this._match([d.tokens.minus, d.tokens.bang, d.tokens.tilde, d.tokens.star, d.tokens.and]) ? this._updateNode(new pe(this._previous().toString(), this._unary_expression())) : this._singular_expression();
  }
  _singular_expression() {
    const e = this._primary_expression(), t = this._postfix_expression();
    return t && (e.postfix = t), e;
  }
  _postfix_expression() {
    if (this._match(d.tokens.bracket_left)) {
      const e = this._short_circuit_or_expression();
      this._consume(d.tokens.bracket_right, "Expected ']'.");
      const t = this._updateNode(new _t(e)), n = this._postfix_expression();
      return n && (t.postfix = n), t;
    }
    if (this._match(d.tokens.period)) {
      const e = this._consume(d.tokens.name, "Expected member name."), t = this._postfix_expression(), n = this._updateNode(new ut(e.lexeme));
      return t && (n.postfix = t), n;
    }
    return null;
  }
  _getStruct(e) {
    return this._context.aliases.has(e) ? this._context.aliases.get(e).type : this._context.structs.has(e) ? this._context.structs.get(e) : null;
  }
  _getType(e) {
    const t = this._getStruct(e);
    if (t !== null) return t;
    switch (e) {
      case "void":
        return k.void;
      case "bool":
        return k.bool;
      case "i32":
        return k.i32;
      case "u32":
        return k.u32;
      case "f32":
        return k.f32;
      case "f16":
        return k.f16;
      case "vec2f":
        return x.vec2f;
      case "vec3f":
        return x.vec3f;
      case "vec4f":
        return x.vec4f;
      case "vec2i":
        return x.vec2i;
      case "vec3i":
        return x.vec3i;
      case "vec4i":
        return x.vec4i;
      case "vec2u":
        return x.vec2u;
      case "vec3u":
        return x.vec3u;
      case "vec4u":
        return x.vec4u;
      case "vec2h":
        return x.vec2h;
      case "vec3h":
        return x.vec3h;
      case "vec4h":
        return x.vec4h;
      case "mat2x2f":
        return x.mat2x2f;
      case "mat2x3f":
        return x.mat2x3f;
      case "mat2x4f":
        return x.mat2x4f;
      case "mat3x2f":
        return x.mat3x2f;
      case "mat3x3f":
        return x.mat3x3f;
      case "mat3x4f":
        return x.mat3x4f;
      case "mat4x2f":
        return x.mat4x2f;
      case "mat4x3f":
        return x.mat4x3f;
      case "mat4x4f":
        return x.mat4x4f;
      case "mat2x2h":
        return x.mat2x2h;
      case "mat2x3h":
        return x.mat2x3h;
      case "mat2x4h":
        return x.mat2x4h;
      case "mat3x2h":
        return x.mat3x2h;
      case "mat3x3h":
        return x.mat3x3h;
      case "mat3x4h":
        return x.mat3x4h;
      case "mat4x2h":
        return x.mat4x2h;
      case "mat4x3h":
        return x.mat4x3h;
      case "mat4x4h":
        return x.mat4x4h;
      case "mat2x2i":
        return x.mat2x2i;
      case "mat2x3i":
        return x.mat2x3i;
      case "mat2x4i":
        return x.mat2x4i;
      case "mat3x2i":
        return x.mat3x2i;
      case "mat3x3i":
        return x.mat3x3i;
      case "mat3x4i":
        return x.mat3x4i;
      case "mat4x2i":
        return x.mat4x2i;
      case "mat4x3i":
        return x.mat4x3i;
      case "mat4x4i":
        return x.mat4x4i;
      case "mat2x2u":
        return x.mat2x2u;
      case "mat2x3u":
        return x.mat2x3u;
      case "mat2x4u":
        return x.mat2x4u;
      case "mat3x2u":
        return x.mat3x2u;
      case "mat3x3u":
        return x.mat3x3u;
      case "mat3x4u":
        return x.mat3x4u;
      case "mat4x2u":
        return x.mat4x2u;
      case "mat4x3u":
        return x.mat4x3u;
      case "mat4x4u":
        return x.mat4x4u;
    }
    return null;
  }
  _validateTypeRange(e, t) {
    if (t.name === "i32") {
      if (e < -2147483648 || e > 2147483647) throw this._error(this._previous(), `Value out of range for i32: ${e}. Line: ${this._currentLine}.`);
    } else if (t.name === "u32" && (e < 0 || e > 4294967295)) throw this._error(this._previous(), `Value out of range for u32: ${e}. Line: ${this._currentLine}.`);
  }
  _primary_expression() {
    if (this._match(d.tokens.ident)) {
      const n = this._previous().toString();
      if (this._check(d.tokens.paren_left)) {
        const r = this._argument_expression_list(), s = this._getType(n);
        return s !== null ? this._updateNode(new Ve(s, r)) : this._updateNode(new xs(n, r));
      }
      if (this._context.constants.has(n)) {
        const r = this._context.constants.get(n);
        return this._updateNode(new jo(n, r.value));
      }
      return this._updateNode(new ke(n));
    }
    if (this._match(d.tokens.int_literal)) {
      const n = this._previous().toString();
      let r = n.endsWith("i") || n.endsWith("i") ? k.i32 : n.endsWith("u") || n.endsWith("U") ? k.u32 : k.x32;
      const s = parseInt(n);
      return this._validateTypeRange(s, r), this._updateNode(new me(new b(s, this._exec.getTypeInfo(r)), r));
    }
    if (this._match(d.tokens.uint_literal)) {
      const n = parseInt(this._previous().toString());
      return this._validateTypeRange(n, k.u32), this._updateNode(new me(new b(n, this._exec.getTypeInfo(k.u32)), k.u32));
    }
    if (this._match([d.tokens.decimal_float_literal, d.tokens.hex_float_literal])) {
      let n = this._previous().toString(), r = n.endsWith("h");
      r && (n = n.substring(0, n.length - 1));
      const s = parseFloat(n);
      this._validateTypeRange(s, r ? k.f16 : k.f32);
      const o = r ? k.f16 : k.f32;
      return this._updateNode(new me(new b(s, this._exec.getTypeInfo(o)), o));
    }
    if (this._match([d.keywords.true, d.keywords.false])) {
      let n = this._previous().toString() === d.keywords.true.rule;
      return this._updateNode(new me(new b(n ? 1 : 0, this._exec.getTypeInfo(k.bool)), k.bool));
    }
    if (this._check(d.tokens.paren_left)) return this._paren_expression();
    if (this._match(d.keywords.bitcast)) {
      this._consume(d.tokens.less_than, "Expected '<'.");
      const n = this._type_decl();
      this._consume(d.tokens.greater_than, "Expected '>'.");
      const r = this._paren_expression();
      return this._updateNode(new $o(n, r));
    }
    const e = this._type_decl(), t = this._argument_expression_list();
    return this._updateNode(new Ve(e, t));
  }
  _argument_expression_list() {
    if (!this._match(d.tokens.paren_left)) return null;
    const e = [];
    do {
      if (this._check(d.tokens.paren_right)) break;
      const t = this._short_circuit_or_expression();
      e.push(t);
    } while (this._match(d.tokens.comma));
    return this._consume(d.tokens.paren_right, "Expected ')' for agument list"), e;
  }
  _optional_paren_expression() {
    this._match(d.tokens.paren_left);
    const e = this._short_circuit_or_expression();
    return this._match(d.tokens.paren_right), e;
  }
  _paren_expression() {
    this._consume(d.tokens.paren_left, "Expected '('.");
    const e = this._short_circuit_or_expression();
    return this._consume(d.tokens.paren_right, "Expected ')'."), e;
  }
  _struct_decl() {
    if (!this._match(d.keywords.struct)) return null;
    const e = this._currentLine, t = this._consume(d.tokens.ident, "Expected name for struct.").toString();
    this._consume(d.tokens.brace_left, "Expected '{' for struct body.");
    const n = [];
    for (; !this._check(d.tokens.brace_right); ) {
      const o = this._attribute(), i = this._consume(d.tokens.name, "Expected variable name.").toString();
      this._consume(d.tokens.colon, "Expected ':' for struct member type.");
      const l = this._attribute(), u = this._type_decl();
      u != null && (u.attributes = l), this._check(d.tokens.brace_right) ? this._match(d.tokens.comma) : this._consume(d.tokens.comma, "Expected ',' for struct member."), n.push(this._updateNode(new Wa(i, u, o)));
    }
    this._consume(d.tokens.brace_right, "Expected '}' after struct body.");
    const r = this._currentLine, s = this._updateNode(new ze(t, n, e, r), e);
    return this._context.structs.set(t, s), s;
  }
  _global_variable_decl() {
    const e = this._variable_decl();
    if (!e) return null;
    if (this._match(d.tokens.equal)) {
      const t = this._const_expression();
      e.value = t;
    }
    if (e.type !== null && e.value instanceof me) {
      if (e.value.type.name !== "x32" && e.type.getTypeName() !== e.value.type.getTypeName())
        throw this._error(this._peek(), `Invalid cast from ${e.value.type.name} to ${e.type.name}. Line:${this._currentLine}`);
      e.value.isScalar && this._validateTypeRange(e.value.scalarValue, e.type), e.value.type = e.type;
    } else e.type === null && e.value instanceof me && (e.type = e.value.type.name === "x32" ? k.i32 : e.value.type, e.value.isScalar && this._validateTypeRange(e.value.scalarValue, e.type));
    return e;
  }
  _override_variable_decl() {
    const e = this._override_decl();
    return e && this._match(d.tokens.equal) && (e.value = this._const_expression()), e;
  }
  _global_const_decl() {
    var e;
    if (!this._match(d.keywords.const)) return null;
    const t = this._consume(d.tokens.name, "Expected variable name"), n = this._currentLine;
    let r = null;
    if (this._match(d.tokens.colon)) {
      const l = this._attribute();
      r = this._type_decl(), r != null && (r.attributes = l);
    }
    let s = null;
    this._consume(d.tokens.equal, "const declarations require an assignment");
    const o = this._short_circuit_or_expression();
    try {
      let l = [k.f32], u = o.constEvaluate(this._exec, l);
      u instanceof b && this._validateTypeRange(u.value, l[0]), l[0] instanceof x && l[0].format === null && u.typeInfo instanceof ct && u.typeInfo.format !== null && (u.typeInfo.format.name === "f16" ? l[0].format = k.f16 : u.typeInfo.format.name === "f32" ? l[0].format = k.f32 : u.typeInfo.format.name === "i32" ? l[0].format = k.i32 : u.typeInfo.format.name === "u32" ? l[0].format = k.u32 : u.typeInfo.format.name === "bool" ? l[0].format = k.bool : console.error(`TODO: impelement template format type ${u.typeInfo.format.name}`)), s = this._updateNode(new me(u, l[0])), this._exec.context.setVariable(t.toString(), u);
    } catch {
      s = o;
    }
    if (r !== null && s instanceof me) {
      if (s.type.name !== "x32" && r.getTypeName() !== s.type.getTypeName())
        throw this._error(this._peek(), `Invalid cast from ${s.type.name} to ${r.name}. Line:${this._currentLine}`);
      s.type = r, s.isScalar && this._validateTypeRange(s.scalarValue, s.type);
    } else r === null && s instanceof me && (r = (e = s?.type) !== null && e !== void 0 ? e : k.f32, r === k.x32 && (r = k.i32));
    const i = this._updateNode(new gn(t.toString(), r, "", "", s), n);
    return this._context.constants.set(i.name, i), i;
  }
  _global_let_decl() {
    if (!this._match(d.keywords.let)) return null;
    const e = this._currentLine, t = this._consume(d.tokens.name, "Expected variable name");
    let n = null;
    if (this._match(d.tokens.colon)) {
      const s = this._attribute();
      n = this._type_decl(), n != null && (n.attributes = s);
    }
    let r = null;
    if (this._match(d.tokens.equal) && (r = this._const_expression()), n !== null && r instanceof me) {
      if (r.type.name !== "x32" && n.getTypeName() !== r.type.getTypeName())
        throw this._error(this._peek(), `Invalid cast from ${r.type.name} to ${n.name}. Line:${this._currentLine}`);
      r.type = n;
    } else n === null && r instanceof me && (n = r.type.name === "x32" ? k.i32 : r.type);
    return r instanceof me && r.isScalar && this._validateTypeRange(r.scalarValue, n), this._updateNode(new Gt(t.toString(), n, "", "", r), e);
  }
  _const_expression() {
    return this._short_circuit_or_expression();
  }
  _variable_decl() {
    if (!this._match(d.keywords.var)) return null;
    const e = this._currentLine;
    let t = "", n = "";
    this._match(d.tokens.less_than) && (t = this._consume(d.storage_class, "Expected storage_class.").toString(), this._match(d.tokens.comma) && (n = this._consume(d.access_mode, "Expected access_mode.").toString()), this._consume(d.tokens.greater_than, "Expected '>'."));
    const r = this._consume(d.tokens.name, "Expected variable name");
    let s = null;
    if (this._match(d.tokens.colon)) {
      const o = this._attribute();
      s = this._type_decl(), s != null && (s.attributes = o);
    }
    return this._updateNode(new He(r.toString(), s, t, n, null), e);
  }
  _override_decl() {
    if (!this._match(d.keywords.override)) return null;
    const e = this._consume(d.tokens.name, "Expected variable name");
    let t = null;
    if (this._match(d.tokens.colon)) {
      const n = this._attribute();
      t = this._type_decl(), t != null && (t.attributes = n);
    }
    return this._updateNode(new ys(e.toString(), t, null));
  }
  _diagnostic() {
    this._consume(d.tokens.paren_left, "Expected '('");
    const e = this._consume(d.tokens.ident, "Expected severity control name.");
    this._consume(d.tokens.comma, "Expected ','");
    let t = this._consume(d.tokens.ident, "Expected diagnostic rule name.").toString();
    return this._match(d.tokens.period) && (t += `.${this._consume(d.tokens.ident, "Expected diagnostic message.").toString()}`), this._consume(d.tokens.paren_right, "Expected ')'"), this._updateNode(new zo(e.toString(), t));
  }
  _enable_directive() {
    const e = this._consume(d.tokens.ident, "identity expected.");
    return this._updateNode(new Af(e.toString()));
  }
  _requires_directive() {
    const e = [this._consume(d.tokens.ident, "identity expected.").toString()];
    for (; this._match(d.tokens.comma); ) {
      const t = this._consume(d.tokens.ident, "identity expected.");
      e.push(t.toString());
    }
    return this._updateNode(new yf(e));
  }
  _type_alias() {
    const e = this._consume(d.tokens.ident, "identity expected.");
    this._consume(d.tokens.equal, "Expected '=' for type alias.");
    let t = this._type_decl();
    if (t === null) throw this._error(this._peek(), "Expected Type for Alias.");
    this._context.aliases.has(t.name) && (t = this._context.aliases.get(t.name).type);
    const n = this._updateNode(new vs(e.toString(), t));
    return this._context.aliases.set(n.name, n), n;
  }
  _type_decl() {
    if (this._check([d.tokens.ident, ...d.texel_format, d.keywords.bool, d.keywords.f32, d.keywords.i32, d.keywords.u32])) {
      const n = this._advance().toString();
      if (this._context.structs.has(n)) return this._context.structs.get(n);
      if (this._context.aliases.has(n)) return this._context.aliases.get(n).type;
      if (!this._getType(n)) {
        const r = this._updateNode(new Fa(n));
        return this._forwardTypeCount++, r;
      }
      return this._updateNode(new k(n));
    }
    let e = this._texture_sampler_types();
    if (e) return e;
    if (this._check(d.template_types)) {
      let n = this._advance().toString(), r = null, s = null;
      return this._match(d.tokens.less_than) && (r = this._type_decl(), s = null, this._match(d.tokens.comma) && (s = this._consume(d.access_mode, "Expected access_mode for pointer").toString()), this._consume(d.tokens.greater_than, "Expected '>' for type.")), this._updateNode(new x(n, r, s));
    }
    if (this._match(d.keywords.ptr)) {
      let n = this._previous().toString();
      this._consume(d.tokens.less_than, "Expected '<' for pointer.");
      const r = this._consume(d.storage_class, "Expected storage_class for pointer");
      this._consume(d.tokens.comma, "Expected ',' for pointer.");
      const s = this._type_decl();
      let o = null;
      return this._match(d.tokens.comma) && (o = this._consume(d.access_mode, "Expected access_mode for pointer").toString()), this._consume(d.tokens.greater_than, "Expected '>' for pointer."), this._updateNode(new An(n, r.toString(), s, o));
    }
    const t = this._attribute();
    if (this._match(d.keywords.array)) {
      let n = null, r = -1;
      const s = this._previous();
      let o = null;
      if (this._match(d.tokens.less_than)) {
        n = this._type_decl(), this._context.aliases.has(n.name) && (n = this._context.aliases.get(n.name).type);
        let l = "";
        if (this._match(d.tokens.comma)) {
          o = this._shift_expression();
          try {
            l = o.constEvaluate(this._exec).toString(), o = null;
          } catch {
            l = "1";
          }
        }
        this._consume(d.tokens.greater_than, "Expected '>' for array."), r = l ? parseInt(l) : 0;
      }
      const i = this._updateNode(new Jt(s.toString(), t, n, r));
      return o && this._deferArrayCountEval.push({ arrayType: i, countNode: o }), i;
    }
    return null;
  }
  _texture_sampler_types() {
    if (this._match(d.sampler_type)) return this._updateNode(new Nt(this._previous().toString(), null, null));
    if (this._match(d.depth_texture_type)) return this._updateNode(new Nt(this._previous().toString(), null, null));
    if (this._match(d.sampled_texture_type) || this._match(d.multisampled_texture_type)) {
      const e = this._previous();
      this._consume(d.tokens.less_than, "Expected '<' for sampler type.");
      const t = this._type_decl();
      return this._consume(d.tokens.greater_than, "Expected '>' for sampler type."), this._updateNode(new Nt(e.toString(), t, null));
    }
    if (this._match(d.storage_texture_type)) {
      const e = this._previous();
      this._consume(d.tokens.less_than, "Expected '<' for sampler type.");
      const t = this._consume(d.texel_format, "Invalid texel format.").toString();
      this._consume(d.tokens.comma, "Expected ',' after texel format.");
      const n = this._consume(d.access_mode, "Expected access mode for storage texture type.").toString();
      return this._consume(d.tokens.greater_than, "Expected '>' for sampler type."), this._updateNode(new Nt(e.toString(), t, n));
    }
    return null;
  }
  _attribute() {
    let e = [];
    for (; this._match(d.tokens.attr); ) {
      const t = this._consume(d.attribute_name, "Expected attribute name"), n = this._updateNode(new tl(t.toString(), null));
      if (this._match(d.tokens.paren_left)) {
        if (n.value = this._consume(d.literal_or_ident, "Expected attribute value").toString(), this._check(d.tokens.comma)) {
          this._advance();
          do {
            const r = this._consume(d.literal_or_ident, "Expected attribute value").toString();
            n.value instanceof Array || (n.value = [n.value]), n.value.push(r);
          } while (this._match(d.tokens.comma));
        }
        this._consume(d.tokens.paren_right, "Expected ')'");
      }
      e.push(n);
    }
    return e.length == 0 ? null : e;
  }
}, Nf = class extends zt {
  constructor(e) {
    super(), e && this.update(e);
  }
  update(e) {
    const t = new Of().parse(e);
    this.updateAST(t);
  }
};
function Uf(a) {
  const e = { attributes: [], bindings: [] };
  let t;
  try {
    t = Vf(a);
  } catch (s) {
    return te.error(s.message)(), e;
  }
  for (const s of t.uniforms) {
    const o = [];
    for (const i of s.type?.members || [])
      o.push({
        name: i.name,
        type: Ja(i.type)
      });
    e.bindings.push({
      type: "uniform",
      name: s.name,
      group: s.group,
      location: s.binding,
      // @ts-expect-error TODO - unused for now but needs fixing
      members: o
    });
  }
  for (const s of t.textures)
    e.bindings.push({
      type: "texture",
      name: s.name,
      group: s.group,
      location: s.binding
    });
  for (const s of t.samplers)
    e.bindings.push({
      type: "sampler",
      name: s.name,
      group: s.group,
      location: s.binding
    });
  const n = t.entry.vertex[0], r = n?.inputs.length || 0;
  for (let s = 0; s < r; s++) {
    const o = n.inputs[s];
    if (o.locationType === "location") {
      const i = Ja(o.type);
      e.attributes.push({
        name: o.name,
        location: Number(o.location),
        type: i
      });
    }
  }
  return e;
}
function Ja(a) {
  return a?.format ? `${a.name}<${a.format.name}>` : a.name;
}
function Vf(a) {
  try {
    return new Nf(a);
  } catch (e) {
    if (e instanceof Error)
      throw e;
    let t = "WGSL parse error";
    throw typeof e == "object" && e?.message && (t += `: ${e.message} `), typeof e == "object" && e?.token && (t += e.token.line || ""), new Error(t, { cause: e });
  }
}
const Or = {};
function Xn(a = "id") {
  Or[a] = Or[a] || 1;
  const e = Or[a]++;
  return `${a}-${e}`;
}
class za {
  id;
  userData = {};
  /** Determines how vertices are read from the 'vertex' attributes */
  topology;
  bufferLayout = [];
  vertexCount;
  indices;
  attributes;
  constructor(e) {
    if (this.id = e.id || Xn("geometry"), this.topology = e.topology, this.indices = e.indices || null, this.attributes = e.attributes, this.vertexCount = e.vertexCount, this.bufferLayout = e.bufferLayout || [], this.indices && !(this.indices.usage & Te.INDEX))
      throw new Error("Index buffer must have INDEX usage");
  }
  destroy() {
    this.indices?.destroy();
    for (const e of Object.values(this.attributes))
      e.destroy();
  }
  getVertexCount() {
    return this.vertexCount;
  }
  getAttributes() {
    return this.attributes;
  }
  getIndexes() {
    return this.indices || null;
  }
  _calculateVertexCount(e) {
    return e.byteLength / 12;
  }
}
function Ff(a, e) {
  if (e instanceof za)
    return e;
  const t = Rf(a, e), { attributes: n, bufferLayout: r } = Wf(a, e);
  return new za({
    topology: e.topology || "triangle-list",
    bufferLayout: r,
    vertexCount: e.vertexCount,
    indices: t,
    attributes: n
  });
}
function Rf(a, e) {
  if (!e.indices)
    return;
  const t = e.indices.value;
  return a.createBuffer({ usage: Te.INDEX, data: t });
}
function Wf(a, e) {
  const t = [], n = {};
  for (const [s, o] of Object.entries(e.attributes)) {
    let i = s;
    switch (s) {
      case "POSITION":
        i = "positions";
        break;
      case "NORMAL":
        i = "normals";
        break;
      case "TEXCOORD_0":
        i = "texCoords";
        break;
      case "COLOR_0":
        i = "colors";
        break;
    }
    if (o) {
      n[i] = a.createBuffer({
        data: o.value,
        id: `${s}-buffer`
      });
      const { value: l, size: u, normalized: c } = o;
      t.push({ name: i, format: tu(l, u, c) });
    }
  }
  const r = e._calculateVertexCount(e.attributes, e.indices);
  return { attributes: n, bufferLayout: t, vertexCount: r };
}
class Is {
  static defaultProps = { ...wt.defaultProps };
  /** Get the singleton default pipeline factory for the specified device */
  static getDefaultPipelineFactory(e) {
    return e._lumaData.defaultPipelineFactory = e._lumaData.defaultPipelineFactory || new Is(e), e._lumaData.defaultPipelineFactory;
  }
  device;
  cachingEnabled;
  destroyPolicy;
  debug;
  _hashCounter = 0;
  _hashes = {};
  _renderPipelineCache = {};
  _computePipelineCache = {};
  get [Symbol.toStringTag]() {
    return "PipelineFactory";
  }
  toString() {
    return `PipelineFactory(${this.device.id})`;
  }
  constructor(e) {
    this.device = e, this.cachingEnabled = e.props._cachePipelines, this.destroyPolicy = e.props._cacheDestroyPolicy, this.debug = e.props.debugFactories;
  }
  /** Return a RenderPipeline matching supplied props. Reuses an equivalent pipeline if already created. */
  createRenderPipeline(e) {
    if (!this.cachingEnabled)
      return this.device.createRenderPipeline(e);
    const t = { ...wt.defaultProps, ...e }, n = this._renderPipelineCache, r = this._hashRenderPipeline(t);
    let s = n[r]?.pipeline;
    return s ? (n[r].useCount++, this.debug && te.log(3, `${this}: ${n[r].pipeline} reused, count=${n[r].useCount}, (id=${e.id})`)()) : (s = this.device.createRenderPipeline({
      ...t,
      id: t.id ? `${t.id}-cached` : Xn("unnamed-cached")
    }), s.hash = r, n[r] = { pipeline: s, useCount: 1 }, this.debug && te.log(3, `${this}: ${s} created, count=${n[r].useCount}`)()), s;
  }
  /** Return a ComputePipeline matching supplied props. Reuses an equivalent pipeline if already created. */
  createComputePipeline(e) {
    if (!this.cachingEnabled)
      return this.device.createComputePipeline(e);
    const t = { ...Bn.defaultProps, ...e }, n = this._computePipelineCache, r = this._hashComputePipeline(t);
    let s = n[r]?.pipeline;
    return s ? (n[r].useCount++, this.debug && te.log(3, `${this}: ${n[r].pipeline} reused, count=${n[r].useCount}, (id=${e.id})`)()) : (s = this.device.createComputePipeline({
      ...t,
      id: t.id ? `${t.id}-cached` : void 0
    }), s.hash = r, n[r] = { pipeline: s, useCount: 1 }, this.debug && te.log(3, `${this}: ${s} created, count=${n[r].useCount}`)()), s;
  }
  release(e) {
    if (!this.cachingEnabled) {
      e.destroy();
      return;
    }
    const t = this._getCache(e), n = e.hash;
    t[n].useCount--, t[n].useCount === 0 ? (this._destroyPipeline(e), this.debug && te.log(3, `${this}: ${e} released and destroyed`)()) : t[n].useCount < 0 ? (te.error(`${this}: ${e} released, useCount < 0, resetting`)(), t[n].useCount = 0) : this.debug && te.log(3, `${this}: ${e} released, count=${t[n].useCount}`)();
  }
  // PRIVATE
  /** Destroy a cached pipeline, removing it from the cache (depending on destroy policy) */
  _destroyPipeline(e) {
    const t = this._getCache(e);
    switch (this.destroyPolicy) {
      case "never":
        return !1;
      case "unused":
        return delete t[e.hash], e.destroy(), !0;
    }
  }
  /** Get the appropriate cache for the type of pipeline */
  _getCache(e) {
    let t;
    if (e instanceof Bn && (t = this._computePipelineCache), e instanceof wt && (t = this._renderPipelineCache), !t)
      throw new Error(`${this}`);
    if (!t[e.hash])
      throw new Error(`${this}: ${e} matched incorrect entry`);
    return t;
  }
  /** Calculate a hash based on all the inputs for a compute pipeline */
  _hashComputePipeline(e) {
    const { type: t } = this.device, n = this._getHash(e.shader.source);
    return `${t}/C/${n}`;
  }
  /** Calculate a hash based on all the inputs for a render pipeline */
  _hashRenderPipeline(e) {
    const t = e.vs ? this._getHash(e.vs.source) : 0, n = e.fs ? this._getHash(e.fs.source) : 0, r = "-", s = this._getHash(JSON.stringify(e.bufferLayout)), { type: o } = this.device;
    switch (o) {
      case "webgl":
        return `${o}/R/${t}/${n}V${r}BL${s}`;
      case "webgpu":
      default:
        const i = this._getHash(JSON.stringify(e.parameters));
        return `${o}/R/${t}/${n}V${r}T${e.topology}P${i}BL${s}`;
    }
  }
  _getHash(e) {
    return this._hashes[e] === void 0 && (this._hashes[e] = this._hashCounter++), this._hashes[e];
  }
}
class _s {
  static defaultProps = { ...ps.defaultProps };
  /** Returns the default ShaderFactory for the given {@link Device}, creating one if necessary. */
  static getDefaultShaderFactory(e) {
    return e._lumaData.defaultShaderFactory ||= new _s(e), e._lumaData.defaultShaderFactory;
  }
  device;
  cachingEnabled;
  destroyPolicy;
  debug;
  _cache = {};
  get [Symbol.toStringTag]() {
    return "ShaderFactory";
  }
  toString() {
    return `${this[Symbol.toStringTag]}(${this.device.id})`;
  }
  /** @internal */
  constructor(e) {
    this.device = e, this.cachingEnabled = e.props._cacheShaders, this.destroyPolicy = e.props._cacheDestroyPolicy, this.debug = !0;
  }
  /** Requests a {@link Shader} from the cache, creating a new Shader only if necessary. */
  createShader(e) {
    if (!this.cachingEnabled)
      return this.device.createShader(e);
    const t = this._hashShader(e);
    let n = this._cache[t];
    if (n)
      n.useCount++, this.debug && te.log(3, `${this}: Reusing shader ${n.shader.id} count=${n.useCount}`)();
    else {
      const r = this.device.createShader({
        ...e,
        id: e.id ? `${e.id}-cached` : void 0
      });
      this._cache[t] = n = { shader: r, useCount: 1 }, this.debug && te.log(3, `${this}: Created new shader ${r.id}`)();
    }
    return n.shader;
  }
  /** Releases a previously-requested {@link Shader}, destroying it if no users remain. */
  release(e) {
    if (!this.cachingEnabled) {
      e.destroy();
      return;
    }
    const t = this._hashShader(e), n = this._cache[t];
    if (n)
      if (n.useCount--, n.useCount === 0)
        this.destroyPolicy === "unused" && (delete this._cache[t], n.shader.destroy(), this.debug && te.log(3, `${this}: Releasing shader ${e.id}, destroyed`)());
      else {
        if (n.useCount < 0)
          throw new Error(`ShaderFactory: Shader ${e.id} released too many times`);
        this.debug && te.log(3, `${this}: Releasing shader ${e.id} count=${n.useCount}`)();
      }
  }
  // PRIVATE
  _hashShader(e) {
    return `${e.stage}:${e.source}`;
  }
}
function qf(a, e) {
  const t = {}, n = "Values";
  if (a.attributes.length === 0 && !a.varyings?.length)
    return { "No attributes or varyings": { [n]: "N/A" } };
  for (const r of a.attributes)
    if (r) {
      const s = `${r.location} ${r.name}: ${r.type}`;
      t[`in ${s}`] = { [n]: r.stepMode || "vertex" };
    }
  for (const r of a.varyings || []) {
    const s = `${r.location} ${r.name}`;
    t[`out ${s}`] = { [n]: JSON.stringify(r) };
  }
  return t;
}
let ge = null, Nr = null;
function Gf(a, { id: e, minimap: t, opaque: n, top: r = "0", left: s = "0", rgbaScale: o = 1 }) {
  ge || (ge = document.createElement("canvas"), ge.id = e, ge.title = e, ge.style.zIndex = "100", ge.style.position = "absolute", ge.style.top = r, ge.style.left = s, ge.style.border = "blue 5px solid", ge.style.transform = "scaleY(-1)", document.body.appendChild(ge), Nr = ge.getContext("2d")), (ge.width !== a.width || ge.height !== a.height) && (ge.width = a.width / 2, ge.height = a.height / 2, ge.style.width = "400px", ge.style.height = "400px");
  const i = a.device.readPixelsToArrayWebGL(a), l = Nr?.createImageData(a.width, a.height);
  if (l) {
    for (let c = 0; c < i.length; c += 4)
      l.data[0 + c + 0] = i[c + 0] * o, l.data[0 + c + 1] = i[c + 1] * o, l.data[0 + c + 2] = i[c + 2] * o, l.data[0 + c + 3] = n ? 255 : i[c + 3] * o;
    Nr?.putImageData(l, 0, 0);
  }
}
function es(a, e, t) {
  if (a === e)
    return !0;
  if (!t || !a || !e)
    return !1;
  if (Array.isArray(a)) {
    if (!Array.isArray(e) || a.length !== e.length)
      return !1;
    for (let n = 0; n < a.length; n++)
      if (!es(a[n], e[n], t - 1))
        return !1;
    return !0;
  }
  if (Array.isArray(e))
    return !1;
  if (typeof a == "object" && typeof e == "object") {
    const n = Object.keys(a), r = Object.keys(e);
    if (n.length !== r.length)
      return !1;
    for (const s of n)
      if (!e.hasOwnProperty(s) || !es(a[s], e[s], t - 1))
        return !1;
    return !0;
  }
  return !1;
}
class Ur {
  bufferLayouts;
  constructor(e) {
    this.bufferLayouts = e;
  }
  getBufferLayout(e) {
    return this.bufferLayouts.find((t) => t.name === e) || null;
  }
  /** Get attribute names from a BufferLayout */
  getAttributeNamesForBuffer(e) {
    return e.attributes ? e.attributes?.map((t) => t.attribute) : [e.name];
  }
  mergeBufferLayouts(e, t) {
    const n = [...e];
    for (const r of t) {
      const s = n.findIndex((o) => o.name === r.name);
      s < 0 ? n.push(r) : n[s] = r;
    }
    return n;
  }
  getBufferIndex(e) {
    const t = this.bufferLayouts.findIndex((n) => n.name === e);
    return t === -1 && te.warn(`BufferLayout: Missing buffer for "${e}".`)(), t;
  }
}
function Jf(a, e) {
  const t = Object.fromEntries(a.attributes.map((r) => [r.name, r.location])), n = e.slice();
  return n.sort((r, s) => {
    const o = r.attributes ? r.attributes.map((c) => c.attribute) : [r.name], i = s.attributes ? s.attributes.map((c) => c.attribute) : [s.name], l = Math.min(...o.map((c) => t[c])), u = Math.min(...i.map((c) => t[c]));
    return l - u;
  }), n;
}
function zf(a) {
  return ArrayBuffer.isView(a) && !(a instanceof DataView);
}
function Hf(a) {
  return Array.isArray(a) ? a.length === 0 || typeof a[0] == "number" : !1;
}
function Zf(a) {
  return zf(a) || Hf(a);
}
function jf(a) {
  return Zf(a) || typeof a == "number" || typeof a == "boolean";
}
function $f(a) {
  const e = { bindings: {}, uniforms: {} };
  return Object.keys(a).forEach((t) => {
    const n = a[t];
    jf(n) ? e.uniforms[t] = n : e.bindings[t] = n;
  }), e;
}
class Xf {
  options = {
    disableWarnings: !1
  };
  /**
   * The map of modules
   * @todo should should this include the resolved dependencies?
   */
  // @ts-ignore Fix typings
  modules;
  /** Stores the uniform values for each module */
  moduleUniforms;
  /** Stores the uniform bindings for each module  */
  moduleBindings;
  /** Tracks if uniforms have changed */
  // moduleUniformsChanged: Record<keyof ShaderPropsT, false | string>;
  /**
   * Create a new UniformStore instance
   * @param modules
   */
  constructor(e, t) {
    Object.assign(this.options, t);
    const n = gs(Object.values(e).filter((r) => r.dependencies));
    for (const r of n)
      e[r.name] = r;
    te.log(1, "Creating ShaderInputs with modules", Object.keys(e))(), this.modules = e, this.moduleUniforms = {}, this.moduleBindings = {};
    for (const [r, s] of Object.entries(e))
      this._addModule(s), s.name && r !== s.name && !this.options.disableWarnings && te.warn(`Module name: ${r} vs ${s.name}`)();
  }
  /** Destroy */
  destroy() {
  }
  /**
   * Set module props
   */
  setProps(e) {
    for (const t of Object.keys(e)) {
      const n = t, r = e[n] || {}, s = this.modules[n];
      if (!s) {
        this.options.disableWarnings || te.warn(`Module ${t} not found`)();
        continue;
      }
      const o = this.moduleUniforms[n], i = this.moduleBindings[n], l = s.getUniforms?.(r, o) || r, { uniforms: u, bindings: c } = $f(l);
      this.moduleUniforms[n] = { ...o, ...u }, this.moduleBindings[n] = { ...i, ...c };
    }
  }
  /**
   * Return the map of modules
   * @todo should should this include the resolved dependencies?
   */
  getModules() {
    return Object.values(this.modules);
  }
  /** Get all uniform values for all modules */
  getUniformValues() {
    return this.moduleUniforms;
  }
  /** Merges all bindings for the shader (from the various modules) */
  getBindingValues() {
    const e = {};
    for (const t of Object.values(this.moduleBindings))
      Object.assign(e, t);
    return e;
  }
  // INTERNAL
  /** Return a debug table that can be used for console.table() or log.table() */
  getDebugTable() {
    const e = {};
    for (const [t, n] of Object.entries(this.moduleUniforms))
      for (const [r, s] of Object.entries(n))
        e[`${t}.${r}`] = {
          type: this.modules[t].uniformTypes?.[r],
          value: String(s)
        };
    return e;
  }
  _addModule(e) {
    const t = e.name;
    this.moduleUniforms[t] = e.defaultUniforms || {}, this.moduleBindings[t] = {};
  }
}
let Kf = "";
async function Yf(a, e) {
  const t = new Image();
  return t.crossOrigin = "anonymous", t.src = a.startsWith("http") ? a : Kf + a, await t.decode(), e ? await createImageBitmap(t, e) : await createImageBitmap(t);
}
const eh = ["+X", "-X", "+Y", "-Y", "+Z", "-Z"], th = ["+X", "-X", "+Y", "-Y", "+Z", "-Z"];
class Ht {
  device;
  id;
  props;
  // TODO - should we type these as possibly `null`? It will make usage harder?
  // @ts-expect-error
  texture;
  // @ts-expect-error
  sampler;
  // @ts-expect-error
  view;
  ready;
  isReady = !1;
  destroyed = !1;
  resolveReady = () => {
  };
  rejectReady = () => {
  };
  get [Symbol.toStringTag]() {
    return "AsyncTexture";
  }
  toString() {
    return `AsyncTexture:"${this.id}"(${this.isReady ? "ready" : "loading"})`;
  }
  constructor(e, t) {
    this.device = e;
    const n = Xn("async-texture");
    this.props = { ...Ht.defaultProps, id: n, ...t }, this.id = this.props.id, t = { ...t }, typeof t?.data == "string" && t.dimension === "2d" && (t.data = Yf(t.data)), t.mipmaps && (t.mipLevels = "auto"), this.ready = new Promise((r, s) => {
      this.resolveReady = () => {
        this.isReady = !0, r();
      }, this.rejectReady = s;
    }), this.initAsync(t);
  }
  async initAsync(e) {
    const t = e.data, n = await ol(t).then(void 0, this.rejectReady);
    if (this.destroyed)
      return;
    const r = this.props.width && this.props.height ? { width: this.props.width, height: this.props.height } : this.getTextureDataSize(n);
    if (!r)
      throw new Error("Texture size could not be determined");
    const s = { ...r, ...e, data: void 0, mipLevels: 1 }, o = this.device.getMipLevelCount(s.width, s.height);
    if (s.mipLevels = this.props.mipLevels === "auto" ? o : Math.min(o, this.props.mipLevels), this.texture = this.device.createTexture(s), this.sampler = this.texture.sampler, this.view = this.texture.view, e.data)
      switch (this.props.dimension) {
        case "1d":
          this._setTexture1DData(this.texture, n);
          break;
        case "2d":
          this._setTexture2DData(n);
          break;
        case "3d":
          this._setTexture3DData(this.texture, n);
          break;
        case "2d-array":
          this._setTextureArrayData(this.texture, n);
          break;
        case "cube":
          this._setTextureCubeData(this.texture, n);
          break;
        case "cube-array":
          this._setTextureCubeArrayData(this.texture, n);
          break;
      }
    this.props.mipmaps && this.generateMipmaps(), te.info(1, `${this} loaded`), this.resolveReady();
  }
  destroy() {
    this.texture && (this.texture.destroy(), this.texture = null), this.destroyed = !0;
  }
  generateMipmaps() {
    this.texture.generateMipmapsWebGL();
  }
  /** Set sampler or create and set new Sampler from SamplerProps */
  setSampler(e = {}) {
    this.texture.setSampler(e instanceof It ? e : this.device.createSampler(e));
  }
  /**
   * Textures are immutable and cannot be resized after creation,
   * but we can create a similar texture with the same parameters but a new size.
   * @note Does not copy contents of the texture
   * @note Mipmaps may need to be regenerated after resizing / setting new data
   * @todo Abort pending promise and create a texture with the new size?
   */
  resize(e) {
    if (!this.isReady)
      throw new Error("Cannot resize texture before it is ready");
    if (e.width === this.texture.width && e.height === this.texture.height)
      return !1;
    if (this.texture) {
      const t = this.texture;
      this.texture = t.clone(e), t.destroy();
    }
    return !0;
  }
  /** Check if texture data is a typed array */
  isTextureLevelData(e) {
    const t = e?.data;
    return ArrayBuffer.isView(t);
  }
  /** Get the size of the texture described by the provided TextureData */
  getTextureDataSize(e) {
    if (!e || ArrayBuffer.isView(e))
      return null;
    if (Array.isArray(e))
      return this.getTextureDataSize(e[0]);
    if (this.device.isExternalImage(e))
      return this.device.getExternalImageSize(e);
    if (e && typeof e == "object" && e.constructor === Object) {
      const n = Object.values(e)[0];
      return { width: n.width, height: n.height };
    }
    throw new Error("texture size deduction failed");
  }
  /** Convert luma.gl cubemap face constants to depth index */
  getCubeFaceDepth(e) {
    switch (e) {
      case "+X":
        return 0;
      case "-X":
        return 1;
      case "+Y":
        return 2;
      case "-Y":
        return 3;
      case "+Z":
        return 4;
      case "-Z":
        return 5;
      default:
        throw new Error(e);
    }
  }
  // EXPERIMENTAL
  setTextureData(e) {
  }
  /** Experimental: Set multiple mip levels */
  _setTexture1DData(e, t) {
    throw new Error("setTexture1DData not supported in WebGL.");
  }
  /** Experimental: Set multiple mip levels */
  _setTexture2DData(e, t = 0) {
    if (!this.texture)
      throw new Error("Texture not initialized");
    const n = this._normalizeTextureData(e);
    n.length > 1 && this.props.mipmaps !== !1 && te.warn(`Texture ${this.id} mipmap and multiple LODs.`)();
    for (let r = 0; r < n.length; r++) {
      const s = n[r];
      this.device.isExternalImage(s) ? this.texture.copyExternalImage({ image: s, depth: t, mipLevel: r, flipY: !0 }) : this.texture.copyImageData({ data: s.data, mipLevel: r });
    }
  }
  /**
   * Experimental: Sets 3D texture data: multiple depth slices, multiple mip levels
   * @param data
   */
  _setTexture3DData(e, t) {
    if (this.texture?.props.dimension !== "3d")
      throw new Error(this.id);
    for (let n = 0; n < t.length; n++)
      this._setTexture2DData(t[n], n);
  }
  /**
   * Experimental: Set Cube texture data, multiple faces, multiple mip levels
   * @todo - could support TextureCubeArray with depth
   * @param data
   * @param index
   */
  _setTextureCubeData(e, t) {
    if (this.texture?.props.dimension !== "cube")
      throw new Error(this.id);
    for (const [n, r] of Object.entries(t)) {
      const s = th.indexOf(n);
      this._setTexture2DData(r, s);
    }
  }
  /**
   * Experimental: Sets texture array data, multiple levels, multiple depth slices
   * @param data
   */
  _setTextureArrayData(e, t) {
    if (this.texture?.props.dimension !== "2d-array")
      throw new Error(this.id);
    for (let n = 0; n < t.length; n++)
      this._setTexture2DData(t[n], n);
  }
  /**
   * Experimental: Sets texture cube array, multiple faces, multiple levels, multiple mip levels
   * @param data
   */
  _setTextureCubeArrayData(e, t) {
    throw new Error("setTextureCubeArrayData not supported in WebGL2.");
  }
  /** Experimental */
  _setTextureCubeFaceData(e, t, n, r = 0) {
    Array.isArray(t) && t.length > 1 && this.props.mipmaps !== !1 && te.warn(`${this.id} has mipmap and multiple LODs.`)();
    const s = eh.indexOf(n);
    this._setTexture2DData(t, s);
  }
  /**
   * Normalize TextureData to an array of TextureImageData / ExternalImages
   * @param data
   * @param options
   * @returns array of TextureImageData / ExternalImages
   */
  _normalizeTextureData(e) {
    const t = this.texture;
    let n;
    return ArrayBuffer.isView(e) ? n = [
      {
        // ts-expect-error does data really need to be Uint8ClampedArray?
        data: e,
        width: t.width,
        height: t.height
        // depth: options.depth
      }
    ] : Array.isArray(e) ? n = e : n = [e], n;
  }
  static defaultProps = {
    ...Ue.defaultProps,
    data: null,
    mipmaps: !1
  };
}
async function ol(a) {
  if (a = await a, Array.isArray(a))
    return await Promise.all(a.map(ol));
  if (a && typeof a == "object" && a.constructor === Object) {
    const e = a, t = await Promise.all(Object.values(e)), n = Object.keys(e), r = {};
    for (let s = 0; s < n.length; s++)
      r[n[s]] = t[s];
    return r;
  }
  return a;
}
const st = 2, nh = 1e4;
class Un {
  static defaultProps = {
    ...wt.defaultProps,
    source: void 0,
    vs: null,
    fs: null,
    id: "unnamed",
    handle: void 0,
    userData: {},
    defines: {},
    modules: [],
    geometry: null,
    indexBuffer: null,
    attributes: {},
    constantAttributes: {},
    varyings: [],
    isInstanced: void 0,
    instanceCount: 0,
    vertexCount: 0,
    shaderInputs: void 0,
    pipelineFactory: void 0,
    shaderFactory: void 0,
    transformFeedback: void 0,
    shaderAssembler: bt.getDefaultShaderAssembler(),
    debugShaders: void 0,
    disableWarnings: void 0
  };
  device;
  id;
  // @ts-expect-error assigned in function called from constructor
  source;
  // @ts-expect-error assigned in function called from constructor
  vs;
  // @ts-expect-error assigned in function called from constructor
  fs;
  pipelineFactory;
  shaderFactory;
  userData = {};
  // Fixed properties (change can trigger pipeline rebuild)
  /** The render pipeline GPU parameters, depth testing etc */
  parameters;
  /** The primitive topology */
  topology;
  /** Buffer layout */
  bufferLayout;
  // Dynamic properties
  /** Use instanced rendering */
  isInstanced = void 0;
  /** instance count. `undefined` means not instanced */
  instanceCount = 0;
  /** Vertex count */
  vertexCount;
  /** Index buffer */
  indexBuffer = null;
  /** Buffer-valued attributes */
  bufferAttributes = {};
  /** Constant-valued attributes */
  constantAttributes = {};
  /** Bindings (textures, samplers, uniform buffers) */
  bindings = {};
  /**
   * VertexArray
   * @note not implemented: if bufferLayout is updated, vertex array has to be rebuilt!
   * @todo - allow application to define multiple vertex arrays?
   * */
  vertexArray;
  /** TransformFeedback, WebGL 2 only. */
  transformFeedback = null;
  /** The underlying GPU "program". @note May be recreated if parameters change */
  pipeline;
  /** ShaderInputs instance */
  // @ts-expect-error Assigned in function called by constructor
  shaderInputs;
  // @ts-expect-error Assigned in function called by constructor
  _uniformStore;
  _attributeInfos = {};
  _gpuGeometry = null;
  props;
  _pipelineNeedsUpdate = "newly created";
  _needsRedraw = "initializing";
  _destroyed = !1;
  /** "Time" of last draw. Monotonically increasing timestamp */
  _lastDrawTimestamp = -1;
  get [Symbol.toStringTag]() {
    return "Model";
  }
  toString() {
    return `Model(${this.id})`;
  }
  constructor(e, t) {
    this.props = { ...Un.defaultProps, ...t }, t = this.props, this.id = t.id || Xn("model"), this.device = e, Object.assign(this.userData, t.userData);
    const n = Object.fromEntries(this.props.modules?.map((l) => [l.name, l]) || []), r = t.shaderInputs || new Xf(n, { disableWarnings: this.props.disableWarnings });
    this.setShaderInputs(r);
    const s = sh(e), o = (
      // @ts-ignore shaderInputs is assigned in setShaderInputs above.
      (this.props.modules?.length > 0 ? this.props.modules : this.shaderInputs?.getModules()) || []
    );
    if (this.device.type === "webgpu" && this.props.source) {
      const { source: l, getUniforms: u } = this.props.shaderAssembler.assembleWGSLShader({
        platformInfo: s,
        ...this.props,
        modules: o
      });
      this.source = l, this._getModuleUniforms = u, this.props.shaderLayout ||= Uf(this.source);
    } else {
      const { vs: l, fs: u, getUniforms: c } = this.props.shaderAssembler.assembleGLSLShaderPair({
        platformInfo: s,
        ...this.props,
        modules: o
      });
      this.vs = l, this.fs = u, this._getModuleUniforms = c;
    }
    this.vertexCount = this.props.vertexCount, this.instanceCount = this.props.instanceCount, this.topology = this.props.topology, this.bufferLayout = this.props.bufferLayout, this.parameters = this.props.parameters, t.geometry && this.setGeometry(t.geometry), this.pipelineFactory = t.pipelineFactory || Is.getDefaultPipelineFactory(this.device), this.shaderFactory = t.shaderFactory || _s.getDefaultShaderFactory(this.device), this.pipeline = this._updatePipeline(), this.vertexArray = e.createVertexArray({
      shaderLayout: this.pipeline.shaderLayout,
      bufferLayout: this.pipeline.bufferLayout
    }), this._gpuGeometry && this._setGeometryAttributes(this._gpuGeometry), "isInstanced" in t && (this.isInstanced = t.isInstanced), t.instanceCount && this.setInstanceCount(t.instanceCount), t.vertexCount && this.setVertexCount(t.vertexCount), t.indexBuffer && this.setIndexBuffer(t.indexBuffer), t.attributes && this.setAttributes(t.attributes), t.constantAttributes && this.setConstantAttributes(t.constantAttributes), t.bindings && this.setBindings(t.bindings), t.transformFeedback && (this.transformFeedback = t.transformFeedback), Object.seal(this);
  }
  destroy() {
    this._destroyed || (this.pipelineFactory.release(this.pipeline), this.shaderFactory.release(this.pipeline.vs), this.pipeline.fs && this.shaderFactory.release(this.pipeline.fs), this._uniformStore.destroy(), this._gpuGeometry?.destroy(), this._destroyed = !0);
  }
  // Draw call
  /** Query redraw status. Clears the status. */
  needsRedraw() {
    this._getBindingsUpdateTimestamp() > this._lastDrawTimestamp && this.setNeedsRedraw("contents of bound textures or buffers updated");
    const e = this._needsRedraw;
    return this._needsRedraw = !1, e;
  }
  /** Mark the model as needing a redraw */
  setNeedsRedraw(e) {
    this._needsRedraw ||= e;
  }
  predraw() {
    this.updateShaderInputs(), this.pipeline = this._updatePipeline();
  }
  draw(e) {
    const t = this._areBindingsLoading();
    if (t)
      return te.info(st, `>>> DRAWING ABORTED ${this.id}: ${t} not loaded`)(), !1;
    try {
      e.pushDebugGroup(`${this}.predraw(${e})`), this.predraw();
    } finally {
      e.popDebugGroup();
    }
    let n;
    try {
      e.pushDebugGroup(`${this}.draw(${e})`), this._logDrawCallStart(), this.pipeline = this._updatePipeline();
      const r = this._getBindings();
      this.pipeline.setBindings(r, {
        disableWarnings: this.props.disableWarnings
      });
      const { indexBuffer: s } = this.vertexArray, o = s ? s.byteLength / (s.indexType === "uint32" ? 4 : 2) : void 0;
      n = this.pipeline.draw({
        renderPass: e,
        vertexArray: this.vertexArray,
        isInstanced: this.isInstanced,
        vertexCount: this.vertexCount,
        instanceCount: this.instanceCount,
        indexCount: o,
        transformFeedback: this.transformFeedback || void 0,
        // WebGL shares underlying cached pipelines even for models that have different parameters and topology,
        // so we must provide our unique parameters to each draw
        // (In WebGPU most parameters are encoded in the pipeline and cannot be changed per draw call)
        parameters: this.parameters,
        topology: this.topology
      });
    } finally {
      e.popDebugGroup(), this._logDrawCallEnd();
    }
    return this._logFramebuffer(e), n ? (this._lastDrawTimestamp = this.device.timestamp, this._needsRedraw = !1) : this._needsRedraw = "waiting for resource initialization", n;
  }
  // Update fixed fields (can trigger pipeline rebuild)
  /**
   * Updates the optional geometry
   * Geometry, set topology and bufferLayout
   * @note Can trigger a pipeline rebuild / pipeline cache fetch on WebGPU
   */
  setGeometry(e) {
    this._gpuGeometry?.destroy();
    const t = e && Ff(this.device, e);
    if (t) {
      this.setTopology(t.topology || "triangle-list");
      const n = new Ur(this.bufferLayout);
      this.bufferLayout = n.mergeBufferLayouts(t.bufferLayout, this.bufferLayout), this.vertexArray && this._setGeometryAttributes(t);
    }
    this._gpuGeometry = t;
  }
  /**
   * Updates the primitive topology ('triangle-list', 'triangle-strip' etc).
   * @note Triggers a pipeline rebuild / pipeline cache fetch on WebGPU
   */
  setTopology(e) {
    e !== this.topology && (this.topology = e, this._setPipelineNeedsUpdate("topology"));
  }
  /**
   * Updates the buffer layout.
   * @note Triggers a pipeline rebuild / pipeline cache fetch
   */
  setBufferLayout(e) {
    const t = new Ur(this.bufferLayout);
    this.bufferLayout = this._gpuGeometry ? t.mergeBufferLayouts(e, this._gpuGeometry.bufferLayout) : e, this._setPipelineNeedsUpdate("bufferLayout"), this.pipeline = this._updatePipeline(), this.vertexArray = this.device.createVertexArray({
      shaderLayout: this.pipeline.shaderLayout,
      bufferLayout: this.pipeline.bufferLayout
    }), this._gpuGeometry && this._setGeometryAttributes(this._gpuGeometry);
  }
  /**
   * Set GPU parameters.
   * @note Can trigger a pipeline rebuild / pipeline cache fetch.
   * @param parameters
   */
  setParameters(e) {
    es(e, this.parameters, 2) || (this.parameters = e, this._setPipelineNeedsUpdate("parameters"));
  }
  // Update dynamic fields
  /**
   * Updates the instance count (used in draw calls)
   * @note Any attributes with stepMode=instance need to be at least this big
   */
  setInstanceCount(e) {
    this.instanceCount = e, this.isInstanced === void 0 && e > 0 && (this.isInstanced = !0), this.setNeedsRedraw("instanceCount");
  }
  /**
   * Updates the vertex count (used in draw calls)
   * @note Any attributes with stepMode=vertex need to be at least this big
   */
  setVertexCount(e) {
    this.vertexCount = e, this.setNeedsRedraw("vertexCount");
  }
  /** Set the shader inputs */
  setShaderInputs(e) {
    this.shaderInputs = e, this._uniformStore = new Bu(this.shaderInputs.modules);
    for (const [t, n] of Object.entries(this.shaderInputs.modules))
      if (rh(n)) {
        const r = this._uniformStore.getManagedUniformBuffer(this.device, t);
        this.bindings[`${t}Uniforms`] = r;
      }
    this.setNeedsRedraw("shaderInputs");
  }
  /** Update uniform buffers from the model's shader inputs */
  updateShaderInputs() {
    this._uniformStore.setUniforms(this.shaderInputs.getUniformValues()), this.setBindings(this.shaderInputs.getBindingValues()), this.setNeedsRedraw("shaderInputs");
  }
  /**
   * Sets bindings (textures, samplers, uniform buffers)
   */
  setBindings(e) {
    Object.assign(this.bindings, e), this.setNeedsRedraw("bindings");
  }
  /**
   * Updates optional transform feedback. WebGL only.
   */
  setTransformFeedback(e) {
    this.transformFeedback = e, this.setNeedsRedraw("transformFeedback");
  }
  /**
   * Sets the index buffer
   * @todo - how to unset it if we change geometry?
   */
  setIndexBuffer(e) {
    this.vertexArray.setIndexBuffer(e), this.setNeedsRedraw("indexBuffer");
  }
  /**
   * Sets attributes (buffers)
   * @note Overrides any attributes previously set with the same name
   */
  setAttributes(e, t) {
    const n = t?.disableWarnings ?? this.props.disableWarnings;
    e.indices && te.warn(`Model:${this.id} setAttributes() - indexBuffer should be set using setIndexBuffer()`)(), this.bufferLayout = Jf(this.pipeline.shaderLayout, this.bufferLayout);
    const r = new Ur(this.bufferLayout);
    for (const [s, o] of Object.entries(e)) {
      const i = r.getBufferLayout(s);
      if (!i) {
        n || te.warn(`Model(${this.id}): Missing layout for buffer "${s}".`)();
        continue;
      }
      const l = r.getAttributeNamesForBuffer(i);
      let u = !1;
      for (const c of l) {
        const f = this._attributeInfos[c];
        if (f) {
          const h = this.device.type === "webgpu" ? r.getBufferIndex(f.bufferName) : f.location;
          this.vertexArray.setBuffer(h, o), u = !0;
        }
      }
      !u && !n && te.warn(`Model(${this.id}): Ignoring buffer "${o.id}" for unknown attribute "${s}"`)();
    }
    this.setNeedsRedraw("attributes");
  }
  /**
   * Sets constant attributes
   * @note Overrides any attributes previously set with the same name
   * Constant attributes are only supported in WebGL, not in WebGPU
   * Any attribute that is disabled in the current vertex array object
   * is read from the context's global constant value for that attribute location.
   * @param constantAttributes
   */
  setConstantAttributes(e, t) {
    for (const [n, r] of Object.entries(e)) {
      const s = this._attributeInfos[n];
      s ? this.vertexArray.setConstantWebGL(s.location, r) : (t?.disableWarnings ?? this.props.disableWarnings) || te.warn(`Model "${this.id}: Ignoring constant supplied for unknown attribute "${n}"`)();
    }
    this.setNeedsRedraw("constants");
  }
  // INTERNAL METHODS
  /** Check that bindings are loaded. Returns id of first binding that is still loading. */
  _areBindingsLoading() {
    for (const e of Object.values(this.bindings))
      if (e instanceof Ht && !e.isReady)
        return e.id;
    return !1;
  }
  /** Extracts texture view from loaded async textures. Returns null if any textures have not yet been loaded. */
  _getBindings() {
    const e = {};
    for (const [t, n] of Object.entries(this.bindings))
      n instanceof Ht ? n.isReady && (e[t] = n.texture) : e[t] = n;
    return e;
  }
  /** Get the timestamp of the latest updated bound GPU memory resource (buffer/texture). */
  _getBindingsUpdateTimestamp() {
    let e = 0;
    for (const t of Object.values(this.bindings))
      t instanceof ds ? e = Math.max(e, t.texture.updateTimestamp) : t instanceof Te || t instanceof Ue ? e = Math.max(e, t.updateTimestamp) : t instanceof Ht ? e = t.texture ? Math.max(e, t.texture.updateTimestamp) : (
        // The texture will become available in the future
        1 / 0
      ) : t instanceof It || (e = Math.max(e, t.buffer.updateTimestamp));
    return e;
  }
  /**
   * Updates the optional geometry attributes
   * Geometry, sets several attributes, indexBuffer, and also vertex count
   * @note Can trigger a pipeline rebuild / pipeline cache fetch on WebGPU
   */
  _setGeometryAttributes(e) {
    const t = { ...e.attributes };
    for (const [n] of Object.entries(t))
      !this.pipeline.shaderLayout.attributes.find((r) => r.name === n) && n !== "positions" && delete t[n];
    this.vertexCount = e.vertexCount, this.setIndexBuffer(e.indices || null), this.setAttributes(e.attributes, { disableWarnings: !0 }), this.setAttributes(t, { disableWarnings: this.props.disableWarnings }), this.setNeedsRedraw("geometry attributes");
  }
  /** Mark pipeline as needing update */
  _setPipelineNeedsUpdate(e) {
    this._pipelineNeedsUpdate ||= e, this.setNeedsRedraw(e);
  }
  /** Update pipeline if needed */
  _updatePipeline() {
    if (this._pipelineNeedsUpdate) {
      let e = null, t = null;
      this.pipeline && (te.log(1, `Model ${this.id}: Recreating pipeline because "${this._pipelineNeedsUpdate}".`)(), e = this.pipeline.vs, t = this.pipeline.fs), this._pipelineNeedsUpdate = !1;
      const n = this.shaderFactory.createShader({
        id: `${this.id}-vertex`,
        stage: "vertex",
        source: this.source || this.vs,
        debugShaders: this.props.debugShaders
      });
      let r = null;
      this.source ? r = n : this.fs && (r = this.shaderFactory.createShader({
        id: `${this.id}-fragment`,
        stage: "fragment",
        source: this.source || this.fs,
        debugShaders: this.props.debugShaders
      })), this.pipeline = this.pipelineFactory.createRenderPipeline({
        ...this.props,
        bufferLayout: this.bufferLayout,
        topology: this.topology,
        parameters: this.parameters,
        // TODO - why set bindings here when we reset them every frame?
        // Should we expose a BindGroup abstraction?
        bindings: this._getBindings(),
        vs: n,
        fs: r
      }), this._attributeInfos = mu(this.pipeline.shaderLayout, this.bufferLayout), e && this.shaderFactory.release(e), t && this.shaderFactory.release(t);
    }
    return this.pipeline;
  }
  /** Throttle draw call logging */
  _lastLogTime = 0;
  _logOpen = !1;
  _logDrawCallStart() {
    const e = te.level > 3 ? 0 : nh;
    te.level < 2 || Date.now() - this._lastLogTime < e || (this._lastLogTime = Date.now(), this._logOpen = !0, te.group(st, `>>> DRAWING MODEL ${this.id}`, { collapsed: te.level <= 2 })());
  }
  _logDrawCallEnd() {
    if (this._logOpen) {
      const e = qf(this.pipeline.shaderLayout, this.id);
      te.table(st, e)();
      const t = this.shaderInputs.getDebugTable();
      te.table(st, t)();
      const n = this._getAttributeDebugTable();
      te.table(st, this._attributeInfos)(), te.table(st, n)(), te.groupEnd(st)(), this._logOpen = !1;
    }
  }
  _drawCount = 0;
  _logFramebuffer(e) {
    const t = this.device.props.debugFramebuffers;
    if (this._drawCount++, !t)
      return;
    const n = e.props.framebuffer;
    n && Gf(n, { id: n.id, minimap: !0 });
  }
  _getAttributeDebugTable() {
    const e = {};
    for (const [t, n] of Object.entries(this._attributeInfos)) {
      const r = this.vertexArray.attributes[n.location];
      e[n.location] = {
        name: t,
        type: n.shaderType,
        values: r ? this._getBufferOrConstantValues(r, n.bufferDataType) : "null"
      };
    }
    if (this.vertexArray.indexBuffer) {
      const { indexBuffer: t } = this.vertexArray, n = t.indexType === "uint32" ? new Uint32Array(t.debugData) : new Uint16Array(t.debugData);
      e.indices = {
        name: "indices",
        type: t.indexType,
        values: n.toString()
      };
    }
    return e;
  }
  // TODO - fix typing of luma data types
  _getBufferOrConstantValues(e, t) {
    const n = Yc(t);
    return (e instanceof Te ? new n(e.debugData) : e).toString();
  }
}
function rh(a) {
  return !!(a.uniformTypes && !ah(a.uniformTypes));
}
function sh(a) {
  return {
    type: a.type,
    shaderLanguage: a.info.shadingLanguage,
    shaderLanguageVersion: a.info.shadingLanguageVersion,
    gpu: a.info.gpu,
    // HACK - we pretend that the DeviceFeatures is a Set, it has a similar API
    features: a.features
  };
}
function ah(a) {
  for (const e in a)
    return !1;
  return !0;
}
class Vn {
  device;
  model;
  transformFeedback;
  static defaultProps = {
    ...Un.defaultProps,
    outputs: void 0,
    feedbackBuffers: void 0
  };
  static isSupported(e) {
    return e?.info?.type === "webgl";
  }
  constructor(e, t = Vn.defaultProps) {
    if (!Vn.isSupported(e))
      throw new Error("BufferTransform not yet implemented on WebGPU");
    this.device = e, this.model = new Un(this.device, {
      id: t.id || "buffer-transform-model",
      fs: t.fs || nf(),
      topology: t.topology || "point-list",
      varyings: t.outputs || t.varyings,
      ...t
    }), this.transformFeedback = this.device.createTransformFeedback({
      layout: this.model.pipeline.shaderLayout,
      // @ts-expect-error TODO
      buffers: t.feedbackBuffers
    }), this.model.setTransformFeedback(this.transformFeedback), Object.seal(this);
  }
  /** Destroy owned resources. */
  destroy() {
    this.model && this.model.destroy();
  }
  /** @deprecated Use {@link destroy}. */
  delete() {
    this.destroy();
  }
  /** Run one transform loop. */
  run(e) {
    e?.inputBuffers && this.model.setAttributes(e.inputBuffers), e?.outputBuffers && this.transformFeedback.setBuffers(e.outputBuffers);
    const t = this.device.beginRenderPass(e);
    this.model.draw(t), t.end();
  }
  // DEPRECATED METHODS
  /** @deprecated App knows what buffers it is passing in - Returns the {@link Buffer} or {@link BufferRange} for given varying name. */
  getBuffer(e) {
    return this.transformFeedback.getBuffer(e);
  }
  /** @deprecated App knows what buffers it is passing in - Reads the {@link Buffer} or {@link BufferRange} for given varying name. */
  readAsync(e) {
    const t = this.getBuffer(e);
    if (!t)
      throw new Error("BufferTransform#getBuffer");
    if (t instanceof Te)
      return t.readAsync();
    const { buffer: n, byteOffset: r = 0, byteLength: s = n.byteLength } = t;
    return n.readAsync(r, s);
  }
}
const Ha = /* @__PURE__ */ new Map();
function ih(a, e) {
  if (!e) return `${Math.round(a)}`;
  const { scale: t = 1, offset: n = 0, decimals: r = 0 } = e, s = t * a + n;
  return `${r ? Math.round(s * 10 ** r) / 10 ** r : Math.round(s)}`;
}
const Fn = [255, 255, 255], Cs = '"Helvetica Neue", Arial, Helvetica, sans-serif', Es = [255, 255, 255], ks = [13, 13, 13], ll = ih, oh = [255, 255, 255];
function he(a, e) {
  const t = {};
  for (const n in a) if (a[n] === void 0 && n in e) {
    const r = e[n];
    r && ("value" in r ? r.value && (t[n] = r.value) : t[n] = r);
  }
  return Object.freeze({ ...a, ...t });
}
const lh = /* @__PURE__ */ new Map(), ch = new class {
  constructor() {
    this.queue = Promise.resolve();
  }
  async run(a) {
    const e = this.queue;
    let t;
    this.queue = new Promise(((n) => {
      t = n;
    }));
    try {
      return await e, await a();
    } finally {
      t();
    }
  }
}();
async function uh(a, e) {
  const t = await (async function(i) {
    if (Ha.has(i)) return Ha.get(i);
    try {
      if (i === "geotiff") return await import("./__vite-optional-peer-dep_geotiff_weatherlayers-gl_false-Cjw5BclT.js");
    } catch (l) {
      throw new Error(`Optional dependency '${i}' is missing, install it with a package manager or provide with \`setLibrary('${i}', library)\``, { cause: l });
    }
  })("geotiff");
  let n;
  try {
    n = await t.fromUrl(a, { allowFullFile: !0, blockSize: Number.MAX_SAFE_INTEGER, fetch: (i, l) => fetch(i, { ...l, headers: { ...l?.headers, ...e?.headers } }) }, e?.signal);
  } catch (i) {
    throw new Error(`Image ${a} can't be decoded.`, { cause: i });
  }
  const r = await n.getImage(0), s = await r.readRasters({ interleave: !0, signal: e?.signal });
  if (!(s instanceof Uint8Array || s instanceof Uint8ClampedArray || s instanceof Float32Array)) throw new Error("Unsupported data format");
  return { data: (function(i, l) {
    if (l == null) return i;
    const u = i.slice(0);
    for (let c = 0; c < u.length; c++) Math.abs(u[c] - l) < 2 * Number.EPSILON && (u[c] = NaN);
    return u;
  })(s, r.getGDALNoData()), width: r.getWidth(), height: r.getHeight() };
}
function fh(a) {
  return async (e, t) => {
    if (t?.cache === !1) return a(e);
    const n = t?.cache ?? lh, r = e + (t?.headers ? ":" + JSON.stringify(t?.headers) : ""), s = n.get(r);
    if (s) return s;
    const o = { ...t, cache: void 0 }, i = a(e, o);
    return n.set(r, i), i.then(((l) => {
      n.set(r, l);
    })), i;
  };
}
const cl = fh((async (a, e) => {
  if (a.includes(".png") || a.includes(".webp") || a.includes("image/png") || a.includes("image/webp")) return (async function(t, n) {
    let r;
    if (n?.headers || n?.signal) {
      const h = await fetch(t, { headers: n.headers, signal: n.signal });
      if (!h.ok) throw new Error(`URL ${t} can't be loaded. Status: ${h.status}`);
      const p = await h.blob();
      r = URL.createObjectURL(p);
    }
    const s = new Image();
    try {
      await new Promise(((h, p) => {
        s.addEventListener("load", h), s.addEventListener("error", p), s.crossOrigin = "anonymous", s.src = r ?? t;
      }));
    } catch (h) {
      throw new Error(`URL ${t} can't be loaded.`, { cause: h });
    } finally {
      r && URL.revokeObjectURL(r);
    }
    try {
      await ch.run((() => s.decode()));
    } catch (h) {
      throw new Error(`Image ${t} can't be decoded.`, { cause: h });
    }
    const o = document.createElement("canvas");
    o.width = s.width, o.height = s.height;
    const i = o.getContext("2d");
    i.drawImage(s, 0, 0);
    const l = i.getImageData(0, 0, o.width, o.height), { data: u, width: c, height: f } = l;
    return { data: u, width: c, height: f };
  })(a, e);
  if (a.includes(".tif") || a.includes("image/tif")) return uh(a, e);
  throw new Error("Unsupported data format");
})), Ze = { NEAREST: "NEAREST", LINEAR: "LINEAR", CUBIC: "CUBIC" }, xe = { SCALAR: "SCALAR", VECTOR: "VECTOR" };
function ln(a) {
  return a % 1;
}
function Vr(a, e) {
  return a.map(((t, n) => a[n] + e[n]));
}
function cn(a, e) {
  return a.map(((t, n) => a[n] * e));
}
function un(a, e) {
  return a.map(((t, n) => a[n] * e[n])).reduce(((t, n) => t + n));
}
function Ct(a, e, t) {
  return a === e ? a : a * (1 - t) + e * t;
}
function xn(a, e, t) {
  return a.map(((n, r) => Ct(a[r], e[r], t)));
}
function hh(a, e) {
  return e ? a[3] >= 255 : !isNaN(a[0]);
}
function ul(a, e, t) {
  return e === xe.VECTOR ? t ? [Ct(t[0], t[1], a[0] / 255), Ct(t[0], t[1], a[1] / 255)] : [a[0], a[1]] : [NaN, NaN];
}
function dh(a, e, t) {
  if (e === xe.VECTOR) {
    const n = ul(a, e, t);
    return Math.hypot(n[0], n[1]);
  }
  return (function(n, r, s) {
    return r === xe.VECTOR ? 0 : s ? Ct(s[0], s[1], n[0] / 255) : n[0];
  })(a, e, t);
}
function de(a, e, t, n, r, s) {
  const { data: o, width: i, height: l } = a, u = o.length / (i * l), c = (t + r + 0.5) / e[0], f = (n + s + 0.5) / e[1], h = Math.max(0, Math.min(i - 1, Math.floor(c * i))), p = Math.max(0, Math.min(l - 1, Math.floor(f * l)));
  return new Array(u).fill(void 0).map(((v, I) => o[(h + p * i) * u + I]));
}
const Za = [3, -6, 0, 4].map(((a) => a / 6)), ja = [-1, 6, -12, 8].map(((a) => a / 6));
function fn(a) {
  return [a * a * a, a * a, a, 1];
}
function Dt(a, e, t, n, r) {
  const s = Vr(Vr(Vr(cn(a, un(ja, fn(r + 1))), cn(e, un(Za, fn(r)))), cn(t, un(Za, fn(1 - r)))), cn(n, un(ja, fn(2 - r))));
  return s[3] = a[3] > 0 && e[3] > 0 && t[3] > 0 && n[3] > 0 ? Math.max(Math.max(Math.max(a[3], e[3]), t[3]), n[3]) : 0, s;
}
function Fr(a, e, t, n, r) {
  return t === Ze.CUBIC ? (function(s, o, i, l) {
    const u = i * o[0] - 0.5, c = l * o[1] - 0.5, f = Math.floor(u), h = Math.floor(c), p = ln(u), v = ln(c);
    return Dt(Dt(de(s, o, f, h, -1, -1), de(s, o, f, h, 0, -1), de(s, o, f, h, 1, -1), de(s, o, f, h, 2, -1), p), Dt(de(s, o, f, h, -1, 0), de(s, o, f, h, 0, 0), de(s, o, f, h, 1, 0), de(s, o, f, h, 2, 0), p), Dt(de(s, o, f, h, -1, 1), de(s, o, f, h, 0, 1), de(s, o, f, h, 1, 1), de(s, o, f, h, 2, 1), p), Dt(de(s, o, f, h, -1, 2), de(s, o, f, h, 0, 2), de(s, o, f, h, 1, 2), de(s, o, f, h, 2, 2), p), v);
  })(a, e, n, r) : t === Ze.LINEAR ? (function(s, o, i, l) {
    const u = i * o[0] - 0.5, c = l * o[1] - 0.5, f = Math.floor(u), h = Math.floor(c), p = ln(u), v = ln(c);
    return xn(xn(de(s, o, f, h, 0, 0), de(s, o, f, h, 1, 0), p), xn(de(s, o, f, h, 0, 1), de(s, o, f, h, 1, 1), p), v);
  })(a, e, n, r) : (function(s, o, i, l) {
    const u = i * o[0] - 0.5, c = l * o[1] - 0.5;
    return de(s, o, Math.round(u), Math.round(c), 0, 0);
  })(a, e, n, r);
}
function ph(a, e, t, n, r, s, o, i) {
  const l = s ? o + 0.5 / t[0] : Ct(0 + 0.5 / t[0], 1 - 0.5 / t[0], o), u = Ct(0 + 0.5 / t[1], 1 - 0.5 / t[1], i);
  return e && r > 0 ? xn(Fr(a, t, n, l, u), Fr(e, t, n, l, u), r) : Fr(a, t, n, l, u);
}
function mh(a, e, t) {
  const n = 1 + Math.max(0, t);
  return [a / n, e / n];
}
const gh = -180, Ah = 180, yh = -85.051129, bh = 85.051129;
function ts(a, e) {
  let t = ((a + 180) % (n = 360) + n) % n - 180;
  var n;
  return typeof e == "number" && t < e && (t += 360), t;
}
function tt(a) {
  return a[2] - a[0] == 360;
}
function Pt(a, e) {
  return { type: "Feature", geometry: { type: "Point", coordinates: a }, properties: e };
}
function vh(a, e, t) {
  const { image: n, image2: r, imageSmoothing: s, imageInterpolation: o, imageWeight: i, imageType: l, imageUnscale: u, imageMinValue: c, imageMaxValue: f } = a, { width: h, height: p } = n, v = (function(L, E, C) {
    const Q = [C[0], C[3]], M = (C[2] - C[0]) / L, Z = (C[3] - C[1]) / E;
    return (z) => {
      const [N, G] = z;
      return [(N - Q[0]) / M, (Q[1] - G) / Z];
    };
  })(h, p, e), I = mh(h, p, s), y = tt(e);
  return { type: "FeatureCollection", features: t.map(((L) => {
    if (!(function(z, N) {
      return z[0] >= N[0] && z[0] <= N[2] && z[1] >= N[1] && z[1] <= N[3];
    })(L, e)) return Pt(L, { value: NaN });
    const E = v(L), C = E[0] / h, Q = E[1] / p, M = ph(n, r, I, o, i, y, C, Q);
    if (!hh(M, u)) return Pt(L, { value: NaN });
    const Z = dh(M, l, u);
    if (typeof c == "number" && !isNaN(c) && Z < c || typeof f == "number" && !isNaN(f) && Z > f) return Pt(L, { value: NaN });
    if (l === xe.VECTOR) {
      const z = (function(N, G, S) {
        if (G === xe.VECTOR) {
          const q = ul(N, G, S);
          return (360 - (Math.atan2(q[1], q[0]) / Math.PI * 180 + 180) - 270) % 360;
        }
        return NaN;
      })(M, l, u);
      return Pt(L, { value: Z, direction: z });
    }
    return Pt(L, { value: Z });
  })) };
}
const xh = /* @__PURE__ */ new WeakMap(), wh = /* @__PURE__ */ new WeakMap();
function Ih(a, e) {
  const { data: t, width: n, height: r } = e, s = t.length / (n * r);
  if (t instanceof Uint8Array || t instanceof Uint8ClampedArray) {
    if (s === 4) return "rgba8unorm";
    if (s === 2) return "rg8unorm";
    if (s === 1) return "r8unorm";
    throw new Error("Unsupported data format");
  }
  if (t instanceof Float32Array) {
    if (!a.features.has("float32-renderable-webgl")) throw new Error("Float textures are required");
    if (s === 2) return "rg32float";
    if (s === 1) return "r32float";
    throw new Error("Unsupported data format");
  }
  throw new Error("Unsupported data format");
}
function nt(a, e, t = !1) {
  const n = t ? xh : wh, r = n.get(a) ?? (() => {
    const s = /* @__PURE__ */ new WeakMap();
    return n.set(a, s), s;
  })();
  return r.get(e) ?? (() => {
    const s = a.createTexture({ format: Ih(a, e), width: e.width, height: e.height, mipLevels: 1, sampler: { magFilter: "nearest", minFilter: "nearest", addressModeU: t ? "repeat" : "clamp-to-edge", addressModeV: "clamp-to-edge", lodMaxClamp: 0 } });
    return s.copyImageData({ data: e.data }), r.set(e, s), s;
  })();
}
let hn = null;
function Ie(a) {
  return hn || (hn = a.createTexture({ width: 1, height: 1, mipLevels: 1 }), hn.copyImageData({ data: new Uint8Array([0, 0, 0, 0]) })), hn;
}
const fl = 6370972;
function Qe(a, e) {
  return fc(a, e, fl);
}
function _h(a, e, t) {
  return dc(a, e, t, fl);
}
function We(a) {
  return !!a.resolution;
}
function hl(a) {
  return !We(a);
}
function Bt(a, e, t) {
  return !(e != null && a.zoom < e) && !(t != null && a.zoom > t);
}
function Ts(a) {
  return [a.longitude, a.latitude];
}
function dl(a) {
  const e = Ts(a);
  return Math.max(Qe(e, a.unproject([a.width / 2, 0])), Qe(e, a.unproject([0, a.height / 2])), ...a.width > a.height ? [Qe(e, a.unproject([a.width / 2 - a.height / 4 * 1, a.height / 2])), Qe(e, a.unproject([a.width / 2 - a.height / 2 * 1, a.height / 2])), Qe(e, a.unproject([a.width / 2 - a.height / 4 * 3, a.height / 2])), Qe(e, a.unproject([a.width / 2 - a.height, a.height / 2]))] : [Qe(e, a.unproject([a.width / 2, a.height / 2 - a.width / 4 * 1])), Qe(e, a.unproject([a.width / 2, a.height / 2 - a.width / 2 * 1])), Qe(e, a.unproject([a.width / 2, a.height / 2 - a.width / 4 * 3])), Qe(e, a.unproject([a.width / 2, a.height / 2 - a.width]))]);
}
function pl(a) {
  return (function(e) {
    const t = e[2] - e[0] < 360 ? ts(e[0]) : gh, n = e[2] - e[0] < 360 ? ts(e[2], t) : Ah;
    return [t, Math.max(e[1], yh), n, Math.min(e[3], bh)];
  })(a.getBounds());
}
function Zt(a) {
  return We(a) ? Math.log2(a.scale) : a.zoom;
}
function $a(a, e) {
  return e * (We(a) ? -1 : 1);
}
function Ye(a, e) {
  return e + (We(a) ? 180 : 0);
}
function Bs(a, e) {
  const t = e.domain(), n = [t[0], t[t.length - 1]], r = lc(e), s = a.createTexture({ width: r.width, height: r.height, mipLevels: 1, sampler: { magFilter: "linear", minFilter: "linear", addressModeU: "clamp-to-edge", addressModeV: "clamp-to-edge" } });
  return s.copyExternalImage({ image: r }), { paletteBounds: n, paletteTexture: s };
}
function Rn(a) {
  return [a[0] / 255, a[1] / 255, a[2] / 255, (a[3] ?? 255) / 255];
}
function Wn(a) {
  return [a[0], a[1], a[2], 255 * a[3]];
}
const Xa = "uniform bitmap2Uniforms{vec4 A;bool B;float C;vec4 D;}bitmap2;const float E=512.;const float F=3.1415926536;const float G=E/F/2.;vec2 H(vec2 I){float J=I.x;float K=clamp(I.y,-89.9,89.9);return vec2(radians(J)+F,F+log(tan(F*0.25+radians(K)*0.5)))*G;}vec2 L(vec2 M){M/=G;return degrees(vec2(M.x-F,atan(exp(M.y-F))*2.-F*0.5));}vec4 N(vec3 O,float P){return mix(bitmap2.D,vec4(O,1.),P);}vec2 Q(vec2 R){return vec2((R.x-bitmap2.A[0])/(bitmap2.A[2]-bitmap2.A[0]),(R.y-bitmap2.A[3])/(bitmap2.A[1]-bitmap2.A[3]));}vec2 S(vec2 T,vec2 U){vec2 uv=T;if(bitmap2.C<-0.5){vec2 I=L(U);uv=Q(I);}else if(bitmap2.C>0.5){vec2 V=H(U);uv=Q(V);}return uv;}", Ka = "A", Ya = "B", ei = "C", ti = "D", xt = Math.PI, Ch = xt / 4, ni = xt / 180, ri = 512;
function si(a) {
  const [e, t] = a, n = t * ni;
  return [ri * (e * ni + xt) / (2 * xt), ri * (xt + Math.log(Math.tan(Ch + 0.5 * n))) / (2 * xt)];
}
function Eh(a = {}) {
  const { LNGLAT: e, CARTESIAN: t, DEFAULT: n } = jn;
  let { viewportGlobe: r, bounds: s, _imageCoordinateSystem: o } = a;
  if (!(function(i) {
    return Number.isFinite(i[0]);
  })(s)) throw new Error("_imageCoordinateSystem only supports rectangular bounds");
  if (o !== n) {
    const i = r ? e : t;
    if (o = o === e ? e : t, o === e && i === t) return { coordinateConversion: -1, bounds: s };
    if (o === t && i === e) {
      const l = si([s[0], s[1]]), u = si([s[2], s[3]]);
      return { coordinateConversion: 1, bounds: [l[0], l[1], u[0], u[1]] };
    }
  }
  return { coordinateConversion: 0, bounds: s };
}
const Et = { name: "bitmap2", vs: Xa, fs: Xa, uniformTypes: { [Ka]: "vec4<f32>", [Ya]: "f32", [ei]: "f32", [ti]: "vec4<f32>" }, getUniforms: function(a = {}) {
  const { bounds: e, coordinateConversion: t } = Eh(a);
  return { [Ka]: e, [Ya]: tt(e) ? 1 : 0, [ei]: t, [ti]: a.transparentColor ? Rn(a.transparentColor) : [0, 0, 0, 0] };
} }, ai = "uniform sampler2D W;uniform sampler2D X;uniform rasterUniforms{vec2 Y;float Z;float a;float b;float c;vec2 d;float e;float f;float g;float h;vec4 i;float j;float k;vec4 l;}raster;", kh = "W", Th = "X", ii = "Y", oi = "Z", li = "a", ci = "b", ui = "c", fi = "d", hi = "e", di = "f", pi = "g", mi = "h", gi = "i", Ai = "j", yi = "k", bi = "l", kt = { name: "raster", vs: ai, fs: ai, uniformTypes: { [ii]: "vec2<f32>", [oi]: "f32", [li]: "f32", [ci]: "f32", [ui]: "f32", [fi]: "vec2<f32>", [hi]: "f32", [di]: "f32", [pi]: "f32", [mi]: "f32", [gi]: "vec4<f32>", [Ai]: "f32", [yi]: "f32", [bi]: "vec4<f32>" }, getUniforms: function(a = {}) {
  return { [kh]: a.imageTexture, [Th]: a.imageTexture2, [ii]: a.imageTexture ? [a.imageTexture.width, a.imageTexture.height] : [0, 0], [oi]: a.imageSmoothing ?? 0, [li]: Object.values(Ze).indexOf(a.imageInterpolation ?? Ze.NEAREST), [ci]: a.imageTexture2 !== a.imageTexture && a.imageWeight ? a.imageWeight : 0, [ui]: Object.values(xe).indexOf(a.imageType ?? xe.SCALAR), [fi]: a.imageUnscale ?? [0, 0], [hi]: a.imageMinValue ?? Number.MIN_SAFE_INTEGER, [di]: a.imageMaxValue ?? Number.MAX_SAFE_INTEGER, [pi]: a.borderEnabled ? 1 : 0, [mi]: a.borderWidth ?? 0, [gi]: a.borderColor ? Rn(a.borderColor) : [0, 0, 0, 0], [Ai]: a.gridEnabled ? 1 : 0, [yi]: a.gridSize ?? 0, [bi]: a.gridColor ? Rn(a.gridColor) : [0, 0, 0, 0] };
} }, vi = "uniform sampler2D m;uniform paletteUniforms{vec2 n;vec4 o;}palette;float p(float min,float max,float q){return(q-min)/(max-min);}vec4 r(sampler2D m,vec2 n,vec4 o,float q){if(n[0]<n[1]){float s=p(n[0],n[1],q);return texture(m,vec2(s,0.));}else{return o;}}", Bh = "m", xi = "n", wi = "o", Tt = { name: "palette", vs: vi, fs: vi, uniformTypes: { [xi]: "vec2<f32>", [wi]: "vec4<f32>" }, getUniforms: function(a = {}) {
  return { [Bh]: a.paletteTexture, [xi]: a.paletteBounds ?? [0, 0], [wi]: a.paletteColor ? Rn(a.paletteColor) : [0, 0, 0, 0] };
} }, Rt = { imageTexture: { type: "object", value: null }, imageTexture2: { type: "object", value: null }, imageSmoothing: { type: "number", value: 0 }, imageInterpolation: { type: "object", value: Ze.CUBIC }, imageWeight: { type: "number", value: 0 }, imageType: { type: "object", value: xe.SCALAR }, imageUnscale: { type: "array", value: null }, imageMinValue: { type: "object", value: null }, imageMaxValue: { type: "object", value: null }, bounds: { type: "array", value: [-180, -90, 180, 90], compare: !0 }, minZoom: { type: "object", value: null }, maxZoom: { type: "object", value: null }, palette: { type: "object", value: null }, borderEnabled: { type: "boolean", value: !1 }, borderWidth: { type: "number", value: 1 }, borderColor: { type: "color", value: Fn }, gridEnabled: { type: "boolean", value: !1 }, gridSize: { type: "number", value: 1 }, gridColor: { type: "color", value: Fn } };
class qn extends Xi {
  getShaders() {
    const e = super.getShaders();
    return { ...e, fs: `#version 300 es
#define SHADER_NAME  raster-bitmap-layer-fragment-shader
#ifdef GL_ES
precision highp float;
#endif
vec4 AG(sampler2D AH,vec2 AI,vec2 AJ,vec2 AK){vec2 uv=(AJ+AK+0.5)/AI;return texture(AH,uv);}const vec4 AL=vec4(3.,-6.,0.,4.)/6.;const vec4 AM=vec4(-1.,6.,-12.,8.)/6.;vec4 AN(float J){return vec4(J*J*J,J*J,J,1.);}vec4 AO(vec4 AP,vec4 AQ,vec4 AR,vec4 AS,float AT){vec4 O=AP*dot(AM,AN(AT+1.))+AQ*dot(AL,AN(AT))+AR*dot(AL,AN(1.-AT))+AS*dot(AM,AN(2.-AT));O.a=(AP.a>0.&&AQ.a>0.&&AR.a>0.&&AS.a>0.)?max(max(max(AP.a,AQ.a),AR.a),AS.a):0.;return O;}vec4 AU(sampler2D AH,vec2 AI,vec2 uv){vec2 AV=uv*AI-0.5;vec2 AJ=floor(AV);vec2 AW=fract(AV);return AO(AO(AG(AH,AI,AJ,vec2(-1,-1)),AG(AH,AI,AJ,vec2(0,-1)),AG(AH,AI,AJ,vec2(1,-1)),AG(AH,AI,AJ,vec2(2,-1)),AW.x),AO(AG(AH,AI,AJ,vec2(-1,0)),AG(AH,AI,AJ,vec2(0,0)),AG(AH,AI,AJ,vec2(1,0)),AG(AH,AI,AJ,vec2(2,0)),AW.x),AO(AG(AH,AI,AJ,vec2(-1,1)),AG(AH,AI,AJ,vec2(0,1)),AG(AH,AI,AJ,vec2(1,1)),AG(AH,AI,AJ,vec2(2,1)),AW.x),AO(AG(AH,AI,AJ,vec2(-1,2)),AG(AH,AI,AJ,vec2(0,2)),AG(AH,AI,AJ,vec2(1,2)),AG(AH,AI,AJ,vec2(2,2)),AW.x),AW.y);}vec4 AX(sampler2D AH,vec2 AI,vec2 uv){vec2 AV=uv*AI-0.5;vec2 AJ=floor(AV);vec2 AW=fract(AV);return mix(mix(AG(AH,AI,AJ,vec2(0,0)),AG(AH,AI,AJ,vec2(1,0)),AW.x),mix(AG(AH,AI,AJ,vec2(0,1)),AG(AH,AI,AJ,vec2(1,1)),AW.x),AW.y);}vec4 AY(sampler2D AH,vec2 AI,vec2 uv){vec2 AV=uv*AI-0.5;vec2 AJ=floor(AV+0.5);return AG(AH,AI,AJ,vec2(0,0));}vec4 AZ(sampler2D AH,vec2 AI,float a,vec2 uv){if(a==2.){return AU(AH,AI,uv);}if(a==1.){return AX(AH,AI,uv);}else{return AY(AH,AI,uv);}}vec4 Aa(sampler2D AH,sampler2D Ab,vec2 AI,float a,float b,bool B,vec2 uv){vec2 Ac;Ac.x=B?uv.x+0.5/AI.x:mix(0.+0.5/AI.x,1.-0.5/AI.x,uv.x);Ac.y=mix(0.+0.5/AI.y,1.-0.5/AI.y,uv.y);if(b>0.){vec4 Ad=AZ(AH,AI,a,Ac);vec4 Ae=AZ(Ab,AI,a,Ac);return mix(Ad,Ae,b);}else{return AZ(AH,AI,a,Ac);}}vec4 Af(sampler2D AH,sampler2D Ab,vec2 Y,float Z,float a,float b,bool B,vec2 uv){float Ag=1.+max(0.,Z);vec2 AI=Y/Ag;return Aa(AH,Ab,AI,a,b,B,uv);}float Ah(float K,float J){return J==0.?sign(K)*F/2.:atan(K,J);}bool Ai(float q){uint Aj=floatBitsToUint(q);return(Aj&0x7fffffffu)>0x7f800000u;}bool Ak(vec4 Ad,vec2 d){if(d[0]<d[1]){return Ad.a>=1.;}else{return!Ai(Ad.x);}}float Al(vec4 Ad,float c,vec2 d){if(c==1.){return 0.;}else{if(d[0]<d[1]){return mix(d[0],d[1],Ad.x);}else{return Ad.x;}}}vec2 Am(vec4 Ad,float c,vec2 d){if(c==1.){if(d[0]<d[1]){return mix(vec2(d[0]),vec2(d[1]),Ad.xy);}else{return Ad.xy;}}else{return vec2(0.);}}float An(vec4 Ad,float c,vec2 d){if(c==1.){vec2 q=Am(Ad,c,d);return length(q);}else{return Al(Ad,c,d);}}float Ao(vec4 Ad,float c,vec2 d){if(c==1.){vec2 q=Am(Ad,c,d);return mod((360.-(Ah(q.y,q.x)/F*180.+180.))-270.,360.)/360.;}else{return 0.;}}in vec2 vTexCoord;in vec2 vTexPos;out vec4 fragColor;void main(void){vec2 uv=S(vTexCoord,vTexPos);vec4 Ad=Af(W,X,raster.Y,raster.Z,raster.a,raster.b,bitmap2.B,uv);if(!Ak(Ad,raster.d)){discard;}float q=An(Ad,raster.c,raster.d);if((!Ai(raster.e)&&q<raster.e)||(!Ai(raster.f)&&q>raster.f)){discard;}vec4 Ap=r(m,palette.n,palette.o,q);fragColor=N(Ap.rgb,Ap.a*layer.opacity);if(bool(raster.g)){vec2 Aq=vec2(length(dFdx(uv)),length(dFdy(uv)));vec2 h=raster.h/2.*Aq;if((uv.x<h.x||uv.x>1.-h.x)||(uv.y<h.y||uv.y>1.-h.y)){fragColor=N(raster.i.rgb,raster.i.a*layer.opacity*2.);}}if(bool(raster.j)){float Ag=1.+max(0.,raster.Z);vec2 AI=raster.Y/Ag;vec2 Ac;Ac.x=bitmap2.B?uv.x+0.5/AI.x:mix(0.+0.5/AI.x,1.-0.5/AI.x,uv.x);Ac.y=mix(0.+0.5/AI.y,1.-0.5/AI.y,uv.y);vec2 AV=Ac*AI-0.5;vec2 AW=fract(AV);vec2 Aq=vec2(length(dFdx(uv)),length(dFdy(uv)));vec2 k=raster.k/2.*Aq*raster.Y;if((AW.x<k.x||AW.x>1.-k.x)&&(AW.y<k.y||AW.y>1.-k.y)){fragColor=N(raster.l.rgb,raster.l.a*layer.opacity*2.);}}geometry.uv=uv;DECKGL_FILTER_COLOR(fragColor,geometry);if(bool(picking.isActive)&&!bool(picking.isAttribute)){float s=p(palette.n[0],palette.n[1],q);float Ar=Ao(Ad,raster.c,raster.d);fragColor=vec4(s,Ar,0,1);}}`, modules: [...e.modules, Et, kt, Tt] };
  }
  updateState(e) {
    const { palette: t } = e.props;
    super.updateState(e), t !== e.oldProps.palette && this._updatePalette();
  }
  draw(e) {
    const { device: t, viewport: n } = this.context, { model: r } = this.state, { imageTexture: s, imageTexture2: o, imageSmoothing: i, imageInterpolation: l, imageWeight: u, imageType: c, imageUnscale: f, imageMinValue: h, imageMaxValue: p, bounds: v, _imageCoordinateSystem: I, transparentColor: y, minZoom: T, maxZoom: L, borderEnabled: E, borderWidth: C, borderColor: Q, gridEnabled: M, gridSize: Z, gridColor: z } = he(this.props, Rt), { paletteTexture: N, paletteBounds: G } = this.state;
    if (!s) return;
    const S = We(n);
    r && Bt(n, T, L) && (r.shaderInputs.setProps({ [Et.name]: { viewportGlobe: S, bounds: v, _imageCoordinateSystem: I, transparentColor: y }, [kt.name]: { imageTexture: s ?? Ie(t), imageTexture2: o ?? Ie(t), imageSmoothing: i, imageInterpolation: l, imageWeight: u, imageType: c, imageUnscale: f, imageMinValue: h, imageMaxValue: p, borderEnabled: E, borderWidth: C, borderColor: Q, gridEnabled: M, gridSize: Z, gridColor: z }, [Tt.name]: { paletteTexture: N ?? Ie(t), paletteBounds: G } }), this.props.image = s, super.draw(e), this.props.image = null);
  }
  _updatePalette() {
    const { device: e } = this.context, { palette: t } = he(this.props, Rt);
    if (!t) return void this.setState({ paletteTexture: void 0, paletteBounds: void 0 });
    const n = $t(t), { paletteBounds: r, paletteTexture: s } = Bs(e, n);
    this.setState({ paletteTexture: s, paletteBounds: r });
  }
  _getRasterMagnitudeValue(e, t) {
    return t[0] + e[0] / 255 * (t[1] - t[0]);
  }
  _getRasterDirectionValue(e) {
    const { imageType: t } = he(this.props, Rt);
    return t === xe.VECTOR ? e[1] / 255 * 360 : NaN;
  }
  getPickingInfo(e) {
    const t = super.getPickingInfo(e), { imageType: n } = he(this.props, Rt), { paletteBounds: r } = this.state;
    if (!t.color) return t;
    let s;
    const o = this._getRasterMagnitudeValue(t.color, r ?? [0, 0]);
    return n === xe.VECTOR ? s = { value: o, direction: this._getRasterDirectionValue(t.color) } : s = { value: o }, t.raster = s, t;
  }
}
qn.layerName = "RasterBitmapLayer", qn.defaultProps = Rt;
const Sh = { ...qn.defaultProps, imageTexture: void 0, imageTexture2: void 0, image: { type: "object", value: null }, image2: { type: "object", value: null }, bounds: { type: "array", value: [-180, -90, 180, 90], compare: !0 } };
class Ii extends je {
  renderLayers() {
    const { device: e } = this.context, { props: t, imageTexture: n, imageTexture2: r } = this.state;
    return t && n ? [new qn(this.props, this.getSubLayerProps({ id: "bitmap", imageTexture: n, imageTexture2: r, _imageCoordinateSystem: jn.LNGLAT, parameters: { cullMode: "back", depthCompare: "always", ...this.props.parameters }, image: Ie(e), image2: Ie(e) }))] : [];
  }
  updateState(e) {
    const { image: t, image2: n, imageUnscale: r, bounds: s } = e.props;
    if (super.updateState(e), t && r && !(t.data instanceof Uint8Array || t.data instanceof Uint8ClampedArray)) throw new Error("imageUnscale can be applied to Uint8 data only");
    if (t !== e.oldProps.image || n !== e.oldProps.image2) {
      const { device: o } = this.context, { image: i, image2: l } = this.props, u = i ? nt(o, i, tt(s)) : null, c = l ? nt(o, l, tt(s)) : null;
      this.setState({ imageTexture: u, imageTexture2: c });
    }
    this.setState({ props: e.props });
  }
}
Ii.layerName = "RasterLayer", Ii.defaultProps = Sh;
const _i = "uniform contourUniforms{float t;float u;float v;}contour;", Ci = "t", Ei = "u", ki = "v", Ti = { name: "contour", vs: _i, fs: _i, uniformTypes: { [Ci]: "f32", [Ei]: "f32", [ki]: "f32" }, getUniforms: function(a = {}) {
  return { [Ci]: a.interval, [Ei]: a.majorInterval, [ki]: a.width };
} }, ns = { imageTexture: { type: "object", value: null }, imageTexture2: { type: "object", value: null }, imageSmoothing: { type: "number", value: 0 }, imageInterpolation: { type: "object", value: Ze.CUBIC }, imageWeight: { type: "number", value: 0 }, imageType: { type: "object", value: xe.SCALAR }, imageUnscale: { type: "object", value: null }, imageMinValue: { type: "object", value: null }, imageMaxValue: { type: "object", value: null }, bounds: { type: "array", value: [-180, -90, 180, 90], compare: !0 }, minZoom: { type: "object", value: null }, maxZoom: { type: "object", value: 10 }, palette: { type: "object", value: null }, color: { type: "color", value: Fn }, interval: { type: "number", value: 0 }, majorInterval: { type: "number", value: 0 }, width: { type: "number", value: 1 } };
class Gn extends Xi {
  getShaders() {
    const e = super.getShaders();
    return { ...e, fs: `#version 300 es
#define SHADER_NAME  contour-bitmap-layer-fragment-shader
#ifdef GL_ES
precision highp float;
#endif
vec4 AG(sampler2D AH,vec2 AI,vec2 AJ,vec2 AK){vec2 uv=(AJ+AK+0.5)/AI;return texture(AH,uv);}const vec4 AL=vec4(3.,-6.,0.,4.)/6.;const vec4 AM=vec4(-1.,6.,-12.,8.)/6.;vec4 AN(float J){return vec4(J*J*J,J*J,J,1.);}vec4 AO(vec4 AP,vec4 AQ,vec4 AR,vec4 AS,float AT){vec4 O=AP*dot(AM,AN(AT+1.))+AQ*dot(AL,AN(AT))+AR*dot(AL,AN(1.-AT))+AS*dot(AM,AN(2.-AT));O.a=(AP.a>0.&&AQ.a>0.&&AR.a>0.&&AS.a>0.)?max(max(max(AP.a,AQ.a),AR.a),AS.a):0.;return O;}vec4 AU(sampler2D AH,vec2 AI,vec2 uv){vec2 AV=uv*AI-0.5;vec2 AJ=floor(AV);vec2 AW=fract(AV);return AO(AO(AG(AH,AI,AJ,vec2(-1,-1)),AG(AH,AI,AJ,vec2(0,-1)),AG(AH,AI,AJ,vec2(1,-1)),AG(AH,AI,AJ,vec2(2,-1)),AW.x),AO(AG(AH,AI,AJ,vec2(-1,0)),AG(AH,AI,AJ,vec2(0,0)),AG(AH,AI,AJ,vec2(1,0)),AG(AH,AI,AJ,vec2(2,0)),AW.x),AO(AG(AH,AI,AJ,vec2(-1,1)),AG(AH,AI,AJ,vec2(0,1)),AG(AH,AI,AJ,vec2(1,1)),AG(AH,AI,AJ,vec2(2,1)),AW.x),AO(AG(AH,AI,AJ,vec2(-1,2)),AG(AH,AI,AJ,vec2(0,2)),AG(AH,AI,AJ,vec2(1,2)),AG(AH,AI,AJ,vec2(2,2)),AW.x),AW.y);}vec4 AX(sampler2D AH,vec2 AI,vec2 uv){vec2 AV=uv*AI-0.5;vec2 AJ=floor(AV);vec2 AW=fract(AV);return mix(mix(AG(AH,AI,AJ,vec2(0,0)),AG(AH,AI,AJ,vec2(1,0)),AW.x),mix(AG(AH,AI,AJ,vec2(0,1)),AG(AH,AI,AJ,vec2(1,1)),AW.x),AW.y);}vec4 AY(sampler2D AH,vec2 AI,vec2 uv){vec2 AV=uv*AI-0.5;vec2 AJ=floor(AV+0.5);return AG(AH,AI,AJ,vec2(0,0));}vec4 AZ(sampler2D AH,vec2 AI,float a,vec2 uv){if(a==2.){return AU(AH,AI,uv);}if(a==1.){return AX(AH,AI,uv);}else{return AY(AH,AI,uv);}}vec4 Aa(sampler2D AH,sampler2D Ab,vec2 AI,float a,float b,bool B,vec2 uv){vec2 Ac;Ac.x=B?uv.x+0.5/AI.x:mix(0.+0.5/AI.x,1.-0.5/AI.x,uv.x);Ac.y=mix(0.+0.5/AI.y,1.-0.5/AI.y,uv.y);if(b>0.){vec4 Ad=AZ(AH,AI,a,Ac);vec4 Ae=AZ(Ab,AI,a,Ac);return mix(Ad,Ae,b);}else{return AZ(AH,AI,a,Ac);}}vec4 Af(sampler2D AH,sampler2D Ab,vec2 Y,float Z,float a,float b,bool B,vec2 uv){float Ag=1.+max(0.,Z);vec2 AI=Y/Ag;return Aa(AH,Ab,AI,a,b,B,uv);}float Ah(float K,float J){return J==0.?sign(K)*F/2.:atan(K,J);}bool Ai(float q){uint Aj=floatBitsToUint(q);return(Aj&0x7fffffffu)>0x7f800000u;}bool Ak(vec4 Ad,vec2 d){if(d[0]<d[1]){return Ad.a>=1.;}else{return!Ai(Ad.x);}}float Al(vec4 Ad,float c,vec2 d){if(c==1.){return 0.;}else{if(d[0]<d[1]){return mix(d[0],d[1],Ad.x);}else{return Ad.x;}}}vec2 Am(vec4 Ad,float c,vec2 d){if(c==1.){if(d[0]<d[1]){return mix(vec2(d[0]),vec2(d[1]),Ad.xy);}else{return Ad.xy;}}else{return vec2(0.);}}float An(vec4 Ad,float c,vec2 d){if(c==1.){vec2 q=Am(Ad,c,d);return length(q);}else{return Al(Ad,c,d);}}float Ao(vec4 Ad,float c,vec2 d){if(c==1.){vec2 q=Am(Ad,c,d);return mod((360.-(Ah(q.y,q.x)/F*180.+180.))-270.,360.)/360.;}else{return 0.;}}in vec2 vTexCoord;in vec2 vTexPos;out vec4 fragColor;void main(void){vec2 uv=S(vTexCoord,vTexPos);vec4 Ad=Af(W,X,raster.Y,raster.Z,raster.a,raster.b,bitmap2.B,uv);if(!Ak(Ad,raster.d)){discard;}float q=An(Ad,raster.c,raster.d);if((!Ai(raster.e)&&q<raster.e)||(!Ai(raster.f)&&q>raster.f)){discard;}float Ap=contour.u>contour.t?floor(contour.u/contour.t):1.;float Aq=q/contour.t;float Ar=(step(fract(Aq/Ap),0.1)+1.)/2.;float As=contour.v*Ar;float At=abs(fract(Aq+0.5)-0.5);float Au=length(vec2(dFdx(Aq),dFdy(Aq)));float Av=1.-clamp((At/Au)+0.5-As,0.,1.);if(Au==0.){Av=0.;}float Aw=Av*Ar;vec4 Ax=r(m,palette.n,palette.o,q);fragColor=vec4(Ax.rgb,Ax.a*Aw*layer.opacity);geometry.uv=uv;DECKGL_FILTER_COLOR(fragColor,geometry);}`, modules: [...e.modules, Et, kt, Tt, Ti] };
  }
  updateState(e) {
    const { palette: t } = e.props;
    super.updateState(e), t !== e.oldProps.palette && this._updatePalette();
  }
  draw(e) {
    const { device: t, viewport: n } = this.context, { model: r } = this.state, { imageTexture: s, imageTexture2: o, imageSmoothing: i, imageInterpolation: l, imageWeight: u, imageType: c, imageUnscale: f, imageMinValue: h, imageMaxValue: p, bounds: v, _imageCoordinateSystem: I, transparentColor: y, minZoom: T, maxZoom: L, color: E, interval: C, majorInterval: Q, width: M } = he(this.props, ns), { paletteTexture: Z, paletteBounds: z } = this.state;
    if (!s) return;
    const N = We(n);
    r && Bt(n, T, L) && (r.shaderInputs.setProps({ [Et.name]: { viewportGlobe: N, bounds: v, _imageCoordinateSystem: I, transparentColor: y }, [kt.name]: { imageTexture: s ?? Ie(t), imageTexture2: o ?? Ie(t), imageSmoothing: i, imageInterpolation: l, imageWeight: u, imageType: c, imageUnscale: f, imageMinValue: h, imageMaxValue: p }, [Tt.name]: { paletteTexture: Z ?? Ie(t), paletteBounds: z, paletteColor: E }, [Ti.name]: { interval: C, majorInterval: Q, width: M } }), this.props.image = s, super.draw(e), this.props.image = null);
  }
  _updatePalette() {
    const { device: e } = this.context, { palette: t } = he(this.props, ns);
    if (!t) return void this.setState({ paletteTexture: void 0, paletteBounds: void 0 });
    const n = $t(t), { paletteBounds: r, paletteTexture: s } = Bs(e, n);
    this.setState({ paletteTexture: s, paletteBounds: r });
  }
}
Gn.layerName = "ContourBitmapLayer", Gn.defaultProps = ns;
const Lh = { ...Gn.defaultProps, imageTexture: void 0, imageTexture2: void 0, image: { type: "object", value: null }, image2: { type: "object", value: null } };
class Bi extends je {
  renderLayers() {
    const { device: e } = this.context, { props: t, imageTexture: n, imageTexture2: r } = this.state;
    return t && n ? [new Gn(this.props, this.getSubLayerProps({ id: "bitmap", imageTexture: n, imageTexture2: r, _imageCoordinateSystem: jn.LNGLAT, parameters: { cullMode: "back", depthCompare: "always", ...this.props.parameters }, image: Ie(e), image2: Ie(e) }))] : [];
  }
  updateState(e) {
    const { image: t, image2: n, imageUnscale: r, bounds: s } = e.props;
    if (super.updateState(e), t && r && !(t.data instanceof Uint8Array || t.data instanceof Uint8ClampedArray)) throw new Error("imageUnscale can be applied to Uint8 data only");
    if (t !== e.oldProps.image || n !== e.oldProps.image2) {
      const { device: o } = this.context, { image: i, image2: l } = this.props, u = i ? nt(o, i, tt(s)) : null, c = l ? nt(o, l, tt(s)) : null;
      this.setState({ imageTexture: u, imageTexture2: c });
    }
    this.setState({ props: e.props });
  }
}
Bi.layerName = "ContourLayer", Bi.defaultProps = Lh;
const Mh = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
function Qh(a = 20) {
  return new Array(a).fill(void 0).map((() => Mh.charAt(Math.floor(62 * Math.random())))).join("");
}
const Dh = kc((Si = function() {
  const a = Symbol("Comlink.proxy"), e = Symbol("Comlink.endpoint"), t = Symbol("Comlink.releaseProxy"), n = Symbol("Comlink.finalizer"), r = Symbol("Comlink.thrown"), s = (_) => typeof _ == "object" && _ !== null || typeof _ == "function", o = { canHandle: (_) => s(_) && _[a], serialize(_) {
    const { port1: D, port2: F } = new MessageChannel();
    return l(_, D), [F, [F]];
  }, deserialize: (_) => (_.start(), (function(D, F) {
    const O = /* @__PURE__ */ new Map();
    return D.addEventListener("message", (function(U) {
      const { data: R } = U;
      if (!R || !R.id) return;
      const W = O.get(R.id);
      if (W) try {
        W(R);
      } finally {
        O.delete(R.id);
      }
    })), v(D, O, [], F);
  })(_)) }, i = /* @__PURE__ */ new Map([["proxy", o], ["throw", { canHandle: (_) => s(_) && r in _, serialize({ value: _ }) {
    let D;
    return D = _ instanceof Error ? { isError: !0, value: { message: _.message, name: _.name, stack: _.stack } } : { isError: !1, value: _ }, [D, []];
  }, deserialize(_) {
    throw _.isError ? Object.assign(new Error(_.value.message), _.value) : _.value;
  } }]]);
  function l(_, D = globalThis, F = ["*"]) {
    D.addEventListener("message", (function O(U) {
      if (!U || !U.data) return;
      if (!(function(ee, J) {
        for (const B of ee)
          if (J === B || B === "*" || B instanceof RegExp && B.test(J)) return !0;
        return !1;
      })(F, U.origin)) return void console.warn(`Invalid origin '${U.origin}' for comlink proxy`);
      const { id: R, type: W, path: re } = Object.assign({ path: [] }, U.data), K = (U.data.argumentList || []).map(E);
      let $;
      try {
        const ee = re.slice(0, -1).reduce(((B, V) => B[V]), _), J = re.reduce(((B, V) => B[V]), _);
        switch (W) {
          case "GET":
            $ = J;
            break;
          case "SET":
            ee[re.slice(-1)[0]] = E(U.data.value), $ = !0;
            break;
          case "APPLY":
            $ = J.apply(ee, K);
            break;
          case "CONSTRUCT":
            $ = (function(B) {
              return Object.assign(B, { [a]: !0 });
            })(new J(...K));
            break;
          case "ENDPOINT":
            {
              const { port1: B, port2: V } = new MessageChannel();
              l(_, V), $ = T(B, [B]);
            }
            break;
          case "RELEASE":
            $ = void 0;
            break;
          default:
            return;
        }
      } catch (ee) {
        $ = { value: ee, [r]: 0 };
      }
      Promise.resolve($).catch(((ee) => ({ value: ee, [r]: 0 }))).then(((ee) => {
        const [J, B] = L(ee);
        D.postMessage(Object.assign(Object.assign({}, J), { id: R }), B), W === "RELEASE" && (D.removeEventListener("message", O), u(D), n in _ && typeof _[n] == "function" && _[n]());
      })).catch(((ee) => {
        const [J, B] = L({ value: new TypeError("Unserializable return value"), [r]: 0 });
        D.postMessage(Object.assign(Object.assign({}, J), { id: R }), B);
      }));
    })), D.start && D.start();
  }
  function u(_) {
    (function(D) {
      return D.constructor.name === "MessagePort";
    })(_) && _.close();
  }
  function c(_) {
    if (_) throw new Error("Proxy has been released and is not useable");
  }
  function f(_) {
    return C(_, /* @__PURE__ */ new Map(), { type: "RELEASE" }).then((() => {
      u(_);
    }));
  }
  const h = /* @__PURE__ */ new WeakMap(), p = "FinalizationRegistry" in globalThis && new FinalizationRegistry(((_) => {
    const D = (h.get(_) || 0) - 1;
    h.set(_, D), D === 0 && f(_);
  }));
  function v(_, D, F = [], O = function() {
  }) {
    let U = !1;
    const R = new Proxy(O, { get(W, re) {
      if (c(U), re === t) return () => {
        (function(K) {
          p && p.unregister(K);
        })(R), f(_), D.clear(), U = !0;
      };
      if (re === "then") {
        if (F.length === 0) return { then: () => R };
        const K = C(_, D, { type: "GET", path: F.map((($) => $.toString())) }).then(E);
        return K.then.bind(K);
      }
      return v(_, D, [...F, re]);
    }, set(W, re, K) {
      c(U);
      const [$, ee] = L(K);
      return C(_, D, { type: "SET", path: [...F, re].map(((J) => J.toString())), value: $ }, ee).then(E);
    }, apply(W, re, K) {
      c(U);
      const $ = F[F.length - 1];
      if ($ === e) return C(_, D, { type: "ENDPOINT" }).then(E);
      if ($ === "bind") return v(_, D, F.slice(0, -1));
      const [ee, J] = I(K);
      return C(_, D, { type: "APPLY", path: F.map(((B) => B.toString())), argumentList: ee }, J).then(E);
    }, construct(W, re) {
      c(U);
      const [K, $] = I(re);
      return C(_, D, { type: "CONSTRUCT", path: F.map(((ee) => ee.toString())), argumentList: K }, $).then(E);
    } });
    return (function(W, re) {
      const K = (h.get(re) || 0) + 1;
      h.set(re, K), p && p.register(W, re, W);
    })(R, _), R;
  }
  function I(_) {
    const D = _.map(L);
    return [D.map(((O) => O[0])), (F = D.map(((O) => O[1])), Array.prototype.concat.apply([], F))];
    var F;
  }
  const y = /* @__PURE__ */ new WeakMap();
  function T(_, D) {
    return y.set(_, D), _;
  }
  function L(_) {
    for (const [D, F] of i) if (F.canHandle(_)) {
      const [O, U] = F.serialize(_);
      return [{ type: "HANDLER", name: D, value: O }, U];
    }
    return [{ type: "RAW", value: _ }, y.get(_) || []];
  }
  function E(_) {
    switch (_.type) {
      case "HANDLER":
        return i.get(_.name).deserialize(_.value);
      case "RAW":
        return _.value;
    }
  }
  function C(_, D, F, O) {
    return new Promise(((U) => {
      const R = new Array(4).fill(0).map((() => Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16))).join("-");
      D.set(R, U), _.start && _.start(), _.postMessage(Object.assign({ id: R }, F), O);
    }));
  }
  const Q = 6371e3;
  function M(_) {
    return _ / 180 * Math.PI;
  }
  const Z = 6370972;
  function z(_, D) {
    return (function(F, O, U = Q) {
      const R = U, W = M(F[1]), re = M(F[0]), K = M(O[1]), $ = K - W, ee = M(O[0]) - re, J = Math.sin($ / 2) * Math.sin($ / 2) + Math.cos(W) * Math.cos(K) * Math.sin(ee / 2) * Math.sin(ee / 2);
      return R * (2 * Math.atan2(Math.sqrt(J), Math.sqrt(1 - J)));
    })(_, D, Z);
  }
  const N = { NEAREST: "NEAREST", LINEAR: "LINEAR", CUBIC: "CUBIC" }, G = { VECTOR: "VECTOR" };
  function S(_) {
    return _ % 1;
  }
  function q(_, D) {
    return _.map(((F, O) => _[O] + D[O]));
  }
  function Y(_, D) {
    return _.map(((F, O) => _[O] * D));
  }
  function j(_, D) {
    return _.map(((F, O) => _[O] * D[O])).reduce(((F, O) => F + O));
  }
  function se(_, D, F) {
    return _ === D ? _ : _ * (1 - F) + D * F;
  }
  function ne(_, D, F) {
    return _.map(((O, U) => se(_[U], D[U], F)));
  }
  function ye(_, D) {
    return D ? _[3] >= 255 : !isNaN(_[0]);
  }
  function Ge(_, D, F) {
    if (D === G.VECTOR) {
      const O = (function(U, R, W) {
        return R === G.VECTOR ? W ? [se(W[0], W[1], U[0] / 255), se(W[0], W[1], U[1] / 255)] : [U[0], U[1]] : [NaN, NaN];
      })(_, D, F);
      return Math.hypot(O[0], O[1]);
    }
    return (function(O, U, R) {
      return U === G.VECTOR ? 0 : R ? se(R[0], R[1], O[0] / 255) : O[0];
    })(_, D, F);
  }
  function le(_, D, F, O, U, R) {
    const { data: W, width: re, height: K } = _, $ = W.length / (re * K), ee = (F + U + 0.5) / D[0], J = (O + R + 0.5) / D[1], B = Math.max(0, Math.min(re - 1, Math.floor(ee * re))), V = Math.max(0, Math.min(K - 1, Math.floor(J * K)));
    return new Array($).fill(void 0).map(((X, ue) => W[(B + V * re) * $ + ue]));
  }
  const Oe = [3, -6, 0, 4].map(((_) => _ / 6)), ht = [-1, 6, -12, 8].map(((_) => _ / 6));
  function Kt(_) {
    return [_ * _ * _, _ * _, _, 1];
  }
  function St(_, D, F, O, U) {
    const R = q(q(q(Y(_, j(ht, Kt(U + 1))), Y(D, j(Oe, Kt(U)))), Y(F, j(Oe, Kt(1 - U)))), Y(O, j(ht, Kt(2 - U))));
    return R[3] = _[3] > 0 && D[3] > 0 && F[3] > 0 && O[3] > 0 ? Math.max(Math.max(Math.max(_[3], D[3]), F[3]), O[3]) : 0, R;
  }
  function Kn(_, D, F, O, U) {
    return F === N.CUBIC ? (function(R, W, re, K) {
      const $ = re * W[0] - 0.5, ee = K * W[1] - 0.5, J = Math.floor($), B = Math.floor(ee), V = S($), X = S(ee);
      return St(St(le(R, W, J, B, -1, -1), le(R, W, J, B, 0, -1), le(R, W, J, B, 1, -1), le(R, W, J, B, 2, -1), V), St(le(R, W, J, B, -1, 0), le(R, W, J, B, 0, 0), le(R, W, J, B, 1, 0), le(R, W, J, B, 2, 0), V), St(le(R, W, J, B, -1, 1), le(R, W, J, B, 0, 1), le(R, W, J, B, 1, 1), le(R, W, J, B, 2, 1), V), St(le(R, W, J, B, -1, 2), le(R, W, J, B, 0, 2), le(R, W, J, B, 1, 2), le(R, W, J, B, 2, 2), V), X);
    })(_, D, O, U) : F === N.LINEAR ? (function(R, W, re, K) {
      const $ = re * W[0] - 0.5, ee = K * W[1] - 0.5, J = Math.floor($), B = Math.floor(ee), V = S($), X = S(ee);
      return ne(ne(le(R, W, J, B, 0, 0), le(R, W, J, B, 1, 0), V), ne(le(R, W, J, B, 0, 1), le(R, W, J, B, 1, 1), V), X);
    })(_, D, O, U) : (function(R, W, re, K) {
      const $ = re * W[0] - 0.5, ee = K * W[1] - 0.5;
      return le(R, W, Math.round($), Math.round(ee), 0, 0);
    })(_, D, O, U);
  }
  function ml(_, D, F, O, U, R, W, re) {
    const K = R ? W + 0.5 / F[0] : se(0 + 0.5 / F[0], 1 - 0.5 / F[0], W), $ = se(0 + 0.5 / F[1], 1 - 0.5 / F[1], re);
    return D && U > 0 ? ne(Kn(_, F, O, K, $), Kn(D, F, O, K, $), U) : Kn(_, F, O, K, $);
  }
  function gl(_, D) {
    const { image: F, image2: O, imageSmoothing: U, imageInterpolation: R, imageWeight: W, imageType: re, imageUnscale: K, imageMinValue: $, imageMaxValue: ee } = _, { width: J, height: B } = F, V = R !== N.NEAREST ? N.NEAREST : R, X = (function(oe, _e, Ne) {
      const Je = 1 + Math.max(0, Ne);
      return [oe / Je, _e / Je];
    })(J, B, U), ue = (function(oe) {
      return oe[2] - oe[0] == 360;
    })(D), fe = new Float32Array(J * B);
    for (let oe = 0; oe < B; oe++) for (let _e = 0; _e < J; _e++) {
      const Ne = _e + oe * J, Je = ml(F, O, X, V, W, ue, _e / J, oe / B);
      if (!ye(Je, K)) {
        fe[Ne] = NaN;
        continue;
      }
      const Lt = Ge(Je, re, K);
      typeof $ == "number" && !isNaN($) && Lt < $ || typeof ee == "number" && !isNaN(ee) && Lt > ee ? fe[Ne] = NaN : fe[Ne] = Lt;
    }
    return { data: fe, width: J, height: B };
  }
  function Al(_, D, F) {
    let { data: O, width: U, height: R } = _;
    const W = 1e3 * F, re = (function(B, V, X) {
      const ue = [X[0], X[3]], fe = (X[2] - X[0]) / B, oe = (X[3] - X[1]) / V;
      return (_e) => {
        const [Ne, Je] = _e;
        return [ue[0] + Ne * fe, ue[1] - Je * oe];
      };
    })(U, R, D);
    O = (function(B, V, X) {
      const ue = new Float32Array(B.length);
      for (let fe = 0; fe < X; fe++) for (let oe = 0; oe < V; oe++) {
        const _e = oe + fe * V;
        if (oe >= 1 && oe <= V - 2 && fe >= 1 && fe <= X - 2) {
          const Ne = [B[oe - 1 + (fe - 1) * V], B[oe + (fe - 1) * V], B[oe + 1 + (fe - 1) * V], B[oe - 1 + fe * V], B[oe + fe * V], B[oe + 1 + fe * V], B[oe - 1 + (fe + 1) * V], B[oe + (fe + 1) * V], B[oe + 1 + (fe - 1) * V]];
          ue[_e] = Ne.reduce(((Je, Lt) => Je + Lt), 0) / Ne.length;
        } else ue[_e] = B[_e];
      }
      return ue;
    })(O, U, R);
    let K = [], $ = [];
    for (let B = 1; B < R - 1; B++) for (let V = 1; V < U - 1; V++) {
      const X = O[V + B * U];
      if (!isNaN(X) && X >= O[V + 1 + B * U] && X >= O[V + 1 + (B + 1) * U] && X >= O[V + (B + 1) * U] && X >= O[V - 1 + (B + 1) * U] && X > O[V - 1 + B * U] && X > O[V - 1 + (B - 1) * U] && X > O[V + (B - 1) * U] && X > O[V + 1 + (B - 1) * U]) {
        const ue = re([V, B]);
        K.push({ position: ue, value: X });
      }
      if (!isNaN(X) && X <= O[V + 1 + B * U] && X <= O[V + 1 + (B + 1) * U] && X <= O[V + (B + 1) * U] && X <= O[V - 1 + (B + 1) * U] && X < O[V - 1 + B * U] && X < O[V - 1 + (B - 1) * U] && X < O[V + (B - 1) * U] && X < O[V + 1 + (B - 1) * U]) {
        const ue = re([V, B]);
        $.push({ position: ue, value: X });
      }
    }
    K = K.sort(((B, V) => V.value - B.value)), $ = $.sort(((B, V) => B.value - V.value));
    const ee = [...K];
    for (let B = 0; B < ee.length; B++) {
      const V = ee[B];
      if (V) for (let X = B + 1; X < ee.length; X++) {
        const ue = ee[X];
        ue && z(V.position, ue.position) < W && (ee[X] = void 0);
      }
    }
    K = ee.filter(((B) => !!B));
    const J = [...$];
    for (let B = 0; B < J.length; B++) {
      const V = J[B];
      if (V) for (let X = B + 1; X < J.length; X++) {
        const ue = J[X];
        ue && z(V.position, ue.position) < W && (J[X] = void 0);
      }
    }
    return $ = J.filter(((B) => !!B)), new Float32Array([K.length, ...K.map(((B) => [...B.position, B.value])).flat(), $.length, ...$.map(((B) => [...B.position, B.value])).flat()]);
  }
  l({ getHighLowPointData(_, D, F, O, U, R, W, re, K, $, ee, J, B, V, X) {
    const ue = (function(fe, oe, _e) {
      return Al(gl(fe, oe), oe, _e);
    })({ image: { data: _, width: D, height: F }, image2: O ? { data: O, width: U, height: R } : null, imageSmoothing: W, imageInterpolation: re, imageWeight: K, imageType: $, imageUnscale: ee, imageMinValue: J, imageMaxValue: B }, V, X);
    return T(ue, [ue.buffer]);
  } });
}, Si.toString().replace(/^function.+?{/, "").slice(0, -1)));
var Si, Ph = Ec(Dh);
const rs = { LOW: "L", HIGH: "H" }, Oh = go(Ph());
function Li(a, e) {
  return { type: "Feature", geometry: { type: "Point", coordinates: a }, properties: e };
}
async function Nh(a, e, t) {
  const { image: n, image2: r, imageSmoothing: s, imageInterpolation: o, imageWeight: i, imageType: l, imageUnscale: u, imageMinValue: c, imageMaxValue: f } = a, { data: h, width: p, height: v } = n, { data: I = null, width: y = null, height: T = null } = r || {}, L = h.slice(0), E = I ? I.slice(0) : null;
  return { type: "FeatureCollection", features: (function(Q) {
    let M = 0;
    const Z = [], z = Q[M++];
    for (let G = 0; G < z; G++) {
      const S = [Q[M++], Q[M++]], q = Q[M++];
      Z.push(Li(S, { type: rs.HIGH, value: q }));
    }
    const N = Q[M++];
    for (let G = 0; G < N; G++) {
      const S = [Q[M++], Q[M++]], q = Q[M++];
      Z.push(Li(S, { type: rs.LOW, value: q }));
    }
    return Z;
  })(await Oh.getHighLowPointData(Zr(L, [L.buffer]), p, v, E ? Zr(E, [E.buffer]) : null, y, T, s, o, i, l, u, c, f, e, t)) };
}
const Mi = "high-low-label";
function Qi(a, e, t) {
  return a.properties.type === rs.HIGH ? Math.round((a.properties.value - t) / t * 100) : Math.round((e - a.properties.value) / e * 100);
}
const Wt = { image: { type: "object", value: null }, image2: { type: "object", value: null }, imageSmoothing: { type: "number", value: 0 }, imageInterpolation: { type: "object", value: Ze.CUBIC }, imageWeight: { type: "number", value: 0 }, imageType: { type: "object", value: xe.SCALAR }, imageUnscale: { type: "array", value: null }, imageMinValue: { type: "object", value: null }, imageMaxValue: { type: "object", value: null }, bounds: { type: "array", value: [-180, -90, 180, 90], compare: !0 }, minZoom: { type: "object", value: null }, maxZoom: { type: "object", value: null }, radius: { type: "number", value: 0 }, unitFormat: { type: "object", value: null }, textFormatFunction: { type: "function", value: ll }, textFontFamily: { type: "object", value: Cs }, textSize: { type: "number", value: 12 }, textColor: { type: "color", value: Es }, textOutlineWidth: { type: "number", value: 1 }, textOutlineColor: { type: "color", value: ks }, palette: { type: "object", value: null } };
class Jn extends je {
  renderLayers() {
    const { viewport: e } = this.context, { props: t, visiblePoints: n, minValue: r, maxValue: s } = this.state;
    if (!t || !n || typeof r != "number" || typeof s != "number") return [];
    const { unitFormat: o, textFormatFunction: i, textFontFamily: l, textSize: u, textColor: c, textOutlineWidth: f, textOutlineColor: h } = he(t, Wt), { paletteScale: p } = this.state;
    return [new In(this.getSubLayerProps({ id: "type", data: n, getPixelOffset: [0, -$a(e, 1.2 * u / 2)], getPosition: (v) => v.geometry.coordinates, getText: (v) => v.properties.type, getSize: 1.2 * u, getColor: (v) => p ? Wn(p(v.properties.value).rgba()) : c, getAngle: Ye(e, 0), outlineWidth: f, outlineColor: h, fontFamily: l, fontSettings: { sdf: !0 }, billboard: !1, extensions: [new Jr()], collisionEnabled: !0, collisionGroup: Mi, collisionTestProps: { sizeScale: 5 }, getCollisionPriority: (v) => Qi(v, r, s), parameters: { cullMode: "front", depthCompare: "always", ...this.props.parameters } })), new In(this.getSubLayerProps({ id: "value", data: n, getPixelOffset: [0, $a(e, 1.2 * u / 2)], getPosition: (v) => v.geometry.coordinates, getText: (v) => i(v.properties.value, o), getSize: u, getColor: (v) => p ? Wn(p(v.properties.value).rgba()) : c, getAngle: Ye(e, 0), outlineWidth: f, outlineColor: h, fontFamily: l, fontSettings: { sdf: !0 }, billboard: !1, extensions: [new Jr()], collisionEnabled: !0, collisionGroup: Mi, collisionTestProps: { sizeScale: 5 }, getCollisionPriority: (v) => Qi(v, r, s), parameters: { cullMode: "front", depthCompare: "always", ...this.props.parameters } }))];
  }
  shouldUpdateState(e) {
    return super.shouldUpdateState(e) || e.changeFlags.viewportChanged;
  }
  updateState(e) {
    const { image: t, image2: n, imageSmoothing: r, imageInterpolation: s, imageWeight: o, imageType: i, imageUnscale: l, imageMinValue: u, imageMaxValue: c, minZoom: f, maxZoom: h, radius: p, unitFormat: v, textFormatFunction: I, textFontFamily: y, textSize: T, textColor: L, textOutlineWidth: E, textOutlineColor: C, palette: Q, visible: M } = e.props;
    super.updateState(e), p && M ? (t === e.oldProps.image && n === e.oldProps.image2 && r === e.oldProps.imageSmoothing && s === e.oldProps.imageInterpolation && o === e.oldProps.imageWeight && i === e.oldProps.imageType && l === e.oldProps.imageUnscale && u === e.oldProps.imageMinValue && c === e.oldProps.imageMaxValue && p === e.oldProps.radius && M === e.oldProps.visible || this._updateFeatures(), (f !== e.oldProps.minZoom || h !== e.oldProps.maxZoom || e.changeFlags.viewportChanged) && this._updateVisibleFeatures(), Q !== e.oldProps.palette && this._updatePalette(), v === e.oldProps.unitFormat && I === e.oldProps.textFormatFunction && y === e.oldProps.textFontFamily && T === e.oldProps.textSize && L === e.oldProps.textColor && E === e.oldProps.textOutlineWidth && C === e.oldProps.textOutlineColor || this._redrawVisibleFeatures(), this.setState({ props: e.props })) : this.setState({ points: void 0, visiblePoints: void 0, minValue: void 0, maxValue: void 0 });
  }
  async _updateFeatures() {
    const { image: e, image2: t, imageSmoothing: n, imageInterpolation: r, imageType: s, imageUnscale: o, imageMinValue: i, imageMaxValue: l, imageWeight: u, bounds: c, radius: f } = he(this.props, Wt);
    if (!e) return;
    const h = Qh();
    this.state.requestId = h;
    const p = { image: e, image2: t, imageSmoothing: n, imageInterpolation: r, imageWeight: u, imageType: s, imageUnscale: o, imageMinValue: i, imageMaxValue: l }, v = (await Nh(p, c, f)).features;
    if (this.state.requestId !== h) return;
    const I = v.map(((L) => L.properties.value)), y = Math.min(...I), T = Math.max(...I);
    this.setState({ points: v, minValue: y, maxValue: T }), this._updateVisibleFeatures();
  }
  _updateVisibleFeatures() {
    const { viewport: e } = this.context, { minZoom: t, maxZoom: n } = he(this.props, Wt), { points: r } = this.state;
    if (!r) return;
    let s;
    s = Bt(e, t, n) ? r : [], this.setState({ visiblePoints: s });
  }
  _updatePalette() {
    const { palette: e } = he(this.props, Wt);
    if (!e) return this.setState({ paletteScale: void 0 }), void this._redrawVisibleFeatures();
    const t = $t(e);
    this.setState({ paletteScale: t }), this._redrawVisibleFeatures();
  }
  _redrawVisibleFeatures() {
    this.setState({ visiblePoints: Array.isArray(this.state.visiblePoints) ? Array.from(this.state.visiblePoints) : this.state.visiblePoints });
  }
}
Jn.layerName = "HighLowCompositeLayer", Jn.defaultProps = Wt;
const Uh = { ...Jn.defaultProps };
class Di extends je {
  renderLayers() {
    const { props: e } = this.state;
    return e ? [new Jn(this.props, this.getSubLayerProps({ id: "composite" }))] : [];
  }
  updateState(e) {
    const { image: t, imageUnscale: n } = e.props;
    if (super.updateState(e), t && n && !(t.data instanceof Uint8Array || t.data instanceof Uint8ClampedArray)) throw new Error("imageUnscale can be applied to Uint8 data only");
    this.setState({ props: e.props });
  }
}
Di.layerName = "HighLowLayer", Di.defaultProps = Uh;
const Ee = { COLD: "COLD", WARM: "WARM", OCCLUDED: "OCCLUDED", STATIONARY: "STATIONARY" }, Pi = { iconAtlas: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGoAAAAqCAYAAABbec77AAAFsmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS41LjAiPgogPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIgogICAgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIgogICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIgogICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iCiAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIKICAgIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIgogICAgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIKICAgeG1wOkNyZWF0ZURhdGU9IjIwMjMtMDMtMTBUMTQ6NDI6NTYrMDEwMCIKICAgeG1wOk1vZGlmeURhdGU9IjIwMjMtMDMtMjVUMDk6MDY6NTgrMDE6MDAiCiAgIHhtcDpNZXRhZGF0YURhdGU9IjIwMjMtMDMtMjVUMDk6MDY6NTgrMDE6MDAiCiAgIHBob3Rvc2hvcDpEYXRlQ3JlYXRlZD0iMjAyMy0wMy0xMFQxNDo0Mjo1NiswMTAwIgogICBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIgogICBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiCiAgIGV4aWY6UGl4ZWxYRGltZW5zaW9uPSIxMDYiCiAgIGV4aWY6UGl4ZWxZRGltZW5zaW9uPSI0MiIKICAgZXhpZjpDb2xvclNwYWNlPSIxIgogICB0aWZmOkltYWdlV2lkdGg9IjEwNiIKICAgdGlmZjpJbWFnZUxlbmd0aD0iNDIiCiAgIHRpZmY6UmVzb2x1dGlvblVuaXQ9IjIiCiAgIHRpZmY6WFJlc29sdXRpb249IjcyLzEiCiAgIHRpZmY6WVJlc29sdXRpb249IjcyLzEiPgogICA8ZGM6dGl0bGU+CiAgICA8cmRmOkFsdD4KICAgICA8cmRmOmxpIHhtbDpsYW5nPSJ4LWRlZmF1bHQiPmZyb250PC9yZGY6bGk+CiAgICA8L3JkZjpBbHQ+CiAgIDwvZGM6dGl0bGU+CiAgIDx4bXBNTTpIaXN0b3J5PgogICAgPHJkZjpTZXE+CiAgICAgPHJkZjpsaQogICAgICBzdEV2dDphY3Rpb249InByb2R1Y2VkIgogICAgICBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZmZpbml0eSBEZXNpZ25lciAyIDIuMC40IgogICAgICBzdEV2dDp3aGVuPSIyMDIzLTAzLTI1VDA5OjA2OjU4KzAxOjAwIi8+CiAgICA8L3JkZjpTZXE+CiAgIDwveG1wTU06SGlzdG9yeT4KICA8L3JkZjpEZXNjcmlwdGlvbj4KIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+Cjw/eHBhY2tldCBlbmQ9InIiPz6ldAqQAAABgWlDQ1BzUkdCIElFQzYxOTY2LTIuMQAAKJF1kd8rg1EYxz/baGKiuKBcLOFqNNTiRtnSKGnNlOFme/dL7cfb+25puVVuV5S48euCv4Bb5VopIiW3XBM3rNfzbmqSPafnPJ/zPed5Ouc5YA2llYze4IZMNq8F/V7nYnjJaX/GRjd2BrFEFF2dDARmqWsfd1jMeDNo1qp/7l9ricV1BSxNwhOKquWFp4Vn1/KqydvCnUoqEhM+FXZpckHhW1OPVvnF5GSVv0zWQkEfWNuFnclfHP3FSkrLCMvL6cukC8rPfcyXOOLZhXmJveI96ATx48XJDFP48DDMuMwe6c4IQ7KiTr67kj9HTnIVmVWKaKySJEUel6gFqR6XmBA9LiNN0ez/377qidGRanWHFxqfDOOtH+xbUC4ZxuehYZSPwPYIF9lafu4Axt5FL9W0vn1o24Czy5oW3YHzTeh6UCNapCLZxK2JBLyeQGsYOq6hebnas599ju8htC5fdQW7ezAg59tWvgEshmfLrsJJUgAAAAlwSFlzAAALEwAACxMBAJqcGAAAAohJREFUeJztmj1uE1EURo8J0BBMmSgV7IE0oUzDCtJQ44JsgcRmEQksAJZARBqoUrGCVNPhGpzGwlIo/J4x9hv7vv/n8D7pSJYlz3xX1x4djQdqamo2M68UNQXnGfBT8TRvlZq2bAFXwK3iSr1XU1gG/F2Spp+zUM1yXgATlhc1AQ4y9qqZyxOgYXlJmgboZmtXM8sn2pek+ZitXQ0w1fB1S9JUZc8UreLSRVVlz5BFFZdSlX1N7gc+3gluNncAvAXeha0TJF3gJbAP7C0A8GOB78AX4FfypsK0qbiUkpR9F+gBF8AY+1nG6rM9daxisk7FpeRW9h3gHL8vnOkLeKaOnT0SFZeSQ9m3md4tuXHoK2UEnKpzZYmNiktJqeyHwDDCDG0M1TmTxlbFpaRQ9g5wTNjLnJSJOneSuKq4lJjK/gD4ELG7lPeqS9QMEgzSj9D7IXCZoLuUSyIuy1fFpYRW9g5l/JJMv6zgCaXiUhrCKftxwt62vAk04ywhVVxKCGU/JI84SJkQ0AZjqLgUH2XfJq2CuzIEHnnMCcRTcSk+yn6asbctJ44zAvFVXIqLsu8Q945DaEZ43G4aFDCApm/Z/byAzracWc4IpFNxKTbKvltYdym/sbzrnlrFpTTIlL1XQFdXXgvmmyWHikuRKPtFAT1d+SyYD8ir4lJWKXsXtz/9SmEMPF4xH5BfxaWsUvajAvr5cqSHuWcYcIvpZWUTHo7sMr08m5R9P3GXGHmuX5gW5fqASq7oB2MWs2d4b9PSOkNpKi7FpOzfCujly1fTkkpVcSkN/16urwvo5Mu1aVElq7iUeWUfFdDHlxs9TGdusFvuRvRMd2oek0zUFJi6qJqamv8wfwB+DW9fiCc45gAAAABJRU5ErkJggg==", iconMapping: { COLD: { x: 2, y: 2, width: 50, height: 38, anchorY: 35, mask: !0 }, WARM: { x: 54, y: 2, width: 50, height: 38, anchorY: 35, mask: !0 } } };
function Vh(a, e) {
  for (let t = a.length - 1; t >= 0; t--) if (e.call(a, a[t], t, a)) return t;
  return -1;
}
const wn = { data: { type: "array", value: [] }, minZoom: { type: "object", value: null }, maxZoom: { type: "object", value: null }, getType: { type: "function", value: null }, getPath: { type: "function", value: null }, width: { type: "number", value: 2 }, coldColor: { type: "color", value: [0, 0, 255] }, warmColor: { type: "color", value: [255, 0, 0] }, occludedColor: { type: "color", value: [148, 0, 211] }, iconSize: { type: "number", value: 15 }, _debug: { type: "boolean", value: !1 } };
class zn extends je {
  renderLayers() {
    const { viewport: e } = this.context, { props: t, visibleFrontLines: n, visibleDebugFrontPoints: r } = this.state;
    if (!t || !n || !r) return [];
    const { getType: s, getPath: o, width: i, coldColor: l, warmColor: u, occludedColor: c, iconSize: f, _debug: h } = he(t, wn);
    if (!s || !o) return [];
    const { iconStyle: p, iconAtlasTexture: v } = this.state;
    if (!p || !v) return [];
    const I = { [Ee.COLD]: l, [Ee.WARM]: u, [Ee.OCCLUDED]: c, [Ee.STATIONARY]: l };
    return [new Qs(this.getSubLayerProps({ id: "path", data: n, getPath: (y) => [y.startPosition, ...y.icons.map(((T) => T.position)), y.endPosition], getColor: (y) => I[s(y.d)], getWidth: i, widthUnits: "pixels" })), new Qs(this.getSubLayerProps({ id: "path-stationary-warm", data: n.filter(((y) => s(y.d) === Ee.STATIONARY)), getPath: (y) => [y.startPosition, ...y.icons.map(((T) => T.position)), y.endPosition], getColor: u, getWidth: i, widthUnits: "pixels", extensions: [new Tl({ dash: !0, highPrecisionDash: !0 })], getDashArray: [45, 45] })), new Ki(this.getSubLayerProps({ id: "icon", data: n.flatMap(((y) => y.icons)), getPosition: (y) => y.position, getIcon: (y) => s(y.d) === Ee.OCCLUDED || s(y.d) === Ee.STATIONARY ? y.alternate ? Ee.COLD : Ee.WARM : s(y.d), getSize: f, getColor: (y) => s(y.d) === Ee.STATIONARY ? y.alternate ? I[Ee.COLD] : I[Ee.WARM] : I[s(y.d)], getAngle: (y) => s(y.d) === Ee.STATIONARY ? y.alternate ? Ye(e, y.direction) : Ye(e, y.direction + 180) : Ye(e, y.direction), iconAtlas: v, iconMapping: p.iconMapping, sizeBasis: "height", billboard: !1, extensions: [new Jr()], collisionEnabled: !0, collisionGroup: "front-icon", collisionTestProps: { sizeScale: 5 }, getCollisionPriority: (y) => y.priority })), ...h ? [new In(this.getSubLayerProps({ id: "text", data: r, getPosition: (y) => y.position, getText: (y) => `${y.index}`, getSize: 12, getColor: Es, getAngle: Ye(e, 0), outlineWidth: 1, outlineColor: ks, fontFamily: Cs, fontSettings: { sdf: !0 }, billboard: !1 }))] : []];
  }
  shouldUpdateState(e) {
    return super.shouldUpdateState(e) || e.changeFlags.viewportChanged;
  }
  updateState(e) {
    const { data: t, getType: n, getPath: r, minZoom: s, maxZoom: o } = e.props;
    super.updateState(e), t && n && r ? (this.state.iconStyle || this._updateIconStyle(), t === e.oldProps.data && r === e.oldProps.getPath || this._updateFeatures(), (s !== e.oldProps.minZoom || o !== e.oldProps.maxZoom || e.changeFlags.viewportChanged) && this._updateVisibleFeatures(), this.setState({ props: e.props })) : this.setState({ features: void 0, debugFeatures: void 0, visibleFeatures: void 0, visibleDebugFeatures: void 0 });
  }
  async _updateIconStyle() {
    const { device: e } = this.context;
    this.setState({ iconStyle: Pi });
    const t = nt(e, await cl(Pi.iconAtlas));
    this.setState({ iconAtlasTexture: t });
  }
  _updateFeatures() {
    const { data: e, getPath: t } = he(this.props, wn);
    if (!t) return;
    const n = e.map(((s) => (function(o, i) {
      const l = i, u = l.slice(0, -1).map(((h, p) => Qe(l[p], l[p + 1]))).reduce(((h, p) => [...h, h[h.length - 1] + p]), [0]);
      let c = [];
      for (let h = 1, p = u[u.length - 1] / 3; p > 5e3; h++, p /= 3) {
        const v = 3 ** h;
        for (let I = 1; I < v; I++) {
          if (h > 1 && I % 3 == 0) continue;
          const y = I * p, T = Vh(u, ((G) => G <= y));
          if (T === -1 || T === l.length - 1) throw new Error("Invalid state");
          const L = T + 1, E = l[T], C = l[L], Q = u[T], M = hc(E, C), Z = _h(E, y - Q, M), z = 90 - M, N = 100 - h;
          c.push({ distance: y, position: Z, direction: z, priority: N });
        }
      }
      c = c.sort(((h, p) => h.distance - p.distance));
      const f = c.map(((h, p) => ({ d: o, ...h, alternate: p % 2 == 0 })));
      return { d: o, startPosition: i[0], endPosition: i[i.length - 1], icons: f };
    })(s, t(s)))), r = e.flatMap(((s) => t(s).map(((o, i) => ({ d: s, position: o, index: i })))));
    this.setState({ frontLines: n, debugFrontPoints: r }), this._updateVisibleFeatures();
  }
  _updateVisibleFeatures() {
    const { viewport: e } = this.context, { minZoom: t, maxZoom: n } = he(this.props, wn), { frontLines: r, debugFrontPoints: s } = this.state;
    if (!r || !s) return;
    let o, i;
    Bt(e, t, n) ? (o = r, i = s) : (o = [], i = []), this.setState({ visibleFrontLines: o, visibleDebugFrontPoints: i });
  }
}
zn.layerName = "FrontCompositeLayer", zn.defaultProps = wn;
const Fh = { ...zn.defaultProps };
class Oi extends je {
  renderLayers() {
    return [new zn(this.props, this.getSubLayerProps({ id: "composite" }))];
  }
}
Oi.layerName = "FrontLayer", Oi.defaultProps = Fh;
const Rh = /* @__PURE__ */ new Map(), Wh = /* @__PURE__ */ new Map();
function qh(a, e = 0) {
  let t;
  if (We(a))
    t = (function(n, r, s) {
      s = Math.min(Math.max(s - 2, 0), 7);
      const i = Rh.get(s) ?? (() => {
        const { uv: c } = Sc(s, !0), f = [];
        for (let h = 0; h < c.length; h += 2) {
          const p = c[h], v = c[h + 1];
          if (p === 0 || v <= 0 || v >= 1) continue;
          const I = 360 * p - 180, y = 180 * v - 90;
          f.push([I, y]);
        }
        return f.push([0, -90]), f.push([0, 90]), f;
      })(), l = Wh.get(s) ?? (() => {
        const c = new cs(i.length, void 0, Float32Array);
        for (let f = 0; f < i.length; f++) {
          const h = i[f];
          c.add(h[0], h[1]);
        }
        return c.finish(), c;
      })();
      return Dc(l, n[0], n[1], void 0, r / 1e3).map(((c) => i[c]));
    })(Ts(a), dl(a), Math.floor(Zt(a) + e + 1));
  else {
    if (!hl(a)) throw new Error("Invalid state");
    t = (function(n, r) {
      const s = new Bc({ size: 1, antimeridian: !0 }), o = [...s.px([n[0], n[1]], r), ...s.px([n[2], n[3]], r)];
      [o[1], o[3]] = [o[3], o[1]];
      const i = 2 ** r, l = o[2] - o[0] + 1, u = o[3] - o[1] + 1, c = [];
      for (let f = 0; f < u; f++) for (let h = 0; h < l; h++) {
        const p = o[0] + h, v = [p, o[1] + f + (p % 2 == 1 ? 0.5 : 0)];
        if (v[0] === 0 || v[1] <= 0 || v[1] >= i) continue;
        const I = s.ll([v[0], v[1]], r);
        I[0] = ts(I[0]), c.push(I);
      }
      return c;
    })(pl(a), Math.floor(Zt(a) + e));
  }
  return t;
}
const ss = { VALUE: "VALUE", ARROW: "ARROW", WIND_BARB: "WIND_BARB" }, Ni = /* @__PURE__ */ new Map([[ss.ARROW, { iconAtlas: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAFtGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS41LjAiPgogPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIgogICAgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIgogICAgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIgogICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iCiAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIKICAgIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIgogICAgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIKICAgeG1wOkNyZWF0ZURhdGU9IjIwMjMtMDMtMTBUMTQ6NDE6MjYrMDEwMCIKICAgeG1wOk1vZGlmeURhdGU9IjIwMjQtMDItMTFUMjM6Mzc6NTErMDE6MDAiCiAgIHhtcDpNZXRhZGF0YURhdGU9IjIwMjQtMDItMTFUMjM6Mzc6NTErMDE6MDAiCiAgIHBob3Rvc2hvcDpEYXRlQ3JlYXRlZD0iMjAyMy0wMy0xMFQxNDo0MToyNiswMTAwIgogICBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIgogICBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiCiAgIGV4aWY6UGl4ZWxYRGltZW5zaW9uPSIxMDAiCiAgIGV4aWY6UGl4ZWxZRGltZW5zaW9uPSIxMDAiCiAgIGV4aWY6Q29sb3JTcGFjZT0iMSIKICAgdGlmZjpJbWFnZVdpZHRoPSIxMDAiCiAgIHRpZmY6SW1hZ2VMZW5ndGg9IjEwMCIKICAgdGlmZjpSZXNvbHV0aW9uVW5pdD0iMiIKICAgdGlmZjpYUmVzb2x1dGlvbj0iNzIvMSIKICAgdGlmZjpZUmVzb2x1dGlvbj0iNzIvMSI+CiAgIDxkYzp0aXRsZT4KICAgIDxyZGY6QWx0PgogICAgIDxyZGY6bGkgeG1sOmxhbmc9IngtZGVmYXVsdCI+YXJyb3c8L3JkZjpsaT4KICAgIDwvcmRmOkFsdD4KICAgPC9kYzp0aXRsZT4KICAgPHhtcE1NOkhpc3Rvcnk+CiAgICA8cmRmOlNlcT4KICAgICA8cmRmOmxpCiAgICAgIHN0RXZ0OmFjdGlvbj0icHJvZHVjZWQiCiAgICAgIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFmZmluaXR5IERlc2lnbmVyIDIgMi4zLjEiCiAgICAgIHN0RXZ0OndoZW49IjIwMjQtMDItMTFUMjM6Mzc6NTErMDE6MDAiLz4KICAgIDwvcmRmOlNlcT4KICAgPC94bXBNTTpIaXN0b3J5PgogIDwvcmRmOkRlc2NyaXB0aW9uPgogPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KPD94cGFja2V0IGVuZD0iciI/PkD+OBEAAAGAaUNDUHNSR0IgSUVDNjE5NjYtMi4xAAAokXWRz0tCQRDHP1phpGFQRIcOEtbJwgykLkFGWCAhZpDVRZ+/ArXHe0ZE16BrUBB16deh/oK6Bp2DoCiC6Oy5qEvFa54KSuQss/PZ7+4Mu7NgjeaUvN7shXyhqEWCAddCbNFlK2HFTjduLHFFVyfC4RAN7fMRixnvB81ajc/9a/ZkSlfA0io8rqhaUXhaOLReVE3eE+5SsvGk8IWwR5MLCj+YeqLCJZMzFf42WYtGJsHaIezK1HGijpWslheWl+PO59aU6n3MlzhShfk5iX3ivehECBLAxQxTTOJnmDGZ/QziY0hWNMj3lvNnWZVcRWaVDTRWyJCliEfUNamekpgWPSUjx4bZ/7991dMjvkp1RwBaXg3jvR9su/CzYxhfJ4bxcwpNL3BdqOWvHsPoh+g7Nc19BM4tuLypaYl9uNqGnmc1rsXLUpO4NZ2Gt3Noj0HnHbQtVXpW3efsCaKb8lW3cHAIA3LeufwLGtZnw2AleGQAAAAJcEhZcwAACxMAAAsTAQCanBgAAAOKSURBVHic7Zy9j01BGIcfSyHZRKmyye21iOpq9CJ6NfEPqMU/oKZeEVHZFQUqraBHoyBUhFwF9yjO3rh7nTtnZs58vO+575NMssXOmY8nM3ve/e1dMAxjfMyApqfNqs1uAFu1J2AcxoQIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIw4QIo4aQYxXGjKX4XGsIuQBMK4wbyhQ4U3sSJdgGvjJMSu6PI0yBd8DRAc9QxT7wg3gpOYVMD+Z2J7K/Sq7RblqslFxCFjIa4HxEf7Wc4t/GxUjJIWRZxgfgSGB/9bwmXkpqIcsyGuB2QN/RcIvDGxgiJaWQVRkNcNqz76g4y/+b6CsllZAuGW9DFjEmtoBPxElJIaRLRgPcDF/KeLhL92b2SRkqZJ2MBpjELmYMXGL9hrqkDBHikvFy6IK0sw38IlxKrBCXjAa4kWZZutnHvbFdUmKE9Mn4DZxMujKlLKr2ECmhQvpkNMDTHIvTyA79m7sqJUSIj4wGuJpvifpYrtp9pPgK8ZUxA05kX6UiVqv2Pilzj++b4yejAR7mX6Iuuqr2ku1y/iXqYl3VXqJ9A47nX6IfUv7IYU77+luDR7S1kAikCAF4XGnc3Urjiqevas/RPiMsN5d0Qn4CzwuP+QD4U3hMJ5KEQPlr637h8dThW7WnaCJzc2kn5CPwptBYu7RiRCFNCJS7tuy68qRE1S42N5d4Ql7Rvo7mxE5HIPfIe0ImxVYyElxZ+9C28bl5DDmrdsvNI+nL2mOa+Nxc4g/1BXsZnvkM+JLhuRtBjqrdcvOB+GbtPk1Fbi75yoK0Vfse8D3h8zaSlFW75eYJSJW1i8rNXUi/slJl7aJyc+2kqNovFp/1iBlatYvLzV1Iv7JgeNYuLjd3oUEIDKva7VftGYit2kXm5i60nJDYrF1kbu5CixCIq9rtuspIaNUuNjcfC6FV+0Z/3rwUIVn7pM4UNwvfqt1y80L4Vu2WmxfkCW4Z4nNzF5peexf0vf5abl6YvqrdcvMKrMvaVeTmLjReWbD+2rLcvBLn6D4hlptXoqtqV5Obu9B6ZXVl7ZabV2a1arfcvDLLVbuq3NyF1isL2qz9xcHXqnLzMXOd9oRs1P9pl8wO8B5lufnYuVJ7AoZhlOIvaGdhp4AP+qMAAAAASUVORK5CYII=", iconMapping: { 0: { x: 0, y: 0, width: 100, height: 100, mask: !0 } } }], [ss.WIND_BARB, { iconAtlas: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA/wAAAKoCAYAAADKyfSuAAAAAXNSR0IArs4c6QAAIABJREFUeF7s3W2sdWd6F/YLIQFf+AJODBRm8kJCMnqMWrVU7pBUVK0UUFCKpwEncezMJBM0ICVNbImED9gZI94i222TL5EIk0SPnSaozbhAFCK1KmoG1yqtWmGJooJLMkxD/NiIL3wAJKRqxcea4+P9stbe17XWuu/7tyUryfPsfa37/l3/rGdf5z5nn98QHgQIECBAgAABAgQIECBAgEB3Ar+hux3ZEAECBAgQIECAAAECBAgQIBAGfiEgQIAAAQIECBAgQIAAAQIdChj4O2yqLREgQIAAAQIECBAgQIAAAQO/DBAgQIAAAQIECBAgQIAAgQ4FDPwdNtWWCBAgQIAAAQIECBAgQICAgV8GCBAgQIAAAQIECBAgQIBAhwIG/g6baksECBAgQIAAAQIECBAgQMDALwMECBAgQIAAAQIECBAgQKBDAQN/h021JQIECBAgQIAAAQIECBAgYOCXAQIECBAgQIAAAQIECBAg0KGAgb/DptoSAQIECBAgQIAAAQIECBAw8MsAAQIECBAgQIAAAQIECBDoUMDA32FTbYkAAQIECBAgQIAAAQIECBj4ZYAAAQIECHxR4CMR8Q+AENi5gJzuvEGW9+sCcioILQh0n1MDfwsxtEYCBAgQWEPgkxHxfRFxb42LuQaBCwXk9EI4L1tVQE5X5XaxCwWGyKmB/8J0eBkBAgQIdCMwDfjfHxHfebOjH46IH+hmdzbSi4Cc9tLJvvchp333t5fdDZVTA38vsbUPAgQIELhE4Ltvhv2vvfPiT0TET15S0GsIFAjIaQGqkukCcppOqmCBwHA5NfAXpEhJAgQIENi9wPTV/acjYhrsDz1+LSL+eER8bvc7scCeBeS05+72szc57aeXPe9k2Jwa+HuOtb0RIECAwCGBP3lzqv81J3j+ekQ8jo/AhgJyuiG+S88WkNPZVJ64ocDQOTXwb5g8lyZAgACBVQV+X0T8YER8/MRV/21E/ImI+LlVV+ZiBL4oIKfS0IKAnLbQJWuU04gw8Pt/BAIECBAYQeBTN6f6X31is69ExLePgGGPuxWQ0922xsJuCcipOLQgIKc3XTLwtxBXayRAgACBSwW+IiKei4inThT4Vzen+n/z0ot4HYErBeT0SkAvX0VATldhdpErBeT0DqCB/8pEeTkBAgQI7FZg+ur+9MF8X3VihT915lv8d7s5C+tGQE67aWXXG5HTrtvbzebk9EArDfzd5NtGCBAgQOBG4HdHxF+MiCdPiPzLm1P9X6BGYCMBOd0I3mUXCcjpIi5P3khATk/AG/g3SqXLEiBAgECJwHfdfDDf7z1R/ccjYvo9vB4EthKQ063kXXeJgJwu0fLcrQTk9Iy8gX+raLouAQIECGQKPBwRL0bEEyeK/oubv3eqnymv1hIBOV2i5blbCcjpVvKuu0RATmdqGfhnQnkaAQIECOxWYPpAvumD+aYP6jn2+LGI+FO73YGFjSAgpyN0uf09Zub00zf35vZV7GBvAnK6oCMG/gVYnkqAAAECuxL4bRHxI2dO9d+OiO+ICKf6u2rdUIuR06Ha3exmM3P60ZvvuHr05rNUXm5WxcL3JiCnF3TEwH8BmpcQIECAwOYC3xoRfyEivvzESn40Ir5385VawMgCcjpy99vZe2ZOp1P9Z29t/UFE3IuI6YuvHgSuEZDTC/UM/BfCeRkBAgQIbCLwW29O9T9+4uq/GhGfdKq/SX9c9F0BOZWEFgQyc3r7VP/u3qcT/lO/NaUFK2vcTkBOr7Q38F8J6OUECBAgsJrAN0fECxHx4RNXdKq/Wjtc6IiAnIpGCwKZOb17qn9o/9PPXN9vAcYadyUgpwntMPAnICpBgAABAqUCv+XmVP/Ur9L7fER8yql+aR8UPy0gpxLSgkBmTk+d6r9n8XpEPBMRr7WAY427EZDTxFYY+BMxlSJAgACBdIFviojp1P5DJyo71U9nV3ChgJwuBPP0TQQyczrnVP95n9K/SZ9bv6icJnfQwJ8MqhwBAgQIpAj8xptT/T99otqbEfE9TvVTvBW5TEBOL3PzqnUFMnPqVH/d3o10NTkt6raBvwhWWQIECBC4WOCP3Jzqf+WJCk71L+b1wiQBOU2CVKZUIDOnTvVLWzV0cTktbL+BvxBXaQIECBC4SOCHTnwb6D+++VV7v3BRZS8ikCcgp3mWKtUJZOTUqX5df1R+V0BOC5Ng4C/EVZrADgUO3VCnr9hPf+5BYC8Cx/7hd6q/lw5Zx6k3qHNzOt17n0NJoFjg2vupU/3iBil/cuBfcj999ozlsJ8pYeD3/2UExhIw8I/V71Z3K6etdm6sdV+a09unpdPvJp9+R7kHgSqBjJweW5tP4K/q2nh15bSw5wb+QlylCexQ4NIb6g63YkkdC8hpx83taGuX5PTuaemDiLgXEW935GIr+xLIyOmhHQ17Wrqv9nazGjktbKWBvxBXaQI7FLjkhrrDbVhS5wJy2nmDO9nekpye+hno6YR/Oun3IFAhkJXT99bmVL+iS2rKaWEGDPyFuEoT2KHAkhvqDpdvSYMIyOkgjW58m3NzOudnoJ+KiPuNe1j+PgUyc+pUf5897mFVclrYRQN/Ia7SBHYoMPeGusOlW9JAAnI6ULMb3uq5nPpk84ab29HS5bSjZna8FTktbK6BvxBXaQI7FDh3Q93hki1pQAE5HbDpDW75VE7nnOo7LW2w6Q0uWU4bbNqAS5bTwqYb+AtxlSawQwGD1A6bYkkfEJBToWhB4FBOPxMRH4mIR09swM9At9DdftYop/30suedyGlhdw38hbhKE9ihgEFqh02xJAO/DDQpcOh+em4jTvXPCfn7bAE5zRZVr0JATitUb2oa+AtxlSawQwED/w6bYkkGfhloUmDJG1Sn+k22uItFy2kXbex+E3Ja2GIDfyGu0gR2KGDg32FTLMnALwNNCsx9g+pUv8n2drNoOe2mlV1vRE4L22vgL8RVmsAOBQz8O2yKJRn4ZaBJgXNvUJ3qN9nW7hYtp921tMsNyWlhWw38hbhKE9ihwLUD/0MR8c4O92VJfQlcm9O+NOxmrwKn3qA61d9r18Zbl5yO1/MWd3xtTr0/PdF1A3+L/y9hzQQuF7hmkHoyIl6IiHsR8fblS/BKAmcFrsnp2eKeQCBJ4FBOvxARj0fEa0nXUIbAtQJyeq2g168hcE1OvT890yED/xoRdg0C+xG4ZJB6OCJejIgnbrbxckRMN1cPAlUCl+S0ai3qEjgmIKey0YKAnLbQJWu8JKfen87MjYF/JpSnEehEYOkNdRrsX4qI6Vulbj+mP58Gfw8CFQJLc1qxBjUJnBOQ03NC/n4PAnK6hy5YwzmBpTn1/vSc6K2/N/AvwPJUAh0IzL2h3v2q6d2tT9/SP31r/4MOTGxhfwJzc7q/lVvRSAJyOlK3292rnLbbu5FWPjen3p9ekAoD/wVoXkKgYYE5N9RjXzW9ve1XIuKZiHirYQtL36/AnJzud/VWNoqAnI7S6bb3Kadt92+U1c/JqfenF6bBwH8hnJcRaFTg1A313FdNpy1Pn9D/dETcb3T/lt2GwJx/+NvYiVX2LCCnPXe3n73JaT+97Hkn3p8WdtfAX4irNIEdChy7ob555Gf1nervsIkDLMkb1AGa3MEW5bSDJg6wBTkdoMkdbNH708ImGvgLcZUmsEOBQzfUNyLikRNrdaq/w0Z2viRvUDtvcCfbk9NOGtn5NuS08wZ3sj3vTwsbaeAvxFWawA4FDt1QTy3Tz+rvsIkDLMkb1AGa3MEW5bSDJg6wBTkdoMkdbNH708ImGvgLcZUmsEOBuTdUp/o7bN5AS/IGdaBmN7xVOW24eQMtXU4HanbDW/X+tLB5Bv5CXKUJ7FBgzg3Vqf4OGzfYkrxBHazhjW5XThtt3GDLltPBGt7odr0/LWycgb8QV2kCOxQ4dUN1qr/Dhg26JG9QB218Y9uW08YaNuhy5XTQxje2be9PCxtm4C/EVZrADgWO3VCd6u+wWQMvyRvUgZvf0NbltKFmDbxUOR24+Q1t3fvTwmYZ+AtxlSawQ4FDN9RXI+KxHa7VksYV8AZ13N63tHM5balb465VTsftfUs79/60sFsG/kJcpQnsUMA//DtsiiV9QEBOhaIFATltoUvWKKcy0IKAnBZ2ycBfiKs0gR0KuKHusCmWZOCXgSYF3E+bbNtwi5bT4Vre5IbltLBtBv5CXKUJ7FDADXWHTbEkA78MNCngftpk24ZbtJwO1/ImNyynhW0z8BfiKk1ghwJuqDtsiiUZ+GWgSQH30ybbNtyi5XS4lje5YTktbJuBvxBXaQI7FHBD3WFTLMnALwNNCrifNtm24RYtp8O1vMkNy2lh2wz8hbhKE9ihgBvqDptiSQZ+GWhSwP20ybYNt2g5Ha7lTW5YTgvbZuAvxFWawA4F3FB32BRLMvDLQJMC7qdNtm24RcvpcC1vcsNyWtg2A38hrtIEdijghrrDpliSgV8GmhRwP22ybcMtWk6Ha3mTG5bTwrYZ+AtxlSawQwE31B02xZIM/DLQpID7aZNtG27Rcjpcy5vcsJwWts3AX4irNIEdCrih7rAplmTgl4EmBdxPm2zbcIuW0+Fa3uSG5bSwbQb+QlylCexQwA11h02xJAO/DDQp4H7aZNuGW7ScDtfyJjcsp4VtM/AX4ipNYIcCbqg7bIolGfhloEkB99Mm2zbcouV0uJY3uWE5LWybgb8QV2kCOxRwQ91hUyzJwC8DTQq4nzbZtuEWLafDtbzJDctpYdsM/IW4ShPYoYAb6g6bYkkGfhloUsD9tMm2DbdoOR2u5U1uWE4L22bgL8RVmsAOBdxQd9gUSzLwy0CTAu6nTbZtuEXL6XAtb3LDclrYNgN/Ia7SBHYo4Ia6w6ZYkoFfBpoUcD9tsm3DLVpOh2t5kxuW08K2GfgLcZUmsEMBN9QdNsWSDPwy0KSA+2mTbRtu0XI6XMub3LCcFrbNwF+IqzSBHQq4oe6wKZZk4JeBJgXcT5ts23CLltPhWt7khuW0sG0G/kJcpQnsUMANdYdNsSQDvww0KeB+2mTbhlu0nA7X8iY3LKeFbTPwF+IqTWCHAm6oO2yKJRn4ZaBJAffTJts23KLldLiWN7lhOS1sm4G/EFdpAjsUcEPdYVMsycAvA00KuJ822bbhFi2nw7W8yQ3LaWHbDPyFuEoT2KGAG+oOm2JJBn4ZaFLA/bTJtg23aDkdruVNblhOC9tm4C/EVZrADgXcUHfYFEsy8MtAkwLup022bbhFy+lwLW9yw3Ja2DYDfyGu0gR2KOCGusOmWJKBXwaaFHA/bbJtwy1aTodreZMbltPCthn4C3GVJrBDATfUHTbFkgz8MtCkgPtpk20bbtFyOlzLm9ywnBa2zcBfiKs0gR0KuKHusCmWZOCXgSYF3E+bbNtwi5bT4Vre5IbltLBtBv5CXKUJ7FDADXWHTbEkA78MNCngftpk24ZbtJwO1/ImNyynhW0z8BfiKk1ghwJuqDtsiiUZ+GWgSQH30ybbNtyi5XS4lje5YTktbJuBvxBXaQI7FHBD3WFTLMnALwNNCrifNtm24RYtp8O1vMkNy2lh2wz8hbhKE9ihgBvqDptiSQZ+GWhSwP20ybYNt2g5Ha7lTW5YTgvbZuAvxFWawA4F3FB32BRLMvDLQJMC7qdNtm24RcvpcC1vcsNyWtg2A38hrtIEdijghrrDpliSgV8GmhRwP22ybcMtWk6Ha3mTG5bTwrYZ+AtxlSawQwE31B02xZIM/DLQpID7aZNtG27Rcjpcy5vcsJwWts3AX4irNIEdCrih7rAplmTgl4EmBdxPm2zbcIuW0+Fa3uSG5bSwbQb+QlylCexQwA11h02xJAO/DDQp4H7aZNuGW7ScDtfyJjcsp4VtM/AX4ipNYIcCbqg7bIolGfhloEkB99Mm2zbcouV0uJY3uWE5LWybgb8QV2kCOxRwQ91hUyzJwC8DTQq4nzbZtuEWLafDtbzJDctpYdsM/IW4ShPYoYAb6g6bYkkGfhloUsD9tMm2DbdoOR2u5U1uWE4L22bgL8RVmsAOBdxQd9gUSzLwy0CTAu6nTbZtuEXL6XAtb3LDclrYNgN/Ia7SBHYo4Ia6w6ZYkoFfBpoUcD9tsm3DLVpOh2t5kxuW08K2GfgLcZUmsEMBN9QdNsWSDPwy0KSA+2mTbRtu0XI6XMub3LCcFrbNwF+IqzSBHQq4oe6wKZZk4JeBJgXcT5ts23CLltPhWt7khuW0sG0G/kJcpQnsUMANdYdNsSQDvww0KeB+2mTbhlu0nA7X8iY3LKeFbTPwF+IqTWCHAm6oO2yKJRn4ZaBJAffTJts23KLldLiWN7lhOS1sm4G/EFdpAjsUcEPdYVMsycAvA00KuJ822bbhFi2nw7W8yQ3LaWHbDPyFuEoT2KGAG+oOm2JJBn4ZaFLA/bTJtg23aDkdruVNblhOC9tm4M/B/e0R8Xsi4kMR8eU3Jf9JRHw+Iv5pRPzznMuoQuBqATfUqwkVWEFATldAdomrBeT0akIFVhCQ0xWQXeJqATm9mvB4AQP/ZbiPRMS3RcR/GhEfjogvPVPmQUT8SkT8TxHx0xHxxmWX9SoCVwu4oV5NqMAKAnK6ArJLXC0gp1cTKrCCgJyugOwSVwvI6dWEBv4swm+8GfSnYf+axzT0T//9/DVFvJbABQJuqBegecnqAnK6OrkLXiAgpxegecnqAnK6OrkLXiAgpxegzX2JE/55Ut8REZ+MiK+b9/TZz/pcRPx4RPzU7Fd4IoHrBNxQr/Pz6nUE5HQdZ1e5TkBOr/Pz6nUE5HQdZ1e5TkBOr/M7+WoD/3ncv3oz7J9/5uXPmIb+77785V5JYLaAG+psKk/cUEBON8R36dkCcjqbyhM3FJDTDfFderaAnM6mWv5EA/9xs6+KiL8REV9zhvVfR8T/d/Pfr978z+kl/05E/K6b/zn977/5TJ1/GBHfFBH/aHkbvYLAbAE31NlUnrihgJxuiO/SswXkdDaVJ24oIKcb4rv0bAE5nU21/IkG/sNmn4iIz5zh/LsR8bM3/00fynfqMX2o3+M3//3BM8/9zoj4ieWt9AoCswTcUGcxedLGAnK6cQNcfpaAnM5i8qSNBeR04wa4/CwBOZ3FdNmTDPwfdPtjEfHZE5w/GRE/ExG/eBl5fENEfEtEfPzE6x+LiFcvrO9lBE4JuKHKRwsCctpCl6xRTmWgBQE5baFL1iinhRkw8L8f93dExD874f0DEfHDSf34MxHxV07U+p0R8WtJ11KGwHsCbqiy0IKAnLbQJWuUUxloQUBOW+iSNcppYQYM/O/H/Z8j4g8d8X4yIl5O7sW3R8T9IzX/TkT8J8nXU46AG6oMtCAgpy10yRrlVAZaEJDTFrpkjXJamAED/xdxn4+IP3fE+ssi4leK+vDhiPjlI7X/fEQ8W3RdZccUcEMds++t7VpOW+vYmOuV0zH73tqu5bS1jo25Xjkt7LuB/13cJ06c3n9JRLxT2IOp9EMR8faRa0zfBfBK8fWVH0fADXWcXre8UzltuXvjrF1Ox+l1yzuV05a7N87a5bSw1wb+d3F/KSK+7oDz9GfTp/Gv8Zg+vf9zBy40/dnXr7EA1xhCwA11iDY3v0k5bb6FQ2xATodoc/OblNPmWzjEBuS0sM0G/ohvjIi/dcD4u2b8ar7s1ky/ku+vHSj6RyPi57Mvpt6QAm6oQ7a9uU3LaXMtG3LBcjpk25vbtJw217IhFyynhW038L/77fLfdsd4+tV7nyh0P1X6Jw78yr6fvvmxg42W5LIdCbihdtTMjrcipx03t6OtyWlHzex4K3LacXM72pqcFjZz9IH/kYj4+wd8/3BE/GKh+6nS3xARf/vAE35/RLyx0Zpcth8BN9R+etnzTuS05+72szc57aeXPe9ETnvubj97k9PCXo4+8P+liPjBO77Tz+wf+nn+wjZ8oPT0c/vTz/TffvzliPizay7CtboUcEPtsq3dbUpOu2tplxuS0y7b2t2m5LS7lna5ITktbOvoA//fi4j/4I7v90bEjxaazyn9PRHxI3ee+L9HxB+Y82LPIXBCwA1VPFoQkNMWumSNcioDLQjIaQtdskY5LczA6AP/g4iYfu3ee49/ExG/JyKmP9/y8aUR8U8j4jfdWsT0a/umP/cgcI2AG+o1el67loCcriXtOtcIyOk1el67loCcriXtOtcIyOk1emdeO/LA/1BETEP07ccvR8SXF3ovKf1PIuLL7rxg+uLEO0uKeC6BOwJuqCLRgoCcttAla5RTGWhBQE5b6JI1ymlhBkYe+P/9iJi+Tf7243+NiI8Wei8p/VpE/Ed3XjD9+MH/saSI5xIw8MtAgwL+4W+waQMuWU4HbHqDW5bTBps24JLltLDpIw/8H4uI//6O7fR/f3Oh95LS/11E/Bd3XjD93z+3pIjnEjDwy0CDAv7hb7BpAy5ZTgdseoNbltMGmzbgkuW0sOkjD/zfFxH/1R3b6f9+utB7SemXIuL777xg+r//6yVFPJeAgV8GGhTwD3+DTRtwyXI6YNMb3LKcNti0AZcsp4VNH3ng/y8PDM/TkP1MofeS0i8e+OLD9EWK/2ZJEc8lQIAAAQIECBAgQIAAgTEFRh74vyki/oc7bf/ZiPiWnUThZyLi8Ttr+c8j4m/sZH2WQYAAAQIECBAgQIAAAQI7Fhh54P93I+L/vNObX4qI/3gn/fpfIuLr76zl34uI/2sn67MMAgQIECBAgAABAgQIENixwMgD/28/8Cvu/t+I+Mqd9OvNiPiKO2uZfpXgP9/J+iyDAAECBAgQIECAAAECBHYsMPLAP7XlrYj40lv9+dcR8aGIeLBxz6Y1fT4ifvOtdUxrenjjdbk8AQIECBAgQIAAAQIECDQiMPrA/79FxB+406vvjYgf3bh/3xMRP3JnDX8vIv7Djdfl8gQIECBAgAABAgQIECDQiMDoA/9fiogfvNOrvxsRX7dx/z4XEX/wzhr+ckT82Y3X5fIECBAgQIAAAQIECBAg0IjA6AP/IxHx9w/06g9HxC9u1MNviIi/feDavz8i3thoTS5LgAABAgQIECBAgAABAo0JjD7wT+16JSK+7U7ffjIiPrFRL38iIj5+59o/HRFPbLQelyVAgAABAgQIECBAgACBBgUM/BHfGBF/60DvfiAifnjlnv6ZiPgrB675RyPi51dei8sRIECAAAECBAgQIECAQMMCBv53m/dLR35u/8mIeHml/n57RNw/cK3p5/m/fqU1uAwBAgQIECBAgAABAgQIdCJg4H+3kd8REdO38R96fFlE/Epxvz8cEb985BrTt/f/VPH1lSdAgAABAgQIECBAgACBzgQM/F9s6F+NiE8e6e+XRMQ7Rb1/KCLePlL7xyPiu4uuqywBAgQIECBAgAABAgQIdCxg4H9/c//viPiaI/2eflXf9Cv7Mh/Tr96bvmX/0OMfRsTXZl5MLQIECBAgQIAAAQIECBAYR8DA//5ef1VE/D8n2v9dEfGZpHh8Z0T8tRO1vjoi/lHStZQhQIAAAQIECBAgQIAAgcEEDPwfbPj06/hODfXTz/r/TET84oVZ+YaI+JYDv3rvdrnpiwHTr+fzIECAAAECBAgQIECAAAECFwkY+A+z/bGI+OwZ0enb+3/25r8HZ577pRHx+M1/07fxn3o8FhGvXtRNLyJAgAABAgQIECBAgAABAjcCBv7jUfgdEfHfRsQfOpOWfxMRvxoR/+zmf37+5vkfiojfFRG/8+Z//qYzdf5ORHxrRPyadBIgQIAAAQIECBAgQIAAgWsFDPznBZ+PiD93/mlXPePPR8SzV1XwYgIECBAgQIAAAQIECBAgcEvAwD8vDk9ExKciYvqk/szH9An9PxYRr2QWVYsAAQIECBAgQIAAAQIECBj4l2XgGyPi227+W/bK9z/7pyNi+u/nrynitQQIECBAgAABAgQIECBA4JiAgf+ybDxyM/T/ZxHx4Yj4kjNl3o6IX4mI//Fm0H/jsst6FQECBAgQIECAAAECBAgQmCdg4J/ndO5ZD90M/tPwP31Y3/SYPrxvGvKn/945V8DfEyBAgAABAgQIECBAgACBTAEDf6amWgQIECBAgAABAgQIECBAYCcCBv6dNMIyCBAgQIAAAQIECBAgQIBApoCBP1NTLQIECBAgQIAAAQIECBAgsBMBA/9OGmEZBAgQIECAAAECBAgQIEAgU8DAn6mpFgECBAgQIECAAAECBAgQ2ImAgX8njbAMAgQIECBAgAABAgQIECCQKWDgz9RUiwABAgQIECBAgAABAgQI7ETAwL+TRlgGAQIECBAgQIAAAQIECBDIFDDwZ2qqRYAAAQIECBAgQIAAAQIEdiJg4N9JIyyDAAECBAgQIECAAAECBAhkChj4MzXVIkCAAAECBAgQIECAAAECOxEw8O+kEZZBgAABAgQIECBAgAABAgQyBQz8mZpqESBAgAABAgQIECBAgACBnQgY+HfSCMsgQIAAAQIECBAgQIAAAQKZAgb+TE21CBAgQIAAAQIECBAgQIDATgQM/DtphGUQIECAAAECBAgQIECAAIFMAQN/pqZaBAgQIECAAAECBAgQIEBgJwIG/p00wjIIECBAgAABAgQIECBAgECmgIE/U1MtAgQIECBAgAABAgQIECCwEwED/04aYRkECBAgQIAAAQIECBAgQCBTwMCfqakWAQIECBAgQIAAAQIECBDYiYCBfyeNsAwCBAgQIECAAAECBAgQIJApYODP1FSLAAECBAgQIECAAAECBAjsRMDAv5NGWAYBAgQIECBAgAABAgQIEMgUMPBnaqpFgAABAgQIECBAgAABAgR2ImDg30kjLIMAAQIECBAgQIAAAQIECGQKGPgzNdUiQIAAAQIECBAgQIAAAQI7ETDw76QRlkGAAAECBAgQIECAAAECBDIFDPyZmtvV+khE/IPtLu/KBGYJyOk+90g5AAAgAElEQVQsJk/aWEBON26Ay88SkNNZTJ5EgAABAgb+9jPwyYj4voi41/5W7KBjATntuLkdbU1OO2pmx1uR046ba2sECBDIFjDwZ4uuV28a8L8/Ir7z5pI/HBE/sN7lXYnALAE5ncXkSRsLyOnGDXD5WQJyOovJkwgQIEDgtoCBv808fPfNsP+1d5b/iYj4yTa3ZNUdCshph03tcEty2mFTO9ySnHbYVFsiQIDAGgIG/jWU864xfXX/6YiYBvtDj1+LiD8eEZ/Lu6RKBBYLyOliMi/YQEBON0B3ycUCcrqYzAsIECBA4LaAgb+dPPzJm1P9rzmx5L8eEY+3syUr7VBATjtsaodbktMOm9rhluS0w6baEgECBNYWMPCvLb78er8vIn4wIj5+4qX/NiL+RET83PLyXkEgRUBOUxgVKRaQ02Jg5VME5DSFURECBAgQmAQM/PvOwaduTvW/+sQyX4mIb9/3NqyucwE57bzBnWxPTjtpZOfbkNPOG2x7BAgQWFvAwL+2+LzrfUVEPBcRT514+r+6OdX/m/NKehaBdAE5TSdVsEBATgtQlUwXkNN0UgUJECBAYBIw8O8vB9NX96cP5vuqE0v7qTPf4r+/XVlRbwJy2ltH+9yPnPbZ1952Jae9ddR+CBAgsCMBA/9+mvG7I+IvRsSTJ5b0L29O9X9hP8u2ksEE5HSwhje6XTlttHGDLVtOB2u47RIgQGALAQP/FuofvOZ33Xww3+89sZwfj4jp9/B6ENhKQE63knfdJQJyukTLc7cSkNOt5F2XAAECgwkY+Ldt+MMR8WJEPHFiGf/i5u+d6m/bq5GvLqcjd7+dvctpO70aeaVyOnL37Z0AAQIbCBj4N0C/ueT0gXzTB/NNH9Rz7PFjEfGnZizx0ze1ZjzVUwgsEpDTRVyevJGAnG4E77KLBOR0EZcnEyBAgECGgIE/Q3FZjd8WET9y5lT/7Yj4jog4d6r/0ZvvEHj05mf/X162FM8mcFRAToWjBQE5baFL1iinMkCAAAECmwkY+Nel/9aI+AsR8eUnLvujEfG9M5Y1neo/e+t5DyLiXkRMXyzwIHCNgJxeo+e1awnI6VrSrnONgJxeo+e1BAgQIHC1gIH/asJZBX7rzan+x088+1cj4pMLT/XvlptO+E99yv+sxXrSsAJyOmzrm9q4nDbVrmEXK6fDtt7GCRAgsC8BA399P745Il6IiA+fuNSlp/qHSk4/I3i/fluu0JmAnHbW0E63I6edNrazbclpZw21HQIECLQsYOCv695vuTnVP/Wr9D4fEZ+68lT/vR28HhHPRMRrdVtSuUMBOe2wqR1uSU47bGqHW5LTDptqSwQIEGhdwMBf08Fviojp1P5DK53qP+9T+msa2XlVOe28wZ1sT047aWTn25DTzhtsewQIEGhVwMCf27nfeHOq/6dPlH0zIr7HqX4uvGqLBOR0EZcnbyQgpxvBu+wiATldxOXJBAgQILC2gIE/T/yP3Jzqf6VT/TxUldIF5DSdVMECATktQFUyXUBO00kVJECAAIFsAQN/nugPnfi2+n9886v2fuHM5T4aES9GxKMnnudn9fN6NmIlOR2x6+3tWU7b69mIK5bTEbtuzwQIEGhMwMCf17Bj//BnfgK/n9XP69eoleR01M63tW85batfo65WTkftfFv7PvWFqTV2Mv266OnXRnsQOCUgp4X5MPDn4R4K6qcjYvrzUw+n+nk9UOm8gJyeN/KM7QXkdPseWMF5ATk9b+QZ2wtsNUhNQ/7TEfH29gRW0ICAnBY2ycCfh3vJP/zTFwSePbOEOaf6D0XEO3lbUaljATntuLkdbU1OO2pmx1uR046b29HW1h6kpgF/GvSd6ncUohW2IqeFyAb+PNwl//BnnupP3yr1QkTc81XUvGZ2XElOO25uR1uT046a2fFW5LTj5na0tTUHKaf6HQVn5a3IaSG4gT8Pd+4//Fmn+g/ffMDfEzdbmG6y0/DvQeCUgJzKRwsCctpCl6xRTmWgBYE1Bimn+i0kYd9rlNPC/hj483DP/cOffar/UkRM38p/++GDUfL62WslOe21s33tS0776mevu5HTXjvb176qBymn+n3lZavdyGmhvIE/D/fUP/xVp/p3Vz99hXX61v4HedtSqTMBOe2soZ1uR047bWxn25LTzhra6XaqBimn+p0GZqNtyWkhvIE/D/dQUD8TER+JiEdPXOb1iHgmIl47s5Tp9P7Qqf7tl71yU+utvG2p1JmAnHbW0E63I6edNrazbclpZw3tdDsVg5RT/U7DsuG25LQQ38Cfh3tJUOd8Av/dn9U/tOLpE/qnT0S9n7cdlToVkNNOG9vZtuS0s4Z2uh057bSxnW3rkpweI3Cq31k4drQdOS1shoE/D3dJUJ3q57mrtExATpd5efY2AnK6jburLhOQ02Venr2NwJKcnlqhU/1t+jfKVeW0sNMG/jzcuUF1qp9nrtJyATldbuYV6wvI6frmrrhcQE6Xm3nF+gJzc3psZU711+/ZiFeU08KuG/jzcM8F1al+nrVKlwvI6eV2XrmegJyuZ+1KlwvI6eV2XrmewLmcnlqJU/31+jT6leS0MAEG/jzcU0F1qp/nrNJ1AnJ6nZ9XryMgp+s4u8p1AnJ6nZ9XryNwySDlVH+d3rjKFwXktDANBv483ENB/UJEPO4T+POQVbpaQE6vJlRgBQE5XQHZJa4WkNOrCRVYQWDpIOVUf4WmuMQHBOS0MBQG/jzcQ0H9dERMf37s4RP48/xVmicgp/OcPGtbATnd1t/V5wnI6Twnz9pWYO4g5VR/2z6NfnU5LUyAgT8Pd+k//E9GxEsR8dCJJbwSEc9ExFt5y1RpcAE5HTwAjWx/y5xOX6h9rhEny9xWQE639Xf1eQJzBimn+vMsPatOQE7rbMPAn4c79x9+p/p55iotF5DT5WZesb7AFjn9aES8GBGPRsT0BdnpDbAHgVMCciofLQicGqSc6rfQwTHWKKeFfTbw5+HO+YffqX6et0qXCcjpZW5eta7A2jmdTvWfvbXFBxFxLyKmN8MeBI4JyKlstCBwbJByqt9C98ZZ47U5nb5j+p1xuJbt1MC/zOvSr/Q71c9zVuk6gVNvUOX0OluvzhNYK6e3T/Xvrn56Mzx9kdaDwCUDf+b9VE5l8BqBQ/fTz0bEx64p6rUEkgWuyen0b/ULvlB/vCMG/ry0HnuD+qaf1c9DVulqATm9mlCBFQTWyOndU/1D23oqIu6vsF+XaFNATtvs22irnvOdKKOZ2O/+BC7J6d0vrPpC/ZG+GvjzAn8oqG9ExCMnLjF968nT3lDmNUGlswJyepbIE3YgUJnTU6el72399ZsPTH1tBxaWsF8BOd1vb6zsiwKXDFL8CKwtsDSnx35M2mfwHOicgT8vznM+XfL21XwCf569SvMF5HS+lWduJ1CV0zmn+s/7lP7tGt/YleW0sYYNutylg9SgTLa9scDcnJ77canps3emz+CZPovH40bAwJ8Xhbn/8DvVzzNXabmAnC4384r1BbJz6lR//R6OcEU5HaHL7e9x7iDV/k7toGWBOTn14ecXdtjAfyHcgZfN+YffqX6et0qXCcjpZW5eta5AZk6d6q/bu5GuJqcjdbvdvc4ZpNrdnZX3IrDWh/X24rVoHwb+RVwnn3zqH36n+nnOKl0nIKfX+Xn1OgIZOXWqv06vRr6KnI7c/Xb2buBvp1cjr3SND0Ed1tfAn9f6Y//wO9XPM1bpeoFrczqdlj53/TJUIHDRF1Dn3k+d6gvYGgIZ99NnzyzUZ0qs0cm+r2Hg77u/veyu8kNQezG6eB8G/ovpPvDCQ0F9NSIey7uESgSuFrg0p7dPS30C6tVtUOCMQEZOj13CJ/CLX5aAnGZJqlMpYOCv1FU7S2DOj0jdvtbcA4Cs9TVdx8Cf1z431DxLleoELsnp3dPS6ZNPp09AnT4J1YNAhUBGTg+ty2lpRbfGrSmn4/a+pZ1fktOW9metfQjMHfj9mPQF/TbwX4B25CVuqHmWKtUJLMnpqZ+BfjkippN+DwIVAlk5fW9tTvUruqSmnMpACwJLctrCfqyxT4E5A79T/Qt7b+C/EO7Ay9xQ8yxVqhOYm9M5PwP9VETcr1uqygMLZObUqf7AQSreupwWAyufIjA3pykXU4TAhQIZH4J64aX7f5mBP6/Hbqh5lirVCZzLqU82r7NXeb6AnM638sztBOR0O3tXni9wLqfzK3kmgTqBaz8EtW5lHVQ28Oc10Q01z1KlOoFTOZ1zqu+0tK43Kn9RQE6loQUBOW2hS9bo/akMtCBw6YegtrC3zddo4M9rgRtqnqVKdQKHcvqZiPhIRDx64rJ+BrquJyp/UEBOpaIFATltoUvW6P2pDLQgIKeFXTLw5+EKap6lSnUCcz4U5e7VnerX9UPlwwJyKhktCMhpC12yRu9PZaAFATkt7JKBPw9XUPMsVaoTWPIG1al+XR9UPi0gpxLSgoCcttAla/T+VAZaEJDTwi4Z+PNwBTXPUqU6gblvUJ3q1/VA5fMCcnreyDO2F5DT7XtgBecFvD89b+QZ2wvIaWEPDPx5uIKaZ6lSncC5N6hO9evsVZ4vIKfzrTxzOwE53c7elecLeH8638oztxOQ00J7A38erqDmWapUJ3DqDapT/Tp3lZcJyOkyL8/eRuDanD4UEe9ss3RXHUjA+9OBmt3wVuW0sHkG/jxcQc2zVKlO4FBOvxARj0fEa3WXVZnAIgE5XcTlyRsJXJPTJyPihYi4FxFvb7R+lx1DwPvTMfrc+i7ltLCDBv48XEHNs1SpTkBO62xVzhOQ0zxLleoELsnpwxHxYkQ8cbOslyNiGv49CFQJXJLTqrWoS+CYgJwWZsPAn4crqHmWKtUJyGmdrcp5AnKaZ6lSncDSnE6D/UsRMX0r/+3H9OfT4O9BoEJgaU4r1qAmgXMCcnpO6Iq/N/BfgXfnpYKaZ6lSnYCc1tmqnCcgp3mWKtUJzM3p3VP9uyuavqV/+tb+B3VLVXlggbk5HZjI1ncgIKeFTTDw5+EKap6lSnUCclpnq3KegJzmWapUJzAnp8dO9W+v6pWIeCYi3qpbqsoDC8zJ6cA8tr4TATktbISBPw9XUPMsVaoTkNM6W5XzBOQ0z1KlOoFTOT13qj+tavqE/qcj4n7dElUmEO6nQtCCgJwWdsnAn4crqHmWKtUJyGmdrcp5AnKaZ6lSncCxnL555Gf1b6/EqX5dX1R+v4D7qUS0ICCnhV0y8OfhCmqepUp1AnJaZ6tynoCc5lmqVCdwKKdvRMQjJy7pVL+uHyofFnA/lYwWBOS0sEsG/jxcQc2zVKlOQE7rbFXOE5DTPEuV6gQO5fTU1Zzq1/VC5eMC7qfS0YKAnBZ2ycCfhyuoeZYq1QnIaZ2tynkCcppnqVKdwNyB36l+XQ9UPi/gfnreyDO2F5DTwh4Y+PNwBTXPUqU6ATmts1U5T0BO8yxVqhOYM/A71a/zV3megPvpPCfP2lZATgv9Dfx5uIKaZ6lSnYCc1tmqnCcgp3mWKtUJnBr4nerXuau8TMD9dJmXZ28jIKeF7gb+PFxBzbNUqU5ATutsVc4TkNM8S5XqBI4N/E7168xVXi7gfrrczCvWF5DTQnMDfx6uoOZZqlQnIKd1tirnCchpnqVKdQKHcvpqRDxWd0mVCSwWcD9dTOYFGwjIaSG6gT8PV1DzLFWqE5DTOluV8wTkNM9SpToBOa2zVTlPQE7zLFWqE5DTOtsw8OfhCmqepUp1AnJaZ6tynoCc5lmqVCcgp3W2KucJyGmepUp1AnJaZ2vgT7QV1ERMpcoE5LSMVuFEATlNxFSqTEBOy2gVThSQ00RMpcoE5LSMNgz8ibaCmoipVJmAnJbRKpwoIKeJmEqVCchpGa3CiQJymoipVJmAnJbRGvgzaQU1U1OtKgE5rZJVN1NATjM11aoSkNMqWXUzBeQ0U1OtKgE5rZINA38mraBmaqpVJSCnVbLqZgrIaaamWlUCclolq26mgJxmaqpVJSCnVbIG/lRZQU3lVKxIQE6LYJVNFZDTVE7FigTktAhW2VQBOU3lVKxIQE6LYKeyPqU/D1dQ8yxVqhOQ0zpblfME5DTPUqU6ATmts1U5T0BO8yxVqhOQ0zpbA3+iraAmYipVJiCnZbQKJwrIaSKmUmUCclpGq3CigJwmYipVJiCnZbRO+DNpBTVTU60qATmtklU3U0BOMzXVqhKQ0ypZdTMF5DRTU60qATmtkvUt/amygprKqViRgJwWwSqbKiCnqZyKFQnIaRGssqkCcprKqViRgJwWwU5l/Qx/Hq6g5lmqVCcgp3W2KucJyGmepUp1AnJaZ6tynoCc5lmqVCcgp3W2Bv5EW0FNxFSqTEBOy2gVThSQ00RMpcoE5LSMVuFEATlNxFSqTEBOy2id8GfSCmqmplpVAnJaJatupoCcZmqqVSUgp1Wy6mYKyGmmplpVAnJaJetb+lNlBTWVU7EiATktglU2VUBOUzkVKxKQ0yJYZVMF5DSVU7EiATktgp3K+hn+PFxBzbNUqU5ATutsVc4TkNM8S5XqBOS0zlblPAE5zbNUqU5ATutsDfyJtoKaiKlUmYCcltEqnCggp4mYSpUJyGkZrcKJAnKaiKlUmYCcltE64c+kFdRMTbWqBOS0SlbdTAE5zdRUq0pATqtk1c0UkNNMTbWqBOS0Sta39KfKCmoqp2JFAnJaBKtsqoCcpnIqViQgp0WwyqYKyGkqp2JFAnJaBDuV9TP8ebiCmmepUp2AnNbZqpwnIKd5lirVCchpna3KeQJymmepUp2AnNbZGvgTbQU1EVOpMgE5LaNVOFFAThMxlSoTkNMyWoUTBeQ0EVOpMgE5LaN1wp9JK6iZmmpVCchplay6mQJymqmpVpWAnFbJqpspIKeZmmpVCchplaxv6U+VFdRUTsWKBOS0CFbZVAE5TeVUrEhATotglU0VkNNUTsWKBOS0CHYq62f483AFNc9SpToBOa2zVTlPQE7zLFWqE5DTOluV8wTkNM9SpToBOa2zNfAn2gpqIqZSZQJyWkarcKKAnCZiKlUmIKdltAonCshpIqZSZQJyWkbrhD+TVlAzNdWqEpDTKll1MwXkNFNTrSoBOa2SVTdTQE4zNdWqEpDTKlnf0p8qK6ipnIoVCchpEayyqQJymsqpWJGAnBbBKpsqIKepnIoVCchpEexU1s/w5+EKap6lSnUCclpnq3KegJzmWapUJyCndbYq5wnIaZ6lSnUCclpna+BPtBXUREylygTktIxW4UQBOU3EVKpMQE7LaBVOFJDTREylygTktIzWCX8mraBmaqpVJSCnVbLqZgrIaaamWlUCclolq26mgJxmaqpVJSCnVbK+pT9VVlBTORUrEpDTIlhlUwXkNJVTsSIBOS2CVTZVQE5TORUrEpDTItiprJ/hz8MV1DxLleoE5LTOVuU8ATnNs1SpTkBO62xVzhOQ0zxLleoE5LTO1sCfaCuoiZhKlQnIaRmtwokCcpqIqVSZgJyW0SqcKCCniZhKlQnIaRmtE/5MWkHN1FSrSkBOq2TVzRSQ00xNtaoE5LRKVt1MATnN1FSrSkBOq2R9S3+qrKCmcipWJCCnRbDKpgrIaSqnYkUCcloEq2yqgJymcipWJCCnRbBTWT/Dn4crqHmWKtUJyGmdrcp5AnKaZ6lSnYCc1tmqnCcgp3mWKtUJyGmdrYE/0VZQEzGVKhOQ0zJahRMF5DQRU6kyATkto1U4UUBOEzGVKhOQ0zJaJ/yZtIKaqalWlYCcVsmqmykgp5maalUJyGmVrLqZAnKaqalWlYCcVsn6lv5UWUFN5VSsSEBOi2CVTRWQ01ROxYoE5LQIVtlUATlN5VSsSEBOi2Cnsn6GPw9XUPMsVaoTkNM6W5XzBOQ0z1KlOgE5rbNVOU9ATvMsVaoTkNM6WwN/oq2gJmIqVSYgp2W0CicKyGkiplJlAnJaRqtwooCcJmIqVSYgp2W0TvgzaQU1U1OtKgE5rZJVN1NATjM11aoSkNMqWXUzBeQ0U1OtKgE5rZL1Lf2psoKayqlYkYCcFsEqmyogp6mcihUJyGkRrLKpAnKayqlYkYCcFsFOZf0Mfx6uoOZZqlQnIKd1tirnCchpnqVKdQJyWmercp6AnOZZqlQnIKd1tgb+QlulCRAgQIAAAQIECBAgQIDAZgJO+Dejd2ECBAgQIECAAAECBAgQIFAnYOCvs1WZAAECBAgQIECAAAECBAhsJmDg34zehQkQIECAAAECBAgQIECAQJ2Agb/OVmUCBAgQIECAAAECBAgQILCZgIF/M3oXJkCAAAECBAgQIECAAAECdQIG/jpblQkQIECAAAECBAgQIECAwGYCBv7N6F2YAAECBAgQIECAAAECBAjUCRj462xVJkCAAAECBAgQIECAAAECmwkY+Dejd2ECBAgQIECAAAECBAgQIFAnYOCvs1WZAAECBAgQIECAAAECBAhsJmDg34zehQkQIECAAAECBAgQIECAQJ2Agb/OVmUCBAgQIECAAAECBAgQILCZgIF/M3oXJkCAAAECBAgQIECAAAECdQIG/jpblQkQIECAAAECBAgQIECAwGYCBv7N6F2YAAECBAgQIECAAAECBAjUCRj462xVJkCAAAECBAgQIECAAAECmwkY+Dejd2ECBAgQIECAAAECBAgQIFAnYOCvs1WZAAECBAgQIECAAAECBAhsJmDg34zehQkQIECAAAECBAgQIECAQJ2Agb/OVmUCBAgQIECAAAECBAgQILCZgIF/M3oXJkCAAAECBAgQIECAAAECdQIG/jpblQkQIECAAAECBAgQIECAwGYCBv7N6F2YAAECBAgQIECAAAECBAjUCRj462xVJkCAAAECBAgQIECAAAECmwkY+Dejd2ECBAgQIECAAAECBAgQIFAnYOCvs1WZAAECBAgQIECAAAECBAhsJmDg34zehQkQIECAAAECBAgQIECAQJ2Agb/OVmUCBAgQIECAAAECBAgQILCZgIF/M3oXJkCAAAECBAgQIECAAAECdQIG/jpblQkQIECAAAECBAgQIECAwGYCBv7N6F2YAAECBAgQIECAAAECBAjUCRj462xVJkCAAAECBAgQIECAAAECmwkY+Dejd2ECBAgQIECAAAECBAgQIFAnYOCvs1WZAAECBAgQIECAAAECBAhsJmDg34zehQkQIECAAAECBAgQIECAQJ2Agb/OVmUCBAgQIECAAAECBAgQILCZgIF/M3oXJkCAAAECBAgQIECAAAECdQIG/jpblQkQIECAAAECBAgQIECAwGYCBv7N6F2YAAECBAgQIECAAAECBAjUCRj462xVJkCAAAECBAgQIECAAAECmwkY+Dejd2ECBAgQIECAAAECBAgQIFAnYOCvs1WZAAECBAgQIECAAAECBAhsJmDg34zehQkQIECAAAECBAgQIECAQJ2Agb/OVmUCBAgQIECAAAECBAgQILCZgIF/M3oXJkCAAAECBAgQIECAAAECdQIG/jpblQkQIECAAAECBAgQIECAwGYCBv7N6F2YAAECBAgQIECAAAECBAjUCRj462xVJkCAAAECBAgQIECAAAECmwkY+Dejd2ECBAgQIECAAAECBAgQIFAnYOCvs1WZAAECBAgQIECAAAECBAhsJmDg34zehQkQIECAAAECBAgQIECAQJ2Agb/OVmUCBAgQIECAAAECBAgQILCZgIF/M3oXJkCAAAECBAgQIECAAAECdQIG/jpblQkQIECAAAECBAgQIECAwGYCBv7N6F2YAAECBAgQIECAAAECBAjUCRj462xVJkCAAAECBAgQIECAAAECmwkY+Dejd2ECBAgQIECAAAECBAgQIFAnYOCvs1WZAAECBAgQIECAAAECBAhsJmDg34zehQkQIECAAAECBAgQIECAQJ2Agb/OVmUCBAgQIECAAAECBAgQILCZgIF/M3oXJkCAAAECBAgQIECAAAECdQIG/jpblQkQIECAAAECBAgQIECAwGYCBv7N6F2YAAECBAgQIECAAAECBAjUCRj462xVJkCAAAECBAgQIECAAAECmwkY+Dejd2ECBAgQIECAAAECBAgQIFAnYOCvs1WZAAECBAgQIECAAAECBAhsJmDg34zehQkQIECAAAECBAgQIECAQJ2Agb/OVmUCBAgQIECAAAECBAgQILCZgIF/M3oXJkCAAAECBAgQIECAAAECdQIG/jpblQkQIECAAAECBAgQIECAwGYCBv7N6F2YAAECBAgQIECAAAECBAjUCRj462xVJkCAAAECBAgQIECAAAECmwkY+Dejd2ECBAgQIECAAAECBAgQIFAnYODPs/2hiHgur9ziSk9GxMuLX+UFownI6Wgdb3O/ctpm30ZbtZyO1vE29yunbfZttFXLaWHHDfx5uFsFdRryn46It/O2olLHAnLacXM72pqcdtTMjrcipx03t6OtyWlHzex4K3Ja2FwDfx7u2kGdBvxp0Heqn9fDESrJ6Qhdbn+Pctp+D0fYgZyO0OX29yin7fdwhB3IaWGXDfx5uGsG1al+Xt9GqySno3W8zf3KaZt9G23Vcjpax9vcr5y22bfRVi2nhR038OfhrhFUp/p5/Rq1kpyO2vm29i2nbfVr1NXK6aidb2vfctpWv0ZdrZwWdt7An4dbHVSn+nm9GrmSnI7c/Xb2Lqft9GrklcrpyN1vZ+9y2k6vRl6pnBZ238Cfh1sVVKf6eT1SKUJOpaAFATltoUvWKKcy0IKAnLbQJWuU08IMGPjzcCuCOvdU/6GIeCdvKyp1LCCnHTe3o63JaUfN7Hgrctpxczvampx21MyOtyKnhc018OfhZgZ1yan+kxHxQkTc86v58prZcSU57bi5HW1NTjtqZsdbkdOOm9vR1uS0o2Z2vBU5LWyugT8PNyuoc0/1H46IFyPiiZstTK+bhn8PAqcE5IHUw4AAACAASURBVFQ+WhCQ0xa6ZI1yKgMtCMhpC12yRjktzICBPw/32qAuPdV/KSKmb+W//ZgG/mnw9yBwTEBOZaMFATltoUvWKKcy0IKAnLbQJWuU08IMGPjzcK8J6qWn+ndXP33RYPrW/gd521KpMwE57ayhnW5HTjttbGfbktPOGtrpduS008Z2ti05LWyogT8P95KgZpzq397BKxHxTES8lbctlToTkNPOGtrpduS008Z2ti057ayhnW5HTjttbGfbktPChhr483CXBjXrVH/awfQJ/U9HxP287ajUqYCcdtrYzrYlp501tNPtyGmnje1sW3LaWUM73Y6cFjbWwJ+HOzeoTvXzzFVaLiCny828Yn0BOV3f3BWXC8jpcjOvWF9ATtc3d8XlAnK63Gz2Kwz8s6nOPnFOUJ3qn2X0hGIBOS0GVj5FQE5TGBUpFpDTYmDlUwTkNIVRkWIBOS0ENvDn4Z4KqlP9PGeVrhOQ0+v8vHodATldx9lVrhOQ0+v8vHodATldx9lVrhOQ0+v8Tr7awJ+HeyyoTvXzjFW6XkBOrzdUoV5ATuuNXeF6ATm93lCFegE5rTd2hesF5PR6w6MVDPx5uIeC+tmI+NiMSzwZES9FxEMnnusT+GdAespZATk9S+QJOxCQ0x00wRLOCsjpWSJP2IGAnO6gCZZwVkBOzxJd/gQD/+V2d195KKifjojpz489Ho6IFyPiiRPP8Qn8eT1S6d08PncHQk4lY28Ccrq3jljPIQE5lYsWBOS0hS5Zo5wWZsDAn4e7NKhO9fPsVZovIKfzrTxzO4Etczp9AezuF8W2k3DlPQvI6Z67Y23vCcipLLQgIKeFXTLw5+HODapT/TxzlZYLyOlyM69YX2CLnH705juuHo2I6Quy0+eveBA4JSCn8tGCgJy20CVrlNPCDBj483DnBNWpfp63SpcJyOllbl61rsDaOZ1O9Z+9tcUHEXEvIqbfsOJB4JiAnMpGCwJy2kKXrFFOCzNg4M/DPRVUp/p5zipdJyCn1/l59ToCa+X09qn+3Z1NJ/zTF2k9CFwy8Gf+uy+nMniNgPvpNXpeu5aAnBZKG/jzcI8F9U2fwJ+HrNLVAnJ6NaECKwiskdO7p/qHtvVURNxfYb8u0aaAnLbZt9FWLaejdbzN/cppYd8M/Hm4h4L6RkQ8cuISPoE/z1+leQJyOs/Js7YVqMzpqdPS93b9ekQ8ExGvbcvg6jsXkNOdN8jyfl1ATgWhBQE5LeySgT8P91BQT1V/5eYN5Vt5S1CJwFkBOT1L5Ak7EKjK6ZxT/ed9Sv8OEtDGEuS0jT6Nvko5HT0BbexfTgv7ZODPw50bVKf6eeYqLReQ0+VmXrG+QHZOneqv38MRriinI3S5/T3Kafs9HGEHclrYZQN/Hu6coDrVz/NW6TIBOb3MzavWFcjMqVP9dXs30tXkdKRut7tXOW23dyOtXE4Lu23gz8M9FVSn+nnOKl0nIKfX+Xn1OgIZOXWqv06vRr6KnI7c/Xb2Lqft9GrklcppYfcN/Hm4x4LqVD/PWKXrBa7N6XRa+tz1y1CBwEmBjJw+e8bYz+oL4bUCcnqtoNevISCnayi7xrUCcnqt4InXG/jzcA8F9dWIeCzvEioRuFrg0pzePi2dfjf59DvKPQhUCWTk9NjafAJ/VdfGqyun4/W8xR3LaYtdG2/NclrYcwN/Hu6hoE6nodOfexDYi8AlOb37M9APIuJeRLy9l01ZR3cCGTk9hOJUv7uobLohOd2U38VnCmyZ04ciYvqxVg8C5wTk9JzQFX9v4L8C785LLwlq3tVVIjBPYElOT/0M9HTCP530exCoEMjK6Xtrc6pf0SU15VQGWhDYKqfTe4QXHBC0EJFdrFFOC9tg4M/DXRLUvKuqRGCZwNyczvlk86ci4v6yy3s2gVkCmTl1qj+L3JMuEJDTC9C8ZHWBtXP6cES8GBFP3OzUAcHqLW/ygnJa2DYDfx7u3KDmXVElAssFzuXUJ5svN/WKfAE5zTdVMV9ATvNNVcwXWDOn06n+SxExfSv/7YfP/snva28V5bSwowb+PNxzQc27kkoELhc4ldM5p/pOSy+398r5AnI638oztxOQ0+3sXXm+wBo5vXuqf3d102f+TJ/9M30GkAeBQwJyWpgLA38eroE/z1KlOoFDOf1MRHwkIh49cVk/A13XE5U/KCCnUtGCgJy20CVrrM7psVP92/J+RbUcnhOQ03NCV/y9gf8KvDsvNfDnWapUJ3Aop+eu5lT/nJC/zxaQ02xR9SoE5LRCVc1sgaqcnjvVn/YxfUL/0z7vJ7ulXdaT08K2GvjzcA38eZYq1QksuaE61a/rg8qnBeRUQloQkNMWumSNFTl1qi9X2QJymi16q56BPw/XwJ9nqVKdwNwbqlP9uh6ofF5ATs8becb2AnK6fQ+s4LxAZk6d6p/39ozLBOT0MrdZrzLwz2Ka9SQD/ywmT9pY4NwN1an+xg1y+V8XkFNBaEFATlvokjVm5dSpvixVCshpoa6BPw/XwJ9nqVKdwKkbqlP9OneVlwnI6TIvz95G4NqcTr+6bPoZZw8ClQLX5tSpfmV31H5PQE4Ls2Dgz8M18OdZqlQncCinX4iIxyPitbrLqkxgkYCcLuLy5I0ErsnpdFr6ws2vKpt+ZZkHgSqBa3P6UkRMX5w69vAJ/FWdG6uunBb228Cfh2vgz7NUqU5ATutsVc4TkNM8S5XqBC7J6d3T0pcjYhr+PQhUCWTk9NDafAJ/VcfGrCunhX038OfhXhLUvKurRGCegJzOc/KsbQXkdFt/V58nsDSnx34GevrzafD3IFAhkJXT22tzql/RqbFrymlh/w38ebhLg5p3ZZUIzBeQ0/lWnrmdgJxuZ+/K8wXm5vTcz0BP39J/LyIezL+0ZxKYLZCV0+mCTvVns3viQgE5XQi25OkG/iVap587N6h5V1SJwHIBOV1u5hXrC8jp+uauuFxgTk59svlyV6/IFZDTXE/VagTktMb116sa+PNw5wQ172oqEbhMQE4vc/OqdQXkdF1vV7tM4FROz53qT1d0WnqZu1ctE5DTZV6evY2AnBa6G/jzcL1BzbNUqU5ATutsVc4TkNM8S5XqBI7l9M2I8Mnmde4qLxOQ02Venr2NgJwWuhv483C9Qc2zVKlOQE7rbFXOE5DTPEuV6gQO5fSNiHjkxCWd6tf1Q+XDAnIqGS0IyGlhlwz8ebjeoOZZqlQnIKd1tirnCchpnqVKdQKHcnrqaj7ZvK4XKh8XkFPpaEFATgu7ZODPw/UGNc9SpToBOa2zVTlPQE7zLFWqE5j7BtWpfl0PVD4vIKfnjTxjewE5LeyBgT8P1xvUPEuV6gTktM5W5TwBOc2zVKlOYM4bVKf6df4qzxOQ03lOnrWtgJwW+hv483C9Qc2zVKlOQE7rbFXOE5DTPEuV6gROvUF1ql/nrvIyATld5uXZ2wjIaaG7gT8P1xvUPEuV6gTktM5W5TwBOc2zVKlO4NgbVKf6deYqLxeQ0+VmXrG+wLU5/XREPLf+stu4ooE/r0/eoOZZqlQnIKd1tirnCchpnqVKdQKHcvpqRDxWd0mVCSwWkNPFZF6wgcClOf1oRLwYEY9GxJMR8fIGa9/9JQ38eS3yBjXPUqU6ATmts1U5T0BO8yxVqhOQ0zpblfME5DTPUqU6gUtyOp3qP3trSQ8i4l5EvF23zDYrG/jz+nZJUPOurhKBeQJyOs/Js7YVkNNt/V19noCcznPyrG0F5HRbf1efJ7Akp7dP9e9Wn074p5N+j1sCBv68OCwJat5VVSKwTEBOl3l59jYCcrqNu6suE5DTZV6evY2AnG7j7qrLBObm9O6p/qGrPBUR95ddvu9nG/jz+js3qHlXVInAcgE5XW7mFesLyOn65q64XEBOl5t5xfoCcrq+uSsuFziX01On+u9d7fWIeCYiXlt++b5fYeDP6++5oOZdSSUClwvI6eV2XrmegJyuZ+1KlwvI6eV2XrmegJyuZ+1KlwucyumcU/3nfUr/cXwD/+XBvPtKN9Q8S5XqBOS0zlblPAE5zbNUqU5ATutsVc4TkNM8S5XqBA7l9DMR8ZGbT+A/dmWn+jN6YuCfgTTzKW6oM6E8bVMBOd2U38VnCsjpTChP21RATjfld/GZAnI6E8rTNhU4lNNzC3Kqf07o5u8N/DOhZjzNDXUGkqdsLiCnm7fAAmYIyOkMJE/ZXEBON2+BBcwQkNMZSJ6yucCSgd+p/sJ2GfgXgp14uhtqnqVKdQJyWmercp6AnOZZqlQnIKd1tirnCchpnqVKdQJzB36n+hf0wMB/AdqRl7ih5lmqVCcgp3W2KucJyGmepUp1AnJaZ6tynoCc5lmqVCdwbuB3qn+FvYH/Crw7L3VDzbNUqU5ATutsVc4TkNM8S5XqBOS0zlblPAE5zbNUqU7g1MDvVP9KdwP/lYC3Xu6GmmepUp2AnNbZqpwnIKd5lirVCchpna3KeQJymmepUp3AoZx+ISIej4jX6i47RmUDf16f3VDzLFWqE5DTOluV8wTkNM9SpToBOa2zVTlPQE7zLFWqE5DTOtsw8OfhCmqepUp1AnJaZ6tynoCc5lmqVCcgp3W2KucJyGmepUp1AnJaZ2vgT7QV1ERMpcoE5LSMVuFEATlNxFSqTEBOy2gVThSQ00RMpcoE5LSMNgz8ibaCmoipVJmAnJbRKpwoIKeJmEqVCchpGa3CiQJymoipVJmAnJbRGvgzaQU1U1OtKgE5rZJVN1NATjM11aoSkNMqWXUzBeQ0U1OtKgE5rZINA38mraBmaqpVJSCnVbLqZgrIaaamWlUCclolq26mgJxmaqpVJSCnVbIG/lRZQU3lVKxIQE6LYJVNFZDTVE7FigTktAhW2VQBOU3lVKxIQE6LYKeyPqU/D1dQ8yxVqhOQ0zpblfME5DTPUqU6ATmts1U5T0BO8yxVqhOQ0zpbA3+iraAmYipVJiCnZbQKJwrIaSKmUmUCclpGq3CigJwmYipVJiCnZbRO+DNpBTVTU60qATmtklU3U0BOMzXVqhKQ0ypZdTMF5DRTU60qATmtkvUt/amygprKqViRgJwWwSqbKiCnqZyKFQnIaRGssqkCcprKqViRgJwWwU5l/Qx/Hq6g5lmqVCcgp3W2KucJyGmepUp1AnJaZ6tynoCc5lmqVCcgp3W2Bv5EW0FNxFSqTEBOy2gVThSQ00RMpcoE5LSMVuFEATlNxFSqTEBOy2id8GfSCmqmplpVAnJaJatupoCcZmqqVSUgp1Wy6mYKyGmmplpVAnJaJetb+lNlBTWVU7EiATktglU2VUBOUzkVKxKQ0yJYZVMF5DSVU7EiATktgp3K+hn+PFxBzbNUqU5ATutsVc4TkNM8S5XqBOS0zlblPAE5zbNUqU5ATutsDfyJtoKaiKlUmYCcltEqnCggp4mYSpUJyGkZrcKJAnKaiKlUmYCcltE64c+kFdRMTbWqBOS0SlbdTAE5zdRUq0pATqtk1c0UkNNMTbWqBOS0Sta39KfKCmoqp2JFAnJaBKtsqoCcpnIqViQgp0WwyqYKyGkqp2JFAnJaBDuV9TP8ebiCmmepUp2AnNbZqpwnIKd5lirVCchpna3KeQJymmepUp2AnNbZGvgTbQU1EVOpMgE5LaNVOFFAThMxlSoTkNMyWoUTBeQ0EVOpMgE5LaN1wp9JK6iZmmpVCchplay6mQJymqmpVpWAnFbJqpspIKeZmmpVCchplaxv6U+VFdRUTsWKBOS0CFbZVAE5TeVUrEhATotglU0VkNNUTsWKBOS0CHYq62f483AFNc9SpToBOa2zVTlPQE7zLFWqE5DTOluV8wTkNM9SpToBOa2zNfAn2gpqIqZSZQJyWkarcKKAnCZiKlUmIKdltAonCshpIqZSZQJyWkbrhD+TVlAzNdWqEpDTKll1MwXkNFNTrSoBOa2SVTdTQE4zNdWqEpDTKlnf0p8qK6ipnIoVCchpEayyqQJymsqpWJGAnBbBKpsqIKepnIoVCchpEexU1s/wF+IqTYAAAQIECBAgQIAAAQIEthIw8G8l77oECBAgQIAAAQIECBAgQKBQwMBfiKs0AQIECBAgQIAAAQIECBDYSsDAv5W86xIgQIAAAQIECBAgQIAAgUIBA38hrtIECBAgQIAAAQIECBAgQGArAQP/VvKuS4AAAQIECBAgQIAAAQIECgUM/IW4ShMgQIAAAQIECBAgQIAAga0EDPxbybsuAQIECBAgQIAAAQIECBAoFDDwF+IqTYAAAQIECBAgQIAAAQIEthIw8G8l77oECBAgQIAAAQIECBAgQKBQwMBfiKs0AQIECBAgQIAAAQIECBDYSsDAv5W86xIgQIAAAQIECBAgQIAAgUIBA38hrtIECBAgQIAAAQIECBAgQGArAQP/VvKuS4AAAQIECBAgQIAAAQIECgUM/IW4ShMgQIAAAQIECBAgQIAAga0EDPxbybsuAQIECBAgQIAAAQIECBAoFDDwF+IqTYAAAQIECBAgQIAAAQIEthIw8G8l77oECBAgQIAAAQIECBAgQKBQwMBfiKs0AQIECBAgQIAAAQIECBDYSsDAv5W86xIgQIAAAQIECBAgQIAAgUIBA38hrtIECBAgQIAAAQIECBAgQGArAQP/VvKuS4AAAQIECBAgQIAAAQIECgUM/IW4ShMgQIAAAQIECBAgQIAAga0EDPxbybsuAQIECBAgQIAAAQIECBAoFDDwF+IqTYAAAQIECBAgQIAAAQIEthIw8G8l77oECBAgQIAAAQIECBAgQKBQwMBfiKs0AQIECBAgQIAAAQIECBDYSsDAv5W86xIgQIAAAQIECBAgQIAAgUIBA38hrtIECBAgQIAAAQIECBAgQGArAQP/VvKuS4AAAQIECBAgQIAAAQIECgUM/IW4ShMgQIAAAQIECBAgQIAAga0EDPxbybsuAQIECBAgQIAAAQIECBAoFDDwF+IqTYAAAQIECBAgQIAAAQIEthIw8G8l77oECBAgQIAAAQIECBAgQKBQwMBfiKs0AQIECBAgQIAAAQIECBDYSsDAv5W86xIgQIAAAQIECBAgQIAAgUIBA38hrtIECBAgQIAAAQIECBAgQGArAQP/VvKuS4AAAQIECBAgQIAAAQIECgUM/IW4ShMgQIAAAQIECBAgQIAAga0EDPxbybsuAQIECBAgQIAAAQIECBAoFDDwF+IqTYAAAQIECBAgQIAAAQIEthIw8G8l77oECBAgQIAAAQIECBAgQKBQwMBfiKs0AQIECBAgQIAAAQIECBDYSsDAv5W86xIgQIAAAQIECBAgQIAAgUIBA38hrtIECBAgQIAAAQIECBAgQGArAQP/VvKuS4AAAQIECBAgQIAAAQIECgUM/IW4ShMgQIAAAQIECBAgQIAAga0EDPxbybsuAQIECBAgQIAAAQIECBAoFDDwF+IqTYAAAQIECBAgQIAAAQIEthIw8G8l77oECBAgQIAAAQIECBAgQKBQwMBfiKs0AQIECBAgQIAAAQIECBDYSsDAv5W86xIgQIAAAQIECBAgQIAAgUIBA38hrtIECBAgQIAAAQIECBAgQGArAQP/VvKuS4AAAQIECBAgQIAAAQIECgUM/IW4ShMgQIAAAQIECBAgQIAAga0EDPxbybsuAQIECBAgQIAAAQIECBAoFDDwF+IqTYAAAQIECBAgQIAAAQIEthIw8G8l77oECBAgQIAAAQIECBAgQKBQwMBfiKs0AQIECBAgQIAAAQIECBDYSsDAv5W86xIgQIAAAQIECBAgQIAAgUIBA38hrtIECBAgQIAAAQIECBAgQGArAQP/VvKuS4AAAQIECBAgQIAAAQIECgUM/IW4ShMgQIAAAQIECBAgQIAAga0EDPxbybsuAQIECBAgQIAAAQIECBAoFDDwF+IqTYAAAQIECBAgQIAAAQIEthIw8G8l77oECBAgQIAAAQIECBAgQKBQwMBfiKs0AQIECBAgQIAAAQIECBDYSsDAv5W86xIgQIAAAQIECBAgQIAAgUIBA38hrtIECBAgQIAAAQIECBAgQGArAQP/VvKuS4AAAQIECBAgQIAAAQIECgUM/IW4ShMgQIAAAQIECBAgQIAAga0EDPxbybsuAQIECBAgQIAAAQIECBAoFDDwF+IqTYAAAQIECBAgQIAAAQIEthIw8G8l77oECBAgQIAAAQIECBAgQKBQwMCfh/tDEfFcXrnFlZ6MiJcXv8oLRhOQ09E63uZ+5bTNvlk1AQIECBAgsDMBA39eQ7Z6gzoN+U9HxNt5W1GpYwE57bi5HW1NTjtqpq0QIECAAAEC2wkY+PPs136DOg3406DvVD+vhyNUktMRutz+HuW0/R7aAQECBAgQILADAQN/XhPWfIPqVD+vb6NVktPROt7mfuW0zb5ZNQECBAgQILAzAQN/XkPWeIPqVD+vX6NWktNRO9/WvuW0rX5ZLQECBAgQILBTAQN/XmOq36A61c/r1ciV5HTk7rezdzltp1dWSoAAAQIECOxYwMCf15yqN6hO9fN6pFKEnEpBCwJy2kKXrJEAAQIECBDYvYCBP69FFW9Q557qPxQR7+RtRaWOBeS04+Z2tLUtc9oRo60QIECAAAECowsY+PMSkPkGdcmp/pMR8UJE3POr+fKa2XElOe24uR1tbaucdkRoKwQIECBAgACBCAN/Xgqy3qDOPdV/OCJejIgnbrYwvW4a/j0InBKQU/loQWDtnLZgYo0ECBAgQIAAgcUCBv7FZEdfcO0b1KWn+i9FxPSt/Lcf08A/Df4eBI4JyKlstCCwZk5b8LBGAgQIECBAgMBFAgb+i9gOvuiaN6iXnurfXcj0RYPpW/sf5G1Lpc4E5LSzhna6nTVy2imdbREgQIAAAQIEvihg4M9LwyVvUDNO9W/v4JWIeCYi3srblkqdCchpZw3tdDvVOe2UzbYIECBAgAABAu8XMPDnJWLpG9SsU/1pB9Mn9D8dEffztqNSpwJy2mljO9tWVU47Y7IdAgQIECBAgMBpAQN/XkLmvkF1qp9nrtJyATldbuYV6wtU5HT9XbgiAQIECBAgQGBjAQN/XgPmvEF1qp/nrdJlAnJ6mZtXrSuQmdN1V+5qBAgQIECAAIEdCRj485px6g2qU/08Z5WuE5DT6/y8eh2BrJyus1pXIUCAAAECBAjsVMDAn9eYY29QnernGat0vYCcXm+oQr3AtTmtX6ErECBAgAABAgQaEDDw5zXp0BvUz0bEx2Zc4smIeCkiHjrxXJ/APwPSU84KyOlZIk/YgcA1Od3B8i2BAAECBAgQILAPAQN/Xh8OvUH9dERMf37s8XBEvBgRT5x4jk/gz+uRSu/m8bk7EHIqGXsTuCSne9uD9RAgQIAAAQIENhcw8Oe1YOkb1MxT/WlguzvE5e1MpZ4E5LSnbva7l6U57VfCzggQIECAAAECVwgY+K/Au/PSuW9QM0/1P3rzHQKPRsT0BYTp8wI8CJwSkFP5aEFgbk5b2Is1EiBAgAABAgQ2EzDw59HPeYOafar/7K3lP4iIexEx/UYADwLHBORUNloQmJPTFvZhjQQIECBAgACBTQUM/Hn8p96gVp3q3139dMI/fVHBg8AlA7+cys1eBAz8e+mEdRAgQIAAAQJNCxj489p37A3qm4mfwD/9rP7tU/1Dq38qIu7nbUulzgTktLOGdrodA3+njbUtAgQIECBAYF0BA3+e96E3qG9ExCMnLjH3E/hv/6z+sXKvR8QzEfFa3pZU6lBATjtsaodbMvB32FRbIkCAAAECBNYXMPDnmR96g3qq+is3A/pbZ5Yw51T/eZ/Sn9fIzivJaecN7mR7Bv5OGmkbBAgQIECAwLYCBv48/7mDlFP9PHOVlgvI6XIzr1hfwMC/vrkrEiBAgAABAh0KGPjzmjpnkHKqn+et0mUCcnqZm1etK2DgX9fb1QgQIECAAIFOBQz8eY09NUg51c9zVuk6ATm9zs+r1xEw8K/j7CoECBAgQIBA5wIG/rwGHxuknOrnGat0vYCcXm+oQr3AnO9EqVzF9OtNp19z6kGAAAECBAgQaFrAwJ/XvkNvUF+NiMfOXMIn8Of1QKXzAnJ63sgzthfYauCfhvynI+Lt7QmsgAABAgQIECBwvYCB/3rD9ypc8i2oWZ/A/1BETD824EHgnICcnhPy93sQWHvgnwb8adB3qr+H7lsDAQIECBAgkCZg4E+jjCWDVOap/vStpy9ExD2nUnnN7LiSnHbc3I62tubA71S/o+DYCgECBAgQIPB+AQN/XiLmDlJZp/oPR8SLEfHEzRamN63T8O9B4JSAnMpHCwJrDPxO9VtIgjUSIECAAAECVwkY+K/ie9+Lzw1S2af6L0XE9K38tx8+aCqvn71WktNeO9vXvqoHfqf6feXFbggQIECAAIEjAgb+vGicGqSqTvXvrn46sZq+tf9B3rZU6kxATjtraKfbqRr4nep3GhjbIkCAAAECBA4LGPjzknHoDepnIuIjEfHoicu8HhHPRMRrZ5Yynd4fOtW//bK5vwIwb9cqtSYgp611bMz1Vgz8TvXHzJJdEyBAgACBoQUM/Hntv+QN6vMR8dyZJdz9Wf1DT58+oX/6hOn7edtRqVMBOe20sZ1t65KcHiNwqt9ZOGyHAAECBAgQmC9g4J9vde6ZS96gOtU/p+nvqwTktEpW3UyBJTk9dV2n+pldUYsAAQIECBBoTsDAn9eyuW9Qnernmau0XEBOl5t5xfoCc3N6bGVO9dfvmSsSIECAAAECOxQw8Oc15dwbVKf6edYqXS4gp5fbeeV6AudyemolTvXX65MrESBAgAABAjsXMPDnNejUG1Sn+nnOKl0nIKfX+Xn1OgKXDPxO9dfpjasQIECAAAECDQkY+POadegN6hci4nGfwJ+HrNLVAnJ6NaECKwgsHfid6q/QFJcgQIAAAQIE2hMw8Of17NTvoXM8pgAAC3NJREFUNz92FZ/An+ev0jwBOZ3n5FnbCswd+J3qb9snVydAgAABAgR2LmDgz2vQ0kHqyYh4KSIeOrGEVyLimYh468wyPz3j1/vl7VSllgXktOXujbP2OQO/U/1x8mCnBAgQIECAwIUCBv4L4Q68bO4glXmq/9GIeDEiHo2I6QsI0xtgDwKnBORUPloQODXwO9VvoYPWSIAAAQIECOxCwMCf14Y5g1T2qf6zt5b/ICLuRcT0ZtiDwDEBOZWNFgSODfxO9VvonjUSIECAAAECuxEw8Oe14tQgVXWqf3f105vh6YsKHgQuGfjlVG72InDofvrZiPjYXhZoHQQIECBAgACBFgQM/HldOjbwv5n8s/q3T/UPrf6piLifty2VOhOQ084a2ul25nwnSqdbty0CBAgQIECAQJ6AgT/P8tAb1Dci4pETl3gnIp6eMaDf/ln9Y+Vev/mAv9fytqRShwJy2mFTO9ySgb/DptoSAQIECBAgsL6AgT/PfM6nSt++2pJP4D93qv+8T+nPa2TnleS08wZ3sj0DfyeNtA0CBAgQIEBgWwEDf57/3EHKqX6euUrLBeR0uZlXrC9g4F/f3BUJECBAgACBDgUM/HlNnTNIOdXP81bpMgE5vczNq9YVMPCv6+1qBAgQIECAQKcCBv68xp4apJzq5zmrdJ2AnF7n59XrCBj413F2FQIECBAgQKBzAQN/XoOPDVJO9fOMVbpeQE6vN1ShXsDAX2/sCgQIECBAgMAAAgb+vCYfeoP6akQ8duYSPoE/rwcqnReQ0/NGnrG9gIF/+x5YAQECBAgQINCBgIE/r4mXvEH9dET4BP68Hqh0XkBOzxt5xvYCl+R0+1VbAQECBAgQIEBgZwIG/ryGLHmD6lQ/z12lZQJyuszLs7cRWJLTbVboqgQIECBAgACBBgQM/HlNmvsG1al+nrlKywXkdLmZV6wvMDen66/MFQkQIECAAAECDQkY+POade4NqlP9PGuVLheQ08vtvHI9gXM5XW8lrkSAAAECBAgQaFjAwJ/XvFNvUJ3q5zmrdJ2AnF7n59XrCBj413F2FQIECBAgQKBzAQN/XoMPvUH9TER8JCIePXGZ1yPimYh4LW8pKhE4KiCnwtGCgIG/hS5ZIwECBAgQILB7AQN/XouO/X7zU1d4PiKey1uCSgTOCsjpWSJP2IGAgX8HTbAEAgQIECBAoH0BA39eD5cMUk7189xVWiYgp8u8PHsbAQP/Nu6uSoAAAQIECHQmYODPa+jcQcqpfp65SssF5HS5mVesL2DgX9/cFQkQIECAAIEOBQz8eU09N0g51c+zVulyATm93M4r1xMw8K9n7UoECBAgQIBAxwIG/rzmnhqknOrnOat0ncC1OX0oIt65bgleTeCsgIH/LJEnECBAgAABAgTOCxj4zxvNfcahN6hfiIjHfQL/XELPW0Hgmpw+GREvRMS9iHh7hbW6xLgCBv5xe2/nBAgQIECAQKKAgT8P0xvUPEuV6gQuyenDEfFiRDxxs6yXI2Ia/j0IVAlcktOqtahLgAABAgQIEGhWwMCf1zpvUPMsVaoTWJrTabB/KSKmb+W//Zj+fBr8PQhUCCzNacUa1CRAgAABAgQINC9g4M9roTeoeZYq1QnMzendU/27K5q+pX/61v4HdUtVeWCBuTkdmMjWCRAgQIAAAQLnBQz8543mPsMb1LlSnrelwJycHjvVv73uVyLimYh4a8vNuHa3AnNy2u3mbYwAAQIECBAgkCVg4M+SjPAGNc9SpTqBUzk9d6o/rWr6hP6nI+J+3RJVJuB+KgMECBAgQIAAgQwBA3+G4rs1DPx5lirVCRzL6ZtHflb/9kqc6tf1ReX3C7ifSgQBAgQIECBAIEHAwJ+AeFPCG9Q8S5XqBA7l9I2IeOTEJZ3q1/VD5cMC7qeSQYAAAQIECBBIEDDwJyAa+PMQVSoXODRInbqoU/3ylrjAAQEDv1gQIECAAAECBBIEDPwJiAb+PESVygXmDvxO9ctb4QInBAz84kGAAAECBAgQSBAw8CcgGvjzEFUqF5gz8DvVL2+DC5wRMPCLCAECBAgQIEAgQcDAn4Bo4M9DVKlc4NTA71S/nN8FZgoY+GdCeRoBAgQIECBA4JSAgT8vH96g5lmqVCdwbOB3ql9nrvJyAffT5WZeQYAAAQIECBD4gICBPy8U3qDmWapUJ3Aop69GxGN1l1SZwGIB99PFZF5AgAABAgQIEPiggIE/LxXeoOZZqlQnIKd1tirnCchpnqVKBAgQIECAwMACBv685nuDmmepUp2AnNbZqpwnIKd5lioRIECAAAECAwsY+POa7w1qnqVKdQJyWmercp6AnOZZqkSAAAECBAgMLGDgz2u+N6h5lirVCchpna3KeQJymmepEgECBAgQIDCwgIE/r/neoOZZqlQnIKd1tirnCchpnqVKBAgQIECAwMACBv685nuDmmepUp2AnNbZqpwnIKd5lioRIECAAAECAwsY+POa7w1qnqVKdQJyWmercp6AnOZZqkSAAAECBAgMLGDgz2u+N6h5lirVCchpna3KeQJymmepEgECBAgQIDCwgIE/r/neoOZZqlQnIKd1tirnCchpnqVKBAgQIECAwMACBv685nuDmmepUp2AnNbZqpwnIKd5lioRIECAAAECAwsY+POa7w1qnqVKdQJyWmercp6AnOZZqkSAAAECBAgMLGDgz2u+N6h5lirVCchpna3KeQJymmepEgECBAgQIDCwgIE/r/neoOZZqlQnIKd1tirnCchpnqVKBAgQIECAwMACBv685nuDmmepUp2AnNbZqpwnIKd5lioRIECAAAECAwsY+Aduvq0TIECAAAECBAgQIECAQL8CBv5+e2tnBAgQIECAAAECBAgQIDCwgIF/4ObbOgECBAgQIECAAAECBAj0K2Dg77e3dkaAAAECBAgQIECAAAECAwsY+Aduvq0TIECAAAECBAgQIECAQL8CBv5+e2tnBAgQIECAAAECBAgQIDCwgIF/4ObbOgECBAgQIECAAAECBAj0K2Dg77e3dkaAAAECBAgQIECAAAECAwsY+Aduvq0TIECAAAECBAgQIECAQL8CBv5+e2tnBAgQIECAAAECBAgQIDCwgIF/4ObbOgECBAgQIECAAAECBAj0K2Dg77e3dkaAAAECBAgQIECAAAECAwsY+Aduvq0TIECAAAECBAgQIECAQL8CBv5+e2tnBAgQIECAAAECBAgQIDCwgIF/4ObbOgECBAgQIECAAAECBAj0K2Dg77e3dkaAAAECBAgQIECAAAECAwsY+Aduvq0TIECAAAECBAgQIECAQL8CBv5+e2tnBAgQIECAAAECBAgQIDCwgIF/4ObbOgECBAgQIECAAAECBAj0K2Dg77e3dkaAAAECBAgQIECAAAECAwsY+Aduvq0TIECAAAECBAgQIECAQL8CBv5+e2tnBAgQIECAAAECBAgQIDCwgIF/4ObbOgECBAgQIECAAAECBAj0K2Dg77e3dkaAAAECBAgQIECAAAECAwsY+Aduvq0TIECAAAECBAgQIECAQL8CBv5+e2tnBAgQIECAAAECBAgQIPD/t1/HBAAAAAjC+re2hyyC8yIsIPjD55tOgAABAgQIECBAgAABAr8Cgv/3W8sIECBAgAABAgQIECBAICwg+MPnm06AAAECBAgQIECAAAECvwKC//dbywgQIECAAAECBAgQIEAgLCD4w+ebToAAAQIECBAgQIAAAQK/AoL/91vLCBAgQIAAAQIECBAgQCAsIPjD55tOgAABAgQIECBAgAABAr8Cgv/3W8sIECBAgAABAgQIECBAICwg+MPnm06AAAECBAgQIECAAAECvwKC//dbywgQIECAAAECBAgQIEAgLCD4w+ebToAAAQIECBAgQIAAAQK/AgOYR34g/YMI8gAAAABJRU5ErkJggg==", iconMapping: { 0: { x: 0, y: 0, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 1: { x: 170, y: 0, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 2: { x: 340, y: 0, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 3: { x: 510, y: 0, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 4: { x: 680, y: 0, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 5: { x: 850, y: 0, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 6: { x: 0, y: 170, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 7: { x: 170, y: 170, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 8: { x: 340, y: 170, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 9: { x: 510, y: 170, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 10: { x: 680, y: 170, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 11: { x: 850, y: 170, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 12: { x: 0, y: 340, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 13: { x: 170, y: 340, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 14: { x: 340, y: 340, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 15: { x: 510, y: 340, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 16: { x: 680, y: 340, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 17: { x: 850, y: 340, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 18: { x: 0, y: 510, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 19: { x: 170, y: 510, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 }, 20: { x: 340, y: 510, width: 170, height: 170, anchorX: 85, anchorY: 133, mask: !0 } }, iconBounds: [0, 51.444] }]]), it = { image: { type: "object", value: null }, image2: { type: "object", value: null }, imageSmoothing: { type: "number", value: 0 }, imageInterpolation: { type: "object", value: Ze.CUBIC }, imageWeight: { type: "number", value: 0 }, imageType: { type: "object", value: xe.SCALAR }, imageUnscale: { type: "array", value: null }, imageMinValue: { type: "object", value: null }, imageMaxValue: { type: "object", value: null }, bounds: { type: "array", value: [-180, -90, 180, 90], compare: !0 }, minZoom: { type: "object", value: null }, maxZoom: { type: "object", value: null }, style: { type: "object", value: ss.VALUE }, density: { type: "number", value: 0 }, unitFormat: { type: "object", value: null }, textFormatFunction: { type: "function", value: ll }, textFontFamily: { type: "object", value: Cs }, textSize: { type: "number", value: 12 }, textColor: { type: "color", value: Es }, textOutlineWidth: { type: "number", value: 1 }, textOutlineColor: { type: "color", value: ks }, iconBounds: { type: "array", value: null }, iconSize: { type: "object", value: 40 }, iconColor: { type: "color", value: oh }, palette: { type: "object", value: null } };
class Hn extends je {
  renderLayers() {
    const { viewport: e } = this.context, { props: t, visiblePoints: n } = this.state;
    if (!t || !n) return [];
    const { style: r, unitFormat: s, textFormatFunction: o, textFontFamily: i, textSize: l, textColor: u, textOutlineWidth: c, textOutlineColor: f, iconSize: h, iconColor: p } = he(t, it), { paletteScale: v } = this.state;
    if (Ni.has(r)) {
      const { iconStyle: I, iconAtlasTexture: y } = this.state;
      if (!I || !y) return [];
      const T = Object.keys(I.iconMapping).length, L = t.iconBounds ?? I.iconBounds ?? [0, 0], E = L[1] - L[0], C = (M) => (M - L[0]) / E, Q = Array.isArray(h) ? h[1] - h[0] : 0;
      return [new Ki(this.getSubLayerProps({ id: "icon", data: n, getPosition: (M) => M.geometry.coordinates, getIcon: (M) => `${Math.min(Math.max(Math.floor(C(M.properties.value) * T), 0), T - 1)}`, getSize: (M) => Array.isArray(h) ? h[0] + C(M.properties.value) * Q : h, getColor: (M) => v ? Wn(v(M.properties.value).rgba()) : p, getAngle: (M) => Ye(e, M.properties.direction ? 360 - M.properties.direction : 0), iconAtlas: y, iconMapping: I.iconMapping, sizeBasis: "height", billboard: !1, parameters: { cullMode: "front", depthCompare: "always", ...this.props.parameters } }))];
    }
    return [new In(this.getSubLayerProps({ id: "text", data: n, getPosition: (I) => I.geometry.coordinates, getText: (I) => o(I.properties.value, s), getSize: l, getColor: (I) => v ? Wn(v(I.properties.value).rgba()) : u, getAngle: Ye(e, 0), outlineWidth: c, outlineColor: f, fontFamily: i, fontSettings: { sdf: !0 }, billboard: !1, parameters: { cullMode: "front", depthCompare: "always", ...this.props.parameters } }))];
  }
  shouldUpdateState(e) {
    return super.shouldUpdateState(e) || e.changeFlags.viewportChanged;
  }
  updateState(e) {
    const { image: t, image2: n, imageSmoothing: r, imageInterpolation: s, imageWeight: o, imageType: i, imageUnscale: l, imageMinValue: u, imageMaxValue: c, minZoom: f, maxZoom: h, style: p, density: v, unitFormat: I, textFormatFunction: y, textFontFamily: T, textSize: L, textColor: E, textOutlineWidth: C, textOutlineColor: Q, iconSize: M, iconColor: Z, palette: z, visible: N } = e.props;
    super.updateState(e), N ? (this.state.iconStyle && p === e.oldProps.style || this._updateIconStyle(), (v !== e.oldProps.density || e.changeFlags.viewportChanged) && this._updatePositions(), t === e.oldProps.image && n === e.oldProps.image2 && r === e.oldProps.imageSmoothing && s === e.oldProps.imageInterpolation && o === e.oldProps.imageWeight && i === e.oldProps.imageType && l === e.oldProps.imageUnscale && u === e.oldProps.imageMinValue && c === e.oldProps.imageMaxValue && N === e.oldProps.visible || this._updateFeatures(), (f !== e.oldProps.minZoom || h !== e.oldProps.maxZoom || e.changeFlags.viewportChanged) && this._updateVisibleFeatures(), z !== e.oldProps.palette && this._updatePalette(), I === e.oldProps.unitFormat && y === e.oldProps.textFormatFunction && T === e.oldProps.textFontFamily && L === e.oldProps.textSize && E === e.oldProps.textColor && C === e.oldProps.textOutlineWidth && Q === e.oldProps.textOutlineColor && M === e.oldProps.iconSize && Z === e.oldProps.iconColor || this._redrawVisibleFeatures(), this.setState({ props: e.props })) : this.setState({ points: void 0, visiblePoints: void 0 });
  }
  async _updateIconStyle() {
    const { device: e } = this.context, { style: t } = he(this.props, it), n = Ni.get(t);
    if (!n) return void this.setState({ iconStyle: void 0, iconAtlasTexture: void 0 });
    this.setState({ iconStyle: n });
    const r = nt(e, await cl(n.iconAtlas));
    this.setState({ iconAtlasTexture: r });
  }
  _updatePositions() {
    const { viewport: e } = this.context, { density: t } = he(this.props, it), n = qh(e, t + 3);
    this.setState({ positions: n }), this._updateFeatures();
  }
  _updateFeatures() {
    const { image: e, image2: t, imageSmoothing: n, imageInterpolation: r, imageWeight: s, imageType: o, imageUnscale: i, imageMinValue: l, imageMaxValue: u, bounds: c } = he(this.props, it), { positions: f } = this.state;
    if (!e || !f) return;
    const h = vh({ image: e, image2: t, imageSmoothing: n, imageInterpolation: r, imageWeight: s, imageType: o, imageUnscale: i, imageMinValue: l, imageMaxValue: u }, c, f).features.filter(((p) => !isNaN(p.properties.value)));
    this.setState({ points: h }), this._updateVisibleFeatures();
  }
  _updateVisibleFeatures() {
    const { viewport: e } = this.context, { minZoom: t, maxZoom: n } = he(this.props, it), { points: r } = this.state;
    if (!r) return;
    let s;
    s = Bt(e, t, n) ? r : [], this.setState({ visiblePoints: s });
  }
  _updatePalette() {
    const { palette: e } = he(this.props, it);
    if (!e) return this.setState({ paletteScale: void 0 }), void this._redrawVisibleFeatures();
    const t = $t(e);
    this.setState({ paletteScale: t }), this._redrawVisibleFeatures();
  }
  _redrawVisibleFeatures() {
    this.setState({ visiblePoints: Array.isArray(this.state.visiblePoints) ? Array.from(this.state.visiblePoints) : this.state.visiblePoints });
  }
}
Hn.layerName = "GridCompositeLayer", Hn.defaultProps = it;
const Gh = { ...Hn.defaultProps };
class Ui extends je {
  renderLayers() {
    const { props: e } = this.state;
    return e ? [new Hn(this.props, this.getSubLayerProps({ id: "composite" }))] : [];
  }
  updateState(e) {
    const { image: t, imageUnscale: n } = e.props;
    if (super.updateState(e), t && n && !(t.data instanceof Uint8Array || t.data instanceof Uint8ClampedArray)) throw new Error("imageUnscale can be applied to Uint8 data only");
    this.setState({ props: e.props });
  }
}
Ui.layerName = "GridLayer", Ui.defaultProps = Gh;
const Vi = "uniform particleUniforms{float w;vec2 x;float y;vec4 z;float AA;float AB;float AC;float AD;float AE;float AF;}particle;", Fi = "w", Ri = "x", Wi = "y", qi = "z", Gi = "AA", Ji = "AB", zi = "AC", Hi = "AD", Zi = "AE", ji = "AF", $i = { name: "particle", vs: Vi, fs: Vi, uniformTypes: { [Fi]: "f32", [Ri]: "vec2<f32>", [Wi]: "f32", [qi]: "vec4<f32>", [Gi]: "f32", [Ji]: "f32", [zi]: "f32", [Hi]: "f32", [Zi]: "f32", [ji]: "f32" }, getUniforms: function(a = {}) {
  return { [Fi]: a.viewportGlobe ? 1 : 0, [Ri]: a.viewportGlobeCenter ?? [0, 0], [Wi]: a.viewportGlobeRadius ?? 0, [qi]: a.viewportBounds ?? [0, 0, 0, 0], [Gi]: a.viewportZoomChangeFactor ?? 0, [Ji]: a.numParticles, [zi]: a.maxAge, [Hi]: a.speedFactor, [Zi]: a.time, [ji]: a.seed };
} }, Rr = "sourcePosition", Wr = "targetPosition", qr = "sourceColor", Gr = "targetColor", qt = { imageTexture: { type: "object", value: null }, imageTexture2: { type: "object", value: null }, imageSmoothing: { type: "number", value: 0 }, imageInterpolation: { type: "object", value: Ze.CUBIC }, imageWeight: { type: "number", value: 0 }, imageType: { type: "object", value: xe.VECTOR }, imageUnscale: { type: "array", value: null }, imageMinValue: { type: "object", value: null }, imageMaxValue: { type: "object", value: null }, bounds: { type: "array", value: [-180, -90, 180, 90], compare: !0 }, minZoom: { type: "object", value: null }, maxZoom: { type: "object", value: 15 }, palette: { type: "object", value: null }, color: { type: "color", value: Fn }, numParticles: { type: "number", min: 1, max: 1e6, value: 5e3 }, maxAge: { type: "number", min: 1, max: 255, value: 10 }, speedFactor: { type: "number", min: 0, max: 50, value: 1 }, width: { type: "number", value: 1 }, animate: !0, wrapLongitude: !0 };
class Zn extends kl {
  getShaders() {
    const e = super.getShaders();
    return { ...e, inject: { ...e.inject, "vs:#decl": (e.inject?.["vs:#decl"] || "") + `
          in float instanceOpacities;
          out float drop;
          const float DROP_POSITION_Z = -1.;
        `, "vs:#main-start": (e.inject?.["vs:#main-start"] || "") + `
          drop = float(instanceSourcePositions.z == DROP_POSITION_Z || instanceTargetPositions.z == DROP_POSITION_Z);
        `, "vs:DECKGL_FILTER_COLOR": (e.inject?.["vs:DECKGL_FILTER_COLOR"] || "") + `
          color.a = color.a * instanceOpacities;
        `, "fs:#decl": (e.inject?.["fs:#decl"] || "") + `
          in float drop;
        `, "fs:#main-start": (e.inject?.["fs:#main-start"] || "") + `
          if (drop > 0.5) discard;
        ` } };
  }
  initializeState() {
    super.initializeState();
    const e = this.getAttributeManager();
    e.remove(["instanceSourcePositions", "instanceTargetPositions", "instanceColors", "instanceWidths"]), e.addInstanced({ instanceSourcePositions: { size: 3, type: "float32", noAlloc: !0 }, instanceTargetPositions: { size: 3, type: "float32", noAlloc: !0 }, instanceColors: { size: 4, type: "float32", noAlloc: !0 }, instanceOpacities: { size: 1, type: "float32", noAlloc: !0 } });
  }
  updateState(e) {
    const { imageType: t, numParticles: n, maxAge: r, width: s, palette: o, visible: i } = e.props;
    super.updateState(e), i && t === xe.VECTOR && n && r && s ? (t === e.oldProps.imageType && n === e.oldProps.numParticles && r === e.oldProps.maxAge && s === e.oldProps.width && i === e.oldProps.visible || this._setupTransformFeedback(), o !== e.oldProps.palette && this._updatePalette()) : this._deleteTransformFeedback();
  }
  finalizeState(e) {
    this._deleteTransformFeedback(), super.finalizeState(e);
  }
  draw(e) {
    const { initialized: t } = this.state;
    if (!t) return;
    const { viewport: n } = this.context, { model: r } = this.state, { minZoom: s, maxZoom: o, width: i, animate: l } = he(this.props, qt), { sourcePositions: u, targetPositions: c, sourceColors: f, opacities: h, transform: p } = this.state;
    u && c && f && h && p && r && Bt(n, s, o) && (r.setAttributes({ instanceSourcePositions: u, instanceTargetPositions: c, instanceColors: f, instanceOpacities: h }), r.setConstantAttributes({ instanceSourcePositions64Low: new Float32Array([0, 0, 0]), instanceTargetPositions64Low: new Float32Array([0, 0, 0]), instanceWidths: new Float32Array([i]) }), super.draw(e), l && this.step());
  }
  _setupTransformFeedback() {
    const { device: e } = this.context, { initialized: t } = this.state;
    t && this._deleteTransformFeedback();
    const { numParticles: n, maxAge: r } = he(this.props, qt), s = n * r, o = n * (r - 1), i = e.createBuffer(new Float32Array(3 * s)), l = e.createBuffer(new Float32Array(3 * s)), u = e.createBuffer(new Float32Array(4 * s)), c = e.createBuffer(new Float32Array(4 * s)), f = e.createBuffer(new Float32Array(new Array(s).fill(void 0).map(((p, v) => 1 - Math.floor(v / n) / r)))), h = new Vn(e, { vs: `#version 300 es
#define SHADER_NAME  particle-line-layer-update-vertex-shader
#ifdef GL_ES
precision highp float;
#endif
vec4 AG(sampler2D AH,vec2 AI,vec2 AJ,vec2 AK){vec2 uv=(AJ+AK+0.5)/AI;return texture(AH,uv);}const vec4 AL=vec4(3.,-6.,0.,4.)/6.;const vec4 AM=vec4(-1.,6.,-12.,8.)/6.;vec4 AN(float J){return vec4(J*J*J,J*J,J,1.);}vec4 AO(vec4 AP,vec4 AQ,vec4 AR,vec4 AS,float AT){vec4 O=AP*dot(AM,AN(AT+1.))+AQ*dot(AL,AN(AT))+AR*dot(AL,AN(1.-AT))+AS*dot(AM,AN(2.-AT));O.a=(AP.a>0.&&AQ.a>0.&&AR.a>0.&&AS.a>0.)?max(max(max(AP.a,AQ.a),AR.a),AS.a):0.;return O;}vec4 AU(sampler2D AH,vec2 AI,vec2 uv){vec2 AV=uv*AI-0.5;vec2 AJ=floor(AV);vec2 AW=fract(AV);return AO(AO(AG(AH,AI,AJ,vec2(-1,-1)),AG(AH,AI,AJ,vec2(0,-1)),AG(AH,AI,AJ,vec2(1,-1)),AG(AH,AI,AJ,vec2(2,-1)),AW.x),AO(AG(AH,AI,AJ,vec2(-1,0)),AG(AH,AI,AJ,vec2(0,0)),AG(AH,AI,AJ,vec2(1,0)),AG(AH,AI,AJ,vec2(2,0)),AW.x),AO(AG(AH,AI,AJ,vec2(-1,1)),AG(AH,AI,AJ,vec2(0,1)),AG(AH,AI,AJ,vec2(1,1)),AG(AH,AI,AJ,vec2(2,1)),AW.x),AO(AG(AH,AI,AJ,vec2(-1,2)),AG(AH,AI,AJ,vec2(0,2)),AG(AH,AI,AJ,vec2(1,2)),AG(AH,AI,AJ,vec2(2,2)),AW.x),AW.y);}vec4 AX(sampler2D AH,vec2 AI,vec2 uv){vec2 AV=uv*AI-0.5;vec2 AJ=floor(AV);vec2 AW=fract(AV);return mix(mix(AG(AH,AI,AJ,vec2(0,0)),AG(AH,AI,AJ,vec2(1,0)),AW.x),mix(AG(AH,AI,AJ,vec2(0,1)),AG(AH,AI,AJ,vec2(1,1)),AW.x),AW.y);}vec4 AY(sampler2D AH,vec2 AI,vec2 uv){vec2 AV=uv*AI-0.5;vec2 AJ=floor(AV+0.5);return AG(AH,AI,AJ,vec2(0,0));}vec4 AZ(sampler2D AH,vec2 AI,float a,vec2 uv){if(a==2.){return AU(AH,AI,uv);}if(a==1.){return AX(AH,AI,uv);}else{return AY(AH,AI,uv);}}vec4 Aa(sampler2D AH,sampler2D Ab,vec2 AI,float a,float b,bool B,vec2 uv){vec2 Ac;Ac.x=B?uv.x+0.5/AI.x:mix(0.+0.5/AI.x,1.-0.5/AI.x,uv.x);Ac.y=mix(0.+0.5/AI.y,1.-0.5/AI.y,uv.y);if(b>0.){vec4 Ad=AZ(AH,AI,a,Ac);vec4 Ae=AZ(Ab,AI,a,Ac);return mix(Ad,Ae,b);}else{return AZ(AH,AI,a,Ac);}}vec4 Af(sampler2D AH,sampler2D Ab,vec2 Y,float Z,float a,float b,bool B,vec2 uv){float Ag=1.+max(0.,Z);vec2 AI=Y/Ag;return Aa(AH,Ab,AI,a,b,B,uv);}float Ah(float K,float J){return J==0.?sign(K)*F/2.:atan(K,J);}bool Ai(float q){uint Aj=floatBitsToUint(q);return(Aj&0x7fffffffu)>0x7f800000u;}bool Ak(vec4 Ad,vec2 d){if(d[0]<d[1]){return Ad.a>=1.;}else{return!Ai(Ad.x);}}float Al(vec4 Ad,float c,vec2 d){if(c==1.){return 0.;}else{if(d[0]<d[1]){return mix(d[0],d[1],Ad.x);}else{return Ad.x;}}}vec2 Am(vec4 Ad,float c,vec2 d){if(c==1.){if(d[0]<d[1]){return mix(vec2(d[0]),vec2(d[1]),Ad.xy);}else{return Ad.xy;}}else{return vec2(0.);}}float An(vec4 Ad,float c,vec2 d){if(c==1.){vec2 q=Am(Ad,c,d);return length(q);}else{return Al(Ad,c,d);}}float Ao(vec4 Ad,float c,vec2 d){if(c==1.){vec2 q=Am(Ad,c,d);return mod((360.-(Ah(q.y,q.x)/F*180.+180.))-270.,360.)/360.;}else{return 0.;}}in vec3 sourcePosition;in vec4 sourceColor;out vec3 targetPosition;out vec4 targetColor;const float Ap=-1.;const vec4 Aq=vec4(0);const float Ar=6370972.;vec2 As(vec2 At,float Au,float Av){float Aw=Au/Ar;float Ax=radians(Av);float Ay=radians(At.y);float Az=radians(At.x);float BA=sin(Ay)*cos(Aw)+cos(Ay)*sin(Aw)*cos(Ax);float BB=asin(BA);float K=sin(Ax)*sin(Aw)*cos(Ay);float J=cos(Aw)-sin(Ay)*BA;float BC=Az+Ah(K,J);float BD=degrees(BB);float BE=degrees(BC);return vec2(BE,BD);}float BF(float BG){float BH=mod(BG+180.,360.)-180.;return BH;}float BF(float BG,float BI){float BH=BF(BG);if(BH<BI){BH+=360.;}return BH;}float BJ(vec2 AF){return fract(sin(dot(AF.xy,vec2(12.9898,78.233)))*43758.5453);}vec2 BK(vec2 AF){return vec2(BJ(AF+1.3),BJ(AF+2.1));}vec2 BL(vec2 BM){if(particle.w==1.){BM.x+=0.0001;BM.x=sqrt(BM.x);float Au=BM.x*particle.y;float Av=BM.y*360.;return As(particle.x,Au,Av);}else{BM.y=smoothstep(0.,1.,BM.y);vec2 BN=particle.z.xy;vec2 BO=particle.z.zw;return mix(BN,BO,BM);}}vec2 BP(vec2 BQ,vec2 BR){float BS=cos(radians(BQ.y));vec2 AK;if(particle.w==1.){AK=vec2(BR.x/BS,BR.y);}else{AK=vec2(BR.x,BR.y*BS);}return BQ+AK;}bool BT(vec2 BQ,vec4 A){vec2 BU=A.xy;vec2 BV=A.zw;float BG=BF(BQ.x,BU.x);float BD=BQ.y;return(BU.x<=BG&&BG<=BV.x&&BU.y<=BD&&BD<=BV.y);}void main(){float BW=mod(float(gl_VertexID),particle.AB);float BX=floor(float(gl_VertexID)/particle.AB);if(BX>0.){return;}if(sourcePosition.z==Ap){vec2 BY=vec2(BW*particle.AF/particle.AB);vec2 BM=BK(BY);vec2 BQ=BL(BM);targetPosition.xy=BQ;targetPosition.x=BF(targetPosition.x);targetColor=Aq;return;}if(particle.AA>1.&&mod(BW,particle.AA)>=1.){targetPosition.xy=sourcePosition.xy;targetPosition.z=Ap;targetColor=Aq;return;}if(abs(mod(BW,particle.AC+2.)-mod(particle.AE,particle.AC+2.))<1.){targetPosition.xy=sourcePosition.xy;targetPosition.z=Ap;targetColor=Aq;return;}if(!BT(sourcePosition.xy,bitmap2.A)){targetPosition.xy=sourcePosition.xy;targetColor=Aq;return;}vec2 uv=Q(sourcePosition.xy);vec4 Ad=Af(W,X,raster.Y,raster.Z,raster.a,raster.b,bitmap2.B,uv);if(!Ak(Ad,raster.d)){targetPosition.xy=sourcePosition.xy;targetColor=Aq;return;}float q=An(Ad,raster.c,raster.d);if((!Ai(raster.e)&&q<raster.e)||(!Ai(raster.f)&&q>raster.f)){targetPosition.xy=sourcePosition.xy;targetColor=Aq;return;}vec2 BR=Am(Ad,raster.c,raster.d)*particle.AD;targetPosition.xy=BP(sourcePosition.xy,BR);targetPosition.x=BF(targetPosition.x);targetColor=sourceColor;targetColor=r(m,palette.n,palette.o,q);}`, modules: [Et, kt, Tt, $i], vertexCount: n, attributes: { [Rr]: i, [qr]: u }, bufferLayout: [{ name: Rr, format: "float32x3" }, { name: qr, format: "float32x4" }], feedbackBuffers: { [Wr]: l, [Gr]: c }, varyings: [Wr, Gr] });
    this.setState({ initialized: !0, numInstances: s, numAgedInstances: o, sourcePositions: i, targetPositions: l, sourceColors: u, targetColors: c, opacities: f, transform: h, previousViewportZoom: 0, previousTime: 0 });
  }
  _runTransformFeedback() {
    const { initialized: e } = this.state;
    if (!e) return;
    const { device: t, viewport: n, timeline: r } = this.context, { imageTexture: s, imageTexture2: o, imageSmoothing: i, imageInterpolation: l, imageWeight: u, imageType: c, imageUnscale: f, imageMinValue: h, imageMaxValue: p, bounds: v, color: I, numParticles: y, maxAge: T, speedFactor: L } = he(this.props, qt), { paletteTexture: E, paletteBounds: C, numAgedInstances: Q, sourcePositions: M, targetPositions: Z, sourceColors: z, targetColors: N, transform: G, previousViewportZoom: S, previousTime: q } = this.state;
    if (!(s && typeof Q == "number" && M && Z && z && N && G)) return;
    const Y = r.getTime();
    if (typeof q == "number" && Y < q + 1e3 / 30) return;
    const j = We(n), se = We(n) ? Ts(n) : void 0, ne = We(n) ? dl(n) : void 0, ye = hl(n) ? pl(n) : void 0, Ge = 2 ** (4 * (typeof S == "number" ? S - Zt(n) : 0)), le = L / 2 ** (Zt(n) + 7);
    G.model.shaderInputs.setProps({ [Et.name]: { viewportGlobe: j, bounds: v, _imageCoordinateSystem: jn.LNGLAT }, [kt.name]: { imageTexture: s ?? Ie(t), imageTexture2: o ?? Ie(t), imageSmoothing: i, imageInterpolation: l, imageWeight: u, imageType: c, imageUnscale: f, imageMinValue: h, imageMaxValue: p }, [Tt.name]: { paletteTexture: E ?? Ie(t), paletteBounds: C, paletteColor: I }, [$i.name]: { viewportGlobe: j, viewportGlobeCenter: se, viewportGlobeRadius: ne, viewportBounds: ye, viewportZoomChangeFactor: Ge, numParticles: y, maxAge: T, speedFactor: le, time: Y, seed: Math.random() } }), G.run({ clearColor: !1, clearDepth: !1, clearStencil: !1, depthReadOnly: !0, stencilReadOnly: !0 });
    const Oe = t.createCommandEncoder();
    Oe.copyBufferToBuffer({ sourceBuffer: M, sourceOffset: 0, destinationBuffer: Z, destinationOffset: 4 * y * 3, size: 4 * Q * 3 }), Oe.copyBufferToBuffer({ sourceBuffer: z, sourceOffset: 0, destinationBuffer: N, destinationOffset: 4 * y * 4, size: 4 * Q * 4 });
    const ht = Oe.finish();
    t.submit(ht), Oe.destroy(), this._swapTransformFeedback(), this.state.previousViewportZoom = Zt(n), this.state.previousTime = Y;
  }
  _swapTransformFeedback() {
    const { sourcePositions: e, targetPositions: t, sourceColors: n, targetColors: r, transform: s } = this.state;
    e && t && n && r && s && (this.state.sourcePositions = t, this.state.targetPositions = e, this.state.sourceColors = r, this.state.targetColors = n, s.model.setAttributes({ [Rr]: t, [qr]: r }), s.transformFeedback.setBuffers({ [Wr]: e, [Gr]: n }));
  }
  _resetTransformFeedback() {
    const { initialized: e } = this.state;
    if (!e) return;
    const { numInstances: t, sourcePositions: n, targetPositions: r, sourceColors: s, targetColors: o } = this.state;
    typeof t == "number" && n && r && s && o && (n.write(new Float32Array(3 * t)), r.write(new Float32Array(3 * t)), s.write(new Float32Array(4 * t)), o.write(new Float32Array(4 * t)));
  }
  _deleteTransformFeedback() {
    const { initialized: e } = this.state;
    if (!e) return;
    const { sourcePositions: t, targetPositions: n, sourceColors: r, targetColors: s, opacities: o, transform: i } = this.state;
    t && n && r && s && o && i && (t.destroy(), n.destroy(), r.destroy(), s.destroy(), o.destroy(), i.destroy(), this.setState({ initialized: !1, sourcePositions: void 0, targetPositions: void 0, sourceColors: void 0, targetColors: void 0, opacities: void 0, transform: void 0 }));
  }
  _updatePalette() {
    const { device: e } = this.context, { palette: t } = he(this.props, qt);
    if (!t) return void this.setState({ paletteTexture: void 0, paletteBounds: void 0 });
    const n = $t(t), { paletteBounds: r, paletteTexture: s } = Bs(e, n);
    this.setState({ paletteTexture: s, paletteBounds: r });
  }
  step() {
    this._runTransformFeedback(), this.setNeedsRedraw();
  }
  clear() {
    this._resetTransformFeedback(), this.setNeedsRedraw();
  }
}
Zn.layerName = "ParticleLineLayer", Zn.defaultProps = qt;
const Jh = { ...Zn.defaultProps, imageTexture: void 0, imageTexture2: void 0, image: { type: "object", value: null }, image2: { type: "object", value: null } };
class as extends je {
  renderLayers() {
    const { device: e } = this.context, { props: t, imageTexture: n, imageTexture2: r } = this.state;
    return t && n ? [new Zn(this.props, this.getSubLayerProps({ id: "line", data: [], imageTexture: n, imageTexture2: r, parameters: { cullMode: "front", depthCompare: "always", ...this.props.parameters }, image: Ie(e), image2: Ie(e) }))] : [];
  }
  updateState(e) {
    const { image: t, image2: n, imageUnscale: r, bounds: s } = e.props;
    if (super.updateState(e), t && r && !(t.data instanceof Uint8Array || t.data instanceof Uint8ClampedArray)) throw new Error("imageUnscale can be applied to Uint8 data only");
    if (t !== e.oldProps.image || n !== e.oldProps.image2) {
      const { device: o } = this.context, { image: i, image2: l } = this.props, u = i ? nt(o, i, tt(s)) : null, c = l ? nt(o, l, tt(s)) : null;
      this.setState({ imageTexture: u, imageTexture2: c });
    }
    this.setState({ props: e.props });
  }
}
as.layerName = "ParticleLayer", as.defaultProps = Jh;
function Xt(a, e) {
  e === void 0 && (e = {});
  var t = e.insertAt;
  if (a && typeof document < "u") {
    var n = document.head || document.getElementsByTagName("head")[0], r = document.createElement("style");
    r.type = "text/css", t === "top" && n.firstChild ? n.insertBefore(r, n.firstChild) : n.appendChild(r), r.styleSheet ? r.styleSheet.cssText = a : r.appendChild(document.createTextNode(a));
  }
}
Xt(".weatherlayers-legend-control{margin:10px;pointer-events:auto}.weatherlayers-legend-control>div{background:hsla(0,0%,100%,.5);color:rgba(0,0,0,.75);display:inline-block;font-family:Helvetica Neue,Arial,Helvetica,sans-serif;font-size:12px;line-height:14px;width:100%}.weatherlayers-legend-control header,.weatherlayers-legend-control main{margin:5px 10px}.weatherlayers-legend-control header{font-weight:700}.weatherlayers-legend-control__legend{margin-top:5px;vertical-align:middle;width:100%}");
Xt(`.weatherlayers-tooltip-control{margin:10px;pointer-events:auto}.weatherlayers-tooltip-control>div{align-items:center;background:hsla(0,0%,100%,.5);color:rgba(0,0,0,.75);display:inline-flex;font-family:Helvetica Neue,Arial,Helvetica,sans-serif;font-size:12px;line-height:20px;padding:0 5px;white-space:nowrap}.weatherlayers-tooltip-control.follow-cursor{margin:0;pointer-events:none;position:absolute;z-index:1}.weatherlayers-tooltip-control.follow-cursor>div{position:absolute}.leaflet-map-pane .weatherlayers-tooltip-control.follow-cursor{z-index:101}.weatherlayers-tooltip-control.follow-cursor:before{content:"";height:0;position:absolute;width:0}.weatherlayers-tooltip-control.follow-cursor[data-follow-cursor-placement=BOTTOM]:before{border-bottom:5px solid hsla(0,0%,100%,.5);border-left:5px solid transparent;border-right:5px solid transparent;left:calc(50% - 5px);top:-5px}.weatherlayers-tooltip-control.follow-cursor[data-follow-cursor-placement=TOP]:before{border-left:5px solid transparent;border-right:5px solid transparent;border-top:5px solid hsla(0,0%,100%,.5);left:calc(50% - 5px);top:0}.weatherlayers-tooltip-control.follow-cursor[data-follow-cursor-placement=RIGHT]:before{border-bottom:5px solid transparent;border-right:5px solid hsla(0,0%,100%,.5);border-top:5px solid transparent;left:-5px;top:calc(50% - 5px)}.weatherlayers-tooltip-control.follow-cursor[data-follow-cursor-placement=LEFT]:before{border-bottom:5px solid transparent;border-left:5px solid hsla(0,0%,100%,.5);border-top:5px solid transparent;left:0;top:calc(50% - 5px)}.weatherlayers-tooltip-control .weatherlayers-tooltip-control__direction{align-items:center;display:inline-flex;margin-left:4px}.weatherlayers-tooltip-control .weatherlayers-tooltip-control__direction-icon{background:no-repeat 50%/contain;background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30' style='enable-background:new 0 0 30 30' xml:space='preserve'%3E%3Cpath d='M3.74 14.5c0-2.04.51-3.93 1.52-5.66s2.38-3.1 4.11-4.11 3.61-1.51 5.64-1.51c1.52 0 2.98.3 4.37.89s2.58 1.4 3.59 2.4 1.81 2.2 2.4 3.6.89 2.85.89 4.39c0 1.52-.3 2.98-.89 4.37s-1.4 2.59-2.4 3.59-2.2 1.8-3.59 2.39-2.84.89-4.37.89c-1.53 0-3-.3-4.39-.89s-2.59-1.4-3.6-2.4-1.8-2.2-2.4-3.58-.88-2.84-.88-4.37zm2.48 0c0 2.37.86 4.43 2.59 6.18 1.73 1.73 3.79 2.59 6.2 2.59 1.58 0 3.05-.39 4.39-1.18s2.42-1.85 3.21-3.2 1.19-2.81 1.19-4.39-.4-3.05-1.19-4.4-1.86-2.42-3.21-3.21-2.81-1.18-4.39-1.18-3.05.39-4.39 1.18S8.2 8.75 7.4 10.1s-1.18 2.82-1.18 4.4zm4.89 5.85 3.75-13.11c.01-.1.06-.15.15-.15s.14.05.15.15l3.74 13.11c.04.11.03.19-.02.25s-.13.06-.24 0l-3.47-1.3c-.1-.04-.2-.04-.29 0l-3.5 1.3c-.1.06-.17.06-.21 0s-.08-.15-.06-.25z'/%3E%3C/svg%3E");display:inline-block;height:20px;opacity:.75;vertical-align:middle;width:20px}.weatherlayers-tooltip-control .weatherlayers-tooltip-control__direction-text{margin-left:2px}.weatherlayers-tooltip-control:not(.has-direction) .weatherlayers-tooltip-control__direction,.weatherlayers-tooltip-control:not(.has-value){display:none}`);
Xt(`.weatherlayers-timeline-control{margin:10px;pointer-events:auto}.weatherlayers-timeline-control>div{background:hsla(0,0%,100%,.5);color:rgba(0,0,0,.75);display:inline-block;font-family:Helvetica Neue,Arial,Helvetica,sans-serif;font-size:12px;line-height:14px;width:100%}.weatherlayers-timeline-control footer,.weatherlayers-timeline-control header,.weatherlayers-timeline-control main{margin:5px 10px;text-align:center}.weatherlayers-timeline-control header{font-weight:700}.weatherlayers-timeline-control footer{display:flex;gap:10px}.weatherlayers-timeline-control__progress-input{margin:-2px 0 2px;vertical-align:middle;width:100%}.weatherlayers-timeline-control__end-datetime,.weatherlayers-timeline-control__start-datetime{flex:0 0}.weatherlayers-timeline-control__buttons{flex:1 0}.weatherlayers-timeline-control__start-datetime{text-align:left}.weatherlayers-timeline-control__end-datetime{text-align:right}.weatherlayers-timeline-control__button{background:no-repeat 50%/contain;display:inline-block;height:16px;vertical-align:middle;width:16px}.weatherlayers-timeline-control__button+.weatherlayers-timeline-control__button{margin-left:5px}.weatherlayers-timeline-control__play-button{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg width='1792' height='1792' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1576 927 248 1665q-23 13-39.5 3t-16.5-36V160q0-26 16.5-36t39.5 3l1328 738q23 13 23 31t-23 31z'/%3E%3C/svg%3E")}.weatherlayers-timeline-control__pause-button{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg width='1792' height='1792' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1664 192v1408q0 26-19 45t-45 19h-512q-26 0-45-19t-19-45V192q0-26 19-45t45-19h512q26 0 45 19t19 45zm-896 0v1408q0 26-19 45t-45 19H192q-26 0-45-19t-19-45V192q0-26 19-45t45-19h512q26 0 45 19t19 45z'/%3E%3C/svg%3E")}.weatherlayers-timeline-control__step-backward-button{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg width='1792' height='1792' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1363 141q19-19 32-13t13 32v1472q0 26-13 32t-32-13L653 941q-9-9-13-19v678q0 26-19 45t-45 19H448q-26 0-45-19t-19-45V192q0-26 19-45t45-19h128q26 0 45 19t19 45v678q4-10 13-19z'/%3E%3C/svg%3E")}.weatherlayers-timeline-control__step-forward-button{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg width='1792' height='1792' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M429 1651q-19 19-32 13t-13-32V160q0-26 13-32t32 13l710 710q9 9 13 19V192q0-26 19-45t45-19h128q26 0 45 19t19 45v1408q0 26-19 45t-45 19h-128q-26 0-45-19t-19-45V922q-4 10-13 19z'/%3E%3C/svg%3E")}.weatherlayers-timeline-control__loader{display:block;margin-top:2px}.weatherlayers-timeline-control__loader-icon{background:no-repeat 50%/contain;background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' style='margin:auto;background:0 0;display:block;shape-rendering:auto' width='16' height='16' viewBox='0 0 100 100' preserveAspectRatio='xMidYMid'%3E%3Ccircle cx='50' cy='50' fill='none' stroke='rgba(0, 0, 0, 0.4)' stroke-width='10' r='25' stroke-dasharray='117.80972450961724 41.269908169872416'%3E%3CanimateTransform attributeName='transform' type='rotate' repeatCount='indefinite' dur='1s' values='0 50 50;360 50 50' keyTimes='0;1'/%3E%3C/circle%3E%3C/svg%3E");display:inline-block;height:16px;vertical-align:middle;width:16px}.weatherlayers-timeline-control__loader-text{color:rgba(0,0,0,.4);margin-left:2px;vertical-align:middle}.weatherlayers-timeline-control.loading *{pointer-events:none}.weatherlayers-timeline-control.running .weatherlayers-timeline-control__play-button,.weatherlayers-timeline-control:not(.running) .weatherlayers-timeline-control__pause-button{display:none}.weatherlayers-timeline-control:not(.loading) .weatherlayers-timeline-control__loader{visibility:hidden}`);
Xt(".weatherlayers-attribution-control{margin-top:2px;pointer-events:auto}.weatherlayers-attribution-control>div{background:hsla(0,0%,100%,.5);color:rgba(0,0,0,.75);display:inline-block;font-family:Helvetica Neue,Arial,Helvetica,sans-serif;font-size:12px;line-height:20px;padding:0 5px}.weatherlayers-attribution-control a{color:rgba(0,0,0,.75);text-decoration:none}.weatherlayers-attribution-control a:hover{text-decoration:underline}");
Xt(`.weatherlayers-logo-control{margin:10px;pointer-events:auto}.weatherlayers-logo-control a{background:no-repeat 50%/contain;background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' xml:space='preserve' style='fill-rule:evenodd;clip-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:2' viewBox='0 0 131 23'%3E%3Cg opacity='.9'%3E%3Cpath d='M27.391 17.706h2.534l1.736-6.475h.132l1.765 6.475h2.52l2.761-10.569H36.07l-1.384 7.009h-.132l-1.75-7.009H30.65l-1.692 7.009h-.131L27.42 7.137h-2.79l2.761 10.569Zm15.092.19c2.615 0 3.611-1.53 3.846-2.504l.022-.088-2.373.007-.015.029c-.117.213-.564.711-1.428.711-.996 0-1.597-.674-1.619-1.839h5.486v-.747c0-2.49-1.56-4.101-4.014-4.101-2.461 0-4.021 1.633-4.021 4.262v.008c0 2.644 1.56 4.262 4.116 4.262Zm-.036-6.687c.805 0 1.377.52 1.501 1.495h-3.003c.125-.96.703-1.495 1.502-1.495Zm7.028 6.622c1.04 0 1.912-.44 2.271-1.136h.139v1.011h2.549v-5.559c0-1.758-1.282-2.783-3.531-2.783-2.204 0-3.611.989-3.757 2.49l-.007.088h2.351l.014-.037c.154-.41.572-.637 1.253-.637.718 0 1.128.33 1.128.879v.637l-1.78.103c-2.102.132-3.259.988-3.259 2.468v.015c0 1.486 1.069 2.461 2.629 2.461Zm-.132-2.644v-.015c0-.484.403-.791 1.172-.842l1.37-.088v.534c0 .703-.637 1.245-1.458 1.245-.652 0-1.084-.322-1.084-.834Zm9.944 2.534c.49 0 .966-.044 1.237-.103v-1.853a5.19 5.19 0 0 1-.651.029c-.674 0-.982-.293-.982-.908v-3.428h1.633V9.554h-1.633V7.687h-2.6v1.867h-1.245v1.904h1.245v4.014c0 1.597.85 2.249 2.996 2.249Zm2.267-.015h2.593v-4.658c0-.938.498-1.575 1.34-1.575.879 0 1.282.557 1.282 1.546v4.687h2.593V12.44c0-1.956-.945-3.076-2.754-3.076-1.15 0-1.97.571-2.322 1.465h-.139V6.5h-2.593v11.206Zm12.719.19c2.615 0 3.611-1.53 3.846-2.504l.022-.088-2.373.007-.015.029c-.117.213-.564.711-1.428.711-.996 0-1.597-.674-1.619-1.839h5.486v-.747c0-2.49-1.56-4.101-4.014-4.101-2.461 0-4.021 1.633-4.021 4.262v.008c0 2.644 1.56 4.262 4.116 4.262Zm-.036-6.687c.805 0 1.377.52 1.501 1.495h-3.003c.125-.96.703-1.495 1.502-1.495Zm4.816 6.497h2.593v-4.314c0-1.128.71-1.78 1.926-1.78.366 0 .74.052 1.084.139V9.562a2.733 2.733 0 0 0-.879-.132c-1.04 0-1.757.52-1.992 1.421h-.139V9.554h-2.593v8.152Zm6.443 0h7.177v-2.161h-4.489V7.137h-2.688v10.569Zm10.36.125c1.04 0 1.912-.44 2.271-1.136h.139v1.011h2.549v-5.559c0-1.758-1.282-2.783-3.53-2.783-2.205 0-3.611.989-3.758 2.49l-.007.088h2.351l.015-.037c.154-.41.571-.637 1.252-.637.718 0 1.128.33 1.128.879v.637l-1.78.103c-2.102.132-3.259.988-3.259 2.468v.015c0 1.486 1.069 2.461 2.629 2.461Zm-.131-2.644v-.015c0-.484.402-.791 1.171-.842l1.37-.088v.534c0 .703-.637 1.245-1.457 1.245-.652 0-1.084-.322-1.084-.834Zm7.233 5.397c2.3 0 3.589-.82 4.336-3.142l2.571-7.888h-2.74l-1.45 5.911h-.154l-1.45-5.911h-2.863l2.783 8.152-.037.227c-.08.476-.527.747-1.304.747-.212 0-.424 0-.571-.007v1.904c.293.007.586.007.879.007Zm10.896-2.688c2.614 0 3.61-1.53 3.845-2.504l.022-.088-2.373.007-.015.029c-.117.213-.564.711-1.428.711-.996 0-1.597-.674-1.619-1.839h5.486v-.747c0-2.49-1.56-4.101-4.014-4.101-2.461 0-4.021 1.633-4.021 4.262v.008c0 2.644 1.56 4.262 4.117 4.262Zm-.037-6.687c.806 0 1.377.52 1.501 1.495h-3.003c.125-.96.704-1.495 1.502-1.495Zm4.816 6.497h2.593v-4.314c0-1.128.711-1.78 1.926-1.78.367 0 .74.052 1.084.139V9.562a2.733 2.733 0 0 0-.879-.132c-1.04 0-1.757.52-1.992 1.421h-.139V9.554h-2.593v8.152Zm9.468.19c2.212 0 3.735-1.083 3.735-2.775v-.008c0-1.223-.769-1.911-2.454-2.248l-1.406-.279c-.776-.161-1.025-.373-1.025-.739v-.015c0-.454.432-.725 1.076-.725.718 0 1.121.381 1.202.718l.014.051h2.373v-.037c-.044-1.303-1.23-2.475-3.589-2.475-2.19 0-3.581 1.018-3.581 2.644v.007c0 1.245.805 2.066 2.38 2.381l1.406.278c.74.154 1.018.373 1.018.754v.008c0 .439-.446.71-1.142.71-.754 0-1.165-.315-1.318-.732l-.015-.044h-2.52v.051c.162 1.421 1.429 2.475 3.846 2.475Z' style='fill:none;fill-rule:nonzero;stroke:%23000;stroke-opacity:.3;stroke-width:3px' transform='translate(-2.33)'/%3E%3Cpath d='M27.391 17.706h2.534l1.736-6.475h.132l1.765 6.475h2.52l2.761-10.569H36.07l-1.384 7.009h-.132l-1.75-7.009H30.65l-1.692 7.009h-.131L27.42 7.137h-2.79l2.761 10.569Zm15.092.19c2.615 0 3.611-1.53 3.846-2.504l.022-.088-2.373.007-.015.029c-.117.213-.564.711-1.428.711-.996 0-1.597-.674-1.619-1.839h5.486v-.747c0-2.49-1.56-4.101-4.014-4.101-2.461 0-4.021 1.633-4.021 4.262v.008c0 2.644 1.56 4.262 4.116 4.262Zm-.036-6.687c.805 0 1.377.52 1.501 1.495h-3.003c.125-.96.703-1.495 1.502-1.495Zm7.028 6.622c1.04 0 1.912-.44 2.271-1.136h.139v1.011h2.549v-5.559c0-1.758-1.282-2.783-3.531-2.783-2.204 0-3.611.989-3.757 2.49l-.007.088h2.351l.014-.037c.154-.41.572-.637 1.253-.637.718 0 1.128.33 1.128.879v.637l-1.78.103c-2.102.132-3.259.988-3.259 2.468v.015c0 1.486 1.069 2.461 2.629 2.461Zm-.132-2.644v-.015c0-.484.403-.791 1.172-.842l1.37-.088v.534c0 .703-.637 1.245-1.458 1.245-.652 0-1.084-.322-1.084-.834Zm9.944 2.534c.49 0 .966-.044 1.237-.103v-1.853a5.19 5.19 0 0 1-.651.029c-.674 0-.982-.293-.982-.908v-3.428h1.633V9.554h-1.633V7.687h-2.6v1.867h-1.245v1.904h1.245v4.014c0 1.597.85 2.249 2.996 2.249Zm2.267-.015h2.593v-4.658c0-.938.498-1.575 1.34-1.575.879 0 1.282.557 1.282 1.546v4.687h2.593V12.44c0-1.956-.945-3.076-2.754-3.076-1.15 0-1.97.571-2.322 1.465h-.139V6.5h-2.593v11.206Zm12.719.19c2.615 0 3.611-1.53 3.846-2.504l.022-.088-2.373.007-.015.029c-.117.213-.564.711-1.428.711-.996 0-1.597-.674-1.619-1.839h5.486v-.747c0-2.49-1.56-4.101-4.014-4.101-2.461 0-4.021 1.633-4.021 4.262v.008c0 2.644 1.56 4.262 4.116 4.262Zm-.036-6.687c.805 0 1.377.52 1.501 1.495h-3.003c.125-.96.703-1.495 1.502-1.495Zm4.816 6.497h2.593v-4.314c0-1.128.71-1.78 1.926-1.78.366 0 .74.052 1.084.139V9.562a2.733 2.733 0 0 0-.879-.132c-1.04 0-1.757.52-1.992 1.421h-.139V9.554h-2.593v8.152Zm6.443 0h7.177v-2.161h-4.489V7.137h-2.688v10.569Zm10.36.125c1.04 0 1.912-.44 2.271-1.136h.139v1.011h2.549v-5.559c0-1.758-1.282-2.783-3.53-2.783-2.205 0-3.611.989-3.758 2.49l-.007.088h2.351l.015-.037c.154-.41.571-.637 1.252-.637.718 0 1.128.33 1.128.879v.637l-1.78.103c-2.102.132-3.259.988-3.259 2.468v.015c0 1.486 1.069 2.461 2.629 2.461Zm-.131-2.644v-.015c0-.484.402-.791 1.171-.842l1.37-.088v.534c0 .703-.637 1.245-1.457 1.245-.652 0-1.084-.322-1.084-.834Zm7.233 5.397c2.3 0 3.589-.82 4.336-3.142l2.571-7.888h-2.74l-1.45 5.911h-.154l-1.45-5.911h-2.863l2.783 8.152-.037.227c-.08.476-.527.747-1.304.747-.212 0-.424 0-.571-.007v1.904c.293.007.586.007.879.007Zm10.896-2.688c2.614 0 3.61-1.53 3.845-2.504l.022-.088-2.373.007-.015.029c-.117.213-.564.711-1.428.711-.996 0-1.597-.674-1.619-1.839h5.486v-.747c0-2.49-1.56-4.101-4.014-4.101-2.461 0-4.021 1.633-4.021 4.262v.008c0 2.644 1.56 4.262 4.117 4.262Zm-.037-6.687c.806 0 1.377.52 1.501 1.495h-3.003c.125-.96.704-1.495 1.502-1.495Zm4.816 6.497h2.593v-4.314c0-1.128.711-1.78 1.926-1.78.367 0 .74.052 1.084.139V9.562a2.733 2.733 0 0 0-.879-.132c-1.04 0-1.757.52-1.992 1.421h-.139V9.554h-2.593v8.152Zm9.468.19c2.212 0 3.735-1.083 3.735-2.775v-.008c0-1.223-.769-1.911-2.454-2.248l-1.406-.279c-.776-.161-1.025-.373-1.025-.739v-.015c0-.454.432-.725 1.076-.725.718 0 1.121.381 1.202.718l.014.051h2.373v-.037c-.044-1.303-1.23-2.475-3.589-2.475-2.19 0-3.581 1.018-3.581 2.644v.007c0 1.245.805 2.066 2.38 2.381l1.406.278c.74.154 1.018.373 1.018.754v.008c0 .439-.446.71-1.142.71-.754 0-1.165-.315-1.318-.732l-.015-.044h-2.52v.051c.162 1.421 1.429 2.475 3.846 2.475Z' style='fill:%23fff;fill-rule:nonzero' transform='translate(-2.33)'/%3E%3Cpath d='m6.107 9.12-2.749 1.193a.68.68 0 0 0-.408.628c0 .275.16.522.407.629l2.75 1.193-2.749 1.192a.684.684 0 0 0-.408.63c0 .275.16.521.407.628l6.213 2.696a1.103 1.103 0 0 0 .877 0l6.212-2.695a.683.683 0 0 0 .408-.629.682.682 0 0 0-.407-.629l-2.75-1.193 2.749-1.193a.683.683 0 0 0 .409-.629.68.68 0 0 0-.408-.628l-2.75-1.194-1.144.497 3.054 1.326-5.736 2.488a.181.181 0 0 1-.151 0l-5.736-2.489 3.054-1.325-1.144-.496Zm9.713 5.465-5.736 2.489a.189.189 0 0 1-.151 0l-5.736-2.49 3.054-1.325 2.319 1.006a1.09 1.09 0 0 0 .877 0l2.319-1.006 3.054 1.326Zm-2.289-7.966c-.011.04-.039.066-.083.079l-1.207.378v1.206a.122.122 0 0 1-.054.103.128.128 0 0 1-.12.016L10.86 8.03l-.744.978a.13.13 0 0 1-.107.051.134.134 0 0 1-.108-.051l-.744-.978-1.207.371c-.038.015-.078.01-.12-.016a.121.121 0 0 1-.053-.103V7.076l-1.208-.378c-.044-.013-.071-.039-.082-.079-.014-.045-.008-.083.016-.114l.744-.978-.744-.977a.121.121 0 0 1-.016-.114c.011-.04.038-.066.082-.079l1.208-.378V2.773c0-.042.017-.077.053-.103.042-.026.082-.032.12-.016l1.207.371.744-.978A.131.131 0 0 1 10.009 2c.047 0 .083.016.107.047l.744.978 1.207-.371c.039-.016.079-.01.12.016a.122.122 0 0 1 .054.103v1.206l1.207.378c.044.013.072.039.083.079a.119.119 0 0 1-.017.114l-.744.977.744.978c.025.031.031.069.017.114M12.39 5.527c0-.307-.063-.601-.188-.88a2.287 2.287 0 0 0-1.269-1.21 2.422 2.422 0 0 0-.924-.18c-.323 0-.631.06-.924.18a2.284 2.284 0 0 0-1.269 1.21 2.115 2.115 0 0 0-.188.88c0 .308.062.602.188.881a2.284 2.284 0 0 0 1.269 1.21c.293.12.601.18.924.18.322 0 .63-.06.924-.18a2.287 2.287 0 0 0 1.269-1.21c.125-.279.188-.573.188-.881' style='fill:none;fill-rule:nonzero;stroke:%23000;stroke-opacity:.3;stroke-width:2.4px' transform='matrix(1.25 0 0 1.25 -2.188 -1)'/%3E%3Cpath d='m6.107 9.12-2.749 1.193a.68.68 0 0 0-.408.628c0 .275.16.522.407.629l2.75 1.193-2.749 1.192a.684.684 0 0 0-.408.63c0 .275.16.521.407.628l6.213 2.696a1.103 1.103 0 0 0 .877 0l6.212-2.695a.683.683 0 0 0 .408-.629.682.682 0 0 0-.407-.629l-2.75-1.193 2.749-1.193a.683.683 0 0 0 .409-.629.68.68 0 0 0-.408-.628l-2.75-1.194-1.144.497 3.054 1.326-5.736 2.488a.181.181 0 0 1-.151 0l-5.736-2.489 3.054-1.325-1.144-.496Zm9.713 5.465-5.736 2.489a.189.189 0 0 1-.151 0l-5.736-2.49 3.054-1.325 2.319 1.006a1.09 1.09 0 0 0 .877 0l2.319-1.006 3.054 1.326Zm-2.289-7.966c-.011.04-.039.066-.083.079l-1.207.378v1.206a.122.122 0 0 1-.054.103.128.128 0 0 1-.12.016L10.86 8.03l-.744.978a.13.13 0 0 1-.107.051.134.134 0 0 1-.108-.051l-.744-.978-1.207.371c-.038.015-.078.01-.12-.016a.121.121 0 0 1-.053-.103V7.076l-1.208-.378c-.044-.013-.071-.039-.082-.079-.014-.045-.008-.083.016-.114l.744-.978-.744-.977a.121.121 0 0 1-.016-.114c.011-.04.038-.066.082-.079l1.208-.378V2.773c0-.042.017-.077.053-.103.042-.026.082-.032.12-.016l1.207.371.744-.978A.131.131 0 0 1 10.009 2c.047 0 .083.016.107.047l.744.978 1.207-.371c.039-.016.079-.01.12.016a.122.122 0 0 1 .054.103v1.206l1.207.378c.044.013.072.039.083.079a.119.119 0 0 1-.017.114l-.744.977.744.978c.025.031.031.069.017.114M12.39 5.527c0-.307-.063-.601-.188-.88a2.287 2.287 0 0 0-1.269-1.21 2.422 2.422 0 0 0-.924-.18c-.323 0-.631.06-.924.18a2.284 2.284 0 0 0-1.269 1.21 2.115 2.115 0 0 0-.188.88c0 .308.062.602.188.881a2.284 2.284 0 0 0 1.269 1.21c.293.12.601.18.924.18.322 0 .63-.06.924-.18a2.287 2.287 0 0 0 1.269-1.21c.125-.279.188-.573.188-.881' style='fill:%23fff;fill-rule:nonzero' transform='matrix(1.25 0 0 1.25 -2.188 -1)'/%3E%3C/g%3E%3C/svg%3E");display:inline-block;height:23px;margin:-1.5px;vertical-align:middle;width:131px}`);
const zh = { for: "hpa-slider" }, Hh = /* @__PURE__ */ yl({
  __name: "WindFieldLayer",
  setup(a) {
    const e = bl("tangramApi");
    if (!e)
      throw new Error("assert: tangram api not provided");
    const t = Yn(300), n = Yn(300), r = Yn(null), s = (c) => {
      let T;
      if (c > 226.32)
        T = 288.15 / 65e-4 * (1 - Math.pow(c / 1013.25, 65e-4 * 287.05 / 9.80665));
      else {
        const L = 216.64999999999998, E = 1013.25 * Math.pow(L / 288.15, 9.80665 / (65e-4 * 287.05));
        T = 11e3 + L * 287.05 / 9.80665 * Math.log(E / c);
      }
      return Math.round(T * 3.28084 / 1e3) * 10;
    }, o = () => {
      n.value = s(t.value);
    }, i = () => {
      u();
    };
    async function l(c) {
      return new Promise((f, h) => {
        const p = new Image();
        p.onload = () => {
          const v = document.createElement("canvas");
          v.width = p.width, v.height = p.height;
          const I = v.getContext("2d");
          if (!I)
            return h(new Error("Could not get 2d context from canvas"));
          I.drawImage(p, 0, 0);
          const y = I.getImageData(0, 0, p.width, p.height);
          f({
            data: y.data,
            width: y.width,
            height: y.height
          });
        }, p.onerror = (v) => {
          h(v);
        }, p.src = c;
      });
    }
    const u = async () => {
      if (e.map.isReady.value) {
        r.value && (r.value.dispose(), r.value = null);
        try {
          const c = await fetch(`/weather/wind?isobaric=${t.value}`);
          if (!c.ok) throw new Error(`HTTP error! status: ${c.status}`);
          const { imageDataUri: f, bounds: h, imageUnscale: p } = await c.json(), v = await l(f), I = [
            [0, [37, 99, 235]],
            [10, [65, 171, 93]],
            [20, [253, 174, 97]],
            [30, [244, 109, 67]],
            [40, [215, 25, 28]],
            [50, [128, 0, 38]]
          ], y = new as({
            id: "wind-field-layer",
            image: v,
            imageType: xe.VECTOR,
            imageUnscale: p,
            bounds: h,
            numParticles: 1500,
            maxAge: 15,
            speedFactor: 20,
            width: 1,
            palette: I,
            animate: !0
          });
          r.value = e.map.addLayer(y);
        } catch (c) {
          console.error("Failed to fetch or display wind data:", c);
        }
      }
    };
    return vl(
      e.map.isReady,
      (c) => {
        c && u();
      },
      { immediate: !0 }
    ), xl(() => {
      n.value = s(t.value);
    }), wl(() => {
      r.value && (r.value.dispose(), r.value = null);
    }), (c, f) => (_l(), Il("div", {
      class: "wind-altitude-control",
      onMousedown: f[1] || (f[1] = Ss(() => {
      }, ["stop"])),
      onTouchstart: f[2] || (f[2] = Ss(() => {
      }, ["stop"]))
    }, [
      Ls("label", zh, Ms(t.value) + "hPa | FL" + Ms(n.value), 1),
      Cl(Ls("input", {
        id: "hpa-slider",
        "onUpdate:modelValue": f[0] || (f[0] = (h) => t.value = h),
        type: "range",
        min: "100",
        max: "1000",
        step: "50",
        onInput: o,
        onChange: i
      }, null, 544), [
        [El, t.value]
      ])
    ], 32));
  }
}), Zh = (a, e) => {
  const t = a.__vccOpts || a;
  for (const [n, r] of e)
    t[n] = r;
  return t;
}, jh = /* @__PURE__ */ Zh(Hh, [["__scopeId", "data-v-7a31b6fa"]]);
function zd(a, e) {
  a.ui.registerWidget("wind-field-layer", "MapOverlay", jh, {
    priority: e?.topbar_order
  });
}
export {
  zd as install
};
//# sourceMappingURL=index.js.map
