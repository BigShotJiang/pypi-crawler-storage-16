"""Singer package for extracting data from the PyPI Stats API."""
