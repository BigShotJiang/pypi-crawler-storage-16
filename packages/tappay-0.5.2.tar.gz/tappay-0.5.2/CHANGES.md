# 0.4.0

* Added more advanced features:
  - cancel refund
  - cancel capture
  - bind card
  - remove card

# 0.3.0

* Added method to support pay-by-token
  https://docs.tappaysdk.com/tutorial/zh/back.html#pay-by-card-token-api

# 0.2.0

* First release!
