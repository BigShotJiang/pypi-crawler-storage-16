# `tardy-pyutils`

A simple python package to hold some often used utility functions and make my
life easier.
