# stub to support existing import paths
from .generated.github import *  # NOQA
