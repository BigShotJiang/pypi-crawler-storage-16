"""TaskRepo - TaskWarrior-inspired CLI for managing tasks as markdown files in git repositories."""

from taskrepo.__version__ import __version__

__all__ = ["__version__"]
