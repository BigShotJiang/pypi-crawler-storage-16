# Development Team

### Current Contributors

**Miroslav Stoyanov** <br/>
Lead Developer <br/>
Oak Ridge National Lab

**Damien T. Lebrun-Grandie** <br/>
Conforming to standards and CI testing <br/>
Oak Ridge National Lab

**Paul Laiu** <br/>
Fortran and application integration <br/>
Oak Ridge National Lab

**Viktor Reshniak** <br/>
Fortran integration and build systems <br/>
Oak Ridge National Lab

**Guannan Zhang** <br/>
Core DREAM capabilities <br/>
Oak Ridge National Lab

### Former Contributors

**William Kong** <br/>
Developer <br/>
Exotic quadrature, optimization modules, libEnsemble integration, <br/>
many miscellaneous contributions <br/>
Oak Ridge National Lab

**Zack Morrow** <br/>
Core Fourier capabilities <br/>
North Carolina State University

**Nicholas Dexter** <br/>
Contributor to core functionality and API <br/>
University of Tennessee at Knoxville

**Clayton Webster** <br/>
Principal Investigator <br/>
Oak Ridge National Lab

**John Burkardt** <br/>
Core functionality <br/>
Florida State University

**Diego Galindo** <br/>
Contributor to core functionality and API <br/>
Oak Ridge National Lab

**Drayton Munster** <br/>
Core Wavelet capabilities <br/>
Virginia Tech
