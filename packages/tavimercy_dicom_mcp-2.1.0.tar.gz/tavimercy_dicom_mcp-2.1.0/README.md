# TaviMercy DICOM MCP

[![PyPI version](https://badge.fury.io/py/tavimercy-dicom-mcp.svg)](https://pypi.org/project/tavimercy-dicom-mcp/)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

基于 MCP (Model Context Protocol) 的 DICOM 医学影像文件分析工具。

## 特性

- 🔍 DICOM 文件扫描和解析
- 📊 医学影像序列分析（主动脉、二尖瓣）
- 📁 按患者和序列自动整理 DICOM 文件
- 📈 导出测量数据为 CSV 格式
- 🔌 完整的 MCP 协议支持
- 🌐 与 Orthanc PACS 服务器集成

## 安装

### 使用 pip 安装

```bash
pip install tavimercy-dicom-mcp
```

### 使用 uvx 直接运行（推荐）

```bash
uvx tavimercy-dicom-mcp
```

## MCP Server 配置

在 MCP 客户端配置文件中添加以下配置：

```json
{
  "mcpServers": {
    "tavimercy-dicom-mcp": {
      "command": "uvx",
      "args": [
        "tavimercy-dicom-mcp"
      ],
      "env": {
        "base_url": "https://your-server.com",
        "name": "your_username",
        "password": "your_password",
        "tel": "your_phone"
      }
    }
  }
}
```

**环境变量说明：**
- `base_url`: 服务器基础URL（必需）
- `name`: 用户名（可选，用于自动登录）
- `password`: 密码（可选，用于自动登录）
- `tel`: 手机号（可选，用于自动登录）

## 工具说明

### 1. scan-dicom-directory
扫描指定目录下所有可读的 .dcm 文件，汇总患者数、序列数、文件数和总字节数，返回 JSON 文本。

**参数：**
- `directory_path` (string): 待扫描的本地目录路径，绝对路径，必须存在且可读

### 2. parse-dicom-file
解析单个 DICOM 文件，提取 PatientID、PatientName、SeriesInstanceUID、SeriesDescription 等元数据，返回结构化 JSON。

**参数：**
- `file_path` (string): 待解析的本地 DICOM 文件路径，需指向实际存在的 .dcm 文件

### 3. analyze-dicom-directory
扫描目录中的 DICOM 序列，按 series_type 选择分析流程并上传到预配置的远端分析服务，返回上传结果及访问 URL。

**参数：**
- `directory_path` (string): 包含待分析 DICOM 序列的本地目录路径，必须存在且具备读取权限
- `series_type` (string): 分析流程类型，`1`=主动脉分析，`9`=二尖瓣分析

### 4. separate-dicom-files
按患者和序列拆分目录下的 DICOM 文件，生成新的子目录结构，并以 JSON 返回整理后的统计结果。

**参数：**
- `directory_path` (string): 待整理的顶层目录路径，执行过程中会在同级创建输出目录

### 5. get-analysis-result
根据 study_uid 查询分析结果，如果没有分析结果，需要进行 analyze-dicom-directory 工具上传分析，返回测量结果的 URL。

**参数：**
- `study_uid` (string): DICOM序列的 study_uid，用于查询分析结果

### 6. export-measurement-csv
导出账号下指定 StudyInstanceUID 数组的测量数值 CSV 文件，返回下载 URL。

**参数：**
- `studyInstanceUids` (array): StudyInstanceUID 数组，用于导出对应的测量数值 CSV 文件

## 开发

### 从源码安装

```bash
git clone https://github.com/jiancongzhang/tavimercy-dicom-mcp.git
cd tavimercy-dicom-mcp
uv sync
```

### 运行测试

```bash
uv run pytest
```

### 构建和发布

```bash
# 构建包
uv build

# 发布到 PyPI
uv publish --token YOUR_PYPI_TOKEN
```

## 技术栈

- **MCP**: Model Context Protocol 服务器实现
- **pydicom**: DICOM 文件解析
- **pyorthanc**: Orthanc PACS 服务器集成
- **pydantic**: 数据验证
- **requests**: HTTP 客户端

## 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

## 作者

Jiancong Zhang (1316795665@qq.com)

## 贡献

欢迎提交 Issue 和 Pull Request！

## 更新日志

### v2.0.0 (2025-12-10)
- 🎉 首次发布到 PyPI
- ✨ 完整的 MCP 协议支持
- 🔧 优化打包配置
- 📚 更新文档
