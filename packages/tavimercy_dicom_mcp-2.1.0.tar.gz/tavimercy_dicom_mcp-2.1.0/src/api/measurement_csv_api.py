"""
Measurement CSV export API module.
"""
import json
import logging
import traceback
import requests
from typing import Dict, Any, List

from src.utils.config_loader import get_default_config

logger = logging.getLogger(__name__)


async def export_measurement_csv(study_instance_uids: List[str]) -> Dict[str, Any]:
    """
    Export measurement CSV file for given StudyInstanceUIDs.
    
    Args:
        study_instance_uids: List of StudyInstanceUID strings
        
    Returns:
        Dictionary containing download URL and result information
    """
    try:
        config = get_default_config()
        base_url = config.get('base_url')
        cookie_val = config.get('cookie')
        
        logger.info(f"[export_measurement_csv] Config loaded - base_url: {base_url}, cookie: {cookie_val[:20] if cookie_val else None}...")
        
        if not base_url or not cookie_val:
            logger.error(f"[export_measurement_csv] Missing config - base_url: {base_url}, has_cookie: {bool(cookie_val)}")
            return {
                "content": [{
                    "type": "text",
                    "text": json.dumps({
                        "error": True,
                        "message": "Configuration error: Missing base_url or cookie."
                    }, ensure_ascii=False)
                }]
            }

        if not cookie_val.startswith("ls="):
            cookie = "ls=" + cookie_val
        else:
            cookie = cookie_val

        # API endpoint
        api_url = f"{base_url}/cad/case/measurement/export"
        
        # Request headers
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip, deflate",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Content-Type": "application/json",
            "Cookie": f"i18next=zh-CN; {cookie}",
            "Pragma": "no-cache",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0",
            "lang": "zh-CN"
        }
        
        # Request payload
        payload = {
            "studyInstanceUids": study_instance_uids
        }
        
        logger.info(f"Exporting measurement CSV for {len(study_instance_uids)} studies")
        logger.info(f"API URL: {api_url}")
        
        # Send POST request
        response = requests.post(
            api_url,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        response.raise_for_status()
        response_data = response.json()
        
        # Check if request was successful
        if response_data.get("success") and response_data.get("code") == 1:
            data = response_data.get("data", {})
            route = data.get("route", "")
            params = data.get("params", "")
            
            # Construct download URL
            if route and params:
                # Remove leading slash from route if present
                route = route.lstrip('/')
                download_url = f"{base_url}/{route}?{params}"
            else:
                # Fallback: use route and params from response directly
                route = response_data.get("route", "")
                params = response_data.get("params", "")
                if route and params:
                    route = route.lstrip('/')
                    download_url = f"{base_url}/{route}?{params}"
                else:
                    download_url = None
            
            result = {
                "success": True,
                "message": response_data.get("msg", "操作成功"),
                "download_url": download_url,
                "route": route,
                "params": params,
                "study_count": len(study_instance_uids)
            }
        else:
            result = {
                "success": False,
                "message": response_data.get("msg", "导出失败"),
                "error": response_data
            }
        
        return {
            "content": [{
                "type": "text",
                "text": json.dumps(result, ensure_ascii=False, indent=2)
            }]
        }
        
    except requests.exceptions.RequestException as e:
        error_info = f"Request failed: {str(e)}"
        logger.error(error_info)
        return {
            "content": [{
                "type": "text",
                "text": json.dumps({
                    "error": True,
                    "message": error_info
                }, ensure_ascii=False)
            }]
        }
    except Exception as e:
        error_info = f"Error during CSV export: {str(e)}\n{traceback.format_exc()}"
        logger.error(error_info)
        return {
            "content": [{
                "type": "text",
                "text": json.dumps({
                    "error": True,
                    "message": error_info
                }, ensure_ascii=False)
            }]
        }

