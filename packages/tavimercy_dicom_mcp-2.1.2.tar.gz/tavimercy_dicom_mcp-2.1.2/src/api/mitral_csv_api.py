"""
Mitral measurement CSV export API module.
"""
import json
import logging
import traceback
import requests
from typing import Dict, Any, List

from src.utils.config_loader import get_default_config

logger = logging.getLogger(__name__)


async def export_mitral_measurement_csv(study_instance_uids: List[str]) -> Dict[str, Any]:
    """
    Export mitral measurement CSV file for given StudyInstanceUIDs.
    
    Args:
        study_instance_uids: List of StudyInstanceUID strings
        
    Returns:
        Dictionary containing download URL and result information
    """
    try:
        config = get_default_config()
        base_url = config.get('base_url')
        cookie_val = config.get('cookie')
        
        logger.info(f"[export_mitral_measurement_csv] Config loaded - base_url: {base_url}, cookie: {cookie_val[:20] if cookie_val else None}...")
        
        if not base_url or not cookie_val:
            logger.error(f"[export_mitral_measurement_csv] Missing config - base_url: {base_url}, has_cookie: {bool(cookie_val)}")
            return {
                "content": [{
                    "type": "text",
                    "text": json.dumps({
                        "error": True,
                        "message": "Configuration error: Missing base_url or cookie."
                    }, ensure_ascii=False)
                }]
            }

        if not cookie_val.startswith("ls="):
            cookie = "ls=" + cookie_val
        else:
            cookie = cookie_val

        # API endpoint for mitral measurements
        api_url = f"{base_url}/api/v1/export/mitral-measurements-summary"
        
        # Request headers
        headers = {
            "Content-Type": "application/json",
            "Cookie": cookie
        }
        
        # Request payload
        payload = {
            "studyInstanceUids": study_instance_uids
        }
        
        logger.info(f"Exporting mitral measurement CSV for {len(study_instance_uids)} studies")
        logger.info(f"API URL: {api_url}")
        
        # Send POST request
        response = requests.post(
            api_url,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        # Check response status
        response.raise_for_status()
        
        # Check if response is CSV file (content-type: text/csv; charset=utf-8)
        content_type = response.headers.get('Content-Type', '')
        transfer_encoding = response.headers.get('Transfer-Encoding', '')
        content_type_lower = content_type.lower()
        
        # Check if response is CSV content
        # content-type 通常是 text/csv; charset=utf-8，transfer-encoding 是 chunked
        if 'csv' in content_type_lower or 'octet-stream' in content_type_lower:
            # Response is CSV file content (requests automatically handles chunked transfer)
            csv_content = response.text
            
            result = {
                "success": True,
                "message": "二尖瓣测量数据导出成功",
                "csv_content": csv_content,
                "content_type": content_type,
                "transfer_encoding": transfer_encoding,
                "study_count": len(study_instance_uids),
                "file_size": len(csv_content.encode('utf-8'))
            }
        else:
            # Try to parse as JSON
            try:
                response_data = response.json()
                # Check if request was successful
                # API returns code: 1 for success, code: 1000+ for errors
                code = response_data.get("code")
                is_success = response_data.get("success", False) or (code == 1)
                
                if is_success and code != 1000:
                    # If response contains download URL
                    download_url = response_data.get("download_url") or response_data.get("url")
                    if download_url:
                        result = {
                            "success": True,
                            "message": response_data.get("msg", "操作成功"),
                            "download_url": download_url,
                            "study_count": len(study_instance_uids)
                        }
                    else:
                        result = {
                            "success": True,
                            "message": response_data.get("msg", "操作成功"),
                            "response": response_data
                        }
                else:
                    # API returned error (code: 1000 or other error codes)
                    result = {
                        "success": False,
                        "message": response_data.get("msg", "导出失败"),
                        "code": code,
                        "error": response_data
                    }
            except json.JSONDecodeError:
                # Response might be CSV even if content-type is not set correctly
                # Check if response text looks like CSV (starts with common CSV patterns)
                response_text = response.text
                if response_text and (',' in response_text or '\t' in response_text):
                    # Likely CSV content
                    result = {
                        "success": True,
                        "message": "二尖瓣测量数据导出成功",
                        "csv_content": response_text,
                        "content_type": content_type or "text/csv",
                        "study_count": len(study_instance_uids),
                        "file_size": len(response_text.encode('utf-8'))
                    }
                else:
                    # Unknown format
                    result = {
                        "success": False,
                        "message": f"Unexpected response format: {content_type}",
                        "status_code": response.status_code,
                        "response_preview": response_text[:200] if response_text else None
                    }
        
        return {
            "content": [{
                "type": "text",
                "text": json.dumps(result, ensure_ascii=False, indent=2)
            }]
        }
        
    except requests.exceptions.RequestException as e:
        error_info = f"Request failed: {str(e)}"
        logger.error(error_info)
        return {
            "content": [{
                "type": "text",
                "text": json.dumps({
                    "error": True,
                    "message": error_info
                }, ensure_ascii=False)
            }]
        }
    except Exception as e:
        error_info = f"Error during mitral CSV export: {str(e)}\n{traceback.format_exc()}"
        logger.error(error_info)
        return {
            "content": [{
                "type": "text",
                "text": json.dumps({
                    "error": True,
                    "message": error_info
                }, ensure_ascii=False)
            }]
        }
