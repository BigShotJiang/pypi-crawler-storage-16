from .primitives import tag, dissolve_tags, iter_tags, inject

__all__ = ["tag", "dissolve_tags", "iter_tags", "inject"]