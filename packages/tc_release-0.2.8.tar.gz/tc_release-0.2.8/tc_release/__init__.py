from .tc_release import main
from .version import __version__  # noqa: F401

__all__ = ["__version__", "main"]
