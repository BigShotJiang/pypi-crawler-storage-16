from .tc_release import main

main()
