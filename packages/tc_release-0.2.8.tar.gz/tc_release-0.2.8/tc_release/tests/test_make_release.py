from __future__ import annotations

import os
from pathlib import Path

import pytest
from git import GitCommandError

from ..tc_release import Repo, initialize_repo, main, make_release


def set_git_identity(repo: Repo) -> None:
    """
    Sets a local git username/email for commits for a repo.

    This is required or else the GHA CI fails due to no identity.
    """
    repo.config_writer().set_value("user", "name", "pytest").release()
    repo.config_writer().set_value("user", "email", "pytest@test.com").release()


def local_configure_and_fetch_repo(repo: Repo, repo_url: str) -> None:
    """
    Fetch repo data and tags.
    This also now handles the case where the repo is already created
    """
    try:
        origin = repo.remote("origin")
        url_match = (origin.url in repo_url) or (repo_url in origin.url)
        if not url_match:
            origin.set_url(repo_url, old_url=origin.url)
    except ValueError:
        origin = repo.create_remote("origin", str(repo_url))

    if not origin.exists():
        raise RuntimeError("Repo URL does not exist!")

    if not origin.refs or not any(["master" in ref.name for ref in origin.refs]):
        origin.fetch(["master:refs/remotes/origin/master",])

    if not repo.tags:
        origin.fetch(["refs/tags/*:refs/tags/*",])


@pytest.fixture
def monkeypatch_configure_and_fetch_repo(monkeypatch):
    monkeypatch.setattr("tc_release.tc_release.configure_and_fetch_repo",
                        local_configure_and_fetch_repo)


@pytest.fixture
def cleanup_submodules():
    """Reset to the tag and commit provided during the test."""
    info_dict = {}
    yield info_dict
    print(info_dict)
    repo = info_dict.get('repo', None)
    if not repo:
        # test failed before information got passed back.
        return

    version = info_dict['version']
    latest_commit = info_dict['latest_commit']

    repo.git.reset("--hard", latest_commit)
    try:
        repo.delete_tag(repo.tag(f"v{version}"))
    except GitCommandError:
        pass
    assert repo.head.commit == latest_commit
    assert not repo.untracked_files


@pytest.mark.parametrize(
    "reponame,plcproj",
    [
        ('lcls-plc-lfe-vac', 'plc_lfe_vac'),
        ('lcls-plc-lfe-motion', None),
        ('lcls-plc-tmo-optics', None),
        ('lcls-twincat-common-components', None),
        ('lcls-twincat-general', None),
        ('lcls-twincat-motion', None),
        ('lcls-twincat-physics', None),
        ('lcls-twincat-pmps', None),
        ('lcls-twincat-vacuum', None),
    ],
)
def test_dry_run(
    monkeypatch: pytest.MonkeyPatch,
    reponame: str,
    plcproj: str | None,
    cleanup_submodules,
    monkeypatch_configure_and_fetch_repo,
):
    """
    Test that the dry run works on a few repositories.
    """
    # Drop into the subfolder to do the work here
    monkeypatch.chdir(Path(__file__).parent / 'projects')
    # Run the part of the release up to but not including git push
    working_dir = os.path.join(os.getcwd(), reponame)
    repo = initialize_repo(working_dir=working_dir)
    # grab last commit hash
    latest_commit = repo.head.commit
    version = '999.999.999'

    # pass info back to the cleanup fixture
    cleanup_submodules['repo'] = repo
    cleanup_submodules['version'] = version
    cleanup_submodules['latest_commit'] = latest_commit

    assert not repo.untracked_files
    set_git_identity(repo=repo)
    repo_url = f'https://github.com/pcdshub/{reponame}'
    major, minor, fix = version.split('.')
    make_release(
        repo=repo,
        working_dir=working_dir,
        full_version_string=f'v{version}',
        repo_url=repo_url,
        select_plcproj=plcproj,
        dry_run=True,
    )
    # Find our version string in the two places it belongs
    # It should be in a file with extension .plcproj embedded in the xml
    if plcproj is None:
        plcproj_path = next(Path(working_dir).rglob('*.plcproj'))
    else:
        plcproj_path = next(Path(working_dir).rglob(f'{plcproj}.plcproj'))
    with plcproj_path.open() as fd:
        assert f'<ProjectVersion>{version}</ProjectVersion>' in fd.read()
    # It should also be in a file named Global_Version.TcGVL with ST struct
    global_version = next(Path(working_dir).rglob('Global_Version.TcGVL'))
    with global_version.open() as fd:
        assert (
            f': ST_LibVersion := (iMajor := {major}, iMinor := {minor}, '
            f"iBuild := {fix}, iRevision := 0, nFlags := 1, "
            f"sVersion := '{version}');"
        ) in fd.read()


def test_dry_run_from_main(
        monkeypatch: pytest.MonkeyPatch,
        monkeypatch_configure_and_fetch_repo,
        cleanup_submodules
):
    """
    For at least one case, go through the full main input.

    This is just to check for exceptions/typos in the invokation of inner
    utilites, which should be tested independently of running through
    main.
    """
    reponame = 'lcls-twincat-general'
    url = f'https://github.com/pcdshub/{reponame}'
    # Drop into the subfolder to do the work here
    monkeypatch.chdir(Path(__file__).parent / 'projects')
    this_working_dir = os.path.join(os.getcwd(), reponame)

    def local_repo_init(working_dir: str) -> Repo:
        # set the working dir to the checked-out submodule dir.
        repo = initialize_repo(working_dir=this_working_dir)
        # monkeypatch a local git username/email to help the ci
        set_git_identity(repo=repo)
        return repo

    monkeypatch.setattr("tc_release.tc_release.initialize_repo", local_repo_init)

    def local_make_release(
        repo: Repo,
        working_dir: str,
        full_version_string: str,
        repo_url: str,
        select_plcproj: str | None = None,
        dry_run: bool = False,
    ):
        return make_release(
            repo,
            this_working_dir,  # redirect to our local submodule checkout
            full_version_string,
            repo_url,
            select_plcproj,
            dry_run
        )

    monkeypatch.setattr("tc_release.tc_release.make_release", local_make_release)

    # pass info back to the cleanup fixture
    repo = initialize_repo(working_dir=this_working_dir)
    latest_commit = repo.head.commit
    assert not repo.untracked_files
    version = "888.888.888"

    cleanup_submodules['repo'] = repo
    cleanup_submodules['version'] = version
    cleanup_submodules['latest_commit'] = latest_commit

    # Hope for no issues
    assert main([
        '--dry-run',
        'v888.888.888',
        url,
    ]) == 0
