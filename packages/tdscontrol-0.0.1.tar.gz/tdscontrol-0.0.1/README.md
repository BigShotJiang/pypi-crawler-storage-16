# TDS Control

A software package for the analysis and controller-design of time-delay systems.

