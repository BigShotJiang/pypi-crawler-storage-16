# ENGR 133 Team 19 Custom Utilities Library

This is a package containing some customized code that was used previously in group and individual projects across engr133 and deemed to be useful enough to reserve a package <br/>

link to package view page: https://pypi.org/project/Team-19-Custom-Utils-Lib <br/>
push new commits with "python3 -m build" and run "python -m twine upload dist/*" with correct workspace setup <br/>
install on local device before using package: run "python3 -m pip install Team_19_Custom_Utils_Lib" <br/>
if there are any errors with undefined functions, run "pip install --upgrade Team-19-Custom-Utils-Lib" to pull the latest version <br/>