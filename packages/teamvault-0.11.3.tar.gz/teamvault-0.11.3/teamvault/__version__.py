__version__ = "0.11.3"  # Also change in pyproject.toml
