from django.apps import AppConfig


class AuditConfig(AppConfig):
    name = 'teamvault.apps.audit'
