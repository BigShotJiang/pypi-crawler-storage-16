/**
 * @file _core.cpp
 * @brief TechKit Python bindings using pybind11
 * 
 * This module exposes TechKit's C API to Python with NumPy integration
 * for high-performance technical analysis.
 */

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <pybind11/stl.h>
#include <techkit/techkit_c.h>
#include <cmath>
#include <string>
#include <stdexcept>
#include <tuple>

namespace py = pybind11;

/*============================================================
 * Result Types
 *============================================================*/

struct PyResult {
    double value;
    bool valid;
};

struct PyMACDResult {
    double macd;
    double signal;
    double histogram;
    bool valid;
};

struct PyBBandsResult {
    double upper;
    double middle;
    double lower;
    bool valid;
};

struct PyStochResult {
    double slowk;
    double slowd;
    bool valid;
};

struct PyAroonResult {
    double up;
    double down;
    bool valid;
};

struct PyADXResult {
    double plus_di;
    double minus_di;
    double adx;
    bool valid;
};

struct PyHTPhasorResult {
    double inphase;
    double quadrature;
    bool valid;
};

struct PyHTSineResult {
    double sine;
    double leadsine;
    bool valid;
};

struct PyMinMaxResult {
    double min;
    double max;
    bool valid;
};

/*============================================================
 * Phase 2 Result Types
 *============================================================*/

struct PyDrawdownResult {
    double drawdown;
    double max_drawdown;
    int duration;
    int max_duration;
    bool valid;
};

struct PyZigZagResult {
    double zigzag_value;
    int direction;
    bool is_pivot;
    int pivot_type;
    double last_pivot_price;
    int bars_since_pivot;
    bool valid;
};

struct PySwingResult {
    bool is_swing_high;
    bool is_swing_low;
    double swing_high_price;
    double swing_low_price;
    int bars_ago;
    bool valid;
};

struct PyPivotResult {
    double pp;
    double r1, r2, r3;
    double s1, s2, s3;
    bool valid;
};

struct PyHarmonicResult {
    int pattern;           // tk_harmonic_type
    int direction;
    double x_price, a_price, b_price, c_price, d_price;
    int x_bar, a_bar, b_bar, c_bar, d_bar;
    double xab_ratio, abc_ratio, bcd_ratio, xad_ratio;
    double prz_high, prz_low;
    double score;
    bool is_complete;
    bool valid;
};

struct PyChartPatternResult {
    int pattern;           // tk_chart_pattern_type
    int direction;
    double neckline;
    double neckline_slope;
    double target_price;
    std::vector<double> point_prices;
    std::vector<int> point_bars;
    int num_points;
    double height;
    double width_bars;
    double symmetry_score;
    double score;
    bool is_complete;
    bool is_confirmed;
    double breakout_price;
    bool valid;
};

/*============================================================
 * Candlestick Pattern Result Type
 *============================================================*/

// CDL Pattern result - returns integer signal
struct PyCDLResult {
    int signal;      // +100 (bullish), -100 (bearish), 0 (none)
    bool valid;
};

/*============================================================
 * Base Indicator Wrapper
 *============================================================*/

class PyIndicator {
public:
    explicit PyIndicator(tk_indicator ind) : ind_(ind) {
        if (!ind_) throw std::runtime_error("Failed to create indicator");
    }
    
    ~PyIndicator() {
        if (ind_) tk_free(ind_);
    }
    
    // Disable copy, enable move
    PyIndicator(const PyIndicator&) = delete;
    PyIndicator& operator=(const PyIndicator&) = delete;
    PyIndicator(PyIndicator&& other) noexcept : ind_(other.ind_) { 
        other.ind_ = nullptr; 
    }
    PyIndicator& operator=(PyIndicator&& other) noexcept {
        if (this != &other) {
            if (ind_) tk_free(ind_);
            ind_ = other.ind_;
            other.ind_ = nullptr;
        }
        return *this;
    }
    
    // Incremental update (single value)
    PyResult update(double value) {
        tk_result r = tk_update(ind_, value);
        return {r.value, r.valid != 0};
    }
    
    // Incremental update (OHLCV)
    PyResult update_ohlcv(double open, double high, double low, 
                          double close, double volume) {
        tk_ohlcv bar = {open, high, low, close, volume};
        tk_result r = tk_update_ohlcv(ind_, &bar);
        return {r.value, r.valid != 0};
    }
    
    // NumPy batch calculation (zero-copy input)
    py::array_t<double> calculate(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        if (buf.ndim != 1) {
            throw std::runtime_error("Input must be 1-dimensional");
        }
        
        double* data = static_cast<double*>(buf.ptr);
        size_t size = static_cast<size_t>(buf.size);
        
        // Create output array
        py::array_t<double> output(size);
        double* out = static_cast<double*>(output.request().ptr);
        
        // Reset and calculate
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_result r = tk_update(ind_, data[i]);
            out[i] = r.valid ? r.value : std::nan("");
        }
        return output;
    }
    
    // Batch calculation for OHLCV indicators
    py::array_t<double> calculate_ohlcv(
        py::array_t<double, py::array::c_style> open,
        py::array_t<double, py::array::c_style> high,
        py::array_t<double, py::array::c_style> low,
        py::array_t<double, py::array::c_style> close,
        py::array_t<double, py::array::c_style> volume
    ) {
        size_t size = static_cast<size_t>(close.request().size);
        const double* o = static_cast<const double*>(open.request().ptr);
        const double* h = static_cast<const double*>(high.request().ptr);
        const double* l = static_cast<const double*>(low.request().ptr);
        const double* c = static_cast<const double*>(close.request().ptr);
        const double* v = static_cast<const double*>(volume.request().ptr);
        
        py::array_t<double> output(size);
        double* out = static_cast<double*>(output.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ohlcv bar = {o[i], h[i], l[i], c[i], v[i]};
            tk_result r = tk_update_ohlcv(ind_, &bar);
            out[i] = r.valid ? r.value : std::nan("");
        }
        return output;
    }
    
    void reset() { tk_reset(ind_); }
    bool is_ready() const { return tk_is_ready(ind_) != 0; }
    int lookback() const { return tk_lookback(ind_); }
    std::string name() const { return tk_name(ind_); }

protected:
    tk_indicator ind_;
};

/*============================================================
 * Multi-Output Indicator Wrappers
 *============================================================*/

// MACD Indicator with 3 outputs
class PyMACDIndicator : public PyIndicator {
protected:
    // Protected constructor for derived classes
    PyMACDIndicator(tk_indicator ind) : PyIndicator(ind) {}
    
public:
    PyMACDIndicator(int fast, int slow, int signal) 
        : PyIndicator(tk_macd_new(fast, slow, signal)) {}
    
    PyMACDResult update_macd(double value) {
        tk_macd_result r = tk_macd_update(ind_, value);
        return {r.macd, r.signal, r.histogram, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>, py::array_t<double>>
    calculate_macd(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        size_t size = static_cast<size_t>(buf.size);
        double* data = static_cast<double*>(buf.ptr);
        
        py::array_t<double> out_macd(size);
        py::array_t<double> out_signal(size);
        py::array_t<double> out_hist(size);
        
        double* macd = static_cast<double*>(out_macd.request().ptr);
        double* signal = static_cast<double*>(out_signal.request().ptr);
        double* hist = static_cast<double*>(out_hist.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_macd_result r = tk_macd_update(ind_, data[i]);
            if (r.valid) {
                macd[i] = r.macd;
                signal[i] = r.signal;
                hist[i] = r.histogram;
            } else {
                macd[i] = signal[i] = hist[i] = std::nan("");
            }
        }
        return std::make_tuple(out_macd, out_signal, out_hist);
    }
};

// MACDEXT - Extended MACD with MA type selection
class PyMACDEXTIndicator : public PyIndicator {
public:
    PyMACDEXTIndicator(int fast, int fast_ma, int slow, int slow_ma, int signal, int signal_ma)
        : PyIndicator(tk_macdext_new(fast, fast_ma, slow, slow_ma, signal, signal_ma)) {}
    
    PyMACDResult update_macd(double value) {
        tk_macd_result r = tk_macdext_update(ind_, value);
        return {r.macd, r.signal, r.histogram, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>, py::array_t<double>>
    calculate_macd(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        size_t size = static_cast<size_t>(buf.size);
        double* data = static_cast<double*>(buf.ptr);
        
        py::array_t<double> out_macd(size);
        py::array_t<double> out_signal(size);
        py::array_t<double> out_hist(size);
        
        double* macd = static_cast<double*>(out_macd.request().ptr);
        double* signal = static_cast<double*>(out_signal.request().ptr);
        double* hist = static_cast<double*>(out_hist.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_macd_result r = tk_macdext_update(ind_, data[i]);
            if (r.valid) {
                macd[i] = r.macd;
                signal[i] = r.signal;
                hist[i] = r.histogram;
            } else {
                macd[i] = signal[i] = hist[i] = std::nan("");
            }
        }
        return std::make_tuple(out_macd, out_signal, out_hist);
    }
};

// MACDFIX - Fixed Period MACD (12, 26, signal)
class PyMACDFIXIndicator : public PyIndicator {
public:
    explicit PyMACDFIXIndicator(int signal_period)
        : PyIndicator(tk_macdfix_new(signal_period)) {}
    
    PyMACDResult update_macd(double value) {
        tk_macd_result r = tk_macdfix_update(ind_, value);
        return {r.macd, r.signal, r.histogram, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>, py::array_t<double>>
    calculate_macd(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        size_t size = static_cast<size_t>(buf.size);
        double* data = static_cast<double*>(buf.ptr);
        
        py::array_t<double> out_macd(size);
        py::array_t<double> out_signal(size);
        py::array_t<double> out_hist(size);
        
        double* macd = static_cast<double*>(out_macd.request().ptr);
        double* signal = static_cast<double*>(out_signal.request().ptr);
        double* hist = static_cast<double*>(out_hist.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_macd_result r = tk_macdfix_update(ind_, data[i]);
            if (r.valid) {
                macd[i] = r.macd;
                signal[i] = r.signal;
                hist[i] = r.histogram;
            } else {
                macd[i] = signal[i] = hist[i] = std::nan("");
            }
        }
        return std::make_tuple(out_macd, out_signal, out_hist);
    }
};

// Bollinger Bands with 3 outputs
class PyBBandsIndicator : public PyIndicator {
public:
    PyBBandsIndicator(int period, double std_up, double std_dn)
        : PyIndicator(tk_bbands_new(period, std_up, std_dn)) {}
    
    PyBBandsResult update_bbands(double value) {
        tk_bbands_result r = tk_bbands_update(ind_, value);
        return {r.upper, r.middle, r.lower, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>, py::array_t<double>>
    calculate_bbands(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        size_t size = static_cast<size_t>(buf.size);
        double* data = static_cast<double*>(buf.ptr);
        
        py::array_t<double> out_upper(size);
        py::array_t<double> out_middle(size);
        py::array_t<double> out_lower(size);
        
        double* upper = static_cast<double*>(out_upper.request().ptr);
        double* middle = static_cast<double*>(out_middle.request().ptr);
        double* lower = static_cast<double*>(out_lower.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_bbands_result r = tk_bbands_update(ind_, data[i]);
            if (r.valid) {
                upper[i] = r.upper;
                middle[i] = r.middle;
                lower[i] = r.lower;
            } else {
                upper[i] = middle[i] = lower[i] = std::nan("");
            }
        }
        return std::make_tuple(out_upper, out_middle, out_lower);
    }
};

// Fast Stochastic result (uses k, d instead of slowk, slowd)
struct PyStochFResult {
    double k;
    double d;
    bool valid;
};

// Stochastic RSI result
struct PyStochRSIResult {
    double k;
    double d;
    bool valid;
};

// Stochastic with 2 outputs
class PyStochIndicator : public PyIndicator {
public:
    PyStochIndicator(int k_period, int k_slow, int d_period)
        : PyIndicator(tk_stoch_new(k_period, k_slow, d_period)) {}
    
    PyStochResult update_stoch(double open, double high, double low, 
                               double close, double volume) {
        tk_ohlcv bar = {open, high, low, close, volume};
        tk_stoch_result r = tk_stoch_update(ind_, &bar);
        return {r.slowk, r.slowd, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>>
    calculate_stoch(
        py::array_t<double, py::array::c_style> high,
        py::array_t<double, py::array::c_style> low,
        py::array_t<double, py::array::c_style> close
    ) {
        size_t size = static_cast<size_t>(close.request().size);
        const double* h = static_cast<const double*>(high.request().ptr);
        const double* l = static_cast<const double*>(low.request().ptr);
        const double* c = static_cast<const double*>(close.request().ptr);
        
        py::array_t<double> out_k(size);
        py::array_t<double> out_d(size);
        
        double* k = static_cast<double*>(out_k.request().ptr);
        double* d = static_cast<double*>(out_d.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ohlcv bar = {0, h[i], l[i], c[i], 0};  // open/volume not needed
            tk_stoch_result r = tk_stoch_update(ind_, &bar);
            if (r.valid) {
                k[i] = r.slowk;
                d[i] = r.slowd;
            } else {
                k[i] = d[i] = std::nan("");
            }
        }
        return std::make_tuple(out_k, out_d);
    }
};

// Fast Stochastic with 2 outputs (k, d)
class PyStochFIndicator : public PyIndicator {
public:
    PyStochFIndicator(int k_period, int d_period)
        : PyIndicator(tk_stochf_new(k_period, d_period)) {}
    
    PyStochFResult update_stochf(double open, double high, double low, 
                                  double close, double volume) {
        tk_ohlcv bar = {open, high, low, close, volume};
        tk_stochf_result r = tk_stochf_update(ind_, &bar);
        return {r.k, r.d, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>>
    calculate_stochf(
        py::array_t<double, py::array::c_style> high,
        py::array_t<double, py::array::c_style> low,
        py::array_t<double, py::array::c_style> close
    ) {
        size_t size = static_cast<size_t>(close.request().size);
        const double* h = static_cast<const double*>(high.request().ptr);
        const double* l = static_cast<const double*>(low.request().ptr);
        const double* c = static_cast<const double*>(close.request().ptr);
        
        py::array_t<double> out_k(size);
        py::array_t<double> out_d(size);
        
        double* k = static_cast<double*>(out_k.request().ptr);
        double* d = static_cast<double*>(out_d.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ohlcv bar = {0, h[i], l[i], c[i], 0};
            tk_stochf_result r = tk_stochf_update(ind_, &bar);
            if (r.valid) {
                k[i] = r.k;
                d[i] = r.d;
            } else {
                k[i] = d[i] = std::nan("");
            }
        }
        return std::make_tuple(out_k, out_d);
    }
};

// Stochastic RSI with 2 outputs (k, d)
class PyStochRSIIndicator : public PyIndicator {
public:
    PyStochRSIIndicator(int rsi_period, int stoch_period, int k_smooth, int d_period)
        : PyIndicator(tk_stochrsi_new(rsi_period, stoch_period, k_smooth, d_period)) {}
    
    PyStochRSIResult update_stochrsi(double value) {
        tk_stochrsi_result r = tk_stochrsi_update(ind_, value);
        return {r.k, r.d, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>>
    calculate_stochrsi(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        size_t size = static_cast<size_t>(buf.size);
        double* data = static_cast<double*>(buf.ptr);
        
        py::array_t<double> out_k(size);
        py::array_t<double> out_d(size);
        
        double* k = static_cast<double*>(out_k.request().ptr);
        double* d = static_cast<double*>(out_d.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_stochrsi_result r = tk_stochrsi_update(ind_, data[i]);
            if (r.valid) {
                k[i] = r.k;
                d[i] = r.d;
            } else {
                k[i] = d[i] = std::nan("");
            }
        }
        return std::make_tuple(out_k, out_d);
    }
};

// Aroon with 2 outputs
class PyAroonIndicator : public PyIndicator {
public:
    explicit PyAroonIndicator(int period)
        : PyIndicator(tk_aroon_new(period)) {}
    
    PyAroonResult update_aroon(double open, double high, double low, 
                               double close, double volume) {
        tk_ohlcv bar = {open, high, low, close, volume};
        tk_aroon_result r = tk_aroon_update(ind_, &bar);
        return {r.up, r.down, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>>
    calculate_aroon(
        py::array_t<double, py::array::c_style> high,
        py::array_t<double, py::array::c_style> low
    ) {
        size_t size = static_cast<size_t>(high.request().size);
        const double* h = static_cast<const double*>(high.request().ptr);
        const double* l = static_cast<const double*>(low.request().ptr);
        
        py::array_t<double> out_up(size);
        py::array_t<double> out_down(size);
        
        double* up = static_cast<double*>(out_up.request().ptr);
        double* down = static_cast<double*>(out_down.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ohlcv bar = {0, h[i], l[i], 0, 0};
            tk_aroon_result r = tk_aroon_update(ind_, &bar);
            if (r.valid) {
                up[i] = r.up;
                down[i] = r.down;
            } else {
                up[i] = down[i] = std::nan("");
            }
        }
        return std::make_tuple(out_up, out_down);
    }
};

// ADX with 3 outputs
class PyADXIndicator : public PyIndicator {
public:
    explicit PyADXIndicator(int period)
        : PyIndicator(tk_adx_new(period)) {}
    
    PyADXResult update_adx(double open, double high, double low, 
                           double close, double volume) {
        tk_ohlcv bar = {open, high, low, close, volume};
        tk_adx_result r = tk_adx_update(ind_, &bar);
        return {r.plus_di, r.minus_di, r.adx, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>, py::array_t<double>>
    calculate_adx(
        py::array_t<double, py::array::c_style> high,
        py::array_t<double, py::array::c_style> low,
        py::array_t<double, py::array::c_style> close
    ) {
        size_t size = static_cast<size_t>(close.request().size);
        const double* h = static_cast<const double*>(high.request().ptr);
        const double* l = static_cast<const double*>(low.request().ptr);
        const double* c = static_cast<const double*>(close.request().ptr);
        
        py::array_t<double> out_plus_di(size);
        py::array_t<double> out_minus_di(size);
        py::array_t<double> out_adx(size);
        
        double* plus_di = static_cast<double*>(out_plus_di.request().ptr);
        double* minus_di = static_cast<double*>(out_minus_di.request().ptr);
        double* adx = static_cast<double*>(out_adx.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ohlcv bar = {0, h[i], l[i], c[i], 0};
            tk_adx_result r = tk_adx_update(ind_, &bar);
            if (r.valid) {
                plus_di[i] = r.plus_di;
                minus_di[i] = r.minus_di;
                adx[i] = r.adx;
            } else {
                plus_di[i] = minus_di[i] = adx[i] = std::nan("");
            }
        }
        return std::make_tuple(out_plus_di, out_minus_di, out_adx);
    }
};

// Hilbert Transform Phasor with 2 outputs
class PyHTPhasorIndicator : public PyIndicator {
public:
    PyHTPhasorIndicator() : PyIndicator(tk_ht_phasor_new()) {}
    
    PyHTPhasorResult update_phasor(double value) {
        tk_ht_phasor_result r = tk_ht_phasor_update(ind_, value);
        return {r.inphase, r.quadrature, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>>
    calculate_phasor(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        size_t size = static_cast<size_t>(buf.size);
        double* data = static_cast<double*>(buf.ptr);
        
        py::array_t<double> out_inphase(size);
        py::array_t<double> out_quadrature(size);
        
        double* inphase = static_cast<double*>(out_inphase.request().ptr);
        double* quadrature = static_cast<double*>(out_quadrature.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ht_phasor_result r = tk_ht_phasor_update(ind_, data[i]);
            if (r.valid) {
                inphase[i] = r.inphase;
                quadrature[i] = r.quadrature;
            } else {
                inphase[i] = quadrature[i] = std::nan("");
            }
        }
        return std::make_tuple(out_inphase, out_quadrature);
    }
};

// Hilbert Transform Sine with 2 outputs
class PyHTSineIndicator : public PyIndicator {
public:
    PyHTSineIndicator() : PyIndicator(tk_ht_sine_new()) {}
    
    PyHTSineResult update_sine(double value) {
        tk_ht_sine_result r = tk_ht_sine_update(ind_, value);
        return {r.sine, r.leadsine, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>>
    calculate_sine(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        size_t size = static_cast<size_t>(buf.size);
        double* data = static_cast<double*>(buf.ptr);
        
        py::array_t<double> out_sine(size);
        py::array_t<double> out_leadsine(size);
        
        double* sine = static_cast<double*>(out_sine.request().ptr);
        double* leadsine = static_cast<double*>(out_leadsine.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ht_sine_result r = tk_ht_sine_update(ind_, data[i]);
            if (r.valid) {
                sine[i] = r.sine;
                leadsine[i] = r.leadsine;
            } else {
                sine[i] = leadsine[i] = std::nan("");
            }
        }
        return std::make_tuple(out_sine, out_leadsine);
    }
};

// MinMax with 2 outputs
class PyMinMaxIndicator : public PyIndicator {
public:
    explicit PyMinMaxIndicator(int period)
        : PyIndicator(tk_minmax_new(period)) {}
    
    PyMinMaxResult update_minmax(double value) {
        tk_minmax_result r = tk_minmax_update(ind_, value);
        return {r.min, r.max, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>>
    calculate_minmax(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        size_t size = static_cast<size_t>(buf.size);
        double* data = static_cast<double*>(buf.ptr);
        
        py::array_t<double> out_min(size);
        py::array_t<double> out_max(size);
        
        double* min_out = static_cast<double*>(out_min.request().ptr);
        double* max_out = static_cast<double*>(out_max.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_minmax_result r = tk_minmax_update(ind_, data[i]);
            if (r.valid) {
                min_out[i] = r.min;
                max_out[i] = r.max;
            } else {
                min_out[i] = max_out[i] = std::nan("");
            }
        }
        return std::make_tuple(out_min, out_max);
    }
};

/*============================================================
 * Phase 2 Multi-Output Indicator Wrappers
 *============================================================*/

// Drawdown with multi-output
class PyDrawdownIndicator : public PyIndicator {
public:
    PyDrawdownIndicator() : PyIndicator(tk_drawdown_new()) {}
    
    PyDrawdownResult update_drawdown(double price) {
        tk_drawdown_result r = tk_drawdown_update(ind_, price);
        return {r.drawdown, r.max_drawdown, r.duration, r.max_duration, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>, py::array_t<int>, py::array_t<int>>
    calculate_drawdown(py::array_t<double, py::array::c_style> input) {
        py::buffer_info buf = input.request();
        size_t size = static_cast<size_t>(buf.size);
        double* data = static_cast<double*>(buf.ptr);
        
        py::array_t<double> out_dd(size);
        py::array_t<double> out_mdd(size);
        py::array_t<int> out_dur(size);
        py::array_t<int> out_mdur(size);
        
        double* dd = static_cast<double*>(out_dd.request().ptr);
        double* mdd = static_cast<double*>(out_mdd.request().ptr);
        int* dur = static_cast<int*>(out_dur.request().ptr);
        int* mdur = static_cast<int*>(out_mdur.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_drawdown_result r = tk_drawdown_update(ind_, data[i]);
            if (r.valid) {
                dd[i] = r.drawdown;
                mdd[i] = r.max_drawdown;
                dur[i] = r.duration;
                mdur[i] = r.max_duration;
            } else {
                dd[i] = mdd[i] = std::nan("");
                dur[i] = mdur[i] = 0;
            }
        }
        return std::make_tuple(out_dd, out_mdd, out_dur, out_mdur);
    }
};

// ZigZag with multi-output
class PyZigZagIndicator : public PyIndicator {
public:
    PyZigZagIndicator(double deviation_pct, int depth)
        : PyIndicator(tk_zigzag_new(deviation_pct, depth)) {}
    
    PyZigZagResult update_zigzag(double open, double high, double low, 
                                  double close, double volume) {
        tk_ohlcv bar = {open, high, low, close, volume};
        tk_zigzag_result r = tk_zigzag_update(ind_, &bar);
        return {r.zigzag_value, r.direction, r.is_pivot != 0, r.pivot_type,
                r.last_pivot_price, r.bars_since_pivot, r.valid != 0};
    }
    
    py::array_t<double> calculate_zigzag(
        py::array_t<double, py::array::c_style> open,
        py::array_t<double, py::array::c_style> high,
        py::array_t<double, py::array::c_style> low,
        py::array_t<double, py::array::c_style> close,
        py::array_t<double, py::array::c_style> volume
    ) {
        size_t size = static_cast<size_t>(close.request().size);
        const double* o = static_cast<const double*>(open.request().ptr);
        const double* h = static_cast<const double*>(high.request().ptr);
        const double* l = static_cast<const double*>(low.request().ptr);
        const double* c = static_cast<const double*>(close.request().ptr);
        const double* v = static_cast<const double*>(volume.request().ptr);
        
        py::array_t<double> output(size);
        double* out = static_cast<double*>(output.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ohlcv bar = {o[i], h[i], l[i], c[i], v[i]};
            tk_zigzag_result r = tk_zigzag_update(ind_, &bar);
            out[i] = r.valid ? r.zigzag_value : std::nan("");
        }
        return output;
    }
};

// Swing High/Low with multi-output
class PySwingIndicator : public PyIndicator {
public:
    PySwingIndicator(int left_bars, int right_bars)
        : PyIndicator(tk_swing_new(left_bars, right_bars)) {}
    
    PySwingResult update_swing(double open, double high, double low, 
                               double close, double volume) {
        tk_ohlcv bar = {open, high, low, close, volume};
        tk_swing_result r = tk_swing_update(ind_, &bar);
        return {r.is_swing_high != 0, r.is_swing_low != 0, 
                r.swing_high_price, r.swing_low_price, r.bars_ago, r.valid != 0};
    }
    
    std::tuple<py::array_t<double>, py::array_t<double>>
    calculate_swing(
        py::array_t<double, py::array::c_style> high,
        py::array_t<double, py::array::c_style> low
    ) {
        size_t size = static_cast<size_t>(high.request().size);
        const double* h = static_cast<const double*>(high.request().ptr);
        const double* l = static_cast<const double*>(low.request().ptr);
        
        py::array_t<double> out_sh(size);
        py::array_t<double> out_sl(size);
        
        double* sh = static_cast<double*>(out_sh.request().ptr);
        double* sl = static_cast<double*>(out_sl.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ohlcv bar = {0, h[i], l[i], 0, 0};
            tk_swing_result r = tk_swing_update(ind_, &bar);
            if (r.valid) {
                sh[i] = r.is_swing_high ? r.swing_high_price : std::nan("");
                sl[i] = r.is_swing_low ? r.swing_low_price : std::nan("");
            } else {
                sh[i] = sl[i] = std::nan("");
            }
        }
        return std::make_tuple(out_sh, out_sl);
    }
};

// Pivot Points with multi-output
class PyPivotIndicator : public PyIndicator {
public:
    explicit PyPivotIndicator(int pivot_type)
        : PyIndicator(tk_pivot_new(static_cast<tk_pivot_type>(pivot_type))) {}
    
    PyPivotResult update_pivot(double open, double high, double low, 
                               double close, double volume) {
        tk_ohlcv bar = {open, high, low, close, volume};
        tk_pivot_result r = tk_pivot_update(ind_, &bar);
        return {r.pp, r.r1, r.r2, r.r3, r.s1, r.s2, r.s3, r.valid != 0};
    }
    
    // Static calculation from HLC
    static PyPivotResult calculate_static(double high, double low, double close,
                                          double prev_close, int pivot_type) {
        tk_pivot_result r = tk_pivot_calculate(high, low, close, prev_close,
                                                static_cast<tk_pivot_type>(pivot_type));
        return {r.pp, r.r1, r.r2, r.r3, r.s1, r.s2, r.s3, r.valid != 0};
    }
};

// Harmonic Pattern Detector
class PyHarmonicIndicator : public PyIndicator {
public:
    PyHarmonicIndicator(double deviation_pct, double tolerance, int max_bars)
        : PyIndicator(tk_harmonic_new(deviation_pct, tolerance, max_bars)) {}
    
    PyHarmonicResult update_harmonic(double open, double high, double low, 
                                      double close, double volume) {
        tk_ohlcv bar = {open, high, low, close, volume};
        tk_harmonic_result r = tk_harmonic_update(ind_, &bar);
        return {
            static_cast<int>(r.pattern), r.direction,
            r.x_price, r.a_price, r.b_price, r.c_price, r.d_price,
            r.x_bar, r.a_bar, r.b_bar, r.c_bar, r.d_bar,
            r.xab_ratio, r.abc_ratio, r.bcd_ratio, r.xad_ratio,
            r.prz_high, r.prz_low, r.score, r.is_complete != 0, r.valid != 0
        };
    }
    
    static std::string pattern_name(int pattern_type) {
        return tk_harmonic_pattern_name(static_cast<tk_harmonic_type>(pattern_type));
    }
};

// Chart Pattern Detector
class PyChartPatternIndicator : public PyIndicator {
public:
    PyChartPatternIndicator(int min_bars, int max_bars, double tolerance)
        : PyIndicator(tk_chart_pattern_new(min_bars, max_bars, tolerance)) {}
    
    PyChartPatternResult update_pattern(double open, double high, double low, 
                                         double close, double volume) {
        tk_ohlcv bar = {open, high, low, close, volume};
        tk_chart_pattern_result r = tk_chart_pattern_update(ind_, &bar);
        
        std::vector<double> prices;
        std::vector<int> bars;
        for (int i = 0; i < r.num_points; ++i) {
            prices.push_back(r.point_prices[i]);
            bars.push_back(r.point_bars[i]);
        }
        
        return {
            static_cast<int>(r.pattern), r.direction,
            r.neckline, r.neckline_slope, r.target_price,
            prices, bars, r.num_points,
            r.height, r.width_bars, r.symmetry_score, r.score,
            r.is_complete != 0, r.is_confirmed != 0, r.breakout_price,
            r.valid != 0
        };
    }
    
    static std::string pattern_name(int pattern_type) {
        return tk_chart_pattern_name(static_cast<tk_chart_pattern_type>(pattern_type));
    }
};

/*============================================================
 * Candlestick Pattern Indicator Wrapper
 *============================================================*/

// Candlestick Pattern Indicator wrapper
class PyCDLIndicator {
public:
    explicit PyCDLIndicator(tk_indicator ind) : ind_(ind) {
        if (!ind_) throw std::runtime_error("Failed to create CDL indicator");
    }
    
    ~PyCDLIndicator() {
        if (ind_) tk_free(ind_);
    }
    
    // Disable copy, enable move
    PyCDLIndicator(const PyCDLIndicator&) = delete;
    PyCDLIndicator& operator=(const PyCDLIndicator&) = delete;
    PyCDLIndicator(PyCDLIndicator&& other) noexcept : ind_(other.ind_) { 
        other.ind_ = nullptr; 
    }
    PyCDLIndicator& operator=(PyCDLIndicator&& other) noexcept {
        if (this != &other) {
            if (ind_) tk_free(ind_);
            ind_ = other.ind_;
            other.ind_ = nullptr;
        }
        return *this;
    }
    
    // Update with single OHLC bar - returns pattern signal
    PyCDLResult update(double open, double high, double low, double close) {
        tk_ohlcv bar = {open, high, low, close, 0.0};
        tk_result r = tk_update_ohlcv(ind_, &bar);
        return {static_cast<int>(r.value), r.valid != 0};
    }
    
    // Batch calculation - returns array of signals
    py::array_t<int> calculate(
        py::array_t<double, py::array::c_style> open,
        py::array_t<double, py::array::c_style> high,
        py::array_t<double, py::array::c_style> low,
        py::array_t<double, py::array::c_style> close
    ) {
        size_t size = static_cast<size_t>(close.request().size);
        const double* o = static_cast<const double*>(open.request().ptr);
        const double* h = static_cast<const double*>(high.request().ptr);
        const double* l = static_cast<const double*>(low.request().ptr);
        const double* c = static_cast<const double*>(close.request().ptr);
        
        py::array_t<int> output(size);
        int* out = static_cast<int*>(output.request().ptr);
        
        tk_reset(ind_);
        for (size_t i = 0; i < size; ++i) {
            tk_ohlcv bar = {o[i], h[i], l[i], c[i], 0.0};
            tk_result r = tk_update_ohlcv(ind_, &bar);
            out[i] = r.valid ? static_cast<int>(r.value) : 0;
        }
        return output;
    }
    
    void reset() { tk_reset(ind_); }
    bool is_ready() const { return tk_is_ready(ind_) != 0; }
    int lookback() const { return tk_lookback(ind_); }
    std::string name() const { return tk_name(ind_); }

private:
    tk_indicator ind_;
};

/*============================================================
 * Module Definition
 *============================================================*/

PYBIND11_MODULE(_core, m) {
    m.doc() = "TechKit - High-performance technical analysis library";
    
    // Version info
    m.def("version", &tk_version_string, "Get version string");
    m.def("version_tuple", []() {
        return py::make_tuple(tk_version_major(), tk_version_minor(), tk_version_patch());
    }, "Get version as (major, minor, patch) tuple");
    
    /*============================================================
     * Result types
     *============================================================*/
    
    py::class_<PyResult>(m, "Result")
        .def_readonly("value", &PyResult::value)
        .def_readonly("valid", &PyResult::valid)
        .def("__bool__", [](const PyResult& r) { return r.valid; })
        .def("__repr__", [](const PyResult& r) {
            return r.valid ? 
                "Result(" + std::to_string(r.value) + ")" : 
                "Result(invalid)";
        });
    
    py::class_<PyMACDResult>(m, "MACDResult")
        .def_readonly("macd", &PyMACDResult::macd)
        .def_readonly("signal", &PyMACDResult::signal)
        .def_readonly("histogram", &PyMACDResult::histogram)
        .def_readonly("valid", &PyMACDResult::valid)
        .def("__bool__", [](const PyMACDResult& r) { return r.valid; })
        .def("__repr__", [](const PyMACDResult& r) {
            if (r.valid) {
                return "MACDResult(macd=" + std::to_string(r.macd) + 
                       ", signal=" + std::to_string(r.signal) + 
                       ", histogram=" + std::to_string(r.histogram) + ")";
            }
            return std::string("MACDResult(invalid)");
        });
    
    py::class_<PyBBandsResult>(m, "BBandsResult")
        .def_readonly("upper", &PyBBandsResult::upper)
        .def_readonly("middle", &PyBBandsResult::middle)
        .def_readonly("lower", &PyBBandsResult::lower)
        .def_readonly("valid", &PyBBandsResult::valid)
        .def("__bool__", [](const PyBBandsResult& r) { return r.valid; });
    
    py::class_<PyStochResult>(m, "StochResult")
        .def_readonly("slowk", &PyStochResult::slowk)
        .def_readonly("slowd", &PyStochResult::slowd)
        .def_readonly("valid", &PyStochResult::valid)
        .def("__bool__", [](const PyStochResult& r) { return r.valid; });
    
    py::class_<PyStochFResult>(m, "StochFResult")
        .def_readonly("k", &PyStochFResult::k)
        .def_readonly("d", &PyStochFResult::d)
        .def_readonly("valid", &PyStochFResult::valid)
        .def("__bool__", [](const PyStochFResult& r) { return r.valid; });
    
    py::class_<PyStochRSIResult>(m, "StochRSIResult")
        .def_readonly("k", &PyStochRSIResult::k)
        .def_readonly("d", &PyStochRSIResult::d)
        .def_readonly("valid", &PyStochRSIResult::valid)
        .def("__bool__", [](const PyStochRSIResult& r) { return r.valid; });
    
    py::class_<PyAroonResult>(m, "AroonResult")
        .def_readonly("up", &PyAroonResult::up)
        .def_readonly("down", &PyAroonResult::down)
        .def_readonly("valid", &PyAroonResult::valid)
        .def("__bool__", [](const PyAroonResult& r) { return r.valid; });
    
    py::class_<PyADXResult>(m, "ADXResult")
        .def_readonly("plus_di", &PyADXResult::plus_di)
        .def_readonly("minus_di", &PyADXResult::minus_di)
        .def_readonly("adx", &PyADXResult::adx)
        .def_readonly("valid", &PyADXResult::valid)
        .def("__bool__", [](const PyADXResult& r) { return r.valid; });
    
    py::class_<PyHTPhasorResult>(m, "HTPhasorResult")
        .def_readonly("inphase", &PyHTPhasorResult::inphase)
        .def_readonly("quadrature", &PyHTPhasorResult::quadrature)
        .def_readonly("valid", &PyHTPhasorResult::valid)
        .def("__bool__", [](const PyHTPhasorResult& r) { return r.valid; });
    
    py::class_<PyHTSineResult>(m, "HTSineResult")
        .def_readonly("sine", &PyHTSineResult::sine)
        .def_readonly("leadsine", &PyHTSineResult::leadsine)
        .def_readonly("valid", &PyHTSineResult::valid)
        .def("__bool__", [](const PyHTSineResult& r) { return r.valid; });
    
    py::class_<PyMinMaxResult>(m, "MinMaxResult")
        .def_readonly("min", &PyMinMaxResult::min)
        .def_readonly("max", &PyMinMaxResult::max)
        .def_readonly("valid", &PyMinMaxResult::valid)
        .def("__bool__", [](const PyMinMaxResult& r) { return r.valid; });
    
    /*============================================================
     * Phase 2 Result Types
     *============================================================*/
    
    py::class_<PyDrawdownResult>(m, "DrawdownResult")
        .def_readonly("drawdown", &PyDrawdownResult::drawdown)
        .def_readonly("max_drawdown", &PyDrawdownResult::max_drawdown)
        .def_readonly("duration", &PyDrawdownResult::duration)
        .def_readonly("max_duration", &PyDrawdownResult::max_duration)
        .def_readonly("valid", &PyDrawdownResult::valid)
        .def("__bool__", [](const PyDrawdownResult& r) { return r.valid; });
    
    py::class_<PyZigZagResult>(m, "ZigZagResult")
        .def_readonly("value", &PyZigZagResult::zigzag_value)
        .def_readonly("direction", &PyZigZagResult::direction)
        .def_readonly("is_pivot", &PyZigZagResult::is_pivot)
        .def_readonly("pivot_type", &PyZigZagResult::pivot_type)
        .def_readonly("last_pivot_price", &PyZigZagResult::last_pivot_price)
        .def_readonly("bars_since_pivot", &PyZigZagResult::bars_since_pivot)
        .def_readonly("valid", &PyZigZagResult::valid)
        .def("__bool__", [](const PyZigZagResult& r) { return r.valid; });
    
    py::class_<PySwingResult>(m, "SwingResult")
        .def_readonly("is_swing_high", &PySwingResult::is_swing_high)
        .def_readonly("is_swing_low", &PySwingResult::is_swing_low)
        .def_readonly("swing_high_price", &PySwingResult::swing_high_price)
        .def_readonly("swing_low_price", &PySwingResult::swing_low_price)
        .def_readonly("bars_ago", &PySwingResult::bars_ago)
        .def_readonly("valid", &PySwingResult::valid)
        .def("__bool__", [](const PySwingResult& r) { return r.valid; });
    
    py::class_<PyPivotResult>(m, "PivotResult")
        .def_readonly("pp", &PyPivotResult::pp)
        .def_readonly("r1", &PyPivotResult::r1)
        .def_readonly("r2", &PyPivotResult::r2)
        .def_readonly("r3", &PyPivotResult::r3)
        .def_readonly("s1", &PyPivotResult::s1)
        .def_readonly("s2", &PyPivotResult::s2)
        .def_readonly("s3", &PyPivotResult::s3)
        .def_readonly("valid", &PyPivotResult::valid)
        .def("__bool__", [](const PyPivotResult& r) { return r.valid; });
    
    py::class_<PyHarmonicResult>(m, "HarmonicResult")
        .def_readonly("pattern", &PyHarmonicResult::pattern)
        .def_readonly("direction", &PyHarmonicResult::direction)
        .def_readonly("x_price", &PyHarmonicResult::x_price)
        .def_readonly("a_price", &PyHarmonicResult::a_price)
        .def_readonly("b_price", &PyHarmonicResult::b_price)
        .def_readonly("c_price", &PyHarmonicResult::c_price)
        .def_readonly("d_price", &PyHarmonicResult::d_price)
        .def_readonly("x_bar", &PyHarmonicResult::x_bar)
        .def_readonly("a_bar", &PyHarmonicResult::a_bar)
        .def_readonly("b_bar", &PyHarmonicResult::b_bar)
        .def_readonly("c_bar", &PyHarmonicResult::c_bar)
        .def_readonly("d_bar", &PyHarmonicResult::d_bar)
        .def_readonly("xab_ratio", &PyHarmonicResult::xab_ratio)
        .def_readonly("abc_ratio", &PyHarmonicResult::abc_ratio)
        .def_readonly("bcd_ratio", &PyHarmonicResult::bcd_ratio)
        .def_readonly("xad_ratio", &PyHarmonicResult::xad_ratio)
        .def_readonly("prz_high", &PyHarmonicResult::prz_high)
        .def_readonly("prz_low", &PyHarmonicResult::prz_low)
        .def_readonly("score", &PyHarmonicResult::score)
        .def_readonly("is_complete", &PyHarmonicResult::is_complete)
        .def_readonly("valid", &PyHarmonicResult::valid)
        .def("__bool__", [](const PyHarmonicResult& r) { return r.valid; });
    
    py::class_<PyChartPatternResult>(m, "ChartPatternResult")
        .def_readonly("pattern", &PyChartPatternResult::pattern)
        .def_readonly("direction", &PyChartPatternResult::direction)
        .def_readonly("neckline", &PyChartPatternResult::neckline)
        .def_readonly("neckline_slope", &PyChartPatternResult::neckline_slope)
        .def_readonly("target_price", &PyChartPatternResult::target_price)
        .def_readonly("point_prices", &PyChartPatternResult::point_prices)
        .def_readonly("point_bars", &PyChartPatternResult::point_bars)
        .def_readonly("num_points", &PyChartPatternResult::num_points)
        .def_readonly("height", &PyChartPatternResult::height)
        .def_readonly("width_bars", &PyChartPatternResult::width_bars)
        .def_readonly("symmetry_score", &PyChartPatternResult::symmetry_score)
        .def_readonly("score", &PyChartPatternResult::score)
        .def_readonly("is_complete", &PyChartPatternResult::is_complete)
        .def_readonly("is_confirmed", &PyChartPatternResult::is_confirmed)
        .def_readonly("breakout_price", &PyChartPatternResult::breakout_price)
        .def_readonly("valid", &PyChartPatternResult::valid)
        .def("__bool__", [](const PyChartPatternResult& r) { return r.valid; });
    
    /*============================================================
     * CDL Pattern Result and Indicator
     *============================================================*/
    
    py::class_<PyCDLResult>(m, "CDLResult")
        .def_readonly("signal", &PyCDLResult::signal)
        .def_readonly("valid", &PyCDLResult::valid)
        .def("__bool__", [](const PyCDLResult& r) { return r.valid && r.signal != 0; })
        .def("is_bullish", [](const PyCDLResult& r) { return r.signal > 0; })
        .def("is_bearish", [](const PyCDLResult& r) { return r.signal < 0; });
    
    py::class_<PyCDLIndicator>(m, "CDLIndicator")
        .def("update", &PyCDLIndicator::update,
             py::arg("open"), py::arg("high"), py::arg("low"), py::arg("close"),
             "Update with OHLC bar, returns CDLResult")
        .def("calculate", &PyCDLIndicator::calculate,
             py::arg("open"), py::arg("high"), py::arg("low"), py::arg("close"),
             "Calculate pattern signals for OHLC arrays")
        .def("reset", &PyCDLIndicator::reset)
        .def("is_ready", &PyCDLIndicator::is_ready)
        .def_property_readonly("lookback", &PyCDLIndicator::lookback)
        .def_property_readonly("name", &PyCDLIndicator::name);
    
    /*============================================================
     * Base indicator class
     *============================================================*/
    
    py::class_<PyIndicator>(m, "Indicator")
        .def("update", &PyIndicator::update, py::arg("value"),
             "Update indicator with a single value (incremental)")
        .def("update_ohlcv", &PyIndicator::update_ohlcv,
             py::arg("open"), py::arg("high"), py::arg("low"), 
             py::arg("close"), py::arg("volume"),
             "Update indicator with OHLCV bar data")
        .def("calculate", &PyIndicator::calculate, py::arg("data"),
             "Calculate indicator for entire array (batch)")
        .def("calculate_ohlcv", &PyIndicator::calculate_ohlcv,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Calculate indicator from OHLCV arrays (batch)")
        .def("reset", &PyIndicator::reset,
             "Reset indicator to initial state")
        .def("is_ready", &PyIndicator::is_ready,
             "Check if indicator has completed warmup period")
        .def_property_readonly("lookback", &PyIndicator::lookback,
             "Number of bars required for warmup")
        .def_property_readonly("name", &PyIndicator::name,
             "Indicator name");
    
    /*============================================================
     * Multi-output indicator classes
     *============================================================*/
    
    py::class_<PyMACDIndicator, PyIndicator>(m, "MACDIndicator")
        .def(py::init<int, int, int>(), 
             py::arg("fast") = 12, py::arg("slow") = 26, py::arg("signal") = 9,
             "Create MACD indicator")
        .def("update_macd", &PyMACDIndicator::update_macd, py::arg("value"),
             "Update with single value, returns MACDResult")
        .def("calculate_macd", &PyMACDIndicator::calculate_macd, py::arg("data"),
             "Calculate MACD for entire array, returns (macd, signal, histogram)");
    
    py::class_<PyBBandsIndicator, PyIndicator>(m, "BBandsIndicator")
        .def(py::init<int, double, double>(),
             py::arg("period") = 20, py::arg("std_up") = 2.0, py::arg("std_dn") = 2.0,
             "Create Bollinger Bands indicator")
        .def("update_bbands", &PyBBandsIndicator::update_bbands, py::arg("value"),
             "Update with single value, returns BBandsResult")
        .def("calculate_bbands", &PyBBandsIndicator::calculate_bbands, py::arg("data"),
             "Calculate Bollinger Bands for array, returns (upper, middle, lower)");
    
    py::class_<PyStochIndicator, PyIndicator>(m, "StochIndicator")
        .def(py::init<int, int, int>(),
             py::arg("k_period") = 14, py::arg("k_slow") = 3, py::arg("d_period") = 3,
             "Create Stochastic Oscillator indicator")
        .def("update_stoch", &PyStochIndicator::update_stoch,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Update with OHLCV bar, returns StochResult")
        .def("calculate_stoch", &PyStochIndicator::calculate_stoch,
             py::arg("high"), py::arg("low"), py::arg("close"),
             "Calculate Stochastic for arrays, returns (slowk, slowd)");
    
    py::class_<PyStochFIndicator, PyIndicator>(m, "StochFIndicator")
        .def(py::init<int, int>(),
             py::arg("k_period") = 5, py::arg("d_period") = 3,
             "Create Fast Stochastic indicator")
        .def("update_stochf", &PyStochFIndicator::update_stochf,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Update with OHLCV bar, returns StochFResult")
        .def("calculate_stochf", &PyStochFIndicator::calculate_stochf,
             py::arg("high"), py::arg("low"), py::arg("close"),
             "Calculate Fast Stochastic for arrays, returns (k, d)");
    
    py::class_<PyStochRSIIndicator, PyIndicator>(m, "StochRSIIndicator")
        .def(py::init<int, int, int, int>(),
             py::arg("rsi_period") = 14, py::arg("stoch_period") = 14,
             py::arg("k_smooth") = 3, py::arg("d_period") = 3,
             "Create Stochastic RSI indicator")
        .def("update_stochrsi", &PyStochRSIIndicator::update_stochrsi,
             py::arg("value"),
             "Update with single value, returns StochRSIResult")
        .def("calculate_stochrsi", &PyStochRSIIndicator::calculate_stochrsi,
             py::arg("data"),
             "Calculate Stochastic RSI for array, returns (k, d)");
    
    py::class_<PyMACDEXTIndicator, PyIndicator>(m, "MACDEXTIndicator")
        .def(py::init<int, int, int, int, int, int>(),
             py::arg("fast_period") = 12, py::arg("fast_ma_type") = 1,
             py::arg("slow_period") = 26, py::arg("slow_ma_type") = 1,
             py::arg("signal_period") = 9, py::arg("signal_ma_type") = 1,
             "Create Extended MACD indicator with MA type selection")
        .def("update_macd", &PyMACDEXTIndicator::update_macd, py::arg("value"),
             "Update with single value, returns MACDResult")
        .def("calculate_macd", &PyMACDEXTIndicator::calculate_macd, py::arg("data"),
             "Calculate MACDEXT for array, returns (macd, signal, histogram)");
    
    py::class_<PyMACDFIXIndicator, PyIndicator>(m, "MACDFIXIndicator")
        .def(py::init<int>(), py::arg("signal_period") = 9,
             "Create Fixed Period MACD (12, 26, signal)")
        .def("update_macd", &PyMACDFIXIndicator::update_macd, py::arg("value"),
             "Update with single value, returns MACDResult")
        .def("calculate_macd", &PyMACDFIXIndicator::calculate_macd, py::arg("data"),
             "Calculate MACDFIX for array, returns (macd, signal, histogram)");
    
    py::class_<PyAroonIndicator, PyIndicator>(m, "AroonIndicator")
        .def(py::init<int>(), py::arg("period") = 14,
             "Create Aroon indicator")
        .def("update_aroon", &PyAroonIndicator::update_aroon,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Update with OHLCV bar, returns AroonResult")
        .def("calculate_aroon", &PyAroonIndicator::calculate_aroon,
             py::arg("high"), py::arg("low"),
             "Calculate Aroon for arrays, returns (up, down)");
    
    py::class_<PyADXIndicator, PyIndicator>(m, "ADXIndicator")
        .def(py::init<int>(), py::arg("period") = 14,
             "Create ADX indicator")
        .def("update_adx", &PyADXIndicator::update_adx,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Update with OHLCV bar, returns ADXResult")
        .def("calculate_adx", &PyADXIndicator::calculate_adx,
             py::arg("high"), py::arg("low"), py::arg("close"),
             "Calculate ADX for arrays, returns (plus_di, minus_di, adx)");
    
    py::class_<PyHTPhasorIndicator, PyIndicator>(m, "HTPhasorIndicator")
        .def(py::init<>(), "Create Hilbert Transform Phasor indicator")
        .def("update_phasor", &PyHTPhasorIndicator::update_phasor, py::arg("value"),
             "Update with single value, returns HTPhasorResult")
        .def("calculate_phasor", &PyHTPhasorIndicator::calculate_phasor, py::arg("data"),
             "Calculate HT Phasor for array, returns (inphase, quadrature)");
    
    py::class_<PyHTSineIndicator, PyIndicator>(m, "HTSineIndicator")
        .def(py::init<>(), "Create Hilbert Transform Sine indicator")
        .def("update_sine", &PyHTSineIndicator::update_sine, py::arg("value"),
             "Update with single value, returns HTSineResult")
        .def("calculate_sine", &PyHTSineIndicator::calculate_sine, py::arg("data"),
             "Calculate HT Sine for array, returns (sine, leadsine)");
    
    py::class_<PyMinMaxIndicator, PyIndicator>(m, "MinMaxIndicator")
        .def(py::init<int>(), py::arg("period") = 30,
             "Create MinMax indicator")
        .def("update_minmax", &PyMinMaxIndicator::update_minmax, py::arg("value"),
             "Update with single value, returns MinMaxResult")
        .def("calculate_minmax", &PyMinMaxIndicator::calculate_minmax, py::arg("data"),
             "Calculate MinMax for array, returns (min, max)");
    
    /*============================================================
     * Phase 2 Multi-output indicator classes
     *============================================================*/
    
    py::class_<PyDrawdownIndicator, PyIndicator>(m, "DrawdownIndicator")
        .def(py::init<>(), "Create Drawdown indicator")
        .def("update_drawdown", &PyDrawdownIndicator::update_drawdown, py::arg("price"),
             "Update with price, returns DrawdownResult")
        .def("calculate_drawdown", &PyDrawdownIndicator::calculate_drawdown, py::arg("prices"),
             "Calculate Drawdown for array, returns (drawdown, max_drawdown, duration, max_duration)");
    
    py::class_<PyZigZagIndicator, PyIndicator>(m, "ZigZagIndicator")
        .def(py::init<double, int>(),
             py::arg("deviation_pct") = 5.0, py::arg("depth") = 12,
             "Create ZigZag indicator")
        .def("update_zigzag", &PyZigZagIndicator::update_zigzag,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Update with OHLCV bar, returns ZigZagResult")
        .def("calculate_zigzag", &PyZigZagIndicator::calculate_zigzag,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Calculate ZigZag for OHLCV arrays");
    
    py::class_<PySwingIndicator, PyIndicator>(m, "SwingIndicator")
        .def(py::init<int, int>(),
             py::arg("left_bars") = 5, py::arg("right_bars") = 5,
             "Create Swing High/Low indicator")
        .def("update_swing", &PySwingIndicator::update_swing,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Update with OHLCV bar, returns SwingResult")
        .def("calculate_swing", &PySwingIndicator::calculate_swing,
             py::arg("high"), py::arg("low"),
             "Calculate Swing for arrays, returns (swing_high, swing_low)");
    
    py::class_<PyPivotIndicator, PyIndicator>(m, "PivotIndicator")
        .def(py::init<int>(), py::arg("pivot_type") = 0,
             "Create Pivot Points indicator (0=Classic, 1=Fibonacci, 2=Woodie, 3=Camarilla, 4=DeMark)")
        .def("update_pivot", &PyPivotIndicator::update_pivot,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Update with OHLCV bar, returns PivotResult")
        .def_static("calculate", &PyPivotIndicator::calculate_static,
             py::arg("high"), py::arg("low"), py::arg("close"),
             py::arg("prev_close") = 0.0, py::arg("pivot_type") = 0,
             "Calculate pivot points from HLC (static)");
    
    py::class_<PyHarmonicIndicator, PyIndicator>(m, "HarmonicIndicator")
        .def(py::init<double, double, int>(),
             py::arg("deviation_pct") = 5.0, py::arg("tolerance") = 0.03,
             py::arg("max_bars") = 100,
             "Create Harmonic Pattern detector")
        .def("update_harmonic", &PyHarmonicIndicator::update_harmonic,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Update with OHLCV bar, returns HarmonicResult")
        .def_static("pattern_name", &PyHarmonicIndicator::pattern_name,
             py::arg("pattern_type"), "Get pattern name from type");
    
    py::class_<PyChartPatternIndicator, PyIndicator>(m, "ChartPatternIndicator")
        .def(py::init<int, int, double>(),
             py::arg("min_bars") = 20, py::arg("max_bars") = 200,
             py::arg("tolerance") = 0.03,
             "Create Chart Pattern detector")
        .def("update_pattern", &PyChartPatternIndicator::update_pattern,
             py::arg("open"), py::arg("high"), py::arg("low"),
             py::arg("close"), py::arg("volume"),
             "Update with OHLCV bar, returns ChartPatternResult")
        .def_static("pattern_name", &PyChartPatternIndicator::pattern_name,
             py::arg("pattern_type"), "Get pattern name from type");
    
    /*============================================================
     * Factory functions for single-output indicators
     *============================================================*/
    
    // Moving Averages
    m.def("sma", [](int p) { return PyIndicator(tk_sma_new(p)); }, 
          py::arg("period"), "Simple Moving Average");
    m.def("ema", [](int p) { return PyIndicator(tk_ema_new(p)); }, 
          py::arg("period"), "Exponential Moving Average");
    m.def("wma", [](int p) { return PyIndicator(tk_wma_new(p)); }, 
          py::arg("period"), "Weighted Moving Average");
    m.def("dema", [](int p) { return PyIndicator(tk_dema_new(p)); }, 
          py::arg("period"), "Double Exponential Moving Average");
    m.def("tema", [](int p) { return PyIndicator(tk_tema_new(p)); }, 
          py::arg("period"), "Triple Exponential Moving Average");
    m.def("kama", [](int p) { return PyIndicator(tk_kama_new(p)); }, 
          py::arg("period"), "Kaufman Adaptive Moving Average");
    m.def("trima", [](int p) { return PyIndicator(tk_trima_new(p)); }, 
          py::arg("period"), "Triangular Moving Average");
    m.def("t3", [](int p, double v) { return PyIndicator(tk_t3_new(p, v)); }, 
          py::arg("period"), py::arg("volume_factor") = 0.7, "T3 Moving Average");
    
    // Generic Moving Average with type selection
    m.def("ma", [](int period, int ma_type) { 
              return PyIndicator(tk_ma_new(period, static_cast<tk_ma_type>(ma_type))); 
          }, py::arg("period") = 30, py::arg("ma_type") = 0,
          "Generic Moving Average - type: 0=SMA, 1=EMA, 2=WMA, 3=DEMA, 4=TEMA, 5=TRIMA, 6=KAMA, 8=T3");
    
    // MAVP - Variable Period Moving Average
    m.def("mavp", [](int min_period, int max_period, int ma_type) { 
              return PyIndicator(tk_mavp_new(min_period, max_period, static_cast<tk_ma_type>(ma_type))); 
          }, py::arg("min_period") = 2, py::arg("max_period") = 30, py::arg("ma_type") = 0,
          "Variable Period Moving Average");
    
    // Momentum Indicators
    m.def("rsi", [](int p) { return PyIndicator(tk_rsi_new(p)); }, 
          py::arg("period") = 14, "Relative Strength Index");
    m.def("mom", [](int p) { return PyIndicator(tk_mom_new(p)); }, 
          py::arg("period") = 10, "Momentum");
    m.def("roc", [](int p) { return PyIndicator(tk_roc_new(p)); }, 
          py::arg("period") = 10, "Rate of Change");
    m.def("rocp", [](int p) { return PyIndicator(tk_rocp_new(p)); }, 
          py::arg("period") = 10, "Rate of Change Percentage");
    m.def("rocr", [](int p) { return PyIndicator(tk_rocr_new(p)); }, 
          py::arg("period") = 10, "Rate of Change Ratio");
    m.def("rocr100", [](int p) { return PyIndicator(tk_rocr100_new(p)); }, 
          py::arg("period") = 10, "Rate of Change Ratio * 100");
    m.def("cci", [](int p) { return PyIndicator(tk_cci_new(p)); }, 
          py::arg("period") = 20, "Commodity Channel Index");
    m.def("adx", [](int p) { return PyIndicator(tk_adx_new(p)); }, 
          py::arg("period") = 14, "Average Directional Index");
    m.def("adxr", [](int p) { return PyIndicator(tk_adxr_new(p)); }, 
          py::arg("period") = 14, "ADX Rating");
    m.def("apo", [](int f, int s) { return PyIndicator(tk_apo_new(f, s)); }, 
          py::arg("fast") = 12, py::arg("slow") = 26, "Absolute Price Oscillator");
    m.def("ppo", [](int f, int s) { return PyIndicator(tk_ppo_new(f, s)); }, 
          py::arg("fast") = 12, py::arg("slow") = 26, "Percentage Price Oscillator");
    m.def("cmo", [](int p) { return PyIndicator(tk_cmo_new(p)); }, 
          py::arg("period") = 14, "Chande Momentum Oscillator");
    m.def("dx", [](int p) { return PyIndicator(tk_dx_new(p)); }, 
          py::arg("period") = 14, "Directional Movement Index");
    m.def("willr", [](int p) { return PyIndicator(tk_willr_new(p)); }, 
          py::arg("period") = 14, "Williams %R");
    m.def("mfi", [](int p) { return PyIndicator(tk_mfi_new(p)); }, 
          py::arg("period") = 14, "Money Flow Index");
    m.def("plus_di", [](int p) { return PyIndicator(tk_plus_di_new(p)); }, 
          py::arg("period") = 14, "Plus Directional Indicator");
    m.def("minus_di", [](int p) { return PyIndicator(tk_minus_di_new(p)); }, 
          py::arg("period") = 14, "Minus Directional Indicator");
    m.def("plus_dm", [](int p) { return PyIndicator(tk_plus_dm_new(p)); }, 
          py::arg("period") = 14, "Plus Directional Movement");
    m.def("minus_dm", [](int p) { return PyIndicator(tk_minus_dm_new(p)); }, 
          py::arg("period") = 14, "Minus Directional Movement");
    m.def("trix", [](int p) { return PyIndicator(tk_trix_new(p)); }, 
          py::arg("period") = 30, "Triple Exponential Average");
    m.def("ultosc", [](int p1, int p2, int p3) { 
              return PyIndicator(tk_ultosc_new(p1, p2, p3)); 
          }, py::arg("period1") = 7, py::arg("period2") = 14, py::arg("period3") = 28,
          "Ultimate Oscillator");
    m.def("aroonosc", [](int p) { return PyIndicator(tk_aroonosc_new(p)); }, 
          py::arg("period") = 14, "Aroon Oscillator");
    m.def("bop", []() { return PyIndicator(tk_bop_new()); }, 
          "Balance of Power");
    
    // Volatility Indicators
    m.def("atr", [](int p) { return PyIndicator(tk_atr_new(p)); }, 
          py::arg("period") = 14, "Average True Range");
    m.def("natr", [](int p) { return PyIndicator(tk_natr_new(p)); }, 
          py::arg("period") = 14, "Normalized Average True Range");
    m.def("trange", []() { return PyIndicator(tk_trange_new()); }, 
          "True Range");
    
    // Volume Indicators
    m.def("obv", []() { return PyIndicator(tk_obv_new()); }, 
          "On Balance Volume");
    m.def("ad", []() { return PyIndicator(tk_ad_new()); }, 
          "Accumulation/Distribution");
    m.def("adosc", [](int f, int s) { return PyIndicator(tk_adosc_new(f, s)); },
          py::arg("fast") = 3, py::arg("slow") = 10, "A/D Oscillator");
    
    // Statistics
    m.def("stddev", [](int p, double nbdev) { return PyIndicator(tk_stddev_new(p, nbdev)); }, 
          py::arg("period") = 5, py::arg("nbdev") = 1.0, "Standard Deviation");
    m.def("var", [](int p) { return PyIndicator(tk_var_new(p)); }, 
          py::arg("period") = 5, "Variance");
    m.def("linearreg", [](int p) { return PyIndicator(tk_linearreg_new(p)); }, 
          py::arg("period") = 14, "Linear Regression");
    m.def("linearreg_slope", [](int p) { return PyIndicator(tk_linearreg_slope_new(p)); }, 
          py::arg("period") = 14, "Linear Regression Slope");
    m.def("linearreg_intercept", [](int p) { return PyIndicator(tk_linearreg_intercept_new(p)); }, 
          py::arg("period") = 14, "Linear Regression Intercept");
    m.def("linearreg_angle", [](int p) { return PyIndicator(tk_linearreg_angle_new(p)); }, 
          py::arg("period") = 14, "Linear Regression Angle");
    m.def("tsf", [](int p) { return PyIndicator(tk_tsf_new(p)); }, 
          py::arg("period") = 14, "Time Series Forecast");
    m.def("beta", [](int p) { return PyIndicator(tk_beta_new(p)); }, 
          py::arg("period") = 5, "Beta");
    m.def("correl", [](int p) { return PyIndicator(tk_correl_new(p)); }, 
          py::arg("period") = 30, "Pearson Correlation");
    
    // Price Transform
    m.def("avgprice", []() { return PyIndicator(tk_avgprice_new()); }, 
          "Average Price");
    m.def("medprice", []() { return PyIndicator(tk_medprice_new()); }, 
          "Median Price");
    m.def("typprice", []() { return PyIndicator(tk_typprice_new()); }, 
          "Typical Price");
    m.def("wclprice", []() { return PyIndicator(tk_wclprice_new()); }, 
          "Weighted Close Price");
    
    // Math Operators
    m.def("max", [](int p) { return PyIndicator(tk_max_new(p)); }, 
          py::arg("period") = 30, "Highest Value");
    m.def("min", [](int p) { return PyIndicator(tk_min_new(p)); }, 
          py::arg("period") = 30, "Lowest Value");
    m.def("sum", [](int p) { return PyIndicator(tk_sum_new(p)); }, 
          py::arg("period") = 30, "Sum");
    m.def("midpoint", [](int p) { return PyIndicator(tk_midpoint_new(p)); }, 
          py::arg("period") = 14, "Midpoint over Period");
    m.def("midprice", [](int p) { return PyIndicator(tk_midprice_new(p)); }, 
          py::arg("period") = 14, "Midpoint Price");
    
    // Hilbert Transform
    m.def("ht_dcperiod", []() { return PyIndicator(tk_ht_dcperiod_new()); }, 
          "Hilbert Transform - Dominant Cycle Period");
    m.def("ht_dcphase", []() { return PyIndicator(tk_ht_dcphase_new()); }, 
          "Hilbert Transform - Dominant Cycle Phase");
    m.def("ht_trendmode", []() { return PyIndicator(tk_ht_trendmode_new()); }, 
          "Hilbert Transform - Trend vs Cycle Mode");
    m.def("ht_trendline", []() { return PyIndicator(tk_ht_trendline_new()); }, 
          "Hilbert Transform - Instantaneous Trendline");
    
    // Parabolic SAR
    m.def("sar", [](double accel, double max) { 
              return PyIndicator(tk_sar_new(accel, max)); 
          }, py::arg("acceleration") = 0.02, py::arg("maximum") = 0.2,
          "Parabolic SAR");
    
    // Extended Parabolic SAR
    m.def("sarext", [](double start_value, double offset_on_reverse,
                       double af_init_long, double af_long, double af_max_long,
                       double af_init_short, double af_short, double af_max_short) { 
              return PyIndicator(tk_sarext_new(start_value, offset_on_reverse,
                                               af_init_long, af_long, af_max_long,
                                               af_init_short, af_short, af_max_short)); 
          }, py::arg("start_value") = 0.0,
             py::arg("offset_on_reverse") = 0.0,
             py::arg("af_init_long") = 0.02,
             py::arg("af_long") = 0.02,
             py::arg("af_max_long") = 0.20,
             py::arg("af_init_short") = 0.02,
             py::arg("af_short") = 0.02,
             py::arg("af_max_short") = 0.20,
          "Extended Parabolic SAR with full parameter control");
    
    /*============================================================
     * Phase 2: Risk Metrics
     *============================================================*/
    
    m.def("sharpe_ratio", [](int period, double risk_free_rate, int annualization) { 
              return PyIndicator(tk_sharpe_new(period, risk_free_rate, annualization)); 
          }, py::arg("period") = 252, py::arg("risk_free_rate") = 0.0, 
             py::arg("annualization") = 252,
          "Rolling Sharpe Ratio");
    
    m.def("sortino_ratio", [](int period, double risk_free_rate, 
                              double target_return, int annualization) { 
              return PyIndicator(tk_sortino_new(period, risk_free_rate, 
                                                 target_return, annualization)); 
          }, py::arg("period") = 252, py::arg("risk_free_rate") = 0.0,
             py::arg("target_return") = 0.0, py::arg("annualization") = 252,
          "Rolling Sortino Ratio");
    
    m.def("max_drawdown", []() { 
              return PyIndicator(tk_max_drawdown_new()); 
          }, "Maximum Drawdown");
    
    m.def("calmar_ratio", [](int period, int annualization) { 
              return PyIndicator(tk_calmar_new(period, annualization)); 
          }, py::arg("period") = 756, py::arg("annualization") = 252,
          "Rolling Calmar Ratio");
    
    m.def("hist_var", [](int period, double confidence) { 
              return PyIndicator(tk_hist_var_new(period, confidence)); 
          }, py::arg("period") = 252, py::arg("confidence") = 0.95,
          "Historical Value at Risk");
    
    m.def("cvar", [](int period, double confidence) { 
              return PyIndicator(tk_cvar_new(period, confidence)); 
          }, py::arg("period") = 252, py::arg("confidence") = 0.95,
          "Conditional VaR / Expected Shortfall");
    
    /*============================================================
     * Phase 2: Volatility Models
     *============================================================*/
    
    m.def("ewma_vol", [](double lambda_, int annualization) { 
              return PyIndicator(tk_ewma_vol_new(lambda_, annualization)); 
          }, py::arg("lambda_") = 0.94, py::arg("annualization") = 252,
          "EWMA Volatility");
    
    m.def("realized_vol", [](int period, int annualization) { 
              return PyIndicator(tk_realized_vol_new(period, annualization)); 
          }, py::arg("period") = 21, py::arg("annualization") = 252,
          "Realized Volatility");
    
    m.def("parkinson_vol", [](int period, int annualization) { 
              return PyIndicator(tk_parkinson_vol_new(period, annualization)); 
          }, py::arg("period") = 21, py::arg("annualization") = 252,
          "Parkinson Volatility (high-low based)");
    
    m.def("garch_vol", [](double omega, double alpha, double beta, int annualization) { 
              return PyIndicator(tk_garch_vol_new(omega, alpha, beta, annualization)); 
          }, py::arg("omega") = 0.000001, py::arg("alpha") = 0.09, 
             py::arg("beta") = 0.90, py::arg("annualization") = 252,
          "GARCH(1,1) Volatility");
    
    /*============================================================
     * Multi-output indicator factory functions
     *============================================================*/
    
    m.def("macd", [](int f, int s, int sig) { 
              return PyMACDIndicator(f, s, sig); 
          }, py::arg("fast") = 12, py::arg("slow") = 26, py::arg("signal") = 9,
          "MACD");
    
    m.def("bbands", [](int p, double up, double dn) { 
              return PyBBandsIndicator(p, up, dn); 
          }, py::arg("period") = 20, py::arg("std_up") = 2.0, py::arg("std_dn") = 2.0,
          "Bollinger Bands");
    
    m.def("stoch", [](int k, int ks, int d) { 
              return PyStochIndicator(k, ks, d); 
          }, py::arg("k_period") = 14, py::arg("k_slow") = 3, py::arg("d_period") = 3,
          "Stochastic Oscillator");
    
    m.def("stochf", [](int k, int d) { 
              return PyStochFIndicator(k, d); 
          }, py::arg("k_period") = 5, py::arg("d_period") = 3,
          "Fast Stochastic Oscillator");
    
    m.def("stochrsi", [](int rsi_period, int stoch_period, int k_smooth, int d_period) { 
              return PyStochRSIIndicator(rsi_period, stoch_period, k_smooth, d_period); 
          }, py::arg("rsi_period") = 14, py::arg("stoch_period") = 14,
             py::arg("k_smooth") = 3, py::arg("d_period") = 3,
          "Stochastic RSI");
    
    m.def("macdext", [](int fast, int fast_ma, int slow, int slow_ma, int signal, int signal_ma) { 
              return PyMACDEXTIndicator(fast, fast_ma, slow, slow_ma, signal, signal_ma); 
          }, py::arg("fast_period") = 12, py::arg("fast_ma_type") = 1,
             py::arg("slow_period") = 26, py::arg("slow_ma_type") = 1,
             py::arg("signal_period") = 9, py::arg("signal_ma_type") = 1,
          "Extended MACD with MA type selection");
    
    m.def("macdfix", [](int signal) { 
              return PyMACDFIXIndicator(signal); 
          }, py::arg("signal_period") = 9,
          "Fixed Period MACD (12, 26, signal)");
    
    m.def("aroon", [](int p) { 
              return PyAroonIndicator(p); 
          }, py::arg("period") = 14,
          "Aroon");
    
    m.def("adx_full", [](int p) { 
              return PyADXIndicator(p); 
          }, py::arg("period") = 14,
          "ADX (with +DI, -DI)");
    
    m.def("ht_phasor", []() { 
              return PyHTPhasorIndicator(); 
          }, "Hilbert Transform - Phasor Components");
    
    m.def("ht_sine", []() { 
              return PyHTSineIndicator(); 
          }, "Hilbert Transform - Sine Wave");
    
    m.def("minmax", [](int p) { 
              return PyMinMaxIndicator(p); 
          }, py::arg("period") = 30,
          "Min and Max over Period");
    
    /*============================================================
     * Phase 2: Multi-output factory functions
     *============================================================*/
    
    m.def("drawdown", []() { 
              return PyDrawdownIndicator(); 
          }, "Drawdown Series (multi-output)");
    
    m.def("zigzag", [](double dev, int depth) { 
              return PyZigZagIndicator(dev, depth); 
          }, py::arg("deviation_pct") = 5.0, py::arg("depth") = 12,
          "ZigZag indicator");
    
    m.def("swing", [](int left, int right) { 
              return PySwingIndicator(left, right); 
          }, py::arg("left_bars") = 5, py::arg("right_bars") = 5,
          "Swing High/Low detector");
    
    m.def("pivot_points", [](int pivot_type) { 
              return PyPivotIndicator(pivot_type); 
          }, py::arg("pivot_type") = 0,
          "Pivot Points (0=Classic, 1=Fibonacci, 2=Woodie, 3=Camarilla, 4=DeMark)");
    
    m.def("harmonic", [](double dev, double tol, int max_bars) { 
              return PyHarmonicIndicator(dev, tol, max_bars); 
          }, py::arg("deviation_pct") = 5.0, py::arg("tolerance") = 0.03,
             py::arg("max_bars") = 100,
          "Harmonic Pattern detector");
    
    m.def("chart_pattern", [](int min_bars, int max_bars, double tol) { 
              return PyChartPatternIndicator(min_bars, max_bars, tol); 
          }, py::arg("min_bars") = 20, py::arg("max_bars") = 200,
             py::arg("tolerance") = 0.03,
          "Chart Pattern detector");
    
    /*============================================================
     * Phase 3: Candlestick Pattern Recognition (61 functions)
     *============================================================*/
    
    // Single candle patterns (12)
    m.def("cdl_doji", []() { return PyCDLIndicator(tk_cdl_doji_new()); },
          "Doji - indecision pattern");
    m.def("cdl_dragonflydoji", []() { return PyCDLIndicator(tk_cdl_dragonfly_doji_new()); },
          "Dragonfly Doji - T-shaped doji with long lower shadow");
    m.def("cdl_gravestonedoji", []() { return PyCDLIndicator(tk_cdl_gravestone_doji_new()); },
          "Gravestone Doji - inverted T-shaped doji");
    m.def("cdl_longleggeddoji", []() { return PyCDLIndicator(tk_cdl_longleg_doji_new()); },
          "Long Legged Doji - doji with long shadows");
    m.def("cdl_hammer", []() { return PyCDLIndicator(tk_cdl_hammer_new()); },
          "Hammer - bullish reversal");
    m.def("cdl_invertedhammer", []() { return PyCDLIndicator(tk_cdl_inverted_hammer_new()); },
          "Inverted Hammer - bullish reversal");
    m.def("cdl_hangingman", []() { return PyCDLIndicator(tk_cdl_hanging_man_new()); },
          "Hanging Man - bearish reversal");
    m.def("cdl_shootingstar", []() { return PyCDLIndicator(tk_cdl_shooting_star_new()); },
          "Shooting Star - bearish reversal");
    m.def("cdl_marubozu", []() { return PyCDLIndicator(tk_cdl_marubozu_new()); },
          "Marubozu - strong momentum candle");
    m.def("cdl_closingmarubozu", []() { return PyCDLIndicator(tk_cdl_closing_marubozu_new()); },
          "Closing Marubozu - no shadow at close");
    m.def("cdl_spinningtop", []() { return PyCDLIndicator(tk_cdl_spinning_top_new()); },
          "Spinning Top - indecision pattern");
    m.def("cdl_highwave", []() { return PyCDLIndicator(tk_cdl_highwave_new()); },
          "High-Wave Candle - extreme indecision");
    
    // Two candle patterns (15)
    m.def("cdl_engulfing", []() { return PyCDLIndicator(tk_cdl_engulfing_new()); },
          "Engulfing Pattern - reversal");
    m.def("cdl_harami", []() { return PyCDLIndicator(tk_cdl_harami_new()); },
          "Harami Pattern - potential reversal");
    m.def("cdl_haramicross", []() { return PyCDLIndicator(tk_cdl_harami_cross_new()); },
          "Harami Cross - harami with doji");
    m.def("cdl_piercing", []() { return PyCDLIndicator(tk_cdl_piercing_new()); },
          "Piercing Pattern - bullish reversal");
    m.def("cdl_darkcloudcover", []() { return PyCDLIndicator(tk_cdl_dark_cloud_cover_new()); },
          "Dark Cloud Cover - bearish reversal");
    m.def("cdl_belthold", []() { return PyCDLIndicator(tk_cdl_belt_hold_new()); },
          "Belt-hold - marubozu opening at extreme");
    m.def("cdl_counterattack", []() { return PyCDLIndicator(tk_cdl_counterattack_new()); },
          "Counterattack - opposing candles at same close");
    m.def("cdl_homingpigeon", []() { return PyCDLIndicator(tk_cdl_homing_pigeon_new()); },
          "Homing Pigeon - bullish harami variation");
    m.def("cdl_inneck", []() { return PyCDLIndicator(tk_cdl_in_neck_new()); },
          "In-Neck Pattern - bearish continuation");
    m.def("cdl_onneck", []() { return PyCDLIndicator(tk_cdl_on_neck_new()); },
          "On-Neck Pattern - bearish continuation");
    m.def("cdl_matchinglow", []() { return PyCDLIndicator(tk_cdl_matching_low_new()); },
          "Matching Low - bullish reversal");
    m.def("cdl_kicking", []() { return PyCDLIndicator(tk_cdl_kicking_new()); },
          "Kicking - two marubozu with gap");
    m.def("cdl_kickingbylength", []() { return PyCDLIndicator(tk_cdl_kicking_by_length_new()); },
          "Kicking by Length - determined by longer marubozu");
    m.def("cdl_separatinglines", []() { return PyCDLIndicator(tk_cdl_separating_lines_new()); },
          "Separating Lines - continuation pattern");
    m.def("cdl_thrusting", []() { return PyCDLIndicator(tk_cdl_thrusting_new()); },
          "Thrusting Pattern - bearish continuation");
    
    // Three candle patterns (12)
    m.def("cdl_morningstar", []() { return PyCDLIndicator(tk_cdl_morning_star_new()); },
          "Morning Star - bullish reversal");
    m.def("cdl_eveningstar", []() { return PyCDLIndicator(tk_cdl_evening_star_new()); },
          "Evening Star - bearish reversal");
    m.def("cdl_morningdojistar", []() { return PyCDLIndicator(tk_cdl_morning_doji_star_new()); },
          "Morning Doji Star - bullish reversal with doji");
    m.def("cdl_eveningdojistar", []() { return PyCDLIndicator(tk_cdl_evening_doji_star_new()); },
          "Evening Doji Star - bearish reversal with doji");
    m.def("cdl_3inside", []() { return PyCDLIndicator(tk_cdl_3_inside_new()); },
          "Three Inside Up/Down - harami with confirmation");
    m.def("cdl_3outside", []() { return PyCDLIndicator(tk_cdl_3_outside_new()); },
          "Three Outside Up/Down - engulfing with confirmation");
    m.def("cdl_3whitesoldiers", []() { return PyCDLIndicator(tk_cdl_3_white_soldiers_new()); },
          "Three Advancing White Soldiers - bullish");
    m.def("cdl_3blackcrows", []() { return PyCDLIndicator(tk_cdl_3_black_crows_new()); },
          "Three Black Crows - bearish");
    m.def("cdl_3linestrike", []() { return PyCDLIndicator(tk_cdl_3_line_strike_new()); },
          "Three-Line Strike - continuation");
    m.def("cdl_abandonedbaby", []() { return PyCDLIndicator(tk_cdl_abandoned_baby_new()); },
          "Abandoned Baby - reversal with gaps");
    m.def("cdl_tristar", []() { return PyCDLIndicator(tk_cdl_tri_star_new()); },
          "Tristar Pattern - three dojis");
    m.def("cdl_identical3crows", []() { return PyCDLIndicator(tk_cdl_identical_3_crows_new()); },
          "Identical Three Crows - bearish");
    
    // Complex patterns (12)
    m.def("cdl_2crows", []() { return PyCDLIndicator(tk_cdl_2_crows_new()); },
          "Two Crows - bearish reversal");
    m.def("cdl_advanceblock", []() { return PyCDLIndicator(tk_cdl_advance_block_new()); },
          "Advance Block - diminishing momentum");
    m.def("cdl_breakaway", []() { return PyCDLIndicator(tk_cdl_breakaway_new()); },
          "Breakaway - 5-bar reversal");
    m.def("cdl_concealbabyswall", []() { return PyCDLIndicator(tk_cdl_conceal_baby_swall_new()); },
          "Concealing Baby Swallow - rare bullish");
    m.def("cdl_dojistar", []() { return PyCDLIndicator(tk_cdl_doji_star_new()); },
          "Doji Star - doji after gap");
    m.def("cdl_gapsidesidewhite", []() { return PyCDLIndicator(tk_cdl_gap_side_side_white_new()); },
          "Gap Side-by-Side White Lines");
    m.def("cdl_hikkake", []() { return PyCDLIndicator(tk_cdl_hikkake_new()); },
          "Hikkake Pattern - inside bar false breakout");
    m.def("cdl_hikkakemod", []() { return PyCDLIndicator(tk_cdl_hikkake_mod_new()); },
          "Modified Hikkake Pattern");
    m.def("cdl_ladderbottom", []() { return PyCDLIndicator(tk_cdl_ladder_bottom_new()); },
          "Ladder Bottom - 5-bar bullish");
    m.def("cdl_rickshawman", []() { return PyCDLIndicator(tk_cdl_rickshaw_man_new()); },
          "Rickshaw Man - long-legged doji");
    m.def("cdl_stalledpattern", []() { return PyCDLIndicator(tk_cdl_stalled_pattern_new()); },
          "Stalled Pattern - exhaustion");
    m.def("cdl_sticksandwich", []() { return PyCDLIndicator(tk_cdl_stick_sandwich_new()); },
          "Stick Sandwich - bullish reversal");
    
    // Final patterns (10)
    m.def("cdl_3starsinsouth", []() { return PyCDLIndicator(tk_cdl_3_stars_in_south_new()); },
          "Three Stars In The South - bullish reversal");
    m.def("cdl_longline", []() { return PyCDLIndicator(tk_cdl_long_line_new()); },
          "Long Line Candle - strong momentum");
    m.def("cdl_shortline", []() { return PyCDLIndicator(tk_cdl_short_line_new()); },
          "Short Line Candle - weak momentum");
    m.def("cdl_mathold", []() { return PyCDLIndicator(tk_cdl_mat_hold_new()); },
          "Mat Hold - continuation pattern");
    m.def("cdl_risefall3methods", []() { return PyCDLIndicator(tk_cdl_rise_fall_3_methods_new()); },
          "Rising/Falling Three Methods - continuation");
    m.def("cdl_takuri", []() { return PyCDLIndicator(tk_cdl_takuri_new()); },
          "Takuri - dragonfly doji with very long shadow");
    m.def("cdl_tasukigap", []() { return PyCDLIndicator(tk_cdl_tasuki_gap_new()); },
          "Tasuki Gap - continuation");
    m.def("cdl_unique3river", []() { return PyCDLIndicator(tk_cdl_unique_3_river_new()); },
          "Unique 3 River - bullish reversal");
    m.def("cdl_upsidegap2crows", []() { return PyCDLIndicator(tk_cdl_upside_gap_2_crows_new()); },
          "Upside Gap Two Crows - bearish");
    m.def("cdl_xsidegap3methods", []() { return PyCDLIndicator(tk_cdl_x_side_gap_3_methods_new()); },
          "Upside/Downside Gap Three Methods");
    
    /*============================================================
     * Phase 2: Enums for pattern types
     *============================================================*/
    
    // MA Types (matches TA-Lib's MA_Type)
    py::enum_<tk_ma_type>(m, "MAType")
        .value("SMA", TK_MA_SMA)
        .value("EMA", TK_MA_EMA)
        .value("WMA", TK_MA_WMA)
        .value("DEMA", TK_MA_DEMA)
        .value("TEMA", TK_MA_TEMA)
        .value("TRIMA", TK_MA_TRIMA)
        .value("KAMA", TK_MA_KAMA)
        .value("MAMA", TK_MA_MAMA)
        .value("T3", TK_MA_T3)
        .export_values();
    
    // Pivot Types
    py::enum_<tk_pivot_type>(m, "PivotType")
        .value("CLASSIC", TK_PIVOT_CLASSIC)
        .value("FIBONACCI", TK_PIVOT_FIBONACCI)
        .value("WOODIE", TK_PIVOT_WOODIE)
        .value("CAMARILLA", TK_PIVOT_CAMARILLA)
        .value("DEMARK", TK_PIVOT_DEMARK)
        .export_values();
    
    // Harmonic Pattern Types
    py::enum_<tk_harmonic_type>(m, "HarmonicType")
        .value("NONE", TK_HARMONIC_NONE)
        .value("GARTLEY_BULL", TK_HARMONIC_GARTLEY_BULL)
        .value("GARTLEY_BEAR", TK_HARMONIC_GARTLEY_BEAR)
        .value("BUTTERFLY_BULL", TK_HARMONIC_BUTTERFLY_BULL)
        .value("BUTTERFLY_BEAR", TK_HARMONIC_BUTTERFLY_BEAR)
        .value("BAT_BULL", TK_HARMONIC_BAT_BULL)
        .value("BAT_BEAR", TK_HARMONIC_BAT_BEAR)
        .value("CRAB_BULL", TK_HARMONIC_CRAB_BULL)
        .value("CRAB_BEAR", TK_HARMONIC_CRAB_BEAR)
        .value("SHARK_BULL", TK_HARMONIC_SHARK_BULL)
        .value("SHARK_BEAR", TK_HARMONIC_SHARK_BEAR)
        .value("CYPHER_BULL", TK_HARMONIC_CYPHER_BULL)
        .value("CYPHER_BEAR", TK_HARMONIC_CYPHER_BEAR)
        .export_values();
    
    // Chart Pattern Types
    py::enum_<tk_chart_pattern_type>(m, "ChartPatternType")
        .value("NONE", TK_CHART_NONE)
        .value("HEAD_SHOULDERS", TK_CHART_HEAD_SHOULDERS)
        .value("INV_HEAD_SHOULDERS", TK_CHART_INV_HEAD_SHOULDERS)
        .value("DOUBLE_TOP", TK_CHART_DOUBLE_TOP)
        .value("DOUBLE_BOTTOM", TK_CHART_DOUBLE_BOTTOM)
        .value("TRIPLE_TOP", TK_CHART_TRIPLE_TOP)
        .value("TRIPLE_BOTTOM", TK_CHART_TRIPLE_BOTTOM)
        .value("TRIANGLE_SYM", TK_CHART_TRIANGLE_SYM)
        .value("TRIANGLE_ASC", TK_CHART_TRIANGLE_ASC)
        .value("TRIANGLE_DESC", TK_CHART_TRIANGLE_DESC)
        .value("WEDGE_RISING", TK_CHART_WEDGE_RISING)
        .value("WEDGE_FALLING", TK_CHART_WEDGE_FALLING)
        .export_values();
}

