"""TechKit Python API - Object-Oriented Interface

This module provides Pythonic wrapper classes for TechKit indicators
with full NumPy integration.

Features:
    - **RAII Memory Management**: Automatic cleanup of C++ resources
    - **Incremental Updates**: O(1) update for streaming data
    - **Batch Calculation**: Vectorized NumPy operations
    - **Type Hints**: Full IDE support with type annotations
    - **Thread Safe**: Each indicator instance is independent

Example:
    Basic usage with incremental updates::

        >>> import numpy as np
        >>> from techkit import SMA, RSI
        >>>
        >>> prices = np.random.randn(100).cumsum() + 100
        >>>
        >>> # Object-oriented usage
        >>> sma = SMA(period=20)
        >>> for price in prices:
        ...     result = sma.update(price)
        ...     if result.valid:
        ...         print(f"SMA: {result.value:.2f}")

    Batch calculation::

        >>> rsi = RSI(period=14)
        >>> rsi_values = rsi.calculate(prices)
        >>> valid_rsi = rsi_values[~np.isnan(rsi_values)]

    Multi-output indicators::

        >>> from techkit import MACD, BBANDS
        >>> macd = MACD(fast=12, slow=26, signal=9)
        >>> result = macd.calculate(prices)
        >>> print(result.macd, result.signal, result.histogram)

Note:
    All indicators require the TechKit C++ extension to be installed.
    Install with: ``pip install techkit``

See Also:
    - :mod:`techkit.talib_compat`: TA-Lib compatible function API
    - :class:`Chain`: For chaining multiple indicators together
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Union, Iterator

import numpy as np
from numpy.typing import NDArray

import techkit._core as _tk


# ============================================================
# Result Types
# ============================================================


@dataclass
class IndicatorResult:
    """Result from single indicator update.

    Attributes:
        value: Calculated indicator value. NaN if not valid.
        valid: True if value is valid (warmup complete).

    Example:
        >>> sma = SMA(20)
        >>> result = sma.update(100.0)
        >>> if result.valid:
        ...     print(f"Value: {result.value:.2f}")
        >>> # Or use directly in if statement
        >>> if result:
        ...     print(result.value)

    Note:
        The ``__bool__`` method allows using the result directly
        in boolean contexts, checking validity.
    """

    value: float
    valid: bool

    def __bool__(self) -> bool:
        """Allow using result directly in if statements."""
        return self.valid

    def __repr__(self) -> str:
        if self.valid:
            return f"IndicatorResult({self.value:.6f})"
        return "IndicatorResult(invalid)"


@dataclass
class MACDResult:
    """Result from MACD calculation.

    Attributes:
        macd: MACD line (fast EMA - slow EMA)
        signal: Signal line (EMA of MACD)
        histogram: MACD histogram (macd - signal)

    Example:
        >>> macd_ind = MACD()
        >>> result = macd_ind.calculate(prices)
        >>> # Tuple unpacking
        >>> macd, signal, hist = result
        >>> # Or access attributes
        >>> print(result.macd[:5])
    """

    macd: NDArray[np.float64]
    signal: NDArray[np.float64]
    histogram: NDArray[np.float64]

    def __iter__(self) -> Iterator[NDArray[np.float64]]:
        """Allow tuple unpacking: macd, signal, hist = result"""
        return iter([self.macd, self.signal, self.histogram])


@dataclass
class BBandsResult:
    """Result from Bollinger Bands calculation.

    Attributes:
        upper: Upper band (middle + stddev * multiplier)
        middle: Middle band (SMA)
        lower: Lower band (middle - stddev * multiplier)

    Example:
        >>> bb = BBANDS(period=20, std_up=2.0)
        >>> upper, middle, lower = bb.calculate(prices)
    """

    upper: NDArray[np.float64]
    middle: NDArray[np.float64]
    lower: NDArray[np.float64]

    def __iter__(self) -> Iterator[NDArray[np.float64]]:
        """Allow tuple unpacking: upper, middle, lower = result"""
        return iter([self.upper, self.middle, self.lower])


@dataclass
class StochResult:
    """Result from Stochastic calculation.

    Attributes:
        slowk: %K line (slow stochastic)
        slowd: %D line (SMA of %K)

    Example:
        >>> stoch = STOCH(k_period=14, k_slow=3, d_period=3)
        >>> k, d = stoch.calculate(high, low, close)
    """

    slowk: NDArray[np.float64]
    slowd: NDArray[np.float64]

    def __iter__(self) -> Iterator[NDArray[np.float64]]:
        """Allow tuple unpacking: k, d = result"""
        return iter([self.slowk, self.slowd])


@dataclass
class AroonResult:
    """Result from Aroon calculation"""

    up: NDArray[np.float64]
    down: NDArray[np.float64]

    def __iter__(self) -> Iterator[NDArray[np.float64]]:
        return iter([self.up, self.down])


@dataclass
class MinMaxResult:
    """Result from MinMax calculation"""

    min: NDArray[np.float64]
    max: NDArray[np.float64]

    def __iter__(self) -> Iterator[NDArray[np.float64]]:
        return iter([self.min, self.max])


# ============================================================
# Base Indicator Class
# ============================================================


class Indicator:
    """Base class for all TechKit indicators.

    Provides common interface for indicator operations including
    incremental updates and batch calculations.

    Note:
        This is an abstract base class. Use specific indicator
        classes like :class:`SMA`, :class:`EMA`, :class:`RSI`, etc.

    Attributes:
        lookback: Number of bars needed before first valid output
        name: Indicator name string
        is_ready: True if warmup period is complete

    Example:
        >>> # All indicators inherit from this class
        >>> sma = SMA(20)
        >>> print(f"Lookback: {sma.lookback}")
        >>> print(f"Name: {sma.name}")
    """

    def __init__(self, indicator: _tk.Indicator) -> None:
        """Initialize with underlying C indicator.

        Args:
            indicator: TechKit C indicator handle
        """
        self._indicator = indicator

    def update(self, value: float) -> IndicatorResult:
        """Update indicator with single value.

        Args:
            value: Input value (typically close price)

        Returns:
            IndicatorResult with value and validity flag

        Example:
            >>> sma = SMA(20)
            >>> for price in prices:
            ...     r = sma.update(price)
            ...     if r:  # Using __bool__
            ...         print(r.value)
        """
        r = self._indicator.update(value)
        return IndicatorResult(r.value, r.valid)

    def calculate(self, data: Union[np.ndarray, list]) -> NDArray[np.float64]:
        """Calculate indicator for entire array.

        Args:
            data: Input array (1D NumPy array or list)

        Returns:
            NumPy array with indicator values (NaN during warmup)

        Example:
            >>> sma = SMA(20)
            >>> result = sma.calculate(prices)
            >>> valid_values = result[~np.isnan(result)]
        """
        arr = np.asarray(data, dtype=np.float64)
        return self._indicator.calculate(arr)

    def reset(self) -> None:
        """Reset indicator to initial state.

        Clears all internal state. After reset, indicator behaves
        as if newly created.
        """
        self._indicator.reset()

    @property
    def lookback(self) -> int:
        """Number of bars needed before first valid output."""
        return self._indicator.lookback

    @property
    def name(self) -> str:
        """Indicator name."""
        return self._indicator.name

    @property
    def is_ready(self) -> bool:
        """True if warmup period is complete."""
        return self._indicator.is_ready()


# ============================================================
# Moving Averages
# ============================================================


class SMA(Indicator):
    """Simple Moving Average.

    Calculates the arithmetic mean of prices over a period.

    Formula:
        SMA = sum(close, period) / period

    Args:
        period: Lookback period (default: 20)

    Attributes:
        period: The configured lookback period

    Example:
        >>> sma = SMA(period=20)
        >>> result = sma.calculate(prices)
        >>>
        >>> # Or incremental
        >>> for price in prices:
        ...     r = sma.update(price)
    """

    def __init__(self, period: int = 20) -> None:
        super().__init__(_tk.sma(period))
        self.period = period


class EMA(Indicator):
    """Exponential Moving Average.

    Gives more weight to recent prices using exponential decay.

    Formula:
        | k = 2 / (period + 1)
        | EMA = close * k + prev_EMA * (1 - k)

    Args:
        period: Lookback period (default: 20)

    Attributes:
        period: The configured lookback period

    Note:
        EMA responds faster to price changes than SMA due to
        exponential weighting of recent data.
    """

    def __init__(self, period: int = 20) -> None:
        super().__init__(_tk.ema(period))
        self.period = period


class WMA(Indicator):
    """Weighted Moving Average"""

    def __init__(self, period: int = 20) -> None:
        super().__init__(_tk.wma(period))
        self.period = period


class DEMA(Indicator):
    """Double Exponential Moving Average"""

    def __init__(self, period: int = 20) -> None:
        super().__init__(_tk.dema(period))
        self.period = period


class TEMA(Indicator):
    """Triple Exponential Moving Average"""

    def __init__(self, period: int = 20) -> None:
        super().__init__(_tk.tema(period))
        self.period = period


class KAMA(Indicator):
    """Kaufman Adaptive Moving Average"""

    def __init__(self, period: int = 30) -> None:
        super().__init__(_tk.kama(period))
        self.period = period


class TRIMA(Indicator):
    """Triangular Moving Average"""

    def __init__(self, period: int = 20) -> None:
        super().__init__(_tk.trima(period))
        self.period = period


class T3(Indicator):
    """T3 Moving Average"""

    def __init__(self, period: int = 5, volume_factor: float = 0.7) -> None:
        super().__init__(_tk.t3(period, volume_factor))
        self.period = period
        self.volume_factor = volume_factor


# ============================================================
# Momentum Indicators
# ============================================================


class RSI(Indicator):
    """Relative Strength Index.

    Measures momentum on a scale of 0-100.

    Interpretation:
        - Above 70: Overbought condition
        - Below 30: Oversold condition

    Args:
        period: Lookback period (default: 14)

    Attributes:
        period: The configured lookback period

    Example:
        >>> rsi = RSI(period=14)
        >>> result = rsi.calculate(prices)
        >>> overbought = result > 70
        >>> oversold = result < 30
    """

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.rsi(period))
        self.period = period


class MOM(Indicator):
    """Momentum"""

    def __init__(self, period: int = 10) -> None:
        super().__init__(_tk.mom(period))
        self.period = period


class ROC(Indicator):
    """Rate of Change"""

    def __init__(self, period: int = 10) -> None:
        super().__init__(_tk.roc(period))
        self.period = period


class ROCP(Indicator):
    """Rate of Change Percentage"""

    def __init__(self, period: int = 10) -> None:
        super().__init__(_tk.rocp(period))
        self.period = period


class ROCR(Indicator):
    """Rate of Change Ratio"""

    def __init__(self, period: int = 10) -> None:
        super().__init__(_tk.rocr(period))
        self.period = period


class ROCR100(Indicator):
    """Rate of Change Ratio * 100"""

    def __init__(self, period: int = 10) -> None:
        super().__init__(_tk.rocr100(period))
        self.period = period


class CCI(Indicator):
    """Commodity Channel Index"""

    def __init__(self, period: int = 20) -> None:
        super().__init__(_tk.cci(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class ADX(Indicator):
    """Average Directional Index"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.adx(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class ADXR(Indicator):
    """Average Directional Index Rating"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.adxr(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class APO(Indicator):
    """Absolute Price Oscillator"""

    def __init__(self, fast: int = 12, slow: int = 26) -> None:
        super().__init__(_tk.apo(fast, slow))
        self.fast = fast
        self.slow = slow


class PPO(Indicator):
    """Percentage Price Oscillator"""

    def __init__(self, fast: int = 12, slow: int = 26) -> None:
        super().__init__(_tk.ppo(fast, slow))
        self.fast = fast
        self.slow = slow


class CMO(Indicator):
    """Chande Momentum Oscillator"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.cmo(period))
        self.period = period


class DX(Indicator):
    """Directional Movement Index"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.dx(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class WILLR(Indicator):
    """Williams %R"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.willr(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class MFI(Indicator):
    """Money Flow Index"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.mfi(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class PLUS_DI(Indicator):
    """Plus Directional Indicator"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.plus_di(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class MINUS_DI(Indicator):
    """Minus Directional Indicator"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.minus_di(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class PLUS_DM(Indicator):
    """Plus Directional Movement"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.plus_dm(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class MINUS_DM(Indicator):
    """Minus Directional Movement"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.minus_dm(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class TRIX(Indicator):
    """Triple Exponential Average"""

    def __init__(self, period: int = 30) -> None:
        super().__init__(_tk.trix(period))
        self.period = period


class ULTOSC(Indicator):
    """Ultimate Oscillator"""

    def __init__(self, period1: int = 7, period2: int = 14, period3: int = 28) -> None:
        super().__init__(_tk.ultosc(period1, period2, period3))
        self.period1 = period1
        self.period2 = period2
        self.period3 = period3

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class AROONOSC(Indicator):
    """Aroon Oscillator"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.aroonosc(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class BOP(Indicator):
    """Balance of Power"""

    def __init__(self) -> None:
        super().__init__(_tk.bop())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class MACD(Indicator):
    """Moving Average Convergence Divergence.

    Trend-following momentum indicator showing relationship between
    two exponential moving averages.

    Outputs:
        - **MACD line**: EMA(fast) - EMA(slow)
        - **Signal line**: EMA(MACD, signal_period)
        - **Histogram**: MACD - Signal

    Args:
        fast: Fast EMA period (default: 12)
        slow: Slow EMA period (default: 26)
        signal: Signal EMA period (default: 9)

    Attributes:
        fast: Fast EMA period
        slow: Slow EMA period
        signal_period: Signal line period

    Example:
        >>> macd = MACD(fast=12, slow=26, signal=9)
        >>> result = macd.calculate(prices)
        >>> # Tuple unpacking
        >>> macd_line, signal_line, histogram = result
        >>> # Or access attributes
        >>> print(result.macd, result.signal, result.histogram)

    Note:
        The standard MACD uses periods 12, 26, 9 which are based on
        trading weeks (12 days ≈ 2 weeks, 26 days ≈ 1 month).
    """

    def __init__(self, fast: int = 12, slow: int = 26, signal: int = 9) -> None:
        self._indicator = _tk.macd(fast, slow, signal)
        self.fast = fast
        self.slow = slow
        self.signal_period = signal

    def update(self, value: float) -> _tk.MACDResult:
        """Update with single value.

        Args:
            value: Close price

        Returns:
            MACDResult with macd, signal, histogram values
        """
        return self._indicator.update_macd(value)

    def calculate(self, data: Union[np.ndarray, list]) -> MACDResult:
        """Calculate MACD for entire array.

        Args:
            data: Input price array

        Returns:
            MACDResult with macd, signal, histogram arrays
        """
        arr = np.asarray(data, dtype=np.float64)
        macd, signal, hist = self._indicator.calculate_macd(arr)
        return MACDResult(macd, signal, hist)


class STOCH(Indicator):
    """Stochastic Oscillator"""

    def __init__(
        self, k_period: int = 14, k_slow: int = 3, d_period: int = 3
    ) -> None:
        self._indicator = _tk.stoch(k_period, k_slow, d_period)
        self.k_period = k_period
        self.k_slow = k_slow
        self.d_period = d_period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> _tk.StochResult:
        """Update with OHLCV bar"""
        return self._indicator.update_stoch(open, high, low, close, volume)

    def calculate(
        self,
        high: np.ndarray,
        low: np.ndarray,
        close: np.ndarray,
    ) -> StochResult:
        """Calculate Stochastic for arrays"""
        h = np.asarray(high, dtype=np.float64)
        l = np.asarray(low, dtype=np.float64)
        c = np.asarray(close, dtype=np.float64)
        k, d = self._indicator.calculate_stoch(h, l, c)
        return StochResult(k, d)


class AROON(Indicator):
    """Aroon Indicator"""

    def __init__(self, period: int = 14) -> None:
        self._indicator = _tk.aroon(period)
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> _tk.AroonResult:
        """Update with OHLCV bar"""
        return self._indicator.update_aroon(open, high, low, close, volume)

    def calculate(
        self,
        high: np.ndarray,
        low: np.ndarray,
    ) -> AroonResult:
        """Calculate Aroon for arrays"""
        h = np.asarray(high, dtype=np.float64)
        l = np.asarray(low, dtype=np.float64)
        up, down = self._indicator.calculate_aroon(h, l)
        return AroonResult(up, down)


# ============================================================
# Volatility Indicators
# ============================================================


class ATR(Indicator):
    """Average True Range.

    Measures volatility using Wilder smoothing of True Range.

    Formula:
        | True Range = max(high-low, |high-prev_close|, |low-prev_close|)
        | ATR = Wilder_MA(True Range, period)

    Args:
        period: Lookback period (default: 14)

    Attributes:
        period: The configured lookback period

    Note:
        Requires OHLCV data. Use ``update_ohlcv()`` for incremental
        updates or pass OHLC arrays to ``calculate()``.

    Example:
        >>> atr = ATR(period=14)
        >>> atr_values = atr.calculate(open, high, low, close)
    """

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.atr(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar.

        Args:
            open: Open price
            high: High price
            low: Low price
            close: Close price
            volume: Volume (optional, default: 0)

        Returns:
            IndicatorResult with ATR value
        """
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)

    def calculate(  # type: ignore[override]
        self,
        open: np.ndarray,
        high: np.ndarray,
        low: np.ndarray,
        close: np.ndarray,
        volume: Optional[np.ndarray] = None,
    ) -> NDArray[np.float64]:
        """Calculate ATR for OHLCV arrays.

        Args:
            open: Open prices array
            high: High prices array
            low: Low prices array
            close: Close prices array
            volume: Volume array (optional)

        Returns:
            NumPy array with ATR values (NaN during warmup)
        """
        o = np.asarray(open, dtype=np.float64)
        h = np.asarray(high, dtype=np.float64)
        l = np.asarray(low, dtype=np.float64)
        c = np.asarray(close, dtype=np.float64)
        v = np.zeros_like(c) if volume is None else np.asarray(volume, dtype=np.float64)
        return self._indicator.calculate_ohlcv(o, h, l, c, v)


class NATR(ATR):
    """Normalized Average True Range"""

    def __init__(self, period: int = 14) -> None:
        Indicator.__init__(self, _tk.natr(period))
        self.period = period


class TRANGE(Indicator):
    """True Range"""

    def __init__(self) -> None:
        super().__init__(_tk.trange())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class BBANDS(Indicator):
    """Bollinger Bands.

    Upper and lower bands based on standard deviation from SMA.

    Formula:
        | Middle = SMA(close, period)
        | Upper = Middle + std_up * StdDev(close, period)
        | Lower = Middle - std_dn * StdDev(close, period)

    Args:
        period: SMA period (default: 20)
        std_up: Upper band multiplier (default: 2.0)
        std_dn: Lower band multiplier (default: 2.0)

    Attributes:
        period: SMA period
        std_up: Upper band standard deviation multiplier
        std_dn: Lower band standard deviation multiplier

    Example:
        >>> bb = BBANDS(period=20, std_up=2.0, std_dn=2.0)
        >>> upper, middle, lower = bb.calculate(prices)
        >>> # Check for price touching bands
        >>> touching_upper = prices >= upper
        >>> touching_lower = prices <= lower
    """

    def __init__(
        self, period: int = 20, std_up: float = 2.0, std_dn: float = 2.0
    ) -> None:
        self._indicator = _tk.bbands(period, std_up, std_dn)
        self.period = period
        self.std_up = std_up
        self.std_dn = std_dn

    def update(self, value: float) -> _tk.BBandsResult:
        """Update with single value.

        Args:
            value: Close price

        Returns:
            BBandsResult with upper, middle, lower values
        """
        return self._indicator.update_bbands(value)

    def calculate(self, data: Union[np.ndarray, list]) -> BBandsResult:
        """Calculate Bollinger Bands for array.

        Args:
            data: Input price array

        Returns:
            BBandsResult with upper, middle, lower arrays
        """
        arr = np.asarray(data, dtype=np.float64)
        upper, middle, lower = self._indicator.calculate_bbands(arr)
        return BBandsResult(upper, middle, lower)


# ============================================================
# Volume Indicators
# ============================================================


class OBV(Indicator):
    """On Balance Volume"""

    def __init__(self) -> None:
        super().__init__(_tk.obv())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class AD(Indicator):
    """Accumulation/Distribution"""

    def __init__(self) -> None:
        super().__init__(_tk.ad())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class ADOSC(Indicator):
    """A/D Oscillator"""

    def __init__(self, fast: int = 3, slow: int = 10) -> None:
        super().__init__(_tk.adosc(fast, slow))
        self.fast = fast
        self.slow = slow

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


# ============================================================
# Statistics
# ============================================================


class STDDEV(Indicator):
    """Standard Deviation"""

    def __init__(self, period: int = 5, nbdev: float = 1.0) -> None:
        super().__init__(_tk.stddev(period, nbdev))
        self.period = period
        self.nbdev = nbdev


class VAR(Indicator):
    """Variance"""

    def __init__(self, period: int = 5) -> None:
        super().__init__(_tk.var(period))
        self.period = period


class LINEARREG(Indicator):
    """Linear Regression"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.linearreg(period))
        self.period = period


class LINEARREG_SLOPE(Indicator):
    """Linear Regression Slope"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.linearreg_slope(period))
        self.period = period


class LINEARREG_INTERCEPT(Indicator):
    """Linear Regression Intercept"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.linearreg_intercept(period))
        self.period = period


class LINEARREG_ANGLE(Indicator):
    """Linear Regression Angle"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.linearreg_angle(period))
        self.period = period


class TSF(Indicator):
    """Time Series Forecast"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.tsf(period))
        self.period = period


class BETA(Indicator):
    """Beta"""

    def __init__(self, period: int = 5) -> None:
        super().__init__(_tk.beta(period))
        self.period = period


class CORREL(Indicator):
    """Pearson Correlation"""

    def __init__(self, period: int = 30) -> None:
        super().__init__(_tk.correl(period))
        self.period = period


# ============================================================
# Price Transform
# ============================================================


class AVGPRICE(Indicator):
    """Average Price"""

    def __init__(self) -> None:
        super().__init__(_tk.avgprice())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class MEDPRICE(Indicator):
    """Median Price"""

    def __init__(self) -> None:
        super().__init__(_tk.medprice())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class TYPPRICE(Indicator):
    """Typical Price"""

    def __init__(self) -> None:
        super().__init__(_tk.typprice())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class WCLPRICE(Indicator):
    """Weighted Close Price"""

    def __init__(self) -> None:
        super().__init__(_tk.wclprice())

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


# ============================================================
# Math Operators
# ============================================================


class MAX(Indicator):
    """Highest Value over Period"""

    def __init__(self, period: int = 30) -> None:
        super().__init__(_tk.max(period))
        self.period = period


class MIN(Indicator):
    """Lowest Value over Period"""

    def __init__(self, period: int = 30) -> None:
        super().__init__(_tk.min(period))
        self.period = period


class SUM(Indicator):
    """Sum over Period"""

    def __init__(self, period: int = 30) -> None:
        super().__init__(_tk.sum(period))
        self.period = period


class MIDPOINT(Indicator):
    """Midpoint over Period"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.midpoint(period))
        self.period = period


class MIDPRICE(Indicator):
    """Midpoint Price"""

    def __init__(self, period: int = 14) -> None:
        super().__init__(_tk.midprice(period))
        self.period = period

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


class MINMAX(Indicator):
    """Min and Max over Period"""

    def __init__(self, period: int = 30) -> None:
        self._indicator = _tk.minmax(period)
        self.period = period

    def update(self, value: float) -> _tk.MinMaxResult:
        """Update with single value"""
        return self._indicator.update_minmax(value)

    def calculate(self, data: Union[np.ndarray, list]) -> MinMaxResult:
        """Calculate MinMax for array"""
        arr = np.asarray(data, dtype=np.float64)
        min_arr, max_arr = self._indicator.calculate_minmax(arr)
        return MinMaxResult(min_arr, max_arr)


# ============================================================
# Hilbert Transform
# ============================================================


class HT_DCPERIOD(Indicator):
    """Hilbert Transform - Dominant Cycle Period"""

    def __init__(self) -> None:
        super().__init__(_tk.ht_dcperiod())


class HT_DCPHASE(Indicator):
    """Hilbert Transform - Dominant Cycle Phase"""

    def __init__(self) -> None:
        super().__init__(_tk.ht_dcphase())


class HT_TRENDMODE(Indicator):
    """Hilbert Transform - Trend vs Cycle Mode"""

    def __init__(self) -> None:
        super().__init__(_tk.ht_trendmode())


class HT_TRENDLINE(Indicator):
    """Hilbert Transform - Instantaneous Trendline"""

    def __init__(self) -> None:
        super().__init__(_tk.ht_trendline())


class HT_PHASOR(Indicator):
    """Hilbert Transform - Phasor Components"""

    def __init__(self) -> None:
        self._indicator = _tk.ht_phasor()

    def update(self, value: float) -> _tk.HTPhasorResult:
        """Update with single value"""
        return self._indicator.update_phasor(value)

    def calculate(
        self, data: Union[np.ndarray, list]
    ) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
        """Calculate HT Phasor for array, returns (inphase, quadrature)"""
        arr = np.asarray(data, dtype=np.float64)
        return self._indicator.calculate_phasor(arr)


class HT_SINE(Indicator):
    """Hilbert Transform - Sine Wave"""

    def __init__(self) -> None:
        self._indicator = _tk.ht_sine()

    def update(self, value: float) -> _tk.HTSineResult:
        """Update with single value"""
        return self._indicator.update_sine(value)

    def calculate(
        self, data: Union[np.ndarray, list]
    ) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
        """Calculate HT Sine for array, returns (sine, leadsine)"""
        arr = np.asarray(data, dtype=np.float64)
        return self._indicator.calculate_sine(arr)


# ============================================================
# Parabolic SAR
# ============================================================


class SAR(Indicator):
    """Parabolic SAR"""

    def __init__(self, acceleration: float = 0.02, maximum: float = 0.2) -> None:
        super().__init__(_tk.sar(acceleration, maximum))
        self.acceleration = acceleration
        self.maximum = maximum

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


# ============================================================
# Phase 2: Risk Metrics
# ============================================================


class SharpeRatio(Indicator):
    """Rolling Sharpe Ratio - risk-adjusted return measure.

    Args:
        period: Rolling window size (default: 252 for daily = 1 year)
        risk_free_rate: Risk-free rate per period (default: 0.0)
        annualization: Annualization factor (252 for daily, 52 for weekly, 12 for monthly)

    Note:
        Input should be period returns (not prices)
    """

    def __init__(
        self,
        period: int = 252,
        risk_free_rate: float = 0.0,
        annualization: int = 252,
    ) -> None:
        super().__init__(_tk.sharpe_ratio(period, risk_free_rate, annualization))
        self.period = period
        self.risk_free_rate = risk_free_rate
        self.annualization = annualization


class SortinoRatio(Indicator):
    """Rolling Sortino Ratio - downside risk-adjusted return.

    Args:
        period: Rolling window size (default: 252)
        risk_free_rate: Risk-free rate per period (default: 0.0)
        target_return: Target return for downside deviation (default: 0.0)
        annualization: Annualization factor (default: 252)

    Note:
        Input should be period returns (not prices)
    """

    def __init__(
        self,
        period: int = 252,
        risk_free_rate: float = 0.0,
        target_return: float = 0.0,
        annualization: int = 252,
    ) -> None:
        super().__init__(
            _tk.sortino_ratio(period, risk_free_rate, target_return, annualization)
        )
        self.period = period
        self.risk_free_rate = risk_free_rate
        self.target_return = target_return
        self.annualization = annualization


class MaxDrawdown(Indicator):
    """Maximum Drawdown from peak.

    Returns the maximum drawdown as a negative value (e.g., -0.15 for 15% drawdown).

    Note:
        Input should be prices (not returns)
    """

    def __init__(self) -> None:
        super().__init__(_tk.max_drawdown())


@dataclass
class DrawdownResult:
    """Result from Drawdown calculation"""

    drawdown: NDArray[np.float64]
    max_drawdown: NDArray[np.float64]
    duration: NDArray[np.int32]
    max_duration: NDArray[np.int32]

    def __iter__(self) -> Iterator:
        return iter([self.drawdown, self.max_drawdown, self.duration, self.max_duration])


class Drawdown(Indicator):
    """Drawdown Series with multi-output.

    Returns:
        - drawdown: Current drawdown (negative value)
        - max_drawdown: Maximum drawdown observed
        - duration: Current drawdown duration in bars
        - max_duration: Maximum drawdown duration

    Note:
        Input should be prices (not returns)
    """

    def __init__(self) -> None:
        self._indicator = _tk.drawdown()

    def update(self, price: float) -> _tk.DrawdownResult:
        """Update with price, returns DrawdownResult"""
        return self._indicator.update_drawdown(price)

    def calculate(self, data: Union[np.ndarray, list]) -> DrawdownResult:
        """Calculate Drawdown for entire array"""
        arr = np.asarray(data, dtype=np.float64)
        dd, mdd, dur, mdur = self._indicator.calculate_drawdown(arr)
        return DrawdownResult(dd, mdd, dur, mdur)


class CalmarRatio(Indicator):
    """Rolling Calmar Ratio - return / max drawdown.

    Args:
        period: Rolling window size (default: 756 = 3 years daily)
        annualization: Annualization factor (default: 252)

    Note:
        Input should be period returns (not prices)
    """

    def __init__(self, period: int = 756, annualization: int = 252) -> None:
        super().__init__(_tk.calmar_ratio(period, annualization))
        self.period = period
        self.annualization = annualization


class HistoricalVaR(Indicator):
    """Historical Value at Risk (VaR).

    Args:
        period: Rolling window size (default: 252)
        confidence: Confidence level (default: 0.95 = 95%)

    Returns:
        VaR as a negative value representing potential loss

    Note:
        Input should be period returns (not prices)
    """

    def __init__(self, period: int = 252, confidence: float = 0.95) -> None:
        super().__init__(_tk.hist_var(period, confidence))
        self.period = period
        self.confidence = confidence


class CVaR(Indicator):
    """Conditional VaR / Expected Shortfall.

    Args:
        period: Rolling window size (default: 252)
        confidence: Confidence level (default: 0.95)

    Returns:
        CVaR = E[return | return <= VaR], more negative than VaR

    Note:
        Input should be period returns (not prices)
    """

    def __init__(self, period: int = 252, confidence: float = 0.95) -> None:
        super().__init__(_tk.cvar(period, confidence))
        self.period = period
        self.confidence = confidence


# ============================================================
# Phase 2: Volatility Models
# ============================================================


class EWMAVolatility(Indicator):
    """EWMA Volatility (RiskMetrics methodology).

    Args:
        lambda_: Decay factor (0.94 for daily RiskMetrics, 0.97 for monthly)
        annualization: Trading days per year (default: 252)

    Note:
        Input should be period returns (not prices)
    """

    def __init__(self, lambda_: float = 0.94, annualization: int = 252) -> None:
        super().__init__(_tk.ewma_vol(lambda_, annualization))
        self.lambda_ = lambda_
        self.annualization = annualization


class RealizedVolatility(Indicator):
    """Realized Volatility (Rolling Window).

    Args:
        period: Rolling window size (default: 21 = ~1 month)
        annualization: Trading days per year (default: 252)

    Note:
        Input should be period returns (not prices)
    """

    def __init__(self, period: int = 21, annualization: int = 252) -> None:
        super().__init__(_tk.realized_vol(period, annualization))
        self.period = period
        self.annualization = annualization


class ParkinsonVolatility(Indicator):
    """Parkinson Volatility (high-low based).

    More efficient than close-to-close volatility, using ~5x less data
    for the same precision.

    Args:
        period: Rolling window size (default: 21)
        annualization: Trading days per year (default: 252)

    Note:
        Requires OHLCV input via update_ohlcv()
    """

    def __init__(self, period: int = 21, annualization: int = 252) -> None:
        super().__init__(_tk.parkinson_vol(period, annualization))
        self.period = period
        self.annualization = annualization

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)

    def calculate(  # type: ignore[override]
        self,
        open: np.ndarray,
        high: np.ndarray,
        low: np.ndarray,
        close: np.ndarray,
        volume: Optional[np.ndarray] = None,
    ) -> NDArray[np.float64]:
        """Calculate Parkinson Volatility for arrays"""
        o = np.asarray(open, dtype=np.float64)
        h = np.asarray(high, dtype=np.float64)
        l = np.asarray(low, dtype=np.float64)
        c = np.asarray(close, dtype=np.float64)
        v = np.zeros_like(c) if volume is None else np.asarray(volume, dtype=np.float64)
        return self._indicator.calculate_ohlcv(o, h, l, c, v)


class GARCHVolatility(Indicator):
    """GARCH(1,1) Volatility Model.

    Args:
        omega: Constant term (long-run variance weight, default: 0.000001)
        alpha: ARCH coefficient - shock impact (default: 0.09)
        beta: GARCH coefficient - persistence (default: 0.90)
        annualization: Trading days per year (default: 252)

    Note:
        For stationarity: alpha + beta < 1
        Input should be period returns (not prices)
    """

    def __init__(
        self,
        omega: float = 0.000001,
        alpha: float = 0.09,
        beta: float = 0.90,
        annualization: int = 252,
    ) -> None:
        super().__init__(_tk.garch_vol(omega, alpha, beta, annualization))
        self.omega = omega
        self.alpha = alpha
        self.beta = beta
        self.annualization = annualization


# ============================================================
# Phase 2: Structure Analysis
# ============================================================


@dataclass
class ZigZagResult:
    """Result from ZigZag update"""

    value: float
    direction: int  # 1=up, -1=down, 0=undefined
    is_pivot: bool
    pivot_type: int  # 1=swing high, -1=swing low
    last_pivot_price: float
    bars_since_pivot: int
    valid: bool

    def __bool__(self) -> bool:
        return self.valid


class ZigZag(Indicator):
    """ZigZag indicator for trend visualization.

    Args:
        deviation_pct: Minimum reversal percentage (default: 5.0%)
        depth: Minimum bars between pivots (default: 12)

    Note:
        Requires OHLCV input via update_ohlcv()
    """

    def __init__(self, deviation_pct: float = 5.0, depth: int = 12) -> None:
        self._indicator = _tk.zigzag(deviation_pct, depth)
        self.deviation_pct = deviation_pct
        self.depth = depth

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> _tk.ZigZagResult:
        """Update with OHLCV bar, returns ZigZagResult"""
        return self._indicator.update_zigzag(open, high, low, close, volume)

    def calculate(  # type: ignore[override]
        self,
        open: np.ndarray,
        high: np.ndarray,
        low: np.ndarray,
        close: np.ndarray,
        volume: Optional[np.ndarray] = None,
    ) -> NDArray[np.float64]:
        """Calculate ZigZag for OHLCV arrays"""
        o = np.asarray(open, dtype=np.float64)
        h = np.asarray(high, dtype=np.float64)
        l = np.asarray(low, dtype=np.float64)
        c = np.asarray(close, dtype=np.float64)
        v = np.zeros_like(c) if volume is None else np.asarray(volume, dtype=np.float64)
        return self._indicator.calculate_zigzag(o, h, l, c, v)


@dataclass
class SwingResult:
    """Result from Swing High/Low detection"""

    swing_high: NDArray[np.float64]
    swing_low: NDArray[np.float64]

    def __iter__(self) -> Iterator[NDArray[np.float64]]:
        return iter([self.swing_high, self.swing_low])


class SwingHighLow(Indicator):
    """Swing High/Low detection.

    Args:
        left_bars: Bars to left for confirmation (default: 5)
        right_bars: Bars to right for confirmation (default: 5)

    Note:
        Outputs with right_bars delay (needs future bars to confirm)
        Requires OHLCV input
    """

    def __init__(self, left_bars: int = 5, right_bars: int = 5) -> None:
        self._indicator = _tk.swing(left_bars, right_bars)
        self.left_bars = left_bars
        self.right_bars = right_bars

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> _tk.SwingResult:
        """Update with OHLCV bar, returns SwingResult"""
        return self._indicator.update_swing(open, high, low, close, volume)

    def calculate(
        self,
        high: np.ndarray,
        low: np.ndarray,
    ) -> SwingResult:
        """Calculate Swing High/Low for arrays"""
        h = np.asarray(high, dtype=np.float64)
        l = np.asarray(low, dtype=np.float64)
        sh, sl = self._indicator.calculate_swing(h, l)
        return SwingResult(sh, sl)


@dataclass
class PivotPointsResult:
    """Result from Pivot Points calculation"""

    pp: float  # Pivot Point
    r1: float  # Resistance 1
    r2: float  # Resistance 2
    r3: float  # Resistance 3
    s1: float  # Support 1
    s2: float  # Support 2
    s3: float  # Support 3
    valid: bool

    def __bool__(self) -> bool:
        return self.valid


class PivotPoints(Indicator):
    """Pivot Points calculation.

    Args:
        pivot_type: Calculation type
            - 0: Classic (PP = (H+L+C)/3)
            - 1: Fibonacci (uses 0.382, 0.618, 1.0 ratios)
            - 2: Woodie (PP = (H+L+2C)/4)
            - 3: Camarilla
            - 4: DeMark

    Note:
        Feed daily/weekly bars, outputs pivots for next period
    """

    CLASSIC = 0
    FIBONACCI = 1
    WOODIE = 2
    CAMARILLA = 3
    DEMARK = 4

    def __init__(self, pivot_type: int = 0) -> None:
        self._indicator = _tk.pivot_points(pivot_type)
        self.pivot_type = pivot_type

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> _tk.PivotResult:
        """Update with OHLCV bar, returns PivotResult"""
        return self._indicator.update_pivot(open, high, low, close, volume)

    @staticmethod
    def calculate_from_hlc(
        high: float,
        low: float,
        close: float,
        prev_close: float = 0.0,
        pivot_type: int = 0,
    ) -> PivotPointsResult:
        """Calculate pivot points from HLC values (static)"""
        r = _tk.PivotIndicator.calculate(high, low, close, prev_close, pivot_type)
        return PivotPointsResult(r.pp, r.r1, r.r2, r.r3, r.s1, r.s2, r.s3, r.valid)


# ============================================================
# Phase 2: Harmonic Patterns
# ============================================================


class HarmonicPattern(Indicator):
    """Harmonic Pattern Detector.

    Detects 6 harmonic patterns: Gartley, Butterfly, Bat, Crab, Shark, Cypher.

    Args:
        deviation_pct: ZigZag deviation for pivot detection (default: 5.0%)
        tolerance: Fibonacci ratio tolerance (default: 0.03 = ±3%)
        max_bars: Maximum bars for pattern formation (default: 100)

    Pattern Types (from HarmonicResult.pattern):
        - 0: None
        - 1-2: Gartley (Bull/Bear)
        - 3-4: Butterfly (Bull/Bear)
        - 5-6: Bat (Bull/Bear)
        - 7-8: Crab (Bull/Bear)
        - 9-10: Shark (Bull/Bear)
        - 11-12: Cypher (Bull/Bear)

    Note:
        Requires OHLCV input
    """

    # Pattern type constants
    NONE = 0
    GARTLEY_BULL = 1
    GARTLEY_BEAR = 2
    BUTTERFLY_BULL = 3
    BUTTERFLY_BEAR = 4
    BAT_BULL = 5
    BAT_BEAR = 6
    CRAB_BULL = 7
    CRAB_BEAR = 8
    SHARK_BULL = 9
    SHARK_BEAR = 10
    CYPHER_BULL = 11
    CYPHER_BEAR = 12

    def __init__(
        self,
        deviation_pct: float = 5.0,
        tolerance: float = 0.03,
        max_bars: int = 100,
    ) -> None:
        self._indicator = _tk.harmonic(deviation_pct, tolerance, max_bars)
        self.deviation_pct = deviation_pct
        self.tolerance = tolerance
        self.max_bars = max_bars

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> _tk.HarmonicResult:
        """Update with OHLCV bar, returns HarmonicResult"""
        return self._indicator.update_harmonic(open, high, low, close, volume)

    @staticmethod
    def pattern_name(pattern_type: int) -> str:
        """Get human-readable pattern name"""
        return _tk.HarmonicIndicator.pattern_name(pattern_type)


# ============================================================
# Phase 2: Chart Patterns
# ============================================================


class ChartPattern(Indicator):
    """Chart Pattern Detector.

    Detects classic chart patterns:
        - Head and Shoulders (regular and inverse)
        - Double Top / Double Bottom
        - Triple Top / Triple Bottom
        - Triangle patterns (Symmetrical, Ascending, Descending)
        - Wedge patterns (Rising, Falling)

    Args:
        min_bars: Minimum bars for pattern formation (default: 20)
        max_bars: Maximum bars for pattern (default: 200)
        tolerance: Tolerance for level matching (default: 0.03 = 3%)

    Pattern Types (from ChartPatternResult.pattern):
        - 0: None
        - 1: Head and Shoulders (bearish)
        - 2: Inverse Head and Shoulders (bullish)
        - 3: Double Top (bearish)
        - 4: Double Bottom (bullish)
        - 5: Triple Top (bearish)
        - 6: Triple Bottom (bullish)
        - 7: Symmetrical Triangle (continuation)
        - 8: Ascending Triangle (bullish)
        - 9: Descending Triangle (bearish)
        - 10: Rising Wedge (bearish)
        - 11: Falling Wedge (bullish)

    Note:
        Requires OHLCV input
    """

    # Pattern type constants
    NONE = 0
    HEAD_SHOULDERS = 1
    INV_HEAD_SHOULDERS = 2
    DOUBLE_TOP = 3
    DOUBLE_BOTTOM = 4
    TRIPLE_TOP = 5
    TRIPLE_BOTTOM = 6
    TRIANGLE_SYM = 7
    TRIANGLE_ASC = 8
    TRIANGLE_DESC = 9
    WEDGE_RISING = 10
    WEDGE_FALLING = 11

    def __init__(
        self,
        min_bars: int = 20,
        max_bars: int = 200,
        tolerance: float = 0.03,
    ) -> None:
        self._indicator = _tk.chart_pattern(min_bars, max_bars, tolerance)
        self.min_bars = min_bars
        self.max_bars = max_bars
        self.tolerance = tolerance

    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> _tk.ChartPatternResult:
        """Update with OHLCV bar, returns ChartPatternResult"""
        return self._indicator.update_pattern(open, high, low, close, volume)

    @staticmethod
    def pattern_name(pattern_type: int) -> str:
        """Get human-readable pattern name"""
        return _tk.ChartPatternIndicator.pattern_name(pattern_type)


# ============================================================
# Phase 3: Candlestick Pattern Recognition (61 patterns)
# ============================================================


@dataclass
class CDLResult:
    """Candlestick pattern detection result.
    
    Attributes:
        signal: Pattern signal (+100 bullish, -100 bearish, 0 none)
        valid: Whether the result is valid
    """
    signal: int
    valid: bool
    
    def __bool__(self) -> bool:
        return self.valid and self.signal != 0
    
    @property
    def is_bullish(self) -> bool:
        """True if bullish pattern detected"""
        return self.signal > 0
    
    @property
    def is_bearish(self) -> bool:
        """True if bearish pattern detected"""
        return self.signal < 0


class CDLIndicator:
    """Base class for candlestick pattern indicators.
    
    All CDL indicators:
    - Take OHLC data as input
    - Return integer signals: +100 (bullish), -100 (bearish), 0 (none)
    """
    
    def __init__(self, indicator) -> None:
        self._indicator = indicator
    
    def update(self, open: float, high: float, low: float, close: float) -> CDLResult:
        """Update with single OHLC bar."""
        r = self._indicator.update(open, high, low, close)
        return CDLResult(signal=r.signal, valid=r.valid)
    
    def calculate(self, open: np.ndarray, high: np.ndarray, 
                  low: np.ndarray, close: np.ndarray) -> NDArray[np.int32]:
        """Batch calculation on OHLC arrays. Returns array of signals."""
        return self._indicator.calculate(
            np.asarray(open, dtype=np.float64),
            np.asarray(high, dtype=np.float64),
            np.asarray(low, dtype=np.float64),
            np.asarray(close, dtype=np.float64)
        )
    
    def reset(self) -> None:
        """Reset indicator state"""
        self._indicator.reset()
    
    @property
    def lookback(self) -> int:
        """Number of bars required for warmup"""
        return self._indicator.lookback
    
    @property
    def name(self) -> str:
        """Indicator name"""
        return self._indicator.name


# Single candle patterns (12)

class CDL_DOJI(CDLIndicator):
    """Doji - indecision pattern with open ≈ close."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_doji())


class CDL_DRAGONFLYDOJI(CDLIndicator):
    """Dragonfly Doji - T-shaped doji with long lower shadow."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_dragonflydoji())


class CDL_GRAVESTONEDOJI(CDLIndicator):
    """Gravestone Doji - inverted T-shaped doji with long upper shadow."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_gravestonedoji())


class CDL_LONGLEGGEDDOJI(CDLIndicator):
    """Long Legged Doji - doji with long upper and lower shadows."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_longleggeddoji())


class CDL_HAMMER(CDLIndicator):
    """Hammer - bullish reversal with small body at top, long lower shadow."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_hammer())


class CDL_INVERTEDHAMMER(CDLIndicator):
    """Inverted Hammer - bullish reversal with long upper shadow."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_invertedhammer())


class CDL_HANGINGMAN(CDLIndicator):
    """Hanging Man - bearish reversal (hammer shape in uptrend)."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_hangingman())


class CDL_SHOOTINGSTAR(CDLIndicator):
    """Shooting Star - bearish reversal with small body at bottom."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_shootingstar())


class CDL_MARUBOZU(CDLIndicator):
    """Marubozu - candle with no shadows (strong momentum)."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_marubozu())


class CDL_CLOSINGMARUBOZU(CDLIndicator):
    """Closing Marubozu - no shadow at the closing end."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_closingmarubozu())


class CDL_SPINNINGTOP(CDLIndicator):
    """Spinning Top - small body with shadows on both sides."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_spinningtop())


class CDL_HIGHWAVE(CDLIndicator):
    """High-Wave Candle - very long shadows indicating volatility."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_highwave())


# Two candle patterns (15)

class CDL_ENGULFING(CDLIndicator):
    """Engulfing Pattern - second candle completely engulfs first."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_engulfing())


class CDL_HARAMI(CDLIndicator):
    """Harami Pattern - second candle contained within first."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_harami())


class CDL_HARAMICROSS(CDLIndicator):
    """Harami Cross Pattern - harami where second candle is doji."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_haramicross())


class CDL_PIERCING(CDLIndicator):
    """Piercing Pattern - bullish reversal, second candle closes above midpoint."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_piercing())


class CDL_DARKCLOUDCOVER(CDLIndicator):
    """Dark Cloud Cover - bearish reversal, second candle closes below midpoint."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_darkcloudcover())


class CDL_BELTHOLD(CDLIndicator):
    """Belt-hold - marubozu opening at extreme."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_belthold())


class CDL_COUNTERATTACK(CDLIndicator):
    """Counterattack - opposing candles closing at same level."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_counterattack())


class CDL_HOMINGPIGEON(CDLIndicator):
    """Homing Pigeon - bullish harami variation."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_homingpigeon())


class CDL_INNECK(CDLIndicator):
    """In-Neck Pattern - bearish continuation (close inside prior close)."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_inneck())


class CDL_ONNECK(CDLIndicator):
    """On-Neck Pattern - bearish continuation."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_onneck())


class CDL_MATCHINGLOW(CDLIndicator):
    """Matching Low - two candles with same close in downtrend."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_matchinglow())


class CDL_KICKING(CDLIndicator):
    """Kicking - two marubozu with gap between."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_kicking())


class CDL_KICKINGBYLENGTH(CDLIndicator):
    """Kicking - bull/bear determined by longer marubozu."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_kickingbylength())


class CDL_SEPARATINGLINES(CDLIndicator):
    """Separating Lines - continuation pattern."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_separatinglines())


class CDL_THRUSTING(CDLIndicator):
    """Thrusting Pattern - bearish continuation."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_thrusting())


# Three candle patterns (12)

class CDL_MORNINGSTAR(CDLIndicator):
    """Morning Star - bullish reversal with star in middle."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_morningstar())


class CDL_EVENINGSTAR(CDLIndicator):
    """Evening Star - bearish reversal with star in middle."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_eveningstar())


class CDL_MORNINGDOJISTAR(CDLIndicator):
    """Morning Doji Star - morning star with doji in middle."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_morningdojistar())


class CDL_EVENINGDOJISTAR(CDLIndicator):
    """Evening Doji Star - evening star with doji in middle."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_eveningdojistar())


class CDL_3INSIDE(CDLIndicator):
    """Three Inside Up/Down - harami followed by confirmation."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_3inside())


class CDL_3OUTSIDE(CDLIndicator):
    """Three Outside Up/Down - engulfing followed by confirmation."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_3outside())


class CDL_3WHITESOLDIERS(CDLIndicator):
    """Three Advancing White Soldiers - three consecutive bullish candles."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_3whitesoldiers())


class CDL_3BLACKCROWS(CDLIndicator):
    """Three Black Crows - three consecutive bearish candles."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_3blackcrows())


class CDL_3LINESTRIKE(CDLIndicator):
    """Three-Line Strike - three trending candles followed by opposite strike."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_3linestrike())


class CDL_ABANDONEDBABY(CDLIndicator):
    """Abandoned Baby - reversal with gap around middle candle."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_abandonedbaby())


class CDL_TRISTAR(CDLIndicator):
    """Tristar Pattern - three doji stars."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_tristar())


class CDL_IDENTICAL3CROWS(CDLIndicator):
    """Identical Three Crows - three crows opening at prior close."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_identical3crows())


# Complex patterns (12)

class CDL_2CROWS(CDLIndicator):
    """Two Crows - bearish reversal."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_2crows())


class CDL_ADVANCEBLOCK(CDLIndicator):
    """Advance Block - three candles with decreasing momentum."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_advanceblock())


class CDL_BREAKAWAY(CDLIndicator):
    """Breakaway - five candle reversal pattern."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_breakaway())


class CDL_CONCEALBABYSWALL(CDLIndicator):
    """Concealing Baby Swallow - rare bullish reversal."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_concealbabyswall())


class CDL_DOJISTAR(CDLIndicator):
    """Doji Star - doji after a long candle with gap."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_dojistar())


class CDL_GAPSIDESIDEWHITE(CDLIndicator):
    """Up/Down-gap side-by-side white lines - continuation pattern."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_gapsidesidewhite())


class CDL_HIKKAKE(CDLIndicator):
    """Hikkake Pattern - inside bar followed by false breakout."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_hikkake())


class CDL_HIKKAKEMOD(CDLIndicator):
    """Modified Hikkake Pattern - variation of hikkake."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_hikkakemod())


class CDL_LADDERBOTTOM(CDLIndicator):
    """Ladder Bottom - five candle bullish reversal."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_ladderbottom())


class CDL_RICKSHAWMAN(CDLIndicator):
    """Rickshaw Man - long-legged doji near middle of range."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_rickshawman())


class CDL_STALLEDPATTERN(CDLIndicator):
    """Stalled Pattern - advance losing momentum."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_stalledpattern())


class CDL_STICKSANDWICH(CDLIndicator):
    """Stick Sandwich - two candles with same close sandwiching opposite."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_sticksandwich())


# Final patterns (10)

class CDL_3STARSINSOUTH(CDLIndicator):
    """Three Stars In The South - bullish reversal with decreasing shadows."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_3starsinsouth())


class CDL_LONGLINE(CDLIndicator):
    """Long Line Candle - candle with long body."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_longline())


class CDL_SHORTLINE(CDLIndicator):
    """Short Line Candle - candle with short body."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_shortline())


class CDL_MATHOLD(CDLIndicator):
    """Mat Hold - continuation pattern with pullback."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_mathold())


class CDL_RISEFALL3METHODS(CDLIndicator):
    """Rising/Falling Three Methods - continuation with consolidation."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_risefall3methods())


class CDL_TAKURI(CDLIndicator):
    """Takuri - dragonfly doji with very long lower shadow."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_takuri())


class CDL_TASUKIGAP(CDLIndicator):
    """Tasuki Gap - continuation pattern with gap."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_tasukigap())


class CDL_UNIQUE3RIVER(CDLIndicator):
    """Unique 3 River - rare bullish reversal pattern."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_unique3river())


class CDL_UPSIDEGAP2CROWS(CDLIndicator):
    """Upside Gap Two Crows - bearish reversal with gap up."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_upsidegap2crows())


class CDL_XSIDEGAP3METHODS(CDLIndicator):
    """Upside/Downside Gap Three Methods - continuation with gap."""
    def __init__(self) -> None:
        super().__init__(_tk.cdl_xsidegap3methods())


# ============================================================
# Phase 4: Remaining Indicators (7)
# ============================================================


class MAType:
    """Moving Average type constants (matches TA-Lib's MA_Type)."""
    SMA = 0
    EMA = 1
    WMA = 2
    DEMA = 3
    TEMA = 4
    TRIMA = 5
    KAMA = 6
    MAMA = 7  # Not implemented
    T3 = 8


class MA(Indicator):
    """Generic Moving Average with type selection.
    
    Parameters:
        period: Averaging period
        ma_type: Type of MA (0=SMA, 1=EMA, 2=WMA, 3=DEMA, 4=TEMA, 5=TRIMA, 6=KAMA, 8=T3)
    """
    def __init__(self, period: int = 30, ma_type: int = MAType.SMA) -> None:
        super().__init__(_tk.ma(period, ma_type))
        self.period = period
        self.ma_type = ma_type


class MAVP(Indicator):
    """Variable Period Moving Average.
    
    Calculates MA with period that varies based on another input series.
    
    Parameters:
        min_period: Minimum period allowed
        max_period: Maximum period allowed
        ma_type: Moving average type
        
    Note:
        Requires special dual input via tk_mavp_update(value, period).
        The standard update() method uses fixed period.
    """
    def __init__(self, min_period: int = 2, max_period: int = 30, 
                 ma_type: int = MAType.SMA) -> None:
        super().__init__(_tk.mavp(min_period, max_period, ma_type))
        self.min_period = min_period
        self.max_period = max_period
        self.ma_type = ma_type


class SAREXT(Indicator):
    """Extended Parabolic SAR with full parameter control.
    
    Parameters:
        start_value: Start value for SAR (0 = auto-detect)
        offset_on_reverse: Offset when trend reverses
        af_init_long: Initial acceleration factor for long
        af_long: Acceleration factor increment for long
        af_max_long: Maximum acceleration factor for long
        af_init_short: Initial acceleration factor for short
        af_short: Acceleration factor increment for short
        af_max_short: Maximum acceleration factor for short
        
    Note:
        Requires OHLCV input via update_ohlcv()
    """
    def __init__(self, 
                 start_value: float = 0.0,
                 offset_on_reverse: float = 0.0,
                 af_init_long: float = 0.02,
                 af_long: float = 0.02,
                 af_max_long: float = 0.20,
                 af_init_short: float = 0.02,
                 af_short: float = 0.02,
                 af_max_short: float = 0.20) -> None:
        super().__init__(_tk.sarext(
            start_value, offset_on_reverse,
            af_init_long, af_long, af_max_long,
            af_init_short, af_short, af_max_short
        ))
    
    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> IndicatorResult:
        """Update with OHLCV bar"""
        r = self._indicator.update_ohlcv(open, high, low, close, volume)
        return IndicatorResult(r.value, r.valid)


@dataclass
class StochFResult:
    """Result from Fast Stochastic calculation"""
    k: NDArray[np.float64]
    d: NDArray[np.float64]

    def __iter__(self) -> Iterator[NDArray[np.float64]]:
        return iter([self.k, self.d])


class STOCHF(Indicator):
    """Fast Stochastic Oscillator.
    
    Unlike full Stochastic, Fast Stochastic doesn't smooth %K.
    
    Parameters:
        k_period: %K period
        d_period: %D period (SMA of %K)
    
    Returns:
        StochFResult with k and d values
        
    Note:
        Requires OHLCV input via update_ohlcv()
    """
    def __init__(self, k_period: int = 5, d_period: int = 3) -> None:
        self._indicator = _tk.stochf(k_period, d_period)
        self.k_period = k_period
        self.d_period = d_period
    
    def update_ohlcv(
        self,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
    ) -> _tk.StochFResult:
        """Update with OHLCV bar, returns StochFResult"""
        return self._indicator.update_stochf(open, high, low, close, volume)
    
    def calculate(
        self,
        high: np.ndarray,
        low: np.ndarray,
        close: np.ndarray,
    ) -> StochFResult:
        """Calculate Fast Stochastic for arrays"""
        h = np.asarray(high, dtype=np.float64)
        l = np.asarray(low, dtype=np.float64)
        c = np.asarray(close, dtype=np.float64)
        k, d = self._indicator.calculate_stochf(h, l, c)
        return StochFResult(k, d)


@dataclass
class StochRSIResult:
    """Result from Stochastic RSI calculation"""
    k: NDArray[np.float64]
    d: NDArray[np.float64]

    def __iter__(self) -> Iterator[NDArray[np.float64]]:
        return iter([self.k, self.d])


class STOCHRSI(Indicator):
    """Stochastic RSI - applies Stochastic calculation to RSI values.
    
    Parameters:
        rsi_period: RSI calculation period
        stoch_period: Stochastic calculation period
        k_smooth: %K smoothing period
        d_period: %D smoothing period
    
    Returns:
        StochRSIResult with k and d values
    """
    def __init__(self, rsi_period: int = 14, stoch_period: int = 14,
                 k_smooth: int = 3, d_period: int = 3) -> None:
        self._indicator = _tk.stochrsi(rsi_period, stoch_period, k_smooth, d_period)
        self.rsi_period = rsi_period
        self.stoch_period = stoch_period
        self.k_smooth = k_smooth
        self.d_period = d_period
    
    def update(self, value: float) -> _tk.StochRSIResult:
        """Update with single value, returns StochRSIResult"""
        return self._indicator.update_stochrsi(value)
    
    def calculate(self, data: Union[np.ndarray, list]) -> StochRSIResult:
        """Calculate Stochastic RSI for array"""
        arr = np.asarray(data, dtype=np.float64)
        k, d = self._indicator.calculate_stochrsi(arr)
        return StochRSIResult(k, d)


class MACDEXT(Indicator):
    """Extended MACD with MA type selection.
    
    Allows using different MA types for fast, slow, and signal lines.
    
    Parameters:
        fast_period: Fast MA period
        slow_period: Slow MA period
        signal_period: Signal line period
        fast_ma_type: MA type for fast line (default EMA)
        slow_ma_type: MA type for slow line (default EMA)
        signal_ma_type: MA type for signal line (default EMA)
    
    Returns:
        MACDResult with macd, signal, histogram
    """
    def __init__(self, fast_period: int = 12, slow_period: int = 26,
                 signal_period: int = 9,
                 fast_ma_type: int = MAType.EMA,
                 slow_ma_type: int = MAType.EMA,
                 signal_ma_type: int = MAType.EMA) -> None:
        self._indicator = _tk.macdext(
            fast_period, fast_ma_type,
            slow_period, slow_ma_type,
            signal_period, signal_ma_type
        )
        self.fast_period = fast_period
        self.slow_period = slow_period
        self.signal_period = signal_period
        self.fast_ma_type = fast_ma_type
        self.slow_ma_type = slow_ma_type
        self.signal_ma_type = signal_ma_type
    
    def update(self, value: float) -> _tk.MACDResult:
        """Update with single value, returns MACDResult"""
        return self._indicator.update_macd(value)
    
    def calculate(self, data: Union[np.ndarray, list]) -> MACDResult:
        """Calculate MACDEXT for entire array"""
        arr = np.asarray(data, dtype=np.float64)
        macd, signal, hist = self._indicator.calculate_macd(arr)
        return MACDResult(macd, signal, hist)


class MACDFIX(Indicator):
    """Fixed Period MACD (12, 26, signal).
    
    Standard MACD with fixed fast=12 and slow=26 periods.
    
    Parameters:
        signal_period: Signal line period (default 9)
    
    Returns:
        MACDResult with macd, signal, histogram
    """
    def __init__(self, signal_period: int = 9) -> None:
        self._indicator = _tk.macdfix(signal_period)
        self.signal_period = signal_period
    
    def update(self, value: float) -> _tk.MACDResult:
        """Update with single value, returns MACDResult"""
        return self._indicator.update_macd(value)
    
    def calculate(self, data: Union[np.ndarray, list]) -> MACDResult:
        """Calculate MACDFIX for entire array"""
        arr = np.asarray(data, dtype=np.float64)
        macd, signal, hist = self._indicator.calculate_macd(arr)
        return MACDResult(macd, signal, hist)


# ============================================================
# Indicator Chain
# ============================================================


class Chain:
    """Chain multiple indicators together

    Example:
        # Smoothed RSI: RSI(14) -> EMA(9)
        chain = Chain([RSI(14), EMA(9)])
        smoothed_rsi = chain.calculate(prices)
    """

    def __init__(self, indicators: List[Indicator]) -> None:
        self.indicators = indicators

    def calculate(self, data: Union[np.ndarray, list]) -> NDArray[np.float64]:
        """Calculate chain: each indicator feeds into the next"""
        result = np.asarray(data, dtype=np.float64)
        for ind in self.indicators:
            ind.reset()
            result = ind.calculate(result)
        return result

    def update(self, value: float) -> IndicatorResult:
        """Update chain incrementally"""
        current = value
        for ind in self.indicators:
            r = ind.update(current)
            if not r.valid:
                return IndicatorResult(np.nan, False)
            current = r.value
        return IndicatorResult(current, True)

    def reset(self) -> None:
        """Reset all indicators in chain"""
        for ind in self.indicators:
            ind.reset()

