# TechKit

[![PyPI version](https://badge.fury.io/py/techkit.svg)](https://badge.fury.io/py/techkit)
[![Python](https://img.shields.io/pypi/pyversions/techkit.svg)](https://pypi.org/project/techkit/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Documentation](https://img.shields.io/badge/docs-Netlify-blue.svg)](https://techkit-docs.netlify.app/)
[![CI](https://github.com/yiivon/techkit/workflows/CI/badge.svg)](https://github.com/yiivon/techkit/actions)

**TechKit** is a high-performance technical analysis library for Python, featuring:

- 🚀 **153 Technical Indicators** - Complete coverage of all TA-Lib indicators
- ⚡ **Blazing Fast** - C++ core with O(1) incremental updates
- 🔄 **100% TA-Lib Compatible** - Drop-in replacement API
- 📊 **61 Candlestick Patterns** - Full CDL pattern recognition
- 🧵 **Thread-Safe** - Zero global state, parallel-ready
- 📦 **Zero Dependencies** - Only NumPy required

## Installation

```bash
pip install techkit
```

### Platform Support

| Platform | Python | Architecture |
|----------|--------|--------------|
| Linux | 3.10-3.13 | x86_64 |
| macOS | 3.10-3.13 | x86_64, arm64 |
| Windows | 3.10-3.13 | AMD64 |

## Quick Start

### Basic Usage

```python
import numpy as np
from techkit import SMA, RSI, MACD, BBANDS

# Sample price data
prices = np.random.randn(100).cumsum() + 100

# Create indicators
sma = SMA(period=20)
rsi = RSI(period=14)
macd = MACD(fast=12, slow=26, signal=9)

# Calculate (batch)
sma_values = sma.calculate(prices)
rsi_values = rsi.calculate(prices)
macd_result = macd.calculate(prices)

print(f"SMA: {sma_values[-1]:.2f}")
print(f"RSI: {rsi_values[-1]:.2f}")
print(f"MACD: {macd_result.macd[-1]:.4f}")
```

### Streaming / Incremental Updates

```python
from techkit import SMA, RSI

sma = SMA(20)
rsi = RSI(14)

# Process bar by bar (O(1) per update)
for price in live_price_stream():
    sma_result = sma.update(price)
    rsi_result = rsi.update(price)
    
    if sma_result.valid and rsi_result.valid:
        print(f"SMA: {sma_result.value:.2f}, RSI: {rsi_result.value:.2f}")
```

### TA-Lib Drop-in Replacement

```python
# Before (TA-Lib)
import talib
sma = talib.SMA(prices, timeperiod=20)
rsi = talib.RSI(prices, timeperiod=14)
macd, signal, hist = talib.MACD(prices)

# After (TechKit) - Same API!
from techkit import talib_compat as ta
sma = ta.SMA(prices, timeperiod=20)
rsi = ta.RSI(prices, timeperiod=14)
macd, signal, hist = ta.MACD(prices)
```

### Candlestick Patterns

```python
from techkit import CDL_HAMMER, CDL_ENGULFING, CDL_MORNINGSTAR

# Detect patterns
hammer = CDL_HAMMER()
signals = hammer.calculate(open, high, low, close)

# Signals: +100 (bullish), -100 (bearish), 0 (none)
bullish_hammers = np.where(signals > 0)[0]
```

### Indicator Chaining

```python
from techkit import Chain, RSI, EMA, SMA

# Smoothed RSI: RSI(14) → EMA(9)
smoothed_rsi = Chain([RSI(14), EMA(9)])
result = smoothed_rsi.calculate(prices)

# Double smoothed: SMA(10) → SMA(5)
double_smooth = Chain([SMA(10), SMA(5)])
result = double_smooth.calculate(prices)
```

### Pandas Integration

```python
import pandas as pd
from techkit import talib_compat as ta

df = pd.read_csv('ohlcv.csv')

# Directly use DataFrame columns
df['SMA_20'] = ta.SMA(df['close'], timeperiod=20)
df['RSI_14'] = ta.RSI(df['close'], timeperiod=14)
df['ATR_14'] = ta.ATR(df['high'], df['low'], df['close'], timeperiod=14)

macd, signal, hist = ta.MACD(df['close'])
df['MACD'] = macd
df['MACD_Signal'] = signal
df['MACD_Hist'] = hist
```

## 📖 API Documentation

**Full API documentation: [techkit-docs.netlify.app/en/api/python-api/](https://techkit-docs.netlify.app/en/api/python-api/)**

- [Object-Oriented API](https://techkit-docs.netlify.app/en/api/python-api/#object-oriented-api)
- [TA-Lib Compatible API](https://techkit-docs.netlify.app/en/api/python-api/#ta-lib-compatible-api)
- [All Indicators Reference](https://techkit-docs.netlify.app/en/api/)

---

## Indicator Categories

### Moving Averages (9)

SMA, EMA, WMA, DEMA, TEMA, KAMA, TRIMA, T3, MA

### Momentum Indicators (26)

RSI, MACD, STOCH, STOCHF, STOCHRSI, CCI, ADX, ADXR, MOM, ROC, ROCP, ROCR, ROCR100, WILLR, MFI, ULTOSC, TRIX, APO, PPO, CMO, DX, PLUS_DI, MINUS_DI, PLUS_DM, MINUS_DM, AROON, AROONOSC, BOP

### Volatility (4)

ATR, NATR, BBANDS, TRANGE

### Volume (4)

OBV, AD, ADOSC, MFI

### Statistics (9)

STDDEV, VAR, LINEARREG, LINEARREG_SLOPE, LINEARREG_INTERCEPT, LINEARREG_ANGLE, TSF, BETA, CORREL

### Price Transform (4)

AVGPRICE, MEDPRICE, TYPPRICE, WCLPRICE

### Math (6)

MAX, MIN, SUM, MIDPOINT, MIDPRICE, MINMAX

### Cycle / Hilbert Transform (6)

HT_DCPERIOD, HT_DCPHASE, HT_TRENDMODE, HT_TRENDLINE, HT_PHASOR, HT_SINE

### Parabolic SAR (2)

SAR, SAREXT

### Candlestick Patterns (61)

CDL_DOJI, CDL_HAMMER, CDL_ENGULFING, CDL_MORNINGSTAR, CDL_EVENINGSTAR, CDL_3WHITESOLDIERS, CDL_3BLACKCROWS, CDL_HARAMI, CDL_PIERCING, CDL_DARKCLOUDCOVER, and 51 more...

### Advanced Analytics (17)

**Risk Metrics**: SharpeRatio, SortinoRatio, CalmarRatio, MaxDrawdown, HistoricalVaR, CVaR

**Volatility Models**: EWMAVolatility, RealizedVolatility, ParkinsonVolatility, GARCHVolatility

**Structure Analysis**: ZigZag, SwingHighLow, PivotPoints

**Pattern Recognition**: HarmonicPattern, ChartPattern

## Performance

TechKit uses C++ with O(1) incremental computation:

| Operation | TechKit | TA-Lib |
|-----------|---------|--------|
| Single update | O(1) | O(n) |
| Batch (1000 bars) | ~0.1ms | ~0.2ms |
| Memory per indicator | O(period) | O(n) |

### Benchmark Example

```python
import time
import numpy as np
from techkit import SMA

prices = np.random.randn(1_000_000).cumsum() + 100

# Batch mode
start = time.time()
result = SMA(20).calculate(prices)
print(f"Batch (1M points): {time.time() - start:.3f}s")

# Streaming mode
sma = SMA(20)
start = time.time()
for price in prices[:100_000]:
    sma.update(price)
print(f"Streaming (100K points): {time.time() - start:.3f}s")
```

## Version Information

```python
import techkit

print(techkit.__version__)       # "1.2.1"
print(techkit.version())         # "1.2.1"
print(techkit.version_tuple())   # (1, 2, 1)
```

## License

MIT License - see [LICENSE](LICENSE) for details.

## Links

- [📖 Full Documentation](https://techkit-docs.netlify.app/) - API Reference & Guides
- [GitHub Repository](https://github.com/yiivon/techkit)
- [Issue Tracker](https://github.com/yiivon/techkit/issues)
- [Changelog](CHANGELOG.md)
