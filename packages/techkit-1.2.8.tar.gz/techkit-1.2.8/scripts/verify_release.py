#!/usr/bin/env python3
"""Pre-release verification script for TechKit v1.2.1."""

import subprocess
import sys
from pathlib import Path

# Fix Windows console encoding
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# Cross-platform symbols
OK = "[OK]"
FAIL = "[FAIL]"


def run_cmd(cmd, cwd=None):
    """Run command and return success status."""
    print(f"  Running: {cmd}")
    result = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"  ERROR: {result.stderr}")
        return False
    return True


def main():
    print("=" * 60)
    print("TechKit Python Bindings v1.2.1 - Pre-Release Verification")
    print("=" * 60)
    
    project_dir = Path(__file__).parent.parent
    checks = []
    
    # 1. Check required files exist
    print("\n1. Checking required files...")
    required_files = [
        "pyproject.toml",
        "README.md",
        "CHANGELOG.md",
        "LICENSE",
        "MANIFEST.in",
        "techkit/__init__.py",
        "techkit/_version.py",
        "techkit/py.typed",
    ]
    for f in required_files:
        path = project_dir / f
        exists = path.exists()
        status = OK if exists else FAIL
        print(f"  {status} {f}")
        checks.append(exists)
    
    # 2. Version consistency
    print("\n2. Checking version (should be 1.2.1)...")
    try:
        version_file = project_dir / "techkit" / "_version.py"
        with open(version_file) as f:
            content = f.read()
        
        if '__version__ = "1.2.1"' in content:
            print(f"  {OK} Version is 1.2.1")
            checks.append(True)
        else:
            print(f"  {FAIL} Version mismatch")
            checks.append(False)
    except Exception as e:
        print(f"  {FAIL} Error: {e}")
        checks.append(False)
    
    # 3. Build test
    print("\n3. Testing build...")
    if run_cmd("pip install -e . -v", cwd=project_dir):
        print(f"  {OK} Build successful")
        checks.append(True)
    else:
        print(f"  {FAIL} Build failed")
        checks.append(False)
    
    # 4. Import test
    print("\n4. Testing imports...")
    try:
        import techkit
        print(f"  {OK} techkit version: {techkit.__version__}")
        
        from techkit import indicators
        indicator_count = len([n for n in dir(indicators) 
                              if not n.startswith('_') 
                              and isinstance(getattr(indicators, n), type)
                              and 'Result' not in n])
        print(f"  {OK} Indicators available: {indicator_count}")
        checks.append(True)
    except Exception as e:
        print(f"  {FAIL} Import error: {e}")
        checks.append(False)
    
    # 5. Run tests
    print("\n5. Running tests...")
    test_cmd = "pytest tests/ -v --ignore=tests/test_cdl_validation.py --ignore=tests/test_remaining_validation.py"
    if run_cmd(test_cmd, cwd=project_dir):
        print(f"  {OK} Tests passed")
        checks.append(True)
    else:
        print(f"  {FAIL} Tests failed")
        checks.append(False)
    
    # Summary
    print("\n" + "=" * 60)
    passed = sum(checks)
    total = len(checks)
    
    if passed == total:
        print(f"{OK} ALL CHECKS PASSED ({passed}/{total})")
        print("\nReady for release v1.2.1!")
        print("\nNext steps:")
        print("  1. git add -A && git commit -m 'Release v1.2.1'")
        print("  2. git tag -a v1.2.1 -m 'TechKit Python v1.2.1'")
        print("  3. git push origin main --tags")
        print("  4. Create GitHub Release -> triggers PyPI publish")
        return 0
    else:
        print(f"{FAIL} SOME CHECKS FAILED ({passed}/{total})")
        print("\nPlease fix issues before release.")
        return 1


if __name__ == "__main__":
    sys.exit(main())

