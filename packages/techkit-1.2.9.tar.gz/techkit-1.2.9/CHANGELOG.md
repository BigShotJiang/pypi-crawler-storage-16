# Changelog

All notable changes to TechKit Python bindings will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.2.1] - 2024-12-07

### Added

#### Phase 1: TA-Lib Compatible Indicators (68 indicators)

- **Moving Averages**: SMA, EMA, WMA, DEMA, TEMA, KAMA, TRIMA, T3, MA
- **Momentum**: RSI, MACD, STOCH, CCI, ADX, ADXR, MOM, ROC, ROCP, ROCR, ROCR100, WILLR, MFI, APO, PPO, CMO, DX, PLUS_DI, MINUS_DI, PLUS_DM, MINUS_DM, TRIX, ULTOSC, AROON, AROONOSC
- **Volatility**: ATR, NATR, TRANGE, BBANDS
- **Volume**: OBV, AD, ADOSC
- **Statistics**: STDDEV, VAR, LINEARREG, LINEARREG_SLOPE, LINEARREG_INTERCEPT, LINEARREG_ANGLE, TSF, BETA, CORREL
- **Price Transform**: AVGPRICE, MEDPRICE, TYPPRICE, WCLPRICE
- **Math**: MAX, MIN, SUM, MINMAX, MINMAXINDEX
- **Cycle**: HT_DCPERIOD, HT_DCPHASE, HT_PHASOR, HT_SINE, HT_TRENDLINE, HT_TRENDMODE
- **Other**: SAR, SAREXT, MAVP, STOCHF, STOCHRSI, MACDEXT, MACDFIX

#### Phase 2: Advanced Analytics (17 indicators)

- **Risk Metrics**: Sharpe Ratio, Sortino Ratio, Calmar Ratio, Max Drawdown, VaR, CVaR
- **Volatility Models**: Parkinson, Garman-Klass, Rogers-Satchell, Yang-Zhang
- **Structure Analysis**: Market Structure, Swing Points, Fair Value Gaps
- **Harmonic Patterns**: Gartley, Butterfly, Bat, Crab

#### Phase 3: Candlestick Patterns (61 patterns)

- **Single Candle**: CDL_DOJI, CDL_HAMMER, CDL_HANGINGMAN, CDL_SHOOTINGSTAR, CDL_INVERTEDHAMMER, CDL_MARUBOZU, CDL_SPINNINGTOP, CDL_HIGHWAVE, CDL_LONGLINE, CDL_SHORTLINE, CDL_DRAGONFLYDOJI, CDL_GRAVESTONEDOJI, CDL_LONGLEGGEDDOJI, CDL_RICKSHAWMAN, CDL_DOJISTAR, CDL_TAKURI, CDL_CLOSINGMARUBOZU
- **Two Candle**: CDL_ENGULFING, CDL_HARAMI, CDL_HARAMICROSS, CDL_PIERCING, CDL_DARKCLOUDCOVER, CDL_BELTHOLD, CDL_COUNTERATTACK, CDL_KICKING, CDL_KICKINGBYLENGTH, CDL_MATCHINGLOW, CDL_ONNECK, CDL_INNECK, CDL_THRUSTING, CDL_HOMINGPIGEON, CDL_SEPARATINGLINES, CDL_2CROWS
- **Three Candle**: CDL_MORNINGSTAR, CDL_EVENINGSTAR, CDL_MORNINGDOJISTAR, CDL_EVENINGDOJISTAR, CDL_ABANDONEDBABY, CDL_3WHITESOLDIERS, CDL_3BLACKCROWS, CDL_3INSIDE, CDL_3OUTSIDE, CDL_3LINESTRIKE, CDL_3STARSINSOUTH, CDL_TRISTAR, CDL_UNIQUE3RIVER, CDL_TASUKIGAP, CDL_GAPSIDESIDEWHITE, CDL_UPSIDEGAP2CROWS, CDL_ADVANCEBLOCK
- **Complex**: CDL_BREAKAWAY, CDL_CONCEALBABYSWALL, CDL_HIKKAKE, CDL_HIKKAKEMOD, CDL_IDENTICAL3CROWS, CDL_LADDERBOTTOM, CDL_MATHOLD, CDL_RISEFALL3METHODS, CDL_STICKSANDWICH, CDL_STALLEDPATTERN, CDL_XSIDEGAP3METHODS

#### Features

- Full NumPy integration with zero-copy operations
- O(1) incremental update for all indicators
- TA-Lib compatible drop-in replacement API (`talib_compat` module)
- Complete type hints (PEP 561 compliant)
- Thread-safe design with zero global state

### Performance

- 100% numerical compatibility with TA-Lib (error < 1e-10)
- Validated against TA-Lib with comprehensive test suite
- Support for Python 3.10, 3.11, 3.12, 3.13
- Pre-built wheels for Linux (x86_64), macOS (x86_64, arm64), Windows (AMD64)

