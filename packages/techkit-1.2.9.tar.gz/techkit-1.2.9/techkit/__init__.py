"""TechKit - High-performance technical analysis library

TechKit provides 153 technical indicators with:
- High performance (C++ core with pybind11)
- Both incremental (streaming) and batch calculation modes
- NumPy integration for efficient array operations
- TA-Lib compatible API for easy migration
- 61 candlestick pattern recognition functions
- Thread-safe design with zero global state

Example usage:

    # OOP API (recommended)
    from techkit import SMA, RSI, MACD
    
    sma = SMA(period=20)
    result = sma.calculate(prices)  # Batch
    result = sma.update(price)      # Incremental
    
    # TA-Lib compatible API
    from techkit import talib_compat as ta
    
    sma = ta.SMA(prices, timeperiod=20)
    macd, signal, hist = ta.MACD(prices)

Version: 1.2.1
"""

from techkit._version import __version__, __version_tuple__

from techkit._core import version, version_tuple
from techkit.indicators import (
    # Base
    Indicator,
    IndicatorResult,
    # Moving Averages
    SMA,
    EMA,
    WMA,
    DEMA,
    TEMA,
    KAMA,
    TRIMA,
    T3,
    # Momentum
    RSI,
    MACD,
    MOM,
    ROC,
    ROCP,
    ROCR,
    ROCR100,
    CCI,
    ADX,
    ADXR,
    APO,
    PPO,
    CMO,
    DX,
    WILLR,
    MFI,
    PLUS_DI,
    MINUS_DI,
    PLUS_DM,
    MINUS_DM,
    TRIX,
    ULTOSC,
    AROON,
    AROONOSC,
    BOP,
    STOCH,
    # Volatility
    ATR,
    NATR,
    TRANGE,
    BBANDS,
    # Volume
    OBV,
    AD,
    ADOSC,
    # Statistics
    STDDEV,
    VAR,
    LINEARREG,
    LINEARREG_SLOPE,
    LINEARREG_INTERCEPT,
    LINEARREG_ANGLE,
    TSF,
    BETA,
    CORREL,
    # Price Transform
    AVGPRICE,
    MEDPRICE,
    TYPPRICE,
    WCLPRICE,
    # Math
    MAX,
    MIN,
    SUM,
    MIDPOINT,
    MIDPRICE,
    MINMAX,
    # Hilbert Transform
    HT_DCPERIOD,
    HT_DCPHASE,
    HT_TRENDMODE,
    HT_TRENDLINE,
    HT_PHASOR,
    HT_SINE,
    # Parabolic SAR
    SAR,
    # Utility
    Chain,
    # Result types
    MACDResult,
    BBandsResult,
    StochResult,
    AroonResult,
    # Phase 2: Risk Metrics
    SharpeRatio,
    SortinoRatio,
    MaxDrawdown,
    Drawdown,
    DrawdownResult,
    CalmarRatio,
    HistoricalVaR,
    CVaR,
    # Phase 2: Volatility Models
    EWMAVolatility,
    RealizedVolatility,
    ParkinsonVolatility,
    GARCHVolatility,
    # Phase 2: Structure Analysis
    ZigZag,
    ZigZagResult,
    SwingHighLow,
    SwingResult,
    PivotPoints,
    PivotPointsResult,
    # Phase 2: Harmonic Patterns
    HarmonicPattern,
    # Phase 2: Chart Patterns
    ChartPattern,
    # Phase 3: Candlestick Patterns (61)
    CDLResult,
    CDLIndicator,
    # Single candle (12)
    CDL_DOJI,
    CDL_DRAGONFLYDOJI,
    CDL_GRAVESTONEDOJI,
    CDL_LONGLEGGEDDOJI,
    CDL_HAMMER,
    CDL_INVERTEDHAMMER,
    CDL_HANGINGMAN,
    CDL_SHOOTINGSTAR,
    CDL_MARUBOZU,
    CDL_CLOSINGMARUBOZU,
    CDL_SPINNINGTOP,
    CDL_HIGHWAVE,
    # Two candle (15)
    CDL_ENGULFING,
    CDL_HARAMI,
    CDL_HARAMICROSS,
    CDL_PIERCING,
    CDL_DARKCLOUDCOVER,
    CDL_BELTHOLD,
    CDL_COUNTERATTACK,
    CDL_HOMINGPIGEON,
    CDL_INNECK,
    CDL_ONNECK,
    CDL_MATCHINGLOW,
    CDL_KICKING,
    CDL_KICKINGBYLENGTH,
    CDL_SEPARATINGLINES,
    CDL_THRUSTING,
    # Three candle (12)
    CDL_MORNINGSTAR,
    CDL_EVENINGSTAR,
    CDL_MORNINGDOJISTAR,
    CDL_EVENINGDOJISTAR,
    CDL_3INSIDE,
    CDL_3OUTSIDE,
    CDL_3WHITESOLDIERS,
    CDL_3BLACKCROWS,
    CDL_3LINESTRIKE,
    CDL_ABANDONEDBABY,
    CDL_TRISTAR,
    CDL_IDENTICAL3CROWS,
    # Complex (12)
    CDL_2CROWS,
    CDL_ADVANCEBLOCK,
    CDL_BREAKAWAY,
    CDL_CONCEALBABYSWALL,
    CDL_DOJISTAR,
    CDL_GAPSIDESIDEWHITE,
    CDL_HIKKAKE,
    CDL_HIKKAKEMOD,
    CDL_LADDERBOTTOM,
    CDL_RICKSHAWMAN,
    CDL_STALLEDPATTERN,
    CDL_STICKSANDWICH,
    # Final (10)
    CDL_3STARSINSOUTH,
    CDL_LONGLINE,
    CDL_SHORTLINE,
    CDL_MATHOLD,
    CDL_RISEFALL3METHODS,
    CDL_TAKURI,
    CDL_TASUKIGAP,
    CDL_UNIQUE3RIVER,
    CDL_UPSIDEGAP2CROWS,
    CDL_XSIDEGAP3METHODS,
    # Phase 4: Remaining Indicators (7)
    MAType,
    MA,
    MAVP,
    SAREXT,
    STOCHF,
    StochFResult,
    STOCHRSI,
    StochRSIResult,
    MACDEXT,
    MACDFIX,
)

__all__ = [
    # Version
    "__version__",
    "__version_tuple__",
    "version",
    "version_tuple",
    # Base
    "Indicator",
    "IndicatorResult",
    # Moving Averages
    "SMA",
    "EMA",
    "WMA",
    "DEMA",
    "TEMA",
    "KAMA",
    "TRIMA",
    "T3",
    # Momentum
    "RSI",
    "MACD",
    "MOM",
    "ROC",
    "ROCP",
    "ROCR",
    "ROCR100",
    "CCI",
    "ADX",
    "ADXR",
    "APO",
    "PPO",
    "CMO",
    "DX",
    "WILLR",
    "MFI",
    "PLUS_DI",
    "MINUS_DI",
    "PLUS_DM",
    "MINUS_DM",
    "TRIX",
    "ULTOSC",
    "AROON",
    "AROONOSC",
    "BOP",
    "STOCH",
    # Volatility
    "ATR",
    "NATR",
    "TRANGE",
    "BBANDS",
    # Volume
    "OBV",
    "AD",
    "ADOSC",
    # Statistics
    "STDDEV",
    "VAR",
    "LINEARREG",
    "LINEARREG_SLOPE",
    "LINEARREG_INTERCEPT",
    "LINEARREG_ANGLE",
    "TSF",
    "BETA",
    "CORREL",
    # Price Transform
    "AVGPRICE",
    "MEDPRICE",
    "TYPPRICE",
    "WCLPRICE",
    # Math
    "MAX",
    "MIN",
    "SUM",
    "MIDPOINT",
    "MIDPRICE",
    "MINMAX",
    # Hilbert Transform
    "HT_DCPERIOD",
    "HT_DCPHASE",
    "HT_TRENDMODE",
    "HT_TRENDLINE",
    "HT_PHASOR",
    "HT_SINE",
    # Parabolic SAR
    "SAR",
    # Utility
    "Chain",
    # Result types
    "MACDResult",
    "BBandsResult",
    "StochResult",
    "AroonResult",
    # Phase 2: Risk Metrics
    "SharpeRatio",
    "SortinoRatio",
    "MaxDrawdown",
    "Drawdown",
    "DrawdownResult",
    "CalmarRatio",
    "HistoricalVaR",
    "CVaR",
    # Phase 2: Volatility Models
    "EWMAVolatility",
    "RealizedVolatility",
    "ParkinsonVolatility",
    "GARCHVolatility",
    # Phase 2: Structure Analysis
    "ZigZag",
    "ZigZagResult",
    "SwingHighLow",
    "SwingResult",
    "PivotPoints",
    "PivotPointsResult",
    # Phase 2: Harmonic Patterns
    "HarmonicPattern",
    # Phase 2: Chart Patterns
    "ChartPattern",
    # Phase 3: Candlestick Patterns (61)
    "CDLResult",
    "CDLIndicator",
    # Single candle (12)
    "CDL_DOJI",
    "CDL_DRAGONFLYDOJI",
    "CDL_GRAVESTONEDOJI",
    "CDL_LONGLEGGEDDOJI",
    "CDL_HAMMER",
    "CDL_INVERTEDHAMMER",
    "CDL_HANGINGMAN",
    "CDL_SHOOTINGSTAR",
    "CDL_MARUBOZU",
    "CDL_CLOSINGMARUBOZU",
    "CDL_SPINNINGTOP",
    "CDL_HIGHWAVE",
    # Two candle (15)
    "CDL_ENGULFING",
    "CDL_HARAMI",
    "CDL_HARAMICROSS",
    "CDL_PIERCING",
    "CDL_DARKCLOUDCOVER",
    "CDL_BELTHOLD",
    "CDL_COUNTERATTACK",
    "CDL_HOMINGPIGEON",
    "CDL_INNECK",
    "CDL_ONNECK",
    "CDL_MATCHINGLOW",
    "CDL_KICKING",
    "CDL_KICKINGBYLENGTH",
    "CDL_SEPARATINGLINES",
    "CDL_THRUSTING",
    # Three candle (12)
    "CDL_MORNINGSTAR",
    "CDL_EVENINGSTAR",
    "CDL_MORNINGDOJISTAR",
    "CDL_EVENINGDOJISTAR",
    "CDL_3INSIDE",
    "CDL_3OUTSIDE",
    "CDL_3WHITESOLDIERS",
    "CDL_3BLACKCROWS",
    "CDL_3LINESTRIKE",
    "CDL_ABANDONEDBABY",
    "CDL_TRISTAR",
    "CDL_IDENTICAL3CROWS",
    # Complex (12)
    "CDL_2CROWS",
    "CDL_ADVANCEBLOCK",
    "CDL_BREAKAWAY",
    "CDL_CONCEALBABYSWALL",
    "CDL_DOJISTAR",
    "CDL_GAPSIDESIDEWHITE",
    "CDL_HIKKAKE",
    "CDL_HIKKAKEMOD",
    "CDL_LADDERBOTTOM",
    "CDL_RICKSHAWMAN",
    "CDL_STALLEDPATTERN",
    "CDL_STICKSANDWICH",
    # Final (10)
    "CDL_3STARSINSOUTH",
    "CDL_LONGLINE",
    "CDL_SHORTLINE",
    "CDL_MATHOLD",
    "CDL_RISEFALL3METHODS",
    "CDL_TAKURI",
    "CDL_TASUKIGAP",
    "CDL_UNIQUE3RIVER",
    "CDL_UPSIDEGAP2CROWS",
    "CDL_XSIDEGAP3METHODS",
    # Phase 4: Remaining Indicators (7)
    "MAType",
    "MA",
    "MAVP",
    "SAREXT",
    "STOCHF",
    "StochFResult",
    "STOCHRSI",
    "StochRSIResult",
    "MACDEXT",
    "MACDFIX",
]
