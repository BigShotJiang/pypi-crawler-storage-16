"""Version information for TechKit."""

__version__ = "1.2.1"
__version_tuple__ = (1, 2, 1)

# Version components
VERSION_MAJOR = 1
VERSION_MINOR = 2
VERSION_PATCH = 1
VERSION_SUFFIX = ""  # e.g., "rc1", "beta1"


def get_version() -> str:
    """Get the full version string."""
    version = f"{VERSION_MAJOR}.{VERSION_MINOR}.{VERSION_PATCH}"
    if VERSION_SUFFIX:
        version += f".{VERSION_SUFFIX}"
    return version

