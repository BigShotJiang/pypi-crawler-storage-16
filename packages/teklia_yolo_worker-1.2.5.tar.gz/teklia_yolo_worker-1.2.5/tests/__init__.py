from pathlib import Path

SAMPLES = Path(__file__).parent / "samples"
