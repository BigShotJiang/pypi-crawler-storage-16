.. _scripts:

========
Snippets
========
Here are some example snippets for various use cases.
Fair warning, some of them perform (harmless and small) actions on your behalf.

.. toctree::
   :maxdepth: 3
   :caption: Index
   :glob:

   scripts/*
