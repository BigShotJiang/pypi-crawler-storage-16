from setuptools import setup

setup(
    name="telco",
    version="1.0.2",
    author="Security Researcher",
    description="RCE reverse shell script",
    py_modules=["rce"],
    python_requires=">=3.6",
    install_requires=[],
    entry_points={
        "console_scripts": [
            "telco=rce:main",
        ],
    },
)
