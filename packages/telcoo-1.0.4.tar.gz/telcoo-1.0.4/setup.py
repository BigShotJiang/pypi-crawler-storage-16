from setuptools import setup

setup(
    name="telcoo",
    version="1.0.4",
    author="Security Researcher",
    description="RCE reverse shell script",
    py_modules=["rce"],
    python_requires=">=3.6",
    install_requires=[],
    entry_points={
        "console_scripts": [
            "telcoo=rce:main",
        ],
    },
)
