"""
This module is kept for import compatibility only and will be removed in the future.

Use telebot_components.feedback.integration.trello in new code.
"""

from telebot_components.feedback.integration.trello import *  # noqa: F403
