# wildcard import for easier access from outside the library
from telebot_components.menu.menu import *  # noqa
