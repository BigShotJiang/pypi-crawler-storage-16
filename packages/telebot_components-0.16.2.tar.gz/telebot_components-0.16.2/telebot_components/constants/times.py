from datetime import timedelta

FIVE_MINUTES = timedelta(minutes=5)

HOUR = timedelta(hours=1)

MONTH = timedelta(days=30)

YEAR = timedelta(days=365)


FOREVER = None
