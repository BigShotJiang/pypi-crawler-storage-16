# rewritten during package build, see build_package.py script
BASE_PATH = "/constructor"
VERSION = "v0.2.17"
