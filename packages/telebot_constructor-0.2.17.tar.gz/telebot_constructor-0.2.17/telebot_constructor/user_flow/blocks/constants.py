FORM_CANCEL_CMD = "/cancel"
FORM_SKIP_FIELD_CMD = "/skip"
