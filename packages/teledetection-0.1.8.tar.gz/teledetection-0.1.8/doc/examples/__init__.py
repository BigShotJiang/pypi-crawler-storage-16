"""Source codes of examples in [this section](#processing_examples.html)."""
