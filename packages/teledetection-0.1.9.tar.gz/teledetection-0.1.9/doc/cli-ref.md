# CLI reference

::: mkdocs-click
    :module: teledetection.cli
    :command: tld
    :depth: 1
