---
trigger: always_on
---

Before the end of complex changes, talk to me summary of changes with smarthome_tts_voice. На русском языке. Use tool smarthome_tts_voice({message: summary_message})