---
description: release a new version
---

- run `python deploy.py [patch|minor|major]`
