---
description: Run tests and fix errors
---

- Run tests
- Fix first test
- Run app
- Fix remain tests