# Thanks to https://github.com/tomtung/latex2unicode/
# Without their work, this project would not be possible.
