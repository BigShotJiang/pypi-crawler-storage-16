import logging

# Configure the logger
logger = logging.getLogger('telegramify_markdown')
