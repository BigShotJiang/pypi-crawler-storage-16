"""
Base Notebook Template

所有 Notebook 模板的基类
"""
from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from datetime import datetime


class BaseNotebookTemplate(ABC):
    """
    Notebook 模板基类
    """
    
    def __init__(
        self,
        best_estimator: str,
        best_config: Dict[str, Any],
        experiment_id: str,
        run_id: str,
        mlflow_tracking_uri: str,
        features: List[str],
        target_col: str,
        metric: str,
        **kwargs
    ):
        """
        初始化模板
        
        Args:
            best_estimator: 最佳估计器名称
            best_config: 最佳超参数配置
            experiment_id: MLflow 实验 ID
            run_id: MLflow Run ID
            mlflow_tracking_uri: MLflow Tracking URI
            features: 特征列名列表
            target_col: 目标列名
            metric: 评估指标
            **kwargs: 其他参数
        """
        self.best_estimator = best_estimator
        self.best_config = best_config
        self.experiment_id = experiment_id
        self.run_id = run_id
        self.mlflow_tracking_uri = mlflow_tracking_uri
        self.features = features
        self.target_col = target_col
        self.metric = metric
        self.kwargs = kwargs
    
    def generate(self) -> Dict[str, Any]:
        """
        生成 Notebook
        
        Returns:
            Notebook 字典
        """
        cells = []
        
        # 添加各个 Cell
        cells.append(self._create_header_cell())
        cells.append(self._create_import_cell())
        cells.append(self._create_mlflow_setup_cell())
        cells.append(self._create_load_data_cell())
        cells.extend(self._create_preprocessing_cells())
        cells.extend(self._create_model_training_cells())
        cells.extend(self._create_evaluation_cells())
        cells.append(self._create_inference_cell())
        
        # 构建 Notebook
        notebook = {
            "cells": cells,
            "metadata": self._create_metadata(),
            "nbformat": 4,
            "nbformat_minor": 5
        }
        
        return notebook
    
    @abstractmethod
    def _create_preprocessing_cells(self) -> List[Dict[str, Any]]:
        """创建预处理 Cells"""
        pass
    
    @abstractmethod
    def _create_model_training_cells(self) -> List[Dict[str, Any]]:
        """创建模型训练 Cells"""
        pass
    
    @abstractmethod
    def _create_evaluation_cells(self) -> List[Dict[str, Any]]:
        """创建评估 Cells"""
        pass
    
    def _create_header_cell(self) -> Dict[str, Any]:
        """创建标题 Cell"""
        task_name = self.__class__.__name__.replace("NotebookTemplate", "")
        return self._create_markdown_cell([
            f"# {task_name} Training - Auto-generated Notebook\n",
            "\n",
            "- This is an auto-generated notebook by WeData AutoML.\n",
            f"- Generated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n",
            f"- Best Estimator: **{self.best_estimator}**\n",
            f"- Metric: **{self.metric}**\n",
            f"- MLflow Experiment: [{self.experiment_id}]({self.mlflow_tracking_uri}/#/experiments/{self.experiment_id})\n",
            f"- MLflow Run: [{self.run_id}]({self.mlflow_tracking_uri}/#/experiments/{self.experiment_id}/runs/{self.run_id})\n",
        ])
    
    def _create_import_cell(self) -> Dict[str, Any]:
        """创建导入 Cell"""
        return self._create_code_cell([
            "import os\n",
            "import mlflow\n",
            "import mlflow.sklearn\n",
            "import pandas as pd\n",
            "import numpy as np\n",
            "from sklearn.pipeline import Pipeline\n",
            "from sklearn.preprocessing import StandardScaler\n",
            "from sklearn.impute import SimpleImputer\n",
        ])
    
    def _create_mlflow_setup_cell(self) -> Dict[str, Any]:
        """创建 MLflow 设置 Cell"""
        return self._create_code_cell([
            f"# Set MLflow tracking URI\n",
            f"mlflow.set_tracking_uri('{self.mlflow_tracking_uri}')\n",
            f"\n",
            f"# Set MLflow registry URI (TCLake plugin for model registration)\n",
            f"region = os.environ.get('QCLOUD_REGION', 'ap-guangzhou')\n",
            f"mlflow.set_registry_uri(f'tclake:{{region}}')\n",
            f"print(f'Registry URI: tclake:{{region}}')\n",
            f"\n",
            f"# Set experiment\n",
            f"mlflow.set_experiment(experiment_id='{self.experiment_id}')\n",
        ])
    
    def _create_load_data_cell(self) -> Dict[str, Any]:
        """创建数据加载 Cell"""
        return self._create_code_cell([
            f"# Load data from MLflow artifact\n",
            f"run_id = '{self.run_id}'\n",
            f"data_path = mlflow.artifacts.download_artifacts(run_id=run_id, artifact_path='data')\n",
            f"\n",
            f"# Load training data\n",
            f"df = pd.read_parquet(f'{{data_path}}/training_data')\n",
            f"print(f'Data shape: {{df.shape}}')\n",
            f"df.head()\n",
        ])
    
    def _create_inference_cell(self) -> Dict[str, Any]:
        """创建推理 Cell"""
        return self._create_code_cell([
            f"# Load model for inference\n",
            f"model_uri = f'runs:/{{run_id}}/model'\n",
            f"model = mlflow.pyfunc.load_model(model_uri)\n",
            f"\n",
            f"# Make predictions\n",
            f"# predictions = model.predict(test_data)\n",
            f"# print(predictions)\n",
        ])
    
    @staticmethod
    def _create_code_cell(source: List[str]) -> Dict[str, Any]:
        """创建代码 Cell"""
        return {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": source
        }
    
    @staticmethod
    def _create_markdown_cell(source: List[str]) -> Dict[str, Any]:
        """创建 Markdown Cell"""
        return {
            "cell_type": "markdown",
            "metadata": {},
            "source": source
        }
    
    def _create_metadata(self) -> Dict[str, Any]:
        """创建 Notebook 元数据"""
        return {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3"
            },
            "language_info": {
                "codemirror_mode": {"name": "ipython", "version": 3},
                "file_extension": ".py",
                "mimetype": "text/x-python",
                "name": "python",
                "nbconvert_exporter": "python",
                "pygments_lexer": "ipython3",
                "version": "3.8.0"
            }
        }

