import asyncio
from src.agent import run_interactive

if __name__ == "__main__":
    asyncio.run(run_interactive())
