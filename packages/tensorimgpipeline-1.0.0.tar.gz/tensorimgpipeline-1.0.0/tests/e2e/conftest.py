"""Pytest configuration and fixtures for e2e tests."""

from .fixtures import cli_runner

__all__ = ["cli_runner"]
