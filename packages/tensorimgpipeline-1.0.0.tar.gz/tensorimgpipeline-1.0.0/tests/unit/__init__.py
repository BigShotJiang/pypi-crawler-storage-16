"""Unit tests for TensorImgPipeline.

Tests individual components in isolation.
"""
