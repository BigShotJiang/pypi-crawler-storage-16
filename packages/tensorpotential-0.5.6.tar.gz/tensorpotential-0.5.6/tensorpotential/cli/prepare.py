from __future__ import annotations

import gc
import importlib
import logging
import os
import re
import sys

from tensorpotential.cli.data import FutureDistributedDataset

try:
    import readline

    no_readline = False
except ImportError:
    no_readline = True

from dataclasses import dataclass
from typing import Dict, Any

from tqdm import tqdm
from importlib import resources
import json

from tensorpotential import constants as tc

from tensorpotential.potentials import (
    get_preset,
    get_public_preset_list,
    get_default_preset_name,
    get_preset_settings,
)

from tensorpotential.loss import *
from tensorpotential.metrics import *
from tensorpotential.instructions.base import (
    str_to_class,
    TPInstruction,
)

from tensorpotential.tpmodel import (
    TrainFunction,
    ComputeFunction,
)

from tensorpotential.calculator.foundation_models import (
    MODELS_METADATA,
    CHECKPOINT_URL_KEY,
    DESCRIPTION_KEY,
)

LOG_FMT = "%(asctime)s %(levelname).1s - %(message)s"
logging.basicConfig(level=logging.INFO, format=LOG_FMT, datefmt="%Y/%m/%d %H:%M:%S")
log = logging.getLogger()


# default_cutoff = {"FS": 7.0, "GRACE_1LAYER": 6.0, "GRACE_2LAYER": 5.0}


@dataclass
class ModelFunctions:
    loss_fn: LossFunction
    regularization_loss_fn: LossFunction
    train_fn: TrainFunction
    compute_fn: ComputeFunction
    metrics_fn: ComputeMetrics


def construct_model(
    potential_config: Dict,
    element_map: Dict,
    rcut: float,
    cutoff_dict: dict = None,
    avg_n_neigh: float | dict = 1.0,
    constant_out_shift: float = 0.0,
    constant_out_scale: float = 1.0,
    atomic_shift_map=None,
) -> dict[str, TPInstruction]:
    """
    Construct a model as a dict of TPInstructions.
    """
    preset = potential_config.get("preset")
    kwargs = potential_config.get("kwargs", {})
    if kwargs:
        log.info(f"Model kwargs: {kwargs}")

    if preset is not None:
        build_fn = get_preset(preset)

        instructions = build_fn(
            element_map=element_map,
            rcut=rcut,
            cutoff_dict=cutoff_dict,
            avg_n_neigh=avg_n_neigh,
            constant_out_shift=constant_out_shift,
            constant_out_scale=constant_out_scale,
            atomic_shift_map=atomic_shift_map,
            **kwargs,
        )

    elif potential_config.get("custom"):
        model = potential_config.get("custom")
        sys.path.append(os.getcwd())
        log.info(f"Importing model from {model} (added to PYTHON_PATH: {os.getcwd()})")
        build_model_fn = str_to_class(model)
        instructions = build_model_fn(
            element_map=element_map,
            rcut=rcut,
            cutoff_dict=cutoff_dict,
            avg_n_neigh=avg_n_neigh,
            constant_out_shift=constant_out_shift,
            constant_out_scale=constant_out_scale,
            atomic_shift_map=atomic_shift_map,
            **kwargs,
        )
    else:
        raise ValueError(
            f"Neither `preset` nor `custom` specified in input.yaml::potential"
        )

    return instructions


def convert_to_tensors_for_model(tp, train_data, test_data, strategy):
    """
    Converts a train and test data into a tf.Tensor using only keys from tp.model's signature

    :param tp: TensorPotential instance
    :param train_data:
    :param test_data:
    :return: tuple of train data and test data
    """
    sigs = tp.get_model_grad_signatures()

    if isinstance(train_data, FutureDistributedDataset):
        train_data, test_data = train_data.generate_dataset(
            strategy=strategy, signatures=sigs
        )
        return train_data, test_data

    train_batches = []
    with tf.device("CPU"):
        # use deque for train_data in order to efficiently popleft and reduce immediate memory usage
        # spawn gc.collect every 100 batches
        log.info("[TRAIN] Convert to tensors")
        n = len(train_data)
        for it in tqdm(range(n), total=n, mininterval=2):
            b = train_data.popleft()
            converted_batch = {
                k: tf.convert_to_tensor(b[k], dtype=v.dtype) for k, v in sigs.items()
            }
            train_batches.append(converted_batch)
            if (it + 1) % 100 == 0:
                gc.collect()
    # train_batches = tuple(train_batches)
    test_batches = None
    if test_data is not None:
        test_batches = []
        with tf.device("CPU"):
            # use deque for test_data in order to efficiently popleft and reduce immediate memory usage
            # spawn gc.collect every 100 batches
            log.info("[TEST] Convert to tensors")
            n = len(test_data)
            for it in tqdm(range(n), total=n, mininterval=2):
                b = test_data.popleft()
                converted_batch = {
                    k: tf.convert_to_tensor(b[k], dtype=v.dtype)
                    for k, v in sigs.items()
                }
                test_batches.append(converted_batch)
                if (it + 1) % 100 == 0:
                    gc.collect()

        # test_batches = tuple(test_batches)
    return train_batches, test_batches


def build_reg_loss(fit_config):
    """
    Build regularization loss
    Params:
        fit_config (dict)
    Return :
        regularization_loss (LossFunction)
    """
    l2_reg = fit_config["loss"].get("l2_reg", None)
    regularization_loss = None
    if l2_reg:
        regularization_loss = LossFunction({"l2": L2Loss(l2_reg, name="l2_loss")})
        log.info(f"Regularization loss L2={l2_reg}")
    return regularization_loss


def build_metrics_function(fit_config, extra_loss_components=None):
    fit_loss = fit_config["loss"]
    metrics_list = []
    if tc.INPUT_FIT_LOSS_ENERGY in fit_loss:
        metrics_list.append(EnergyMetrics())

    if tc.INPUT_FIT_LOSS_FORCES in fit_loss:
        metrics_list.append(ForceMetrics())

    if tc.INPUT_FIT_LOSS_STRESS in fit_loss or tc.INPUT_FIT_LOSS_VIRIAL in fit_loss:
        metrics_list.append(VirialMetrics())

    if extra_loss_components is not None:
        for loss_component in extra_loss_components:
            extra_metric = loss_component.corresponding_metrics
            if extra_metric is not None:
                metrics_list.append(extra_metric())
    # if tc.INPUT_FIT_LOSS_EFG in fit_loss:
    #     from tensorpotential.experimental.efg.metrics import AtomicEFGMetrics
    #
    #     metrics_list.append(AtomicEFGMetrics())

    return metrics_list


def build_loss_function(fit_config):
    """
    Build loss function from fit_config (support backward compat with old format)
    Params:
        fit_config (dict)

    Return:
        loss_function (LossFunction)
    """
    if "loss" not in fit_config:
        energy_loss_weight = fit_config.get("energy_loss_weight", 1.0)
        forces_loss_weight = fit_config.get("forces_loss_weight", 100.0)
        fit_config["loss"] = {
            tc.INPUT_FIT_LOSS_ENERGY: {"type": "square", "weight": energy_loss_weight},
            tc.INPUT_FIT_LOSS_FORCES: {"type": "square", "weight": forces_loss_weight},
        }
        # old-style configuration
        log.warning(
            "DEPRECATION WARNING! Instead of `energy_loss_weight` and `forces_loss_weight`"
            " use input.yaml::fit::loss dict (see doc)"
        )
    fit_loss = fit_config["loss"]

    def get_loss_component(key, loss_types_dict):
        loss_config = fit_loss[key].copy()
        loss_weight = loss_config.pop("weight")
        loss_type = loss_config.pop("type", "square")

        if loss_type not in loss_types_dict:
            raise ValueError(f"Unknown type of loss function {loss_type}")
        return loss_types_dict[loss_type](loss_weight, **loss_config)

    loss_components = {}
    loss_comp_name = tc.INPUT_FIT_LOSS_ENERGY
    if loss_comp_name in fit_loss:
        loss_components[loss_comp_name] = get_loss_component(
            loss_comp_name,
            {
                "square": WeightedSSEEnergyPerAtomLoss,
                "huber": WeightedHuberEnergyPerAtomLoss,
                "mae": WeightedMAEEPALoss,
            },
        )

    loss_comp_name = tc.INPUT_FIT_LOSS_FORCES
    if loss_comp_name in fit_loss:
        loss_components[loss_comp_name] = get_loss_component(
            loss_comp_name,
            {
                "square": WeightedSSEForceLoss,
                "huber": WeightedHuberForceLoss,
            },
        )

    loss_comp_name = tc.INPUT_FIT_LOSS_VIRIAL
    if loss_comp_name in fit_loss:
        loss_components[loss_comp_name] = get_loss_component(
            loss_comp_name,
            {
                "square": WeightedSSEVirialLoss,
                "huber": WeightedHuberVirialLoss,
            },
        )

    loss_comp_name = tc.INPUT_FIT_LOSS_STRESS
    if loss_comp_name in fit_loss:
        loss_components[loss_comp_name] = get_loss_component(
            loss_comp_name,
            {
                "square": WeightedSSEStressLoss,
                "huber": WeightedHuberStressLoss,
                "mae": WeightedMAEStressLoss,
            },
        )

    # extra loss components
    extra_loss_componens = fit_loss.get("extra_components", None)

    extras = None
    if extra_loss_componens is not None:
        extras = []
        # mod = importlib.import_module("tensorpotential.experimental.extra_losses")
        from tensorpotential.experimental import extra_losses

        for loss_comp_name, loss_config in extra_loss_componens.items():
            try:
                # loss_func = getattr(mod, loss_comp_name)
                loss_func = getattr(extra_losses, loss_comp_name)
                loss_weight = loss_config.pop("weight")
                loss_comp = loss_func(loss_weight, **loss_config)
                loss_components[loss_comp_name] = loss_comp
                extras.append(loss_comp)
            except AttributeError as e:
                raise NameError(f"Could not find loss function {loss_comp_name}")

    loss_func: LossFunction = LossFunction(loss_components=loss_components)

    reg_loss: LossFunction = build_reg_loss(fit_config)
    return loss_func, reg_loss, extras


def construct_model_functions(fit_config):
    loss_func, regularization_loss, extra_components = build_loss_function(fit_config)
    is_fit_stress = (
        tc.INPUT_FIT_LOSS_STRESS in loss_func.loss_components
        or tc.INPUT_FIT_LOSS_VIRIAL in loss_func.loss_components
    )
    if is_fit_stress:
        train_function_name = fit_config.get(
            "train_function", "ComputeBatchEnergyForcesVirials"
        )
    else:
        train_function_name = fit_config.get(
            "train_function", "ComputeBatchEnergyAndForces"
        )
    compute_function_name = fit_config.get(
        "compute_function", "ComputeStructureEnergyAndForcesAndVirial"
    )

    # Try import from default tpmodel.py, otherwise try experimental package
    # Code should work even if experimental package is removed!
    mod = importlib.import_module("tensorpotential.tpmodel")
    compute_function_config = fit_config.get("compute_function_config", {})
    if hasattr(mod, train_function_name):
        train_fn = getattr(mod, train_function_name)(
            compute_function_config=compute_function_config
        )
    else:
        mod_exp = importlib.import_module("tensorpotential.experimental.model_computes")
        train_fn: TrainFunction = getattr(mod_exp, train_function_name)(
            compute_function_config=compute_function_config
        )

    if hasattr(mod, compute_function_name):
        compute_fn: ComputeFunction = getattr(mod, compute_function_name)(
            compute_function_config=compute_function_config
        )
    else:
        mod_exp = importlib.import_module("tensorpotential.experimental.model_computes")
        compute_fn: ComputeFunction = getattr(mod_exp, compute_function_name)(
            compute_function_config=compute_function_config
        )

    metrics = build_metrics_function(fit_config, extra_loss_components=extra_components)
    compute_metrics = ComputeMetrics(metrics=metrics)

    model_functions = ModelFunctions(
        loss_fn=loss_func,
        regularization_loss_fn=regularization_loss,
        train_fn=train_fn,
        compute_fn=compute_fn,
        metrics_fn=compute_metrics,
    )

    return model_functions


def input_choice(query, choices, default_choice):
    """Input from stdin with list of available choices and default choice."""
    choices = list(choices)
    assert default_choice in choices
    while True:
        choice = (
            input(
                query
                + f", available options: {', '.join(choices)} (default = {default_choice}): "
            )
            or default_choice
        )
        if choice in choices:
            break
    return choice


def input_with_default(query, default_choice: Any = None):
    """Input from stdin with default value."""
    choice = input(query + ": ") or default_choice
    return choice


def input_no_default(query):
    """Input from stdin with default value."""
    while True:
        choice = input(query)
        if choice:
            break
    return choice


def generate_template_input():

    print("Generating 'input.yaml'")
    if not no_readline:
        readline.parse_and_bind("tab: complete")

    with resources.open_text("tensorpotential.resources", "input_template.yaml") as f:
        input_yaml_text = f.read()

    # 1. Training set and size
    train_filename = input_no_default(
        "Enter training dataset filename (ex.: data.pkl.gz, [TAB] - autocompletion): "
    )
    input_yaml_text = input_yaml_text.replace("{{TRAIN_FILENAME}}", train_filename)

    test_filename = input_with_default(
        "Enter test dataset filename (ex.: test.pkl.gz, [ENTER] - no separate test dataset)",
    )
    test_size = (
        float(
            input_with_default(
                "Enter test set fraction (default = 0.05)", default_choice=0.05
            )
        )
        if not test_filename
        else None
    )

    if test_filename:
        input_yaml_text = input_yaml_text.replace(
            "{{TEST_DATA}}", f"""test_filename: {test_filename}"""
        )
    elif test_size is not None and test_size > 0:
        input_yaml_text = input_yaml_text.replace(
            "{{TEST_DATA}}", f"""test_size: {test_size}"""
        )
    else:
        raise ValueError("Either test_filename or test_size must be specified.")

    # 2. Elements
    determine_elements_from_dataset = False
    elements_str = input(
        """Please enter list of elements (ex.: "Cu", "AlNi", [ENTER] - determine from dataset): """
    )
    if elements_str:
        patt = re.compile("([A-Z][a-z]?)")
        elements = patt.findall(elements_str)
        elements = sorted(elements)
        determine_elements_from_dataset = False
        print("Number of elements: ", len(elements))
        print("Elements: ", elements)
        elements = f"elements: [{elements}]"
    else:
        # determine from training set
        determine_elements_from_dataset = True
        elements = ""
    input_yaml_text = input_yaml_text.replace("{{ELEMENTS}}", elements)

    learning_rate = 0.008
    eval_init_stats = False

    finetune_model = input_choice(
        f"Do you want to finetune foundation model",
        choices=["yes", "no"],
        default_choice="no",
    )
    if finetune_model == "yes":

        available_foundation_models = [
            k for k, v in MODELS_METADATA.items() if CHECKPOINT_URL_KEY in v
        ]
        print("Available foundation models:")
        for model_name in available_foundation_models:
            print(f" - {model_name}: {MODELS_METADATA[model_name][DESCRIPTION_KEY]}")
        foundation_model_name = input_choice(
            f"Enter foundation model name",
            choices=available_foundation_models,
            default_choice="GRACE-1L-OMAT",
        )
        potential_template = f"""finetune_foundation_model: {foundation_model_name} 
        
  reduce_elements: True #  default - False, reduce elements to those provided in dataset 
        """
        input_yaml_text = input_yaml_text.replace("{{CUTOFF}}", "n/a")
        learning_rate = 0.001
        eval_init_stats = True
    else:
        print("Fitting from scratch")
        def_preset = get_default_preset_name()
        preset_name = input_choice(
            f"Enter model preset",
            choices=get_public_preset_list(),
            default_choice=def_preset if def_preset is not None else "GRACE_1LAYER",
        )
        potential_template = """preset: {{PRESET_NAME}} 

  ## For custom model from model.py::custom_model
  #  custom: model.custom_model

  # keywords-arguments that will be passed to preset or custom function
  kwargs: {{KWARGS}}

  #shift: False # True/False
  scale: True # False/True or float"""
        potential_template = potential_template.replace(
            "{{PRESET_NAME}}", str(preset_name)
        )

        avail_preset_complexities = get_preset_settings(preset_name)
        if avail_preset_complexities is not None:
            preset_complexity = input_choice(
                "Model complexity",
                choices=avail_preset_complexities.keys(),
                default_choice="medium",
            )
            kwargs = avail_preset_complexities[preset_complexity]
            def_cutoff = kwargs.pop("rcut")

            kwargs_str = json.dumps(kwargs).strip()
            kwargs_str = kwargs_str.replace('"', "").replace("'", "")
            potential_template = potential_template.replace("{{KWARGS}}", kwargs_str)

            cutoff = float(
                input_with_default(
                    f"Enter cutoff (default={def_cutoff})",
                    default_choice=def_cutoff,
                )
            )
        else:
            cutoff = 6
        print("Cutoff: ", cutoff)
        input_yaml_text = input_yaml_text.replace("{{CUTOFF}}", str(cutoff))

    input_yaml_text = input_yaml_text.replace(
        "{{POTENTIAL_SETTINGS}}", potential_template
    )
    input_yaml_text = input_yaml_text.replace(
        "{{eval_init_stats}}", str(eval_init_stats)
    )
    input_yaml_text = input_yaml_text.replace("{{learning_rate}}", str(learning_rate))
    input_yaml_text = input_yaml_text.replace(
        "{{min_learning_rate}}", str(learning_rate / 12)
    )

    ####### loss function type ###
    loss_type = input_choice(
        "Loss function type", choices=["square", "huber"], default_choice="huber"
    )
    input_yaml_text = input_yaml_text.replace("{{LOSS_TYPE}}", loss_type)

    huber_delta = (
        input_with_default(
            "For huber loss, please enter delta (default = 0.01)", default_choice=0.01
        )
        if loss_type == "huber"
        else None
    )
    extra_loss_args = f", delta: {huber_delta}" if loss_type == "huber" else ""
    input_yaml_text = input_yaml_text.replace("{{EXTRA_E_ARGS}}", extra_loss_args)

    ####### force loss weight ###
    print("Energy loss weight is equal to 1")
    force_loss_weight = str(
        input_with_default("Enter force loss weight (default = 5)", default_choice=5)
    )
    input_yaml_text = input_yaml_text.replace(
        "{{FORCE_LOSS_WEIGHT}}", force_loss_weight
    )

    ####### stress loss weight ###
    stress_loss_weight = input_with_default(
        "Enter stress loss weight (default = None)", default_choice=None
    )
    if stress_loss_weight is not None:
        stress_loss_str = f"stress: {{ weight: {stress_loss_weight}, type: {loss_type} {extra_loss_args} }},"
        input_yaml_text = input_yaml_text.replace("{{STRESS_LOSS}}", stress_loss_str)
    else:
        input_yaml_text = input_yaml_text.replace("{{STRESS_LOSS}}", "")

    switch_after = input_with_default(
        "Switch loss function E:F:S weights after certain number of epochs (total number of epochs = 500)? If yes - enter number of epochs (default = None)",
        default_choice=None,
    )
    if switch_after is not None:
        new_learning_rate = input_with_default(
            "Learning rate after switching (default = 0.001)", default_choice=0.001
        )
        new_energy_weight = input_with_default(
            "Energy weight after switching (old value = 1, default = 5)",
            default_choice=5,
        )
        new_force_weight = input_with_default(
            f"Force weight after switching (old value = {force_loss_weight}, default = 2)",
            default_choice=2,
        )

        switch_expression_str = (
            f"""switch: {{ after_iter: {switch_after}, learning_rate: {new_learning_rate}, """
            + f"""energy: {{ weight: {new_energy_weight} }}, """
            + f"""forces: {{ weight: {new_force_weight} }}, """
        )

        if stress_loss_weight is not None:
            new_stress_weight = input_with_default(
                f"Stress weight after switching (old value = {stress_loss_weight}, default = same value)",
                default_choice=stress_loss_weight,
            )
            switch_expression_str += f"""stress: {{ weight: {new_stress_weight} }}, """
        switch_expression_str += "}"
    else:
        switch_expression_str = ""
    input_yaml_text = input_yaml_text.replace("{{SWITCH_LOSS}}", switch_expression_str)

    # weighting scheme
    weighting_inp = input_choice(
        "Enter weighting scheme type",
        choices=["uniform", "energy"],
        default_choice="uniform",
    )

    if weighting_inp == "energy":
        weighting = """weighting: { type: energy_based, DElow: 1.0, DEup: 10.0, DFup: 50.0, DE: 1.0, DF: 1.0, wlow: 0.75, energy: convex_hull, seed: 42}"""
        print("Use energy-based sample weighting: ", weighting)
        # also enable compute_convex_hull: True option
        input_yaml_text = input_yaml_text.replace("{{COMPUTE_CONVEX_HULL}}", "True")
    else:
        weighting = ""
        print("Use uniform-based sample weighting")
        input_yaml_text = input_yaml_text.replace("{{COMPUTE_CONVEX_HULL}}", "False")

    input_yaml_text = input_yaml_text.replace("{{WEIGHTING_SCHEME}}", weighting)

    batch_size = input_with_default(
        "Enter batch size (default = 32)", default_choice=32
    )
    input_yaml_text = input_yaml_text.replace("{{BATCH_SIZE}}", str(batch_size))
    input_yaml_text = input_yaml_text.replace(
        "{{TEST_BATCH_SIZE}}", str(4 * int(batch_size))
    )

    with open("input.yaml", "w") as f:
        print(input_yaml_text, file=f)
    print("Input file is written into `input.yaml`")
    sys.exit(0)
