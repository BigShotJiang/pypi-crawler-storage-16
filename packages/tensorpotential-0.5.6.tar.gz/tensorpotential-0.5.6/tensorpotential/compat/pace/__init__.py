# import local subpackages
from . import potentials
from . import utils
from . import functions

# import local submodules
from . import fit
from . import tensorpot
from . import _version
from . import fitmetrics

__version__ = _version.get_versions()["version"]
