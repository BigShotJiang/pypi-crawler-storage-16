use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use uuid::Uuid;

#[cfg(test)]
use mockall::automock;

use crate::config::{MetricConfigLevel, MetricConfigType};
use crate::db::clickhouse::query_builder::{DatapointFilter, FloatComparisonOperator};
use crate::db::stored_datapoint::StoredDatapoint;
use crate::endpoints::datasets::DatapointKind;
use crate::endpoints::datasets::v1::types::DatapointOrderBy;
use crate::error::Error;

#[derive(Debug, Serialize, Deserialize, ts_rs::TS)]
#[ts(export)]
pub struct MetricFilter {
    pub metric: String,
    pub metric_type: MetricConfigType,
    pub operator: FloatComparisonOperator,
    pub threshold: f64,
    pub join_on: MetricConfigLevel,
}

#[derive(Debug, Serialize, Deserialize, ts_rs::TS)]
#[serde(rename_all = "snake_case")]
#[ts(export)]
pub enum DatasetOutputSource {
    // When generating a dataset, don't include any output.
    None,
    // When generating a dataset, include original inference output.
    Inference,
    // When generating a dataset, include any linked demonstration as output.
    Demonstration,
}

#[derive(Debug, Serialize, Deserialize, ts_rs::TS)]
#[cfg_attr(test, ts(export, optional_fields))]
pub struct DatasetQueryParams {
    pub inference_type: DatapointKind,
    pub function_name: Option<String>,
    pub dataset_name: Option<String>,
    pub variant_name: Option<String>,
    pub extra_where: Option<Vec<String>>,
    pub extra_params: Option<HashMap<String, String>>,
    // TODO: consider supporting compound filters (e.g. AND/OR)
    pub metric_filter: Option<MetricFilter>,
    pub output_source: DatasetOutputSource,
    pub limit: Option<u32>,
    pub offset: Option<u32>,
}

/// Parameters to query for dataset metadata (by aggregating over the datapoint tables).
#[derive(Deserialize)]
pub struct GetDatasetMetadataParams {
    /// Only select datasets matching a specific function.
    pub function_name: Option<String>,

    /// The maximum number of datasets to return.
    pub limit: Option<u32>,

    /// The number of datasets to skip before starting to return results.
    pub offset: Option<u32>,
}

#[derive(Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct DatasetMetadata {
    pub dataset_name: String,
    pub count: u32,
    pub last_updated: String,
}

#[derive(Deserialize, ts_rs::TS)]
#[cfg_attr(test, ts(export, optional_fields))]
pub struct CountDatapointsForDatasetFunctionParams {
    pub dataset_name: String,
    pub function_name: String,
    pub function_type: DatapointKind,
}

#[derive(Deserialize, ts_rs::TS)]
#[cfg_attr(test, ts(export, optional_fields))]
/// Legacy struct for old get_datapoint clickhouse query. To be deprecated.
pub struct GetDatapointParams {
    pub dataset_name: String,
    pub datapoint_id: Uuid,
    /// Whether to include stale datapoints in the query; false by default.
    pub allow_stale: Option<bool>,
}

/// A struct representing query params for a SELECT datapoints query.
#[derive(Deserialize)]
pub struct GetDatapointsParams {
    /// Dataset name to query. If not provided, all datasets will be queried.
    /// At least one of `dataset_name` or `ids` must be provided.
    #[serde(default)]
    pub dataset_name: Option<String>,

    /// Function name to filter by. If provided, only datapoints from this function will be returned.
    #[serde(default)]
    pub function_name: Option<String>,

    /// IDs of the datapoints to query. If not provided, all datapoints will be queried.
    /// At least one of `dataset_name` or `ids` must be provided.
    #[serde(default)]
    pub ids: Option<Vec<Uuid>>,

    /// Maximum number of datapoints to return.
    pub limit: u32,

    /// Number of datapoints to skip before starting to return results.
    pub offset: u32,

    /// Whether to include stale datapoints in the query.
    pub allow_stale: bool,

    /// Optional filter to apply when querying datapoints.
    /// Supports filtering by tags, time, and logical combinations (AND/OR/NOT).
    #[serde(default)]
    pub filter: Option<DatapointFilter>,

    /// Optional ordering criteria for the results.
    #[serde(default)]
    pub order_by: Option<Vec<DatapointOrderBy>>,

    /// Text query to filter. Case-insensitive substring search.
    #[serde(default)]
    pub search_query_experimental: Option<String>,
}

#[async_trait]
#[cfg_attr(test, automock)]
pub trait DatasetQueries {
    /// Counts rows for a dataset based on query parameters
    async fn count_rows_for_dataset(&self, params: &DatasetQueryParams) -> Result<u32, Error>;

    /// Inserts rows into a dataset table by selecting from the inference tables
    /// Returns the number of rows inserted
    async fn insert_rows_for_dataset(&self, params: &DatasetQueryParams) -> Result<u32, Error>;

    /// Gets dataset metadata (name, count, last updated)
    async fn get_dataset_metadata(
        &self,
        params: &GetDatasetMetadataParams,
    ) -> Result<Vec<DatasetMetadata>, Error>;

    /// Gets the count of unique dataset names
    async fn count_datasets(&self) -> Result<u32, Error>;

    /// Inserts a batch of datapoints into the database
    /// Internally separates chat and JSON datapoints and writes them to the appropriate tables
    /// Returns the number of rows written.
    async fn insert_datapoints(&self, datapoints: &[StoredDatapoint]) -> Result<u64, Error>;

    /// Counts datapoints for a specific dataset and function
    async fn count_datapoints_for_dataset_function(
        &self,
        params: &CountDatapointsForDatasetFunctionParams,
    ) -> Result<u32, Error>;

    /// Gets a single datapoint by dataset name and ID
    /// TODO(shuyangli): To deprecate in favor of `get_datapoints`
    async fn get_datapoint(&self, params: &GetDatapointParams) -> Result<StoredDatapoint, Error>;

    /// Gets multiple datapoints with various filters and pagination
    async fn get_datapoints(
        &self,
        params: &GetDatapointsParams,
    ) -> Result<Vec<StoredDatapoint>, Error>;

    /// Deletes datapoints or datasets by marking specified datapoints as stale.
    /// This is a soft deletion, so evaluation runs will still refer to it.
    ///
    /// If `datapoint_ids` is None, all datapoints in the dataset will be deleted.
    /// Otherwise, it's required to be non-empty, and only those datapoints with the given IDs will be deleted.
    ///
    /// Returns the number of datapoints that were deleted.
    async fn delete_datapoints(
        &self,
        dataset_name: &str,
        datapoint_ids: Option<&[Uuid]>,
    ) -> Result<u64, Error>;
}
