---
paths: src/assets/**/*
---

Load the `brand:styling-tenzir-ui` skill.
