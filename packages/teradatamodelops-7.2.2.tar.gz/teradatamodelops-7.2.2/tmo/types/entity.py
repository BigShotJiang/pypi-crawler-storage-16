from enum import Enum


class EntityType(Enum):
    MODEL = "model"
    FEATURE_ENGINEERING_TASK = "feature_engineering_task"
