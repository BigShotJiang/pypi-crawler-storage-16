from termitype.cli.bootstrap import bootstrap

if __name__ == "__main__":
    bootstrap()
