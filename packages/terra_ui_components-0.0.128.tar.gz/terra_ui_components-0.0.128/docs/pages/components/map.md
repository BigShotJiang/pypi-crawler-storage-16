---
meta:
    title: Map
    description:
layout: component
---

## Examples

### Default Map

```html:preview
<terra-map></terra-map>
```

### Configured Map

```html:preview
<terra-map has-navigation has-shape-selector has-coord-tracker></terra-map>
```

[component-metadata:terra-map]
