"""
Core modules for threading, proxy management, and work distribution.
"""