from .base_code_analyzer import BaseCodeAnalyzer
from .cpp_code_analyzer import CppCodeAnalyzer
from .go_code_analyzer import GoCodeAnalyzer
from .python_code_analyzer import PythonCodeAnalyzer
from .java_code_analyzer import JavaCodeAnalyzer
from .javascript_code_analyzer import JavascriptCodeAnalyzer


class AnalyzerFactory:

    _analyzers = {
        "python": PythonCodeAnalyzer(),
        "cpp": CppCodeAnalyzer(),
        "go": GoCodeAnalyzer(),
        "java": JavaCodeAnalyzer(),
        "javascript": JavascriptCodeAnalyzer()
    }

    @classmethod
    def get_analyzer(cls, language: str):
        if language not in cls._analyzers:
            raise ValueError(f"Unsupported language: {language}")
        return cls._analyzers.get(language)
