import re

from abc import ABC, abstractmethod
from typing import Tuple, List, Dict, Any

from ..models import CoverageResult
from ..common.file_utils import read_file


class BaseCodeAnalyzer(ABC):
    """代码分析器基类"""
    language = 'default'

    @abstractmethod
    def analyze(self, source_file: str, test_file: str) -> Dict[str, Any]:
        """分析测试覆盖率"""
        ...

    @abstractmethod
    def calculate_cyclomatic_complexity(self, source_code: str) -> int:
        """圈复杂度"""
        ...

    @abstractmethod
    def calculate_dependency_complexity(self, source_code: str) -> int:
        """依赖复杂度（import + 参数 + 调用等）"""
        ...
    
    def _calculate_lizard_complexity(self, source_code: str) -> int:
        """使用lizard计算圈复杂度"""
        try:
            import lizard
            import tempfile
            import os

            # 创建临时文件以使用lizard分析
            with tempfile.NamedTemporaryFile(mode='w', suffix=f'.{self.language}', delete=False) as temp_file:
                temp_file.write(source_code)
                temp_file_path = temp_file.name

            try:
                # 使用lizard分析代码
                result = lizard.analyze_file(temp_file_path)
                total_complexity = sum(func.cyclomatic_complexity for func in result.function_list)

                # 如果没有函数，返回基于控制结构的简单复杂度
                if not result.function_list:
                    return self.calculate_cyclomatic_complexity(source_code)

                return max(1, total_complexity)
            finally:
                # 删除临时文件
                os.unlink(temp_file_path)
        except Exception:
            # 如果lizard分析失败，使用内置方法
            return self.calculate_cyclomatic_complexity(source_code)

    def calculate_complexity(self, source_code: str) -> Tuple[int, int]:
        """计算代码复杂度（圈复杂度和依赖复杂度）"""
        try:
            # 尝试使用lizard计算圈复杂度
            import lizard
            cyclomatic_complexity = self._calculate_lizard_complexity(source_code)
        except ImportError:
            # 如果lizard不可用，则使用内置方法
            cyclomatic_complexity = self.calculate_cyclomatic_complexity(source_code)

        dependency_complexity = self.calculate_dependency_complexity(source_code)
        return cyclomatic_complexity, dependency_complexity

    def analyze_unmatched_file(self, source_file: str, language: str = None) -> CoverageResult:
        """分析未匹配文件的复杂度"""
        try:
            source_code = read_file(source_file)
            cyclomatic_complexity, dependency_complexity = self.calculate_complexity(source_code)
            return CoverageResult(
                source_file=source_file,
                language=language or self.language,
                cyclomatic_complexity=cyclomatic_complexity,
                dependency_complexity=dependency_complexity
            )
        except Exception:
            return CoverageResult(
                source_file=source_file,
                language=language or self.language,
                cyclomatic_complexity=0,
                dependency_complexity=0
            )

    def calculate_similarity(self, source_code: str, test_code: str) -> float:
        """计算源代码 & 测试代码相似度"""
        source_tokens = set(self._tokenize_code(source_code))
        test_tokens = set(self._tokenize_code(test_code))

        if not source_tokens or not test_tokens:
            return 0.0

        intersection = len(source_tokens.intersection(test_tokens))
        union = len(source_tokens.union(test_tokens))
        return round(intersection / union * 100.0, 2)

    def _tokenize_code(self, code: str) -> List[str]:
        """将代码分解为标记"""
        # 去除注释和空白字符
        lines = code.split('\n')
        tokens = []

        for line in lines:
            # 移除行注释
            if '//' in line:
                line = line[:line.index('//')]
            elif '#' in line:
                line = line[:line.index('#')]
            
            # 提取标识符、关键字、操作符等
            token_pattern = r'\b\w+\b|[^\w\s]'
            line_tokens = re.findall(token_pattern, line)
            tokens.extend([t for t in line_tokens if t.strip()])

        return tokens
