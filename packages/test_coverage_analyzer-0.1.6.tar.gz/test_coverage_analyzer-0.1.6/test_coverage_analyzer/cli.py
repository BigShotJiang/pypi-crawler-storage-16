"""命令行接口"""
import os
import sys
import json
import uuid
import traceback

from pathlib import Path

from .finder import TestFileFinder
from .analyzer import AnalyzerFactory
from .utils import (
    merge_sort_coverage_data,
    save_results_to_json
)
from .common.file_utils import write_json, write_file
from .prompts import *


def json2prompt(json_data):
    """
    将JSON数据转换为prompt格式的处理函数
    返回结构化的prompt数据（字典格式）
    """
    prompt_data = []

    if 'coverage_results' in json_data and len(json_data['coverage_results'])>0:
        for item in json_data['coverage_results']:
            prompt_data.append({
                'id': str(uuid.uuid4().hex),
                'prompt': f'''请给{item["language"]}代码文件{item["source_file"]}生成增量单元测试用例，它对应的测试文件为{item["test_file"]}，当前测试代码未覆盖的测试元素为{item["uncovered_elements"]},待测文件的圈复杂度为{item["cyclomatic_complexity"]}，依赖复杂度为{item["dependency_complexity"]}。接下来你要根据给定的文件的复杂度增量生成单元测试，使得待测文件的覆盖率尽可能高。'''
            })

    if 'unmatched' in json_data and len(json_data['unmatched'])>0:
        for item in json_data['unmatched']:
            prompt_data.append({
                'id': str(uuid.uuid4().hex),
                'prompt': f'''请给{item["language"]}代码文件{item["source_file"]}生成全量单元测试用例，待测文件的圈复杂度为{item["cyclomatic_complexity"]}，依赖复杂度为{item["dependency_complexity"]}。接下来你要根据给定的文件的复杂度全量生成单元测试，使得待测文件的覆盖率尽可能高。'''
            })

    return prompt_data


def save_prompt_json(prompt_data, output_dir, file_prefix):
    """保存prompt数据为JSON文件"""
    prompt_json_path = os.path.join(output_dir, f"{file_prefix}_prompt.json")
    with open(prompt_json_path, 'w', encoding='utf-8') as f:
        json.dump(prompt_data, f, ensure_ascii=False, indent=2)
    
    return prompt_json_path


def main():
    """主函数，提供命令行接口"""
    # 解析命令行参数
    if len(sys.argv) < 2 or len(sys.argv) > 8:
        print("用法: test-coverage-analyzer <源代码路径> [输出目录] [文件名前缀] [--threshold <阈值>] [--prompt] [--print]")
        print("参数说明:")
        print("  --threshold <阈值>: 设置覆盖率阈值（0-100的数字），过滤覆盖率高于阈值的文件")
        print("  --prompt: 对JSON文件进行二次处理生成拆解的文件粒度的单测prompts（不指定该参数默认不处理）")
        print("  --print: 将结果打印到终端（默认不会打印）")
        print("示例:")
        print("  test-coverage-analyzer ./my_project")
        print("  test-coverage-analyzer ./my_project ./reports my_result")
        print("  test-coverage-analyzer ./my_project ./reports my_result --threshold 50")
        print("  test-coverage-analyzer ./my_project ./reports my_result --threshold 80 --prompt --print")
        sys.exit(1)

    # 获取参数
    source_path = sys.argv[1]

    # 设置默认值
    default_output_dir = "./.zhanlu/test-local"
    output_dir = default_output_dir
    file_prefix = "test_scanner_result"
    # 默认不开启prompt处理
    prompt = False
    # 默认无阈值过滤
    threshold = None
    # 是否打印到终端，默认不开启
    print_to_terminal = False

    # 解析可选参数
    arg_index = 2
    while arg_index < len(sys.argv):
        arg = sys.argv[arg_index]

        if arg == '--threshold':
            arg_index += 1
            if arg_index >= len(sys.argv):
                print("错误: --threshold 参数需要指定一个数值")
                sys.exit(1)
            try:
                threshold = float(sys.argv[arg_index])
                if threshold < 0 or threshold > 100:
                    print("错误: 阈值必须在0-100之间")
                    sys.exit(1)
            except ValueError:
                print(f"错误: --threshold 参数必须是数字，得到: {sys.argv[arg_index]}")
                sys.exit(1)
        elif arg == '--prompt':
            prompt = True
        elif arg == '--print':
            print_to_terminal = True
        elif not arg.startswith('--'):
            # 位置参数：输出目录和文件名前缀
            if output_dir == default_output_dir:
                output_dir = arg
            elif file_prefix == "scanner_result":
                file_prefix = arg
            else:
                print(f"错误: 无效参数 '{arg}'")
                sys.exit(1)
        else:
            print(f"错误: 未知参数 '{arg}'")
            sys.exit(1)

        arg_index += 1

    # 验证源路径
    if not os.path.exists(source_path):
        print(f"错误: 源路径 '{source_path}' 不存在")
        sys.exit(1)

    # 创建输出目录（如果不存在）
    try:
        Path(output_dir).mkdir(parents=True, exist_ok=True)
    except Exception as e:
        print(f"错误: 无法创建输出目录 '{output_dir}': {e}")
        sys.exit(1)

    # 构建完整的文件路径
    json_path = os.path.join(output_dir, f"{file_prefix}.json")
    md_path = os.path.join(output_dir, f"{file_prefix}.md")

    # 执行分析
    finder = TestFileFinder()

    try:
        print(f"正在分析路径: {source_path}")
        print("查找源文件和测试文件配对...")

        matches, unmatched = finder.find_test_files(source_path)

        print(f"找到 {len(matches)} 个配对，{len(unmatched)} 个未匹配文件")
        print("分析覆盖率和代码复杂度...")

        # 分析覆盖率
        coverage_results = []
        for match in matches:
            coverage_result = AnalyzerFactory.get_analyzer(match.language).analyze(
                match.source_file, 
                match.test_file
            )
            coverage_results.append(coverage_result)

        # 应用阈值过滤
        if threshold is not None:
            print(f"应用阈值过滤 ({threshold}%)...")
            filtered_matches = []
            filtered_coverage_results = []

            for match, coverage_result in zip(matches, coverage_results):
                if coverage_result.coverage_percentage <= threshold:
                    filtered_matches.append(match)
                    filtered_coverage_results.append(coverage_result)

            matches = filtered_matches
            coverage_results = filtered_coverage_results
            print(f"过滤后剩余 {len(matches)} 个配对文件")

        # 分析未匹配文件的复杂度
        unmatched_results = []
        for source_file, lang in unmatched:
            unmatched_result = AnalyzerFactory.get_analyzer(lang).analyze_unmatched_file(source_file)
            unmatched_results.append(unmatched_result)

        # 保存结果
        # save_results_to_txt(matches, unmatched, coverage_results, unmatched_results, txt_path)
        json_data = save_results_to_json(matches, unmatched, coverage_results, unmatched_results)

        # 如果开启prompt处理
        if prompt:
            print("正在处理JSON数据生成prompt格式...")
            # 转换为prompt格式
            prompt_data = json2prompt(json_data)
            # 保存prompt文件
            prompt_json_path = save_prompt_json(prompt_data, output_dir, file_prefix)
            print(f"  Prompt JSON文件: {prompt_json_path}")

        json_results = merge_sort_coverage_data(json_data)
        file_res_prompts = [file_res_template_with_uncovered.format_map(file_res) if file_res['test_file'] \
            else file_res_template.format_map(file_res) for file_res in json_results['coverage_results']]
        project_res_prompts = project_res_template.format(
            file_count=len(json_results['coverage_results']),
            business_file_count=len(json_results['coverage_results']),
            zero_coverage_count=len(json_data["unmatched"]),
            file_result='\n'.join(file_res_prompts)
        )
        # write_json(json_path, json_results)
        write_file(md_path, project_res_prompts)

        print(f"结果已保存到: {md_path}")
        print(f"\n=== 分析结果摘要 ===")
        print(f"源文件总数: {len(matches) + len(unmatched)}")
        print(f"已匹配测试文件: {len(matches)}")
        print(f"未匹配测试文件: {len(unmatched)}")

        avg_coverage = sum([cr['coverage_percentage'] for cr in json_results['coverage_results']]) / len(json_results['coverage_results']) if json_results['coverage_results'] else 0
        print(f"平均覆盖率: {avg_coverage:.2f}%")

        if unmatched_results:
            avg_cyclomatic = sum(ur.cyclomatic_complexity for ur in unmatched_results) / len(unmatched_results) if unmatched_results else 0
            print(f"未匹配文件平均圈复杂度: {avg_cyclomatic:.2f}\n")
        if print_to_terminal:
            print(project_res_prompts)

    except Exception as e:
        print(f"错误: {e}")
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
