import json


def read_file(file_path, encoding='utf-8'):
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            return f.read()
    except FileNotFoundError:
        raise FileNotFoundError(f"File '{file_path}' not found.")
    except Exception as e:
        raise Exception(f"Error reading file '{file_path}': {str(e)}")


def load_json(json_path, encoding='utf-8'):
    """加载JSON文件"""
    with open(json_path, 'r', encoding=encoding) as f:
        return json.load(f)


def write_json(output_path, result, encoding='utf-8', indent=2):
    with open(output_path, 'w', encoding=encoding) as f:
        json.dump(result, f, ensure_ascii=False, indent=indent)


def write_file(output_path, result, encoding='utf-8'):
    with open(output_path, 'w', encoding=encoding) as f:
        f.write(result)
