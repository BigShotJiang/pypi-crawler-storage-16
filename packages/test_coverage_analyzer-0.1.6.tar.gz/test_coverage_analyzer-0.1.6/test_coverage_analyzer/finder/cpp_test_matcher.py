import os

from pathlib import Path
from typing import TYPE_CHECKING

from .base_test_matcher import BaseTestMatcher
from ..models import TestFileMatch

# 避免循环依赖：运行时不导入 TestFileFinder，只在类型检查时加载
if TYPE_CHECKING:
    from .test_file_finder import TestFileFinder


class CppTestMatcher(BaseTestMatcher):
    def __init__(self):
        super().__init__(
            language="cpp",
            source_pattern=r'.*\.(cpp|cc|cxx|c\+\+)$',
            test_patterns=[
                r'.*_test\.(cpp|cc|cxx|c\+\+)$',
                r'.*test_.*\.(cpp|cc|cxx|c\+\+)$',
                r'test_.*\.(cpp|cc|cxx|c\+\+)$',
                r'.*Test\.(cpp|cc|cxx|c\+\+)$'
            ],
            language_excludes=[
                r'.*CMakeLists\.txt$',
                r'.*Makefile$',
                r'.*makefile$',
                r'.*config\.h$',
                r'.*config\.cpp$',
                r'.*settings\.h$',
                r'.*settings\.cpp$',
                r'.*constants\.h$',
                r'.*constants\.cpp$',
                r'.*Dockerfile$',
                r'.*docker-compose\.yml$',
                r'.*docker-compose\.yaml$'
            ]
        )
        self.CPP_EXTENSIONS = [".cpp", ".cc", ".cxx", ".c++"]

    def build_possible_test_names(self, source_file: str):
        source_path = Path(source_file)
        name = source_path.stem

        return [
            f"{name}_test{ext}"
            for ext in self.CPP_EXTENSIONS
        ] + [
            f"test_{name}{ext}"
            for ext in self.CPP_EXTENSIONS
        ] + [
            f"{name}Test{ext}"
            for ext in self.CPP_EXTENSIONS
        ]

    def _is_test_file(self, filename: str, matcher: BaseTestMatcher) -> bool:
        return any(p.match(filename) for p in matcher.test_patterns)

    def is_matching_test(self, source_name: str, test_filename: str) -> bool:
        for ext in self.CPP_EXTENSIONS:
            if test_filename in {
                f"{source_name}_test{ext}",
                f"test_{source_name}{ext}",
                f"{source_name}Test{ext}",
            }:
                return True
        return False

    def find_test_files(self, path: str, finder: "TestFileFinder"):
        # 收集所有项目文件
        all_files = []
        for root, _, files in os.walk(path):
            for f in files:
                full = os.path.join(root, f)
                all_files.append(full)

        all_files_set = set(all_files)

        # 按目录分类
        dir_index = {}
        for f in all_files:
            d = os.path.dirname(f)
            dir_index.setdefault(d, []).append(f)

        TEST_DIR_NAMES = {"test", "tests", "unit", "unittests"}

        test_dirs = {d for d in dir_index if os.path.basename(d).lower() in TEST_DIR_NAMES}

        matches = []
        unmatched = []

        for source in all_files:
            matcher = finder._get_language_matcher(source)
            if not matcher:
                continue

            filename = os.path.basename(source)
            if finder._should_exclude(filename, matcher):
                continue

            # 排除测试文件
            if self._is_test_file(filename, matcher):
                continue

            source_path = Path(source)
            source_name = source_path.stem
            source_dir = str(source_path.parent)

            # 同目录精确匹配
            for test_name in matcher.build_possible_test_names(source):
                test_path = os.path.join(source_dir, test_name)
                if test_path in all_files_set:
                    matches.append(TestFileMatch(source, test_path, matcher.language))
                    break
            else:
                found = False

                # test/ 目录精确搜索
                for td in test_dirs:
                    for f in dir_index.get(td, []):
                        test_filename = os.path.basename(f)

                        if not any(p.match(test_filename) for p in matcher.test_patterns):
                            continue

                        if matcher.is_matching_test(source_name, test_filename):
                            matches.append(TestFileMatch(source, f, matcher.language))
                            found = True
                            break

                    if found:
                        break

                # 全局 fallback 搜索
                if not found:
                    for f in all_files:
                        test_filename = os.path.basename(f)

                        if not any(p.match(test_filename) for p in matcher.test_patterns):
                            continue

                        if matcher.is_matching_test(source_name, test_filename):
                            matches.append(TestFileMatch(source, f, matcher.language))
                            found = True
                            break

                if not found:
                    # unmatched.append((source, matcher.language))
                    unmatched.append(TestFileMatch(source, None, matcher.language))
        return matches, unmatched
