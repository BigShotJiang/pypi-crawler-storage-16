from pathlib import Path

from .base_test_matcher import BaseTestMatcher


class GoTestMatcher(BaseTestMatcher):
    def __init__(self):
        super().__init__(
            language="go",
            source_pattern=r'.*\.go$',
            test_patterns=[r'.*_test\.go$'],
            language_excludes=[
                r'.*go\.mod$',
                r'.*go\.sum$',
                r'.*config\.go$',     # Go配置文件
                r'.*config.*\.go$',
                r'.*settings\.go$',
                r'.*Dockerfile$',
                r'.*docker-compose\.yml$',
                r'.*docker-compose\.yaml$'
            ]
        )

    def build_possible_test_names(self, source_file: str):
        name = Path(source_file).stem
        return [f"{name}_test.go"]

    def is_matching_test(self, source_name: str, test_filename: str) -> bool:
        """检查测试文件名是否可能对应源文件名"""
        stem = Path(test_filename).stem
        return stem == f"{source_name}_test"
