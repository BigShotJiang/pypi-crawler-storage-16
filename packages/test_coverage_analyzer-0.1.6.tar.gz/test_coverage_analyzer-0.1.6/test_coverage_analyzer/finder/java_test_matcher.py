from pathlib import Path

from .base_test_matcher import BaseTestMatcher


class JavaTestMatcher(BaseTestMatcher):
    def __init__(self):
        super().__init__(
            language="java",
            source_pattern=r'.*\.java$',
            test_patterns=[
                r'.*Test\.java$',
                r'Test.*\.java$',
                r'.*Tests\.java$',
                r'.*TestCase\.java$'
            ],
            language_excludes=[
                r'.*pom\.xml$',       # Maven配置文件
                r'.*build\.gradle$',  # Gradle配置文件
                r'.*settings\.gradle$',
                r'.*application\.properties$',  # Spring配置文件
                r'.*application\.yml$',
                r'.*application\.yaml$',
                r'.*logback\.xml$',
                r'.*log4j\.xml$',
                r'.*config\.java$',   # 配置类
                r'.*Config\.java$',
                r'.*Settings\.java$',
                r'.*settings\.java$',
                r'.*Constants\.java$', # 常量类
                r'.*constants\.java$',
                r'.*Dockerfile$',
                r'.*docker-compose\.yml$',
                r'.*docker-compose\.yaml$'
            ]
        )

    def build_possible_test_names(self, source_file: str):
        name = Path(source_file).stem
        return [
            f"{name}Test.java",
            f"{name}Tests.java",
            f"{name}TestCase.java"
        ]

    def is_matching_test(self, source_name: str, test_filename: str) -> bool:
        """检查测试文件名是否可能对应源文件名"""
        stem = Path(test_filename).stem
        return stem in {
            f"{source_name}Test",
            f"{source_name}Tests",
            f"{source_name}TestCase"
        }
