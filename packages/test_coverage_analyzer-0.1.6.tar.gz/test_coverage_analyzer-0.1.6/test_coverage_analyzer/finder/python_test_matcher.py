import os
from pathlib import Path
from collections import defaultdict

from .base_test_matcher import BaseTestMatcher
from ..models import TestFileMatch


EXCLUDED_DIRS = {
            ".git", ".idea", ".vscode", "__pycache__", "node_modules",
            "build", "dist", "target", ".venv", "venv", ".mypy_cache", ".pytest_cache", 'migrations'
        }

EXCLUDED_FILES = {
            "__init__.py", "__main__.py", "setup.py", "requirements.txt","requirements.py", "config.py", "settings.py", "manage.py", "tests.py",
            "Dockerfile", "docker-compose.yml", "docker-compose.yaml",
            "Pipfile", "pyproject.toml", "tox.ini"
        }


class PythonTestMatcher(BaseTestMatcher):
    def __init__(self):
        super().__init__(
            language="python",
            source_pattern=r".*\.py$",
            test_patterns=[
                r'.*_test\.py$',
                # r'.*test_.*\.py$',
                r'test_.*\.py$'
            ],
            language_excludes = [
                            r'.*__init__\.py$',   # Python的__init__.py文件
                            r'.*config\.py$',     # Python的配置文件
                            r'.*settings\.py$',   # Python的设置文件
                            r'.*setup\.py$',      # Python的setup文件
                            r'.*requirements\.py$',
                            r'.*requirements.*\.txt$',
                            r'.*Pipfile$',
                            r'.*pyproject\.toml$',
                            r'.*tox\.ini$',
                            r'.*Dockerfile$',
                            r'.*docker-compose\.yml$',
                            r'.*docker-compose\.yaml$',
            ]
        )

    def build_possible_test_names(self, source_file: str):
        name = Path(source_file).stem
        return [
            f"test_{name}.py",
            f"{name}_test.py",
            # f"{name}_tests.py"
        ]

    def is_matching_test(self, source_name: str, test_filename: str) -> bool:
        """检查测试文件名是否可能对应源文件名"""
        stem = Path(test_filename).stem
        return stem in {
            f"test_{source_name}",
            f"{source_name}_test",
            #f"{source_name}_tests"
        }

    def is_test_file(self, filename):
        if filename.endswith(".py"):
            return filename.startswith("test_") or filename.endswith("_test.py")
        else:
            return False

    def scan_all_files(self, base_path):
        source_files = defaultdict(list)
        test_files = defaultdict(list)

        for root, dirs, files in os.walk(base_path):
            # 过滤掉不需要遍历的目录
            dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS]

            for file in files:
                ext = os.path.splitext(file)[1]
                if ext != '.py' or file in EXCLUDED_FILES:
                    continue

                full_path = os.path.join(root, file)
                full_path = os.path.abspath(full_path)  # 确保是绝对路径

                if self.is_test_file(file):
                    test_files[file].append(full_path)
                else:
                    source_files[file].append(full_path)

        return source_files, test_files

    def get_possible_source_name(self, test_name):
        """
        根据测试文件名返回可能的源文件名
        """
        if test_name.endswith(".py") and test_name.startswith("test_"):
            return test_name.replace("test_", "", 1)
        elif test_name.endswith(".py") and test_name.endswith("_test.py"):
            return test_name.replace("_test.py", ".py")
        else:
            return None  # 无法推断

    def normalize_test_path(self, test_path):
        """
        将 test 文件路径还原成可能的源文件路径
        例如：
        - tests/test_utils.py → utils.py
        - com/example/UserServiceTest.java → com/example/UserService.java
        - math_test.cpp → math.cpp
        - some_package/math_test.go → some_package/math.go
        """
        parts = test_path.split(os.sep)
        filename = parts[-1]

        # 去除目录前缀
        if parts[0] in {"tests", "test", "__tests__", "__test__"}:
            parts = parts[1:]

        # 文件名处理（统一由 get_possible_source_name 推断）
        source_name = self.get_possible_source_name(filename)
        if source_name:
            parts[-1] = source_name
        return os.path.join(*parts)

    def match_test_to_source_with_path(self, source_files, test_files):
        matched_pairs = []
        unmatched_tests = []
        matched_sources = set()  # 记录所有已经被匹配到的源文件路径

        for test_name, test_paths in test_files.items():
            for test_rel_path in test_paths:
                normalized = self.normalize_test_path(test_rel_path)
                test_base_name = os.path.basename(normalized)  # 例如 process.py
                best_match = None
                strict_match_found = False

                #  第一轮：路径完全匹配
                for source_list in source_files.values():
                    for source_rel_path in source_list:
                        if normalized == source_rel_path:
                            best_match = source_rel_path
                            strict_match_found = True
                            break
                        elif normalized.endswith(source_rel_path):  # 子路径匹配

                            best_match = source_rel_path
                    if strict_match_found:
                        break

                #  第二轮 fallback：根据 test_process.py → process.py 的同名匹配
                if not strict_match_found:
                    target_name = self.get_possible_source_name(test_name)
                    if target_name and target_name in source_files:
                        
                        best_match = source_files[target_name][0]
            

                if best_match:
                    matched_pairs.append(TestFileMatch(best_match, test_rel_path, "python"))
                    matched_sources.add(best_match)
                else:
                    unmatched_tests.append(test_rel_path)

        # 收集所有“没有匹配到任何测试文件”的源文件
        unmatched_sources = []
        for source_list in source_files.values():
            for source_rel_path in source_list:
                if source_rel_path not in matched_sources:
                    # unmatched_sources.append((source_rel_path, "python"))
                    unmatched_sources.append(TestFileMatch(test_rel_path, None, "python"))

        return matched_pairs, unmatched_sources    

    def find_test_files(self, path: str, **kwargs):
        source_files, test_files = self.scan_all_files(path)
        matches, unmatches = self.match_test_to_source_with_path(source_files=source_files, test_files=test_files)
        return matches, unmatches
