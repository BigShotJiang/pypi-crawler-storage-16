from dataclasses import dataclass, field
from typing import List


@dataclass
class TestFileMatch:
    """测试文件匹配结果"""
    source_file: str
    test_file: str
    language: str


@dataclass
class CoverageResult:
    """覆盖率结果"""
    source_file: str
    test_file: str = None
    language: str = None
    total_testable_elements: int = 0
    tested_elements: int = 0
    coverage_percentage: float = 0.0
    uncovered_elements: List[str] = field(default_factory=list)
    code_similarity: float = 0.0
    cyclomatic_complexity: int = 0
    dependency_complexity: int = 0


@dataclass
class LanguagePatterns:
    """语言模式配置"""
    source_pattern: str
    test_patterns: List[str]
    exclude_patterns: List[str]
