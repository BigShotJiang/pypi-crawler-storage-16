project_res_template = """【当前项目单元测试覆盖率总览】
- 扫描文件总数：{file_count}
- 存在可测试业务文件数：{business_file_count}
- 覆盖率为 0 的文件数：{zero_coverage_count}

【文件级覆盖明细】
{file_result}"""

file_res_template = """源文件：{source_file}
测试文件：{test_file}
圈复杂度：{cyclomatic_complexity}
依赖复杂度：{dependency_complexity}
"""

file_res_template_with_uncovered = """源文件：{source_file}
测试文件：{test_file}
测试覆盖率：{coverage_percentage}%
未覆盖元素：{uncovered_elements}
圈复杂度：{cyclomatic_complexity}
依赖复杂度：{dependency_complexity}
"""
