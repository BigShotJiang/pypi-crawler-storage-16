# Test Coverage Analyzer

多语言测试文件查找和覆盖率分析工具，支持Python、Java、Go、C++、JavaScript等语言。

## 功能特点

- 自动查找源代码对应的测试文件
- 分析代码覆盖率
- 计算代码相似度
- 评估代码复杂度（圈复杂度和依赖复杂度）
- 生成详细的分析报告

## 安装

```bash
pip install test-coverage-analyzer
```

# 使用方法
## 命令行使用

```bash
test-coverage-analyzer <源代码路径> <输出文件名>

# For example
test-coverage-analyzer ./my_project ./coverage_report
```

## Python API 使用

```python
from test_coverage_analyzer import TestFileFinder, CoverageAnalyzer

# 创建查找器和分析器
finder = TestFileFinder()
analyzer = CoverageAnalyzer()

# 查找测试文件
matches, unmatched = finder.find_test_files("./my_project")

# 分析覆盖率
coverage_results = []
for match in matches:
    result = analyzer.analyze_coverage(
        match.source_file,
        match.test_file,
        match.language
    )
    coverage_results.append(result)
```

# 支持的语言
- Python
- Java
- Go
- C++
- JavaScript/TypeScript

# 输出报告

工具会生成两种格式的报告：

- TXT 格式：人类可读的详细报告
- JSON 格式：便于程序处理的结构化数据