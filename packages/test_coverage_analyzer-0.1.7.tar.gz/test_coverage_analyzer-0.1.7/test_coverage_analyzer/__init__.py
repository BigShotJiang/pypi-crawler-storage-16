"""
Test Coverage Analyzer - 多语言测试文件查找和覆盖率分析工具
"""

__version__ = "0.1.4"
__author__ = "xisang"
__email__ = "xisang@gmail.com"

from .finder import TestFileFinder
   
from .analyzer import AnalyzerFactory

from .utils import (
    save_results_to_txt,
    save_results_to_json
)
from .models import (
    TestFileMatch,
    CoverageResult
)

from .cli import main

__all__ = [
    "AnalyzerFactory",
    "TestFileFinder",
    "save_results_to_txt",
    "save_results_to_json",
    "TestFileMatch",
    "CoverageResult",
    "main"
]
