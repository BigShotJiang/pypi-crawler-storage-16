import re
import os

from typing import Dict, Any

from .base_code_analyzer import BaseCodeAnalyzer, CoverageResult


class CppCodeAnalyzer(BaseCodeAnalyzer):
    language = 'cpp'

    def calculate_cyclomatic_complexity(self, source_code: str) -> int:
        """C++ 代码圈复杂度计算逻辑"""

        # 去除注释 
        code = re.sub(r'/\*.*?\*/', '', source_code, flags=re.DOTALL)
        code = re.sub(r'//.*', '', code)

        complexity = 1  # 基础路径

        #  控制流关键字 
        patterns = [
            r'\belse\s+if\s*\(',   # else if 单独统计，避免被 if 重复计数
            r'\bif\s*\(',
            r'\bfor\s*\(',
            r'\bwhile\s*\(',
            r'\bcatch\s*\(',
            r'\bcase\b',          # switch 的每个 case 是一个分支
        ]

        for p in patterns:
            complexity += len(re.findall(p, code))

        # try 本身算一个分支
        complexity += len(re.findall(r'\btry\s*\{', code))

        # 逻辑运算符
        complexity += len(re.findall(r'&&|\|\|', code))

        # 三元运算符 ?: 
        complexity += len(re.findall(r'\?', code))

        return max(1, complexity)

    def calculate_dependency_complexity(self, source_code: str) -> int:
        """依赖复杂度计算：include + 函数参数数量"""

        dependency_complexity = 0

        # 去除注释 
        code = re.sub(r'/\*.*?\*/', '', source_code, flags=re.DOTALL)
        code = re.sub(r'//.*', '', code)

        # include 
        include_pattern = r'^\s*#\s*include\s+[<"].+[>"]'
        dependency_complexity += len(re.findall(include_pattern, code, re.MULTILINE))

        # 支持格式：
        # void func(int a, float b)
        # int A::foo(const string& s)
        # template <T> T bar(T x, T y)
        func_pattern = r'(\w[\w:]*)\s*\(([^)]*)\)'

        functions = re.findall(func_pattern, code)

        for func_name, params in functions:
            # 排除构造函数 / 析构函数（没有返回值）
            if func_name.startswith("~"):
                continue

            # 无参数
            params = params.strip()
            if not params:
                continue

            # 计算参数数量
            count = len([p for p in params.split(',') if p.strip()])
            dependency_complexity += count

        return max(0, dependency_complexity)

    def analyze(self, source_file: str, test_file: str) -> Dict[str, Any]:
        """C++ 文件覆盖率分析逻辑"""
        try:
            with open(source_file, 'r', encoding='utf-8') as f:
                source_code = f.read()

            filename = os.path.basename(source_file).lower()
            if any(keyword in filename for keyword in ['config', 'settings', 'constants']):
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language='cpp',
                    total_testable_elements=0,
                    tested_elements=0,
                    coverage_percentage=0.0,
                    uncovered_elements=[],
                    code_similarity=0.0,
                    cyclomatic_complexity=0,
                    dependency_complexity=0
                )

            # 预编译所有正则表达式
            PUBLIC_PATTERN = re.compile(r'\bpublic\s*:')
            PRIVATE_PROTECTED_PATTERN = re.compile(r'\b(private|protected)\s*:')
            FUNCTION_PATTERN = re.compile(r'\b\w[\w:]*\s+(\w+)\s*\([^)]*\)\s*\{?')
            CONSTRUCTOR_PATTERN = re.compile(r'\b(\w+)\s*\([^)]*\)\s*\{')
            CLASS_PATTERN = re.compile(r'\b(class|struct)\s+(\w+)')
            FUNCTION_CALL_PATTERN = re.compile(r'\b{0}\s*\(')  # 需要format填充函数名
            CLASS_REF_PATTERN = re.compile(r'\b{0}\b')  # 需要format填充类名

            # 提取 public 区域函数
            testable_elements = []
            in_public = False
            lines = source_code.splitlines()  # 避免重复调用splitlines()
            
            for line in lines:
                if PUBLIC_PATTERN.search(line):
                    in_public = True
                    continue
                if PRIVATE_PROTECTED_PATTERN.search(line):
                    in_public = False
                    continue

                if in_public:
                    m = FUNCTION_PATTERN.search(line)
                    if m:
                        name = m.group(1)
                        if name not in self.DEFAULT_IGNORE:
                            testable_elements.append(name)

            # 无 public 时尝试通用函数提取
            if not testable_elements:
                matches = CONSTRUCTOR_PATTERN.findall(source_code)
                for name in matches:
                    if name[0].isupper() and name not in self.DEFAULT_IGNORE:
                        testable_elements.append(name)

            # 类提取
            class_matches = CLASS_PATTERN.findall(source_code)
            for _, cls in class_matches:
                testable_elements.append(f"class_{cls}")

            # 去重
            testable_elements = list(set(testable_elements))

            # 读取测试文件
            with open(test_file, 'r', encoding='utf-8') as f:
                test_code = f.read()

            # 匹配测试中出现的调用
            tested_elements = []
            for elem in testable_elements:
                if elem.startswith("class_"):
                    cname = elem[6:]
                    # 使用预编译的类引用模式
                    if CLASS_REF_PATTERN.format(re.escape(cname)).search(test_code):
                        tested_elements.append(elem)
                else:
                    # 使用预编译的函数调用模式
                    if FUNCTION_CALL_PATTERN.format(re.escape(elem)).search(test_code):
                        tested_elements.append(elem)

            tested_elements = list(set(e for e in tested_elements if e not in self.DEFAULT_IGNORE))

            # 最终计算
            total = len(testable_elements)
            tested = len(tested_elements)
            coverage = tested / total * 100 if total else 0.0
            uncovered = [e for e in testable_elements if e not in tested_elements]

            # similarity = self.calculate_similarity(source_code, test_code)
            cyclomatic_complexity = self.calculate_cyclomatic_complexity(source_code)
            dependency_complexity = self.calculate_dependency_complexity(source_code)

            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='cpp',
                total_testable_elements=total,
                tested_elements=tested,
                coverage_percentage=coverage,
                uncovered_elements=uncovered,
                cyclomatic_complexity=cyclomatic_complexity,
                dependency_complexity=dependency_complexity
            )

        except Exception:
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='cpp',
                total_testable_elements=0,
                tested_elements=0,
                coverage_percentage=0.0,
                uncovered_elements=[],
                code_similarity=0.0,
                cyclomatic_complexity=0,
                dependency_complexity=0
            )
