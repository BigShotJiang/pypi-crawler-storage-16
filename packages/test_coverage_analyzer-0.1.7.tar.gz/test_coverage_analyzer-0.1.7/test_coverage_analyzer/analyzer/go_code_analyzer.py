import re
import os
from typing import Dict, Any

from .base_code_analyzer import BaseCodeAnalyzer, CoverageResult


class GoCodeAnalyzer(BaseCodeAnalyzer):
    language = 'go'

    # 预编译正则表达式，提高性能
    _IF_PATTERN = re.compile(r'\bif\s*\(')
    _FOR_PATTERN = re.compile(r'\bfor\s*[^\{]*\{')
    _SWITCH_PATTERN = re.compile(r'\bswitch\s*[^\{]*\{')
    _SELECT_PATTERN = re.compile(r'\bselect\s*\{')
    _BOOL_OP_PATTERN = re.compile(r'&&|\|\|')
    _IMPORT_PATTERN = re.compile(r'^\s*import\s+', re.MULTILINE)
    _FUNC_DECL_PATTERN = re.compile(r'func\s+\w+\s*\([^)]*\)')
    _PUBLIC_FUNC_PATTERN = re.compile(r'func\s+([A-Z]\w*)\s*\([^)]*\)\s*[^{]*\{')
    _TYPE_PATTERN = re.compile(r'type\s+([A-Z]\w+)')
    _COMMENT_PATTERN = re.compile(r'//.*?$|/\*.*?\*/', re.DOTALL | re.MULTILINE)

    # 忽略列表，包含Go语言内置函数和关键字
    _IGNORE_ELEMENTS = {
        'main', 'len', 'append', 'copy', 'close', 'delete', 'make', 'new', 'panic', 
        'print', 'println', 'recover', 'cap', 'complex', 'imag', 'real', 'Type', 
        'Value', 'error', 'string', 'int', 'int64', 'int32', 'float64', 'bool', 
        'byte', 'rune', 'map', 'slice', 'chan', 'struct', 'interface', 'func', 
        'var', 'const', 'type', 'package', 'import', 'return', 'if', 'else', 
        'for', 'range', 'switch', 'case', 'default', 'break', 'continue', 
        'goto', 'fallthrough', 'defer', 'go', 'select', 'true', 'false', 'nil'
    }

    _CONTROL_ELEMENTS = ['if', 'for', 'range', 'switch', 'return', 'func', 
        'var', 'const', 'type', 'import', 'package', 
        'go', 'defer', 'select', 'case', 'default', 
        'break', 'continue', 'goto', 'fallthrough'
    ]

    def calculate_cyclomatic_complexity(self, source_code: str) -> int:
        """计算Go代码圈复杂度"""
        # 移除注释以避免在注释中的匹配
        code_without_comments = self._COMMENT_PATTERN.sub('', source_code)

        complexity = 1  # 基础复杂度

        # 计算圈复杂度：控制结构
        complexity += len(self._IF_PATTERN.findall(code_without_comments))
        complexity += len(self._FOR_PATTERN.findall(code_without_comments))
        complexity += len(self._SWITCH_PATTERN.findall(code_without_comments))
        complexity += len(self._SELECT_PATTERN.findall(code_without_comments))

        # 计算布尔运算符
        complexity += len(self._BOOL_OP_PATTERN.findall(code_without_comments))

        return complexity

    def calculate_dependency_complexity(self, source_code: str) -> int:
        """import + 函数参数复杂度"""
        # 移除注释以避免在注释中的匹配
        code_without_comments = self._COMMENT_PATTERN.sub('', source_code)
        
        dependency_complexity = 0
        
        # 计算依赖复杂度：导入语句数量
        dependency_complexity += len(self._IMPORT_PATTERN.findall(code_without_comments))
        
        # 计算函数参数数量
        func_declarations = self._FUNC_DECL_PATTERN.findall(code_without_comments)
        for func in func_declarations:
            # 提取参数部分
            start = func.find('(')
            end = func.rfind(')')
            if start != -1 and end != -1 and end > start:
                param_part = func[start+1:end]
                if param_part.strip():
                    # 分割参数并计算数量，处理参数类型声明
                    params = [p.strip() for p in param_part.split(',') if p.strip()]
                    # Go函数参数可能包含多个变量声明，如 func(a, b int, c string)
                    param_count = 0
                    for param in params:
                        # 检查是否有多个变量名
                        var_part = param.split()[:-1] if len(param.split()) > 1 else [param]
                        # 计算变量名数量
                        for var_decl in var_part:
                            if ' ' not in var_decl.strip():
                                param_count += 1
                            else:
                                # 处理多个变量名的情况
                                var_names = var_decl.split()
                                param_count += len(var_names) - 1  # 最后一个是类型名
                    dependency_complexity += param_count

        return dependency_complexity

    def analyze(self, source_file: str, test_file: str) -> Dict[str, Any]:
        """分析Go文件的覆盖率"""
        try:
            with open(source_file, 'r', encoding='utf-8') as f:
                source_code = f.read()
            
            # 检查是否是配置文件，如果是则不进行分析
            filename = os.path.basename(source_file)
            if 'config' in filename.lower() or 'settings' in filename.lower():
                # 返回空结果，因为这些文件不需要测试
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language='go',
                    total_testable_elements=0,
                    tested_elements=0,
                    coverage_percentage=0.0,
                    uncovered_elements=[],
                    code_similarity=0.0,
                    cyclomatic_complexity=0,
                    dependency_complexity=0
                )
            
            # 移除注释以避免在注释中的匹配
            source_code_no_comments = self._COMMENT_PATTERN.sub('', source_code)
            
            # 提取Go公共函数和类型（大写字母开头）
            testable_elements = set()
            
            # 提取公共函数（以大写字母开头）
            functions = self._PUBLIC_FUNC_PATTERN.findall(source_code_no_comments)
            # 过滤掉常见的控制结构关键字
            valid_functions = [f for f in functions 
                              if f not in self._CONTROL_ELEMENTS]
            testable_elements.update(valid_functions)
            
            # 提取公共类型（以大写字母开头）
            types = self._TYPE_PATTERN.findall(source_code_no_comments)
            for t in types:
                testable_elements.add(f"type_{t}")
            
            # 读取测试文件
            with open(test_file, 'r', encoding='utf-8') as f:
                test_code = f.read()
            
            # 查找测试函数中调用的源元素
            tested_elements = set()
            for element in testable_elements:
                if element.startswith('type_'):
                    # 检查类型是否在测试中被使用
                    type_name = element[5:]  # 移除 'type_' 前缀
                    pattern = r'\b' + re.escape(type_name) + r'\b'
                else:
                    # 检查函数是否在测试中被调用
                    pattern = r'\b' + re.escape(element) + r'\s*\('
                
                if re.search(pattern, test_code):
                    tested_elements.add(element)
            
            # 过滤掉常见的不需要测试的元素
            testable_elements = [e for e in testable_elements if e not in self._IGNORE_ELEMENTS]
            tested_elements = [e for e in tested_elements if e not in self._IGNORE_ELEMENTS]
            
            total = len(testable_elements)
            tested = len(tested_elements)
            coverage = (tested / total * 100) if total > 0 else 0.0
            uncovered = [e for e in testable_elements if e not in tested_elements]
            
            # 计算代码相似度和复杂度
            # similarity = self.calculate_similarity(source_code, test_code)
            cyclomatic_complexity = self.calculate_cyclomatic_complexity(source_code)
            dependency_complexity = self.calculate_dependency_complexity(source_code)

            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='go',
                total_testable_elements=total,
                tested_elements=tested,
                coverage_percentage=coverage,
                uncovered_elements=uncovered,
                cyclomatic_complexity=cyclomatic_complexity,
                dependency_complexity=dependency_complexity
            )
        except Exception:
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='go',
                total_testable_elements=0,
                tested_elements=0,
                coverage_percentage=0.0,
                uncovered_elements=[],
                code_similarity=0.0,
                cyclomatic_complexity=0,
                dependency_complexity=0
            )
