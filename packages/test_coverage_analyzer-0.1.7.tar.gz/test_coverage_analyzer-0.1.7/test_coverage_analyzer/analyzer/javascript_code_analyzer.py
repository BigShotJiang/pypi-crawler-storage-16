import re
import os

from typing import Dict, Any

from .base_code_analyzer import BaseCodeAnalyzer, CoverageResult


class JavascriptCodeAnalyzer(BaseCodeAnalyzer):
    language = 'javaScript'

    def calculate_cyclomatic_complexity(self, source_code: str) -> int:
        """计算JavaScript代码圈复杂度"""
        complexity = 1  # 基础复杂度
        
        # 计算圈复杂度：控制结构
        complexity += len(re.findall(r'\bif\s*\(', source_code))
        complexity += len(re.findall(r'\bfor\s*\(', source_code))
        complexity += len(re.findall(r'\bwhile\s*\(', source_code))
        complexity += len(re.findall(r'\bswitch\s*\(', source_code))
        complexity += len(re.findall(r'\btry\s*\{', source_code))
        complexity += len(re.findall(r'\bcatch\s*\(', source_code))
        
        # 计算布尔运算符
        complexity += len(re.findall(r'&&|\|\|', source_code))
        
        return max(1, complexity)

    def calculate_dependency_complexity(self, source_code: str) -> int:
        """import + 函数参数复杂度"""
        # 计算依赖复杂度：import语句数量
        dependency_complexity += len(re.findall(r'^\s*import\s+.*from', source_code, re.MULTILINE))
        dependency_complexity += len(re.findall(r'^\s*require\s*\(', source_code, re.MULTILINE))
        
        # 计算函数参数数量
        func_declarations = re.findall(r'(?:function\s+\w+|const\s+\w+\s*=|var\s+\w+\s*=|let\s+\w+\s*=)\s*\([^)]*\)', source_code)
        for func in func_declarations:
            param_part = func[func.find('(')+1:func.find(')')]
            if param_part.strip():
                param_count = len([p for p in param_part.split(',') if p.strip()])
                dependency_complexity += param_count

        return max(0, dependency_complexity)

    def analyze(self, source_file: str, test_file: str) -> Dict[str, Any]:
        """分析JavaScript文件的覆盖率"""
        try:
            with open(source_file, 'r', encoding='utf-8') as f:
                source_code = f.read()
            
            # 检查是否是配置文件，如果是则不进行分析
            filename = os.path.basename(source_file)
            if 'config' in filename.lower() or 'settings' in filename.lower():
                # 返回空结果，因为这些文件不需要测试
                return CoverageResult(
                    source_file=source_file,
                    test_file=test_file,
                    language='javascript',
                    total_testable_elements=0,
                    tested_elements=0,
                    coverage_percentage=0.0,
                    uncovered_elements=[],
                    code_similarity=0.0,
                    cyclomatic_complexity=0,
                    dependency_complexity=0
                )
            
            # 提取JavaScript可测试元素（大写字母开头的函数和类）
            testable_elements = []
            
            # 提取函数定义（大写字母开头）
            func_pattern = r'function\s+([A-Z]\w*)\s*\([^)]*\)|const\s+([A-Z]\w*)\s*=\s*[^=].*?=>|var\s+([A-Z]\w*)\s*=\s*[^=].*?=>|let\s+([A-Z]\w*)\s*=\s*[^=].*?=>'
            matches = re.findall(func_pattern, source_code)
            
            # 提取函数名（从元组中获取非空值）
            for match in matches:
                for name in match:
                    if name and not name.startswith('_') and name not in ['if', 'for', 'while', 'switch', 'return', 'function', 'const', 'var', 'let', 'class', 'new', 'this', 'super', 'import', 'export', 'default', 'static', 'async', 'await', 'try', 'catch', 'finally', 'throw', 'throws', 'extends', 'implements', 'instanceof', 'typeof', 'delete', 'in', 'of', 'with', 'do', 'break', 'continue', 'case', 'default', 'true', 'false', 'null', 'undefined', 'console', 'window', 'document', 'Math', 'Date', 'Array', 'Object', 'String', 'Number', 'Boolean', 'Function', 'Symbol', 'Map', 'Set', 'WeakMap', 'WeakSet', 'Promise', 'Generator', 'Error', 'JSON', 'RegExp', 'isNaN', 'isFinite', 'parseInt', 'parseFloat', 'encodeURI', 'encodeURIComponent', 'decodeURI', 'decodeURIComponent', 'eval', 'escape', 'unescape', 'alert', 'prompt', 'confirm', 'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval', 'require', 'module', 'exports', 'arguments', 'length', 'prototype', 'constructor', 'toString', 'valueOf', 'hasOwnProperty', 'isPrototypeOf', 'propertyIsEnumerable', 'toLocaleString']:
                        testable_elements.append(name)
            
            # 提取类定义
            class_pattern = r'class\s+([A-Z]\w+)'
            classes = re.findall(class_pattern, source_code)
            for cls in classes:
                testable_elements.append(f"class_{cls}")
            
            # 读取测试文件
            with open(test_file, 'r', encoding='utf-8') as f:
                test_code = f.read()
            
            # 查找测试函数中调用的源元素
            tested_elements = []
            for element in testable_elements:
                if element.startswith('class_'):
                    # 检查类是否在测试中被使用
                    class_name = element[6:]  # 移除 'class_' 前缀
                    pattern = r'\b' + re.escape(class_name) + r'\b'
                else:
                    # 检查函数是否在测试中被调用
                    pattern = r'\b' + re.escape(element) + r'\s*\('
                
                if re.search(pattern, test_code):
                    tested_elements.append(element)
            
            # 去重并过滤不需要测试的元素
            tested_elements = list(set(tested_elements))
            testable_elements = list(set(testable_elements))
            
            # 过滤掉常见的不需要测试的元素
            ignore_elements = {'main', 'console', 'log', 'error', 'warn', 'info', 'debug', 'time', 'timeEnd', 'assert', 'dir', 'table', 'trace', 'group', 'groupEnd', 'count', 'clear', 'length', 'toString', 'valueOf', 'hasOwnProperty', 'isPrototypeOf', 'propertyIsEnumerable', 'toLocaleString', 'charAt', 'charCodeAt', 'concat', 'indexOf', 'lastIndexOf', 'match', 'replace', 'search', 'slice', 'split', 'substring', 'toLowerCase', 'toUpperCase', 'trim', 'substr', 'valueOf', 'includes', 'startsWith', 'endsWith', 'repeat', 'padStart', 'padEnd', 'trimStart', 'trimEnd', 'trimLeft', 'trimRight', 'matchAll', 'replaceAll', 'at', 'push', 'pop', 'shift', 'unshift', 'splice', 'sort', 'reverse', 'concat', 'join', 'slice', 'indexOf', 'lastIndexOf', 'includes', 'forEach', 'map', 'filter', 'reduce', 'reduceRight', 'every', 'some', 'find', 'findIndex', 'flat', 'flatMap', 'entries', 'keys', 'values', 'copyWithin', 'fill', 'push', 'pop', 'shift', 'unshift', 'splice', 'sort', 'reverse', 'concat', 'join', 'slice', 'indexOf', 'lastIndexOf', 'includes', 'forEach', 'map', 'filter', 'reduce', 'reduceRight', 'every', 'some', 'find', 'findIndex', 'flat', 'flatMap', 'entries', 'keys', 'values', 'copyWithin', 'fill', 'length', 'constructor', 'prototype', 'name', 'arguments', 'caller', 'callee', 'apply', 'bind', 'call', 'toString', 'valueOf', 'toLocaleString', 'hasInstance', 'isConcatSpreadable', 'iterator', 'match', 'replace', 'search', 'species', 'split', 'toPrimitive', 'toStringTag', 'unscopables', 'Math', 'abs', 'acos', 'acosh', 'asin', 'asinh', 'atan', 'atanh', 'atan2', 'ceil', 'cbrt', 'expm1', 'clz32', 'cos', 'cosh', 'exp', 'floor', 'fround', 'hypot', 'imul', 'log', 'log1p', 'log2', 'log10', 'max', 'min', 'pow', 'random', 'round', 'sign', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'trunc', 'E', 'LN10', 'LN2', 'LOG10E', 'LOG2E', 'PI', 'SQRT1_2', 'SQRT2', 'Date', 'now', 'parse', 'UTC', 'getFullYear', 'getMonth', 'getDate', 'getDay', 'getHours', 'getMinutes', 'getSeconds', 'getMilliseconds', 'getTime', 'getYear', 'getUTCFullYear', 'getUTCMonth', 'getUTCDate', 'getUTCDay', 'getUTCHours', 'getUTCMinutes', 'getUTCSeconds', 'getUTCMilliseconds', 'setDate', 'setFullYear', 'setHours', 'setMilliseconds', 'setMinutes', 'setMonth', 'setSeconds', 'setTime', 'setUTCDate', 'setUTCFullYear', 'setUTCHours', 'setUTCMilliseconds', 'setUTCMinutes', 'setUTCMonth', 'setUTCSeconds', 'setYear', 'toDateString', 'toTimeString', 'toLocaleDateString', 'toLocaleTimeString', 'toISOString', 'toJSON', 'toGMTString', 'toUTCString', 'valueOf', 'getTimezoneOffset', 'getYear', 'setYear', 'toSource', 'toString', 'Object', 'assign', 'create', 'defineProperties', 'defineProperty', 'freeze', 'getOwnPropertyDescriptor', 'getOwnPropertyDescriptors', 'getOwnPropertyNames', 'getOwnPropertySymbols', 'getPrototypeOf', 'is', 'isExtensible', 'isFrozen', 'isSealed', 'keys', 'preventExtensions', 'propertyIsEnumerable', 'seal', 'setPrototypeOf', 'values', 'entries', 'fromEntries', 'hasOwnProperty', 'isPrototypeOf', 'propertyIsEnumerable', 'toLocaleString', 'toString', 'valueOf', 'Array', 'isArray', 'from', 'of', 'concat', 'copyWithin', 'entries', 'every', 'fill', 'filter', 'find', 'findIndex', 'flat', 'flatMap', 'forEach', 'includes', 'indexOf', 'join', 'keys', 'lastIndexOf', 'map', 'pop', 'push', 'reduce', 'reduceRight', 'reverse', 'shift', 'slice', 'some', 'sort', 'splice', 'unshift', 'values', 'length', 'Number', 'isFinite', 'isInteger', 'isNaN', 'isSafeInteger', 'parseFloat', 'parseInt', 'toExponential', 'toFixed', 'toPrecision', 'toString', 'valueOf', 'Boolean', 'toString', 'valueOf', 'String', 'fromCharCode', 'fromCodePoint', 'raw', 'charAt', 'charCodeAt', 'codePointAt', 'concat', 'endsWith', 'includes', 'indexOf', 'lastIndexOf', 'localeCompare', 'match', 'matchAll', 'normalize', 'padEnd', 'padStart', 'repeat', 'replace', 'replaceAll', 'search', 'slice', 'split', 'startsWith', 'substring', 'toLowerCase', 'toUpperCase', 'trim', 'trimStart', 'trimEnd', 'trimLeft', 'trimRight', 'toLocaleLowerCase', 'toLocaleUpperCase', 'valueOf', 'toString', 'Function', 'length', 'name', 'arguments', 'caller', 'constructor', 'apply', 'bind', 'call', 'toString', 'Symbol', 'asyncIterator', 'hasInstance', 'isConcatSpreadable', 'iterator', 'match', 'matchAll', 'replace', 'search', 'species', 'split', 'toPrimitive', 'toStringTag', 'unscopables', 'for', 'keyFor', 'Map', 'clear', 'delete', 'entries', 'forEach', 'get', 'has', 'keys', 'set', 'size', 'values', 'Set', 'add', 'clear', 'delete', 'entries', 'forEach', 'has', 'keys', 'size', 'values', 'WeakMap', 'delete', 'get', 'has', 'set', 'WeakSet', 'add', 'delete', 'has', 'Promise', 'all', 'race', 'reject', 'resolve', 'allSettled', 'any', 'Error', 'name', 'message', 'stack', 'JSON', 'parse', 'stringify', 'RegExp', 'exec', 'test', 'compile', 'flags', 'global', 'ignoreCase', 'multiline', 'source', 'sticky', 'unicode', 'lastIndex', 'toString', 'compile', 'exec', 'test', 'isNaN', 'isFinite', 'parseInt', 'parseFloat', 'encodeURI', 'encodeURIComponent', 'decodeURI', 'decodeURIComponent', 'eval', 'escape', 'unescape', 'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval', 'require', 'module', 'exports', 'arguments', 'length', 'prototype', 'constructor', 'toString', 'valueOf', 'hasOwnProperty', 'isPrototypeOf', 'propertyIsEnumerable', 'toLocaleString', 'window', 'document', 'alert', 'prompt', 'confirm'}
            testable_elements = [e for e in testable_elements if e not in ignore_elements]
            tested_elements = [e for e in tested_elements if e not in ignore_elements]
            
            total = len(testable_elements)
            tested = len(tested_elements)
            coverage = (tested / total * 100) if total > 0 else 0.0
            uncovered = [e for e in testable_elements if e not in tested_elements]
            
            # 计算代码相似度和复杂度
            # similarity = self.calculate_similarity(source_code, test_code)
            cyclomatic_complexity, dependency_complexity = self.calculate_complexity(source_code)
            
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='javascript',
                total_testable_elements=total,
                tested_elements=tested,
                coverage_percentage=coverage,
                uncovered_elements=uncovered,
                cyclomatic_complexity=cyclomatic_complexity,
                dependency_complexity=dependency_complexity
            )
        except Exception:
            return CoverageResult(
                source_file=source_file,
                test_file=test_file,
                language='javascript',
                total_testable_elements=0,
                tested_elements=0,
                coverage_percentage=0.0,
                uncovered_elements=[],
                code_similarity=0.0,
                cyclomatic_complexity=0,
                dependency_complexity=0
            )
