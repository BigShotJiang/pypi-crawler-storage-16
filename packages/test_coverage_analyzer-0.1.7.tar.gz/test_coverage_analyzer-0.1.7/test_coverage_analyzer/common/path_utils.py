from pathlib import Path

def normalize_path(path: str, for_storage: bool = False) -> str:
    """
    统一路径分隔符的简化版本

    Args:
        path: 原始路径
        for_storage: 如果为True，返回POSIX风格（适合存储）
                     如果为False，返回当前系统原生格式（适合文件操作）
    
    Returns:
        标准化后的路径
    """
    p = Path(path)
    return p.as_posix() if for_storage else str(p)
