import re
import abc

from typing import Optional


class BaseTestMatcher(abc.ABC):

    def __init__(
        self,
        language: str,
        source_pattern: str,
        test_patterns: list[str],
        language_excludes: list[str]
    ):
        self.language = language

        self.source_pattern = re.compile(source_pattern)
        self.test_patterns = [re.compile(p) for p in test_patterns]
        self.language_excludes = [re.compile(p) for p in language_excludes]

    @abc.abstractmethod
    def build_possible_test_names(self, source_file: str) -> list[str]:
        ...

    @abc.abstractmethod
    def is_matching_test(self, source_name: str, test_filename: str) -> bool:
        ...


class TestMatcherRegistry:
    def __init__(self):
        self.matchers = {}

    def register(self, matcher: BaseTestMatcher):
        self.matchers[matcher.language] = matcher

    def get(self, language: str) -> Optional[BaseTestMatcher]:
        return self.matchers.get(language)

    def all(self):
        return self.matchers.values()
