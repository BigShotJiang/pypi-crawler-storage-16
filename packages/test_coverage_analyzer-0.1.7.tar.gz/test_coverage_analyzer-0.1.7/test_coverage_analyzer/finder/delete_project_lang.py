import os
from collections import Counter
from pathlib import Path
from typing import Optional, Dict

# 可以按需扩展
EXT_TO_LANG: Dict[str, str] = {
    ".py": "python",
    ".pyw": "python",
    ".java": "java",
    ".cpp": "cpp",
    ".cc": "cpp",
    ".cxx": "cpp",
    ".c": "c",
    ".h": "cpp",          
    ".hpp": "cpp",
    ".hh": "cpp",
    ".cs": "csharp",
    ".go": "go",
    ".js": "javascript",
    ".jsx": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".rb": "ruby",
    ".php": "php",
    ".rs": "rust",
    ".kt": "kotlin",
    ".kts": "kotlin",
    ".swift": "swift",
    ".m": "objective-c", 
    ".mm": "objective-c++",
    ".scala": "scala",
}

# 不需要统计的目录（按需扩展）
EXCLUDED_DIRS = {
    ".git", ".idea", ".vscode", "__pycache__", "venv", ".venv",
    "node_modules", "dist", "build", "target", ".mypy_cache",
    ".pytest_cache", ".tox", ".github", ".gitlab",
}

def detect_project_language(root: str) -> Optional[str]:
    """
    粗略判断一个项目的主语言：
    - 按文件后缀统计各语言的源码文件数量
    - 返回数量最多的语言名称，如 'python', 'java', 'cpp' 等
    - 如果没找到任何已知语言文件，返回 None
    """
    root_path = Path(root)
    if not root_path.exists():
        raise FileNotFoundError(f"Path not found: {root}")

    lang_counter = Counter()

    for dirpath, dirnames, filenames in os.walk(root_path):
        # 过滤掉不需要遍历的目录
        dirnames[:] = [d for d in dirnames if d not in EXCLUDED_DIRS]

        for filename in filenames:
            ext = os.path.splitext(filename)[1].lower()
            lang = EXT_TO_LANG.get(ext)
            if not lang:
                continue
            lang_counter[lang] += 1

    if not lang_counter:
        return None

    # 返回出现次数最多的语言
    main_lang, _ = lang_counter.most_common(1)[0]
    return main_lang


if __name__ == "__main__":
    # 示例：检测当前目录的主语言
    project_root = "/opt/tmp/nlp/liangchunfeng/DjangoBlog"
    lang = detect_project_language(project_root)
    if lang is None:
        print("未检测到主语言（没有识别到源码文件）")
    else:
        print(f"项目主要语言：{lang}")
