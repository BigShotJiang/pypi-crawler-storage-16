from pathlib import Path

from .base_test_matcher import BaseTestMatcher


class JavascriptTestMatcher(BaseTestMatcher):
    def __init__(self):
        super().__init__(
            language="javascript",
            source_pattern=r'.*\.(js|jsx)$',
            test_patterns=[
                r'.*\.(test|spec)\.(js|jsx)$',
                r'.*test\.(js|jsx)$',
                r'test_.*\.(js|jsx)$'
            ],
            language_excludes=[
                r'.*package\.json$',
                r'.*package-lock\.json$',
                r'.*yarn\.lock$',
                r'.*webpack\.config\.js$',   # Webpack配置
                r'.*babel\.config\.js$',     # Babel配置
                r'.*jest\.config\.js$',      # Jest配置
                r'.*config\.js$',            # 配置文件
                r'.*config\.json$',
                r'.*settings\.js$',
                r'.*settings\.json$',
                r'.*Dockerfile$',
                r'.*docker-compose\.yml$',
                r'.*docker-compose\.yaml$'
            ]
        )

    def build_possible_test_names(self, source_file: str):
        # JS: *.test.*, *.spec.*, test_*
        source_path = Path(source_file)
        name = Path(source_file).stem
        ext = source_path.suffix
        return [
            f"{name}.test{ext}",
            f"{name}.spec{ext}",
            f"test_{name}{ext}"
        ]

    def is_matching_test(self, source_name: str, test_filename: str) -> bool:
        """检查测试文件名是否可能对应源文件名"""
        stem = Path(test_filename).stem
        if '.test.' in stem or stem.endswith('.test'):
            return stem.replace('.test', '') == source_name
        elif '.spec.' in stem or stem.endswith('.spec'):
            return stem.replace('.spec', '') == source_name

        return stem == f"test_{source_name}"
