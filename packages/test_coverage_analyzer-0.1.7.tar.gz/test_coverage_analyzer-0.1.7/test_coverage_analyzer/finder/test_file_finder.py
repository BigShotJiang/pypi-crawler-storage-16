import os
import re
from pathlib import Path
from typing import Optional, List

from .base_test_matcher import BaseTestMatcher, TestMatcherRegistry
from .python_test_matcher import PythonTestMatcher
from .cpp_test_matcher import CppTestMatcher
from .javascript_test_matcher import JavascriptTestMatcher
from .go_test_matcher import GoTestMatcher
from .java_test_matcher import JavaTestMatcher

from ..models import TestFileMatch
from .delete_project_lang import detect_project_language


class TestFileFinder:

    def __init__(self):
        registry = TestMatcherRegistry()
        registry.register(PythonTestMatcher())
        registry.register(JavaTestMatcher())
        registry.register(GoTestMatcher())
        registry.register(CppTestMatcher())
        registry.register(JavascriptTestMatcher())

        self.registry = registry
        self.common_excludes = [re.compile(p) for p in [
            r'^\..*',    # 以.开头的文件
            r'.*\.md$',  # markdown文件
            r'.*\.txt$',
            r'.*\.log$',
            r'.*\.json$',
            r'.*\.yaml$',
            r'.*\.yml$',
            r'.*\.xml$',
            r'.*\.html$',
            r'.*\.css$',
            r'.*\.png$',
            r'.*\.jpg$',
            r'.*\.jpeg$',
            r'.*\.gif$',
            r'.*\.svg$',
            r'.*\.pdf$',
            r'.*\.zip$',
            r'.*\.tar$',
            r'.*\.gz$',
            r'.*\.rar$',
            r'.*Dockerfile$',
            r'.*docker-compose\.yml$',
            r'.*docker-compose\.yaml$'
        ]]
        self.src_dirnames = ['src']

    def _should_exclude(self, filename: str, matcher: BaseTestMatcher = None) -> bool:
        if any(p.match(filename) for p in self.common_excludes):
            return True

        if matcher and any(p.match(filename) for p in matcher.language_excludes):
            return True

        return False

    def _get_language_matcher(self, file_path: str) -> Optional[BaseTestMatcher]:
        filename = os.path.basename(file_path)
        for matcher in self.registry.all():
            if matcher.source_pattern.match(filename):
                return matcher
        return None

    def _list_all_files(self, path: str) -> List[str]:
        all_files = []

        for root, _, files in os.walk(path):
            for f in files:
                all_files.append(os.path.join(root, f))
        return all_files

    def find_test_files(self, path: str):
        lang = detect_project_language(path)
        matcher = self.registry.get(lang)
        has_custom_find = (
            # 子类真的定义了这个方法（不是父类继承的）
            "find_test_files" in type(matcher).__dict__ and
            callable(type(matcher).find_test_files)
        )
        # TODO: CPP/Python需校验是否有问题
        if has_custom_find:
            return matcher.find_test_files(path, finder=self)

        else:
            # 其他语言的测试文件匹配逻辑
            # 收集所有待测文件
            all_source_files = self._list_all_files(path)
            root_path = Path(path).resolve()
            parts = root_path.parts
            src_index = -1
            for i, part in enumerate(parts):
                if part in self.src_dirnames:
                    src_index = i
                    break
            if src_index > 0:
                project_root = str(Path(*parts[:src_index]))
            else:
                project_root = path
            all_files = self._list_all_files(project_root)

            matches = []
            unmatched = []

            # 默认逻辑（仅作用于没有自定义逻辑的语言）
            for source in all_source_files:
                matcher = self._get_language_matcher(source)
                if not matcher:
                    continue

                filename = os.path.basename(source)
                if self._should_exclude(filename, matcher):
                    continue

                mathched_file = self._find_test_file(source, all_files, matcher)
                if mathched_file.test_file:
                    matches.append(mathched_file)
                else:
                    unmatched.append((source, matcher.language))

            return matches, unmatched

    def _find_test_file(self, source, all_files, matcher):
        """默认匹配逻辑"""

        source_path = Path(source)
        source_name = source_path.stem
        source_dir = source_path.parent

        all_files_set = set(all_files)

        # 1) 同目录查找
        for test_name in matcher.build_possible_test_names(source):
            test_path = str(source_dir / test_name)
            if test_path in all_files_set:
                return TestFileMatch(source, test_path, matcher.language)

        # 2) 全局模糊匹配
        for f in all_files:
            test_filename = os.path.basename(f)
            if any(p.match(test_filename) for p in matcher.test_patterns):
                if matcher.is_matching_test(source_name, test_filename):
                    return TestFileMatch(source, f, matcher.language)

        # 3) 无匹配
        return TestFileMatch(source, None, matcher.language)
