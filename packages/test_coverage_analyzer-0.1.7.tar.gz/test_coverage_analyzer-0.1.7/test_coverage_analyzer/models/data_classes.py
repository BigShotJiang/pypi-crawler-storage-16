from typing import List
from dataclasses import dataclass, field

from ..common import normalize_path


@dataclass
class TestFileMatch:
    """测试文件匹配结果"""
    source_file: str
    test_file: str
    language: str


@dataclass
class CoverageResult:
    """覆盖率结果"""
    source_file: str
    test_file: str = None
    language: str = None
    total_testable_elements: int = 0
    tested_elements: int = 0
    coverage_percentage: float = 0.0
    uncovered_elements: List[str] = field(default_factory=list)
    code_similarity: float = 0.0
    cyclomatic_complexity: int = 0
    dependency_complexity: int = 0

    def __post_init__(self):
        """实例化后自动统一路径分隔符"""
        if self.source_file:
            self.source_file = normalize_path(self.source_file, for_storage=False)

        if self.test_file:
            self.test_file = normalize_path(self.test_file, for_storage=False)


@dataclass
class LanguagePatterns:
    """语言模式配置"""
    source_pattern: str
    test_patterns: List[str]
    exclude_patterns: List[str]
