project_res_template = """
=== 文件级覆盖明细 ===
{file_result}"""

file_res_template = """源文件：{source_file}
测试文件：{test_file}
圈复杂度：{cyclomatic_complexity}
依赖复杂度：{dependency_complexity}
"""

file_res_template_with_uncovered = """源文件：{source_file}
测试文件：{test_file}
测试覆盖率：{coverage_percentage}%
未覆盖元素：{uncovered_elements}
圈复杂度：{cyclomatic_complexity}
依赖复杂度：{dependency_complexity}
"""
