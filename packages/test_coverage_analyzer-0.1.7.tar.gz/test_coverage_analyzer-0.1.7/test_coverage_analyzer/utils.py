from typing import List, Tuple
from dataclasses import asdict
from pathlib import Path

from .models import (
    TestFileMatch,
    CoverageResult
)


def save_results_to_txt(matches: List[TestFileMatch],
                        unmatched: List[Tuple[str, str]],
                        coverage_results: List[CoverageResult],
                        unmatched_results: List[CoverageResult],
                        output_path: str):
    """将匹配结果和覆盖率分析保存到txt文件"""
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("单元测试文件查找及代码分析结果\n")
        f.write("=" * 80 + "\n\n")
        
        if matches:
            f.write(f"找到 {len(matches)} 个源文件与测试文件的配对:\n")
            f.write("-" * 80 + "\n")
            
            for i, match in enumerate(matches, 1):
                f.write(f"{i}. 语言: {match.language}\n")
                f.write(f"   源文件: {match.source_file}\n")
                f.write(f"   测试文件: {match.test_file}\n")
                
                # 查找对应的覆盖率结果
                coverage_result = next((cr for cr in coverage_results if 
                                      cr.source_file == match.source_file and 
                                      cr.test_file == match.test_file), None)
                
                if coverage_result:
                    f.write(f"   可测试元素总数: {coverage_result.total_testable_elements}\n")
                    f.write(f"   已测试元素: {coverage_result.tested_elements}\n")
                    f.write(f"   覆盖率: {coverage_result.coverage_percentage:.2f}%\n")
                    f.write(f"   代码相似度: {coverage_result.code_similarity:.2f}%\n")
                    f.write(f"   圈复杂度: {coverage_result.cyclomatic_complexity}\n")
                    f.write(f"   依赖复杂度: {coverage_result.dependency_complexity}\n")
                    
                    if coverage_result.uncovered_elements:
                        f.write(f"   未覆盖元素: {', '.join(coverage_result.uncovered_elements)}\n")
                    else:
                        f.write("   未覆盖元素: 无\n")
                else:
                    f.write("   覆盖率分析: 无法分析\n")
                
                f.write("\n")
        else:
            f.write("未找到任何源文件与测试文件的配对\n\n")

        if unmatched:
            f.write(f"未找到测试文件的源文件 ({len(unmatched)} 个):\n")
            f.write("-" * 80 + "\n")

            for i, (source_file, lang) in enumerate(unmatched, 1):
                f.write(f"{i}. 语言: {lang}\n")
                f.write(f"   源文件: {source_file}\n")

                # 查找对应的未匹配结果
                unmatched_result = next((ur for ur in unmatched_results if 
                                       ur.source_file == source_file), None)

                if unmatched_result:
                    f.write(f"   圈复杂度: {unmatched_result.cyclomatic_complexity}\n")
                    f.write(f"   依赖复杂度: {unmatched_result.dependency_complexity}\n")
                else:
                    f.write("   复杂度分析: 无法分析\n")

                f.write("\n")
        else:
            f.write("所有源文件都找到了对应的测试文件\n\n")

        # 输出覆盖率统计摘要
        if coverage_results or unmatched_results:
            f.write("复杂度统计摘要:\n")
            f.write("-" * 80 + "\n")

            # 匹配文件的统计
            if coverage_results:
                avg_cyclomatic_matched = sum(cr.cyclomatic_complexity for cr in coverage_results) / len(coverage_results)
                avg_dependency_matched = sum(cr.dependency_complexity for cr in coverage_results) / len(coverage_results)
                f.write(f"已匹配文件 ({len(coverage_results)} 个):\n")
                f.write(f"  平均圈复杂度: {avg_cyclomatic_matched:.2f}\n")
                f.write(f"  平均依赖复杂度: {avg_dependency_matched:.2f}\n")

            # 未匹配文件的统计
            if unmatched_results:
                avg_cyclomatic_unmatched = sum(ur.cyclomatic_complexity for ur in unmatched_results) / len(unmatched_results)
                avg_dependency_unmatched = sum(ur.dependency_complexity for ur in unmatched_results) / len(unmatched_results)
                f.write(f"\n未匹配文件 ({len(unmatched_results)} 个):\n")
                f.write(f"  平均圈复杂度: {avg_cyclomatic_unmatched:.2f}\n")
                f.write(f"  平均依赖复杂度: {avg_dependency_unmatched:.2f}\n")

            # 整体覆盖率统计
            if coverage_results:
                total_elements = sum(cr.total_testable_elements for cr in coverage_results)
                total_tested = sum(cr.tested_elements for cr in coverage_results)
                avg_coverage = sum(cr.coverage_percentage for cr in coverage_results) / len(coverage_results) if coverage_results else 0
                avg_similarity = sum(cr.code_similarity for cr in coverage_results) / len(coverage_results) if coverage_results else 0

                f.write(f"\n覆盖率统计:\n")
                f.write(f"  总可测试元素数: {total_elements}\n")
                f.write(f"  已测试元素数: {total_tested}\n")
                f.write(f"  平均覆盖率: {avg_coverage:.2f}%\n")
                f.write(f"  平均代码相似度: {avg_similarity:.2f}%\n")

            # 按语言统计
            f.write("\n按语言统计:\n")
            lang_stats = {}

            # 处理匹配文件的统计
            for cr in coverage_results:
                lang = cr.language
                if lang not in lang_stats:
                    lang_stats[lang] = {
                        'matched_count': 0, 'unmatched_count': 0,
                        'avg_cyclomatic_matched': 0, 'avg_dependency_matched': 0,
                        'avg_cyclomatic_unmatched': 0, 'avg_dependency_unmatched': 0,
                        'coverage_sum': 0
                    }
                lang_stats[lang]['matched_count'] += 1
                lang_stats[lang]['avg_cyclomatic_matched'] += cr.cyclomatic_complexity
                lang_stats[lang]['avg_dependency_matched'] += cr.dependency_complexity
                lang_stats[lang]['coverage_sum'] += cr.coverage_percentage

            # 处理未匹配文件的统计
            for ur in unmatched_results:
                lang = ur.language
                if lang not in lang_stats:
                    lang_stats[lang] = {
                        'matched_count': 0, 'unmatched_count': 0,
                        'avg_cyclomatic_matched': 0, 'avg_dependency_matched': 0,
                        'avg_cyclomatic_unmatched': 0, 'avg_dependency_unmatched': 0,
                        'coverage_sum': 0
                    }
                lang_stats[lang]['unmatched_count'] += 1
                lang_stats[lang]['avg_cyclomatic_unmatched'] += ur.cyclomatic_complexity
                lang_stats[lang]['avg_dependency_unmatched'] += ur.dependency_complexity

            # 输出各语言统计
            for lang, stats in lang_stats.items():
                f.write(f"\n  {lang}:\n")
                f.write(f"    已匹配文件数: {stats['matched_count']}\n")
                f.write(f"    未匹配文件数: {stats['unmatched_count']}\n")

                if stats['matched_count'] > 0:
                    avg_cyclo_matched = stats['avg_cyclomatic_matched'] / stats['matched_count']
                    avg_dep_matched = stats['avg_dependency_matched'] / stats['matched_count']
                    avg_cov = stats['coverage_sum'] / stats['matched_count']
                    f.write(f"    已匹配文件平均圈复杂度: {avg_cyclo_matched:.2f}\n")
                    f.write(f"    已匹配文件平均依赖复杂度: {avg_dep_matched:.2f}\n")
                    f.write(f"    平均覆盖率: {avg_cov:.2f}%\n")

                if stats['unmatched_count'] > 0:
                    avg_cyclo_unmatched = stats['avg_cyclomatic_unmatched'] / stats['unmatched_count']
                    avg_dep_unmatched = stats['avg_dependency_unmatched'] / stats['unmatched_count']
                    f.write(f"    未匹配文件平均圈复杂度: {avg_cyclo_unmatched:.2f}\n")
                    f.write(f"    未匹配文件平均依赖复杂度: {avg_dep_unmatched:.2f}\n")


def save_results_to_json(matches: List[TestFileMatch], unmatched: List[Tuple[str, str]], 
                         coverage_results: List[CoverageResult], unmatched_results: List[CoverageResult]):
    """将匹配结果和覆盖率分析保存到JSON文件"""
    # 转换数据为字典格式
    matches_dict = [asdict(match) for match in matches]
    coverage_dict = [asdict(cr) for cr in coverage_results]
    unmatched_dict = [asdict(ur) for ur in unmatched_results]

    # 构建最终JSON结构
    result = {
        "matches": matches_dict,
        "unmatched": unmatched_dict,
        "coverage_results": coverage_dict,
        "summary": {
            "total_matches": len(matches),
            "total_unmatched": len(unmatched),
            "total_coverage_analyzed": len(coverage_results),
            "total_unmatched_analyzed": len(unmatched_results),
            # 统计覆盖率摘要
            "coverage_summary": {
                "total_testable_elements": sum(cr["total_testable_elements"] for cr in coverage_dict),
                "total_tested_elements": sum(cr["tested_elements"] for cr in coverage_dict),
                "avg_coverage_percentage": (sum(cr["coverage_percentage"] for cr in coverage_dict) / len(coverage_dict)) if coverage_dict else 0,
                # "avg_code_similarity": (sum(cr["code_similarity"] for cr in coverage_dict) / len(coverage_dict)) if coverage_dict else 0,
                "avg_cyclomatic_complexity_matched": (sum(cr["cyclomatic_complexity"] for cr in coverage_dict) / len(coverage_dict)) if coverage_dict else 0,
                "avg_dependency_complexity_matched": (sum(cr["dependency_complexity"] for cr in coverage_dict) / len(coverage_dict)) if coverage_dict else 0
            },
            # 未匹配文件的复杂度统计
            "unmatched_summary": {
                "avg_cyclomatic_complexity": (sum(ur["cyclomatic_complexity"] for ur in unmatched_dict) / len(unmatched_dict)) if unmatched_dict else 0,
                "avg_dependency_complexity": (sum(ur["dependency_complexity"] for ur in unmatched_dict) / len(unmatched_dict)) if unmatched_dict else 0
            },
            # 按语言统计
            "language_stats": {}
        }
    }

    # 按语言统计详细信息
    lang_stats = {}

    # 处理匹配文件
    for cr in coverage_dict:
        lang = cr["language"]
        if lang not in lang_stats:
            lang_stats[lang] = {
                "matched": {
                    "count": 0,
                    "total_testable": 0,
                    "total_tested": 0,
                    "coverage_sum": 0,
                    "cyclomatic_sum": 0,
                    "dependency_sum": 0,
                    # "similarity_sum": 0
                },
                "unmatched": {
                    "count": 0,
                    "cyclomatic_sum": 0,
                    "dependency_sum": 0
                }
            }
        lang_stats[lang]["matched"]["count"] += 1
        lang_stats[lang]["matched"]["total_testable"] += cr["total_testable_elements"]
        lang_stats[lang]["matched"]["total_tested"] += cr["tested_elements"]
        lang_stats[lang]["matched"]["coverage_sum"] += cr["coverage_percentage"]
        lang_stats[lang]["matched"]["cyclomatic_sum"] += cr["cyclomatic_complexity"]
        lang_stats[lang]["matched"]["dependency_sum"] += cr["dependency_complexity"]
        # lang_stats[lang]["matched"]["similarity_sum"] += cr["code_similarity"]

    # 处理未匹配文件
    for ur in unmatched_dict:
        lang = ur["language"]
        if lang not in lang_stats:
            lang_stats[lang] = {
                "matched": {
                    "count": 0,
                    "total_testable": 0,
                    "total_tested": 0,
                    "coverage_sum": 0,
                    "cyclomatic_sum": 0,
                    "dependency_sum": 0,
                    # "similarity_sum": 0
                },
                "unmatched": {
                    "count": 0,
                    "cyclomatic_sum": 0,
                    "dependency_sum": 0
                }
            }
        lang_stats[lang]["unmatched"]["count"] += 1
        lang_stats[lang]["unmatched"]["cyclomatic_sum"] += ur["cyclomatic_complexity"]
        lang_stats[lang]["unmatched"]["dependency_sum"] += ur["dependency_complexity"]

    # 计算各语言的平均值
    for lang, stats in lang_stats.items():
        result["summary"]["language_stats"][lang] = {
            "total_files": stats["matched"]["count"] + stats["unmatched"]["count"],
            "matched_files": stats["matched"]["count"],
            "unmatched_files": stats["unmatched"]["count"],
            "matched_stats": {
                "avg_coverage": stats["matched"]["coverage_sum"] / stats["matched"]["count"] if stats["matched"]["count"] > 0 else 0,
                "avg_cyclomatic": stats["matched"]["cyclomatic_sum"] / stats["matched"]["count"] if stats["matched"]["count"] > 0 else 0,
                "avg_dependency": stats["matched"]["dependency_sum"] / stats["matched"]["count"] if stats["matched"]["count"] > 0 else 0,
                # "avg_similarity": stats["matched"]["similarity_sum"] / stats["matched"]["count"] if stats["matched"]["count"] > 0 else 0,
                "total_testable_elements": stats["matched"]["total_testable"],
                "coverage_ratio": (stats["matched"]["total_tested"] / stats["matched"]["total_testable"] * 100) if stats["matched"]["total_testable"] > 0 else 0
            },
            "unmatched_stats": {
                "avg_cyclomatic": stats["unmatched"]["cyclomatic_sum"] / stats["unmatched"]["count"] if stats["unmatched"]["count"] > 0 else 0,
                "avg_dependency": stats["unmatched"]["dependency_sum"] / stats["unmatched"]["count"] if stats["unmatched"]["count"] > 0 else 0
            }
        }

    return result


def merge_sort_coverage_data(json_data, limit=None):
    # 提取 coverage_results 和 unmatched
    coverage_results = json_data.get("coverage_results", [])
    unmatched = json_data.get("unmatched", [])

    # 合并 coverage_results 和 normalized_unmatched
    combined = coverage_results + unmatched
    all_results = {}
    # 按覆盖率和圈复杂度升序排序（由易到难）
    min_path_parts_len = min([len(Path(r["source_file"]).resolve().parts) for r in combined])
    for r in combined:
        common_path_parts = Path(r["source_file"]).resolve().parts[:min_path_parts_len]
        common_path = str(Path(*common_path_parts))
        if common_path not in all_results:
            all_results[common_path] = []
        all_results[common_path].append(r)
    for path, results in all_results.items():
        all_results[path] = sorted(
            results,
            key=lambda x: (-x['dependency_complexity'], x["coverage_percentage"], x["cyclomatic_complexity"])
        )
    combined_sorted = sorted(
        all_results.items(),
        key=lambda x: (-sum([r["dependency_complexity"] for r in x[1]]) / len(x[1]),
                       sum([r["coverage_percentage"] for r in x[1]]) / len(x[1]),
                       sum([r["cyclomatic_complexity"] for r in x[1]]) / len(x[1]))
    )
    combined_sorted_ = sum([x[1] for x in combined_sorted], [])
    if limit:
        combined_sorted_ = combined_sorted_[:limit]

    # 返回新结构（不含 matches，只保留处理后的结果）
    result = {
        "coverage_results": combined_sorted_
    }

    return result
