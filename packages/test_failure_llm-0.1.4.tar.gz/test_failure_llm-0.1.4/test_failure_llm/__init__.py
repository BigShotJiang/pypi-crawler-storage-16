from .analyzer import CustomAIAnalyzer
from .model import ScratchMultimodalLLM

__version__ = "0.1.4"
