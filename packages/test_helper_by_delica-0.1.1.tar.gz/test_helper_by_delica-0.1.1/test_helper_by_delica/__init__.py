from test_helper_by_delica.test_helper_funcs import test_bool_func




