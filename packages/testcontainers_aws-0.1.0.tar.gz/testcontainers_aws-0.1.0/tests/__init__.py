"""Test suite for testcontainers-aws."""
