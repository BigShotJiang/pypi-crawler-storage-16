"""
Test Runner - Execute scenarios and generate reports
"""

import logging
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional
import json

from .orchestrator import TestOrchestrator
from .scenario import TestScenario
from .config import EngineConfig

logger = logging.getLogger(__name__)


class TestRunner:
    """
    Execute multiple test scenarios and generate reports.
    
    Features:
    - Run multiple scenarios
    - Generate JUnit XML reports
    - Generate HTML reports
    - Summary statistics
    - Tag-based filtering
    """
    
    def __init__(self, config: Optional[EngineConfig] = None):
        self.config = config or EngineConfig.from_env()
        self.orchestrator = TestOrchestrator(self.config)
        self.scenarios: List[TestScenario] = []
        self.results: List[Dict[str, Any]] = []
    
    def add_scenario(self, scenario: TestScenario) -> "TestRunner":
        """Add a scenario to run"""
        self.scenarios.append(scenario)
        return self
    
    def add_scenarios(self, *scenarios: TestScenario) -> "TestRunner":
        """Add multiple scenarios to run"""
        self.scenarios.extend(scenarios)
        return self
    
    def run(
        self,
        tags: Optional[List[str]] = None,
        fail_fast: bool = False
    ) -> Dict[str, Any]:
        """
        Run all scenarios.
        
        Args:
            tags: Optional tags to filter scenarios
            fail_fast: Stop on first failure
        
        Returns:
            Summary results dictionary
        """
        logger.info("🚀 Starting test run")
        start_time = time.time()
        
        # Filter scenarios by tags
        scenarios_to_run = self._filter_scenarios_by_tags(tags) if tags else self.scenarios
        
        if not scenarios_to_run:
            logger.warning("⚠️ No scenarios to run")
            return self._generate_summary(0)
        
        logger.info(f"📋 Running {len(scenarios_to_run)} scenarios")
        
        # Check services health before running
        health_status = self.orchestrator.check_services_health()
        if not all(health_status.values()):
            logger.error("❌ Some services are unhealthy, aborting test run")
            return self._generate_summary(time.time() - start_time)
        
        # Run scenarios
        for scenario in scenarios_to_run:
            try:
                result = self.orchestrator.execute_scenario(scenario)
                self.results.append(result)
                
                if fail_fast and result["status"] == "failed":
                    logger.warning("⚠️ Fail-fast enabled, stopping test run")
                    break
                
            except Exception as e:
                logger.error(f"❌ Scenario execution error: {e}")
                if fail_fast:
                    break
        
        # Cleanup
        try:
            self.orchestrator.cleanup()
        except Exception as e:
            logger.warning(f"⚠️ Cleanup failed: {e}")
        
        # Generate summary
        duration = time.time() - start_time
        summary = self._generate_summary(duration)
        
        logger.info(f"✅ Test run complete: {summary['passed']}/{summary['total']} passed")
        
        return summary
    
    def _filter_scenarios_by_tags(self, tags: List[str]) -> List[TestScenario]:
        """Filter scenarios by tags"""
        return [
            scenario for scenario in self.scenarios
            if any(tag in scenario.tags for tag in tags)
        ]
    
    def _generate_summary(self, duration: float) -> Dict[str, Any]:
        """Generate test run summary"""
        total = len(self.results)
        passed = sum(1 for r in self.results if r["status"] == "passed")
        failed = sum(1 for r in self.results if r["status"] == "failed")
        
        return {
            "total": total,
            "passed": passed,
            "failed": failed,
            "duration": duration,
            "timestamp": datetime.now().isoformat(),
            "results": self.results
        }
    
    def generate_junit_xml(self, output_path: Path):
        """
        Generate JUnit XML report.
        
        Args:
            output_path: Path to save XML file
        """
        from xml.etree.ElementTree import Element, SubElement, tostring
        from xml.dom import minidom
        
        testsuites = Element("testsuites")
        
        for result in self.results:
            testsuite = SubElement(testsuites, "testsuite")
            testsuite.set("name", result["scenario"])
            testsuite.set("tests", str(len(result["steps"])))
            testsuite.set("failures", str(sum(1 for s in result["steps"] if s["status"] == "failed")))
            testsuite.set("time", f"{result['duration']:.3f}")
            
            for step in result["steps"]:
                testcase = SubElement(testsuite, "testcase")
                testcase.set("name", step["description"])
                testcase.set("classname", result["scenario"])
                testcase.set("time", f"{step['duration']:.3f}")
                
                if step["status"] == "failed":
                    failure = SubElement(testcase, "failure")
                    failure.set("message", step.get("error", "Unknown error"))
                    failure.text = step.get("error", "")
        
        # Pretty print
        xml_str = minidom.parseString(tostring(testsuites)).toprettyxml(indent="  ")
        
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(xml_str, encoding="utf-8")
        
        logger.info(f"📄 JUnit XML report saved: {output_path}")
    
    def generate_html_report(self, output_path: Path):
        """
        Generate HTML report.
        
        Args:
            output_path: Path to save HTML file
        """
        summary = self._generate_summary(0)
        
        html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Report - {summary['timestamp']}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #333;
            border-bottom: 3px solid #4CAF50;
            padding-bottom: 10px;
        }}
        .summary {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }}
        .stat {{
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }}
        .stat.total {{ background: #2196F3; color: white; }}
        .stat.passed {{ background: #4CAF50; color: white; }}
        .stat.failed {{ background: #f44336; color: white; }}
        .stat h2 {{ margin: 0; font-size: 48px; }}
        .stat p {{ margin: 10px 0 0 0; font-size: 18px; }}
        .scenario {{
            margin: 20px 0;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
        }}
        .scenario-header {{
            padding: 15px;
            background: #f9f9f9;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .scenario-header.passed {{ border-left: 5px solid #4CAF50; }}
        .scenario-header.failed {{ border-left: 5px solid #f44336; }}
        .scenario-name {{ font-size: 18px; font-weight: bold; }}
        .scenario-status {{
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: bold;
        }}
        .scenario-status.passed {{ background: #4CAF50; color: white; }}
        .scenario-status.failed {{ background: #f44336; color: white; }}
        .steps {{
            padding: 15px;
        }}
        .step {{
            padding: 10px;
            margin: 5px 0;
            border-radius: 4px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .step.passed {{ background: #e8f5e9; }}
        .step.failed {{ background: #ffebee; }}
        .step-description {{ flex: 1; }}
        .step-duration {{ color: #666; font-size: 14px; margin-left: 10px; }}
        .error {{
            background: #ffebee;
            border: 1px solid #f44336;
            border-radius: 4px;
            padding: 10px;
            margin: 10px 0;
            color: #c62828;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🧪 Test Report</h1>
        <p><strong>Generated:</strong> {summary['timestamp']}</p>
        <p><strong>Duration:</strong> {summary['duration']:.2f}s</p>
        
        <div class="summary">
            <div class="stat total">
                <h2>{summary['total']}</h2>
                <p>Total Scenarios</p>
            </div>
            <div class="stat passed">
                <h2>{summary['passed']}</h2>
                <p>Passed</p>
            </div>
            <div class="stat failed">
                <h2>{summary['failed']}</h2>
                <p>Failed</p>
            </div>
        </div>
        
        <h2>Scenarios</h2>
"""
        
        for result in self.results:
            html += f"""
        <div class="scenario">
            <div class="scenario-header {result['status']}">
                <div class="scenario-name">{result['scenario']}</div>
                <div>
                    <span class="scenario-status {result['status']}">{result['status'].upper()}</span>
                    <span style="margin-left: 10px; color: #666;">{result['duration']:.2f}s</span>
                </div>
            </div>
            <div class="steps">
"""
            
            for step in result["steps"]:
                html += f"""
                <div class="step {step['status']}">
                    <div class="step-description">
                        <strong>{step['type']}:</strong> {step['description']}
                    </div>
                    <div class="step-duration">{step['duration']:.3f}s</div>
                </div>
"""
                if step.get("error"):
                    html += f"""
                <div class="error">
                    <strong>Error:</strong> {step['error']}
                </div>
"""
            
            html += """
            </div>
        </div>
"""
        
        html += """
    </div>
</body>
</html>
"""
        
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(html, encoding="utf-8")
        
        logger.info(f"📄 HTML report saved: {output_path}")
    
    def generate_json_report(self, output_path: Path):
        """
        Generate JSON report.
        
        Args:
            output_path: Path to save JSON file
        """
        summary = self._generate_summary(0)
        
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            json.dumps(summary, indent=2),
            encoding="utf-8"
        )
        
        logger.info(f"📄 JSON report saved: {output_path}")
    
    def close(self):
        """Close orchestrator connections"""
        self.orchestrator.close()
