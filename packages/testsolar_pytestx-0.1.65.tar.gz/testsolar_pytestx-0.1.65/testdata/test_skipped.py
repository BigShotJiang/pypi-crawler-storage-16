import pytest


@pytest.mark.skip(reason="no way of currently testing this")
def test_filtered():
    assert 3 == 4
