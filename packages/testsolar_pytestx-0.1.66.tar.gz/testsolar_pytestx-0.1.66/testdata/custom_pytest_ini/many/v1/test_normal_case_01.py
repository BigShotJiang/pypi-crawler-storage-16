def test_success():
    """
    测试获取答案
    """
    print("this is print sample output")
    assert 4 == 4
