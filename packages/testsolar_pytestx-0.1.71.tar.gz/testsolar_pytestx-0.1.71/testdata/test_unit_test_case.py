class TestInnerCase:

    def test_inner_case(self):
        pass
