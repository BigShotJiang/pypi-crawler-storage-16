import os
import runpod

runpod.api_key = os.getenv("RUNPOD_API_KEY")
