# Tex Jam

A scaffold for LaTeX templates.
