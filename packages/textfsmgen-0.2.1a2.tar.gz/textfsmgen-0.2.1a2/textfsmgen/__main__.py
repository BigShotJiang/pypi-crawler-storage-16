
from textfsmgen.main import Cli

console = Cli()
console.run()
