from ._is_difficult_word import is_difficult_word

__all__ = ["is_difficult_word"]
