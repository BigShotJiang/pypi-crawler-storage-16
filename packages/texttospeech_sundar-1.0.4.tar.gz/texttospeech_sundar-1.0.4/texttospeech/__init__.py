from .tts import tts_sundar, __version__

__all__ = ["tts_sundar", "__version__"]
