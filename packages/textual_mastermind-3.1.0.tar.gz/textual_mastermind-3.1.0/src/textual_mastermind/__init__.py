from textual_mastermind.app import MastermindApp


def main():
    app = MastermindApp()
    app.run()
