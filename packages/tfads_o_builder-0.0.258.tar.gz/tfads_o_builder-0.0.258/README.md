# tfads-o-builder

## Installation
```sh
pip install tfads-o-builder
```

## Getting Started
See tests.
