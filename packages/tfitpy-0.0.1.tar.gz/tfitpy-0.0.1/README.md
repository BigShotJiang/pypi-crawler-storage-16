
# TFit

TFit :  Assessing the combinatorial potential of Transcription Factors in Gene Regulation

# Usage

## Installation 

## Initial setup




# Development setup

## Clone

## Accessing the CLI

`poetry run tfit --help`


