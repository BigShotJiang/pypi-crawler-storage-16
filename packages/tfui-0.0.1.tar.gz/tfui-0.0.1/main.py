def main():
    print("Hello from tfui!")


if __name__ == "__main__":
    main()
