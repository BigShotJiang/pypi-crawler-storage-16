import sys


def main():
    from tgzr.cli.main_cli import tgzr_cli

    sys.exit(tgzr_cli())
