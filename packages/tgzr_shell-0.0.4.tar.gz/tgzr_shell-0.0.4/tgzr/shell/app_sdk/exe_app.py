from types import ModuleType

import os

from ._base_app import _BaseShellApp


class ShellExeApp(_BaseShellApp):
    def __init__(
        self,
        exe_path: str,
        app_name: str,
        run_module: ModuleType | None,
        app_id: str | None = None,
        app_groups: list[str] = [],
    ):
        super().__init__(app_name, run_module, app_id, app_groups)
        self.exe_path = exe_path

    def run_app(self):
        # NOTE:
        # The nice gui app must be runnable with:
        # `python -m <self.run_native_module>`
        # This module can use

        # TODO: find out how we can pass tgzr.cli args to here:
        os.system(self.exe_path)
