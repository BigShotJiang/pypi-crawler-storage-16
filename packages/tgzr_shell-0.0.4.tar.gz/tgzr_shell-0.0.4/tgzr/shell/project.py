from __future__ import annotations
from typing import TYPE_CHECKING

from pathlib import Path

if TYPE_CHECKING:
    from .studio import Studio


class Project:
    def __init__(self, studio: Studio, name: str) -> None:
        self._studio = studio
        self._name = name

    @property
    def name(self) -> str:
        return self._name

    @property
    def venv_path(self) -> Path:
        return self._studio.project_venv_path(self.name)

    def exists(self) -> bool:
        return self.venv_path.exists()
