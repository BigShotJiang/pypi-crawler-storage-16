# tgzr.shell
tgzr workstation runtime

# Create a Shell Application plugin:

You need to:
- create an instance of a `tgzr.shell.app_sdk.ShellApp`
- add an entry point in the group "tgzr.shell.app_plugin" pointing to that app


**Here is a minimalist workging example:**
> 
> **your_package/app.py**:
> ```python
> from . import run_native, run_dev, pages
> from tgzr.shell.app_skd import ShellApp
> 
> app = ShellApp(
>     "app_name",
>     run_native_module=run_native,
>     run_dev_module=run_dev,
>     static_file_path=Path(pages.__file__).parent / "static_files",
> )
> ``` 
>
> **your_package/pages.py**:
> ```python
> from nicegui import ui
> 
> 
> @ui.page("/", title="My App")
> async def main():
>     ui.label("Hello world! 😛")
> ```
> 
> **your_package/run_native.py**:
> ```python
> if __name__ == "__main__":
>    from .app import app
>
>    app.run_app(native=True, reload=False)
> ``` 
>
> **your_package/run_dev.py**:
> ```python
> if __name__ in {"__main__", "__mp_main__"}:
>     from .app import app
>    app.run_app(native=False, reload=True)
> ``` 
>
> **pyproject.toml**:
> ```
> [project.entry-points."tgzr.shell.app_plugin"]
> my_shell_app = "your_package:app"
> ```


