from dataclasses import dataclass

from nicegui import ui

from tgzr.shell.session import Session, get_default_session
from tgzr.shell.studio import Studio
from tgzr.shell.project import Project


@dataclass
class State:
    session: Session | None = None
    studio: Studio | None = None
    project: Project | None = None
    package_name: str | None = None


def render_studio_list(state: State, on_select):
    session = state.session
    if session is None or session.workspace is None:
        ui.label("No active session. Please login.")
        return

    default_studio_name = session.workspace.config.default_studio_name
    studios = session.workspace.get_studios()
    single = len(studios) == 1
    single = len(studios) == 1

    with ui.list().props("bordered separator").classes("w-full"):
        for studio in studios:
            with ui.item(on_click=lambda e, s=studio: on_select(e.sender, s)):
                with ui.item_section().props("avatar"):
                    ui.icon("sym_o_domain")
                with ui.item_section():
                    ui.item_label(studio.name)
                    ui.item_label(str(studio.path)).props("caption")
                if not single and studio.name == default_studio_name:
                    with ui.item_section().props("side"):
                        ui.chip(
                            "default",
                        ).props("dense outline")
    if not studios:
        ui.button(
            "Create your first studio",
            icon="sym_o_celebration",
            on_click=lambda: ui.notify(
                "Oops, not implemented... 😅",
                position="top",
            ),
        ).props("flat")
    else:
        ui.button(
            "Create another studio",
            icon="sym_o_domain_add",
            on_click=lambda: ui.notify(
                "Oops, not implemented... 😅",
                position="top",
            ),
        ).props("flat")


def render_project_list(state: State, on_select):
    studio = state.studio
    if studio is None:
        ui.label("Select a studio...")
        return
    default_project_name = None  # TODO: implement studio.confi.default_project_name
    project_names = studio.get_project_names() + ["FakeProject 1", "AnotherFakeProject"]
    single = len(project_names) == 1
    with ui.list().props("bordered separator").classes("w-full"):
        for project_name in project_names:
            project = studio.get_project(project_name)
            with ui.item(on_click=lambda e, p=project: on_select(e.sender, p)):
                with ui.item_section().props("avatar"):
                    ui.icon("sym_o_domain")
                with ui.item_section():
                    ui.item_label(project.name)
                with ui.item_section().props("side"):
                    if not single and studio.name == default_project_name:
                        ui.chip(
                            "default",
                        ).props("dense outline")
                    if not project.exists():
                        ui.chip("missing", color="negative").props(
                            "dense outline"
                        ).tooltip(f"Folder does not exists: {project.venv_path}")

    if not project_names:
        ui.button(
            "Create a project",
            icon="sym_o_celebration",
            on_click=lambda: ui.notify(
                "Oops, not implemented... 😅",
                position="top",
            ),
        ).props("flat")
    else:
        ui.button(
            "Create another project",
            icon="sym_o_video_camera_back",
            on_click=lambda: ui.notify(
                "Oops, not implemented... 😅",
                position="top",
            ),
        ).props("flat")


def render_package_list(state: State, on_select):
    project = state.project
    if project is None:
        ui.label("Select a project...")
        return

    fake_packages = [
        "tgzr.cli (fake)",
        "tgzr.shell (fake)",
        "tgzr.shell_app.manager_panel (fake)",
        "tgzr.shell_app.launcher (fake)",
        "tgzr.shell_app.harmony_host (fake)",
    ]
    import random

    package_names = project.get_package_names() + random.sample(
        fake_packages, k=random.randint(1, len(fake_packages))
    )
    package_names.sort()
    with ui.list().props("bordered separator").classes("w-full"):
        for package_name in package_names:
            with ui.item(on_click=lambda e, p=project: on_select(e.sender, p)):
                with ui.item_section().props("avatar"):
                    ui.icon("sym_o_deployed_code")
                with ui.item_section():
                    ui.item_label(package_name)
                with ui.item_section().props("side"):
                    with ui.row(align_items="center"):
                        ui.chip(
                            "x.y.z",
                        ).props("dense outline")
                        pypi_url = f"https://pypi.org/project/{package_name.split()[0]}"
                        with ui.link(target=pypi_url, new_tab=True):
                            ui.icon("fa-brands fa-python", size="sm").tooltip(pypi_url)

    ui.button(
        "Install Package",
        icon="sym_o_install_desktop",
        on_click=lambda: ui.notify(
            "Oops, not implemented... 😅",
            position="top",
        ),
    ).props("flat")


def render_plugin_list(state: State, tgzr_only: bool, on_select):
    project = state.project
    package_name = state.package_name
    if project is None:
        return
    if package_name is None:
        ui.label("Select a package...")
        return

    from importlib.metadata import entry_points

    fake_plugins = entry_points()
    plugins = project.get_plugins() + [ep for ep in fake_plugins]
    plugins.sort(key=lambda p: p.group)

    last_group = None
    with ui.list().props("bordered").classes("w-full"):
        for entry_point in plugins:
            if tgzr_only and not entry_point.group.startswith("tgzr"):
                continue
            if entry_point.group != last_group:
                if last_group is not None:
                    ui.separator()
                ui.item_label(entry_point.group).props("header").classes("text-bold")
            last_group = entry_point.group
            with ui.item(on_click=lambda e, ep=entry_point: on_select(e.sender, ep)):
                with ui.item_section().props("avatar"):
                    ui.icon("sym_o_extension")
                with ui.item_section():
                    ui.item_label(entry_point.name)
                    ui.item_label(entry_point.module).props("caption")
                # with ui.item_section().props("side"):
                #     with ui.link(target="https://pypi.org/project/tgzr", new_tab=True):
                #         ui.icon("fa-brands fa-python")


def studios_tab():
    session = get_default_session()
    if session is None or session.workspace is None:
        ui.label("No active session. Please login.")
        return

    state = State(session=session)
    selected_classes = "bg-teal-800"

    def on_studio_select(item: ui.item, studio: Studio):
        for i in item.parent_slot.parent:
            i.classes(remove=selected_classes)
        item.classes(selected_classes)
        state.studio = studio
        state.project = None
        project_list.refresh()
        package_list.refresh()
        plugin_list.refresh()

    @ui.refreshable
    def studio_list():
        render_studio_list(state, on_studio_select)

    def on_project_select(item: ui.item, project: Project):
        for i in item.parent_slot.parent:
            i.classes(remove=selected_classes)
        item.classes(selected_classes)
        state.project = project
        state.package_name = None
        package_list.refresh()
        plugin_list.refresh()

    @ui.refreshable
    def project_list():
        render_project_list(state, on_project_select)

    def on_package_select(item: ui.item, package_name: str):
        for i in item.parent_slot.parent:
            i.classes(remove=selected_classes)
        item.classes(selected_classes)
        state.package_name = package_name
        plugin_list.refresh()

    @ui.refreshable
    def package_list():
        render_package_list(state, on_package_select)

    def on_plugin_select(item: ui.item, plugin):
        print(f"Selected Plugin: [{plugin.group}] {plugin.name}={plugin.value}")
        for i in item.parent_slot.parent:
            i.classes(remove=selected_classes)
        item.classes(selected_classes)

    @ui.refreshable
    def plugin_list():
        render_plugin_list(state, all_plugins_switch.value, on_plugin_select)

    with ui.row(wrap=False).classes("w-full h-full"):
        with ui.column().classes("w-full"):
            with ui.column(align_items="center").classes("w-full"):
                ui.label("Studio").classes("text-xl")
                studio_list()

        with ui.column().classes("w-full"):
            with ui.column(align_items="center").classes("w-full"):
                ui.label("Project").classes("text-xl")
                project_list()

        with ui.column().classes("w-full"):
            with ui.column(align_items="center").classes("w-full"):
                ui.label("Packages").classes("text-xl")
                package_list()

        with ui.column().classes("w-full"):
            with ui.column(align_items="center").classes("w-full"):
                with ui.row(align_items="center").classes("p-0"):
                    ui.label("Plugins").classes("text-xl")
                    all_plugins_switch = (
                        ui.switch(value=True, on_change=plugin_list.refresh)
                        .props("dense")
                        .tooltip("Only list TGZR plugins")
                    )
                plugin_list()
