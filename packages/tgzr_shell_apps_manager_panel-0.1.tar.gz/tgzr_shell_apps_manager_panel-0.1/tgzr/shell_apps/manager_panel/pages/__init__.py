from nicegui import ui

from tgzr.nice.tgzr_visid import TGZRVisId
from tgzr.nice import layout
from tgzr.shell.session import get_default_session

from ..components.studios_tab import studios_tab


def welcome_tab():
    with ui.row(align_items="center").classes("w-full h-full"):
        with ui.column(align_items="center").classes("w-full text-xl"):
            ui.label("Welcome to TGZR Manager")
            ui.label("Select a section")
            ui.label("⬅️ here")


def apps_tab():
    with ui.row(wrap=False).classes("w-full"):
        with ui.column(align_items="center").classes("w-full"):
            ui.label("Apps").classes("text-xl")


def install_tab():
    with ui.column(align_items="center").classes("w-full"):
        ui.button("Create new installation", icon="sym_o_location_on")
        ui.button("Duplicate this installation", icon="sym_o_moved_location")
        ui.button(
            "Remove this installation", icon="sym_o_location_off", color="negative"
        )


def dev_tab():
    with ui.row(wrap=False).classes("w-full"):
        with ui.column(align_items="center").classes("w-full"):
            ui.label("Dev Tools").classes("text-xl")


def render_session_dialog():
    with ui.dialog().props(
        'backdrop-filter="blur(4px) brightness(40%)"'
    ) as session_dialog, ui.card():
        with ui.column(align_items="center").classes("text-md tracking-wide"):
            ui.label("Settings").classes("text-4xl font-thin tracking-[.5em]")
            with ui.column().classes("w-full"):
                verbose_cb = ui.checkbox("Verbose", value=False)
                home_input = ui.input("Home", value="/path/to/session/home")
            with ui.row().classes("w-full"):
                ui.space()
                ui.button("Apply")

    def update_dialog():
        session = get_default_session()
        if session is None:
            verbose_cb.set_value(False)
            home_input.set_value("")
        else:
            verbose_cb.set_value(session.config.verbose)
            home_input.set_value(str(session.home))

    session_dialog.on("show", update_dialog)
    return session_dialog


@ui.page("/", title="TGZR - Manager Panel")
async def main():
    session = get_default_session()

    visid = TGZRVisId()
    default_tab_name = None  # use welcome
    # default_tab_name = "Studios"  # tmp for dev

    tab_renderers = dict(
        studios=studios_tab,
        apps=apps_tab,
        install=install_tab,
        dev=dev_tab,
    )

    def change_tab(e):
        tab_name = e.value
        render_tab_content.refresh(tab_name)

    @ui.refreshable
    def render_tab_content(tab_name: str | None = None):
        renderer = None
        if tab_name is not None:
            renderer = tab_renderers.get(tab_name.lower())
        if renderer is None:
            renderer = welcome_tab

        renderer()

    session_dialog = render_session_dialog()
    if session is None:
        session_dialog.open()

    with layout.fullpage():
        with ui.row(align_items="center").classes("p-5 w-full"):
            visid.logo(classes="w-16")
            with ui.row(align_items="baseline"):
                ui.label("TGZR").classes("text-5xl font-thin tracking-[1em]")
                ui.label("Manager").classes("text-2xl font-thin tracking-[1em]")
            ui.space()
            ui.button(icon="settings", color="W", on_click=session_dialog.open).props(
                "flat size=1em"
            )

        with ui.row(wrap=False).classes("w-full"):
            with ui.tabs(on_change=change_tab, value=default_tab_name).classes(
                "xw-full"
            ).props("vertical") as tabs:
                ui.tab("Studios")
                ui.tab("Apps")
                ui.tab("Install")
                ui.tab("Dev")
            with ui.column().classes("w-full xh-full p-5"):
                render_tab_content(default_tab_name)
