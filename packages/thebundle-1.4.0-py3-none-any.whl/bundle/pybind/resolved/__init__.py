from .pkgconfig import PkgConfigResolved, PkgConfigResult
from .module import ModuleResolved
from .project import ProjectResolved
