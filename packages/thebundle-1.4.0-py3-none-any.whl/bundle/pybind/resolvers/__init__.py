from .pkgconfig import PkgConfigResolver
from .module import ModuleResolver
from .project import ProjectResolver
