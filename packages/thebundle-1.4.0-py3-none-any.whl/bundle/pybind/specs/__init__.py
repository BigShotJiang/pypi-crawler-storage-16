from .pkgconfig import PkgConfigSpec
from .module import ModuleSpec
from .project import ProjectSpec
