from .ble import NAME, STATIC_PATH, router
