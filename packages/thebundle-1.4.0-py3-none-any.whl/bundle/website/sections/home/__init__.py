from .home import NAME, STATIC_PATH, router
