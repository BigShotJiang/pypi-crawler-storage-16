.. _expansion:

Expansion
=========

Utilities that extend Thema’s core, e.g., linking graphs to external analysis tools.

.. toctree::
   :maxdepth: 2

   thema.expansion.realtor
   thema.expansion.utils
