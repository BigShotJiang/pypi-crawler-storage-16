starFilters
===========

.. automodule:: thema.multiverse.universe.utils.starFilters
   :members:
   :undoc-members:
   :show-inheritance:
