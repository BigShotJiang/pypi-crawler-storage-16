starSelectors
=============

.. automodule:: thema.multiverse.universe.utils.starSelectors
   :members:
   :undoc-members:
   :show-inheritance:
