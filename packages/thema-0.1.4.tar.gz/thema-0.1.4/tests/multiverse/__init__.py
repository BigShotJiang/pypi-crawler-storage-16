"""
Test module for Thema's multiverse.
"""
