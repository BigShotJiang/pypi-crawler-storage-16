"""
Shared constants for the thinkagain.core module.
"""

# Special constant for graph termination
END = "__end__"

__all__ = ["END"]
