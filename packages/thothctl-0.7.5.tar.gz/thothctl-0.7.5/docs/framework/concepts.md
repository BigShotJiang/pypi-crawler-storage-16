# Concepts

## Environment

Define the development environment for IaC projects. For example, native OS like Debian/Linux, Windows or DevToContainers.

## Project

IaC project, could be around a use case, blueprint, starter template published in your Catalog or default setup. 

## Space

Logical space to define the Internal Developer Platform context. For example the information about endpoints, credential, and registries.


