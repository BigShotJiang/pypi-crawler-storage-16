"""MCP Service for ThothCTL."""

from .service import run_server, serve

__all__ = ["run_server", "serve"]
