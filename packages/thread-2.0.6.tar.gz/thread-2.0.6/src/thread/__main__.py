# To make CLI accessible with py/python/python3 -m thread ...
from .cli import app

if __name__ == '__main__':
    app(prog_name='thread')
