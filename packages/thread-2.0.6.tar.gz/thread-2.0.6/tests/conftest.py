from thread import Settings

Settings.set_verbosity('quiet')
