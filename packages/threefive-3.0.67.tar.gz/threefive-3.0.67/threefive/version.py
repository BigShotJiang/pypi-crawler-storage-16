"""
threefive.version
from the cli tool run: threefive version
"""

MAJOR = 3
MINOR = 0
MINI = 67

version = f"{MAJOR}.{MINOR}.{MINI}"
