"""
Thulium: Multilingual Handwriting Intelligence for Python.
"""

from thulium.version import __version__

__all__ = ["__version__"]
