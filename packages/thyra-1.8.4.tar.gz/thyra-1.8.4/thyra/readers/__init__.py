# thyra/readers/__init__.py

# Import readers to trigger registration
from . import bruker, imzml_reader  # noqa: F401
