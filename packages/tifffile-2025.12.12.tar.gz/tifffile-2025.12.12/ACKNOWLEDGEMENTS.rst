Acknowledgements
----------------
* Egor Zindy, for lsm_scan_info specifics.
* Wim Lewis for a bug fix and some LSM functions.
* Hadrien Mary for help on reading MicroManager files.
* Christian Kliche for help writing tiled and color-mapped files.
* Grzegorz Bokota, for reporting and fixing OME-XML handling issues.
