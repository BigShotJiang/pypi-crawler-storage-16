"""Things that deal with UDF results that do not depend on the rest of DAGs.

Clients should almost never have to deal with anything in this module or its
submodules.
"""
