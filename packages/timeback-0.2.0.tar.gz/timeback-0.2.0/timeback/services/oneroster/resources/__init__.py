"""Resources service for OneRoster Resources API."""

from timeback.services.oneroster.resources.resources_service import ResourcesService

__all__ = ["ResourcesService"]

