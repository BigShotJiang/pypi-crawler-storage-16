"""Tests for analysis module."""

