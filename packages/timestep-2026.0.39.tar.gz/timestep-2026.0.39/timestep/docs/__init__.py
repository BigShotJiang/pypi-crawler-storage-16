"""Documentation generation utilities."""

