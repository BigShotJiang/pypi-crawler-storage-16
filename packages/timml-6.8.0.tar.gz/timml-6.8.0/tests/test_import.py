def test_import():
    import timml

    print(timml.__version__)


if __name__ == "__main__":
    test_import()
