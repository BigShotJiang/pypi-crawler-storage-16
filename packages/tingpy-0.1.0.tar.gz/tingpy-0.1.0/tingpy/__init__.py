from .client import TingClient as Client
from .pairing import print_pairing_qr as pair_device

__version__ = '0.1.0'
