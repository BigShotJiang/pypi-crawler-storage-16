from core import make_app, run

app = make_app()

# for debugging purposes
if __name__ == '__main__':
    run(app)
