
__name__ = 'tinybird'
__description__ = 'Tinybird Command Line Tool'
__url__ = 'https://www.tinybird.co/docs/forward/commands'
__author__ = 'Tinybird'
__author_email__ = 'support@tinybird.co'
__version__ = '1.0.5'
__revision__ = '60ae688'
