def match_target_modules(name, target_list, mode='contains'):
    if not target_list:
        return False
    normalized_targets = [t.lower() for t in target_list]
    last_component = name.split('.')[-1].lower()
    name_lower = name.lower()
    if mode == 'exact':
        return last_component in normalized_targets
    if mode == 'suffix':
        return any(last_component.endswith(target) for target in normalized_targets)
    return any(target in name_lower for target in normalized_targets)

def get_parent_module(model, module_name):
    parts = module_name.split('.')
    parent = model
    for part in parts[:-1]:
        parent = getattr(parent, part)
    return (parent, parts[-1])