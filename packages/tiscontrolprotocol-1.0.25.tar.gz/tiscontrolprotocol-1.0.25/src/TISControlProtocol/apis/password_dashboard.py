from homeassistant.components.http import HomeAssistantView
from aiohttp import web
import logging
import os

_LOGGER = logging.getLogger(__name__)


class PasswordDashboardEndpoint(HomeAssistantView):
    """Custom Dashboard Endpoint with Cookie and Token Auth."""

    url = "/api/password-dashboard"
    name = "api:password-dashboard"
    requires_auth = False  # We handle auth manually

    def __init__(self, views_path, hass):
        self.views_path = views_path
        # Store hass reference correctly during init
        self.hass = hass

    async def get(self, request):
        user = None

        # 1. Try to authenticate via Cookie (Session)
        session_id = request.cookies.get("auth_session_id")
        if session_id:
            session = await self.hass.auth.async_get_session(session_id)
            if session and session.is_active:
                user = session.user
                _LOGGER.debug(f"Authenticated via Cookie: {user.name}")

        # 2. (Optional Fallback) Try to authenticate via Query Token
        if not user:
            auth_token = request.query.get("token")
            if auth_token:
                # Validate the Long Lived Access Token
                refresh_token = await self.hass.auth.async_validate_access_token(
                    auth_token
                )
                if refresh_token:
                    user = refresh_token.user
                    _LOGGER.debug(f"Authenticated via Token: {user.name}")

        # 3. Validation Logic
        if user is None:
            _LOGGER.warning(
                "Unauthorized access to Password Dashboard (No valid cookie or token). Redirecting."
            )
            # Redirect to root to force login flow
            return web.HTTPFound(location="/")

        if not user.is_admin:
            return web.Response(text="403: Admins only", status=403)

        # 4. Serve the file
        file_path = os.path.join(self.views_path, "password_dashboard", "index.html")

        if not os.path.exists(file_path):
            return web.Response(
                text=f"Error: Dashboard file not found at {file_path}", status=404
            )

        return web.FileResponse(file_path)
