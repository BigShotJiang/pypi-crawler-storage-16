STATIC_URL_PREFIX = "/local/tis_assets"
