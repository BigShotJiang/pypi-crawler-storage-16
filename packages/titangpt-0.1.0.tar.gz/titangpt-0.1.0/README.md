# TitanGPT.ru Python Client

Official Python client for TitanGPT.ru API - OpenAI compatible interface.
