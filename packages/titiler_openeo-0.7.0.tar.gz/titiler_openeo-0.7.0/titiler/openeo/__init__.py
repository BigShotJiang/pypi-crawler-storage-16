"""titiler.openeo"""

__version__ = "0.7.0"
