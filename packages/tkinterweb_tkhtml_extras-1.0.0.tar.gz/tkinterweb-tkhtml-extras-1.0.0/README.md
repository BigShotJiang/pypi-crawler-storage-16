# TkinterWeb-Tkhtml-Extras

**This package provides pre-built binaries of a modified version of the Tkhtml3 widget from https://github.com/Andereoo/TkinterWeb-Tkhtml, which enables the display of styled HTML and CSS code in Tkinter applications.**

This package is an extension to the TkinterWeb-Tkhtml package. 

**See https://github.com/Andereoo/TkinterWeb for more information.**
