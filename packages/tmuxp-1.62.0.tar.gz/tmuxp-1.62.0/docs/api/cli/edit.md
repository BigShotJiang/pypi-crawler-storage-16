# tmuxp edit - `tmuxp.cli.edit`

```{eval-rst}
.. automodule:: tmuxp.cli.edit
   :members:
   :show-inheritance:
   :undoc-members:
```
