# tmuxp freeze - `tmuxp.cli.freeze`

```{eval-rst}
.. automodule:: tmuxp.cli.freeze
   :members:
   :show-inheritance:
   :undoc-members:
```
