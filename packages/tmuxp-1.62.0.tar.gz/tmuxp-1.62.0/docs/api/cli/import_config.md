# tmuxp import - `tmuxp.cli.import_config`

```{eval-rst}
.. automodule:: tmuxp.cli.import_config
   :members:
   :show-inheritance:
   :undoc-members:
```
