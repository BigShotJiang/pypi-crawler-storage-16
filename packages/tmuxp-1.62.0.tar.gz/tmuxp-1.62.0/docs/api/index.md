(api)=

# API Reference

:::{seealso}
See {ref}`libtmux's API <libtmux:api>` and {ref}`Quickstart <libtmux:quickstart>` to see how you can control
tmux via python API calls.
:::

```{toctree}
internals/index
cli/index
workspace/index
exc
log
plugin
shell
util
types
```
