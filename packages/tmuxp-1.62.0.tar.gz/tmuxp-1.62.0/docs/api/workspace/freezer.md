# Freezer - `tmuxp.workspace.freezer`

```{eval-rst}
.. automodule:: tmuxp.workspace.freezer
   :members:
   :show-inheritance:
   :undoc-members:
```
