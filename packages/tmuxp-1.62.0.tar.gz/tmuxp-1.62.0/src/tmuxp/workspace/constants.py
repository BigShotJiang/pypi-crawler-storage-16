"""Constant variables for tmuxp workspace functionality."""

from __future__ import annotations

VALID_WORKSPACE_DIR_FILE_EXTENSIONS = [".yaml", ".yml", ".json"]
