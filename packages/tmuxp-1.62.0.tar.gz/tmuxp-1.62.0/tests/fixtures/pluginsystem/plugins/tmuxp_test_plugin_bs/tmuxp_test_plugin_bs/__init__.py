"""Example tmuxp plugin module that hooks in before_script, if declared."""
