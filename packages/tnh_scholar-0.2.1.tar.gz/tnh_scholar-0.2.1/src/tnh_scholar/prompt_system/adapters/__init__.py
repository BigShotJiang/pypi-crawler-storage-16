"""Prompt catalog adapters."""

