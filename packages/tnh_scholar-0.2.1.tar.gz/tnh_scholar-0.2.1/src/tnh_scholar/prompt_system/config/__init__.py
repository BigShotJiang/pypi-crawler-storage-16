"""Configuration models and policies for the prompt system."""

