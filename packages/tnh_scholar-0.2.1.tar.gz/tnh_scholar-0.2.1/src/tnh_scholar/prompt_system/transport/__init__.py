"""Transport layer for prompt system (git/filesystem/cache)."""

