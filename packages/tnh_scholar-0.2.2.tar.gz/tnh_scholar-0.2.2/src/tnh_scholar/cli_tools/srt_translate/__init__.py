from .srt_translate import main, srt_translate

__all__ = ["main", "srt_translate"]