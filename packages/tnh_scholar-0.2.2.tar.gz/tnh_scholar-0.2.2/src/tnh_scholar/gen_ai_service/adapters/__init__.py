"""Adapters for easier migration from legacy interfaces."""

from .simple_completion import simple_completion

__all__ = ["simple_completion"]
