"""
Prompt system package scaffolding per ADR-PT04.

Modules will provide object-service compliant prompt catalog, rendering, and validation.
"""

