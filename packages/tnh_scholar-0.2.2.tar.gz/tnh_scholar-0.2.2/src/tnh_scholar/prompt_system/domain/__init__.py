"""Domain models and protocols for prompt handling."""

