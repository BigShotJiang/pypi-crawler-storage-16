"""Mappers for translating transport data to domain models and back."""

