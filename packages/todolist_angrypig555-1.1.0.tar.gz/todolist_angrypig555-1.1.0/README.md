# to-do-list
A to do list in textual

Required dependencies: textual, rich, python3
Runs on any OS, tested on ubuntu and windows 11.

# Changelog
v1.1.0
- Added progress bar
- Stable release
