# token-service-tool

`token-service-tool` is a lightweight and developer-friendly Python utility designed to fetch OAuth2 access tokens from Azure Active Directory (Azure AD) using the Client Credentials flow.

This package is ideal for microservices, backend applications, internal tools, automation scripts, or any environment where a secure and minimal method of retrieving access tokens is required—without bringing in heavy Azure SDK dependencies.

---

## Features

- ✔ Minimal API surface — easy to integrate  
- ✔ Stateless: no environment variable dependency  
- ✔ No Azure CLI or SDK required  
- ✔ Pure Python implementation using `requests`  
- ✔ Consistent error handling with clear messages  
- ✔ Fully unit-tested (mocked, no network calls)  
- ✔ Compatible with serverless functions, containers, and CI/CD pipelines  

---

## Installation

Install the latest version from PyPI:

```bash
pip install token-service-tool
```

## Usage

```python
from token_service_tool import TokenService

service = TokenService(
    client_id="YOUR_CLIENT_ID",
    client_secret="YOUR_CLIENT_SECRET",
    tenant_id="YOUR_TENANT_ID",
    scope="https://graph.microsoft.com/.default",
    token_url=f"https://login.microsoftonline.com/YOUR_TENANT_ID/oauth2/v2.0/token",
    grant_type="client_credentials"
)

access_token = service.get_access_token()
print("Access Token:", access_token)
```
