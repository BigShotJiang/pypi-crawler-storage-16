"""DeepSeek model info Provider."""

from tokonomics.model_discovery.deepseek_provider.provider import DeepSeekProvider

__all__ = ["DeepSeekProvider"]
