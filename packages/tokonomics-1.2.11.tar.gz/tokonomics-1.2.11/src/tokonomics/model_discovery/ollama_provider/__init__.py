"""Ollama model info Provider."""

from tokonomics.model_discovery.ollama_provider.provider import OllamaProvider

__all__ = ["OllamaProvider"]
