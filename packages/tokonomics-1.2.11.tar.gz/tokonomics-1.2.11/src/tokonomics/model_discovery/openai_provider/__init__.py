"""OpenAI model info Provider."""

from tokonomics.model_discovery.openai_provider.provider import OpenAIProvider

__all__ = ["OpenAIProvider"]
