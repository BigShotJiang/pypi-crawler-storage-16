"""xAI model info Provider."""

from tokonomics.model_discovery.xai_provider.provider import XAIProvider

__all__ = ["XAIProvider"]
