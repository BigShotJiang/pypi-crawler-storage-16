from .._net._socket import _Socket as SocketType, socket as socket


__all__ = ['SocketType', 'socket']
