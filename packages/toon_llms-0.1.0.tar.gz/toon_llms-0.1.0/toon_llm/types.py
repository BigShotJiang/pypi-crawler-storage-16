class Field:
    def __init__(self, id: int):
        self.id = id

class Int(Field): pass
class Str(Field): pass
class Bool(Field): pass
