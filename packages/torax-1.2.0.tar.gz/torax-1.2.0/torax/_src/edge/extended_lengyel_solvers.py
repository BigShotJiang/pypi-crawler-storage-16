# Copyright 2025 DeepMind Technologies Limited
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Solver methods for the extended Lengyel model."""

import dataclasses
import enum
import functools
import jax
from jax import numpy as jnp
from torax._src import constants
from torax._src.edge import collisional_radiative_models
from torax._src.edge import divertor_sol_1d as divertor_sol_1d_lib
from torax._src.edge import extended_lengyel_defaults
from torax._src.solver import jax_root_finding
# pylint: disable=invalid-name

# Scale factors for physics calculations to avoid numerical issues in fp32.
_LINT_SCALE_FACTOR = 1e30
_DENSITY_SCALE_FACTOR = 1e-20

# _LINT_SCALE_FACTOR * _DENSITY_SCALE_FACTOR**2
_LINT_K_INVERSE_SCALE_FACTOR = 1e-10


class PhysicsOutcome(enum.IntEnum):
  """Status of the _solve_for_qcc or _solve_for_c_z_prefactor calculations.

  Attributes:
    SUCCESS: The calculation was successful.
    C_Z_PREFACTOR_NEGATIVE: c_z_prefactor was negative. This is unphysical and
      indicates that even with no seeded impurities, a value lower than the
      target temperature is reached. To reach the target temperature, we thus
      need added heating with "negative impurities" which is not physically
      possible.
    QCC_SQUARED_NEGATIVE: qcc_squared was negative. This is unphysical and
      indicates that so much power has been lost such that the target
      temperature would be negative according to the formulations used in the
      model. This indicates full detachment.
  """

  SUCCESS = 0
  C_Z_PREFACTOR_NEGATIVE = 1
  Q_CC_SQUARED_NEGATIVE = 2


class FixedPointOutcome(enum.IntEnum):
  """Status of the fixed-point iterative solver.

  Attributes:
    SUCCESS: The solver ran successfully. Currently this is the only possible
      outcome since no convergence criteria (e.g. tolerance) are used.
  """

  SUCCESS = 0


@jax.tree_util.register_dataclass
@dataclasses.dataclass(frozen=True)
class ExtendedLengyelSolverStatus:
  """Container for solver status outputs.

  Attributes:
    physics_outcome: Outcome of the physics helper functions. See
      `extended_lengyel_solvers.PhysicsOutcome` for details.
    numerics_outcome: Outcome of the numerical solver. This will be a
      `jax_root_finding.RootMetadata` for the Newton-Raphson solver, or a
      `extended_lengyel_solvers.FixedPointOutcome` for the fixed-point solver.
  """

  physics_outcome: PhysicsOutcome
  numerics_outcome: jax_root_finding.RootMetadata | FixedPointOutcome


def inverse_mode_fixed_point_solver(
    initial_sol_model: divertor_sol_1d_lib.DivertorSOL1D,
    iterations: int = extended_lengyel_defaults.FIXED_POINT_ITERATIONS,
) -> tuple[divertor_sol_1d_lib.DivertorSOL1D, ExtendedLengyelSolverStatus]:
  """Runs the fixed-point iterative solver for the inverse mode."""

  def body_fun(_, carry):

    current_sol_model, _ = carry

    current_sol_model.state.q_parallel = divertor_sol_1d_lib.calc_q_parallel(
        params=current_sol_model.params,
        T_e_separatrix=current_sol_model.T_e_separatrix,
        alpha_t=current_sol_model.state.alpha_t,
    )

    # Solve for the impurity concentration required to achieve the target
    # temperature for a given q_parallel. This also updates the divertor and
    # separatrix Z_eff values in sol_model, used downstream.
    current_sol_model.state.c_z_prefactor, physics_outcome = (
        _solve_for_c_z_prefactor(sol_model=current_sol_model)
    )

    # Update alpha_t for the next loop iteration.
    current_sol_model.state.alpha_t = divertor_sol_1d_lib.calc_alpha_t(
        params=current_sol_model.params,
        T_e_separatrix=current_sol_model.T_e_separatrix,
        Z_eff_separatrix=current_sol_model.Z_eff_separatrix,
    )

    # Update kappa_e for the next loop iteration.
    current_sol_model.state.kappa_e = divertor_sol_1d_lib.calc_kappa_e(
        current_sol_model.divertor_Z_eff
    )

    # Returning the updated-in-place current_sol_model.
    return current_sol_model, physics_outcome

  final_sol_model, physics_outcome = jax.lax.fori_loop(
      lower=0,
      upper=iterations,
      body_fun=body_fun,
      init_val=(initial_sol_model, PhysicsOutcome.SUCCESS),
  )

  solver_status = ExtendedLengyelSolverStatus(
      physics_outcome=physics_outcome,
      numerics_outcome=FixedPointOutcome.SUCCESS,
  )

  return final_sol_model, solver_status


def forward_mode_fixed_point_solver(
    initial_sol_model: divertor_sol_1d_lib.DivertorSOL1D,
    iterations: int = extended_lengyel_defaults.FIXED_POINT_ITERATIONS,
) -> tuple[divertor_sol_1d_lib.DivertorSOL1D, ExtendedLengyelSolverStatus]:
  """Runs the fixed-point iterative solver for the forward mode."""

  # Relaxation function needed for fixed point iteration in forward mode for
  # stability.
  def _relax(new_value, prev_value, relaxation_factor=0.4):
    return relaxation_factor * new_value + (1 - relaxation_factor) * prev_value

  def body_fun(i, carry):

    current_sol_model, _ = carry

    # Store current values for the next relaxation step
    prev_sol_model = current_sol_model

    # Update q_parallel based on the current separatrix temperature and alpha_t.
    current_sol_model.state.q_parallel = divertor_sol_1d_lib.calc_q_parallel(
        params=current_sol_model.params,
        T_e_separatrix=current_sol_model.T_e_separatrix,
        alpha_t=current_sol_model.state.alpha_t,
    )

    # Calculate heat flux at the cc-interface for fixed impurity concentrations.
    new_q_cc, physics_outcome = _solve_for_qcc(sol_model=current_sol_model)

    # Calculate new target electron temperature with forward two-point model.
    # Clip to small positive value to avoid NaNs.
    current_sol_model.state.T_e_target = jnp.maximum(
        divertor_sol_1d_lib.calc_T_e_target(
            sol_model=current_sol_model,
            parallel_heat_flux_at_cc_interface=new_q_cc,
        ),
        constants.CONSTANTS.eps,
    )

    # Update kappa_e and alpha_t for the next iteration.
    current_sol_model.state.kappa_e = divertor_sol_1d_lib.calc_kappa_e(
        current_sol_model.divertor_Z_eff
    )

    current_sol_model.state.alpha_t = divertor_sol_1d_lib.calc_alpha_t(
        params=current_sol_model.params,
        T_e_separatrix=current_sol_model.T_e_separatrix,
        Z_eff_separatrix=current_sol_model.Z_eff_separatrix,
    )

    # Relaxation step after the first iteration
    current_sol_model = jax.lax.cond(
        i > 0,
        lambda sol_model: dataclasses.replace(
            sol_model,
            state=dataclasses.replace(
                sol_model.state,
                T_e_target=_relax(
                    sol_model.state.T_e_target,
                    prev_sol_model.state.T_e_target,
                ),
                alpha_t=_relax(
                    sol_model.state.alpha_t, prev_sol_model.state.alpha_t
                ),
            ),
        ),
        lambda sol_model: sol_model,
        current_sol_model,
    )

    # Returning the updated-in-place current_sol_model.
    return current_sol_model, physics_outcome

  final_sol_model, physics_outcome = jax.lax.fori_loop(
      lower=0,
      upper=iterations,
      body_fun=body_fun,
      init_val=(initial_sol_model, PhysicsOutcome.SUCCESS),
  )

  solver_status = ExtendedLengyelSolverStatus(
      physics_outcome=physics_outcome,
      numerics_outcome=FixedPointOutcome.SUCCESS,
  )

  return final_sol_model, solver_status


def forward_mode_newton_solver(
    initial_sol_model: divertor_sol_1d_lib.DivertorSOL1D,
    maxiter: int = extended_lengyel_defaults.NEWTON_RAPHSON_ITERATIONS,
    tol: float = extended_lengyel_defaults.NEWTON_RAPHSON_TOL,
) -> tuple[divertor_sol_1d_lib.DivertorSOL1D, ExtendedLengyelSolverStatus]:
  """Runs the Newton-Raphson solver for the forward mode.

  Solves for {q_parallel, alpha_t, kappa_e, T_e_target} given fixed
  impurities.

  Args:
    initial_sol_model: A DivertorSOL1D object containing the initial plasma
      parameters and fixed impurity concentrations.
    maxiter: Maximum number of iterations for the Newton-Raphson solver.
    tol: Tolerance for convergence of the Newton-Raphson solver.

  Returns:
    final_sol_model: The updated DivertorSOL1D object with the solved state
      variables.
    metadata: Metadata from the root-finding process, including convergence
      status and number of iterations.
  """
  # 1. Create initial guess state vector.
  # Uses log space for strictly positive variables and to improve conditioning.
  # alpha_t is left linear since should always remain O(1) and log steps
  # can lead to numerical issues due to exponential amplification. Positivity is
  # enforced via softplus when unpacking.
  x0 = jnp.stack([
      jnp.log(initial_sol_model.state.q_parallel),
      initial_sol_model.state.alpha_t,
      jnp.log(initial_sol_model.state.kappa_e),
      jnp.log(initial_sol_model.state.T_e_target),
  ])

  # 2. Define residual function, closing over params and fixed c_z.
  fixed_cz = initial_sol_model.state.c_z_prefactor
  params = initial_sol_model.params

  residual_fun = functools.partial(
      _forward_residual, params=params, fixed_cz=fixed_cz
  )

  # 3. Run Newton-Raphson.
  x_root, metadata = jax_root_finding.root_newton_raphson(
      residual_fun, x0, maxiter=maxiter, tol=tol, use_jax_custom_root=True
  )

  # 4. Construct final model.
  final_state = divertor_sol_1d_lib.ExtendedLengyelState(
      q_parallel=jnp.exp(x_root[0]),
      alpha_t=jax.nn.softplus(x_root[1]),
      kappa_e=jnp.exp(x_root[2]),
      T_e_target=jnp.exp(x_root[3]),
      c_z_prefactor=fixed_cz,
  )
  final_sol_model = divertor_sol_1d_lib.DivertorSOL1D(
      params=params, state=final_state
  )

  # 5. Re-calculate physics outcome at final state to return the physics_outcome
  _, physics_outcome = _solve_for_qcc(sol_model=final_sol_model)

  solver_status = ExtendedLengyelSolverStatus(
      physics_outcome=physics_outcome,
      numerics_outcome=metadata,
  )

  return final_sol_model, solver_status


def inverse_mode_newton_solver(
    initial_sol_model: divertor_sol_1d_lib.DivertorSOL1D,
    maxiter: int = extended_lengyel_defaults.NEWTON_RAPHSON_ITERATIONS,
    tol: float = extended_lengyel_defaults.NEWTON_RAPHSON_TOL,
) -> tuple[divertor_sol_1d_lib.DivertorSOL1D, ExtendedLengyelSolverStatus]:
  """Runs the Newton-Raphson solver for the inverse mode.

  Solves for {q_parallel, alpha_t, kappa_e, c_z_prefactor} given a fixed
  target electron temperature.

  Args:
    initial_sol_model: A DivertorSOL1D object containing the initial plasma
      parameters and a fixed target electron temperature.
    maxiter: Maximum number of iterations for the Newton-Raphson solver.
    tol: Tolerance for convergence of the Newton-Raphson solver.

  Returns:
    final_sol_model: The updated DivertorSOL1D object with the solved state
      variables.
    metadata: Metadata from the root-finding process, including convergence
      status and number of iterations.
  """
  # 1. Create initial guess state vector.

  # Uses log space for strictly positive variables and to improve conditioning.
  # alpha_t is left linear since should always remain O(1) and log steps
  # can lead to numerical issues due to exponential amplification. Positivity is
  # enforced via softplus when unpacking.

  x0 = jnp.stack([
      jnp.log(initial_sol_model.state.q_parallel),
      initial_sol_model.state.alpha_t,
      jnp.log(initial_sol_model.state.kappa_e),
      initial_sol_model.state.c_z_prefactor,
  ])

  # 2. Define residual function, closing over params and fixed T_t.
  fixed_Tt = initial_sol_model.state.T_e_target
  params = initial_sol_model.params

  residual_fun = functools.partial(
      _inverse_residual, params=params, fixed_Tt=fixed_Tt
  )

  # 3. Run Newton-Raphson.
  x_root, metadata = jax_root_finding.root_newton_raphson(
      residual_fun, x0, maxiter=maxiter, tol=tol, use_jax_custom_root=True
  )

  # 4. Construct final model.
  final_state = divertor_sol_1d_lib.ExtendedLengyelState(
      q_parallel=jnp.exp(x_root[0]),
      alpha_t=jax.nn.softplus(x_root[1]),
      kappa_e=jnp.exp(x_root[2]),
      c_z_prefactor=x_root[3],
      T_e_target=fixed_Tt,
  )

  final_sol_model = divertor_sol_1d_lib.DivertorSOL1D(
      params=params, state=final_state
  )

  # 5. Re-calculate physics outcome at final state to return the physics_outcome
  _, physics_outcome = _solve_for_c_z_prefactor(sol_model=final_sol_model)

  solver_status = ExtendedLengyelSolverStatus(
      physics_outcome=physics_outcome,
      numerics_outcome=metadata,
  )
  return final_sol_model, solver_status


def forward_mode_hybrid_solver(
    initial_sol_model: divertor_sol_1d_lib.DivertorSOL1D,
    fixed_point_iterations: int = extended_lengyel_defaults.HYBRID_FIXED_POINT_ITERATIONS,
    newton_raphson_iterations: int = extended_lengyel_defaults.NEWTON_RAPHSON_ITERATIONS,
    newton_raphson_tol: float = extended_lengyel_defaults.NEWTON_RAPHSON_TOL,
) -> tuple[divertor_sol_1d_lib.DivertorSOL1D, ExtendedLengyelSolverStatus]:
  """Runs the hybrid solver for the forward mode."""
  intermediate_sol_model, _ = forward_mode_fixed_point_solver(
      initial_sol_model=initial_sol_model,
      iterations=fixed_point_iterations,
  )
  final_sol_model, solver_status = forward_mode_newton_solver(
      initial_sol_model=intermediate_sol_model,
      maxiter=newton_raphson_iterations,
      tol=newton_raphson_tol,
  )
  return final_sol_model, solver_status


def inverse_mode_hybrid_solver(
    initial_sol_model: divertor_sol_1d_lib.DivertorSOL1D,
    fixed_point_iterations: int = extended_lengyel_defaults.HYBRID_FIXED_POINT_ITERATIONS,
    newton_raphson_iterations: int = extended_lengyel_defaults.NEWTON_RAPHSON_ITERATIONS,
    newton_raphson_tol: float = extended_lengyel_defaults.NEWTON_RAPHSON_TOL,
) -> tuple[divertor_sol_1d_lib.DivertorSOL1D, ExtendedLengyelSolverStatus]:
  """Runs the hybrid solver for the inverse mode."""
  intermediate_sol_model, _ = inverse_mode_fixed_point_solver(
      initial_sol_model=initial_sol_model,
      iterations=fixed_point_iterations,
  )
  final_sol_model, solver_status = inverse_mode_newton_solver(
      initial_sol_model=intermediate_sol_model,
      maxiter=newton_raphson_iterations,
      tol=newton_raphson_tol,
  )
  return final_sol_model, solver_status


def _forward_residual(
    x_vec: jax.Array,
    params: divertor_sol_1d_lib.ExtendedLengyelParameters,
    fixed_cz: jax.Array,
) -> jax.Array:
  """Calculates the residual vector for Forward Mode F(x) = 0."""
  # 1. Construct physical state from vector guess (uses exp/softplus).
  current_state = divertor_sol_1d_lib.ExtendedLengyelState(
      q_parallel=jnp.exp(x_vec[0]),
      alpha_t=jax.nn.softplus(x_vec[1]),
      kappa_e=jnp.exp(x_vec[2]),
      T_e_target=jnp.exp(x_vec[3]),
      c_z_prefactor=fixed_cz,
  )
  temp_model = divertor_sol_1d_lib.DivertorSOL1D(
      params=params, state=current_state
  )

  # 2. Calculate next guess of state variables.

  # a) q_parallel
  qp_calc = divertor_sol_1d_lib.calc_q_parallel(
      params=params,
      T_e_separatrix=temp_model.T_e_separatrix,
      alpha_t=current_state.alpha_t,
  )

  # b) alpha_t
  at_calc = divertor_sol_1d_lib.calc_alpha_t(
      params=temp_model.params,
      T_e_separatrix=temp_model.T_e_separatrix,
      Z_eff_separatrix=temp_model.Z_eff_separatrix,
  )

  # c) kappa_e
  ke_calc = divertor_sol_1d_lib.calc_kappa_e(temp_model.divertor_Z_eff)

  # d) T_t
  q_cc_calc, _ = _solve_for_qcc(sol_model=temp_model)
  Tt_calc = divertor_sol_1d_lib.calc_T_e_target(
      sol_model=temp_model,
      parallel_heat_flux_at_cc_interface=q_cc_calc,
  )

  # 3. Compute residuals in solver space for conditioning.
  # Enforce positivity for numerical stability.
  qp_calc_safe = jnp.maximum(qp_calc, constants.CONSTANTS.eps)
  ke_calc_safe = jnp.maximum(ke_calc, constants.CONSTANTS.eps)
  Tt_calc_safe = jnp.maximum(Tt_calc, constants.CONSTANTS.eps)
  at_calc_safe = jnp.maximum(at_calc, constants.CONSTANTS.eps)

  r_qp = jnp.log(qp_calc_safe) - x_vec[0]
  r_at = at_calc_safe - current_state.alpha_t
  r_ke = jnp.log(ke_calc_safe) - x_vec[2]
  r_Tt = jnp.log(Tt_calc_safe) - x_vec[3]

  return jnp.stack([r_qp, r_at, r_ke, r_Tt])


def _inverse_residual(
    x_vec: jax.Array,
    params: divertor_sol_1d_lib.ExtendedLengyelParameters,
    fixed_Tt: jax.Array,
) -> jax.Array:
  """Calculates the residual vector for Inverse Mode F(x) = 0."""
  # 1. Construct physical state from vector guess.
  current_state = divertor_sol_1d_lib.ExtendedLengyelState(
      q_parallel=jnp.exp(x_vec[0]),
      alpha_t=jax.nn.softplus(x_vec[1]),
      kappa_e=jnp.exp(x_vec[2]),
      c_z_prefactor=x_vec[3],
      T_e_target=fixed_Tt,
  )

  temp_model = divertor_sol_1d_lib.DivertorSOL1D(
      params=params, state=current_state
  )

  # 2. Calculate next guess of state variables.

  # a) q_parallel
  qp_calc = divertor_sol_1d_lib.calc_q_parallel(
      params=params,
      T_e_separatrix=temp_model.T_e_separatrix,
      alpha_t=current_state.alpha_t,
  )

  # b) alpha_t
  at_calc = divertor_sol_1d_lib.calc_alpha_t(
      params=temp_model.params,
      T_e_separatrix=temp_model.T_e_separatrix,
      Z_eff_separatrix=temp_model.Z_eff_separatrix,
  )

  # c) kappa_e
  ke_calc = divertor_sol_1d_lib.calc_kappa_e(temp_model.divertor_Z_eff)

  # d) c_z_prefactor
  cz_calc, _ = _solve_for_c_z_prefactor(sol_model=temp_model)

  # 3. Compute residuals in solver space for conditioning.
  qp_calc_safe = jnp.maximum(qp_calc, constants.CONSTANTS.eps)
  ke_calc_safe = jnp.maximum(ke_calc, constants.CONSTANTS.eps)
  at_calc_safe = jnp.maximum(at_calc, constants.CONSTANTS.eps)

  r_qp = jnp.log(qp_calc_safe) - x_vec[0]
  r_at = at_calc_safe - current_state.alpha_t
  r_ke = jnp.log(ke_calc_safe) - x_vec[2]
  r_cz = cz_calc - current_state.c_z_prefactor

  return jnp.stack([r_qp, r_at, r_ke, r_cz])


def _solve_for_c_z_prefactor(
    sol_model: divertor_sol_1d_lib.DivertorSOL1D,
) -> tuple[jax.Array, PhysicsOutcome]:
  """Solves the extended Lengyel model for the required impurity concentration.

  This function implements the extended Lengyel model in inverse mode,
  calculating the seeded impurity concentration (`c_z`) needed to achieve the
  an input target temperature consistent with a given set of plasma parameters.

  See Section 5 of T. Body et al 2025 Nucl. Fusion 65 086002 for the derivation.
  https://doi.org/10.1088/1741-4326/ade4d9

  Args:
    sol_model: A DivertorSOL1D object containing the plasma parameters.

  Returns:
      c_z_prefactor: The scaling factor for the seeded impurity concentrations.
        To be multiplied by seed_impurity_weights to get each seeded impurity
        concentration. Clipped to zero if the solution required it
        to be negative, which is unphysical.
      status: A PhysicsOutcome enum indicating the outcome of the calculation.
  """
  # Temperatures must be in keV for the L_INT calculation.
  cc_temp_keV = sol_model.electron_temp_at_cc_interface / 1000.0
  div_temp_keV = sol_model.divertor_entrance_electron_temp / 1000.0
  sep_temp_keV = sol_model.T_e_separatrix / 1000.0

  # Calculate integrated radiation terms (L_INT) for seeded impurities.
  # See Eq. 34 in Body et al. 2025.
  Ls_cc_div = (
      collisional_radiative_models.calculate_weighted_L_INT(
          sol_model.params.seed_impurity_weights,
          start_temp=cc_temp_keV,
          stop_temp=div_temp_keV,
          ne_tau=sol_model.params.ne_tau,
      )
      * _LINT_SCALE_FACTOR
  )
  Ls_cc_u = (
      collisional_radiative_models.calculate_weighted_L_INT(
          sol_model.params.seed_impurity_weights,
          start_temp=cc_temp_keV,
          stop_temp=sep_temp_keV,
          ne_tau=sol_model.params.ne_tau,
      )
      * _LINT_SCALE_FACTOR
  )
  Ls_div_u = Ls_cc_u - Ls_cc_div

  # Calculate integrated radiation terms for fixed background impurities.
  Lf_cc_div = (
      collisional_radiative_models.calculate_weighted_L_INT(
          sol_model.params.fixed_impurity_concentrations,
          start_temp=cc_temp_keV,
          stop_temp=div_temp_keV,
          ne_tau=sol_model.params.ne_tau,
      )
      * _LINT_SCALE_FACTOR
  )
  Lf_cc_u = (
      collisional_radiative_models.calculate_weighted_L_INT(
          sol_model.params.fixed_impurity_concentrations,
          start_temp=cc_temp_keV,
          stop_temp=sep_temp_keV,
          ne_tau=sol_model.params.ne_tau,
      )
      * _LINT_SCALE_FACTOR
  )
  Lf_div_u = Lf_cc_u - Lf_cc_div

  # Define shorthand variables for clarity, matching the paper's notation.
  qu = sol_model.state.q_parallel
  qcc = sol_model.parallel_heat_flux_at_cc_interface
  b = sol_model.params.divertor_broadening_factor
  # `k` is a lumped parameter from the Lengyel model derivation.
  # See Eq. 33 in Body et al. 2025.
  # Need log to avoid overflow in fp32 when jitted.
  log_k = (
      jnp.log(2.0)
      + jnp.log(sol_model.state.kappa_e)
      + 2.0
      * jnp.log(
          sol_model.params.separatrix_electron_density * _DENSITY_SCALE_FACTOR
      )
      + 2.0 * jnp.log(sol_model.T_e_separatrix)
  )

  k = jnp.exp(log_k)

  # Calculate the squared parallel heat flux at the divertor entrance.
  # This formula is derived by combining the Lengyel equations for the region
  # above and below the divertor entrance. See Eq. 40 in Body et al. 2025.
  q_div_squared = (
      Ls_div_u
      / _LINT_SCALE_FACTOR
      * (qcc**2 + k * Lf_cc_div / _LINT_K_INVERSE_SCALE_FACTOR)
      + (Ls_cc_div / _LINT_SCALE_FACTOR)
      * (qu**2 - k * Lf_div_u / _LINT_K_INVERSE_SCALE_FACTOR)
  ) / (Ls_div_u / _LINT_SCALE_FACTOR / b**2 + Ls_cc_div / _LINT_SCALE_FACTOR)

  # Calculate the required seeded impurity concentration `c_z`.
  # See Eq. 42 in Body et al. 2025.
  c_z_prefactor = (
      (qu**2 + (1.0 / b**2 - 1.0) * q_div_squared - qcc**2)
      / (k * Ls_cc_u / _LINT_K_INVERSE_SCALE_FACTOR)
  ) - (Lf_cc_u / Ls_cc_u)

  # Check for unphysical result.
  status = jnp.where(
      c_z_prefactor < 0.0,
      PhysicsOutcome.C_Z_PREFACTOR_NEGATIVE,
      PhysicsOutcome.SUCCESS,
  )

  # c_z is related to impurity density which physically cannot be negative.
  # The natural floor of c_z_prefactor is zero.
  c_z_prefactor = jnp.where(
      status == PhysicsOutcome.SUCCESS, c_z_prefactor, 0.0
  )

  return c_z_prefactor, status


def _solve_for_qcc(
    sol_model: divertor_sol_1d_lib.DivertorSOL1D,
) -> tuple[jax.Array, PhysicsOutcome]:
  """Calculates the parallel heat flux at the cc-interface for fixed impurities.

  This function is part of the extended Lengyel model in forward mode,
  calculating the parallel heat flux at the convective-conductive interface
  (`q_cc`) which is needed to calculate the target temperature consistent with
  a given set of plasma parameters.

  See Section 5 of T. Body et al 2025 Nucl. Fusion 65 086002 for the derivation.
  This is equation 38 rearranged for q_cc, and using equation 39 to calculate
  q_div.
  https://doi.org/10.1088/1741-4326/ade4d9

  Args:
    sol_model: A DivertorSOL1D object containing the plasma parameters.

  Returns:
      q_cc: The parallel heat flux at the cc-interface
      status: A PhysicsOutcome enum indicating the outcome of the calculation.
  """
  # Temperatures must be in keV for the L_INT calculation.
  cc_temp_keV = sol_model.electron_temp_at_cc_interface / 1000.0
  div_temp_keV = sol_model.divertor_entrance_electron_temp / 1000.0
  sep_temp_keV = sol_model.T_e_separatrix / 1000.0

  # Calculate integrated radiation terms for fixed impurities.
  # See Eq. 34 in Body et al. 2025.
  Lint_cc_div = (
      collisional_radiative_models.calculate_weighted_L_INT(
          sol_model.params.fixed_impurity_concentrations,
          start_temp=cc_temp_keV,
          stop_temp=div_temp_keV,
          ne_tau=sol_model.params.ne_tau,
      )
      * _LINT_SCALE_FACTOR
  )
  Lint_cc_u = (
      collisional_radiative_models.calculate_weighted_L_INT(
          sol_model.params.fixed_impurity_concentrations,
          start_temp=cc_temp_keV,
          stop_temp=sep_temp_keV,
          ne_tau=sol_model.params.ne_tau,
      )
      * _LINT_SCALE_FACTOR
  )
  Lint_div_u = Lint_cc_u - Lint_cc_div

  # Define shorthand variables for clarity, matching the paper's notation.
  qu = sol_model.state.q_parallel
  b = sol_model.params.divertor_broadening_factor
  # `k` is a lumped parameter from the Lengyel model derivation.
  # See Eq. 33 in Body et al. 2025.
  # Need log to avoid overflow in fp32 when jitted.
  log_k = (
      jnp.log(2.0)
      + jnp.log(sol_model.state.kappa_e)
      + 2.0
      * jnp.log(
          sol_model.params.separatrix_electron_density * _DENSITY_SCALE_FACTOR
      )
      + 2.0 * jnp.log(sol_model.T_e_separatrix)
  )

  k = jnp.exp(log_k)

  qcc_squared = (
      qu**2 / b**2
      - k * (Lint_div_u / b**2 + Lint_cc_div) / _LINT_K_INVERSE_SCALE_FACTOR
  )

  # Check for unphysical result.
  status = jnp.where(
      qcc_squared <= constants.CONSTANTS.eps,
      PhysicsOutcome.Q_CC_SQUARED_NEGATIVE,
      PhysicsOutcome.SUCCESS,
  )

  # Clip qcc to a low but positive value to avoid NaNs. Still corresponds to
  # near total detachment.
  qcc = jnp.where(
      status == PhysicsOutcome.SUCCESS,
      jnp.sqrt(qcc_squared),
      constants.CONSTANTS.eps,
  )

  return qcc, status
