from typing import *
globals()['overload'] = lambda function: function