Contributor Guide
=================

This document provides guidelines for contributors, including setup instructions, development workflow, and contribution rules.

.. include:: ../../../CONTRIBUTING.rst
   :start-line: 3
