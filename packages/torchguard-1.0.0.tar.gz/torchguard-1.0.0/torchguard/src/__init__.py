"""
TorchGuard source package.

All implementation code lives here. The top-level torchguard/__init__.py
re-exports the public API.
"""
