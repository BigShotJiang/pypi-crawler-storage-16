# 🚀 Contributing to TotalSegmentator

TotalSegmentator is an open source project and we are happy to accept contributions. There are many ways to contribute, from writing tutorials or blog posts, improving the documentation, submitting bug reports and feature requests or writing code which can be incorporated into TotalSegmentator itself.
