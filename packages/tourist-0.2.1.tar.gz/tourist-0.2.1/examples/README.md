### examples

Various scripts demonstrating how Tourist can help build various LLM or automated scraping apps.

![Tourist as a LangChain Tool](../docs/langchain-tools-20240804.gif)