from .routes import info  # noqa
