from .routes import tour  # noqa
