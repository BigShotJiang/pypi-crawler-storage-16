from setuptools import setup, find_packages

setup(
    name="tpu-commons",
    version="0.0.1",
    packages=find_packages(),
    author="sjnscythe",
    author_email="scytheabhi97@gmail.com",
    description="A poc for google",
    python_requires='>=3.6',
)
