#!/usr/bin/env python
#  -*- coding: utf-8 -*-
__author__ = 'mayanqiong'

"""
定义常量
"""

FUTURE_EXCHANGES = ["CFFEX", "SHFE", "DCE", "CZCE", "INE", "GFEX"]
STOCK_EXCHANGES = ["SSE", "SZSE"]
SPOT_EXCHANGES = ["SSWE"]
KQ_EXCHANGES = ["KQ"]
KQD_EXCHANGES = ["KQD"]
