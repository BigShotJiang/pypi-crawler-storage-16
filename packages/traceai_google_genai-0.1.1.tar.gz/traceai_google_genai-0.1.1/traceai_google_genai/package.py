_instruments = ("google-genai",)
_supports_metrics = False
