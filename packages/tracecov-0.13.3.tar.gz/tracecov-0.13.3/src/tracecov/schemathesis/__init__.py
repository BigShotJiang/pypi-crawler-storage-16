def install() -> None:
    from . import handler, options  # noqa: F401
