---
sdk: gradio
sdk_version: {GRADIO_VERSION}
app_file: ui/main.py
tags:
 - trackio
hf_oauth: true
hf_oauth_scopes:
 - write-repos
---