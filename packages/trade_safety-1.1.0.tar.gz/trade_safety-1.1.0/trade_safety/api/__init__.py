"""FastAPI router for Trade Safety."""

from trade_safety.api.router import create_trade_safety_router

__all__ = ["create_trade_safety_router"]
