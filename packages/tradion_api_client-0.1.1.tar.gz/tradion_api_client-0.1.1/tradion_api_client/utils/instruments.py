"""
Helper module for instrument token management
You need to get the correct instrument tokens from RMONEY API or documentation
"""

# Common NSE instruments (Example tokens - verify with your broker)
INSTRUMENTS = {
    # Indices
    "NIFTY": "NSE|26000",
    "BANKNIFTY": "NSE|26009",
    "FINNIFTY": "NSE|26037",
    
    # Stocks (Examples - these tokens may not be accurate)
    "RELIANCE": "NSE|2885",
    "TCS": "NSE|11536",
    "INFY": "NSE|1594",
    "HDFC": "NSE|1333",
    "ICICIBANK": "NSE|4963",
    
    # Add your instruments here
}

def get_token(symbol: str) -> str:
    """Get instrument token by symbol name"""
    return INSTRUMENTS.get(symbol.upper())

def get_symbol(token: str) -> str:
    """Get symbol name by token"""
    for symbol, tok in INSTRUMENTS.items():
        if tok == token:
            return symbol
    return token

# You can fetch the complete instrument list from RMONEY API
# Typically brokers provide a CSV/JSON file with all instrument tokens
