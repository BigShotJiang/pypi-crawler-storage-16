# Introduction

This package is written to be used as a tradion API Client in Python.
With the correct API credentials, User can access tradion interactive & market data.

## Installation
install
```bash
uv add aiohttp == 3.11.11

```bash
uv add tradion_api_client
```



## Usage

```python
from tradion_api_client import InteractiveClient, MarketDataClient

# Your code here
```
