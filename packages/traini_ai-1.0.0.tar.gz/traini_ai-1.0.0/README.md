# 🐕 Traini AI SDK

> Dog emotion analysis and human-dog communication platform

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## ✨ Features

Traini AI SDK provides four main capabilities:

1. 🖼️ **Image Analysis** - Analyze dog emotions from images
2. 🎥 **Video Analysis** - Process dog videos to detect emotional states over time
3. 👤➡️🐕 **Human-to-Dog Translation** - Convert human speech into dog-optimized audio
4. 🐕➡️👤 **Dog-to-Human Translation** - Interpret dog vocalizations into human language

---

## 🚀 Installation

```bash
pip install traini-ai
```

---

## 💻 Quick Test

```python
from traini_ai import TrainiClient

# Create client
client = TrainiClient()

# Test image analysis
result = client.analyze_image("dog.jpg", return_confidence=True)
print(f"Emotion: {result['emotion']}")
print(f"Confidence: {result['confidence']:.2%}")

# Test video analysis
result = client.analyze_video("video.mp4", return_timeline=True)
print(f"Dominant emotion: {result['dominant_emotion']}")

# Test human-to-dog translation
result = client.translate_human_to_dog("speech.wav", tone='friendly')
print(f"Translation: {result['text']}")

# Test dog-to-human translation
result = client.translate_dog_to_human("bark.wav", include_sound_type=True)
print(f"Sound type: {result['sound_type']}")
print(f"Meaning: {result['text']}")
```

---

## 📋 Output Formats

### Image Analysis Output

```python
{
    'text': 'The dog appears happy.',
    'emotion': 'happy',           # Requires return_confidence=True
    'confidence': 0.87,            # Requires return_confidence=True
    'audio': b'...'                # Audio narration bytes
}
```

### Video Analysis Output

```python
{
    'text': 'Throughout the video, the dog appears mostly happy.',
    'dominant_emotion': 'happy',
    'timeline': [                  # Requires return_timeline=True
        {
            'timestamp': 0.5,
            'emotion': 'happy',
            'confidence': 0.85
        },
        {
            'timestamp': 1.0,
            'emotion': 'playful',
            'confidence': 0.78
        }
    ],
    'audio': b'...'                # Audio narration bytes
}
```

### Human-to-Dog Translation Output

```python
{
    'text': 'Translated to dog-friendly frequencies with friendly tone.',
    'transcription': 'Good boy',   # Requires include_transcription=True
    'interpretation': 'Positive reinforcement command',
    'audio': b'...'                # Dog-optimized audio bytes
}
```

### Dog-to-Human Translation Output

```python
{
    'text': 'The dog is warning about something in their territory.',
    'sound_type': 'bark_alert',    # Requires include_sound_type=True
    'emotion': 'alert',
    'context': 'territorial',
    'audio': b'...'                # Audio narration bytes
}
```

**Supported Sound Types:**
- `bark_alert` - Warning or alert bark
- `bark_play` - Playful bark
- `bark_excitement` - Excited bark
- `whine` - Whining sound
- `growl` - Growling sound
- `howl` - Howling sound

---

## 📖 License

MIT License - see the LICENSE file for details.

---

Made with ❤️ for dogs and their humans
