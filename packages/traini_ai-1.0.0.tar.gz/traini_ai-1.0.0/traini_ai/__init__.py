"""
Traini AI SDK
A comprehensive SDK for dog emotion analysis and human-dog communication
"""

__version__ = "1.0.0"
__author__ = "Traini AI Team"

from .client import TrainiClient
from .modules.image_analyzer import ImageAnalyzer
from .modules.video_analyzer import VideoAnalyzer
from .modules.human_to_dog import HumanToDogTranslator
from .modules.dog_to_human import DogToHumanTranslator

# 向后兼容的别名
DogEmotionClient = TrainiClient

__all__ = [
    "TrainiClient",
    "DogEmotionClient",  # 向后兼容
    "ImageAnalyzer",
    "VideoAnalyzer",
    "HumanToDogTranslator",
    "DogToHumanTranslator",
]
