# Segmentation guide

```{toctree}
:maxdepth: 3

editor
effects
effect_pipeline
```
