from __future__ import annotations

from trame_client.utils.version import get_version

__version__ = get_version("trame_slicer")
