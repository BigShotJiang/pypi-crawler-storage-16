from transformer_lm_gan.transformer_lm_gan import (
    LanguageModelGenerator,
    Discriminator,

)
