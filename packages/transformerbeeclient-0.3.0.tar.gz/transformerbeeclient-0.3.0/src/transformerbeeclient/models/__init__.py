"""
models contains the classes that are used to represent the data that is being sent to/from the transformer.bee
"""
