# transkribus-to-prima

> Transforms Transkribus' [flavor of PAGE-XML](https://gitlab.com/readcoop/transkribus/TranskribusCore/-/blob/master/src/main/resources/xsd/pagecontent_extension.xsd) to [standard PAGE-XML](https://ocr-d.de/en/gt-guidelines/trans/trPage.html)

## Installation

From PyPI:

```
pip install transkribus-to-prima
```

From repo root:

```
pip install .
```
