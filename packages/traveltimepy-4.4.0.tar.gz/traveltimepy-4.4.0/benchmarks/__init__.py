"""Module for benchmarks."""
