def print_indented(text, indent_level=0):
    indentation = "\t" * indent_level
    print(f"{indentation}{text}")
