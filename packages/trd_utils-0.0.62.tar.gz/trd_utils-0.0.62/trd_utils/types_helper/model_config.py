

class ModelConfig:
    ignored_fields: list[str] = None
    mapped_fields: dict[str, str] = None


