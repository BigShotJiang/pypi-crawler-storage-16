import click


@click.group(help="Command line interface for trefoil")
def cli():
    pass