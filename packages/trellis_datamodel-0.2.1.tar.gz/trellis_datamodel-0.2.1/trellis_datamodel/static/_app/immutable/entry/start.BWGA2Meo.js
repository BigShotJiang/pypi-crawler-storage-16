import{l as o,a as r}from"../chunks/lI9_22st.js";export{o as load_css,r as start};
