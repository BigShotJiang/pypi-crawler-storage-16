__all__ = []

TYPE_CHECKING = False
if TYPE_CHECKING:
    from collections.abc import Callable
    from typing import Any, Protocol

    from tressed.type_form import TypeForm
    from tressed.type_path import TypePath

    class LoaderProtocol(Protocol):
        def _load[T](
            self, value: Any, type_form: TypeForm[T], type_path: TypePath
        ) -> T: ...
        def _resolve_alias[T](
            self, type_form: TypeForm[T], type_path: TypePath, name: str
        ) -> str: ...

    type LoaderFn[T] = Callable[[Any, TypeForm[T], TypePath, LoaderProtocol], T]
    type TypeLoaderSpecializer[T] = Callable[[TypeForm[T], TypePath], str | None]

    __all__ += [
        "LoaderProtocol",
        "LoaderFn",
        "TypeLoaderSpecializer",
    ]
