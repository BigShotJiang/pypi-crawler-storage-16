# trifold

`trifold` is a tool to serve static websites using a content delivery network (CDN).

**[Documentation & Quickstart](https://jpt.sh/projects/trifold/)**

**[Repository](https://codeberg.org/jpt/trifold/)**

This allows painless deployment of sites consisting entirely of static assets (HTML, CSS, JS, images) for pennies a month.
It is the perfect companion to deploy sites built with static-site generators like [Hugo](https://gohugo.io), [Zola](https://getzola.org), [Quarto](https://quarto.org), or [zensical](https://zensical.org).

The tool provides a simple CLI that allows:

- initializing new projects without touching the CDN web interface
- syncing local HTML/CSS/JS/etc. to the CDN & clearing the cache
- configuring a custom domain name to point at your files, with SSL enabled
- setting a maximum monthly cost to avoid surprise bills
- using CDN edge functions to support redirects
