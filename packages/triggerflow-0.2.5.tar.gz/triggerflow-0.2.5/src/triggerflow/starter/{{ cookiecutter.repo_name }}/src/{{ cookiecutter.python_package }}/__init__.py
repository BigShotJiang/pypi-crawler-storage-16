"""{{ cookiecutter.project_name }}"""

__version__ = "0.1"
