=======
History
=======

0.1.0 (2024-02-29)
------------------

* First release on PyPI.
