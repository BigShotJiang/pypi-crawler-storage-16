=====
Usage
=====

To use Transparent Research Object utils in a project::

    import tro_utils
