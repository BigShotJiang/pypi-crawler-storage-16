# ⚡ Quick Start: Docker Speed Optimization

## What Changed?

Your Co-DataScientist now uses a **two-stage Docker build** that's **24-240x faster** for hypothesis testing!

## How It Works (Simple Version)

### Before
```
For EACH hypothesis:
  1. FROM python:3.10-slim
  2. Install system packages (30s)
  3. pip install numpy pandas torch... (2-20 min) ← SLOW
  4. Copy code (5s)
  5. Run
```

### After
```
Baseline (once):
  1. FROM python:3.10-slim
  2. Install system packages (30s)
  3. pip install numpy pandas torch... (2-20 min)
  4. Copy code (5s)
  5. Save as base image ✅

For EACH hypothesis:
  1. FROM base-image ← Reuse!
  2. Copy code (5s) ← FAST
  3. Run
```

## Speed Gains

| What | Before | After |
|------|--------|-------|
| Baseline | 2-20 min | 2-20 min (same) |
| Each hypothesis | 2-20 min | **5-10 sec** ⚡ |
| 10 generations × 4 parallel | ~10 hours | **~15 minutes** 🚀 |

## No Changes Needed!

✅ Same config.yaml  
✅ Same commands  
✅ Same workflow  
✅ Automatic cleanup  
✅ Just **WAY faster**

## What You'll See

When you run `co-datascientist run config.yaml`:

```
🏗️  Building base image with dependencies: co-datascientist-abc12345
   (This is slow but only happens once - all hypotheses will reuse this!)
[████████] 15 min
✅ Base image built - all future hypotheses will be fast!

⚡ Building hypothesis image: co-datascientist-def12345
   (Fast build - only copying code changes)
[████████] 8 sec ← FAST!

⚡ Building hypothesis image: co-datascientist-ghi12345
[████████] 7 sec ← FAST!
```

## That's It!

No configuration needed. Just enjoy the speed! 🎉
