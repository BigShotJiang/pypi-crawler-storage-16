from truefoundry.deploy.lib import session


def logout():
    session.logout()
