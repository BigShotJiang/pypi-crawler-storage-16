from trulens.dashboard.utils.sis_utils import render_page

if __name__ == "__main__":
    render_page("records")
