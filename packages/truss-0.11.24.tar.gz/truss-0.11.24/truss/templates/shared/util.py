import multiprocessing
import os
import sys
from typing import List, Optional

import psutil

BLOB_DOWNLOAD_TIMEOUT_SECS = 600  # 10 minutes
# number of seconds to wait for truss server child processes before sending kill signal
CHILD_PROCESS_WAIT_TIMEOUT_SECONDS = 120


def model_supports_predict_proba(model: object) -> bool:
    if not hasattr(model, "predict_proba"):
        return False
    if hasattr(model, "_check_proba"):  # noqa eg Support Vector Machines *can* predict proba if they made certain choices while training
        try:
            model._check_proba()
            return True
        except AttributeError:
            return False
    return True


def cpu_count():
    """Get the available CPU count for this system.
    Takes the minimum value from the following locations:
    - Total system cpus available on the host.
    - CPU Affinity (if set)
    - Cgroups limit (if set)
    """
    count = os.cpu_count()

    # Check CPU affinity if available
    try:
        affinity_count = len(psutil.Process().cpu_affinity())
        if affinity_count > 0:
            count = min(count, affinity_count)
    except Exception:
        pass

    # Check cgroups if available
    if sys.platform == "linux":
        try:
            with open("/sys/fs/cgroup/cpu,cpuacct/cpu.cfs_quota_us") as f:
                quota = int(f.read())
            with open("/sys/fs/cgroup/cpu,cpuacct/cpu.cfs_period_us") as f:
                period = int(f.read())
            cgroups_count = int(quota / period)
            if cgroups_count > 0:
                count = min(count, cgroups_count)
        except Exception:
            pass

    return count


def all_processes_dead(procs: List[multiprocessing.Process]) -> bool:
    for proc in procs:
        if proc.is_alive():
            return False
    return True


def kill_child_processes(
    parent_pid: int,
    timeout_seconds: Optional[float] = CHILD_PROCESS_WAIT_TIMEOUT_SECONDS,
):
    try:
        parent = psutil.Process(parent_pid)
    except psutil.NoSuchProcess:
        return
    children = parent.children(recursive=True)
    for process in children:
        process.terminate()
    gone, alive = psutil.wait_procs(children, timeout=timeout_seconds)
    for process in alive:
        process.kill()
