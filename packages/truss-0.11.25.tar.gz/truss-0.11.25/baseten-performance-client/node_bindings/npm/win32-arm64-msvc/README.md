# `@basetenlabs/performance-client-win32-arm64-msvc`

This is the **aarch64-pc-windows-msvc** binary for `@basetenlabs/performance-client`
