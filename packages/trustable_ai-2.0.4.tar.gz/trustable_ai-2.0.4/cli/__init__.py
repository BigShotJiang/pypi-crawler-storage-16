"""CLI tool for Trustable AI Workbench."""

from .main import cli

__all__ = ["cli"]
