from . write import run

run()