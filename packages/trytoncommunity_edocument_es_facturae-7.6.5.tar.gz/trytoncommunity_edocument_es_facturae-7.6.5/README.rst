############################
Edocument Es Facturae Module
############################


The *Edocument Spanish Facturae* adds support for generating FacturaE
electronic documents in Tryton.

.. toctree::
   :maxdepth: 2

   usage
   design
   releases
