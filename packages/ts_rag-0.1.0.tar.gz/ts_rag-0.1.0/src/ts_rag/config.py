"""
TashanRAG 统一配置管理模块

该模块负责：
1. 加载并强制使用 .env 文件中的配置
2. 提供统一的配置访问接口
3. 验证必需的配置项
4. 设置 LiteLLM 相关配置
"""

import os
import sys
import warnings
from pathlib import Path

from dotenv import load_dotenv

# 抑制来自第三方库的弃用警告
warnings.filterwarnings("ignore", category=DeprecationWarning, module="litellm.*")


class TashanRAGConfig:
    """TashanRAG 统一配置管理类

    采用单例模式，确保全项目使用同一份配置。
    优先使用 .env 文件中的配置，会覆盖系统环境变量。
    """

    _instance = None
    _initialized = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self._load_env()
            self._validate_config()
            self._setup_litellm()
            self._initialized = True

    def _load_env(self):
        """加载 .env 文件并强制使用其中的配置

        优先级：
        1. .env 文件中的配置（最高优先级）
        2. 系统环境变量
        3. 硬编码默认值（最低优先级）
        """
        # 获取项目根目录
        if hasattr(sys, "_MEIPASS"):
            # Py打包后的情况
            project_root = Path(sys._MEIPASS).parent
        else:
            # 开发环境
            project_root = Path(__file__).parent.parent.parent

        env_path = project_root / ".env"
        example_env_path = project_root / ".env.example"

        # 检查是否在测试环境中
        is_testing = os.environ.get("PYTEST_CURRENT_TEST") or "test" in sys.modules

        # 在测试环境中，使用 .env.example，如果不存在则使用 .env
        if is_testing:
            if example_env_path.exists():
                env_path = example_env_path
            elif not env_path.exists():
                # 如果 .env 也不存在，设置测试用的默认值
                os.environ.setdefault("OPENAI_API_KEY", "sk-test-key-for-testing-only")
                os.environ.setdefault("OPENAI_BASE_URL", "https://api.openai.com/v1")
                os.environ.setdefault("MODEL_NAME", "gpt-3.5-turbo")
                os.environ.setdefault("TASHANRAG_PAPER_ROOT", "01-文献")

        if env_path.exists():
            # 先使用 load_dotenv 加载
            load_dotenv(dotenv_path=env_path)

            # 然后强制读取并设置，确保覆盖系统环境变量
            with open(env_path, encoding="utf-8") as f:
                for _line_num, line in enumerate(f, 1):
                    line = line.strip()
                    # 跳过空行和注释
                    if not line or line.startswith("#"):
                        continue

                    # 解析键值对
                    if "=" in line:
                        # 只分割第一个 =，支持值中包含 =
                        key, value = line.split("=", 1)
                        key = key.strip()
                        value = value.strip()

                        # 移除值两端的引号（如果有）
                        if (value.startswith('"') and value.endswith('"')) or (
                            value.startswith("'") and value.endswith("'")
                        ):
                            value = value[1:-1]

                        os.environ[key] = value

        else:
            if not is_testing:
                print(f"[Config] 警告: 未找到 .env 文件 ({env_path})", file=sys.stderr)
                print("[Config] 请创建 .env 文件或设置环境变量", file=sys.stderr)

    def _validate_config(self):
        """验证必需的配置项"""
        required_configs = {
            "OPENAI_API_KEY": "API 密钥",
            "OPENAI_BASE_URL": "API 基础 URL",
        }

        missing_configs = []
        for key, desc in required_configs.items():
            if not os.environ.get(key):
                missing_configs.append(f"{key} ({desc})")

        if missing_configs:
            error_msg = "缺少必需的配置项：\n" + "\n".join(f"  - {c}" for c in missing_configs)
            raise ValueError(error_msg)

    def _setup_litellm(self):
        """设置 LiteLLM 相关配置"""
        try:
            # 尝试相对导入（支持作为包运行）
            try:
                from .llm_config import register_qwen_models
            except ImportError:
                # 回退到绝对导入（开发模式）
                from llm_config import register_qwen_models

            register_qwen_models()
        except ImportError:
            # 注册失败不是致命错误，只给出警告
            # LiteLLM 仍然可以正常工作，只是可能缺少一些自定义模型
            print(
                "[Config] 警告: 无法导入 llm_config，LiteLLM 模型可能未注册",
                file=sys.stderr,
            )

    # OpenAI API 配置
    @property
    def openai_api_key(self) -> str:
        """OpenAI API 密钥"""
        return os.environ["OPENAI_API_KEY"]

    @property
    def openai_base_url(self) -> str:
        """OpenAI API 基础 URL"""
        return os.environ["OPENAI_BASE_URL"]

    @property
    def model_name(self) -> str:
        """默认使用的模型名称"""
        return os.environ.get("MODEL_NAME", "openai/qwen-flash")

    # 论文相关配置
    @property
    def paper_root(self) -> str:
        """论文根目录"""
        return os.environ.get("TASHANRAG_PAPER_ROOT") or os.environ.get("DEFAULT_PAPER_ROOT") or "01-文献"

    @property
    def index_dir(self) -> str:
        """索引目录（相对于论文目录）"""
        return ".indexonly"

    @property
    def papers_dir(self) -> str:
        """转换后的论文目录（相对于论文目录）"""
        return os.path.join(self.index_dir, "papers")

    @property
    def index_data_dir(self) -> str:
        """索引数据目录（相对于论文目录）"""
        return os.path.join(self.index_dir, "index_data")

    # 处理配置
    @property
    def max_concurrent_visits(self) -> int:
        """最大并发访问数"""
        return int(os.environ.get("MAX_CONCURRENT_VISITS", "5"))

    @property
    def top_k_default(self) -> int:
        """默认检索的论文数量"""
        return int(os.environ.get("TOP_K_DEFAULT", "3"))

    # 路径配置
    @property
    def project_root(self) -> Path:
        """项目根目录"""
        if hasattr(sys, "_MEIPASS"):
            return Path(sys._MEIPASS).parent
        else:
            return Path(__file__).parent.parent.parent

    def get_absolute_path(self, relative_path: str) -> str:
        """获取相对路径的绝对路径"""
        if os.path.isabs(relative_path):
            return relative_path
        return str(self.project_root / relative_path)

    # 调试配置
    @property
    def debug_mode(self) -> bool:
        """是否开启调试模式"""
        return os.environ.get("DEBUG", "false").lower() == "true"

    @property
    def verbose(self) -> bool:
        """是否输出详细信息"""
        return os.environ.get("VERBOSE", "false").lower() == "true"

    # 缓存配置
    @property
    def enable_cache(self) -> bool:
        """是否启用缓存"""
        return os.environ.get("ENABLE_CACHE", "true").lower() == "true"

    def print_config(self):
        """打印当前配置（调试用）"""
        print("\n" + "=" * 60)
        print("TashanRAG 配置信息")
        print("=" * 60)
        print(f"API Base URL: {self.openai_base_url}")
        print(f"Model: {self.model_name}")
        print(f"Paper Root: {self.paper_root}")
        print(f"Max Concurrent Visits: {self.max_concurrent_visits}")
        print(f"Top K Default: {self.top_k_default}")
        print(f"Debug Mode: {self.debug_mode}")
        print("=" * 60)


# 创建全局配置实例
config = TashanRAGConfig()

# 为了向后兼容，也可以直接导入常用配置
OPENAI_API_KEY = config.openai_api_key
OPENAI_BASE_URL = config.openai_base_url
MODEL_NAME = config.model_name
PAPER_ROOT = config.paper_root
MAX_CONCURRENT_VISITS = config.max_concurrent_visits
TOP_K_DEFAULT = config.top_k_default
