import os
import sys
from pathlib import Path

# ================= 导入模块 =================
try:
    import findpdf
except ImportError:
    # 尝试添加当前目录到 sys.path (适配 server 调用场景)
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if current_dir not in sys.path:
        sys.path.append(current_dir)
    try:
        import findpdf
    except ImportError:
        print("错误: 找不到 findpdf.py")
        sys.exit(1)

try:
    from pdf2md import PDFToMarkdownParser
except ImportError:
    print("错误: 找不到 pdf2md.py")
    sys.exit(1)

# ================= 辅助函数 =================


def get_relative_key(full_path, root_path):
    try:
        rel = full_path.relative_to(root_path)
        return str(rel.with_suffix("")).replace("\\", "/")
    except ValueError:
        return None


def scan_existing_mds(papers_root):
    md_map = {}
    if not papers_root.exists():
        return md_map
    for md_file in papers_root.rglob("*.md"):
        key = get_relative_key(md_file, papers_root)
        if key:
            md_map[key] = md_file
    return md_map


# ================= 核心逻辑封装 =================


def run_pdf_sync_pipeline(target_root_path: str):
    """
    供外部调用的主入口函数
    :param target_root_path: PDF 所在的根目录 (例如 /home/TEST/test_search/01-文献)
    """
    source_root = Path(target_root_path)

    if not source_root.exists():
        print(f"【错误】找不到源文件夹: {source_root}")
        return

    # 定义隐藏目录结构 (.indexonly 放在 source_root 内部)
    hidden_dir = source_root / ".indexonly"
    index_file = hidden_dir / "paperfind.txt"
    papers_output_root = hidden_dir / "papers"

    print("=== [Step 1] PDF->MD 增量同步启动 ===")
    print(f"源目录: {source_root}")
    print(f"MD库目录: {papers_output_root}")

    # 1. 初始化环境
    if not hidden_dir.exists():
        hidden_dir.mkdir(parents=True, exist_ok=True)

    if not papers_output_root.exists():
        papers_output_root.mkdir(parents=True, exist_ok=True)

    # 2. 扫描 PDF (findpdf)
    print("扫描 PDF 列表...")
    findpdf.find_all_pdfs(str(source_root), str(index_file))

    # 3. 构建 Source Map
    source_pdf_map = {}
    if index_file.exists():
        with open(index_file, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                p = Path(line)
                key = get_relative_key(p, source_root.resolve())
                if key:
                    source_pdf_map[key] = p

    # 4. 扫描现有 MD
    dest_md_map = scan_existing_mds(papers_output_root)

    # 5. 计算差异
    source_keys = set(source_pdf_map.keys())
    dest_keys = set(dest_md_map.keys())
    keys_to_add = source_keys - dest_keys
    keys_to_remove = dest_keys - source_keys

    print(
        f"同步分析: 总PDF {len(source_keys)} | 现有MD {len(dest_keys)} | "
        f"新增 {len(keys_to_add)} | 删除 {len(keys_to_remove)}"
    )

    # 6. 执行删除
    if keys_to_remove:
        for key in keys_to_remove:
            md_path_to_delete = dest_md_map[key]
            try:
                os.remove(md_path_to_delete)
                # 尝试清理空目录
                parent_dir = md_path_to_delete.parent
                if parent_dir != papers_output_root and not any(parent_dir.iterdir()):
                    try:
                        parent_dir.rmdir()
                    except Exception:
                        pass
            except OSError:
                pass

    # 7. 执行转换 (新增)
    if keys_to_add:
        print(f"开始转换 {len(keys_to_add)} 个新文件...")
        for i, key in enumerate(keys_to_add, 1):
            pdf_path = source_pdf_map[key]
            relative_parent = Path(key).parent
            target_dir = papers_output_root / relative_parent
            target_dir.mkdir(parents=True, exist_ok=True)

            print(f"[{i}/{len(keys_to_add)}] 转换: {pdf_path.name}")
            try:
                parser = PDFToMarkdownParser(pdf_path, target_dir)
                parser.run()
            except Exception as e:
                print(f"   [转换失败] {e}")
    else:
        print("没有新文件需要转换。")

    print("=== [Step 1] PDF->MD 同步完成 ===\n")


# ================= 脚本入口 (兼容旧用法) =================

if __name__ == "__main__":
    # 默认测试路径 (Windows)
    # 实际生产环境请通过 run_pdf_sync_pipeline 调用
    BASE_DIR = Path(__file__).resolve().parent
    DEFAULT_TEST_TARGET = BASE_DIR / "paperfindtest"

    if DEFAULT_TEST_TARGET.exists():
        run_pdf_sync_pipeline(str(DEFAULT_TEST_TARGET))
    else:
        print(f"默认测试目录不存在: {DEFAULT_TEST_TARGET}")
