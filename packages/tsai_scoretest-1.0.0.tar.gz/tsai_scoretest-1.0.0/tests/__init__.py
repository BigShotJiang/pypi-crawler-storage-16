"""Test suite for scoretest package."""
