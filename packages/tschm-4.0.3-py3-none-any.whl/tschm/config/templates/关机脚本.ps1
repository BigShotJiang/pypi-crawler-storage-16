


# 休眠命令
shutdown -s -t 00 -f









