Simple Colors Code
