def red(s):
    print(f"\033[1;31m{s}\033[0m")
def green(s):
    print(f"\033[1;32m{s}\033[0m")
def yellow(s):
    print(f"\033[1;33m{s}\033[0m")
def blue(s):
    print(f"\033[1;34m{s}\033[0m")
