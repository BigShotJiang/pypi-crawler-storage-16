# Changelog

## 1.2
- Drop python 3.9 support

## 1.1

- Drop python 3.8 support

## 1.0

- Added TTLMap class
