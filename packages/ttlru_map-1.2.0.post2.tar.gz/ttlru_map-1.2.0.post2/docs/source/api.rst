API
===

.. autosummary::
    :toctree: generated
    :recursive:

    ttlru_map.TTLMap
