﻿ttl\_dict.TTLMap
=================

.. currentmodule:: ttlru_map

.. autoclass:: TTLMap


   .. automethod:: __init__


   .. rubric:: Methods

   .. autosummary::

      ~TTLMap.__init__
      ~TTLMap.clear
      ~TTLMap.get
      ~TTLMap.items
      ~TTLMap.keys
      ~TTLMap.pop
      ~TTLMap.popitem
      ~TTLMap.setdefault
      ~TTLMap.update
      ~TTLMap.values
