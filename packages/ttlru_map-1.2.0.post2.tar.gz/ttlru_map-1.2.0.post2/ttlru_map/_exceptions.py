class TTLMapError(Exception):
    pass


class TTLMapInvalidConfigError(TTLMapError):
    pass
