# Twinkly Twinkly Little Star

`ttls` is a small package to help you make async requests to Twinkly LEDs. A command line tool (also called `ttls`) is also included, as well as some examples how to create both loadable movies and realtime sequences.

Written based on the [excellent XLED documentation](https://xled-docs.readthedocs.io/en/latest/) by [@scrool](https://github.com/scrool).
