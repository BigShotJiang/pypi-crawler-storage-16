Commit all changes in the repo and push the changes up to github
