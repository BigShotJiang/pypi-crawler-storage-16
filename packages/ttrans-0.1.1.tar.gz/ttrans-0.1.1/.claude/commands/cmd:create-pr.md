Commit all changes and create a new pull request with all commits squashed and a summary of all changes as the PR description. 
