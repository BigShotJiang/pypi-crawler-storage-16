# Architectural Decision Records

This document captures key architectural decisions and their rationale.

<!--
Entries are added by /cmd:graduate after completing features.
Format:
## ADR-NNN: [Decision Title] - YYYY-MM-DD
### Context
### Decision
### Consequences
-->
