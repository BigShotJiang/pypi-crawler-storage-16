# Specification

This document describes the features, behaviors, and constraints of the system.

<!--
Entries are added by /cmd:graduate after completing features.
Each section describes a feature's behaviors and constraints as implemented.
-->

## Features

<!-- Feature sections will be added here -->
