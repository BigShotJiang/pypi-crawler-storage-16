# Install dependencies using uv
uv sync
