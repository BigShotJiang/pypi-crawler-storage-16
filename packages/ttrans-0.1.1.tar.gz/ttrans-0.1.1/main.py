def main():
    print("Hello from ttrans!")


if __name__ == "__main__":
    main()
