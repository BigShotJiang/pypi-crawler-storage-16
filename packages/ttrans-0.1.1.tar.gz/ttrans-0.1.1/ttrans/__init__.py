"""ttrans - macOS meeting transcription assistant with TUI."""

__version__ = "0.1.1"
