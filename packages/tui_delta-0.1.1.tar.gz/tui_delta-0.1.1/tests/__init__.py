"""Tests for tui-delta."""
