"""File indexing for fast repository lookups."""

from tunacode.indexing.code_index import CodeIndex

__all__ = ["CodeIndex"]
