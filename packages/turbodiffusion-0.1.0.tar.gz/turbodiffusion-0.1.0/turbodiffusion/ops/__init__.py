from .core import int8_linear, int8_quant, rmsnorm, layernorm
from .core import Int8Linear, FastRMSNorm, FastLayerNorm