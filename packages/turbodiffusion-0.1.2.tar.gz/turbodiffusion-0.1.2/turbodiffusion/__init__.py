from .SLA import SparseLinearAttention as SLA
from .SageSLA import SparseLinearAttention as SageSLA
