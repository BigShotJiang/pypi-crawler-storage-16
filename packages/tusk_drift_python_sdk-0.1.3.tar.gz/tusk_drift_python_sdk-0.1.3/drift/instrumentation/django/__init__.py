"""Django instrumentation for Drift SDK."""

from .instrumentation import DjangoInstrumentation

__all__ = ["DjangoInstrumentation"]
