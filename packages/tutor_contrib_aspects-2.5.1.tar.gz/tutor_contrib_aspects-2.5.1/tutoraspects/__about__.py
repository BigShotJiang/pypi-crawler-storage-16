"""
Expose some package metadata.
"""

__version__ = "2.5.1"
