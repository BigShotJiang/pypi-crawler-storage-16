"""
Package version.
"""
__version__ = "19.1.1"
