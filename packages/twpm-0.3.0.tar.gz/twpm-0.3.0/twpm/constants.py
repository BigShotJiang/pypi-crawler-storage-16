from twpm.core.primitives import ProgressNode

DEFAULT_PROGRESS_NODE = ProgressNode
