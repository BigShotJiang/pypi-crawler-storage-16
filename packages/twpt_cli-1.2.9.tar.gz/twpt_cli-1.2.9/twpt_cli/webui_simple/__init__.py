"""Simplified Web UI for ThreatWinds Pentest CLI."""
