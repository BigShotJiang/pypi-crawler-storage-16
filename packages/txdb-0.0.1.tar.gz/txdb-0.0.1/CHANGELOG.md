# Changelog

## Version 0.0.1

- Initial release of the package with class structure and basic functionality.
