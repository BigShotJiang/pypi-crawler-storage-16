# Changelog

## Version 0.0.1 - 0.0.2

- Initial release of the package with class structure and basic functionality.
