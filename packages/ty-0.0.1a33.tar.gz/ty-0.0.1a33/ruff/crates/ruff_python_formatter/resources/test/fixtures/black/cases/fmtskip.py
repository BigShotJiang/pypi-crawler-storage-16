a, b = 1, 2
c =    6  # fmt: skip
d = 5
