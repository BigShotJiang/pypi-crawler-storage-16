# flags: --line-ranges=6-7
class Foo:

    @overload
    def foo(): ...

    def fox(self):
        print()
