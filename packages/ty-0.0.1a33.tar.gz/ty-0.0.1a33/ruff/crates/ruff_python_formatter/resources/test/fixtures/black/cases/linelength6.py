# Regression test for #3427, which reproes only with line length <= 6
def f():
    """
    x
    """
