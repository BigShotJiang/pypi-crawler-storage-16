#!/python

# regression test for #4762
"""
docstring
"""
from __future__ import annotations

import os
