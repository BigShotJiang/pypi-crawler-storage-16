def fn(*args: *tuple[*A, B]) -> None:
    pass


fn.__annotations__
