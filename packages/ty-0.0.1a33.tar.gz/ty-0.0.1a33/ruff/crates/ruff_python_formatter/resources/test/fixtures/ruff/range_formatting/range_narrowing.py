def test ():
    <RANGE_START>if True:
        print(  "format")
    elif False:
        print (   "and this")<RANGE_END>
        print("not this"   )

    print("nor this" )
