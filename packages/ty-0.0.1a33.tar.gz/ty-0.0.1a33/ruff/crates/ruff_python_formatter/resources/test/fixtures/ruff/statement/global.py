def f():
    global x, y, z


def f():
    # leading comment
    global x, y, z # end-of-line comment
    # trailing comment


def f():
    global analyze_featuremap_layer, analyze_featuremapcompression_layer, analyze_latencies_post, analyze_motions_layer, analyze_size_model


def f():
    global analyze_featuremap_layer, analyze_featuremapcompression_layer, analyze_latencies_post, analyze_motions_layer, analyze_size_model  # end-of-line comment
