
return len(self.nodeseeeeeeeee), sum(
    len(node.parents) for node in self.node_map.values()
)


return len(self.nodeseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee), sum(
    len(node.parents) for node in self.node_map.values()
)


return (
    len(self.nodeseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee), sum(
    len(node.parents) for node in self.node_map.values()
    )
)

# Regression tests for https://github.com/astral-sh/ruff/issues/8042
def f():
    return (
        self.get_filename() + ".csv" +
        "text/csv" +
        output.getvalue().encode("utf-8----------------"),
    )


def f():
    return (
        self.get_filename() + ".csv" + "text/csv",
        output.getvalue().encode("utf-8----------------")
    )

def f():
    return (
        self.get_filename() + ".csv",
        "text/csv",
        output.getvalue().encode("utf-8----------------")
    )


def f():
    return self.get_filename() + ".csv" + "text/csv" + output.getvalue().encode("utf-8----------------"),

def f():
    return self.get_filename() + ".csv" + "text/csv", output.getvalue().encode("utf-8----------------")

def f():
    return self.get_filename() + ".csv", "text/csv", output.getvalue().encode("utf-8----------------")
