a[b]
a[b][c]
