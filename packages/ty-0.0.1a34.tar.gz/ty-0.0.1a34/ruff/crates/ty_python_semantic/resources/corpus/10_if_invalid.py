x if $z
