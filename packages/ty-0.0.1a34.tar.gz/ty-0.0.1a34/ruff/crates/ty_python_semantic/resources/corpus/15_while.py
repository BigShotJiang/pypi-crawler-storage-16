while a:
    b
