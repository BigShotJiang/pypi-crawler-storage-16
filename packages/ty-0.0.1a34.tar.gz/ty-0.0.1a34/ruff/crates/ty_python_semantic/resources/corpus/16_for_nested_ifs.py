for x in y:
    if a:
        if x:
            y
        else:
            x
    else:
        b
