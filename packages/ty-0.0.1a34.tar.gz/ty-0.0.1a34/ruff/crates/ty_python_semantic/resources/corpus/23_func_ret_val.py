def foo(a):
    return a
