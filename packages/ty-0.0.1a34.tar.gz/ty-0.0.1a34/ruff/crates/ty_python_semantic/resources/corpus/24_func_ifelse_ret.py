def foo(a):
    if a:
        return b
    else:
        return c
