def foo():
    yield
    yield a
    b = yield a
