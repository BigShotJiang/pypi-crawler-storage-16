(z for x in y for z in x)
