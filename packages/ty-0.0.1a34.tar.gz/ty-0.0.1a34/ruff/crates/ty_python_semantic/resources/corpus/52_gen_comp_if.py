(x for x in s if x)
(x for x in s if x if ~x)
