f = lambda: [x for x in y]
