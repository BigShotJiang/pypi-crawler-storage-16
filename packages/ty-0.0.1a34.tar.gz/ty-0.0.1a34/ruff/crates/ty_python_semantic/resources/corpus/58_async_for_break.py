# TODO(T130415563): Line numbers don't match up with 3.10 base compiler
#async def test2():
#    async for i in a:
#        if i:
#            break
