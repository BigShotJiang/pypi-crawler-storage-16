async def foo():
    async for a in b:
        c
    else:
        d
