try:
    a
except Exc:
    b
except Exc2:
    c
