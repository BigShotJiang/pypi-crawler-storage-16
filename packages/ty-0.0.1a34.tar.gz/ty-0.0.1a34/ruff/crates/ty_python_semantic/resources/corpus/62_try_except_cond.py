try:
    pass
except Exception as exc:
    if x:
        y = x
    elif z:
        y = z
