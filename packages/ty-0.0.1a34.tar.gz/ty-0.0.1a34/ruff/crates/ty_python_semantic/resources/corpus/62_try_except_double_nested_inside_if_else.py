if a:
    try:
        try:
            pass
        except:
            pass
    except:
        pass
else:
    pass
