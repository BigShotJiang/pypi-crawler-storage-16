super

def foo():
    super
