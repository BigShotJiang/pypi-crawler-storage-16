match 0:
    case 0 if False:
        x = False
    case 0 if True:
        x = True
