match x:
    case [1, 0] if x := x[:0]:
        y = 1
