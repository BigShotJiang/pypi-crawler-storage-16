name_1
{0: 0 for unique_name_0 in unique_name_1 if name_1}


@[name_2 for unique_name_2 in name_2]
def name_2():
    pass


def name_2():
    pass


match 0:
    case name_2():
        pass
    case []:
        name_1 = 0
