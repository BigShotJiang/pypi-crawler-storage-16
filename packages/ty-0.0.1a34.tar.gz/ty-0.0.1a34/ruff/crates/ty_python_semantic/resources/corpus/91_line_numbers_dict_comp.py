a = {
    1: 2
    for x in y
}
