t: "tuple[list[int]]"
