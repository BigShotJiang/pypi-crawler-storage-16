def _[T: (T if cond else U)[0], U](): pass
