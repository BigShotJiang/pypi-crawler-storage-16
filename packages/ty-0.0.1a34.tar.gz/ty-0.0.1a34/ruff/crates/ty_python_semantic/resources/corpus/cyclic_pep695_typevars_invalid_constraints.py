class _[T: (0, T[0])]:
    def _(x: T):
        if x:
            pass
