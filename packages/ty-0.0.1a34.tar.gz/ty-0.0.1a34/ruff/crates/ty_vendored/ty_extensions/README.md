The `build.rs` copies the `ty_extensions.pyi` file in this directory into
the `vendor/typeshed/stdlib` directory.
