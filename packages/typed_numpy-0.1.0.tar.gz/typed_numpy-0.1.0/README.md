# typed-numpy

[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

Typed NumPy with static shape typing and runtime shape validation.

> [!WARNING]
> Experimental & WIP.

## License

This project falls under the [MIT License](LICENSE).
