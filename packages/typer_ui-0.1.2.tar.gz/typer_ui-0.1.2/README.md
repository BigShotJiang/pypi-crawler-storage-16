# Typer UI

[![PyPI version](https://badge.fury.io/py/typer-ui.svg)](https://badge.fury.io/py/typer-ui)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python Versions](https://img.shields.io/pypi/pyversions/typer-ui.svg)](https://pypi.org/project/typer-ui/)

**Typer UI** is a powerful Python library that automatically generates a web-based user interface for your [Typer](https://typer.tiangolo.com/) CLI applications. Built on top of [NiceGUI](https://nicegui.io/), it provides a modern, interactive way to inspect and execute your commands without writing a single line of frontend code.

![Typer UI Screenshot](docs/images/screenshot.png)

---

## 🚀 Features

-   **Zero Configuration**: Instantly turn any Typer CLI into a web app.
-   **Automatic Introspection**: Detects commands, arguments, options, and types automatically.
-   **Interactive Forms**: Generates user-friendly inputs for string, integer, boolean, and choice parameters.
-   **Real-time Output**: View command execution logs (stdout/stderr) directly in the browser.
-   **Type Safe**: leverages Python type hints to generate the correct UI components.
-   **Modern Design**: Clean, responsive interface powered by NiceGUI.

## 📦 Installation

Install `typer-ui` via pip:

```bash
pip install typer-ui
```

Since `typer-ui` relies on `typer` and `nicegui`, they will be installed as dependencies.

## 🛠 Usage

Integrating `typer-ui` is incredibly simple. Just wrap your existing Typer application instance and call `.run()`.

### Example

Assuming you have a Typer app in `main.py`:

```python
import typer
from typer_ui import TyperUI

app = typer.Typer()

@app.command()
def hello(name: str):
    print(f"Hello {name}")

@app.command()
def goodbye(name: str, formal: bool = False):
    if formal:
        print(f"Goodbye, Ms./Mr. {name}")
    else:
        print(f"Bye {name}!")

if __name__ == "__main__":
    # Create the TyperUI instance
    ui = TyperUI(app, title="My App UI")
    
    # Run the server
    ui.run()
```

Run your script:

```bash
python main.py
```

Your browser will automatically open showing the Typer UI interface at `http://localhost:8080`.

## 🎮 Demo

We have included a comprehensive demo in this repository to showcase the capabilities of existing CLIs.

To run the demo:

1.  **Clone the repository**:
    ```bash
    git clone https://github.com/amitb2050/typer-ui.git
    cd typer-ui
    ```

2.  **Install dependencies**:
    It is recommended to use a virtual environment.
    ```bash
    python -m venv venv
    source venv/bin/activate  # On Windows: venv\Scripts\activate
    pip install -e .
    ```

3.  **Run the Demo UI**:
    To see the UI in action, run the following command:
    ```bash
    python demo/run_ui.py
    ```

    You can also run the underlying CLI directly to compare:
    ```bash
    python demo/run.py --help
    ```

This will launch the UI for a sample CLI application (`mycli`) found in the `demo` directory. Explore the commands, try different inputs, and see the execution results live!

## 🤝 Contributing

Contributions are welcome! If you find a bug or feature request, please open an issue or submit a pull request.

1.  Fork the repository.
2.  Create a branch for your feature (`git checkout -b feature/amazing-feature`).
3.  Commit your changes.
4.  Push to the branch.
5.  Open a Pull Request.

### Dev Environment
We use `tox` for automation. To run tests:
```bash
pip install tox
tox
```

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
