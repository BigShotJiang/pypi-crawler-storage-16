"""Make the CLI runnable using python -m array_api."""

from .cli import app

app(prog_name="array-api")
