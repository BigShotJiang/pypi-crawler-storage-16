## 1.1.1.20251214 (2025-12-14)

[geopandas] Unpin pandas-stubs ([#15134](https://github.com/python/typeshed/pull/15134))

## 1.1.1.20251203 (2025-12-03)

Pin dependencies on pandas-stubs to < 2.3.3.251201 ([#15100](https://github.com/python/typeshed/pull/15100))

## 1.1.1.20250829 (2025-08-29)

[geopandas] Some @final methods are overridden ([#14657](https://github.com/python/typeshed/pull/14657))

## 1.1.1.20250809 (2025-08-09)

Mark stub-only private symbols as `@type_check_only` in third-party stubs (#14545)

## 1.1.1.20250708 (2025-07-08)

Bump geopandas stubs to version 1.1.1 (#14244)

## 1.0.1.20250601 (2025-06-01)

[geopandas] Add a # type: ignore (#14200)

Should help with #14194

## 1.0.1.20250528 (2025-05-28)

[geopandas] Unblock CI (#14178)

## 1.0.1.20250510 (2025-05-10)

[geopandas] Fix CI tests in some circumstances (#13978)

Add "libproj-dev" and "proj-bin" to apt_dependencies.
These packages are necessary to build the pyproj
dependency if a pre-built wheel is not available.

## 1.0.1.20250404 (2025-04-04)

Enable Ruff flake8-todos (TD) (#13748)

## 1.0.1.20250310 (2025-03-10)

Fix override issue in GeoDataFrame.astype return type (#13606)

## 1.0.1.20250304 (2025-03-04)

Drop flake8-noqa and remove workarounds to work with Ruff (#13571)

## 1.0.1.20250120 (2025-01-20)

Add geopandas stubs (#12990)

