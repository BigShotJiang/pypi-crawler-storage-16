"""
UAFT - Universal Automation Framework Tool
"""

__version__ = "0.2.0"
