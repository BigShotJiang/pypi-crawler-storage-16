""" uamt """
__version__="1.2.2"
from .uamtto import *
