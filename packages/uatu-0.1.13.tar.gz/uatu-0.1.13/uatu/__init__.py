"""
Uatu - The Watcher

An agentic system troubleshooting tool powered by Claude.
"""

__version__ = "0.1.13"
