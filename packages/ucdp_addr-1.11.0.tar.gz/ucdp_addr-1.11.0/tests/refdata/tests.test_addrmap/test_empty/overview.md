* Top:     `None`
* Defines: `None`
* Size:    `None`

| Addrspace | Type | Base | Size | Infos | Attributes |
| --------- | ---- | ---- | ---- | ----- | ---------- |


| Addrspace | Word | Field | Offset | Access | Reset | Infos | Attributes |
| --------- | ---- | ----- | ------ | ------ | ----- | ----- | ---------- |
