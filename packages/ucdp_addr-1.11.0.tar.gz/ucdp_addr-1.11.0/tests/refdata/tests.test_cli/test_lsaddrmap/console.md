* Top:     `top_lib.top`
* Defines: `None`
* Size:    `268 KB`

| Addrspace | Type | Base      | Size             | Infos | Attributes |
| --------- | ---- | --------- | ---------------- | ----- | ---------- |
| one       | -    | `0x11000` | `512x32 (2 KB)`  |       |            |
| two       | -    | `0x12000` | `1024x32 (4 KB)` |       |            |
| one       | -    | `0x41000` | `512x32 (2 KB)`  |       |            |
| two       | -    | `0x42000` | `1024x32 (4 KB)` |       |            |
