dsa.deque module
================

.. automodule:: dsa.deque
   :members:
   :show-inheritance:
   :undoc-members:
