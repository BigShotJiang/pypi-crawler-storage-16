dsa.prim module
===============

.. automodule:: dsa.prim
   :members:
   :show-inheritance:
   :undoc-members:
