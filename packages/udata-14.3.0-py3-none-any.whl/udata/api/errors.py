from udata.i18n import gettext as _

VALIDATION_ERROR = _(
    "Validation error: your data cannot be updated for "
    "now, we have been notified of the error and we will "
    "fix it as soon as possible."
)
