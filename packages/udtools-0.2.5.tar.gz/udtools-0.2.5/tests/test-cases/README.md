# Test the validator in Windows command line (cmd)

```batch
tools\test-cases\test.bat 2> tools\test-cases\test.log
```
