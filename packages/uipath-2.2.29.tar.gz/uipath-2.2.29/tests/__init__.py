"""
Test suite for UiPath SDK.
Contains test cases for all CLI commands and utilities.
"""
