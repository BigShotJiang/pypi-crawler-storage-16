
from typing import List
from typing import NewType

EnhancedListBoxItems = NewType('EnhancedListBoxItems', List[str])
