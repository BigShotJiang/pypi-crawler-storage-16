'''Tools for managing a satellite tracking ground station.

pass_commander figures out when a given satellite is overhead and then points an antenna at it and
manages a radio to talk to it.
'''
