'''Tests for pass_commander using pytest.

Invoke from from the project root directory using `pytest`
'''
