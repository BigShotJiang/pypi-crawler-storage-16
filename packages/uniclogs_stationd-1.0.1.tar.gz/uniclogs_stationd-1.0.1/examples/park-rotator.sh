#!/bin/sh

echo "P 180 90" | nc -Nw 1 localhost 4533
