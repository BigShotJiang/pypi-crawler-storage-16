# Unicode Radical Converter

一个智能的Unicode部首转换工具，用于将CJK（中日韩）部首字符转换为对应的完整汉字。

[![Python Version](https://img.shields.io/badge/python-3.7+-blue.svg)](https://python.org)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Build Status](https://img.shields.io/badge/build-passing-brightgreen.svg)](https://github.com/yourusername/unicode-radical-converter)

## 特性

- 🚀 **智能识别**：自动识别Unicode中的CJK部首字符
- 🎯 **精准转换**：基于Unicode名称和预设映射的高效转换
- 🔧 **灵活配置**：支持多种转换方法和自定义映射
- 📦 **易于使用**：简单的API和命令行工具
- 🧪 **完全测试**：高覆盖率的单元测试

## 安装

```bash
# 使用pip安装
pip install unicode-radical-converter

# 从源码安装
git clone https://github.com/yourusername/unicode-radical-converter.git
cd unicode-radical-converter
pip install -e .
```

## 快速开始

### Python API

```python
from unicode_radical_converter import convert

# 基本转换
print(convert('⻩金时代'))  # 输出: 黄金时代
print(convert('⻌向未来'))  # 输出: 走向未来
print(convert('⻨田风光'))  # 输出: 麦田风光

# 批量转换
texts = ['⻩金时代', '⻌向未来', '普通文本']
results = convert_batch(texts)
print(results)  # ['黄金时代', '走向未来', '普通文本']
```

### 命令行工具

```bash
# 转换文本
urc convert "⻩金时代"

# 从文件读取并转换
urc convert -f input.txt -o output.txt

# 分析文本中的部首
urc analyze "⻩⻌⻨⻬"

# 列出所有映射
urc list

# 检查字符是否是部首
urc check "⻩"

# 添加新映射
urc add "⻡" "象"

# 查看统计信息
urc stats
```

## 高级用法

### 自定义转换器

```python
from unicode_radical_converter import RadicalConverter

# 创建转换器实例
converter = RadicalConverter()

# 转换文本
result = converter.convert('⻩金⻌在⻨田')

# 分析文本
analysis = converter.analyze_text('⻩金⻌在⻨田')
for item in analysis:
    print(f"位置{item['position']}: {item['radical']} -> {item['maps_to']}")

# 添加自定义映射
converter.add_mapping('⚡', '闪')
print(converter.convert('⚡光'))  # 输出: 闪光
```

### 转换方法

```python
from unicode_radical_converter import convert

text = '⻩金时代'

# 自动转换（先尝试Unicode标准化，再使用映射表）
print(convert(text, method='auto'))

# 仅使用映射表
print(convert(text, method='mapping_only'))

# 仅使用Unicode标准化
print(convert(text, method='normalize_only'))
```

## 支持的部首

本工具支持多种类型的部首：

1. **CJK部首补充** (U+2E80-U+2EFF)
   - 例：⻩ (黄), ⻌ (走), ⻨ (麦)

2. **康熙部首** (U+2F00-U+2FDF)
   - 例：⾚ (赤), ⾨ (門), ⾛ (走)

3. **CJK简化部首**
   - 例：⻬ (黑), ⻭ (黹)

## API 参考

### 函数接口

- `convert(text, method='auto')` - 转换文本
- `convert_batch(text_list, method='auto')` - 批量转换
- `analyze_text(text)` - 分析文本中的部首
- `is_radical(char)` - 检查是否是部首
- `add_mapping(radical, hanzi)` - 添加映射

### 类接口

- `RadicalConverter` - 核心转换器类
- `MappingStrategy` - 映射策略类

## 贡献

欢迎贡献代码！请遵循以下步骤：

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开 Pull Request

### 开发环境设置

```bash
# 克隆仓库
git clone https://github.com/yourusername/unicode-radical-converter.git
cd unicode-radical-converter

# 创建虚拟环境
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 安装开发依赖
pip install -e ".[dev]"

# 运行测试
pytest

# 代码格式化
black unicode_radical_converter tests
```

## 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 更新日志

### v0.1.0 (2024-01-01)
- 初始版本发布
- 支持基本的部首转换功能
- 提供Python API和命令行工具
- 包含完整的测试套件

## 致谢

- Unicode标准中的CJK部首定义
- 康熙部首系统
- 所有贡献者和用户的支持

## 联系方式

- 项目主页: https://github.com/Ayjc/unicode-radical-converter
- 问题反馈: https://github.com/Ayjc/unicode-radical-converter/issues
- 邮箱: yuanjc20011223@gmail.com
