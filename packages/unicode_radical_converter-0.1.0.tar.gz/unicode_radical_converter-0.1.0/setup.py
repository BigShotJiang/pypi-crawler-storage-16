"""
setup.py - 兼容旧版pip的安装脚本
"""

from setuptools import setup

# 主要配置在pyproject.toml中
setup()