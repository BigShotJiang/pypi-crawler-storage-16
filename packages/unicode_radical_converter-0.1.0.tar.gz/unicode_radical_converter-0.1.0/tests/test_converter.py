"""
测试转换器模块
"""

import unittest
import sys
import os

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from unicode_radical_converter.converter import RadicalConverter
from unicode_radical_converter.mappings import MappingStrategy


class TestRadicalConverter(unittest.TestCase):
    """测试RadicalConverter类"""

    def setUp(self):
        """测试前的准备"""
        self.converter = RadicalConverter()

    def test_basic_conversion(self):
        """测试基本转换功能"""
        test_cases = [
            ('⻩金时代', '黄金时代'),
            ('⻌向未来', '走向未来'),
            ('⻨田风光', '麦田风光'),
            ('⻬社会', '黑社会'),
            ('⾚胆忠心', '赤胆忠心'),
            ('⾨外汉', '门外汉'),
        ]

        for input_text, expected in test_cases:
            with self.subTest(input=input_text):
                result = self.converter.convert(input_text)
                self.assertEqual(result, expected)

    def test_no_conversion_needed(self):
        """测试不需要转换的情况"""
        text = '这是一段普通文本'
        result = self.converter.convert(text)
        self.assertEqual(result, text)

    def test_empty_text(self):
        """测试空文本"""
        self.assertEqual(self.converter.convert(''), '')
        self.assertEqual(self.converter.convert(None), '')

    def test_mixed_text(self):
        """测试混合文本（部首和普通字符混合）"""
        text = '⻩金在⻌路上'
        result = self.converter.convert(text)
        self.assertEqual(result, '黄金在走路上')

    def test_conversion_methods(self):
        """测试不同的转换方法"""
        text = '⻩金时代'

        # auto方法（默认）
        result_auto = self.converter.convert(text, method='auto')
        self.assertEqual(result_auto, '黄金时代')

        # mapping_only方法
        result_mapping = self.converter.convert(text, method='mapping_only')
        self.assertEqual(result_mapping, '黄金时代')

        # normalize_only方法（对部首通常无效）
        result_normalize = self.converter.convert(text, method='normalize_only')
        # 部首不会通过标准化转换，所以应该保持原样
        self.assertEqual(result_normalize, text)

    def test_batch_convert(self):
        """测试批量转换"""
        text_list = ['⻩金时代', '⻌向未来', '普通文本']
        result = self.converter.batch_convert(text_list)
        expected = ['黄金时代', '走向未来', '普通文本']
        self.assertEqual(result, expected)

    def test_is_radical(self):
        """测试is_radical方法"""
        self.assertTrue(self.converter.is_radical('⻩'))
        self.assertTrue(self.converter.is_radical('⻌'))
        self.assertFalse(self.converter.is_radical('黄'))
        self.assertFalse(self.converter.is_radical('A'))
        self.assertFalse(self.converter.is_radical('1'))

    def test_analyze_text(self):
        """测试文本分析功能"""
        text = '⻩金⻌在⻨田里'
        analysis = self.converter.analyze_text(text)

        self.assertEqual(len(analysis), 3)

        # 检查第一个部首
        self.assertEqual(analysis[0]['radical'], '⻩')
        self.assertEqual(analysis[0]['maps_to'], '黄')
        self.assertEqual(analysis[0]['position'], 0)

    def test_add_mapping(self):
        """测试添加映射"""
        # 测试新映射
        self.converter.add_mapping('⻢', '马')
        self.assertEqual(self.converter.convert('⻢车'), '马车')

        # 测试覆盖现有映射
        self.converter.add_mapping('⻩', 'X')
        self.assertEqual(self.converter.convert('⻩'), 'X')

    def test_remove_mapping(self):
        """测试移除映射"""
        # 确保映射存在
        self.assertTrue(self.converter.is_radical('⻩'))

        # 移除映射
        removed = self.converter.remove_mapping('⻩')
        self.assertEqual(removed, '黄')

        # 验证映射已被移除
        self.assertFalse(self.converter.is_radical('⻩'))

        # 测试移除不存在的映射
        none_result = self.converter.remove_mapping('⚡')
        self.assertIsNone(none_result)

    def test_get_mapping_info(self):
        """测试获取映射信息"""
        info = self.converter.get_mapping_info('⻩')

        self.assertEqual(info['character'], '⻩')
        self.assertEqual(info['unicode'], 'U+2EE9')
        self.assertTrue(info['is_radical'])
        self.assertEqual(info['maps_to'], '黄')
        self.assertIsNotNone(info['unicode_name'])

    def test_get_mapping_statistics(self):
        """测试获取映射统计"""
        stats = self.converter.get_mapping_statistics()

        self.assertIn('total_mappings', stats)
        self.assertIn('unique_hanzi', stats)
        self.assertIn('many_to_one', stats)
        self.assertGreater(stats['total_mappings'], 0)
        self.assertGreater(stats['unique_hanzi'], 0)

    def test_export_mappings(self):
        """测试导出映射"""
        # 测试dict格式
        dict_export = self.converter.export_mappings('dict')
        self.assertIsInstance(dict_export, dict)
        self.assertIn('⻩', dict_export)

        # 测试list格式
        list_export = self.converter.export_mappings('list')
        self.assertIsInstance(list_export, list)
        self.assertGreater(len(list_export), 0)

        # 测试json格式
        json_export = self.converter.export_mappings('json')
        self.assertIsInstance(json_export, str)
        self.assertIn('⻩', json_export)

    def test_lazy_initialization(self):
        """测试延迟初始化"""
        lazy_converter = RadicalConverter(lazy_init=True)

        # 初始时mappings应该为空
        self.assertEqual(len(lazy_converter.mappings), 0)

        # 使用功能时应该自动初始化
        result = lazy_converter.convert('⻩')
        self.assertEqual(result, '黄')
        self.assertGreater(len(lazy_converter.mappings), 0)


class TestMappingStrategy(unittest.TestCase):
    """测试MappingStrategy类"""

    def setUp(self):
        """测试前的准备"""
        self.strategy = MappingStrategy()

    def test_generate_all_mappings(self):
        """测试生成所有映射"""
        mappings = self.strategy.generate_all_mappings()
        self.assertIsInstance(mappings, dict)
        self.assertGreater(len(mappings), 0)

    def test_is_radical_character(self):
        """测试判断是否为部首字符"""
        self.assertTrue(self.strategy.is_radical_character('⻩'))
        self.assertTrue(self.strategy.is_radical_character('⻌'))
        self.assertFalse(self.strategy.is_radical_character('黄'))
        self.assertFalse(self.strategy.is_radical_character('A'))

    def test_get_unicode_info(self):
        """测试获取Unicode信息"""
        info = self.strategy.get_unicode_info('⻩')

        self.assertEqual(info['character'], '⻩')
        self.assertEqual(info['code_point'], 0x2EE9)
        self.assertTrue(info['is_radical'])
        self.assertIsNotNone(info['name'])


if __name__ == '__main__':
    unittest.main()