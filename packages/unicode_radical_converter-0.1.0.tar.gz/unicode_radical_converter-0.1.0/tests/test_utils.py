"""
测试工具函数模块
"""

import unittest
import sys
import os

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from unicode_radical_converter.utils import (
    convert, convert_batch, analyze_text, is_radical,
    get_radical_info, list_radicals, add_mapping,
    normalize_unicode
)


class TestUtils(unittest.TestCase):
    """测试工具函数"""

    def test_convert(self):
        """测试convert函数"""
        self.assertEqual(convert('⻩金时代'), '黄金时代')
        self.assertEqual(convert('⻌向未来'), '走向未来')
        self.assertEqual(convert('普通文本'), '普通文本')
        self.assertEqual(convert(''), '')

    def test_convert_with_method(self):
        """测试带方法的convert函数"""
        text = '⻩金时代'
        self.assertEqual(convert(text, method='auto'), '黄金时代')
        self.assertEqual(convert(text, method='mapping_only'), '黄金时代')

    def test_convert_batch(self):
        """测试批量转换"""
        text_list = ['⻩金时代', '⻌向未来', '普通文本']
        result = convert_batch(text_list)
        expected = ['黄金时代', '走向未来', '普通文本']
        self.assertEqual(result, expected)

    def test_analyze_text(self):
        """测试文本分析"""
        text = '⻩金⻌在⻨田'
        analysis = analyze_text(text)

        self.assertIsInstance(analysis, list)
        self.assertEqual(len(analysis), 3)

        # 检查返回的结构
        for item in analysis:
            self.assertIn('position', item)
            self.assertIn('radical', item)
            self.assertIn('maps_to', item)
            self.assertIn('unicode', item)

    def test_is_radical(self):
        """测试is_radical函数"""
        self.assertTrue(is_radical('⻩'))
        self.assertTrue(is_radical('⻌'))
        self.assertFalse(is_radical('黄'))
        self.assertFalse(is_radical('A'))

    def test_get_radical_info(self):
        """测试get_radical_info函数"""
        info = get_radical_info('⻩')

        self.assertIsInstance(info, dict)
        self.assertEqual(info['character'], '⻩')
        self.assertTrue(info['is_radical'])
        self.assertEqual(info['maps_to'], '黄')

    def test_list_radicals(self):
        """测试list_radicals函数"""
        radicals = list_radicals()

        self.assertIsInstance(radicals, dict)
        self.assertGreater(len(radicals), 0)
        self.assertIn('⻩', radicals)

    def test_add_mapping(self):
        """测试add_mapping函数"""
        # 添加一个测试映射
        add_mapping('⚡', '闪')

        # 验证映射已添加
        self.assertTrue(is_radical('⚡'))
        self.assertEqual(convert('⚡光'), '闪光')

    def test_normalize_unicode(self):
        """测试Unicode标准化函数"""
        # 测试NFC
        text = 'é'  # e + combining acute
        normalized = normalize_unicode(text, 'NFC')
        self.assertNotEqual(normalized, text)

        # 测试无效的标准化形式
        with self.assertRaises(ValueError):
            normalize_unicode('test', 'INVALID')

    def test_global_converter_persistence(self):
        """测试全局转换器的持久性"""
        # 添加映射到全局转换器
        add_mapping('☁', '云')

        # 验证映射在后续调用中仍然存在
        self.assertEqual(convert('☁️白'), '云白')


if __name__ == '__main__':
    unittest.main()