"""
Unicode Radical Converter - 智能Unicode部首转换工具

这个包提供了一个智能的工具，用于将Unicode中的CJK（中日韩）部首字符
转换为对应的完整汉字。它使用多种策略自动识别和转换部首。

主要功能：
- 自动识别Unicode部首字符
- 基于Unicode名称的智能映射
- 支持多种标准化形式
- 可扩展的映射系统
- 命令行工具

基本用法：
    >>> from unicode_radical_converter import convert
    >>> convert('⻩金时代')
    '黄金时代'

    >>> from unicode_radical_converter import RadicalConverter
    >>> converter = RadicalConverter()
    >>> converter.convert('⻌向未来')
    '走向未来'
"""

from .converter import RadicalConverter
from .utils import convert, analyze_text

__version__ = "0.1.0"
__author__ = "Alex Yuan"
__email__ = "alexyuan@example.com"

__all__ = [
    'RadicalConverter',
    'convert',
    'analyze_text',
    '__version__',
]