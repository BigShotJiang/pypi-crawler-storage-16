"""
命令行接口模块

提供命令行工具，方便在终端中使用Unicode部首转换功能。
"""

import argparse
import sys
import json
from typing import Optional
from .converter import RadicalConverter
from .utils import convert, analyze_text


def create_parser() -> argparse.ArgumentParser:
    """创建命令行参数解析器"""
    parser = argparse.ArgumentParser(
        prog='unicode-radical-converter',
        description='智能Unicode部首转换工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 转换文本中的部首
  urc convert "⻩金时代"

  # 从文件读取并转换
  urc convert -f input.txt -o output.txt

  # 分析文本中的部首
  urc analyze "⻩⻌⻨⻬"

  # 查看所有映射
  urc list

  # 检查字符是否是部首
  urc check "⻩"
        """
    )

    subparsers = parser.add_subparsers(dest='command', help='可用命令')

    # convert命令
    convert_parser = subparsers.add_parser(
        'convert',
        help='转换文本中的Unicode部首'
    )
    convert_parser.add_argument(
        'text',
        nargs='?',
        help='要转换的文本（如果不提供，需要使用-f选项）'
    )
    convert_parser.add_argument(
        '-f', '--file',
        type=str,
        help='输入文件路径'
    )
    convert_parser.add_argument(
        '-o', '--output',
        type=str,
        help='输出文件路径（默认输出到标准输出）'
    )
    convert_parser.add_argument(
        '-m', '--method',
        choices=['auto', 'normalize_only', 'mapping_only', 'nfkc', 'nfkd', 'nfc', 'nfd'],
        default='auto',
        help='转换方法（默认: auto）'
    )

    # analyze命令
    analyze_parser = subparsers.add_parser(
        'analyze',
        help='分析文本中的部首'
    )
    analyze_parser.add_argument(
        'text',
        nargs='?',
        help='要分析的文本（如果不提供，需要使用-f选项）'
    )
    analyze_parser.add_argument(
        '-f', '--file',
        type=str,
        help='输入文件路径'
    )
    analyze_parser.add_argument(
        '-j', '--json',
        action='store_true',
        help='以JSON格式输出'
    )

    # check命令
    check_parser = subparsers.add_parser(
        'check',
        help='检查字符是否是部首'
    )
    check_parser.add_argument(
        'character',
        help='要检查的字符'
    )
    check_parser.add_argument(
        '-j', '--json',
        action='store_true',
        help='以JSON格式输出详细信息'
    )

    # list命令
    list_parser = subparsers.add_parser(
        'list',
        help='列出所有已知的部首映射'
    )
    list_parser.add_argument(
        '-j', '--json',
        action='store_true',
        help='以JSON格式输出'
    )
    list_parser.add_argument(
        '-c', '--count',
        action='store_true',
        help='只显示映射数量'
    )

    # add命令
    add_parser = subparsers.add_parser(
        'add',
        help='添加新的部首映射'
    )
    add_parser.add_argument(
        'radical',
        help='部首字符'
    )
    add_parser.add_argument(
        'hanzi',
        help='对应的汉字'
    )

    # stats命令
    stats_parser = subparsers.add_parser(
        'stats',
        help='显示映射统计信息'
    )

    return parser


def handle_convert(args) -> None:
    """处理convert命令"""
    # 获取输入文本
    if args.file:
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                text = f.read()
        except Exception as e:
            print(f"错误：无法读取文件 {args.file}: {e}", file=sys.stderr)
            sys.exit(1)
    elif args.text:
        text = args.text
    else:
        print("错误：必须提供文本或使用-f选项指定文件", file=sys.stderr)
        sys.exit(1)

    # 转换文本
    result = convert(text, args.method)

    # 输出结果
    if args.output:
        try:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(result)
            print(f"转换结果已保存到: {args.output}")
        except Exception as e:
            print(f"错误：无法写入文件 {args.output}: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        print(result)


def handle_analyze(args) -> None:
    """处理analyze命令"""
    # 获取输入文本
    if args.file:
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                text = f.read()
        except Exception as e:
            print(f"错误：无法读取文件 {args.file}: {e}", file=sys.stderr)
            sys.exit(1)
    elif args.text:
        text = args.text
    else:
        print("错误：必须提供文本或使用-f选项指定文件", file=sys.stderr)
        sys.exit(1)

    # 分析文本
    radicals = analyze_text(text)

    if not radicals:
        print("文本中未发现已知的部首")
        return

    # 输出结果
    if args.json:
        print(json.dumps(radicals, ensure_ascii=False, indent=2))
    else:
        print(f"发现 {len(radicals)} 个部首:")
        for r in radicals:
            print(f"\n位置 {r['position']}:")
            print(f"  部首: {r['radical']} ({r['unicode']})")
            print(f"  映射到: {r['maps_to']}")
            print(f"  上下文: ...{r['context']}...")


def handle_check(args) -> None:
    """处理check命令"""
    if len(args.character) != 1:
        print("错误：请提供单个字符", file=sys.stderr)
        sys.exit(1)

    converter = RadicalConverter()
    info = converter.get_mapping_info(args.character)

    if args.json:
        print(json.dumps(info, ensure_ascii=False, indent=2))
    else:
        print(f"字符: {info['character']} ({info['unicode']})")
        if info['unicode_name']:
            print(f"Unicode名称: {info['unicode_name']}")
        print(f"是部首: {'是' if info['is_radical'] else '否'}")
        if info['maps_to']:
            print(f"映射到: {info['maps_to']}")
        if info['maps_from']:
            print(f"是以下部首的映射目标: {info['maps_from']}")


def handle_list(args) -> None:
    """处理list命令"""
    converter = RadicalConverter()
    mappings = converter.mappings

    if args.count:
        print(f"共有 {len(mappings)} 个部首映射")
        return

    if args.json:
        print(json.dumps(mappings, ensure_ascii=False, indent=2))
    else:
        print(f"部首映射列表 (共 {len(mappings)} 个):")
        for radical, hanzi in sorted(mappings.items()):
            print(f"  {radical} ({f'U+{ord(radical):04X}'}) -> {hanzi} ({f'U+{ord(hanzi):04X}'})")


def handle_add(args) -> None:
    """处理add命令"""
    if len(args.radical) != 1 or len(args.hanzi) != 1:
        print("错误：部首和汉字都必须是单个字符", file=sys.stderr)
        sys.exit(1)

    converter = RadicalConverter()
    converter.add_mapping(args.radical, args.hanzi)
    print(f"已添加映射: {args.radical} -> {args.hanzi}")


def handle_stats(args) -> None:
    """处理stats命令"""
    converter = RadicalConverter()
    stats = converter.get_mapping_statistics()

    print("映射统计信息:")
    print(f"  总映射数: {stats['total_mappings']}")
    print(f"  唯一汉字数: {stats['unique_hanzi']}")

    if stats['many_to_one']:
        print("\n多对一映射（多个部首映射到同一汉字）:")
        for hanzi, radicals in stats['many_to_one'].items():
            print(f"  {hanzi}: {', '.join(radicals)}")


def main() -> None:
    """主函数"""
    parser = create_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    try:
        if args.command == 'convert':
            handle_convert(args)
        elif args.command == 'analyze':
            handle_analyze(args)
        elif args.command == 'check':
            handle_check(args)
        elif args.command == 'list':
            handle_list(args)
        elif args.command == 'add':
            handle_add(args)
        elif args.command == 'stats':
            handle_stats(args)
    except KeyboardInterrupt:
        print("\n操作已取消", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"错误：{e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()