"""
核心转换器模块

实现了Unicode部首到汉字的智能转换逻辑。
"""

import unicodedata
from typing import Dict, List, Any, Optional, Tuple
from .mappings import MappingStrategy


class RadicalConverter:
    """
    Unicode部首转换器

    这个类提供了将Unicode中的CJK部首字符转换为对应完整汉字的功能。
    它使用多种策略自动识别和转换部首。

    Attributes:
        mappings: 部首到汉字的映射字典
        mapping_strategy: 映射策略实例
    """

    def __init__(self, lazy_init: bool = False):
        """
        初始化转换器

        Args:
            lazy_init: 是否延迟初始化映射表（True时在首次使用时才生成）
        """
        self.mappings: Dict[str, str] = {}
        self.mapping_strategy = MappingStrategy()

        if not lazy_init:
            self._initialize_mappings()

    def _initialize_mappings(self) -> None:
        """初始化映射表"""
        self.mappings = self.mapping_strategy.generate_all_mappings()

    def convert(self, text: str, method: str = 'auto') -> str:
        """
        转换文本中的部首

        Args:
            text: 要转换的文本
            method: 转换方法
                - 'auto': 自动（先尝试Unicode标准化，再使用映射表）
                - 'normalize_only': 仅使用Unicode标准化
                - 'mapping_only': 仅使用映射表
                - 'nfkc', 'nfkd': 指定标准化形式

        Returns:
            转换后的文本
        """
        if not text:
            return text

        # 确保映射表已初始化
        if not self.mappings:
            self._initialize_mappings()

        result = []

        for char in text:
            converted = self._convert_char(char, method)
            result.append(converted)

        return ''.join(result)

    def _convert_char(self, char: str, method: str) -> str:
        """转换单个字符"""
        if method in ['auto', 'nfkc', 'nfkd', 'nfc', 'nfd']:
            # 首先尝试Unicode标准化
            form = method.upper() if method != 'auto' else 'NFKC'
            normalized = unicodedata.normalize(form, char)
            if normalized != char:
                return normalized

        if method in ['auto', 'mapping_only']:
            # 然后尝试映射表
            if char in self.mappings:
                return self.mappings[char]

        # 保持原样
        return char

    def batch_convert(self, text_list: List[str], method: str = 'auto') -> List[str]:
        """
        批量转换文本

        Args:
            text_list: 文本列表
            method: 转换方法

        Returns:
            转换后的文本列表
        """
        return [self.convert(text, method) for text in text_list]

    def analyze_text(self, text: str) -> List[Dict[str, Any]]:
        """
        分析文本中的部首

        Args:
            text: 要分析的文本

        Returns:
            包含部首信息的字典列表，每个字典包含：
                - position: 位置
                - radical: 部首字符
                - unicode: Unicode码位
                - maps_to: 映射到的汉字
                - context: 上下文（前后各5个字符）
        """
        if not text:
            return []

        # 确保映射表已初始化
        if not self.mappings:
            self._initialize_mappings()

        radicals_found = []

        for i, char in enumerate(text):
            if char in self.mappings:
                info = {
                    'position': i,
                    'radical': char,
                    'unicode': f'U+{ord(char):04X}',
                    'maps_to': self.mappings[char],
                    'context': text[max(0, i-5):i+6]
                }
                radicals_found.append(info)

        return radicals_found

    def is_radical(self, char: str) -> bool:
        """检查字符是否是已知的部首"""
        if not self.mappings:
            self._initialize_mappings()
        return char in self.mappings

    def get_mapping_info(self, char: str) -> Dict[str, Any]:
        """
        获取字符的映射信息

        Args:
            char: 要查询的字符

        Returns:
            包含详细信息的字典
        """
        if not self.mappings:
            self._initialize_mappings()

        info = {
            'character': char,
            'unicode': f'U+{ord(char):04X}',
            'is_radical': char in self.mappings,
            'has_reverse_mapping': char in self.mappings.values(),
            'maps_to': self.mappings.get(char),
            'maps_from': None
        }

        # 查找反向映射
        if info['has_reverse_mapping']:
            for radical, hanzi in self.mappings.items():
                if hanzi == char:
                    info['maps_from'] = radical
                    break

        # 获取Unicode名称
        try:
            info['unicode_name'] = unicodedata.name(char)
        except ValueError:
            info['unicode_name'] = None

        return info

    def add_mapping(self, radical: str, hanzi: str) -> None:
        """
        添加新的映射

        Args:
            radical: 部首字符
            hanzi: 对应的汉字
        """
        if not radical or not hanzi:
            raise ValueError("Radical and hanzi cannot be empty")

        self.mappings[radical] = hanzi

    def remove_mapping(self, radical: str) -> Optional[str]:
        """
        移除映射

        Args:
            radical: 要移除的部首

        Returns:
            被移除的映射的汉字，如果不存在返回None
        """
        return self.mappings.pop(radical, None)

    def get_mapping_statistics(self) -> Dict[str, Any]:
        """
        获取映射表的统计信息

        Returns:
            包含统计信息的字典
        """
        if not self.mappings:
            self._initialize_mappings()

        stats = {
            'total_mappings': len(self.mappings),
            'unique_hanzi': len(set(self.mappings.values())),
            'one_to_many': {},  # 一个部首对应多个汉字（虽然我们的实现不支持）
            'many_to_one': {},  # 多个部首对应一个汉字
        }

        # 统计多对一映射
        reverse_map = {}
        for radical, hanzi in self.mappings.items():
            if hanzi not in reverse_map:
                reverse_map[hanzi] = []
            reverse_map[hanzi].append(radical)

        for hanzi, radicals in reverse_map.items():
            if len(radicals) > 1:
                stats['many_to_one'][hanzi] = radicals

        return stats

    def export_mappings(self, format: str = 'dict') -> Any:
        """
        导出映射表

        Args:
            format: 导出格式 ('dict', 'list', 'json')

        Returns:
            导出的映射数据
        """
        if format == 'dict':
            return self.mappings.copy()
        elif format == 'list':
            return [
                {
                    'radical': radical,
                    'hanzi': hanzi,
                    'radical_unicode': f'U+{ord(radical):04X}',
                    'hanzi_unicode': f'U+{ord(hanzi):04X}'
                }
                for radical, hanzi in sorted(self.mappings.items())
            ]
        elif format == 'json':
            import json
            return json.dumps(self.mappings, ensure_ascii=False, indent=2)
        else:
            raise ValueError(f"Unsupported export format: {format}")