"""
映射数据和策略模块

包含各种映射策略和预设的映射数据。
"""

import unicodedata
from typing import Dict, List, Tuple


class MappingStrategy:
    """映射策略类，负责生成和管理部首到汉字的映射"""

    # CJK部首的Unicode范围
    RADICAL_RANGES = [
        (0x2E80, 0x2EFF),  # CJK Radicals Supplement
        (0x2F00, 0x2FDF),  # Kangxi Radicals
        (0x31C0, 0x31EF),  # CJK Strokes
        (0x2FF0, 0x2FFF),  # Ideographic Description Characters
    ]

    # 基于Unicode名称的模式映射
    NAME_PATTERNS = {
        'CJK RADICAL SIMPLIFIED': {
            'YELLOW': '黄',
            'WALK': '走',
            'EAT': '食',
            'GHOST': '鬼',
            'RAIN': '雨',
            'BLUE': '青',
            'TOOTH': '齿',
            'FROG': '黾',
            'TRIPOD': '鼎',
            'DRUM': '鼓',
            'RAT': '鼠',
            'HORSE': '马',
            'BONE': '骨',
            'FISH': '鱼',
            'BIRD': '鸟',
            'SALT': '卤',
            'WHEAT': '麦',
            'HEMP': '麻',
            'MILLET': '黍',
            'BLACK': '黑',
            'THREAD': '丝',
            'SNAIL': '虫',
            'TALK': '言',
            'KNIFE': '刀',
            'BOX': '口',
            'TABLE': '几',
            'SEAL': '卩',
            'LAME': '止',
            'SMALL': '小',
            'SECOND': '二',
            'DIVINATION': '卜',
            'CLIFF': '厂',
            'REPEAT': '彳',
        },
        'CJK RADICAL C-SIMPLIFIED': {
            'EVEN': '黑',
            'HALF': '半',
            'NINE': '九',
            'FOUR': '四',
            'FOOT': '足',
            'RIVER': '川',
            'MOUND': '土',
            'CORPSE': '尸',
            'SLOW': '彡',
            'ROPE': '糸',
            'COMPANY': '阝',
            'CITY': '邑',
        },
        'CJK RADICAL J-SIMPLIFIED': {
            'TOOTH': '歯',
            'EAT': '食',
            'RIVER': '川',
            'GOLD': '金',
            'FISH': '魚',
            'BIRD': '鳥',
            'HORSE': '馬',
            'OLD': '老',
            'COMPANY': '阝',
            'CITY': '邑',
        },
    }

    # 康熙部首214个
    KANGXI_RADICALS = {
        '⾀': '一',  # 1
        '⾁': '丨',  # 2
        '⾂': '丿',  # 3
        '⾃': '丶',  # 4
        '⾄': '乙',  # 5
        '⾅': '亅',  # 6
        '⾆': '二',  # 7
        '⾇': '亠',  # 8
        '⾈': '人',  # 9
        '⾉': '儿',  # 10
        '⾊': '入',  # 11
        '⾋': '八',  # 12
        '⾌': '冂',  # 13
        '⾍': '冖',  # 14
        '⾎': '冫',  # 15
        '⾏': '几',  # 16
        '⾐': '凵',  # 17
        '⾑': '刀',  # 18
        '⾒': '力',  # 19
        '⾓': '勹',  # 20
        '⾔': '匕',  # 21
        '⾕': '匚',  # 22
        '⾖': '匸',  # 23
        '⾗': '十',  # 24
        '⾘': '卜',  # 25
        '⾙': '卩',  # 26
        '⾚': '厂',  # 27
        '⾛': '厶',  # 28
        '⾜': '又',  # 29
        '⾝': '口',  # 30
        '⾟': '囗',  # 31
        '⾠': '土',  # 32
        '⾡': '士',  # 33
        '⾢': '夂',  # 34
        '⾣': '夊',  # 35
        '⾤': '夕',  # 36
        '⾥': '大',  # 37
        '⾦': '女',  # 38
        '⾧': '子',  # 39
        '⾨': '宀',  # 40
        '⾩': '寸',  # 41
        '⾪': '小',  # 42
        '⾫': '尢',  # 43
        '⾬': '尸',  # 44
        '⾭': '屮',  # 45
        '⾮': '山',  # 46
        '⾯': '川',  # 47
        '⾰': '工',  # 48
        '⾱': '己',  # 49
        '⾲': '巾',  # 50
        '⾳': '干',  # 51
        '⾴': '幺',  # 52
        '⾵': '广',  # 53
        '⾶': '廴',  # 54
        '⾷': '廾',  # 55
        '⾸': '弋',  # 56
        '⾹': '弓',  # 57
        '⾺': '彐',  # 58
        '⾻': '彡',  # 59
        '⾼': '彳',  # 60
        '⾽': '心',  # 61
        '⾾': '戈',  # 62
        '⾿': '户',  # 63
        '⿀': '手',  # 64
        '⿁': '支',  # 65
        '⿂': '攴',  # 66
        '⿃': '文',  # 67
        '⿄': '斗',  # 68
        '⿅': '斤',  # 69
        '⿆': '方',  # 70
        '⿇': '无',  # 71
        '⿈': '曰',  # 72
        '⿉': '日',  # 73
        '⿊': '月',  # 74
        '⿋': '木',  # 75
        '⿌': '欠',  # 76
        '⿍': '止',  # 77
        '⿎': '歹',  # 78
        '⿏': '殳',  # 79
        '⿐': '毋',  # 80
        '⿑': '比',  # 81
        '⿒': '毛',  # 82
        '⿓': '氏',  # 83
        '⿔': '气',  # 84
        '⿕': '水',  # 85
        '⿖': '火',  # 86
        '⿗': '爪',  # 87
        '⿘': '父',  # 88
        '⿙': '爻',  # 89
        '⿚': '片',  # 90
        '⿛': '牙',  # 91
        '⿜': '牛',  # 92
        '⿝': '犬',  # 93
        '⿞': '玄',  # 94
        '⿟': '玉',  # 95
        '⿠': '瓜',  # 96
        '⿡': '瓦',  # 97
        '⿢': '甘',  # 98
        '⿣': '生',  # 99
        '⿤': '用',  # 100
        '⿥': '田',  # 101
        '⿦': '疋',  # 102
        '⿧': '疒',  # 103
        '⿨': '癶',  # 104
        '⿩': '白',  # 105
        '⿪': '皮',  # 106
        '⿫': '皿',  # 107
        '⿬': '目',  # 108
        '⿭': '矛',  # 109
        '⿮': '矢',  # 110
        '⿯': '石',  # 111
        '⿰': '示',  # 112
        '⿱': '禸',  # 113
        '⿲': '禾',  # 114
        '⿳': '穴',  # 115
        '⿴': '立',  # 116
        '⿵': '竹',  # 117
        '⿶': '米',  # 118
        '⿷': '糸',  # 119
        '⿸': '缶',  # 120
        '⿹': '网',  # 121
        '⿺': '羊',  # 122
        '⿻': '羽',  # 123
        '⿼': '老',  # 124
        '⿽': '而',  # 125
        '⿾': '耒',  # 126
        '⿿': '耳',  # 127
        '豈': '聿',  # 128
        '更': '肉',  # 129
        '車': '臣',  # 130
        '賈': '自',  # 131
        '滑': '至',  # 132
        '串': '臼',  # 133
        '句': '舌',  # 134
        '龜': '舛',  # 135
        '龜': '舟',  # 136
        '契': '艮',  # 137
        '金': '色',  # 138
        '喇': '艸',  # 139
        '奈': '虍',  # 140
        '懶': '虫',  # 141
        '癩': '血',  # 142
        '羅': '行',  # 143
        '蘿': '衣',  # 144
        '螺': '襾',  # 145
    }

    # CJK部首补充（U+2EE9等）
    CJK_RADICAL_SUPPLEMENT = {
        '⻩': '黄',  # U+2EE9
        '⻌': '走',  # U+2ECC
        '⻍': '走',  # U+2ECD
        '⻎': '走',  # U+2ECE
        '⻏': '走',  # U+2ECF
        '⻐': '走',  # U+2ED0
        '⻑': '走',  # U+2ED1
        '⻒': '走',  # U+2ED2
        '⻓': '長',  # U+2ED3
        '⻔': '門',  # U+2ED4
        '⻕': '門',  # U+2ED5
        '⻖': '門',  # U+2ED6
        '⻗': '雨',  # U+2ED7
        '⻘': '青',  # U+2ED8
        '⻙': '食',  # U+2ED9
        '⻚': '食',  # U+2EDA
        '⻛': '食',  # U+2EDB
        '⻜': '食',  # U+2EDC
        '⻝': '齿',  # U+2EDD
        '⻞': '黾',  # U+2EDE
        '⻟': '鼎',  # U+2EDF
        '⻠': '鼓',  # U+2EE0
        '⻡': '鼠',  # U+2EE1
        '⻢': '马',  # U+2EE2
        '⻣': '骨',  # U+2EE3
        '⻤': '鬼',  # U+2EE4
        '⻥': '鱼',  # U+2EE5
        '⻦': '鸟',  # U+2EE6
        '⻧': '卤',  # U+2EE7
        '⻨': '麦',  # U+2EE8
        '⻩': '黄',  # U+2EE9 (重复，确保)
        '⻪': '麻',  # U+2EEA
        '⻫': '黍',  # U+2EEB
        '⻬': '黑',  # U+2EEC
        '⻭': '黹',  # U+2EED
        '⻮': '黾',  # U+2EEE
        '⻯': '鼎',  # U+2EEF
        '⻰': '鼓',  # U+2EF0
        '⻱': '鼠',  # U+2EF1
        '⻲': '鼻',  # U+2EF2
        '⻳': '齐',  # U+2EF3
    }

    def generate_all_mappings(self) -> Dict[str, str]:
        """生成所有映射"""
        mappings = {}

        # 1. 基于Unicode名称的映射
        name_mappings = self._generate_from_unicode_names()
        mappings.update(name_mappings)

        # 2. 康熙部首映射
        mappings.update(self.KANGXI_RADICALS)

        # 3. CJK部首补充映射
        mappings.update(self.CJK_RADICAL_SUPPLEMENT)

        return mappings

    def _generate_from_unicode_names(self) -> Dict[str, str]:
        """基于Unicode字符名称生成映射"""
        mappings = {}

        for start, end in self.RADICAL_RANGES:
            for code in range(start, end + 1):
                try:
                    char = chr(code)
                    name = unicodedata.name(char)

                    # 检查是否匹配任何模式
                    for pattern, mapping in self.NAME_PATTERNS.items():
                        if pattern in name:
                            for en, zh in mapping.items():
                                if en in name:
                                    mappings[char] = zh
                                    break
                except ValueError:
                    continue

        return mappings

    def get_radical_by_unicode(self, code_point: int) -> str:
        """通过Unicode码位获取字符"""
        return chr(code_point)

    def is_radical_character(self, char: str) -> bool:
        """检查字符是否在部首范围内"""
        code = ord(char)
        for start, end in self.RADICAL_RANGES:
            if start <= code <= end:
                return True
        return False

    def get_unicode_info(self, char: str) -> Dict[str, any]:
        """获取字符的Unicode信息"""
        try:
            return {
                'character': char,
                'code_point': ord(char),
                'unicode_hex': f'U+{ord(char):04X}',
                'name': unicodedata.name(char),
                'is_radical': self.is_radical_character(char),
                'category': unicodedata.category(char),
            }
        except ValueError:
            return {
                'character': char,
                'code_point': ord(char),
                'unicode_hex': f'U+{ord(char):04X}',
                'name': None,
                'is_radical': self.is_radical_character(char),
                'category': unicodedata.category(char),
            }