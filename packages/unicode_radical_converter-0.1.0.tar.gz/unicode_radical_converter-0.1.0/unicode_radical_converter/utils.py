"""
工具函数模块

提供便捷的函数接口，简化常见操作。
"""

import unicodedata
from typing import List, Dict, Any
from .converter import RadicalConverter

# 全局转换器实例
_default_converter = None

def _get_default_converter() -> RadicalConverter:
    """获取默认转换器实例（延迟初始化）"""
    global _default_converter
    if _default_converter is None:
        _default_converter = RadicalConverter()
    return _default_converter

def convert(text: str, method: str = 'auto') -> str:
    """
    转换文本中的Unicode部首为完整汉字

    Args:
        text: 要转换的文本
        method: 转换方法 ('auto', 'nfc', 'nfd', 'nfkc', 'nfkd')

    Returns:
        转换后的文本

    Example:
        >>> convert('⻩金时代')
        '黄金时代'
    """
    converter = _get_default_converter()
    return converter.convert(text, method)

def convert_batch(text_list: List[str], method: str = 'auto') -> List[str]:
    """
    批量转换文本

    Args:
        text_list: 文本列表
        method: 转换方法

    Returns:
        转换后的文本列表
    """
    converter = _get_default_converter()
    return converter.batch_convert(text_list, method)

def analyze_text(text: str) -> List[Dict[str, Any]]:
    """
    分析文本中的部首

    Args:
        text: 要分析的文本

    Returns:
        包含部首信息的字典列表

    Example:
        >>> analyze_text('⻩金时代')
        [{'position': 0, 'radical': '⻩', 'maps_to': '黄', ...}]
    """
    converter = _get_default_converter()
    return converter.analyze_text(text)

def is_radical(char: str) -> bool:
    """
    检查字符是否是已知的部首

    Args:
        char: 要检查的字符

    Returns:
        如果是部首返回True，否则返回False
    """
    converter = _get_default_converter()
    return converter.is_radical(char)

def get_radical_info(char: str) -> Dict[str, Any]:
    """
    获取字符的详细映射信息

    Args:
        char: 要查询的字符

    Returns:
        包含映射信息的字典
    """
    converter = _get_default_converter()
    return converter.get_mapping_info(char)

def list_radicals() -> Dict[str, str]:
    """
    列出所有已知的部首映射

    Returns:
        部首到汉字的映射字典
    """
    converter = _get_default_converter()
    return converter.mappings.copy()

def add_mapping(radical: str, hanzi: str) -> None:
    """
    添加新的部首映射（会影响全局默认转换器）

    Args:
        radical: 部首字符
        hanzi: 对应的汉字
    """
    converter = _get_default_converter()
    converter.add_mapping(radical, hanzi)

def normalize_unicode(text: str, form: str = 'NFKC') -> str:
    """
    Unicode标准化（独立函数）

    Args:
        text: 要标准化的文本
        form: 标准化形式 ('NFC', 'NFD', 'NFKC', 'NFKD')

    Returns:
        标准化后的文本
    """
    if form not in ['NFC', 'NFD', 'NFKC', 'NFKD']:
        raise ValueError(f"Invalid normalization form: {form}")
    return unicodedata.normalize(form, text)