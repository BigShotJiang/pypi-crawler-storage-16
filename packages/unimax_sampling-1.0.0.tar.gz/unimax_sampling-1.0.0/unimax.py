import argparse
from dataclasses import dataclass
import dataclasses
import sys
from collections.abc import Sequence
from pathlib import Path
import json

try:
    import polars as pl
    import datasets
except ImportError:
    pl = None
    Dataset = None


@dataclass
class UniMaxDistribution:
    """
    Represents the distribution of epochs and character budgets across languages.

    :param budgets: A mapping of language codes to their allocated budgets in characters.
    :param epochs: A mapping of language codes to their allocated number of epochs.
    :param probabilities: A mapping of language codes to their sampling probability relative to the total budget.
    """

    budgets: dict[str, int]
    epochs: dict[str, int]
    probabilities: dict[str, int]


# TODO: Citation
def unimax(
    language_counts: dict[str, int],
    character_budget: int,
    max_epochs: int,
    redistribute: list[str] | None = None,
) -> UniMaxDistribution:
    """
    Calculates an effective distribution of epochs across languages given a fixed character budget. Implements the UniMax algorithm proposed by Chung et al. (2023), with an additional optional budget redistribution feature to set an upper bound of one epoch for some languages while still utilizing the full budget.

    :param language_counts: A dictionary mapping language codes to their counts.
    :param character_budget: The fixed character budget for multilingual training.
    :param max_epochs: The maximum number of epochs allowed for any individual language.
    :param redistribute: A list of language codes that remaining characters above one epoch should be redistributed from. If set to `None`, the function is equivalent to the original UniMax algorithm.

    :return: A UniMaxDistribution object containing the calculated budgets, epochs, and probabilities.

    .. rubric:: References

    Hyung Won Chung, Xavier Garcia, Adam Roberts, Yi Tay, Orhan Firat, Sharan Narang, and Noah Constant. 2023. UniMax: Fairer and More Effective Language Sampling for Large-Scale Multilingual Pretraining. In The Eleventh International Conference on Learning Representations, ICLR 2023, Kigali, Rwanda.
    """
    languages = sorted(language_counts.items(), key=lambda item: item[1])
    remaining_budget = character_budget
    language_budgets = {}

    for index, (language, count) in enumerate(languages):
        budget_per_language = remaining_budget / (len(languages) - index)
        if budget_per_language > count * max_epochs:
            language_budgets[language] = budget = count * max_epochs
        else:
            language_budgets[language] = budget = budget_per_language

        remaining_budget -= budget

    if redistribute:
        remaining_budget = 0
        for language in redistribute:
            count = language_counts[language]
            budget = language_budgets[language]
            epochs = budget / count
            if epochs < 1:
                continue

            remaining_budget += budget - count
            language_budgets[language] = count

        remaining_languages = {
            language
            for language, budget in language_budgets.items()
            if budget / language_counts[language] < max_epochs
        } - set(redistribute)
        additional_budget = remaining_budget / len(remaining_languages)

        for language in remaining_languages:
            language_budgets[language] += additional_budget

    return UniMaxDistribution(
        language_budgets,
        {
            language: budget / language_counts[language]
            for language, budget in language_budgets.items()
        },
        {
            language: budget / character_budget
            for language, budget in language_budgets.items()
        },
    )


_BATCH_SIZE = 1_000_000


def count_characters(
    dataset_path: str,
    config: str | None = None,
    split: str = "train",
    text_key: str = "text",
) -> int:
    """
    Counts the number of characters in a text dataset.

    :param dataset_path: The path to the huggingface dataset on the HuggingFace Hub or on disk.
    :param config: An optional subset configuration of the dataset.
    :param split: The split to count (default is 'train').

    :return: The total number of characters in the given split
    """
    if pl is None or datasets is None:
        raise ImportError(
            "Polars and the datasets library are required to compute character counts. "
            "Install them with: pip install 'unimax_sampling[count]'"
        )

    dataset = datasets.load_dataset(dataset_path, config, split=split).select_columns(
        text_key
    )
    if not isinstance(dataset, datasets.Dataset):
        raise TypeError(
            f"Expected a Dataset instance for split {split!r} but got {type(dataset)!r}"
        )

    return int(
        sum(
            dataset.with_format("polars").map(
                lambda subset: subset.select(
                    characters=pl.col("text").str.len_chars().sum()  # pyright: ignore
                ),
                batched=True,
                num_proc=16,
                batch_size=_BATCH_SIZE,
            )["characters"]
        )
    )


def main(args: Sequence[str] | None = None):
    """
    Main entry point which executes one of the following sub-commands using the given arguments:
    - 'unimax': Calculates a fair distribution of epochs across languages given a fixed character budget using the UniMax sampling method.
    - 'count-characters': Counts the number of characters in a dataset.

    :param args: Command line arguments.
    """
    if args is None:
        args = sys.argv[1:]

    # TODO: Improve description
    parser = argparse.ArgumentParser(
        description="An implementation of the UniMax sampling method which allows calculating a balanced distribution across languages"
        " given a fixed character budget.\n\nReferences\n\n"
        "Hyung Won Chung, Noah Constant, Xavier Garcia, Adam Roberts, Yi Tay, Sharan Narang, and Orhan Firat. 2023. UniMax: Fairer and more Effective Language Sampling for Large-Scale Multilingual Pretraining."
    )
    subparsers = parser.add_subparsers(
        dest="mode", help="Available commands", required=True
    )

    count_description = "Count the number of characters in a dataset"
    count_parser = subparsers.add_parser(
        "count-characters",
        help=count_description,
        description=count_description,
    )
    count_parser.add_argument("dataset", help="A huggingface dataset")
    count_parser.add_argument(
        "language_code", help="ISO 639-3 code of the dataset language"
    )
    count_parser.add_argument(
        "output_file", type=Path, help="JSON file to save the number of characters in"
    )
    count_parser.add_argument(
        "-c", "--config", help="A subset configuration of the dataset"
    )
    count_parser.add_argument(
        "-s", "--split", default="train", help="The split to count"
    )
    count_parser.add_argument(
        "-t",
        "--text-key",
        default="text",
        help="Name of the text column in the dataset",
    )

    unimax_description = "Calculate a fair distribution of epochs across languages given a fixed character budget"
    max_parser = subparsers.add_parser(
        "unimax",
        help=unimax_description,
        description=unimax_description,
    )
    max_parser.add_argument(
        "character_count_files",
        nargs="+",
        help="JSON files in which the character count of each language are stored",
    )
    max_parser.add_argument(
        "-c",
        "--character-budget",
        required=True,
        type=int,
        help="Fixed character budget for the multilingual training run",
    )
    max_parser.add_argument(
        "-m",
        "--max-epochs",
        required=True,
        type=int,
        help="Maximum epochs allowed for any individual language",
    )
    max_parser.add_argument(
        "-r",
        "--redistribute",
        nargs="+",
        default=(),
        help="Equally redistribute remaining characters above 1 epoch from selected languages to other languages with less than maximum epochs",
    )
    max_parser.add_argument(
        "-o",
        "--output",
        type=argparse.FileType("x", encoding="utf-8"),
        default=sys.stdout,
        help="Output file for the number of epochs per language",
    )

    arguments = parser.parse_args(args)

    match arguments.mode:
        case "count-characters":
            character_count = count_characters(
                arguments.dataset,
                arguments.config,
                arguments.split,
                arguments.text_key,
            )
            with open(arguments.output_file, "w") as file:
                json.dump({arguments.language_code: character_count}, file)

        case "unimax":
            character_counts = {}
            for file_path in arguments.character_count_files:
                with open(file_path, "r", encoding="utf-8") as file:
                    character_counts.update(json.load(file))

            result = unimax(
                character_counts,
                arguments.character_budget,
                arguments.max_epochs,
                arguments.redistribute,
            )
            with arguments.output as output:
                json.dump(dataclasses.asdict(result), output)


if __name__ == "__main__":
    main()
