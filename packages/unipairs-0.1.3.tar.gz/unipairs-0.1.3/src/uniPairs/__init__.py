# pkgs/uniPairs/src/uniPairs/__init__.py
from .estimator import UniPairs
__all__ = ["UniPairs"]