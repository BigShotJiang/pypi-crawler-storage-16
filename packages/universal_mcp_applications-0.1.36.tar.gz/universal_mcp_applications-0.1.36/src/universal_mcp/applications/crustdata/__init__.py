from .app import CrustdataApp
