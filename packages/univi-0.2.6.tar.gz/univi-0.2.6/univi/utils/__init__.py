from .io import write_univi_latent

__all__ = [
    "write_univi_latent",
]