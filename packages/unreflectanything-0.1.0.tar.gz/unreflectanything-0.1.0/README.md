<div align="center">

<p>
<b>Alberto Rota<sup>1</sup>, Mert Kiray<sup>2,3</sup>, Mert Asim Karaoglu<sup>4,2</sup>, Patrick Ruhkamp<sup>2</sup>,<br>
Elena De Momi<sup>1</sup>, Nassir Navab<sup>2,3</sup>, Benjamin Busam<sup>2,3</sup></b><br>

<sup>1</sup>Politecnico di Milano &nbsp;&nbsp; <sup>2</sup>Technical University of Munich &nbsp;&nbsp; <sup>3</sup>Munich Center for Machine Learning (MCML) &nbsp;&nbsp; <sup>4</sup>ImFusion
</p> 

<p>
<a href="#" style="padding:12px 28px;background:linear-gradient(135deg, #667eea 0%, #764ba2 100%);color:#fff;border-radius:50px;text-decoration:none;margin:8px;display:inline-block;font-weight:600;box-shadow:0 4px 15px rgba(102, 126, 234, 0.4);transition:all 0.3s cubic-bezier(0.4, 0, 0.2, 1);position:relative;overflow:hidden;" onmouseover="this.style.transform='translateY(-4px) scale(1.05)';this.style.boxShadow='0 8px 25px rgba(102, 126, 234, 0.6)';this.style.background='linear-gradient(135deg, #764ba2 0%, #667eea 100%)'" onmouseout="this.style.transform='translateY(0) scale(1)';this.style.boxShadow='0 4px 15px rgba(102, 126, 234, 0.4)';this.style.background='linear-gradient(135deg, #667eea 0%, #764ba2 100%)'">📄 Paper</a> 
<a href="https://github.com/alberto-rota/UnReflectAnything" style="padding:12px 28px;background:linear-gradient(135deg, #11998e 0%, #38ef7d 100%);color:#fff;border-radius:50px;text-decoration:none;margin:8px;display:inline-block;font-weight:600;box-shadow:0 4px 15px rgba(17, 153, 142, 0.4);transition:all 0.3s cubic-bezier(0.4, 0, 0.2, 1);position:relative;overflow:hidden;" onmouseover="this.style.transform='translateY(-4px) scale(1.05)';this.style.boxShadow='0 8px 25px rgba(17, 153, 142, 0.6)';this.style.background='linear-gradient(135deg, #38ef7d 0%, #11998e 100%)'" onmouseout="this.style.transform='translateY(0) scale(1)';this.style.boxShadow='0 4px 15px rgba(17, 153, 142, 0.4)';this.style.background='linear-gradient(135deg, #11998e 0%, #38ef7d 100%)'">💻 Code</a>
</p> 

<img src="assets/header.png" alt="method overview" width="90%"/>

</div>
