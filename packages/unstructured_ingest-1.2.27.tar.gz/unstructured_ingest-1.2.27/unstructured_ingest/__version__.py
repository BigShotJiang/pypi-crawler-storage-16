__version__ = "1.2.27"  # pragma: no cover
