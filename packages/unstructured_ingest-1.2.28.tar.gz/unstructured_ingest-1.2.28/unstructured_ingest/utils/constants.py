# Used to append to metadata for uploaders that store element-level data
RECORD_ID_LABEL = "record_id"
