"""
main entrypoint when running python3 -m untext
"""

from untext.main import main

if __name__ == "__main__":
    main()
