"""Core tests package."""
