"""Training tests package."""
