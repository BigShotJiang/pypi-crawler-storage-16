"""Losses tests package."""
