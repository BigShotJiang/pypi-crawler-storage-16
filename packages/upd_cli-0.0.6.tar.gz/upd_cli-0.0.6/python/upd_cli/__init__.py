"""
upd-cli: A fast dependency updater for Python and Node.js projects.
"""

__version__ = "0.0.1"
