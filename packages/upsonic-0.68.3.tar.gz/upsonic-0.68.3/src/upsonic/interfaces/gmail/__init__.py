from upsonic.interfaces.gmail.gmail import GmailInterface
from upsonic.interfaces.gmail.schemas import CheckEmailsResponse

__all__ = ["GmailInterface", "CheckEmailsResponse"]

