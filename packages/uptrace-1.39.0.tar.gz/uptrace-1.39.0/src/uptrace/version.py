"""Uptrace distro version"""

__version__ = "1.39.0"
