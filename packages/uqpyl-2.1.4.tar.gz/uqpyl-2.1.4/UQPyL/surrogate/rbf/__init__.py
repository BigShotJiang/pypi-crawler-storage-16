from .kernel import Cubic, Linear, Multiquadric, ThinPlateSpline, Gaussian
from .radial_basis_function import RBF