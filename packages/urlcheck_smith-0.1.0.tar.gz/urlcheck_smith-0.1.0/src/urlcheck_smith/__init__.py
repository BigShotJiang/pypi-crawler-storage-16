# src/urlcheck_smith/data/__init__.py
"""
Data package for urlcheck-smith.

Contains YAML files for classification rules and presets.
"""
