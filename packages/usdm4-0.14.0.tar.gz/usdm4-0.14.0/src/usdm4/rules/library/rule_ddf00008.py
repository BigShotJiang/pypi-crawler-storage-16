from usdm3.rules.library.rule_ddf00008 import RuleDDF00008 as V3Rule


class RuleDDF00008(V3Rule):
    pass
