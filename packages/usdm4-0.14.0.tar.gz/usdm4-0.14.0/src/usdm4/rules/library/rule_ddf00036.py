from usdm3.rules.library.rule_ddf00036 import RuleDDF00036 as V3Rule


class RuleDDF00036(V3Rule):
    pass
