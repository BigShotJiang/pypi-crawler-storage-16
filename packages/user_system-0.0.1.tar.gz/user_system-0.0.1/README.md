# user_system 

A simple backend implementation for website user management.

GitHub repo: [https://github.com/GGN-2015/user_system](https://github.com/GGN-2015/user_system)

## Installation

```bash
pip install user_system
```

### Tables in the Database

1. (`user`) User List:

   1. (`user_id`) User ID (Primary Key): A string of alphanumeric characters (length ≥ 6, ≤ 32)

   2. (`passwd_md5`) User Password MD5: A lowercase hex hash digest string

   3. (`nickname`) User Nickname: A string of 32 characters (length ≤ 32)

   4. (`introduction`) User Profile: A string of 2000 characters (length ≤ 2000)

   5. (`is_admin`) Administrator Status

2. (`challenge`) Challenge Response Table:

   1. (`user_id`) User ID (Primary Key): A user can have at most one challenge

   2. (`create_time`) Application Time: Unix time stamp

   3. (`content`) Challenge Content: A random string of 32 characters (alphanumeric, ≤ 6)

   4. (`die_time`) Record Timeout: Unix time stamp

3. (`cookie_token`) Cookie-token Table:

   1. (`cookie_token`) Cookie-token Value (Primary Key)

   2. (`user_id`) User ID: A user can have multiple cookie-tokens. Cookie-token

   3. (`create_time`) Cookie-token Acquisition Time: Unix time stamp

   4. (`die_time`) Record Timeout Time: Unix time stamp

   5. (`use_time`) Record Last Use Time: Unix time stamp

4. (`invitation`) Invitation Code Table (for Registering Users):

   1. (`content`) Invitation Code (Primary Key): A random string of length 32 (alphanumeric underscores)

   2. (`die_time`) Timeout Time: Unix time stamp

   3. (`remain`) Remaining Uses: An integer greater than or equal to 1

### All Supported Operations

1. (`user_system.ope_new_usr`) Register a user using an invitation code (cookie-token not required)

   1. User selects their ID and password using MD5 hash

   2. User provides an invitation code (invitation code validity needs to be verified and uses deducted)

2. (`user_system.ope_ulist`) View all non-administrator user lists (cookie-token not required)

   1. Returns a user ID List

3. (`user_system.ope_see`) View the nickname and profile of a specified non-administrator user (no cookie-token required)

   1. Specify a user ID

   2. Returns two strings

4. (`user_system.ope_new_ch`) Request a challenge response (no cookie-token required)

   1. Specify a user ID

   2. The system will return the challenge content

5. (`user_system.ope_res_ch`) Answer a challenge response (no cookie-token required)

   1. Specify a user ID

   2. The system will return a cookie-token upon successful challenge

6. (`user_system.ope_logout`) Logout: (cookie-token required) Log out of a cookie-token

   1. Specify your own cookie-token

   2. Specify the cookie-token to be logged out

   3. Administrator users can log out of any cookie-token; regular users can only log out of their own user's cookie-token. Cookie-token

7. (`user_system.ope_tlist`) View all cookie-tokens for a specified user (cookie-token required)

   1. Specify your own cookie-token

   2. Specify the user ID

   3. Administrators can view any user's cookie-token; regular users can only view their own.

8. (`user_system.ope_chg_pwd`) Change password (cookie-token required):

   1. Specify your own cookie-token

   2. Specify the user ID

   3. Specify the MD5 hash digest of the new password (lowercase hex hash, verification required)

   4. Administrators can change anyone's password; regular users can only change their own.

9. (`user_system.ope_ch_nick`) Change nickname (cookie-token required)

   1. Specify your own cookie-token

   2. Specify the user ID

   3. Specify the new nickname (note length verification)

   4. Administrators can modify anyone's nickname; regular users can only modify their own nickname.

10. (`user_system.ope_ch_intro`) Modify Profile (Requires cookie-token)

    1. Specify your own cookie-token

    2. Specify your user ID

    3. Specify the new profile (note length validation)

    4. Administrators can modify anyone's profile; regular users can only modify their own profile.

11. (`user_system.ope_set_admin`) Set Administrator (Requires cookie-token)

    1. Specify your own cookie-token

    2. Specify your user ID

    3. Only administrators can set other users as administrators.

12. (`user_system.ope_unset_admin`) Unset Administrator (Requires cookie-token)

    1. Specify your own cookie-token

    2. Specify your user ID

    3. Only administrators can unset other users as administrators.

    4. Administrators cannot revoke their own administrator status.

13. (`user_system.ope_new_inv`) Add Invitation Code (Requires Cookie-token)

    1. Specify your own cookie-token

    2. Specify expiration time

    3. Specify the number of registrations that can be used

    4. Only administrators can add invitation codes.

14. (`user_system.ope_del_inv`) Delete Invitation Code (Requires Cookie-token)

    1. Specify your own cookie-token

    2. Specify the invitation code

    3. Only administrators can delete invitation codes.

15. (`user_system.ope_del_usr`) Delete User (Requires Cookie-token)

    1. Specify your own cookie-token

    2. Specify user ID

    3. Administrators can delete any non-administrator user; regular users can only delete their own users.

16. (`user_system.ope_ilist`) View Invitation Code List (Requires Cookie-token)

    1. Only administrators can view the invitation code list.

    2. You can see the content, remaining uses, and expiration time of each invitation code.