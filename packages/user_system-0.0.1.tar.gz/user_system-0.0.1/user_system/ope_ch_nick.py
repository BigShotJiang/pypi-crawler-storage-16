from .user_sql_system import connect_database, token_timeout, token_desc, user_exists, use_token

def ope_ch_nick(db_filepath:str, cookie_token:str, user_id:str, new_nick:str) -> bool:
    with connect_database(db_filepath) as conn:
        token_timeout(conn)
        is_admin, user_id_now = token_desc(conn, cookie_token)
        if user_id_now == "":
            print("not login")
            return False
        use_token(conn, cookie_token)

        if not user_exists(conn, user_id):
            print(f"user {user_id} not exists")
            return False
        
        if len(new_nick) <= 0 or len(new_nick) > 32:
            print(f"nickname length: {len(new_nick)} not allowed (1 ~ 32 char)")
            return False

        if is_admin or user_id_now == user_id:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE user
                SET nickname = ?
                WHERE user_id = ?;
            """, (new_nick, user_id))
            print("nickname changed")
            return True
        
        else:
            print("access not allowed")
            return False
