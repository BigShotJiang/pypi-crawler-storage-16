from .user_sql_system import connect_database, token_desc, token_timeout, user_exists, is_md5, use_token

# 修改用户口令
# 管理员可以修改任何人的口令
# 用户只能修改自己的口令
# 如果修改成功则返回 True
def ope_chg_pwd(db_filepath:str, cookie_token:str, user_id:str, new_pwd_md5:str) -> bool:
    with connect_database(db_filepath) as conn:

        # 删除过期 token
        token_timeout(conn)

        # 检查当前用户是否正确登录
        is_admin, user_id_now = token_desc(conn, cookie_token)
        if user_id_now == "":
            print(f"token {user_id_now} is invalid")
            return False
        use_token(conn, cookie_token)
        
        # 检查被修改口令的用户是否存在
        if not user_exists(conn, user_id):
            print(f"user {user_id} does not exist")
            return False
        
        # 检查字符串是否是合法的 md5 字符串
        if not is_md5(new_pwd_md5):
            print("new_pwd_md5 is not a md5 string")
            return False
        
        # 修改口令
        if is_admin or user_id_now == user_id:

            # 修改口令
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE user
                SET passwd_md5 = ?
                WHERE user_id = ?;
            """, (new_pwd_md5, user_id))

            # 修改口令后，需要将用户除了当前 cookie_token 外的所有 cookie_token 都下线
            # 如果是管理员修改其他用户口令：相当于删除所有 cookie_token
            # 如果是用户自己修改自己口令：则需要保持当前 cookie_token 不下线
            cursor.execute("""
                DELETE FROM cookie_token
                WHERE user_id = ? and cookie_token <> ?;
            """, (user_id, cookie_token))

            print("password changed")
            return True
        
        # 没有权限修改口令
        else:
            print("do not have right to operate")
            return False
