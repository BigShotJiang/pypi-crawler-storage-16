from .user_sql_system import connect_database, token_timeout, inv_timeout, token_desc, use_token

# 用于删除一个邀请码
# 如果删除成功返回 True
# 如果邀请码不存在或者删除失败返回 False
def ope_del_inv(db_filepath:str, cookie_token:str, invitation:str) -> bool:
    with connect_database(db_filepath) as conn:

        inv_timeout(conn)
        token_timeout(conn)
        is_admin, user_id = token_desc(conn, cookie_token)
        if user_id == "":
            print(f"{cookie_token} is not a valid cookie_token")
            return False
        use_token(conn, cookie_token)
        
        if not is_admin:
            print(f"user {user_id} is not admin")
            return False
        
        cursor = conn.cursor()
        cursor.execute("""
            SELECT *
            FROM invitation
            WHERE content = ?;
        """, (invitation, ))
        ilist = cursor.fetchall()

        if len(ilist) <= 0:
            print(f"{invitation} is not an invitation")
            return False

        cursor.execute("""
            DELETE FROM invitation
            WHERE content = ?;
        """, (invitation, ))
        print(f"invitation {invitation} is deleted")
        return True
