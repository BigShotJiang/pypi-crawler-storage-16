from .user_sql_system import connect_database, token_timeout, token_desc, user_exists, remove_usr, use_token

# 普通用户只能删除自己的用户
# 管理员除了自己的用户外谁的用户都能删除
# 注意其他表格的级联删除
def ope_del_usr(db_filepath:str, cookie_token:str, user_id:str) -> bool:
    with connect_database(db_filepath) as conn:
        token_timeout(conn)
        is_admin, user_id_now = token_desc(conn, cookie_token)
        if user_id_now == "":
            print("not login")
            return False
        use_token(conn, cookie_token)
        
        if not user_exists(conn, user_id):
            print(f"user {user_id} not exists")
            return False
        
        if is_admin:
            if user_id_now == user_id:
                print(f"admin user {user_id} can not self remove")
                return False
            else:
                remove_usr(conn, user_id)
                return True
        else:
            if user_id != user_id_now:
                print(f"operation unallowed")
                return False
            else:
                remove_usr(conn, user_id)
                return True
