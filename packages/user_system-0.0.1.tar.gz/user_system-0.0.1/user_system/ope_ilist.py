from typing import Optional
from .user_sql_system import connect_database, token_timeout, inv_timeout, token_desc, use_token

# 查看所有邀请码
# 只有管理员有权限进行这个操作
# 操作失败返回 None
# 返回的内容为一个 list of tuple, tuple 中元素依次为：邀请码、剩余次数、过期时间
def ope_ilist(db_filepath:str, cookie_token:str) -> Optional[list[tuple[str, int, float]]]:
    with connect_database(db_filepath) as conn:

        inv_timeout(conn)
        token_timeout(conn)
        is_admin, user_id = token_desc(conn, cookie_token)
        if user_id == "":
            print(f"{cookie_token} is not a valid cookie_token")
            return None
        use_token(conn, cookie_token)
        
        if not is_admin:
            print(f"user {user_id} is not an admin")
            return None
        
        cursor = conn.cursor()
        cursor.execute("""
            SELECT content, remain, die_time
            FROM invitation
        """)
        return list(cursor.fetchall())
