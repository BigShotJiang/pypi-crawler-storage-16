from .user_sql_system import connect_database, token_timeout, token_desc, del_token, use_token

# 将指定的 token 推出登录
def ope_logout(db_filepath:str, cookie_token:str, aim_cookie_token:str):

    with connect_database(db_filepath) as conn:

        # 清除所有超时的 token
        token_timeout(conn)

        # 如果 user_id 返回空，说明 cookie 不存在
        is_admin, user_id = token_desc(conn, cookie_token)
        if user_id == "":
            print(f"{cookie_token} is not a valid cookie_token")
            return
        use_token(conn, cookie_token)
        
        # 获取被退出的 token 的信息
        _, user_id2 = token_desc(conn, aim_cookie_token)
        if user_id2 == "":
            print(f"{aim_cookie_token} is not a valid cookie_token")
            return
        
        # 如果当前用户是管理员或者是试图下线同用户的 cookie_token
        if is_admin or user_id == user_id2:
            del_token(conn, aim_cookie_token)
            print(f"now cookie_token {aim_cookie_token} is offline")
