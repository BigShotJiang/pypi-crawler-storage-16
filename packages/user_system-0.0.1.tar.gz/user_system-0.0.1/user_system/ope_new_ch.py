from .user_sql_system import connect_database, user_exists, ch_timeout, create_ch, has_ch

# 申请一个指定用户的新的挑战应答
# 如果当前用户仍然有一个没有超时的挑战应答则复用
# 如果函数返回的字符串不是空字符串，则认为存在可用的挑战应答
def ope_new_ch(db_filepath:str, user_id:str, timeout_sec:float=300.0) -> str:

    # 创建连接
    with connect_database(db_filepath) as conn:

        # 检查用户是否存在
        if not user_exists(conn, user_id):
            print(f"user {user_id} not exists")
            return ""
        
        # 清除超时的挑战应答
        ch_timeout(conn)

        # 检查是否目前已经有挑战应答
        content = has_ch(conn, user_id)
        if content:
            print(f"there is an old challenge {content}")
            return content

        # 如果没有可用的挑战应答则创建一个新的
        return create_ch(conn, user_id, timeout_sec)
