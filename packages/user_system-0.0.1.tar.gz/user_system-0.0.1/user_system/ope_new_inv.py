import time
from .user_sql_system import connect_database, token_desc, generate_random_string, token_timeout, inv_timeout, use_token

# 创建一个新的邀请码
# 如果创建成功则返回这个邀请码
# 如果创建失败则返回空字符串
def ope_new_inv(
        db_filepath:str, cookie_token:str, remain:int=1, timeout_sec:float=366.0 * 86400) -> str:
    
    with connect_database(db_filepath) as conn:
        
        # 删除所有超时 token
        token_timeout(conn)

        # 删除所有超时以及用光了的邀请码
        inv_timeout(conn)

        # 鉴权
        is_admin, user_id = token_desc(conn, cookie_token)
        if user_id == "":
            print(f"{cookie_token} is not a valid cookie_token")
            return ""
        use_token(conn, cookie_token)

        if not is_admin:
            print(f"user {user_id} is not admin")
            return ""
        
        cursor = conn.cursor()
        new_invitaion_code = generate_random_string(length=32, include_symbol=False)

        # 创建一个新的邀请码
        cursor.execute("""
            INSERT INTO invitation
            VALUES (?, ?, ?);
        """, (new_invitaion_code, time.time() + timeout_sec, remain))

        print(f"new invitation code created {new_invitaion_code}")
        return new_invitaion_code
