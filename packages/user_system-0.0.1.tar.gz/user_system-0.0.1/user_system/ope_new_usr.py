from .user_sql_system import connect_database, inv_timeout, user_exists, inv_exists, is_md5

# 借助邀请码注册一个新用户
def ope_new_usr(db_filepath:str, user_id:str, passwd_md5:str, invitation:str) -> bool:
    with connect_database(db_filepath) as conn:
        inv_timeout(conn)
        if not inv_exists(conn, invitation):
            print(f"{invitation} is not an invitaion content")
            return False
        if user_exists(conn, user_id):
            print(f"user {user_id} already exists")
            return False
        if not is_md5(passwd_md5):
            print(f"{passwd_md5} is not an md5")
            return False
        if not 6 <= len(user_id) <= 32:
            print(f"len of user_id {len(user_id)} is not in 6 ~ 32")
            return False
        
        # 创建新用户
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO user VALUES (?, ?, ?, ?, ?);
        """, (user_id, passwd_md5, user_id, "", False))

        # 让邀请码的 remain 减一
        cursor.execute("""
            UPDATE invitation
            SET remain = remain - 1
            WHERE content = ?
        """, (invitation, ))
        print(f"new user {user_id} created")
        return True
