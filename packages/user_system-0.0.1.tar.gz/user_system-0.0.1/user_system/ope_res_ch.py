from .user_sql_system import connect_database, user_exists, ch_timeout, has_ch, pwd_md5, md5, del_ch, gen_token

# 试图回答一个挑战应答
# 如果回答成功则返回一个 cookie-token
# 如果回答失败则返回空字符串
def ope_res_ch(db_filepath:str, user_id:str, response:str, timeout_sec:float=86400.0) -> str:

    # 创建连接
    with connect_database(db_filepath) as conn:

        # 判断用户是否存在
        if not user_exists(conn, user_id):
            print(f"user {user_id} not exists")
            return ""

        # 删除过期挑战应答
        ch_timeout(conn)

        # 判断挑战应答是否存在
        ch_content = has_ch(conn, user_id)
        if ch_content == "":
            print(f"user {user_id} does not have a challenge")
            return ""

        # 判断挑战应答结果是否正确
        pwd = pwd_md5(conn, user_id) # 获取用户口令
        answer = md5(pwd + ch_content)

        # 挑战应答不正确的情况
        if answer != response:
            print(f"wong challenge response for user {user_id}")
            return ""
        
        # 挑战应答成功，先删除挑战应答，再创建 cookie-token
        del_ch(conn, user_id)
        cookie_token = gen_token(conn, user_id, timeout_sec)
        print(f"challenge success for user {user_id}, cookie_token: {cookie_token}")
        return cookie_token
