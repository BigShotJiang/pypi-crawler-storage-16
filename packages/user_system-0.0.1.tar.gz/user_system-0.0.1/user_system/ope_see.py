from typing import Tuple
from .user_sql_system import connect_database, user_exists, is_admin

# 给定一个用户 ID 查询其昵称和用户描述
# 如果查询成功返回 (True, nickname, introduction)
# 如果查询失败返回 (False, "", "")
# 这个功能是未登录用户的公开可用功能
def ope_see(db_filepath:str, user_id:str) -> Tuple[bool, str, str]:
    
    # 建立连接
    with connect_database(db_filepath) as conn:

        # 用户不存在，查询失败
        if not user_exists(conn, user_id):
            return False, "", ""
        
        # 如果被查询的用户是管理员，则查询失败
        if is_admin(conn, user_id):
            return False, "", ""
        
        # 查询用户信息
        cursor = conn.cursor()
        cursor.execute("""
            SELECT nickname, introduction
            FROM user 
            WHERE user_id = ?;
        """, (user_id,))
        nickname, introduction = cursor.fetchone()
        return True, nickname, introduction
