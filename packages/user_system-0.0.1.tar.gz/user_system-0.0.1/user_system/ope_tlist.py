from typing import Optional
from .user_sql_system import connect_database, token_desc, token_timeout, use_token

# 查看某个指定用户当前所有活动 cookie
# 如果查询失败则返回 None
# 否则返回一个 list
def ope_tlist(db_filepath:str, cookie_token:str, user_id:str) -> Optional[list[str]]:
    with connect_database(db_filepath) as conn:

        # 删除所有超时 token
        token_timeout(conn)

        # 未登录不允许查看
        is_admin, user_id_now = token_desc(conn, cookie_token)
        if user_id_now == "":
            return None
        use_token(conn, cookie_token)
        
        if is_admin or user_id_now == user_id:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT cookie_token
                FROM cookie_token
                WHERE user_id = ?;
            """, (user_id, ))
            return [term[0] for term in cursor.fetchall()]
        
        else:
            return None
