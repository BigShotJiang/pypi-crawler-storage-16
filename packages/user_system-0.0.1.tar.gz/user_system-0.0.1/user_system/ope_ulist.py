from .user_sql_system import connect_database

# 这是一个公开可用的命令
# 可以查询所有非管理员用户的 ID
# 之所以不可以查询管理员用户的 ID，是为了防止暴力爆破口令
def ope_ulist(db_filepath:str) -> list[str]:
    
    # 建立连接
    with connect_database(db_filepath) as conn:

        cursor = conn.cursor()
        cursor.execute("""
            SELECT user_id
            FROM user
            WHERE is_admin = 0;
        """)
        return [term[0] for term in cursor.fetchall()]
