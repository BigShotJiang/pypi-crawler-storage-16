from .user_sql_system import connect_database, token_desc, token_timeout, user_exists, use_token

# 把一个指定用户取消设置为管理员
# 只有管理员才能将其他人设置成管理员
# 管理员不能将自己的管理员身份取消
# 设置成功返回 True
def ope_unset_admin(db_filepath:str, cookie_token:str, user_id: str) -> bool:
    with connect_database(db_filepath) as conn:
        token_timeout(conn)
        is_admin, user_id_now = token_desc(conn, cookie_token)
        if user_id_now == "":
            print("not login")
            return False
        use_token(conn, cookie_token)
        
        if not is_admin:
            print(f"user {user_id_now} is not admin")
            return False
        if not user_exists(conn, user_id):
            print(f"user {user_id} is not exists")
            return False
        if user_id == user_id_now:
            print(f"you can not remove yourself from admin")
            return False
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE user
            SET is_admin = 0
            WHERE user_id = ?;
        """, (user_id, ))
        return True
