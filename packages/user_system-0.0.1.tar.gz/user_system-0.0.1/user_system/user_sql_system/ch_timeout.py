import time
from sqlite3 import Connection

# 删除所有超时的挑战应答记录
# 返回删除的元素数
# chanllenge timeout 即 ct_timeout
def ch_timeout(conn:Connection) -> int:
    time_now = time.time()
    cursor = conn.cursor()

    # 查询有哪些记录是超时的
    cursor.execute("""
        SELECT * FROM challenge WHERE die_time < ?;
    """, (time_now, ))
    ch_list = cursor.fetchall()

    # 如果有超时记录，则删除他们
    if (cnt := len(ch_list)) >= 1:
        print(f"delete {len(ch_list)} outdate challenge item")
        cursor.execute("""
            DELETE FROM challenge WHERE die_time < ?;
        """, (time_now, ))
    
    return cnt
