import time
from sqlite3 import Connection
from .rand import generate_random_string

# 无论当前是否已经有挑战应答，这个语句都会创建一个新的挑战应答
# 但是由于 challenge 表的 UNIQUE 要求，一个用户只能同时有一个挑战应答
# 因此可能会触发报错
def create_ch(conn:Connection, user_id:str, timeout_sec:float) -> str:
    time_now = time.time()
    content = generate_random_string(length=32, include_symbol=False)
    
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO challenge VALUES (?, ?, ?, ?);
    """, (user_id, time_now, content, time_now + timeout_sec))
    
    print(f"create a new challenge {content}")
    return content
