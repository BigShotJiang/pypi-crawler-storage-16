# 本文件描述创建表格所需要的 SQL 语句
# create table sql (ct_sql)

create_user_table_sql = """
    CREATE TABLE IF NOT EXISTS user (
        user_id      TEXT    NOT NULL UNIQUE,
        passwd_md5   TEXT    NOT NULL,
        nickname     TEXT    NOT NULL,
        introduction TEXT    NOT NULL,
        is_admin     INTEGER NOT NULL DEFAULT 0
    );
"""

# 时间之所以用 float 是因为我打算采用 Unix 时间戳作为时间的依据
create_challenge_table_sql = """
    CREATE TABLE IF NOT EXISTS challenge (
        user_id      TEXT NOT NULL UNIQUE,
        create_time  REAL NOT NULL,
        content      TEXT NOT NULL,
        die_time     REAL NOT NULL
    );
"""

# use_time 是最后一次使用这个 cookie_token 的时间戳
create_cookie_token_table_sql = """
    CREATE TABLE IF NOT EXISTS cookie_token (
        cookie_token TEXT NOT NULL UNIQUE,
        user_id      TEXT NOT NULL,
        create_time  REAL NOT NULL,
        die_time     REAL NOT NULL,
        use_time     REAL NOT NULL
    );
"""

create_invitation_table_sql = """
    CREATE TABLE IF NOT EXISTS invitation (
        content  TEXT    NOT NULL UNIQUE,
        die_time REAL    NOT NULL,
        remain   INTEGER NOT NULL
    );
"""
