import sqlite3
import os

from .rand import generate_random_string
from .md5 import md5
from . import ct_sql

# 创建初始数据库
# 运行 init_database 时会向 stdout 输出 root 用户的口令
def init_database(db_filepath:str):
    assert not os.path.isfile(db_filepath)
    print(f"init_database: {db_filepath}")

    # 这条语句会自动创建文件（如果文件不存在）
    with sqlite3.connect(db_filepath) as conn:

        # 开始一个事务
        conn.execute('BEGIN TRANSACTION')
        cursor = conn.cursor()

        # 创建用户表
        cursor.execute(ct_sql.create_user_table_sql)

        # 创建挑战应答表
        cursor.execute(ct_sql.create_challenge_table_sql)

        # 创建 cookie-token 表
        cursor.execute(ct_sql.create_cookie_token_table_sql)

        # 创建邀请码表
        cursor.execute(ct_sql.create_invitation_table_sql)

        # 创建 root 用户（管理员）
        root_pwd = generate_random_string(length=12, include_symbol=False)
        print(f"root_pwd: {root_pwd}")
        cursor.execute("""
            INSERT INTO user VALUES (?, ?, ?, ?, ?);
        """, ("root", md5(root_pwd), "root", "", True))

        # 创建 user1 用户（非管理员）
        print(f"user1: {root_pwd}")
        cursor.execute("""
            INSERT INTO user VALUES (?, ?, ?, ?, ?);
        """, ("user1", md5(root_pwd), "user1", "", False))

        # 执行事务
        conn.commit()

# 如果数据库文件不存在，则创建初始数据库并连接
# 如果数据库文件存在，则直接连接
def connect_database(db_filepath:str) -> sqlite3.Connection:
    if not os.path.isfile(db_filepath):
        init_database(db_filepath)
    conn = sqlite3.connect(db_filepath)
    return conn
