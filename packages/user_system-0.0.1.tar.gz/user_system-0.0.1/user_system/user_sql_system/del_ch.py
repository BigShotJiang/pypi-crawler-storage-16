from sqlite3 import Connection

# 删除指定用户的所有挑战应答记录
def del_ch(conn:Connection, user_id:str):
    cursor = conn.cursor()
    cursor.execute("""
        DELETE FROM challenge WHERE user_id = ?;
    """, (user_id, ))
