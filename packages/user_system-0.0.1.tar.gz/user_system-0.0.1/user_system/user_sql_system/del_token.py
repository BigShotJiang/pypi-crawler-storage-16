from sqlite3 import Connection

# 删除指定的 token
def del_token(conn:Connection, aim_cookie_token:str):
    cursor = conn.cursor()
    cursor.execute("""
        DELETE FROM cookie_token WHERE cookie_token = ?
    """, (aim_cookie_token, ))
