import time
from sqlite3 import Connection
from .rand import generate_random_string

# 为当前用户生成一个新的 cookie_token
def gen_token(conn:Connection, user_id:str, timeout_sec:float) -> str:
    time_now = time.time()
    cookie_token = generate_random_string(length=32, include_symbol=False)

    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO cookie_token VALUES (?, ?, ?, ?, ?);
    """, (cookie_token, user_id, time_now, time_now + timeout_sec, time_now))
    return cookie_token
