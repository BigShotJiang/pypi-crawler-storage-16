from sqlite3 import Connection

# 判断某个用户现在是否有可用的挑战应答
# 如果有，返回挑战应答的 content
# 如果没有则返回空字符串
def has_ch(conn:Connection, user_id:str) -> str:
    # 查询用户当前是否有可用挑战应答
    cursor = conn.cursor()
    cursor.execute("""
        SELECT content FROM challenge WHERE user_id = ?;
    """, (user_id, ))
    ch_list = cursor.fetchall()
    
    if len(ch_list) >= 1:
        content = ch_list[0][0] # 返回 content 字段即可
        return content
    
    # 当前用户没有找到挑战应答
    else:
        return ""
