from sqlite3 import Connection

def inv_exists(conn: Connection, invitation:str) -> bool:
    cursor = conn.cursor()
    cursor.execute("""
        SELECT *
        FROM invitation
        WHERE content = ?;
    """, (invitation, ))
    return len(cursor.fetchall()) >= 1
