from sqlite3 import Connection
import time

# 删除所有超时的邀请码以及剩余次数小于等于 0 的邀请码
def inv_timeout(conn:Connection):
    cursor = conn.cursor()
    cursor.execute("""
        DELETE FROM invitation
        WHERE die_time < ? or remain <= 0;
    """, (time.time(), ))
