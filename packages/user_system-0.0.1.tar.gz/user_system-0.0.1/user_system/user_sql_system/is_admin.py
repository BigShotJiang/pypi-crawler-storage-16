from sqlite3 import Connection
from .user_exists import user_exists

# 判断一个用户是不是管理员
# 如果用户不存在也返回 False
def is_admin(conn:Connection, user_id:str) -> bool:
    if not user_exists(conn, user_id):
        return False
    
    cursor = conn.cursor()
    cursor.execute("""
        SELECT is_admin FROM user WHERE user_id = ?
    """, (user_id, ))
    return bool(cursor.fetchone()[0])
