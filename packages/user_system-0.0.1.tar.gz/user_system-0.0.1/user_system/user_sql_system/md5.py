import hashlib

# 给定任意字符串
# 生成其在 utf-8 下的哈希摘要的小写模式
def md5(s:str) -> str:
    return hashlib.md5(s.encode("utf-8")).hexdigest().lower()

# 判断一个字符串是否是 32 位 16进制数
def is_md5(s:str) -> bool:
    char_set = [str(i) for i in range(10)] + ['a', 'b', 'c', 'd', 'e', 'f']
    for i in range(len(s)):
        if s[i] not in char_set:
            return False
    return True
