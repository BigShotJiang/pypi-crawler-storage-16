from sqlite3 import Connection
from .user_exists import user_exists

# 如果用户不存在，则返回空字符串
# 如果用户存在则就返回其口令的 md5 值
def pwd_md5(conn:Connection, user_id:str) -> str:
    
    # 获取口令
    # 返回其 md5 值
    if not user_exists(conn, user_id):
        return ""
    
    cursor = conn.cursor()
    cursor.execute("""
        SELECT passwd_md5 FROM user WHERE user_id = ?
    """, (user_id, ))
    pwd_list = cursor.fetchall()
    return pwd_list[0][0]
