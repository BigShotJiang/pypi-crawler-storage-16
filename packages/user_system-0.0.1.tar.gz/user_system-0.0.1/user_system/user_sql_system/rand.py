import random
import string

def generate_random_string(
    length: int = 12,
    include_upper: bool = True,    # 是否包含大写字母
    include_lower: bool = True,    # 是否包含小写字母
    include_digit: bool = True,    # 是否包含数字
    include_underline: bool = True, # 是否包含下划线
    include_symbol: bool = True,   # 是否包含符号
    symbols: str = string.punctuation  # 自定义符号集（默认包含常见符号）
) -> str:
    # 1. 参数校验：长度必须大于0
    if length < 1:
        raise ValueError("随机字符串长度必须大于0")
    
    # 2. 构建可选字符池
    char_pool = ""
    # 添加大写字母（A-Z）
    if include_upper:
        char_pool += string.ascii_uppercase
    # 添加小写字母（a-z）
    if include_lower:
        char_pool += string.ascii_lowercase
    # 添加数字（0-9）
    if include_digit:
        char_pool += string.digits
    # 添加下划线
    if include_underline:
        char_pool += "_"
    # 添加符号
    if include_symbol:
        char_pool += symbols
    
    # 3. 校验：必须至少选择一种字符类型
    if not char_pool:
        raise ValueError("至少需要选择一种字符类型（字母、数字、下划线、符号）")
    
    # 4. 生成随机字符串：从字符池中随机选择length个字符，拼接成字符串
    # random.choices：允许重复选择字符（如果需要不重复，可改用random.sample，但需确保length <= len(char_pool)）
    random_chars = random.choices(char_pool, k=length)
    return "".join(random_chars)
