from sqlite3 import Connection

# 删除某个用户关联的所有记录
# 注意级联删除
def remove_usr(conn:Connection, user_id:str):
    cursor = conn.cursor()
    for table_name in ["user", "challenge", "cookie_token"]:
        cursor.execute(f"""
            DELETE FROM {table_name}
            WHERE user_id = ?;
        """, (user_id, ))
