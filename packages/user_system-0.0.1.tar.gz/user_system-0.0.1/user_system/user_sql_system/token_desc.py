from typing import Tuple
from sqlite3 import Connection
from .is_admin import is_admin

# 如果 cookie_token 存在，则返回 is_admin, user_id
# 如果不存在，则返回 False, ""
def token_desc(conn:Connection, cookie_token:str) -> Tuple[bool, str]:
    cursor = conn.cursor()
    cursor.execute("""
        SELECT user_id FROM cookie_token WHERE cookie_token = ?;
    """, (cookie_token, ))
    cookie_list = cursor.fetchall()

    # cookie_token 不存在
    if len(cookie_list) <= 0:
        return False, ""
    else:
        user_id = cookie_list[0][0]
        return is_admin(conn, user_id), user_id
