import time
from sqlite3 import Connection

# 把所有超时的 cookie_token 删除掉
def token_timeout(conn:Connection):
    time_now = time.time()
    cursor = conn.cursor()
    cursor.execute("""
        DELETE FROM cookie_token WHERE die_time < ?;
    """, (time_now, ))
    conn.commit()
