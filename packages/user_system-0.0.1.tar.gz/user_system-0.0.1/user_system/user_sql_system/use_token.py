from sqlite3 import Connection
import time

def use_token(conn:Connection, cookie_token:str):
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE cookie_token
        SET use_time = ?
        WHERE cookie_token = ?;
    """, (time.time(), cookie_token))
