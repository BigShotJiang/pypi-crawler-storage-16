from sqlite3 import Connection

# 判断一个用户是否存在
# 如果用户存在则返回 True 否则返回 False
def user_exists(conn:Connection, user_id:str) -> bool:
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM user WHERE user_id = ?;
    """, (user_id, ))
    user_list = cursor.fetchall()
    return len(user_list) >= 1
