"""
Exposes the public API for the ORM feature.
"""

from .database import db

__all__ = ["db"]
