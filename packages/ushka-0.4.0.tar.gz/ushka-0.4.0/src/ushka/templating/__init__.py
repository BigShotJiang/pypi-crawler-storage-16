"""
Exposes the public API for the templating feature.
"""

from .engine import render

__all__ = ["render"]
