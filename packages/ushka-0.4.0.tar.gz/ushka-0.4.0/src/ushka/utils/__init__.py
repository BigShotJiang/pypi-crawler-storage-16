"""This package provides various utilities and helpers for Ushka.

Exports:
    flash: A function to "flash" a message to be stored in the session.
    get_flashed_messages: A function to retrieve flashed messages from the session.
    Category: An enum for message categories (e.g., success, danger).
"""

from .flash import Category, flash, get_flashed_messages

__all__ = ["flash", "get_flashed_messages", "Category"]
