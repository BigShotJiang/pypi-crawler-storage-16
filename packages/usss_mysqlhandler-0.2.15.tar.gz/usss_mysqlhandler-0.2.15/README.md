# Simplify using MySQL
## Class and methods to simplify using MySQL

MysqlHandler class is a context manager, use thus:


  
This 
1. opens connection to MySQL
2. Provides methods simplify executing queries (delete, insert, select, update) and getting results.
3. Closes the connection reliably on exit from scope

Simple: insert ... on duplicate key update

https://guides.github.com/features/mastering-markdown/

