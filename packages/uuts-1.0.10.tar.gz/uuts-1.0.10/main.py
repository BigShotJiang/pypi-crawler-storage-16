import package.uuts.documentation as tsdoc
from pathlib import Path
import sys
import argparse


class MyParser(argparse.ArgumentParser):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs) 
    
    def error(self, message):
        self.print_help(sys.stderr)
        self.exit(2, '%s: error: %s\n' % (self.prog, message))

    def _check_directory_exists(self, value: str) -> bool:
        """
        Validates and returns the absolute path to the output directory.
        """
        path = Path(value.rstrip("/\\"))
        path = path.resolve()
        return path.exists()

    def _input_str(self, value: str) -> str:
        """
        Validates and returns the absolute path to the input directory.
        """
        if self._check_directory_exists(value):
            return str(value)
        else:
            raise argparse.ArgumentTypeError(f"Input directory {value} does not exist")


    def _output_str(self, value: str) -> str:
        """
        Validates and returns the absolute path to the output directory.
        """
        if self.args.action == "generateDocumentation":
            if self._check_directory_exists(value):
                return str(value)
            else:
                raise argparse.ArgumentTypeError(f"Output directory {value} does not exist")
        else:
            raise argparse.ArgumentTypeError(f"--output is not required for action {self.args.action} but was provided")
        
    def validate_args(self, args):
        """
        Validates the command-line arguments.
        """
        if args.action == "generateDocumentation":
            if not self._check_directory_exists(args.input):
                raise argparse.ArgumentTypeError(f"Input directory {args.input} does not exist")
            if not self._check_directory_exists(args.output):
                raise argparse.ArgumentTypeError(f"Output directory {args.output} does not exist")
        else:
            raise argparse.ArgumentTypeError(f"Unknown action {args.action}. Action was not implemented.")
        

def main():
    """
    Main function to generate documentation for the Time Series Metamodel.
    Parses command-line arguments and initiates the documentation generation process.
    """
    parser = MyParser(
        description='Documentation generator for Time Series Metamodel.',
        epilog="Example: uv run generatedoc.py --action \"generateDocumentation\" --input \"absolute_path_to_metamodel.zip\" "
               "--output \"absolute_path_to_output_directory\" --language \"cs\""
    )
    parser.add_argument('--action', type=str, required=True, help='Action to perform. Either "generateDocumentation" to generate documentation or "analyzeImpact" to run analyzeImpact of the metamodel or "analyzeImpactAndDeploy" to run analyzeImpact and deploy procedure')
    parser.add_argument('--input', type=str, required=True, help='Path to the metamodel zip file or metamodel directory.')
    parser.add_argument('--output', type=str, required=False, default='./', help='Path to the output documentation directory. (default: "./")')
    parser.add_argument('--language', type=str, required=False, default='en', help='Language code for the documentation (default: "en").')
    parser.add_argument('--pages', type=str, required=False, default='', help='List of urls of pages used in case there '
                         'are so many tsdefinitions that the documentation needs to be split into '
                         'multiple pages. (default: "") Example: "book/page?code=4532154,book/page?code=56476")')
    # Parse arguments
    args = parser.parse_args(sys.argv[1:])
    parser.validate_args(args)
    page_urls = []
    if args.pages:
        page_urls = args.pages.split(',')
    # Set up paths
    metamodel_path = Path(args.input)
    output_path = Path(args.output.rstrip("/\\"))
    print(f'Generating documentation from "{str(metamodel_path.resolve())}" '
          f'to "{str(output_path.resolve())}" in language "{args.language}"')
    # Generate documentation
    documentation = tsdoc.Documentation(metamodel_path, output_path)
    documentation.generate_documentation(language=args.language, page_urls=page_urls)
    print(f'\nOK - documentation successfully generated\nSee "{str(output_path.resolve())}"\n')

if __name__ == "__main__":
    main()
    exit(0)
