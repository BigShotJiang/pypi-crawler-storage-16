from pathlib import Path
from .doctsobjecttyperelation import DocTsObjectTypeRelation
import fetchx.ioutils as ioutils
from .doctsbusinesstype import DocTsBusinessType
from .doctstimeunit import DocTsTimeUnit

class DocTsType(dict):
    def __init__(self, *args, **kwargs):
        """
        Represents a Time Series Type in the metamodel.
        Inherits from dict to store type properties.
        """
        super().__init__(*args, **kwargs)
        self.tsbusinesstype = None  # type: DocTsBusinessType | None
        self.tstimeunit = None  # type: DocTsTimeUnit | None

    @staticmethod
    def load_from_directory(base_path: Path) -> dict[str, 'DocTsType']:
        """
        Load all Time Series Types from the specified directory.
        :param base_path: Base path where the metamodel is located.
        :return: A dictionary mapping type codes to DocTsType instances.
        """
        result = {}
        tstype_path = base_path / "metamodel/tsType"
        # Load all .json files
        files, directories = ioutils.search_folder(str(tstype_path.resolve()), list_of_extensions=[".json"])
        for file in files:
            value = ioutils.load_json(file)
            code = Path(file).stem
            result[code] = DocTsType(value)
        return result
        