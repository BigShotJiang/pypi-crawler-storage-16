from pathlib import Path
from .doctsobjecttyperelation import DocTsObjectTypeRelation
import fetchx.ioutils as ioutils
from .doctstimeunit import DocTsTimeUnit

class DocTsBusinessType(dict):
    def __init__(self, *args, **kwargs):
        """
        Represents a Time Series Business Type in the metamodel.
        Inherits from dict to store business type properties.
        """
        super().__init__(*args, **kwargs)
        self.tstimeunit = None  # type: DocTsTimeUnit | None

    @staticmethod
    def load_from_directory(base_path: Path) -> dict[str, 'DocTsBusinessType']:
        """
        Load all Time Series Business Types from the specified directory.
        :param base_path: Base path where the metamodel is located.
        :return: A dictionary mapping business type codes to DocTsBusinessType instances.
        """
        result = {}
        tstype_path = base_path / "metamodel/tsBusinessType"
        # Load all .json files
        files, directories = ioutils.search_folder(str(tstype_path.resolve()), list_of_extensions=[".json"])
        for file in files:
            value = ioutils.load_json(file)
            code = Path(file).stem
            result[code] = DocTsBusinessType(value)
        return result
        