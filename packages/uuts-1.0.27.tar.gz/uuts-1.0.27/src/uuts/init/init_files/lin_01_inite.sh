curl -LsSf https://astral.sh/uv/install.sh | sh
uv init 
uv add fetchx
uv lock --upgrade
uv run python -c "import fetchx.init"
