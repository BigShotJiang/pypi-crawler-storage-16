echo "##################################################"
echo "####  The very first start may take a minute  ####"
echo "####  To use Jupyter please open web browser  ####"
echo "####          http://localhost:8888/          ####"
echo "##################################################"
uv add jupyter
uv run --with jupyter jupyter lab