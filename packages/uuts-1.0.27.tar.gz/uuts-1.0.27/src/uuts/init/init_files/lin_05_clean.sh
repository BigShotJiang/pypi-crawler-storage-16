uv cache clean
uv cache prune