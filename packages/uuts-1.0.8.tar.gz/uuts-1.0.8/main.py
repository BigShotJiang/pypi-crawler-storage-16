import package.uuts.documentation as tsdoc
from pathlib import Path
import sys
import argparse


class MyParser(argparse.ArgumentParser):
    def error(self, message):
        self.print_help(sys.stderr)
        self.exit(2, '%s: error: %s\n' % (self.prog, message))
        

def main():
    """
    Main function to generate documentation for the Time Series Metamodel.
    Parses command-line arguments and initiates the documentation generation process.
    """
    parser = MyParser(
        description='Documentation generator for Time Series Metamodel.',
        epilog="Example: uv run generatedoc.py --input \"absolute_path_to_metamodel.zip\" "
               "--output \"absolute_path_to_output_directory\" --language \"cs\""
    )
    parser.add_argument('--input', type=str, required=True, help='Path to the metamodel zip file or metamodel directory.')
    parser.add_argument('--output', type=str, required=True, help='Path to the output documentation directory.')
    parser.add_argument('--language', type=str, default='en', help='Language code for the documentation (default: en).')
    parser.add_argument('--pages', type=str, default='', help='List of urls of pages used in case there '
                         'are so many tsdefinitions that the documentation needs to be split into '
                         'multiple pages default is empty. Example: "book/page?code=4532154,book/page?code=56476"')
    # Parse arguments
    args = parser.parse_args(sys.argv[1:])
    page_urls = []
    if args.pages:
        page_urls = args.pages.split(',')
    # Set up paths
    metamodel_path = Path(args.input)
    output_path = Path(args.output.rstrip("/\\"))
    print(f'Generating documentation from "{str(metamodel_path.resolve())}" '
          f'to "{str(output_path.resolve())}" in language "{args.language}"')
    # Generate documentation
    documentation = tsdoc.Documentation(metamodel_path, output_path)
    documentation.generate_documentation(language=args.language, page_urls=page_urls)
    print(f'\nOK - documentation successfully generated\nSee "{str(output_path.resolve())}"\n')

if __name__ == "__main__":
    main()
    exit(0)
