from __future__ import absolute_import

from .documentation import Documentation

__all__ = (
    "Documentation",
)
