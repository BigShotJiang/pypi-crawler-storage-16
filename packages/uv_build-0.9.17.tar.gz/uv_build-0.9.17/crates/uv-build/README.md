# Build backend for uv

This package is a slimmed down version of uv containing only the build backend. See
https://pypi.org/project/uv/ and https://docs.astral.sh/uv/ for the main project package and
documentation.
