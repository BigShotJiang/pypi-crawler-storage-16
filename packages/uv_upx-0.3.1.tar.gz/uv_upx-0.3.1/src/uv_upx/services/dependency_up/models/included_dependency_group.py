type IncludedDependencyGroup = dict[str, str]
