from .WordTokenizer import tokenize
from .SyllableTokenizer import tokenize
from .AffixTokenizer import tokenize
from .CharTokenizer import tokenize