def hello():
    print('asdfasf')