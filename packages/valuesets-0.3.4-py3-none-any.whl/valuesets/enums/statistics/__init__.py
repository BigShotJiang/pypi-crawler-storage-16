"""Auto-generated package."""

from .prediction_outcomes import OutcomeTypeEnum as PredictionOutcomeType

__all__ = ["PredictionOutcomeType"]
