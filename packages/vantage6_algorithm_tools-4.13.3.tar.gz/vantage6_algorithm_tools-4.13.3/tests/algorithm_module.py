import pandas as pd


def hello_world(data: pd.DataFrame):
    return data
