"""Codebase scanning commands for Vantage CLI.

This module provides automatic agent detection from source code including:
- Multi-framework detection (17+ frameworks)
- Connection inference
- System extraction
- Health check integration
"""

from __future__ import annotations

import json
from pathlib import Path

import typer

from vantage_cli.output import get_console

scan_app = typer.Typer(
    name="scan",
    help="Scan codebases for agent definitions.",
    no_args_is_help=True,
)


@scan_app.command("directory")
def scan_directory(
    directory: Path = typer.Argument(
        ...,
        help="Path to directory containing agent code",
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output JSON file path for extracted system",
    ),
    html: bool = typer.Option(
        False,
        "--html",
        help="Generate HTML executive report",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed output",
    ),
    run_healthcheck: bool = typer.Option(
        True,
        "--healthcheck/--no-healthcheck",
        help="Run health check after scanning",
    ),
    format: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
):
    """Scan a codebase to auto-detect agent systems.

    Supports 17+ frameworks including CrewAI, AutoGen, LangGraph,
    LlamaIndex, and more. No more manual JSON configuration!

    Examples:

        vantage scan directory ./my_project
        vantage scan directory ./my_project --output system.json
        vantage scan directory ./my_project --html
    """
    from vantage_core.scanners import UniversalScanner

    from vantage_cli.output.html_report import generate_html_report

    console = get_console()

    console.print(f"\n[bold blue]Scanning: {directory}[/bold blue]\n")

    scanner = UniversalScanner(verbose=verbose)
    result = scanner.scan_directory(directory)

    if not result.agents:
        console.warning("No agents detected in the codebase.")
        console.print()
        console.info("Supported frameworks:")
        console.print("  CrewAI, AutoGen, LangGraph, LlamaIndex, Semantic Kernel,")
        console.print("  DSPy, SmolaGents, PydanticAI, MetaGPT, and more...")
        console.print()
        console.muted("Make sure your agent definitions are in Python files.")
        return

    # Generate HTML Report
    if html:
        report_path = generate_html_report(result)
        console.success(f"Generated Executive Report: {report_path}")

    # JSON output mode
    if format == "json":
        system = result.to_agent_system(name=directory.name)
        system_dict = _system_to_dict(system)
        console.print_always(json.dumps(system_dict, indent=2))
        return

    # Text output mode
    console.success(f"Found {len(result.agents)} agents ({result.framework})")
    console.print(f"  Files scanned: {result.files_scanned}")
    console.print(f"  Connections: {len(result.connections)}")

    if result.errors and verbose:
        console.print(f"\n[yellow]Warnings: {len(result.errors)}[/yellow]")
        for error in result.errors[:5]:
            console.muted(f"  {error}")

    # Show detected agents
    console.print_subheader("Detected Agents")

    for agent in result.agents:
        console.print(f"\n  [cyan]{agent.name}[/cyan] ({agent.id})")
        model = agent.metadata.get("model", "Unknown")
        console.print(f"    Model: {model}")
        console.print(f"    File: {agent.file_path}:{agent.line_number}")

        # Show prompt preview
        if agent.system_prompt:
            prompt_preview = agent.system_prompt[:100]
            if len(agent.system_prompt) > 100:
                prompt_preview += "..."
            prompt_preview = prompt_preview.replace("\n", " ")
            console.print(f"    Prompt: {prompt_preview}")

    # Show connections
    if result.connections:
        console.print_subheader("Detected Connections")
        for conn in result.connections:
            condition = f" (if {conn.condition})" if conn.condition else ""
            console.print(f"  {conn.source_id} -> {conn.target_id}{condition}")

    # Convert to AgentSystem
    system = result.to_agent_system(name=directory.name)

    # Save if output specified
    if output:
        system_dict = _system_to_dict(system)
        with open(output, "w") as f:
            json.dump(system_dict, f, indent=2)
        console.success(f"Saved to {output}")

    # Run health check
    if run_healthcheck:
        _run_quick_healthcheck(console, system)


def _system_to_dict(system) -> dict:
    """Convert AgentSystem to dictionary for JSON serialization."""
    return {
        "name": system.name,
        "description": system.description,
        "version": system.version,
        "agents": [
            {
                "id": agent.id,
                "name": agent.name,
                "description": agent.description,
                "model": agent.model,
                "temperature": agent.temperature,
                "max_tokens": agent.max_tokens,
                "prompt": {"content": agent.prompt.content},
            }
            for agent in system.agents.values()
        ],
        "topology": {
            "entry_points": system.topology.entry_points,
            "exit_points": system.topology.exit_points,
            "connections": [
                {
                    "source": conn.source,
                    "target": conn.target,
                    "condition": conn.condition,
                    "data_passed": conn.data_passed,
                }
                for conn in system.topology.connections
            ],
        },
        "metadata": system.metadata,
    }


def _run_quick_healthcheck(console, system) -> None:
    """Run quick health check on detected system."""
    from vantage_core.analysis.cost_estimator import CostEstimator
    from vantage_core.analysis.failure_taxonomy import MASTFailureDetector

    console.print()
    console.print("=" * 60)
    console.print("[bold]Running Health Check on Detected System[/bold]")
    console.print("=" * 60)

    # MAST Failure Detection
    detector = MASTFailureDetector(risk_threshold=0.3)
    failure_risks = detector.detect_failure_risks(system)

    if failure_risks:
        critical = [r for r in failure_risks if r.risk_level == "critical"]
        high = [r for r in failure_risks if r.risk_level == "high"]

        if critical:
            console.error(f"{len(critical)} CRITICAL failure risks")
        if high:
            console.warning(f"{len(high)} high-risk failure modes")

        console.print_subheader("Top Issues")
        for risk in failure_risks[:3]:
            theme = console.theme
            color = theme.get_risk_color(risk.risk_level)
            console.print(
                f"  [{color}]{risk.failure_mode.code}: {risk.failure_mode.name}[/{color}]"
            )
            console.print(f"    [{theme.success}]-> {risk.recommendation}[/{theme.success}]")
    else:
        console.success("No significant failure risks detected!")

    # Cascade Risk
    cascade = detector.calculate_cascade_risk(system)
    if cascade.cascade_score >= 50:
        console.warning(f"Cascade Risk: {cascade.cascade_score:.0f}/100")

    # Cost
    estimator = CostEstimator()
    cost = estimator.estimate_system_cost(system)
    console.print(
        f"\n[bold]Cost Estimate:[/bold] ${cost.monthly_cost_1000_runs:.2f}/month (1K runs)"
    )

    # Overall Score
    failure_penalty = min(len(failure_risks) * 5, 40)
    cascade_penalty = cascade.cascade_score * 0.3
    health_score = max(100 - failure_penalty - cascade_penalty, 0)

    theme = console.theme
    if health_score >= 80:
        color = theme.success
    elif health_score >= 60:
        color = theme.warning
    else:
        color = theme.error

    console.print(f"\n[bold]Health Score: [{color}]{health_score:.0f}/100[/{color}][/bold]")


@scan_app.command("frameworks")
def list_frameworks():
    """List all supported frameworks for agent detection.

    Shows detection capabilities for each framework.
    """
    console = get_console()

    console.print_header("Supported Frameworks for Auto-Detection")

    framework_info = [
        ("CrewAI", "full", "Agents, Tasks, Crews, Flows"),
        ("LangChain", "full", "Chains, Agents, Tools"),
        ("LangGraph", "full", "StateGraphs, Nodes, Edges"),
        ("AutoGen", "full", "Agents, GroupChat, Workflows"),
        ("LlamaIndex", "full", "Agents, Tools, Workflows"),
        ("Semantic Kernel", "full", "Plugins, Functions, Agents"),
        ("DSPy", "full", "Modules, Signatures"),
        ("SmolaGents", "full", "HfAgents, Tools"),
        ("PydanticAI", "full", "Agents, Tools"),
        ("MetaGPT", "partial", "Roles, Actions"),
        ("Agno", "full", "Agents, Tools"),
        ("Google ADK", "full", "Agents, Tools"),
        ("OpenAI Swarm", "full", "Agents, Handoffs"),
        ("BrowserUse", "partial", "Browser Agents"),
        ("OpenHands", "partial", "CodeAct Agents"),
        ("Skyvern", "partial", "Browser Workflows"),
        ("Dify", "partial", "YAML Workflows"),
    ]

    table = console.create_table(
        columns=["Framework", "Support", "Detects"],
    )

    for name, support, detects in framework_info:
        support_style = "[green]Full[/green]" if support == "full" else "[yellow]Partial[/yellow]"
        table.add_row(name, support_style, detects)

    console.print(table)

    console.print()
    console.info("To scan a project:")
    console.print("  vantage scan directory ./my-project")
