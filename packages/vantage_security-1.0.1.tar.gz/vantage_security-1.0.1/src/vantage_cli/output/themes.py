"""Color themes and styling for Vantage CLI.

Provides consistent, professional theming across all CLI output.
"""

from dataclasses import dataclass


@dataclass
class Theme:
    """Color theme configuration."""

    # Brand colors
    primary: str = "blue"
    secondary: str = "cyan"
    accent: str = "magenta"

    # Status colors
    success: str = "green"
    warning: str = "yellow"
    error: str = "red"
    info: str = "cyan"
    muted: str = "dim"

    # Severity colors
    critical: str = "red bold"
    high: str = "red"
    medium: str = "yellow"
    low: str = "cyan"
    informational: str = "dim"

    # Grade colors
    grade_a: str = "green bold"
    grade_b: str = "green"
    grade_c: str = "yellow"
    grade_d: str = "red"
    grade_f: str = "red bold"

    # UI elements
    border: str = "blue"
    header: str = "bold blue"
    subheader: str = "bold cyan"
    label: str = "cyan"
    value: str = "white"
    highlight: str = "bold white"

    def get_severity_color(self, severity: str) -> str:
        """Get color for severity level."""
        mapping = {
            "critical": self.critical,
            "high": self.high,
            "medium": self.medium,
            "low": self.low,
            "info": self.informational,
            "informational": self.informational,
        }
        return mapping.get(severity.lower(), self.muted)

    def get_grade_color(self, grade: str) -> str:
        """Get color for security grade."""
        mapping = {
            "A": self.grade_a,
            "B": self.grade_b,
            "C": self.grade_c,
            "D": self.grade_d,
            "F": self.grade_f,
        }
        return mapping.get(grade.upper(), self.muted)

    def get_score_color(self, score: float) -> str:
        """Get color based on score value (0-100)."""
        if score >= 90:
            return self.grade_a
        elif score >= 80:
            return self.grade_b
        elif score >= 70:
            return self.grade_c
        elif score >= 60:
            return self.grade_d
        else:
            return self.grade_f

    def get_risk_color(self, risk_level: str) -> str:
        """Get color for risk level."""
        mapping = {
            "minimal": self.success,
            "low": self.info,
            "moderate": self.warning,
            "high": self.error,
            "critical": self.critical,
        }
        return mapping.get(risk_level.lower(), self.muted)


# Default theme instance
DEFAULT_THEME = Theme()


# Professional dark theme
DARK_THEME = Theme(
    primary="bright_blue",
    secondary="bright_cyan",
    accent="bright_magenta",
    success="bright_green",
    warning="bright_yellow",
    error="bright_red",
)


# High contrast theme for accessibility
HIGH_CONTRAST_THEME = Theme(
    primary="bold blue",
    secondary="bold cyan",
    success="bold green",
    warning="bold yellow",
    error="bold red",
    muted="white",
)


def get_theme(name: str = "default") -> Theme:
    """Get theme by name."""
    themes: dict[str, Theme] = {
        "default": DEFAULT_THEME,
        "dark": DARK_THEME,
        "high_contrast": HIGH_CONTRAST_THEME,
    }
    return themes.get(name, DEFAULT_THEME)
