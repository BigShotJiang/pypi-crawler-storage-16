"""Output formatting for Vantage CLI."""

from vantage_cli.output.console import MimicConsole, ScanProgress, console, get_console
from vantage_cli.output.themes import (
    DARK_THEME,
    DEFAULT_THEME,
    HIGH_CONTRAST_THEME,
    Theme,
    get_theme,
)

__all__ = [
    "MimicConsole",
    "ScanProgress",
    "console",
    "get_console",
    "DEFAULT_THEME",
    "DARK_THEME",
    "HIGH_CONTRAST_THEME",
    "Theme",
    "get_theme",
]
