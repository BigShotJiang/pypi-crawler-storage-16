"""Error handling for Vantage CLI.

Provides consistent error handling, formatting, and exit codes.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import NoReturn

import typer

from vantage_cli.output import console


class ExitCode(IntEnum):
    """Standard exit codes for CLI operations."""

    SUCCESS = 0
    GENERAL_ERROR = 1
    CONFIGURATION_ERROR = 2
    FILE_NOT_FOUND = 3
    PERMISSION_ERROR = 4
    VALIDATION_ERROR = 5
    SECURITY_FINDINGS = 10  # Findings detected (for CI/CD)
    SCORE_BELOW_THRESHOLD = 11  # Score below minimum (for CI/CD)
    CRITICAL_FINDINGS = 12  # Critical findings detected
    TIMEOUT = 13
    SCAN_FAILED = 14


@dataclass
class CLIError:
    """Structured CLI error."""

    message: str
    code: ExitCode
    hint: str | None = None
    context: str | None = None


def handle_error(error: CLIError) -> NoReturn:
    """Handle a CLI error and exit with appropriate code."""
    console.error(error.message)

    if error.context:
        console.muted(f"  Context: {error.context}")

    if error.hint:
        console.warning(f"  Hint: {error.hint}")

    raise typer.Exit(error.code)


def file_not_found_error(path: str) -> NoReturn:
    """Handle file not found error."""
    handle_error(
        CLIError(
            message=f"File not found: {path}",
            code=ExitCode.FILE_NOT_FOUND,
            hint=f"Check the file path and ensure it exists: ls -la {path}",
        )
    )


def permission_error(path: str) -> NoReturn:
    """Handle permission error."""
    handle_error(
        CLIError(
            message=f"Permission denied: {path}",
            code=ExitCode.PERMISSION_ERROR,
            hint=f"Check file permissions: ls -la {path}",
        )
    )


def json_parse_error(path: str, error: str, line: int | None = None) -> NoReturn:
    """Handle JSON parse error."""
    context = f"at line {line}" if line else None
    handle_error(
        CLIError(
            message=f"Invalid JSON in {path}: {error}",
            code=ExitCode.VALIDATION_ERROR,
            context=context,
            hint="Validate your JSON with: python -m json.tool < your_file.json",
        )
    )


def configuration_error(message: str, hint: str | None = None) -> NoReturn:
    """Handle configuration error."""
    handle_error(
        CLIError(
            message=f"Configuration error: {message}",
            code=ExitCode.CONFIGURATION_ERROR,
            hint=hint,
        )
    )


def scan_error(message: str, context: str | None = None) -> NoReturn:
    """Handle scan error."""
    handle_error(
        CLIError(
            message=f"Scan failed: {message}",
            code=ExitCode.SCAN_FAILED,
            context=context,
            hint="Try running with --verbose for more details",
        )
    )


def timeout_error(operation: str, timeout: int) -> NoReturn:
    """Handle timeout error."""
    handle_error(
        CLIError(
            message=f"Operation timed out: {operation}",
            code=ExitCode.TIMEOUT,
            context=f"Timeout was {timeout} seconds",
            hint="Try increasing the timeout with --timeout option",
        )
    )


def check_security_findings(
    critical: int,
    high: int,
    fail_on_findings: bool,
    min_score: float | None = None,
    actual_score: float | None = None,
) -> ExitCode:
    """Check findings and determine exit code for CI/CD.

    Returns:
        ExitCode indicating the result:
        - SUCCESS if no issues
        - CRITICAL_FINDINGS if critical findings and fail_on_findings
        - SECURITY_FINDINGS if high findings and fail_on_findings
        - SCORE_BELOW_THRESHOLD if score below minimum
    """
    if fail_on_findings and critical > 0:
        return ExitCode.CRITICAL_FINDINGS

    if fail_on_findings and high > 0:
        return ExitCode.SECURITY_FINDINGS

    if min_score is not None and actual_score is not None:
        if actual_score < min_score:
            return ExitCode.SCORE_BELOW_THRESHOLD

    return ExitCode.SUCCESS
