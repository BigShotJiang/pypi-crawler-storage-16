"""Dependency mapping and topology analysis for multi-agent systems.

Visualizes and analyzes agent relationships, communication patterns,
and information flow through the system.
"""

from __future__ import annotations

from typing import Any

import networkx as nx

from vantage_core.core.models import AgentSystem


class DependencyMapper:
    """Maps and analyzes dependencies between agents."""

    def __init__(self, system: AgentSystem):
        """Initialize dependency mapper.

        Args:
            system: The agent system to analyze
        """
        self.system = system
        self._graph = self._build_graph()

    def _build_graph(self) -> nx.DiGraph:
        """Build a NetworkX directed graph from the system topology."""
        graph = nx.DiGraph()

        # Add nodes (agents)
        for agent_id, agent in self.system.agents.items():
            graph.add_node(
                agent_id,
                name=agent.name,
                description=agent.description,
                token_count=agent.prompt.token_estimate(),
            )

        # Add edges (connections)
        for connection in self.system.topology.connections:
            graph.add_edge(
                connection.source,
                connection.target,
                pattern=connection.pattern.value,
                condition=connection.condition,
                data_passed=connection.data_passed,
            )

        return graph

    def get_dependency_graph(self) -> dict[str, list[str]]:
        """Get agent dependencies as an adjacency list.

        Returns:
            Dict mapping agent_id -> list of downstream agent_ids
        """
        return {
            agent_id: list(self._graph.successors(agent_id)) for agent_id in self._graph.nodes()
        }

    def get_reverse_dependencies(self) -> dict[str, list[str]]:
        """Get reverse dependencies (who depends on whom).

        Returns:
            Dict mapping agent_id -> list of upstream agent_ids
        """
        return {
            agent_id: list(self._graph.predecessors(agent_id)) for agent_id in self._graph.nodes()
        }

    def find_critical_agents(self) -> list[str]:
        """Find agents that are critical to system flow.

        Critical agents are those with high betweenness centrality,
        meaning they sit on many paths between other agents.

        Returns:
            List of critical agent IDs sorted by importance
        """
        if len(self._graph.nodes()) < 2:
            return list(self._graph.nodes())

        try:
            centrality = nx.betweenness_centrality(self._graph)
            sorted_agents = sorted(centrality.items(), key=lambda x: x[1], reverse=True)
            # Return agents with above-average centrality
            avg_centrality = sum(centrality.values()) / len(centrality)
            return [agent_id for agent_id, score in sorted_agents if score > avg_centrality]
        except nx.NetworkXError:
            return []

    def find_bottlenecks(self) -> list[dict[str, Any]]:
        """Find potential bottlenecks in the system.

        Bottlenecks are agents with high in-degree (many inputs)
        or high out-degree (many outputs).

        Returns:
            List of bottleneck info dicts
        """
        bottlenecks = []

        for agent_id in self._graph.nodes():
            in_degree = self._graph.in_degree(agent_id)
            out_degree = self._graph.out_degree(agent_id)

            # Thresholds for bottleneck detection
            if in_degree >= 3 or out_degree >= 3:
                bottleneck_type = []
                if in_degree >= 3:
                    bottleneck_type.append("high_fan_in")
                if out_degree >= 3:
                    bottleneck_type.append("high_fan_out")

                bottlenecks.append(
                    {
                        "agent_id": agent_id,
                        "agent_name": self.system.agents[agent_id].name,
                        "in_degree": in_degree,
                        "out_degree": out_degree,
                        "bottleneck_type": bottleneck_type,
                        "recommendation": self._get_bottleneck_recommendation(
                            in_degree, out_degree
                        ),
                    }
                )

        return bottlenecks

    def _get_bottleneck_recommendation(self, in_degree: int, out_degree: int) -> str:
        """Get recommendation for addressing a bottleneck."""
        if in_degree >= 3 and out_degree >= 3:
            return (
                "This agent has many inputs and outputs. Consider splitting "
                "into multiple specialized agents to reduce complexity."
            )
        elif in_degree >= 3:
            return (
                "High fan-in detected. Consider adding a load balancer agent "
                "or batching inputs to prevent overload."
            )
        else:
            return (
                "High fan-out detected. Consider adding a router agent to "
                "manage delegation logic."
            )

    def get_execution_order(self) -> list[list[str]]:
        """Get suggested execution order using topological sort.

        Returns a list of "layers" where each layer can execute in parallel.

        Returns:
            List of agent ID lists (layers)
        """
        if not self._graph.nodes():
            return []

        # Check for cycles
        if not nx.is_directed_acyclic_graph(self._graph):
            # Can't topologically sort cyclic graph
            return [list(self._graph.nodes())]

        # Get topological generations (layers)
        try:
            return [list(gen) for gen in nx.topological_generations(self._graph)]
        except nx.NetworkXError:
            return [list(self._graph.nodes())]

    def find_isolated_subgraphs(self) -> list[set[str]]:
        """Find disconnected subgraphs (isolated agent clusters).

        Returns:
            List of sets of agent IDs in each subgraph
        """
        # Convert to undirected for connectivity analysis
        undirected = self._graph.to_undirected()
        components = list(nx.connected_components(undirected))

        # Only return if there are multiple components
        if len(components) > 1:
            return [comp for comp in components]

        return []

    def get_path_between_agents(
        self,
        source_id: str,
        target_id: str,
    ) -> list[str] | None:
        """Get the shortest path between two agents.

        Args:
            source_id: Source agent ID
            target_id: Target agent ID

        Returns:
            List of agent IDs in path, or None if no path exists
        """
        try:
            return nx.shortest_path(self._graph, source_id, target_id)
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            return None

    def get_all_paths_between_agents(
        self,
        source_id: str,
        target_id: str,
        max_paths: int = 10,
    ) -> list[list[str]]:
        """Get all simple paths between two agents.

        Args:
            source_id: Source agent ID
            target_id: Target agent ID
            max_paths: Maximum number of paths to return

        Returns:
            List of paths (each path is a list of agent IDs)
        """
        try:
            paths = list(nx.all_simple_paths(self._graph, source_id, target_id))
            return paths[:max_paths]
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            return []

    def compute_system_metrics(self) -> dict[str, Any]:
        """Compute various graph metrics for the system.

        Returns:
            Dict of metric names to values
        """
        metrics: dict[str, Any] = {
            "total_agents": len(self._graph.nodes()),
            "total_connections": len(self._graph.edges()),
        }

        if not self._graph.nodes():
            return metrics

        # Density (ratio of actual to possible connections)
        metrics["density"] = nx.density(self._graph)

        # Average degree
        degrees = [d for _, d in self._graph.degree()]
        metrics["avg_degree"] = sum(degrees) / len(degrees) if degrees else 0

        # Check if DAG
        metrics["is_dag"] = nx.is_directed_acyclic_graph(self._graph)

        # Number of entry points (no incoming edges)
        metrics["entry_points"] = sum(
            1 for n in self._graph.nodes() if self._graph.in_degree(n) == 0
        )

        # Number of exit points (no outgoing edges)
        metrics["exit_points"] = sum(
            1 for n in self._graph.nodes() if self._graph.out_degree(n) == 0
        )

        # Longest path length (if DAG)
        if metrics["is_dag"] and self._graph.nodes():
            try:
                metrics["longest_path_length"] = nx.dag_longest_path_length(self._graph)
            except nx.NetworkXError:
                metrics["longest_path_length"] = 0

        # Isolated subgraphs
        isolated = self.find_isolated_subgraphs()
        metrics["isolated_subgraphs"] = len(isolated)

        return metrics

    def to_mermaid(self) -> str:
        """Export topology as Mermaid diagram syntax.

        Returns:
            Mermaid diagram string
        """
        lines = ["graph TD"]

        # Add nodes with labels
        for agent_id in self._graph.nodes():
            agent = self.system.agents.get(agent_id)
            if agent:
                label = agent.name.replace('"', '\\"')
                lines.append(f'    {agent_id}["{label}"]')

        # Add edges
        for source, target, data in self._graph.edges(data=True):
            pattern = data.get("pattern", "sequential")
            condition = data.get("condition", "")

            if condition:
                label = f"|{condition}|"
                lines.append(f"    {source} -->{label} {target}")
            elif pattern == "parallel":
                lines.append(f"    {source} -.-> {target}")
            else:
                lines.append(f"    {source} --> {target}")

        # Style entry and exit points
        for entry in self.system.topology.entry_points:
            if entry in self._graph.nodes():
                lines.append(f"    style {entry} fill:#90EE90")

        for exit_point in self.system.topology.exit_points:
            if exit_point in self._graph.nodes():
                lines.append(f"    style {exit_point} fill:#FFB6C1")

        return "\n".join(lines)

    def to_ascii(self) -> str:
        """Generate a simple ASCII representation of the topology.

        Returns:
            ASCII diagram string
        """
        if not self._graph.nodes():
            return "Empty system - no agents defined"

        lines = []
        lines.append("Agent Topology")
        lines.append("=" * 40)

        # Get execution order for layering
        layers = self.get_execution_order()

        if not layers:
            layers = [list(self._graph.nodes())]

        for i, layer in enumerate(layers):
            lines.append(f"\nLayer {i + 1}:")
            for agent_id in layer:
                agent = self.system.agents.get(agent_id)
                name = agent.name if agent else agent_id

                # Get connections
                incoming = list(self._graph.predecessors(agent_id))
                outgoing = list(self._graph.successors(agent_id))

                if incoming:
                    incoming_str = f" <- [{', '.join(incoming)}]"
                else:
                    incoming_str = " (entry)"

                if outgoing:
                    outgoing_str = f" -> [{', '.join(outgoing)}]"
                else:
                    outgoing_str = " (exit)"

                lines.append(f"  [{agent_id}] {name}")
                lines.append(f"    {incoming_str}{outgoing_str}")

        return "\n".join(lines)

    def suggest_optimizations(self) -> list[dict[str, Any]]:
        """Suggest topology optimizations.

        Returns:
            List of optimization suggestions
        """
        suggestions = []

        metrics = self.compute_system_metrics()

        # Check for low density (disconnected agents)
        if metrics["density"] < 0.1 and metrics["total_agents"] > 2:
            suggestions.append(
                {
                    "type": "low_connectivity",
                    "severity": "medium",
                    "message": (
                        f"Low graph density ({metrics['density']:.2f}). "
                        "Some agents may not be well-connected."
                    ),
                    "recommendation": (
                        "Review agent connections and ensure all agents are "
                        "reachable from entry points."
                    ),
                }
            )

        # Check for multiple entry points
        if metrics["entry_points"] > 2:
            suggestions.append(
                {
                    "type": "multiple_entries",
                    "severity": "low",
                    "message": (
                        f"Multiple entry points detected ({metrics['entry_points']}). "
                        "This may complicate request routing."
                    ),
                    "recommendation": (
                        "Consider adding a router agent at the front to "
                        "direct requests to appropriate entry points."
                    ),
                }
            )

        # Check for isolated subgraphs
        if metrics["isolated_subgraphs"] > 0:
            suggestions.append(
                {
                    "type": "isolated_subgraphs",
                    "severity": "high",
                    "message": (
                        f"Isolated subgraphs detected ({metrics['isolated_subgraphs']}). "
                        "Some agents cannot communicate with others."
                    ),
                    "recommendation": ("Connect isolated subgraphs or remove unused agents."),
                }
            )

        # Check bottlenecks
        bottlenecks = self.find_bottlenecks()
        if bottlenecks:
            suggestions.append(
                {
                    "type": "bottlenecks",
                    "severity": "medium",
                    "message": (
                        f"Potential bottlenecks detected: "
                        f"{', '.join(b['agent_name'] for b in bottlenecks)}"
                    ),
                    "recommendation": bottlenecks[0]["recommendation"],
                }
            )

        if not suggestions:
            suggestions.append(
                {
                    "type": "healthy",
                    "severity": "info",
                    "message": "No topology issues detected.",
                    "recommendation": "Your topology looks healthy!",
                }
            )

        return suggestions
