"""
PDF Compliance Report Generator

Generates professional PDF reports for security auditors including:
- Executive summary
- OWASP LLM Top 10 mapping
- SOC 2 evidence summary
- Detailed findings
- Remediation recommendations
- Appendices with technical details

Uses reportlab for PDF generation (optional dependency).
Falls back to HTML report if reportlab is not installed.
"""

import html
from dataclasses import dataclass, field
from datetime import datetime

from vantage_core.compliance.owasp_mapping import (
    OWASP_CATEGORIES,
    OWASPCategory,
    OWASPMapping,
    get_owasp_coverage,
)
from vantage_core.compliance.soc2_evidence import (
    SOC2_AI_CONTROLS,
    SOC2EvidencePackage,
)


@dataclass
class ReportConfig:
    """Configuration for report generation."""

    # Report metadata
    title: str = "AI Agent Security Assessment Report"
    organization: str = ""
    system_name: str = ""
    report_date: str = ""
    prepared_by: str = "Vantage Security Scanner"
    confidentiality: str = "CONFIDENTIAL"

    # Content sections
    include_executive_summary: bool = True
    include_owasp_mapping: bool = True
    include_soc2_evidence: bool = True
    include_detailed_findings: bool = True
    include_remediation: bool = True
    include_appendices: bool = True

    # Styling
    logo_path: str | None = None
    primary_color: str = "#1a365d"  # Dark blue
    accent_color: str = "#3182ce"  # Blue
    header_font: str = "Helvetica-Bold"
    body_font: str = "Helvetica"

    def __post_init__(self):
        if not self.report_date:
            self.report_date = datetime.utcnow().strftime("%Y-%m-%d")


@dataclass
class ReportData:
    """Data for report generation."""

    # Scan results
    scan_results: dict = field(default_factory=dict)
    atss_score: int = 0
    atss_grade: str = "N/A"
    total_findings: int = 0
    critical_findings: int = 0
    high_findings: int = 0
    medium_findings: int = 0
    low_findings: int = 0

    # Agents
    agents_detected: int = 0
    frameworks: list[str] = field(default_factory=list)

    # Mappings
    owasp_mapping: OWASPMapping | None = None
    soc2_package: SOC2EvidencePackage | None = None

    # Findings
    findings: list[dict] = field(default_factory=list)


class ComplianceReportGenerator:
    """
    Generates compliance reports in PDF and HTML formats.

    Usage:
        generator = ComplianceReportGenerator(config)
        generator.generate_pdf(data, output_path)
        generator.generate_html(data, output_path)
    """

    def __init__(self, config: ReportConfig | None = None):
        """Initialize the report generator."""
        self.config = config or ReportConfig()

    def generate_pdf(self, data: ReportData, output_path: str) -> bool:
        """
        Generate a PDF compliance report.

        Args:
            data: Report data
            output_path: Path for output PDF

        Returns:
            True if PDF was generated, False if fell back to HTML
        """
        try:
            from reportlab.lib import colors
            from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
            from reportlab.lib.pagesizes import A4, letter
            from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
            from reportlab.lib.units import inch
            from reportlab.platypus import (
                Image,
                ListFlowable,
                ListItem,
                PageBreak,
                Paragraph,
                SimpleDocTemplate,
                Spacer,
                Table,
                TableStyle,
            )

            return self._generate_pdf_reportlab(data, output_path)

        except ImportError:
            # Fall back to HTML
            html_path = output_path.replace(".pdf", ".html")
            self.generate_html(data, html_path)
            print(f"reportlab not installed. Generated HTML report: {html_path}")
            print("Install reportlab for PDF: pip install reportlab")
            return False

    def _generate_pdf_reportlab(self, data: ReportData, output_path: str) -> bool:
        """Generate PDF using reportlab."""
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.lib.units import inch
        from reportlab.platypus import (
            PageBreak,
            Paragraph,
            SimpleDocTemplate,
            Spacer,
            Table,
            TableStyle,
        )

        # Create document
        doc = SimpleDocTemplate(
            output_path,
            pagesize=letter,
            rightMargin=0.75 * inch,
            leftMargin=0.75 * inch,
            topMargin=0.75 * inch,
            bottomMargin=0.75 * inch,
        )

        # Styles
        styles = getSampleStyleSheet()
        styles.add(
            ParagraphStyle(
                name="Title",
                parent=styles["Heading1"],
                fontSize=24,
                spaceAfter=30,
                alignment=TA_CENTER,
            )
        )
        styles.add(
            ParagraphStyle(
                name="Subtitle",
                parent=styles["Normal"],
                fontSize=12,
                alignment=TA_CENTER,
                textColor=colors.gray,
            )
        )
        styles.add(
            ParagraphStyle(
                name="SectionHeading",
                parent=styles["Heading2"],
                fontSize=16,
                spaceBefore=20,
                spaceAfter=10,
                textColor=colors.HexColor(self.config.primary_color),
            )
        )
        styles.add(
            ParagraphStyle(
                name="SubHeading",
                parent=styles["Heading3"],
                fontSize=12,
                spaceBefore=15,
                spaceAfter=8,
            )
        )
        styles.add(
            ParagraphStyle(
                name="BodyText",
                parent=styles["Normal"],
                fontSize=10,
                alignment=TA_JUSTIFY,
                spaceAfter=8,
            )
        )
        styles.add(
            ParagraphStyle(
                name="FindingCritical",
                parent=styles["Normal"],
                fontSize=10,
                textColor=colors.red,
                spaceBefore=4,
            )
        )
        styles.add(
            ParagraphStyle(
                name="FindingHigh",
                parent=styles["Normal"],
                fontSize=10,
                textColor=colors.HexColor("#DC2626"),
                spaceBefore=4,
            )
        )

        # Build content
        story = []

        # Title page
        story.append(Spacer(1, 2 * inch))
        story.append(Paragraph(self.config.title, styles["Title"]))
        story.append(Spacer(1, 0.5 * inch))

        if self.config.organization:
            story.append(Paragraph(self.config.organization, styles["Subtitle"]))
        if self.config.system_name:
            story.append(Paragraph(f"System: {self.config.system_name}", styles["Subtitle"]))

        story.append(Spacer(1, 0.5 * inch))
        story.append(Paragraph(f"Report Date: {self.config.report_date}", styles["Subtitle"]))
        story.append(Paragraph(f"Prepared by: {self.config.prepared_by}", styles["Subtitle"]))
        story.append(Spacer(1, inch))
        story.append(Paragraph(self.config.confidentiality, styles["Subtitle"]))
        story.append(PageBreak())

        # Executive Summary
        if self.config.include_executive_summary:
            story.append(Paragraph("Executive Summary", styles["SectionHeading"]))

            # Score summary
            grade_color = self._get_grade_color(data.atss_grade)
            summary_text = f"""
            This report presents the security assessment results for the AI agent system.
            The system achieved an <b>ATSS Score of {data.atss_score}/100</b>
            (Grade: <font color="{grade_color}"><b>{data.atss_grade}</b></font>).
            """
            story.append(Paragraph(summary_text, styles["BodyText"]))

            # Findings summary table
            findings_data = [
                ["Severity", "Count"],
                ["Critical", str(data.critical_findings)],
                ["High", str(data.high_findings)],
                ["Medium", str(data.medium_findings)],
                ["Low", str(data.low_findings)],
                ["Total", str(data.total_findings)],
            ]
            findings_table = Table(findings_data, colWidths=[2 * inch, 1.5 * inch])
            findings_table.setStyle(
                TableStyle(
                    [
                        (
                            "BACKGROUND",
                            (0, 0),
                            (-1, 0),
                            colors.HexColor(self.config.primary_color),
                        ),
                        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                        ("FONTSIZE", (0, 0), (-1, -1), 10),
                        ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                        (
                            "BACKGROUND",
                            (0, 1),
                            (-1, 1),
                            colors.HexColor("#FEE2E2"),
                        ),  # Critical - red
                        (
                            "BACKGROUND",
                            (0, 2),
                            (-1, 2),
                            colors.HexColor("#FED7AA"),
                        ),  # High - orange
                        (
                            "BACKGROUND",
                            (0, 3),
                            (-1, 3),
                            colors.HexColor("#FEF3C7"),
                        ),  # Medium - yellow
                        (
                            "BACKGROUND",
                            (0, 4),
                            (-1, 4),
                            colors.HexColor("#D1FAE5"),
                        ),  # Low - green
                        ("GRID", (0, 0), (-1, -1), 1, colors.black),
                    ]
                )
            )
            story.append(Spacer(1, 0.25 * inch))
            story.append(findings_table)

            # Key metrics
            story.append(Spacer(1, 0.25 * inch))
            story.append(Paragraph("Key Metrics", styles["SubHeading"]))
            metrics_text = f"""
            * AI Agents Detected: {data.agents_detected}<br/>
            * Frameworks: {', '.join(data.frameworks) if data.frameworks else 'None detected'}<br/>
            * Scan Date: {self.config.report_date}
            """
            story.append(Paragraph(metrics_text, styles["BodyText"]))
            story.append(PageBreak())

        # OWASP LLM Top 10 Mapping
        if self.config.include_owasp_mapping and data.owasp_mapping:
            story.append(Paragraph("OWASP LLM Top 10 Mapping", styles["SectionHeading"]))

            owasp_text = """
            This section maps the identified vulnerabilities to the OWASP Top 10 for
            Large Language Model Applications. This mapping helps identify compliance
            with industry-standard security categories for LLM systems.
            """
            story.append(Paragraph(owasp_text, styles["BodyText"]))

            coverage = get_owasp_coverage(data.owasp_mapping)

            # Coverage table
            owasp_data = [["Category", "Name", "Findings"]]
            for cat in OWASPCategory:
                count = data.owasp_mapping.get_category_count(cat)
                owasp_data.append(
                    [
                        cat.value,
                        OWASP_CATEGORIES[cat].name,
                        str(count) if count > 0 else "-",
                    ]
                )

            owasp_table = Table(owasp_data, colWidths=[1 * inch, 3.5 * inch, 1 * inch])
            owasp_table.setStyle(
                TableStyle(
                    [
                        (
                            "BACKGROUND",
                            (0, 0),
                            (-1, 0),
                            colors.HexColor(self.config.primary_color),
                        ),
                        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                        ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                        ("ALIGN", (2, 0), (2, -1), "CENTER"),
                        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                        ("FONTSIZE", (0, 0), (-1, -1), 9),
                        ("GRID", (0, 0), (-1, -1), 0.5, colors.gray),
                        (
                            "ROWBACKGROUNDS",
                            (0, 1),
                            (-1, -1),
                            [colors.white, colors.HexColor("#F7FAFC")],
                        ),
                    ]
                )
            )
            story.append(Spacer(1, 0.25 * inch))
            story.append(owasp_table)

            story.append(Spacer(1, 0.25 * inch))
            coverage_text = f"""
            <b>Coverage Summary:</b> {coverage['categories_covered']} of {coverage['total_categories']}
            OWASP categories have associated findings ({coverage['coverage_percentage']:.1f}% coverage).
            """
            story.append(Paragraph(coverage_text, styles["BodyText"]))
            story.append(PageBreak())

        # SOC 2 Evidence Summary
        if self.config.include_soc2_evidence and data.soc2_package:
            story.append(Paragraph("SOC 2 Evidence Summary", styles["SectionHeading"]))

            soc2_text = """
            This section summarizes the evidence collected for SOC 2 Type II compliance
            related to AI/LLM security controls. The following controls were evaluated:
            """
            story.append(Paragraph(soc2_text, styles["BodyText"]))

            coverage = data.soc2_package.get_coverage_summary()

            # SOC 2 coverage table
            soc2_data = [["Control", "Name", "Category", "Status"]]
            for control_id, control in SOC2_AI_CONTROLS.items():
                status = (
                    "Covered" if control_id in data.soc2_package.controls_covered else "Missing"
                )
                soc2_data.append(
                    [
                        control_id,
                        control.name[:35],
                        control.category.value,
                        status,
                    ]
                )

            soc2_table = Table(soc2_data, colWidths=[0.8 * inch, 2.5 * inch, 1.5 * inch, 1 * inch])
            soc2_table.setStyle(
                TableStyle(
                    [
                        (
                            "BACKGROUND",
                            (0, 0),
                            (-1, 0),
                            colors.HexColor(self.config.primary_color),
                        ),
                        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                        ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                        ("FONTSIZE", (0, 0), (-1, -1), 9),
                        ("GRID", (0, 0), (-1, -1), 0.5, colors.gray),
                        (
                            "ROWBACKGROUNDS",
                            (0, 1),
                            (-1, -1),
                            [colors.white, colors.HexColor("#F7FAFC")],
                        ),
                    ]
                )
            )
            story.append(Spacer(1, 0.25 * inch))
            story.append(soc2_table)

            story.append(Spacer(1, 0.25 * inch))
            soc2_summary = f"""
            <b>Evidence Summary:</b> {coverage['controls_covered']} of {coverage['total_controls']}
            controls have evidence collected ({coverage['coverage_percentage']:.1f}% coverage).
            Total evidence items: {coverage['evidence_count']}.
            """
            story.append(Paragraph(soc2_summary, styles["BodyText"]))
            story.append(PageBreak())

        # Detailed Findings
        if self.config.include_detailed_findings and data.findings:
            story.append(Paragraph("Detailed Findings", styles["SectionHeading"]))

            for i, finding in enumerate(data.findings[:50], 1):  # Limit to 50
                severity = finding.get("severity", "medium").lower()
                sev_style = (
                    f"Finding{severity.title()}" if severity in ["critical", "high"] else "BodyText"
                )

                story.append(
                    Paragraph(
                        f"<b>Finding {i}:</b> {finding.get('type', 'Unknown')} "
                        f"[{severity.upper()}]",
                        styles.get(sev_style, styles["BodyText"]),
                    )
                )

                if finding.get("description"):
                    story.append(
                        Paragraph(
                            f"Description: {finding.get('description')}",
                            styles["BodyText"],
                        )
                    )

                if finding.get("location"):
                    story.append(
                        Paragraph(
                            f"Location: {finding.get('location')}",
                            styles["BodyText"],
                        )
                    )

                if finding.get("remediation"):
                    story.append(
                        Paragraph(
                            f"<b>Remediation:</b> {finding.get('remediation')}",
                            styles["BodyText"],
                        )
                    )

                story.append(Spacer(1, 0.15 * inch))

            if len(data.findings) > 50:
                story.append(
                    Paragraph(
                        f"... and {len(data.findings) - 50} more findings. "
                        "See appendix for complete list.",
                        styles["BodyText"],
                    )
                )

        # Build PDF
        doc.build(story)
        return True

    def _get_grade_color(self, grade: str) -> str:
        """Get color for grade."""
        colors = {
            "A": "#059669",  # Green
            "B": "#10B981",  # Light green
            "C": "#F59E0B",  # Yellow
            "D": "#F97316",  # Orange
            "F": "#DC2626",  # Red
        }
        return colors.get(grade, "#6B7280")

    def generate_html(self, data: ReportData, output_path: str) -> None:
        """
        Generate an HTML compliance report.

        Args:
            data: Report data
            output_path: Path for output HTML
        """
        html_content = self._build_html_report(data)
        with open(output_path, "w") as f:
            f.write(html_content)

    def _build_html_report(self, data: ReportData) -> str:
        """Build HTML report content."""
        grade_color = self._get_grade_color(data.atss_grade)

        # Build OWASP section
        owasp_html = ""
        if self.config.include_owasp_mapping and data.owasp_mapping:
            owasp_rows = ""
            for cat in OWASPCategory:
                count = data.owasp_mapping.get_category_count(cat)
                owasp_rows += f"""
                <tr>
                    <td>{cat.value}</td>
                    <td>{OWASP_CATEGORIES[cat].name}</td>
                    <td class="text-center">{count if count > 0 else '-'}</td>
                </tr>
                """
            coverage = get_owasp_coverage(data.owasp_mapping)
            owasp_html = f"""
            <section class="section">
                <h2>OWASP LLM Top 10 Mapping</h2>
                <p>This section maps vulnerabilities to the OWASP Top 10 for LLM Applications.</p>
                <table>
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th>Name</th>
                            <th>Findings</th>
                        </tr>
                    </thead>
                    <tbody>
                        {owasp_rows}
                    </tbody>
                </table>
                <p><strong>Coverage:</strong> {coverage['categories_covered']} of {coverage['total_categories']} categories
                ({coverage['coverage_percentage']:.1f}%)</p>
            </section>
            """

        # Build SOC 2 section
        soc2_html = ""
        if self.config.include_soc2_evidence and data.soc2_package:
            soc2_rows = ""
            for control_id, control in SOC2_AI_CONTROLS.items():
                status = (
                    "Covered" if control_id in data.soc2_package.controls_covered else "Missing"
                )
                status_class = "status-covered" if status == "Covered" else "status-missing"
                soc2_rows += f"""
                <tr>
                    <td>{control_id}</td>
                    <td>{control.name}</td>
                    <td>{control.category.value}</td>
                    <td class="{status_class}">{status}</td>
                </tr>
                """
            coverage = data.soc2_package.get_coverage_summary()
            soc2_html = f"""
            <section class="section">
                <h2>SOC 2 Evidence Summary</h2>
                <p>Evidence collected for SOC 2 Type II compliance.</p>
                <table>
                    <thead>
                        <tr>
                            <th>Control</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {soc2_rows}
                    </tbody>
                </table>
                <p><strong>Coverage:</strong> {coverage['controls_covered']} of {coverage['total_controls']} controls
                ({coverage['coverage_percentage']:.1f}%)</p>
            </section>
            """

        # Build findings section
        findings_html = ""
        if self.config.include_detailed_findings and data.findings:
            findings_items = ""
            for i, finding in enumerate(data.findings[:50], 1):
                severity = finding.get("severity", "medium").lower()
                findings_items += f"""
                <div class="finding finding-{severity}">
                    <h4>Finding {i}: {html.escape(finding.get('type', 'Unknown'))}
                        <span class="severity severity-{severity}">{severity.upper()}</span>
                    </h4>
                    <p><strong>Description:</strong> {html.escape(finding.get('description', 'N/A'))}</p>
                    <p><strong>Location:</strong> {html.escape(finding.get('location', 'N/A'))}</p>
                    {f"<p><strong>Remediation:</strong> {html.escape(finding.get('remediation', ''))}</p>" if finding.get('remediation') else ''}
                </div>
                """
            findings_html = f"""
            <section class="section">
                <h2>Detailed Findings</h2>
                {findings_items}
                {f'<p class="note">... and {len(data.findings) - 50} more findings.</p>' if len(data.findings) > 50 else ''}
            </section>
            """

        return f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{html.escape(self.config.title)}</title>
    <style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            color: #1a202c;
            max-width: 900px;
            margin: 0 auto;
            padding: 40px 20px;
        }}
        .header {{
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 2px solid {self.config.primary_color};
        }}
        h1 {{ color: {self.config.primary_color}; font-size: 28px; margin-bottom: 10px; }}
        .subtitle {{ color: #718096; font-size: 14px; }}
        .confidential {{
            display: inline-block;
            background: #EDF2F7;
            padding: 4px 12px;
            border-radius: 4px;
            font-size: 12px;
            margin-top: 15px;
        }}
        .section {{ margin-bottom: 40px; }}
        h2 {{
            color: {self.config.primary_color};
            font-size: 20px;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 1px solid #E2E8F0;
        }}
        .score-box {{
            background: linear-gradient(135deg, {self.config.primary_color}, {self.config.accent_color});
            color: white;
            padding: 30px;
            border-radius: 12px;
            text-align: center;
            margin: 20px 0;
        }}
        .score {{ font-size: 48px; font-weight: bold; }}
        .grade {{ font-size: 24px; color: {grade_color}; background: white; padding: 5px 15px; border-radius: 8px; margin-top: 10px; display: inline-block; }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }}
        th, td {{
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #E2E8F0;
        }}
        th {{
            background: {self.config.primary_color};
            color: white;
            font-weight: 600;
        }}
        tr:nth-child(even) {{ background: #F7FAFC; }}
        .text-center {{ text-align: center; }}
        .finding {{
            background: #F7FAFC;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 4px solid #CBD5E0;
        }}
        .finding-critical {{ border-left-color: #DC2626; }}
        .finding-high {{ border-left-color: #F97316; }}
        .finding-medium {{ border-left-color: #F59E0B; }}
        .finding-low {{ border-left-color: #10B981; }}
        .finding h4 {{ margin-bottom: 10px; }}
        .severity {{
            font-size: 11px;
            padding: 2px 8px;
            border-radius: 4px;
            margin-left: 10px;
        }}
        .severity-critical {{ background: #FEE2E2; color: #DC2626; }}
        .severity-high {{ background: #FED7AA; color: #C2410C; }}
        .severity-medium {{ background: #FEF3C7; color: #B45309; }}
        .severity-low {{ background: #D1FAE5; color: #059669; }}
        .status-covered {{ color: #059669; font-weight: bold; }}
        .status-missing {{ color: #9CA3AF; }}
        .metrics-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }}
        .metric {{
            background: #F7FAFC;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }}
        .metric-value {{ font-size: 24px; font-weight: bold; color: {self.config.primary_color}; }}
        .metric-label {{ font-size: 12px; color: #718096; }}
        .note {{ font-style: italic; color: #718096; }}
        @media print {{
            body {{ padding: 20px; }}
            .section {{ page-break-inside: avoid; }}
        }}
    </style>
</head>
<body>
    <header class="header">
        <h1>{html.escape(self.config.title)}</h1>
        {f'<p class="subtitle">{html.escape(self.config.organization)}</p>' if self.config.organization else ''}
        {f'<p class="subtitle">System: {html.escape(self.config.system_name)}</p>' if self.config.system_name else ''}
        <p class="subtitle">Report Date: {self.config.report_date} | Prepared by: {html.escape(self.config.prepared_by)}</p>
        <span class="confidential">{html.escape(self.config.confidentiality)}</span>
    </header>

    <section class="section">
        <h2>Executive Summary</h2>
        <div class="score-box">
            <div class="score">{data.atss_score}/100</div>
            <div class="grade">Grade: {data.atss_grade}</div>
        </div>

        <div class="metrics-grid">
            <div class="metric">
                <div class="metric-value">{data.total_findings}</div>
                <div class="metric-label">Total Findings</div>
            </div>
            <div class="metric">
                <div class="metric-value" style="color: #DC2626;">{data.critical_findings}</div>
                <div class="metric-label">Critical</div>
            </div>
            <div class="metric">
                <div class="metric-value" style="color: #F97316;">{data.high_findings}</div>
                <div class="metric-label">High</div>
            </div>
            <div class="metric">
                <div class="metric-value">{data.agents_detected}</div>
                <div class="metric-label">Agents Detected</div>
            </div>
        </div>

        <p><strong>Frameworks:</strong> {', '.join(data.frameworks) if data.frameworks else 'None detected'}</p>
    </section>

    {owasp_html}
    {soc2_html}
    {findings_html}

    <footer style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #E2E8F0; text-align: center; color: #718096; font-size: 12px;">
        Generated by Vantage Security Scanner | {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}
    </footer>
</body>
</html>
        """


def generate_compliance_report(
    scan_results: dict,
    output_path: str,
    format: str = "pdf",
    owasp_mapping: OWASPMapping | None = None,
    soc2_package: SOC2EvidencePackage | None = None,
    config: ReportConfig | None = None,
) -> str:
    """
    Generate a compliance report from scan results.

    Args:
        scan_results: Vantage scan results
        output_path: Output file path
        format: Output format ('pdf' or 'html')
        owasp_mapping: Optional pre-computed OWASP mapping
        soc2_package: Optional pre-computed SOC 2 package
        config: Report configuration

    Returns:
        Path to generated report
    """
    # Build report data
    data = ReportData(
        scan_results=scan_results,
        atss_score=scan_results.get("score", 0),
        atss_grade=scan_results.get("grade", "N/A"),
        total_findings=scan_results.get("findings_count", len(scan_results.get("findings", []))),
        critical_findings=scan_results.get("critical_count", 0),
        high_findings=scan_results.get("high_count", 0),
        medium_findings=scan_results.get("medium_count", 0),
        low_findings=scan_results.get("low_count", 0),
        agents_detected=scan_results.get("agents_detected", 0),
        frameworks=scan_results.get("frameworks", []),
        owasp_mapping=owasp_mapping,
        soc2_package=soc2_package,
        findings=scan_results.get("findings", []),
    )

    # Generate report
    generator = ComplianceReportGenerator(config)

    if format.lower() == "pdf":
        success = generator.generate_pdf(data, output_path)
        if not success:
            # Fell back to HTML
            return output_path.replace(".pdf", ".html")
    else:
        generator.generate_html(data, output_path)

    return output_path
