from dataclasses import dataclass

@dataclass
class LicenseStatus:
    is_valid: bool = True
    tier: str = "free"
    features: list = None

def check_license() -> LicenseStatus:
    return LicenseStatus(is_valid=True, tier="free", features=["basic_scan"])

def require_feature(feature_name: str) -> bool:
    return False

