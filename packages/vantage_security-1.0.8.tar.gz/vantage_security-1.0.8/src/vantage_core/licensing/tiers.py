"""Tier definitions and feature access control.

Defines the three tiers and their capabilities:
- Community: Free, open source features
- Professional: Paid individual/team tier
- Enterprise: Full-featured enterprise tier
"""

from dataclasses import dataclass
from enum import Enum
from typing import Any


class Tier(str, Enum):
    """License tier levels."""

    COMMUNITY = "community"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"


class TierFeature(str, Enum):
    """Features that can be gated by tier."""

    # Payload features
    BASIC_PAYLOADS = "basic_payloads"  # 33 basic payloads
    FULL_PAYLOADS = "full_payloads"  # All 206+ payloads
    CUSTOM_PAYLOADS = "custom_payloads"  # Enterprise custom payloads

    # Testing features
    MOCK_TESTING = "mock_testing"  # Mock/simulated testing
    LIVE_LLM_TESTING = "live_llm_testing"  # Real LLM API testing
    MULTI_MODEL_TESTING = "multi_model_testing"  # Test across multiple models

    # Analysis features
    BASIC_SCANNING = "basic_scanning"  # Agent detection, basic vulnerabilities
    ADVANCED_SCANNING = "advanced_scanning"  # Full security pipeline
    ML_DETECTION = "ml_detection"  # ML-based detection
    EFFECTIVENESS_SCORES = "effectiveness_scores"  # Payload effectiveness data
    FRAMEWORK_STATS = "framework_stats"  # Framework vulnerability statistics

    # Reporting features
    CLI_REPORTS = "cli_reports"  # Basic CLI output
    JSON_EXPORT = "json_export"  # JSON export
    SARIF_EXPORT = "sarif_export"  # SARIF for code scanning
    COMPLIANCE_REPORTS = "compliance_reports"  # OWASP/SOC2 reports
    PDF_REPORTS = "pdf_reports"  # PDF generation

    # Dashboard features
    BASIC_DASHBOARD = "basic_dashboard"  # Basic stats
    TEAM_DASHBOARD = "team_dashboard"  # Full team dashboard
    REMEDIATION_TRACKING = "remediation_tracking"  # Remediation management
    HISTORICAL_TRENDS = "historical_trends"  # Trend analysis

    # Integration features
    CI_CD_BASIC = "ci_cd_basic"  # Basic CI/CD integration
    CI_CD_ADVANCED = "ci_cd_advanced"  # Advanced CI/CD features
    API_ACCESS = "api_access"  # REST API access
    WEBHOOK_NOTIFICATIONS = "webhook_notifications"  # Webhook alerts

    # Support features
    COMMUNITY_SUPPORT = "community_support"  # GitHub issues
    EMAIL_SUPPORT = "email_support"  # Email support
    PRIORITY_SUPPORT = "priority_support"  # Priority support


@dataclass
class TierLimits:
    """Numerical limits for a tier."""

    payload_count: int
    scans_per_day: int
    agents_per_scan: int
    findings_detail_level: str  # "basic", "standard", "full"
    history_retention_days: int
    team_members: int
    projects: int
    api_requests_per_hour: int

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "payload_count": self.payload_count,
            "scans_per_day": self.scans_per_day,
            "agents_per_scan": self.agents_per_scan,
            "findings_detail_level": self.findings_detail_level,
            "history_retention_days": self.history_retention_days,
            "team_members": self.team_members,
            "projects": self.projects,
            "api_requests_per_hour": self.api_requests_per_hour,
        }


# Feature availability by tier
TIER_FEATURES: dict[Tier, set[TierFeature]] = {
    Tier.COMMUNITY: {
        # Basic payload access
        TierFeature.BASIC_PAYLOADS,
        # Testing
        TierFeature.MOCK_TESTING,
        # Analysis
        TierFeature.BASIC_SCANNING,
        # Reporting
        TierFeature.CLI_REPORTS,
        TierFeature.JSON_EXPORT,
        # Dashboard
        TierFeature.BASIC_DASHBOARD,
        # Integration
        TierFeature.CI_CD_BASIC,
        # Support
        TierFeature.COMMUNITY_SUPPORT,
    },
    Tier.PROFESSIONAL: {
        # All community features
        TierFeature.BASIC_PAYLOADS,
        TierFeature.MOCK_TESTING,
        TierFeature.BASIC_SCANNING,
        TierFeature.CLI_REPORTS,
        TierFeature.JSON_EXPORT,
        TierFeature.BASIC_DASHBOARD,
        TierFeature.CI_CD_BASIC,
        TierFeature.COMMUNITY_SUPPORT,
        # Professional features
        TierFeature.FULL_PAYLOADS,
        TierFeature.LIVE_LLM_TESTING,
        TierFeature.ADVANCED_SCANNING,
        TierFeature.ML_DETECTION,
        TierFeature.EFFECTIVENESS_SCORES,
        TierFeature.FRAMEWORK_STATS,
        TierFeature.SARIF_EXPORT,
        TierFeature.COMPLIANCE_REPORTS,
        TierFeature.TEAM_DASHBOARD,
        TierFeature.HISTORICAL_TRENDS,
        TierFeature.CI_CD_ADVANCED,
        TierFeature.API_ACCESS,
        TierFeature.EMAIL_SUPPORT,
    },
    Tier.ENTERPRISE: {
        # All professional features
        TierFeature.BASIC_PAYLOADS,
        TierFeature.FULL_PAYLOADS,
        TierFeature.MOCK_TESTING,
        TierFeature.LIVE_LLM_TESTING,
        TierFeature.BASIC_SCANNING,
        TierFeature.ADVANCED_SCANNING,
        TierFeature.ML_DETECTION,
        TierFeature.EFFECTIVENESS_SCORES,
        TierFeature.FRAMEWORK_STATS,
        TierFeature.CLI_REPORTS,
        TierFeature.JSON_EXPORT,
        TierFeature.SARIF_EXPORT,
        TierFeature.COMPLIANCE_REPORTS,
        TierFeature.BASIC_DASHBOARD,
        TierFeature.TEAM_DASHBOARD,
        TierFeature.HISTORICAL_TRENDS,
        TierFeature.CI_CD_BASIC,
        TierFeature.CI_CD_ADVANCED,
        TierFeature.API_ACCESS,
        TierFeature.COMMUNITY_SUPPORT,
        TierFeature.EMAIL_SUPPORT,
        # Enterprise-only features
        TierFeature.CUSTOM_PAYLOADS,
        TierFeature.MULTI_MODEL_TESTING,
        TierFeature.PDF_REPORTS,
        TierFeature.REMEDIATION_TRACKING,
        TierFeature.WEBHOOK_NOTIFICATIONS,
        TierFeature.PRIORITY_SUPPORT,
    },
}

# Numerical limits by tier
TIER_LIMITS: dict[Tier, TierLimits] = {
    Tier.COMMUNITY: TierLimits(
        payload_count=33,
        scans_per_day=10,
        agents_per_scan=20,
        findings_detail_level="basic",
        history_retention_days=7,
        team_members=1,
        projects=3,
        api_requests_per_hour=0,  # No API access
    ),
    Tier.PROFESSIONAL: TierLimits(
        payload_count=206,  # Full database
        scans_per_day=100,
        agents_per_scan=100,
        findings_detail_level="standard",
        history_retention_days=90,
        team_members=10,
        projects=20,
        api_requests_per_hour=1000,
    ),
    Tier.ENTERPRISE: TierLimits(
        payload_count=-1,  # Unlimited (includes custom)
        scans_per_day=-1,  # Unlimited
        agents_per_scan=-1,  # Unlimited
        findings_detail_level="full",
        history_retention_days=365,
        team_members=-1,  # Unlimited
        projects=-1,  # Unlimited
        api_requests_per_hour=-1,  # Unlimited
    ),
}


def get_tier_features(tier: Tier) -> set[TierFeature]:
    """Get features available for a tier.

    Args:
        tier: The tier level

    Returns:
        Set of available features
    """
    return TIER_FEATURES.get(tier, TIER_FEATURES[Tier.COMMUNITY])


def get_tier_limits(tier: Tier) -> TierLimits:
    """Get numerical limits for a tier.

    Args:
        tier: The tier level

    Returns:
        TierLimits object
    """
    return TIER_LIMITS.get(tier, TIER_LIMITS[Tier.COMMUNITY])


def is_feature_available(feature: TierFeature, tier: Tier) -> bool:
    """Check if a feature is available for a tier.

    Args:
        feature: The feature to check
        tier: The tier level

    Returns:
        True if feature is available
    """
    return feature in get_tier_features(tier)


def get_minimum_tier_for_feature(feature: TierFeature) -> Tier:
    """Get the minimum tier required for a feature.

    Args:
        feature: The feature to check

    Returns:
        Minimum required tier
    """
    for tier in [Tier.COMMUNITY, Tier.PROFESSIONAL, Tier.ENTERPRISE]:
        if feature in TIER_FEATURES[tier]:
            return tier
    return Tier.ENTERPRISE


def get_tier_comparison() -> dict[str, dict[str, Any]]:
    """Get a comparison of all tiers for display.

    Returns:
        Dictionary with tier comparison data
    """
    comparison = {}

    for tier in Tier:
        features = get_tier_features(tier)
        limits = get_tier_limits(tier)

        comparison[tier.value] = {
            "name": tier.value.title(),
            "features": [f.value for f in features],
            "limits": limits.to_dict(),
            "feature_count": len(features),
        }

    return comparison
