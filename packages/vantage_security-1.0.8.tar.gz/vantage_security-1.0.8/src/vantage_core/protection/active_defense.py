"""
Active Defense Middleware (Security Decorator).

Wraps agent functions to provide real-time protection against:
1. Prompt Injection
2. PII Leaks
3. Toxic Output

Usage:
    @SecurityDecorator(config=SecurityConfig(...))
    def my_agent_tool(input_str):
        ...
"""

import functools
import logging
import re
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from vantage_core.protection.detector_engine import HybridDetector

logger = logging.getLogger(__name__)


@dataclass
class SecurityConfig:
    block_injection: bool = True
    block_pii: bool = True
    threshold: float = 0.85
    action: str = "log"  # block, log, sanitize
    whitelist: list[str] = field(default_factory=list)


class SecurityDecorator:
    def __init__(self, config: SecurityConfig | None = None):
        self.config = config or SecurityConfig()
        self.detector = HybridDetector()

    def __call__(self, func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # 1. Scan Arguments (Input Hardening)
            for arg in args:
                if isinstance(arg, str):
                    self._check_input(arg)

            for key, val in kwargs.items():
                if isinstance(val, str):
                    self._check_input(val)

            # 2. Execute Function
            result = func(*args, **kwargs)

            # 3. Scan Output (Leak Prevention - TODO)
            return result

        return wrapper

    def _check_input(self, text: str) -> Any:
        # Check Whitelist First
        if self.config.whitelist:
            for pattern in self.config.whitelist:
                if re.search(pattern, text, re.IGNORECASE):
                    # Whitelisted
                    from vantage_core.protection.detector_engine import DetectionResult

                    logger.debug(f"Input matches whitelist pattern: {pattern}")
                    return DetectionResult(False, 0.0, {"action": "allow", "reason": "whitelisted"})

        if not self.config.block_injection:
            # Return a dummy safe result if scanning is off
            # We import here to avoid circular deps if needed, or assume imports exist
            from vantage_core.protection.detector_engine import DetectionResult

            return DetectionResult(False, 0.0)

        result = self.detector.detect(text)

        # Store action for logger
        result.metadata = result.metadata or {}

        if result.is_injection and result.confidence >= self.config.threshold:
            msg = f"Security Violation: Prompt injection detected (confidence {result.confidence})"
            logger.warning(msg)

            if self.config.action == "block":
                result.metadata["action"] = "block"
                raise SecurityViolationError(msg)
            else:
                result.metadata["action"] = "log"
        else:
            result.metadata["action"] = "allow"

        return result


class SecurityViolationError(Exception):
    """Raised when a security policy is violated."""

    pass
