"""
Developer Experience (DevX) Logging Module.

Provides real-time, rich visual feedback for security events during development.
Acts as a \"Live Traffic Monitor\" for the agent's security layer.
"""

from datetime import datetime

from rich.console import Console
from rich.markup import escape
from rich.theme import Theme

# Custom theme for security events
custom_theme = Theme(
    {
        "sec.safe": "bold green",
        "sec.warn": "bold yellow",
        "sec.block": "bold white on red",
        "sec.honey": "bold white on magenta",
        "sec.meta": "dim cyan",
    }
)

console = Console(theme=custom_theme)


class DevLogger:
    """Live security monitor logger."""

    @staticmethod
    def log_check(input_preview: str, result, duration_ms: float):
        """Log a security scan result."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        escaped_input = escape(input_preview[:50].replace("\n", " ")) + (
            "..." if len(input_preview) > 50 else ""
        )

        if result.is_injection:
            # Blocked/Detected
            status_style = "sec.block" if result.metadata.get("action") == "block" else "sec.warn"
            status_icon = "🚨" if result.metadata.get("action") == "block" else "⚠️ "
            status_text = "BLOCKED" if result.metadata.get("action") == "block" else "DETECTED"

            console.print(
                f"[{timestamp}] {status_icon} [sec.meta]Vantage[/] "
                f"[{status_style}] {status_text} [/] "
                f'Confidence: {result.confidence:.2f} | Input: "{escaped_input}"'
            )
            if result.metadata.get("reason"):
                console.print(
                    f"      └─ Reason: [sec.warn]{result.metadata['reason']}[/]",
                    highlight=False,
                )

            if result.metadata.get("action") == "block":
                console.print(
                    "      └─ [dim]False positive? Add regex to whitelist or use action='log'[/dim]",
                    highlight=False,
                )

        else:
            # Safe
            console.print(
                f"[{timestamp}] 🛡️  [sec.meta]Vantage[/] "
                f"[sec.safe] SAFE    [/] "
                f'({duration_ms:.1f}ms) | Input: "{escaped_input}"'
            )

    @staticmethod
    def log_honeypot(tool_name: str, agent_name: str):
        """Log a honeypot trigger event."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        console.print(
            f"[{timestamp}] 🍯 [sec.meta]Vantage[/] "
            f"[sec.honey] HONEYPOT TRIGGERED [/] "
            f"Agent '{agent_name}' attempted to use trap tool: [bold]{tool_name}[/]"
        )
        console.print("      └─ [bold red]High Certainty Attack Detected![/]")
