"""Base scanner interface for detecting agent systems in codebases.

This module provides the foundation for all framework-specific scanners in the
monorepo. It defines the BaseScanner abstract class and supporting data structures.
"""

from __future__ import annotations

import ast
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    ScanResult,
)

logger = logging.getLogger(__name__)


class BaseScanner(ABC):
    """Base class for framework-specific scanners.

    All framework scanners should inherit from this class and implement
    the scan_file method. The scan_directory method provides default
    behavior for scanning multiple files.

    Attributes:
        framework_name: Name of the framework this scanner handles
        verbose: Whether to log detailed information
    """

    framework_name: str = "unknown"

    def __init__(self, verbose: bool = False, symbol_table: Any = None):
        """Initialize scanner.

        Args:
            verbose: Whether to log detailed information
            symbol_table: ProjectSymbolTable for resolving definitions
        """
        self.verbose = verbose
        self.symbol_table = symbol_table

    def _log_warning(self, message: str) -> None:
        """Log a warning message if verbose is enabled."""
        if self.verbose:
            logger.warning(message)

    def _log_debug(self, message: str) -> None:
        """Log a debug message if verbose is enabled."""
        if self.verbose:
            logger.debug(message)

    def scan_directory(self, path: Path) -> ScanResult:
        """Scan a directory for agent definitions.

        Args:
            path: Path to directory to scan

        Returns:
            ScanResult with detected agents and connections
        """
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        errors: list[str] = []
        files_scanned = 0

        # Find Python files
        python_files = list(path.rglob("*.py"))

        # Also check for YAML configs
        yaml_files = list(path.rglob("*.yaml")) + list(path.rglob("*.yml"))

        for py_file in python_files:
            # Skip test files, venv, etc.
            if self._should_skip_file(py_file):
                continue

            try:
                result = self.scan_file(py_file)
                agents.extend(result.agents)
                connections.extend(result.connections)
                files_scanned += 1
            except Exception as e:
                error_msg = f"Error scanning {py_file}: {e}"
                errors.append(error_msg)
                if self.verbose:
                    logger.warning(error_msg)

        # Scan YAML files for config-based agents
        for yaml_file in yaml_files:
            if self._should_skip_file(yaml_file):
                continue

            try:
                result = self._scan_yaml_file(yaml_file)
                agents.extend(result.agents)
                files_scanned += 1
            except Exception as e:
                if self.verbose:
                    logger.warning(f"Error scanning {yaml_file}: {e}")

        # Infer connections if not explicitly found
        if not connections and len(agents) > 1:
            connections = self._infer_connections(agents)

        # Determine entry/exit points
        entry_points, exit_points = self._determine_endpoints(agents, connections)

        return ScanResult(
            agents=agents,
            connections=connections,
            # ScanResult model doesn't have entry_points/exit_points fields in core.py,
            # but detected ScanResult in base.py DID.
            # Let's check core.py ScanResult definition again.
            # It has: findings, frameworks_detected, errors.
            # It DOES NOT have entry_points/exit_points.
            # So I should drop them or add them to metadata?
            # Or assume the shared model is the source of truth.
            # Shared ScanResult fields: scan_id, timestamp, target_path, duration_ms, score, grade, agents, connections, findings, frameworks_detected, files_scanned, errors.
            target_path=str(path),
            frameworks_detected=[self.framework_name] if agents else [],
            files_scanned=files_scanned,
            errors=errors,
        )

    @abstractmethod
    def scan_file(self, path: Path) -> ScanResult:
        """Scan a single file for agent definitions.

        Args:
            path: Path to Python file

        Returns:
            ScanResult with detected agents
        """
        pass

    def _scan_yaml_file(self, path: Path) -> ScanResult:
        """Scan a YAML file for agent configs.

        Override in subclasses that support YAML config.
        """
        return ScanResult(
            target_path=str(path),
            agents=[],
            connections=[],
            frameworks_detected=[self.framework_name],
            files_scanned=0,
            errors=[],
        )

    def _should_skip_file(self, path: Path) -> bool:
        """Check if a file should be skipped."""
        # Skip common non-source directories (check path parts)
        skip_dirs = {
            ".venv",
            "venv",
            "__pycache__",
            ".git",
            "node_modules",
            ".egg-info",
        }
        path_parts = set(path.parts)
        if skip_dirs & path_parts:
            return True

        # Skip test directories - but only if "tests" is a directory component
        if "tests" in path_parts:
            return True

        # Skip test files by filename pattern (test_ prefix or _test suffix)
        filename = path.name
        if filename.startswith("test_") or filename.endswith("_test.py"):
            return True

        return False

    def _infer_connections(self, agents: list[DetectedAgent]) -> list[DetectedConnection]:
        """Infer connections between agents based on their definitions.

        This is a fallback when explicit connections aren't found.
        """
        connections: list[DetectedConnection] = []

        # Look for references to other agents in system prompts
        for agent in agents:
            if not agent.system_prompt:
                continue

            prompt_lower = agent.system_prompt.lower()

            # Check for references to other agents
            for other in agents:
                if other.id == agent.id:
                    continue

                # Check if this agent mentions the other
                if (
                    other.name.lower() in prompt_lower
                    or other.id.lower() in prompt_lower
                    or f"to {other.name.lower()}" in prompt_lower
                    or f"from {other.name.lower()}" in prompt_lower
                ):
                    # Determine direction
                    if f"to {other.name.lower()}" in prompt_lower or "pass" in prompt_lower:
                        connections.append(
                            DetectedConnection(
                                source_id=agent.id,
                                target_id=other.id,
                                connection_type=ConnectionType.DELEGATION,
                                confidence=0.5,
                                confidence_level=ConnectionConfidence.INFERRED,
                                evidence=["Inferred from system prompt reference"],
                            )
                        )
                    elif f"from {other.name.lower()}" in prompt_lower or "receive" in prompt_lower:
                        connections.append(
                            DetectedConnection(
                                source_id=other.id,
                                target_id=agent.id,
                                connection_type=ConnectionType.DELEGATION,
                                confidence=0.5,
                                confidence_level=ConnectionConfidence.INFERRED,
                                evidence=["Inferred from system prompt reference"],
                            )
                        )

        return connections

    def _determine_endpoints(
        self, agents: list[DetectedAgent], connections: list[DetectedConnection]
    ) -> tuple[list[str], list[str]]:
        """Determine entry and exit points."""
        if not agents:
            return [], []

        sources = {c.source_id for c in connections}
        targets = {c.target_id for c in connections}

        # Entry points: agents that are sources but not targets
        entry_points = list(sources - targets) if sources else [agents[0].id]

        # Exit points: agents that are targets but not sources
        exit_points = list(targets - sources) if targets else [agents[-1].id]

        # If no connections, use first and last agents
        if not connections:
            entry_points = [agents[0].id]
            exit_points = [agents[-1].id] if len(agents) > 1 else []

        return entry_points, exit_points

    def _parse_python_file(self, path: Path) -> ast.Module:
        """Parse a Python file into AST."""
        with open(path, encoding="utf-8") as f:
            return ast.parse(f.read(), filename=str(path))

    def _extract_string_value(self, node: ast.expr) -> str | None:
        """Extract string value from an AST node."""
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        elif isinstance(node, ast.JoinedStr):
            # f-string - try to extract parts
            parts = []
            for value in node.values:
                if isinstance(value, ast.Constant):
                    parts.append(str(value.value))
            return "".join(parts) if parts else None
        return None

    def _extract_dict_value(self, node: ast.expr) -> dict[str, Any] | None:
        """Extract dict value from an AST node."""
        if isinstance(node, ast.Dict):
            result = {}
            for key, value in zip(node.keys, node.values):
                if key is None:
                    continue
                key_str = self._extract_string_value(key)
                if key_str:
                    val = self._extract_string_value(value)
                    if val:
                        result[key_str] = val
            return result
        return None

    def _get_call_name(self, node: ast.Call) -> str:
        """Get the name of a function call.

        Args:
            node: AST Call node

        Returns:
            Function name (e.g., 'Agent' from 'Agent()' or 'from_tools' from 'Agent.from_tools()')
        """
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            return node.func.attr
        return ""

    def _extract_value(self, node: ast.expr) -> Any:
        """Extract Python value from an AST expression node.

        Handles:
        - Constants (strings, numbers, booleans, None)
        - Names (variable references)
        - Lists
        - Dicts
        - f-strings (with placeholders for dynamic parts)
        - Tuples

        Args:
            node: AST expression node

        Returns:
            Extracted Python value or None if extraction fails
        """
        if isinstance(node, ast.Constant):
            return node.value
        elif isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.List):
            return [self._extract_value(elt) for elt in node.elts]
        elif isinstance(node, ast.Tuple):
            return tuple(self._extract_value(elt) for elt in node.elts)
        elif isinstance(node, ast.Dict):
            result: dict[str, Any] = {}
            for key, value in zip(node.keys, node.values):
                if key is not None:
                    k = self._extract_value(key)
                    if k is not None:
                        result[str(k)] = self._extract_value(value)
            return result
        elif isinstance(node, ast.JoinedStr):
            # f-string - extract parts
            parts: list[str] = []
            for value in node.values:
                if isinstance(value, ast.Constant):
                    parts.append(str(value.value))
                elif isinstance(value, ast.FormattedValue):
                    parts.append("{...}")  # Placeholder for dynamic value
            return "".join(parts)
        elif isinstance(node, ast.Attribute):
            # For attribute access like module.constant
            return f"{self._extract_value(node.value)}.{node.attr}"
        elif isinstance(node, ast.Call):
            # For nested calls, return the call name
            return self._get_call_name(node)
        return None

    def _extract_keyword_arg(self, node: ast.Call, arg_name: str) -> Any:
        """Extract a keyword argument value from a call.

        Args:
            node: AST Call node
            arg_name: Name of the keyword argument

        Returns:
            Extracted value or None if not found
        """
        for keyword in node.keywords:
            if keyword.arg == arg_name:
                return self._extract_value(keyword.value)
        return None

    def _make_id(self, name: str) -> str:
        """Convert a name to a valid snake_case ID.

        Args:
            name: Input name (can contain spaces, special chars)

        Returns:
            Valid snake_case identifier
        """
        import re

        # Convert to string and lowercase
        id_str = str(name).lower()
        # Remove special characters except whitespace and underscores
        id_str = re.sub(r"[^\w\s]", "", id_str)
        # Replace whitespace with underscores
        id_str = re.sub(r"\s+", "_", id_str)
        # Remove multiple consecutive underscores
        id_str = re.sub(r"_+", "_", id_str)
        # Strip leading/trailing underscores
        id_str = id_str.strip("_")
        return id_str or "agent"

    def _format_display_name(self, name: str) -> str:
        """Convert an ID or snake_case name to a display name.

        Args:
            name: Input name (snake_case or camelCase)

        Returns:
            Title Case display name
        """
        import re

        # Replace underscores with spaces
        name = re.sub(r"_", " ", name)
        # Split camelCase
        name = re.sub(r"([a-z])([A-Z])", r"\1 \2", name)
        return name.title()
