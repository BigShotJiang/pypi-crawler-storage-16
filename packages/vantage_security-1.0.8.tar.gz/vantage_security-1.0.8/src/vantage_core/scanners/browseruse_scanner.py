"""Scanner for browser-use agent definitions.

browser-use is a framework for LLM-driven browser automation that enables
AI agents to autonomously navigate web pages and complete complex tasks.

Example detection targets:

    # Basic Agent with task
    from browser_use import Agent, Browser
    from browser_use.llm import ChatOpenAI

    agent = Agent(
        task="Navigate to Google and search for AI news",
        llm=ChatOpenAI(model="gpt-4o"),
        browser_profile=BrowserProfile(headless=False),
    )

    # Custom Actions
    from browser_use import Tools, ActionResult

    tools = Tools()

    @tools.action("Search for query")
    async def search_action(params):
        return ActionResult(extracted_content="Search results...")

    # Agent with custom system message
    agent = Agent(
        task="Extract product information",
        llm=llm,
        override_system_message="You are a specialized browser agent...",
        extend_system_message="Additional instructions...",
    )
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import Any

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult
from vantage_core.scanners.mixins import ASTExtractionMixin

logger = logging.getLogger(__name__)


class BrowserUseScanner(BaseScanner, ASTExtractionMixin):
    """Scanner for browser-use agent definitions.

    Detects:
    - Agent() instantiations with task and llm parameters
    - BrowserConfig and Controller configurations
    - @controller.action and @tools.action decorated functions
    - Custom system message overrides
    """

    framework_name = "browser-use"

    # Known LLM model classes in browser-use
    LLM_MODELS = {
        "ChatOpenAI",
        "ChatAnthropic",
        "ChatGoogle",
        "ChatGroq",
        "ChatAzureOpenAI",
        "ChatOllama",
        "ChatBrowserUse",
        "ChatOCIRaw",
        "ChatDeepSeek",
        "ChatGemini",
        "ChatMistral",
    }

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a Python file for browser-use agent definitions.

        Uses two-pass scanning:
        1. Find Agent() instantiations and custom actions
        2. Link actions to agents via controller/tools references

        Args:
            path: Path to Python file

        Returns:
            ScanResult with detected agents
        """
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        errors: list[str] = []

        try:
            tree = self._parse_python_file(path)
        except SyntaxError as e:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[f"Syntax error in {path}: {e}"],
            )

        # Check for browser_use imports
        content = path.read_text(encoding="utf-8")
        if not self._has_browser_use_imports(content):
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[],
            )

        # Track controller/tools variable names for action linking
        controller_vars: set[str] = set()
        agent_vars: dict[str, DetectedAgent] = {}

        # First pass: find Tools/Controller instantiations
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        call_name = self._get_call_name(node.value)
                        if call_name in ["Tools", "Controller"]:
                            controller_vars.add(target.id)

        # Second pass: find Agent instantiations
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        agent = self._parse_agent_assignment(target, node.value, path)
                        if agent:
                            agents.append(agent)
                            agent_vars[target.id] = agent

            # Also handle standalone Agent() calls (without assignment)
            elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
                agent = self._parse_agent_call(node.value, path)
                if agent:
                    agents.append(agent)

        # Third pass: find async with Agent patterns
        for node in ast.walk(tree):
            if isinstance(node, ast.AsyncWith):
                for item in node.items:
                    if isinstance(item.context_expr, ast.Call):
                        agent = self._parse_agent_call(item.context_expr, path)
                        if agent:
                            # Update agent ID with variable name if available
                            if item.optional_vars and isinstance(item.optional_vars, ast.Name):
                                agent = DetectedAgent(
                                    id=self._make_id(item.optional_vars.id),
                                    name=self._format_display_name(item.optional_vars.id),
                                    framework=agent.framework,
                                    file_path=agent.file_path,
                                    line_number=agent.line_number,
                                    system_prompt=agent.system_prompt,
                                    tools=agent.tools,
                                    trust_level=agent.trust_level,
                                    metadata=agent.metadata,
                                )
                            agents.append(agent)

        # Fourth pass: find custom actions via decorators
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                action = self._parse_action_decorator(node, path, controller_vars)
                if action:
                    agents.append(action)

        # Fifth pass: detect multi-agent coordination patterns
        connections = self._detect_agent_coordination(tree, agent_vars)

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=errors,
        )

    def _has_browser_use_imports(self, content: str) -> bool:
        """Check if file has browser-use imports.

        Args:
            content: File content as string

        Returns:
            True if browser-use imports are present
        """
        return any(p in content for p in ["from browser_use", "import browser_use"])

    def _parse_agent_assignment(
        self, target: ast.Name, call: ast.Call, path: Path
    ) -> DetectedAgent | None:
        """Parse Agent() instantiation assigned to a variable.

        Args:
            target: Variable name target
            call: AST Call node
            path: Source file path

        Returns:
            DetectedAgent or None if not an Agent call
        """
        call_name = self._get_call_name(call)
        if call_name != "Agent":
            return None

        var_name = target.id
        return self._build_agent_from_call(call, path, var_name)

    def _parse_agent_call(self, call: ast.Call, path: Path) -> DetectedAgent | None:
        """Parse standalone Agent() call.

        Args:
            call: AST Call node
            path: Source file path

        Returns:
            DetectedAgent or None if not an Agent call
        """
        call_name = self._get_call_name(call)
        if call_name != "Agent":
            return None

        # Generate a name from task if available
        task = self._extract_keyword_arg(call, "task")
        if task and isinstance(task, str):
            # Use first few words of task as name
            words = task.split()[:3]
            var_name = "_".join(words).lower()
        else:
            var_name = "browser_agent"

        return self._build_agent_from_call(call, path, var_name)

    def _build_agent_from_call(self, call: ast.Call, path: Path, var_name: str) -> DetectedAgent:
        """Build DetectedAgent from Agent() call.

        Args:
            call: AST Call node
            path: Source file path
            var_name: Variable name for the agent

        Returns:
            DetectedAgent instance
        """
        # Extract task
        task = self._extract_keyword_arg(call, "task")
        if not isinstance(task, str):
            task = ""

        # Extract system message overrides
        override_prompt = self._extract_keyword_arg(call, "override_system_message")
        extend_prompt = self._extract_keyword_arg(call, "extend_system_message")

        # Build system prompt
        if override_prompt and isinstance(override_prompt, str):
            system_prompt = override_prompt
        elif task:
            system_prompt = f"Task: {task}"
            if extend_prompt and isinstance(extend_prompt, str):
                system_prompt += f"\n\n{extend_prompt}"
        else:
            system_prompt = "browser-use Agent"

        # Extract LLM model
        model = self._extract_llm_model(call)

        # Extract browser configuration
        browser_config = self._extract_browser_config(call)
        if browser_config:
            system_prompt += f"\n\nBrowser: {browser_config}"

        # Extract controller configuration
        controller_config = self._extract_controller_config(call)
        if controller_config:
            system_prompt += f"\n\nController: {controller_config}"

        # Build raw config
        raw_config: dict[str, Any] = {
            "task": task,
        }

        # Add optional configurations
        use_vision = self._extract_keyword_arg(call, "use_vision")
        if use_vision is not None:
            raw_config["use_vision"] = use_vision

        use_thinking = self._extract_keyword_arg(call, "use_thinking")
        if use_thinking is not None:
            raw_config["use_thinking"] = use_thinking

        max_actions = self._extract_keyword_arg(call, "max_actions_per_step")
        if max_actions is not None:
            raw_config["max_actions_per_step"] = max_actions

        max_failures = self._extract_keyword_arg(call, "max_failures")
        if max_failures is not None:
            raw_config["max_failures"] = max_failures

        return DetectedAgent(
            id=self._make_id(var_name),
            name=self._format_display_name(var_name),
            framework=Framework.BROWSERUSE,
            file_path=str(path),
            line_number=call.lineno,
            system_prompt=system_prompt.strip(),
            metadata={"model": model, "raw_config": raw_config},
        )

    def _extract_llm_model(self, node: ast.Call) -> str:
        """Extract LLM model name from Agent call.

        Args:
            node: AST Call node for Agent

        Returns:
            Model name string
        """
        llm_node = self._get_keyword_node(node, "llm")
        if llm_node and isinstance(llm_node, ast.Call):
            # Get the model type
            llm_type = self._get_call_name(llm_node)
            # Get the model parameter
            model_param = self._extract_keyword_arg(llm_node, "model")
            if model_param and isinstance(model_param, str):
                return model_param
            elif llm_type:
                return llm_type
        return "gpt-4o"  # browser-use default

    def _get_keyword_node(self, node: ast.Call, arg_name: str) -> ast.expr | None:
        """Get the AST node for a keyword argument.

        Args:
            node: AST Call node
            arg_name: Keyword argument name

        Returns:
            AST expression node or None
        """
        for keyword in node.keywords:
            if keyword.arg == arg_name:
                return keyword.value
        return None

    def _extract_browser_config(self, node: ast.Call) -> str:
        """Extract browser configuration summary from Agent call.

        Args:
            node: AST Call node for Agent

        Returns:
            Configuration summary string
        """
        config_parts: list[str] = []

        # Check browser_profile
        profile_node = self._get_keyword_node(node, "browser_profile")
        if profile_node and isinstance(profile_node, ast.Call):
            headless = self._extract_keyword_arg(profile_node, "headless")
            if headless is not None:
                config_parts.append(f"headless={headless}")

            disable_security = self._extract_keyword_arg(profile_node, "disable_security")
            if disable_security is not None:
                config_parts.append(f"disable_security={disable_security}")

        return ", ".join(config_parts)

    def _extract_controller_config(self, node: ast.Call) -> str:
        """Extract controller configuration summary from Agent call.

        Args:
            node: AST Call node for Agent

        Returns:
            Configuration summary string
        """
        config_parts: list[str] = []

        # Check controller or tools parameter
        for param_name in ["controller", "tools"]:
            controller_node = self._get_keyword_node(node, param_name)
            if controller_node and isinstance(controller_node, ast.Call):
                exclude_actions = self._extract_keyword_arg(controller_node, "exclude_actions")
                if exclude_actions:
                    config_parts.append(f"exclude_actions={exclude_actions}")

        return ", ".join(config_parts)

    def _parse_action_decorator(
        self,
        node: ast.FunctionDef | ast.AsyncFunctionDef,
        path: Path,
        controller_vars: set[str],
    ) -> DetectedAgent | None:
        """Parse @action decorated function as custom action.

        Args:
            node: Function definition node
            path: Source file path
            controller_vars: Set of known controller/tools variable names

        Returns:
            DetectedAgent for the action or None
        """
        for decorator in node.decorator_list:
            if self._is_action_decorator(decorator, controller_vars):
                # Extract action description
                description = self._extract_action_description(decorator)

                return DetectedAgent(
                    id=self._make_id(node.name),
                    name=self._format_display_name(node.name),
                    framework=Framework.BROWSERUSE,
                    file_path=str(path),
                    line_number=node.lineno,
                    system_prompt=description or f"Custom action: {node.name}",
                    metadata={
                        "raw_config": {
                            "action_type": "custom",
                            "function": node.name,
                            "is_async": isinstance(node, ast.AsyncFunctionDef),
                        }
                    },
                )
        return None

    def _is_action_decorator(self, decorator: ast.expr, controller_vars: set[str]) -> bool:
        """Check if decorator is an action decorator.

        Args:
            decorator: AST decorator node
            controller_vars: Known controller/tools variable names

        Returns:
            True if this is an action decorator
        """
        if isinstance(decorator, ast.Call):
            func = decorator.func
            # Pattern: @tools.action(...) or @controller.action(...)
            if isinstance(func, ast.Attribute) and func.attr == "action":
                if isinstance(func.value, ast.Name):
                    return func.value.id in controller_vars or func.value.id in [
                        "tools",
                        "controller",
                    ]
                # Pattern: @tools.registry.action(...)
                elif isinstance(func.value, ast.Attribute) and func.value.attr == "registry":
                    if isinstance(func.value.value, ast.Name):
                        return func.value.value.id in controller_vars or func.value.value.id in [
                            "tools",
                            "controller",
                        ]
            # Pattern: @action(...)
            elif isinstance(func, ast.Name) and func.id == "action":
                return True
        elif isinstance(decorator, ast.Attribute):
            # Pattern: @tools.action (without call)
            if decorator.attr == "action":
                if isinstance(decorator.value, ast.Name):
                    return decorator.value.id in controller_vars or decorator.value.id in [
                        "tools",
                        "controller",
                    ]
        return False

    def _extract_action_description(self, decorator: ast.expr) -> str | None:
        """Extract description from action decorator.

        Args:
            decorator: AST decorator node

        Returns:
            Action description or None
        """
        if isinstance(decorator, ast.Call):
            # First positional argument is usually the description
            if decorator.args:
                desc = self._extract_value(decorator.args[0])
                if isinstance(desc, str):
                    return desc
            # Or it might be a keyword argument
            desc = self._extract_keyword_arg(decorator, "description")
            if isinstance(desc, str):
                return desc
        return None

    def _detect_agent_coordination(
        self,
        tree: ast.Module,
        agent_vars: dict[str, DetectedAgent],
    ) -> list[DetectedConnection]:
        """Detect coordination between browser-use agents.

        Looks for patterns where one agent's result is passed to another:
        - result1 = await agent1.run()
        - result2 = await agent2.run(result1.extracted_content)

        Args:
            tree: AST module
            agent_vars: Map of variable names to agent objects

        Returns:
            List of detected connections
        """
        connections: list[DetectedConnection] = []

        # Track which variables hold agent results
        result_vars: dict[str, str] = {}  # result_var -> agent_var

        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        # Check for await agent.run() patterns
                        call_node = node.value
                        if isinstance(call_node, ast.Await):
                            call_node = call_node.value

                        if isinstance(call_node, ast.Call):
                            if isinstance(call_node.func, ast.Attribute):
                                if call_node.func.attr == "run":
                                    if isinstance(call_node.func.value, ast.Name):
                                        agent_name = call_node.func.value.id
                                        if agent_name in agent_vars:
                                            result_vars[target.id] = agent_name

                                            # Check if any argument references a previous result
                                            for arg in call_node.args:
                                                source_agent = self._find_result_source(
                                                    arg, result_vars
                                                )
                                                if source_agent and source_agent in agent_vars:
                                                    connections.append(
                                                        DetectedConnection(
                                                            source_id=agent_vars[source_agent].id,
                                                            target_id=agent_vars[agent_name].id,
                                                            connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                                                            confidence=0.95,
                                                            confidence_level=ConnectionConfidence.FRAMEWORK,
                                                            evidence=[
                                                                f"browser-use agent chain: {source_agent}.run() -> {agent_name}.run()"
                                                            ],
                                                        )
                                                    )

        return connections

    def _find_result_source(self, node: ast.AST, result_vars: dict[str, str]) -> str | None:
        """Find if an AST node references a previous agent result.

        Args:
            node: AST node to check
            result_vars: Map of result variables to their source agents

        Returns:
            Source agent name or None
        """
        if isinstance(node, ast.Name):
            return result_vars.get(node.id)
        elif isinstance(node, ast.Attribute):
            # Check for result.extracted_content or similar patterns
            if isinstance(node.value, ast.Name):
                return result_vars.get(node.value.id)
        return None
