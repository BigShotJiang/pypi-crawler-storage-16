"""Shared mixin utilities for framework scanners.

This module provides reusable utilities for:
- AST extraction and value parsing
- Configuration file parsing (YAML, JSON, TOML)
- ID and name formatting
"""

from __future__ import annotations

import ast
import json
import logging
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class ASTExtractionMixin:
    """Shared AST extraction utilities for scanners.

    Provides common methods for extracting values from Python AST nodes,
    including function calls, keyword arguments, and various value types.

    Example:
        >>> class MyScanner(BaseScanner, ASTExtractionMixin):
        ...     def scan_file(self, path):
        ...         tree = self._parse_python_file(path)
        ...         for node in ast.walk(tree):
        ...             if isinstance(node, ast.Call):
        ...                 name = self._get_call_name(node)
        ...                 prompt = self._extract_keyword_arg(node, "system_prompt")
    """

    def _get_call_name(self, node: ast.Call) -> str:
        """Get the name of a function call.

        Args:
            node: AST Call node

        Returns:
            Function name (e.g., 'Agent' from 'Agent()' or 'from_tools' from 'Agent.from_tools()')

        Example:
            >>> # For `Agent(name="test")`, returns "Agent"
            >>> # For `client.create()`, returns "create"
        """
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            return node.func.attr
        return ""

    def _get_full_call_chain(self, node: ast.Call) -> str:
        """Get full dotted call chain from a function call.

        Args:
            node: AST Call node

        Returns:
            Full dotted path (e.g., 'client.beta.assistants.create')

        Example:
            >>> # For `client.beta.assistants.create()`, returns "client.beta.assistants.create"
        """
        parts: list[str] = []
        current: ast.expr | None = node.func

        while current:
            if isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            elif isinstance(current, ast.Name):
                parts.append(current.id)
                break
            else:
                break

        return ".".join(reversed(parts))

    def _extract_keyword_arg(self, node: ast.Call, arg_name: str) -> Any:
        """Extract a keyword argument value from a call.

        Args:
            node: AST Call node
            arg_name: Name of the keyword argument

        Returns:
            Extracted value or None if not found

        Example:
            >>> # For `Agent(system_prompt="You are helpful")`,
            >>> # _extract_keyword_arg(node, "system_prompt") returns "You are helpful"
        """
        for keyword in node.keywords:
            if keyword.arg == arg_name:
                return self._extract_value(keyword.value)
        return None

    def _extract_value(self, node: ast.expr) -> Any:
        """Extract Python value from an AST expression node.

        Handles:
        - Constants (strings, numbers, booleans, None)
        - Names (variable references)
        - Lists
        - Dicts
        - f-strings (with placeholders for dynamic parts)
        - Tuples

        Args:
            node: AST expression node

        Returns:
            Extracted Python value or None if extraction fails

        Example:
            >>> # For ast.Constant(value="hello"), returns "hello"
            >>> # For ast.List with [1, 2, 3], returns [1, 2, 3]
        """
        if isinstance(node, ast.Constant):
            return node.value
        elif isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.List):
            return [self._extract_value(elt) for elt in node.elts]
        elif isinstance(node, ast.Tuple):
            return tuple(self._extract_value(elt) for elt in node.elts)
        elif isinstance(node, ast.Dict):
            result: dict[str, Any] = {}
            for key, value in zip(node.keys, node.values):
                if key is not None:
                    k = self._extract_value(key)
                    if k is not None:
                        result[str(k)] = self._extract_value(value)
            return result
        elif isinstance(node, ast.JoinedStr):
            # f-string - extract parts
            parts: list[str] = []
            for value in node.values:
                if isinstance(value, ast.Constant):
                    parts.append(str(value.value))
                elif isinstance(value, ast.FormattedValue):
                    parts.append("{...}")  # Placeholder for dynamic value
            return "".join(parts)
        elif isinstance(node, ast.Attribute):
            # For attribute access like module.constant
            return f"{self._extract_value(node.value)}.{node.attr}"
        elif isinstance(node, ast.Call):
            # For nested calls, return the call name
            return self._get_call_name(node)
        return None

    def _extract_positional_arg(self, node: ast.Call, index: int) -> Any:
        """Extract a positional argument value from a call.

        Args:
            node: AST Call node
            index: Position index (0-based)

        Returns:
            Extracted value or None if index out of range
        """
        if len(node.args) > index:
            return self._extract_value(node.args[index])
        return None

    def _make_id(self, name: str) -> str:
        """Convert a name to a valid snake_case ID.

        Args:
            name: Input name (can contain spaces, special chars)

        Returns:
            Valid snake_case identifier

        Example:
            >>> _make_id("Research Assistant Agent!")
            'research_assistant_agent'
        """
        # Convert to string and lowercase
        id_str = str(name).lower()
        # Remove special characters except whitespace and underscores
        id_str = re.sub(r"[^\w\s]", "", id_str)
        # Replace whitespace with underscores
        id_str = re.sub(r"\s+", "_", id_str)
        # Remove multiple consecutive underscores
        id_str = re.sub(r"_+", "_", id_str)
        # Strip leading/trailing underscores
        id_str = id_str.strip("_")
        return id_str or "agent"

    def _format_display_name(self, name: str) -> str:
        """Convert an ID or snake_case name to a display name.

        Args:
            name: Input name (snake_case or camelCase)

        Returns:
            Title Case display name

        Example:
            >>> _format_display_name("research_agent")
            'Research Agent'
            >>> _format_display_name("ResearchAgent")
            'Research Agent'
        """
        # Replace underscores with spaces
        name = re.sub(r"_", " ", name)
        # Split camelCase
        name = re.sub(r"([a-z])([A-Z])", r"\1 \2", name)
        return name.title()

    def _get_decorator_names(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> list[str]:
        """Get list of decorator names for a function.

        Args:
            node: Function definition node

        Returns:
            List of decorator names
        """
        names: list[str] = []
        for decorator in node.decorator_list:
            if isinstance(decorator, ast.Name):
                names.append(decorator.id)
            elif isinstance(decorator, ast.Attribute):
                names.append(decorator.attr)
            elif isinstance(decorator, ast.Call):
                if isinstance(decorator.func, ast.Name):
                    names.append(decorator.func.id)
                elif isinstance(decorator.func, ast.Attribute):
                    names.append(decorator.func.attr)
        return names

    def _has_decorator(self, node: ast.FunctionDef | ast.AsyncFunctionDef, name: str) -> bool:
        """Check if a function has a specific decorator.

        Args:
            node: Function definition node
            name: Decorator name to check

        Returns:
            True if decorator is present
        """
        return name in self._get_decorator_names(node)


class ConfigFileMixin:
    """Shared configuration file parsing utilities.

    Provides methods for safely parsing YAML, JSON, and TOML config files
    with graceful degradation when optional dependencies are missing.

    Example:
        >>> class MyScanner(BaseScanner, ConfigFileMixin):
        ...     def scan_config(self, path):
        ...         config = self._parse_yaml_config(path)
        ...         if config:
        ...             return self._extract_agents(config)
    """

    def _parse_yaml_config(self, path: Path) -> dict[str, Any]:
        """Parse a YAML configuration file safely.

        Gracefully handles missing PyYAML dependency by returning empty dict.

        Args:
            path: Path to YAML file

        Returns:
            Parsed dictionary or empty dict on error
        """
        try:
            import yaml

            with open(path, encoding="utf-8") as f:
                result = yaml.safe_load(f)
                return result if isinstance(result, dict) else {}
        except ImportError:
            logger.debug("PyYAML not installed, skipping YAML parsing")
            return {}
        except Exception as e:
            logger.warning(f"Error parsing YAML file {path}: {e}")
            return {}

    def _parse_json_config(self, path: Path) -> dict[str, Any]:
        """Parse a JSON configuration file.

        Args:
            path: Path to JSON file

        Returns:
            Parsed dictionary or empty dict on error
        """
        try:
            content = path.read_text(encoding="utf-8")
            result = json.loads(content)
            return result if isinstance(result, dict) else {}
        except Exception as e:
            logger.warning(f"Error parsing JSON file {path}: {e}")
            return {}

    def _parse_toml_config(self, path: Path) -> dict[str, Any]:
        """Parse a TOML configuration file.

        Uses tomllib (Python 3.11+) with fallback to toml package.

        Args:
            path: Path to TOML file

        Returns:
            Parsed dictionary or empty dict on error
        """
        try:
            # Try Python 3.11+ built-in first
            import tomllib

            with open(path, "rb") as f:
                return tomllib.load(f)
        except ImportError:
            # Fall back to toml package
            try:
                import toml

                return toml.load(path)
            except ImportError:
                logger.debug("Neither tomllib nor toml available, skipping TOML parsing")
                return {}
        except Exception as e:
            logger.warning(f"Error parsing TOML file {path}: {e}")
            return {}

    def _detect_config_format(self, path: Path) -> str:
        """Detect configuration file format from extension.

        Args:
            path: Path to config file

        Returns:
            Format string: 'yaml', 'json', 'toml', or 'unknown'
        """
        suffix = path.suffix.lower()
        if suffix in [".yaml", ".yml"]:
            return "yaml"
        elif suffix == ".json":
            return "json"
        elif suffix == ".toml":
            return "toml"
        return "unknown"

    def _parse_config(self, path: Path) -> dict[str, Any]:
        """Parse a configuration file, auto-detecting format.

        Args:
            path: Path to config file

        Returns:
            Parsed dictionary or empty dict on error
        """
        fmt = self._detect_config_format(path)
        if fmt == "yaml":
            return self._parse_yaml_config(path)
        elif fmt == "json":
            return self._parse_json_config(path)
        elif fmt == "toml":
            return self._parse_toml_config(path)
        else:
            logger.warning(f"Unknown config format for {path}")
            return {}
