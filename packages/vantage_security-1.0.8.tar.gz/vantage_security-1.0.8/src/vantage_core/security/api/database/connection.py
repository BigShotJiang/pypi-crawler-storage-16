"""
Database Connection Manager for Vantage Security Platform.

This module provides async database engine creation, session management,
connection pooling configuration, and health check functionality.
"""

import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool import NullPool

logger = logging.getLogger(__name__)


# Default configuration values
DEFAULT_DATABASE_URL = "postgresql+asyncpg://localhost:5432/vantage"
DEFAULT_POOL_SIZE = 5
DEFAULT_MAX_OVERFLOW = 10
DEFAULT_POOL_RECYCLE = 3600
DEFAULT_POOL_PRE_PING = True
DEFAULT_ECHO = False


# Global engine and session maker
_engine: AsyncEngine | None = None
_async_session_maker: async_sessionmaker[AsyncSession] | None = None


def get_async_engine(
    database_url: str | None = None,
    pool_size: int = DEFAULT_POOL_SIZE,
    max_overflow: int = DEFAULT_MAX_OVERFLOW,
    pool_recycle: int = DEFAULT_POOL_RECYCLE,
    pool_pre_ping: bool = DEFAULT_POOL_PRE_PING,
    echo: bool = DEFAULT_ECHO,
    use_null_pool: bool = False,
) -> AsyncEngine:
    """
    Create or get the async database engine.

    Args:
        database_url: PostgreSQL connection URL (asyncpg driver)
        pool_size: Number of connections in the pool
        max_overflow: Max connections above pool_size
        pool_recycle: Seconds before recycling a connection
        pool_pre_ping: Check connection health before use
        echo: Log all SQL queries
        use_null_pool: Use NullPool for testing (no pooling)

    Returns:
        AsyncEngine instance

    Raises:
        ValueError: If database_url is not provided and no default is set
    """
    global _engine

    if _engine is not None:
        return _engine

    if database_url is None:
        # Try to get from environment or use default
        import os

        database_url = os.getenv("DATABASE_URL", DEFAULT_DATABASE_URL)

    # Ensure the URL uses asyncpg driver
    if database_url.startswith("postgresql://"):
        database_url = database_url.replace("postgresql://", "postgresql+asyncpg://", 1)

    # Configure pool class
    pool_class = NullPool if use_null_pool else None

    engine_kwargs = {
        "echo": echo,
        "pool_pre_ping": pool_pre_ping,
    }

    if pool_class:
        engine_kwargs["poolclass"] = pool_class
    else:
        engine_kwargs.update(
            {
                "pool_size": pool_size,
                "max_overflow": max_overflow,
                "pool_recycle": pool_recycle,
            }
        )

    _engine = create_async_engine(database_url, **engine_kwargs)

    logger.info(
        f"Created async database engine with pool_size={pool_size}, " f"max_overflow={max_overflow}"
    )

    return _engine


def get_async_session_maker(
    engine: AsyncEngine | None = None,
) -> async_sessionmaker[AsyncSession]:
    """
    Get or create the async session maker.

    Args:
        engine: AsyncEngine to use. If None, uses global engine.

    Returns:
        async_sessionmaker instance
    """
    global _async_session_maker

    if _async_session_maker is not None:
        return _async_session_maker

    if engine is None:
        engine = get_async_engine()

    _async_session_maker = async_sessionmaker(
        bind=engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autocommit=False,
        autoflush=False,
    )

    return _async_session_maker


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency for getting database sessions.

    Yields:
        AsyncSession instance

    Example:
        @app.get("/users")
        async def get_users(db: AsyncSession = Depends(get_db)):
            result = await db.execute(select(User))
            return result.scalars().all()
    """
    session_maker = get_async_session_maker()
    async with session_maker() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


@asynccontextmanager
async def get_db_context() -> AsyncGenerator[AsyncSession, None]:
    """
    Context manager for database sessions.

    Use this when you need a session outside of FastAPI dependency injection.

    Example:
        async with get_db_context() as db:
            result = await db.execute(select(User))
            users = result.scalars().all()
    """
    session_maker = get_async_session_maker()
    async with session_maker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def check_database_health() -> dict:
    """
    Check database connection health.

    Returns:
        Dictionary with health status information

    Example:
        health = await check_database_health()
        if health["status"] == "healthy":
            print("Database is operational")
    """
    try:
        session_maker = get_async_session_maker()
        async with session_maker() as session:
            # Execute simple query to verify connection
            result = await session.execute(text("SELECT 1"))
            result.scalar()

            # Get pool status if available
            engine = get_async_engine()
            pool_status = {}
            if hasattr(engine.pool, "size"):
                pool_status = {
                    "pool_size": engine.pool.size(),
                    "checked_in": engine.pool.checkedin(),
                    "checked_out": engine.pool.checkedout(),
                    "overflow": engine.pool.overflow(),
                }

            return {
                "status": "healthy",
                "database": "connected",
                "pool": pool_status,
            }

    except Exception as e:
        logger.error(f"Database health check failed: {e}")
        return {
            "status": "unhealthy",
            "database": "disconnected",
            "error": str(e),
        }


async def init_db() -> None:
    """
    Initialize database connection and create tables if needed.

    This should be called during application startup.
    """
    engine = get_async_engine()

    # Verify connection
    health = await check_database_health()
    if health["status"] != "healthy":
        raise RuntimeError(f"Database connection failed: {health.get('error', 'Unknown error')}")

    logger.info("Database connection initialized successfully")


async def close_db() -> None:
    """
    Close database connections and cleanup.

    This should be called during application shutdown.
    """
    global _engine, _async_session_maker

    if _engine is not None:
        await _engine.dispose()
        _engine = None
        _async_session_maker = None
        logger.info("Database connections closed")


def reset_engine() -> None:
    """
    Reset the global engine and session maker.

    Useful for testing to ensure clean state between tests.
    """
    global _engine, _async_session_maker
    _engine = None
    _async_session_maker = None
