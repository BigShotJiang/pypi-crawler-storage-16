"""
Database models for Vantage Security Platform Web Dashboard.

This module defines SQLAlchemy models for projects, project members,
webhooks, webhook deliveries, and audit logs.
"""

from datetime import datetime
from enum import Enum
from uuid import uuid4

from sqlalchemy import (
    JSON,
    Boolean,
    CheckConstraint,
    Column,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()


class Role(str, Enum):
    """User roles for RBAC."""

    ADMIN = "admin"
    SECURITY_ENGINEER = "security_engineer"
    DEVELOPER = "developer"
    VIEWER = "viewer"


class ScanStatusDB(str, Enum):
    """Database scan status enum."""

    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class SourceType(str, Enum):
    """Source type for scans."""

    UPLOAD = "upload"
    GITHUB = "github"
    GITLAB = "gitlab"


class User(Base):
    """User account model."""

    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255))
    name = Column(String(255))
    is_active = Column(Boolean, default=True)
    is_mfa_enabled = Column(Boolean, default=False)
    mfa_secret = Column(String(255))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    projects_owned = relationship("Project", back_populates="owner")
    project_memberships = relationship("ProjectMember", back_populates="user")
    api_keys = relationship("APIKey", back_populates="user")


class Project(Base):
    """Project container model."""

    __tablename__ = "projects"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    owner_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    settings = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    owner = relationship("User", back_populates="projects_owned")
    members = relationship("ProjectMember", back_populates="project", cascade="all, delete-orphan")
    scans = relationship("Scan", back_populates="project", cascade="all, delete-orphan")
    webhooks = relationship("Webhook", back_populates="project", cascade="all, delete-orphan")
    score_history = relationship(
        "ScoreHistory", back_populates="project", cascade="all, delete-orphan"
    )

    __table_args__ = (Index("idx_projects_owner", "owner_id"),)


class ProjectMember(Base):
    """Project membership and role assignment."""

    __tablename__ = "project_members"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    project_id = Column(
        UUID(as_uuid=True),
        ForeignKey("projects.id", ondelete="CASCADE"),
        nullable=False,
    )
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    role = Column(String(50), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    project = relationship("Project", back_populates="members")
    user = relationship("User", back_populates="project_memberships")

    __table_args__ = (
        UniqueConstraint("project_id", "user_id", name="uq_project_user"),
        Index("idx_project_members_project", "project_id"),
        Index("idx_project_members_user", "user_id"),
        CheckConstraint(
            "role IN ('admin', 'security_engineer', 'developer', 'viewer')",
            name="ck_valid_role",
        ),
    )


class Scan(Base):
    """Security scan record."""

    __tablename__ = "scans"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    project_id = Column(
        UUID(as_uuid=True),
        ForeignKey("projects.id", ondelete="CASCADE"),
        nullable=False,
    )
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    status = Column(String(50), nullable=False, default="pending")
    source_type = Column(String(50), nullable=False)
    source_ref = Column(String(500))
    branch = Column(String(255))
    commit_sha = Column(String(40))
    atss_score = Column(Integer)
    topology_score = Column(Integer)
    agent_score = Column(Integer)
    interaction_score = Column(Integer)
    agent_count = Column(Integer)
    tool_count = Column(Integer)
    finding_count = Column(Integer)
    error_message = Column(Text)
    metadata = Column(JSON, default=dict)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    project = relationship("Project", back_populates="scans")
    findings = relationship("Finding", back_populates="scan", cascade="all, delete-orphan")
    score_history = relationship(
        "ScoreHistory", back_populates="scan", cascade="all, delete-orphan"
    )

    __table_args__ = (
        Index("idx_scans_project", "project_id"),
        Index("idx_scans_user", "user_id"),
        Index("idx_scans_status", "status"),
        Index("idx_scans_created", "created_at"),
        Index("idx_scans_project_status_created", "project_id", "status", "created_at"),
        CheckConstraint(
            "status IN ('pending', 'processing', 'completed', 'failed', 'cancelled')",
            name="ck_valid_status",
        ),
        CheckConstraint("source_type IN ('upload', 'github', 'gitlab')", name="ck_valid_source"),
        CheckConstraint("atss_score >= 0 AND atss_score <= 100", name="ck_atss_range"),
    )


class Finding(Base):
    """Security finding from a scan."""

    __tablename__ = "findings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    scan_id = Column(UUID(as_uuid=True), ForeignKey("scans.id", ondelete="CASCADE"), nullable=False)
    severity = Column(String(20), nullable=False)
    category = Column(String(100), nullable=False)
    title = Column(String(500), nullable=False)
    description = Column(Text, nullable=False)
    location = Column(JSON)
    evidence = Column(Text)
    owasp_mapping = Column(String(50))
    cwe_id = Column(String(20))
    remediation_id = Column(UUID(as_uuid=True))
    remediation_code = Column(Text)
    is_false_positive = Column(Boolean, default=False)
    triaged_at = Column(DateTime)
    triaged_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    scan = relationship("Scan", back_populates="findings")

    __table_args__ = (
        Index("idx_findings_scan", "scan_id"),
        Index("idx_findings_severity", "severity"),
        Index("idx_findings_category", "category"),
        Index("idx_findings_scan_severity", "scan_id", "severity"),
        CheckConstraint(
            "severity IN ('critical', 'high', 'medium', 'low', 'info')",
            name="ck_valid_severity",
        ),
    )


class ScoreHistory(Base):
    """Historical ATSS scores for trend analysis."""

    __tablename__ = "score_history"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    project_id = Column(
        UUID(as_uuid=True),
        ForeignKey("projects.id", ondelete="CASCADE"),
        nullable=False,
    )
    scan_id = Column(UUID(as_uuid=True), ForeignKey("scans.id", ondelete="CASCADE"), nullable=False)
    total_score = Column(Integer, nullable=False)
    topology_score = Column(Integer, nullable=False)
    agent_score = Column(Integer, nullable=False)
    interaction_score = Column(Integer, nullable=False)
    breakdown = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    project = relationship("Project", back_populates="score_history")
    scan = relationship("Scan", back_populates="score_history")

    __table_args__ = (
        Index("idx_score_history_project", "project_id"),
        Index("idx_score_history_created", "created_at"),
    )


class Webhook(Base):
    """Webhook configuration for project notifications."""

    __tablename__ = "webhooks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    project_id = Column(
        UUID(as_uuid=True),
        ForeignKey("projects.id", ondelete="CASCADE"),
        nullable=False,
    )
    url = Column(String(2000), nullable=False)
    secret_hash = Column(String(255))
    events = Column(JSON, nullable=False, default=list)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    project = relationship("Project", back_populates="webhooks")
    deliveries = relationship(
        "WebhookDelivery", back_populates="webhook", cascade="all, delete-orphan"
    )

    __table_args__ = (Index("idx_webhooks_project", "project_id"),)


class WebhookDelivery(Base):
    """Webhook delivery attempt tracking."""

    __tablename__ = "webhook_deliveries"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    webhook_id = Column(
        UUID(as_uuid=True),
        ForeignKey("webhooks.id", ondelete="CASCADE"),
        nullable=False,
    )
    event_type = Column(String(50), nullable=False)
    payload = Column(JSON, nullable=False)
    response_code = Column(Integer)
    response_body = Column(Text)
    attempt_number = Column(Integer, nullable=False, default=1)
    next_retry_at = Column(DateTime)
    delivered_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    webhook = relationship("Webhook", back_populates="deliveries")

    __table_args__ = (
        Index("idx_webhook_deliveries_webhook", "webhook_id"),
        Index("idx_webhook_deliveries_retry", "next_retry_at"),
    )


class AuditLog(Base):
    """Audit log for tracking security-relevant actions."""

    __tablename__ = "audit_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    action = Column(String(100), nullable=False)
    resource_type = Column(String(100), nullable=False)
    resource_id = Column(UUID(as_uuid=True))
    outcome = Column(String(20), nullable=False)
    ip_address = Column(String(45))  # IPv6 compatible
    user_agent = Column(Text)
    metadata = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("idx_audit_logs_user", "user_id"),
        Index("idx_audit_logs_resource", "resource_type", "resource_id"),
        Index("idx_audit_logs_created", "created_at"),
        CheckConstraint("outcome IN ('success', 'denied', 'error')", name="ck_valid_outcome"),
    )


class APIKey(Base):
    """API key for programmatic access."""

    __tablename__ = "api_keys"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(100), nullable=False)
    key_prefix = Column(String(10), nullable=False)
    key_hash = Column(String(255), nullable=False)
    scopes = Column(JSON, default=list)
    last_used_at = Column(DateTime)
    expires_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    user = relationship("User", back_populates="api_keys")

    __table_args__ = (
        Index("idx_api_keys_user", "user_id"),
        Index("idx_api_keys_prefix", "key_prefix"),
    )
