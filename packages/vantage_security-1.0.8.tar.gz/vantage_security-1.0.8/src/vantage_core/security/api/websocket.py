"""
WebSocket handlers for real-time scan progress updates.

This module provides WebSocket endpoints for streaming scan progress,
findings updates, and completion notifications.
"""

import json
from datetime import datetime
from typing import Any

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

router = APIRouter(tags=["websocket"])


# Message types for WebSocket communication
class WSMessageType:
    """WebSocket message types."""

    SUBSCRIBE = "subscribe"
    UNSUBSCRIBE = "unsubscribe"
    PROGRESS = "scan.progress"
    STAGE_COMPLETE = "scan.stage_complete"
    FINDING = "scan.finding"
    COMPLETE = "scan.complete"
    ERROR = "scan.error"
    PING = "ping"
    PONG = "pong"


class ScanProgressMessage(BaseModel):
    """Message for scan progress updates."""

    type: str
    scan_id: str
    data: dict[str, Any]
    timestamp: str


class ConnectionManager:
    """Manages WebSocket connections for scan subscriptions."""

    def __init__(self):
        """Initialize connection manager."""
        # Maps scan_id to list of connected websockets
        self._scan_connections: dict[str, list[WebSocket]] = {}
        # Maps websocket to list of subscribed scan_ids
        self._connection_scans: dict[WebSocket, list[str]] = {}

    async def connect(self, websocket: WebSocket):
        """Accept a new WebSocket connection."""
        await websocket.accept()
        self._connection_scans[websocket] = []

    def disconnect(self, websocket: WebSocket):
        """Handle WebSocket disconnection."""
        # Remove from all scan subscriptions
        scan_ids = self._connection_scans.get(websocket, [])
        for scan_id in scan_ids:
            if scan_id in self._scan_connections:
                if websocket in self._scan_connections[scan_id]:
                    self._scan_connections[scan_id].remove(websocket)
                if not self._scan_connections[scan_id]:
                    del self._scan_connections[scan_id]

        # Remove connection tracking
        if websocket in self._connection_scans:
            del self._connection_scans[websocket]

    def subscribe(self, websocket: WebSocket, scan_id: str):
        """Subscribe a connection to scan updates."""
        if scan_id not in self._scan_connections:
            self._scan_connections[scan_id] = []

        if websocket not in self._scan_connections[scan_id]:
            self._scan_connections[scan_id].append(websocket)

        if websocket in self._connection_scans:
            if scan_id not in self._connection_scans[websocket]:
                self._connection_scans[websocket].append(scan_id)

    def unsubscribe(self, websocket: WebSocket, scan_id: str):
        """Unsubscribe a connection from scan updates."""
        if scan_id in self._scan_connections:
            if websocket in self._scan_connections[scan_id]:
                self._scan_connections[scan_id].remove(websocket)

        if websocket in self._connection_scans:
            if scan_id in self._connection_scans[websocket]:
                self._connection_scans[websocket].remove(scan_id)

    async def broadcast_to_scan(self, scan_id: str, message: dict):
        """Broadcast a message to all connections subscribed to a scan."""
        if scan_id not in self._scan_connections:
            return

        # Add timestamp if not present
        if "timestamp" not in message:
            message["timestamp"] = datetime.utcnow().isoformat()

        message_json = json.dumps(message)
        dead_connections = []

        for connection in self._scan_connections[scan_id]:
            try:
                await connection.send_text(message_json)
            except Exception:
                dead_connections.append(connection)

        # Clean up dead connections
        for connection in dead_connections:
            self.disconnect(connection)

    async def send_personal(self, websocket: WebSocket, message: dict):
        """Send a message to a specific connection."""
        if "timestamp" not in message:
            message["timestamp"] = datetime.utcnow().isoformat()

        await websocket.send_text(json.dumps(message))

    def get_scan_connections(self, scan_id: str) -> int:
        """Get number of connections subscribed to a scan."""
        return len(self._scan_connections.get(scan_id, []))


# Global connection manager instance
connection_manager = ConnectionManager()


@router.websocket("/ws/scans/{scan_id}/progress")
async def websocket_scan_progress(
    websocket: WebSocket,
    scan_id: str,
    token: str | None = Query(None, description="Authentication token"),
):
    """
    WebSocket endpoint for real-time scan progress updates.

    Clients connect to this endpoint to receive live updates about
    scan progress, findings, and completion status.
    """
    # TODO: Validate token for authentication
    # For now, accept all connections

    await connection_manager.connect(websocket)
    connection_manager.subscribe(websocket, scan_id)

    try:
        # Send initial connection acknowledgment
        await connection_manager.send_personal(
            websocket,
            {
                "type": "connected",
                "scan_id": scan_id,
                "message": f"Subscribed to scan {scan_id}",
            },
        )

        # Listen for messages from client
        while True:
            data = await websocket.receive_text()

            try:
                message = json.loads(data)
                msg_type = message.get("type")

                if msg_type == WSMessageType.PING:
                    await connection_manager.send_personal(
                        websocket,
                        {
                            "type": WSMessageType.PONG,
                        },
                    )

                elif msg_type == WSMessageType.SUBSCRIBE:
                    new_scan_id = message.get("scan_id")
                    if new_scan_id:
                        connection_manager.subscribe(websocket, new_scan_id)
                        await connection_manager.send_personal(
                            websocket,
                            {
                                "type": "subscribed",
                                "scan_id": new_scan_id,
                            },
                        )

                elif msg_type == WSMessageType.UNSUBSCRIBE:
                    old_scan_id = message.get("scan_id")
                    if old_scan_id:
                        connection_manager.unsubscribe(websocket, old_scan_id)
                        await connection_manager.send_personal(
                            websocket,
                            {
                                "type": "unsubscribed",
                                "scan_id": old_scan_id,
                            },
                        )

            except json.JSONDecodeError:
                await connection_manager.send_personal(
                    websocket,
                    {
                        "type": "error",
                        "message": "Invalid JSON message",
                    },
                )

    except WebSocketDisconnect:
        connection_manager.disconnect(websocket)


@router.websocket("/ws/dashboard")
async def websocket_dashboard(
    websocket: WebSocket,
    token: str | None = Query(None, description="Authentication token"),
):
    """
    WebSocket endpoint for dashboard real-time updates.

    Provides updates for multiple scans, score changes, and notifications.
    """
    await connection_manager.connect(websocket)

    try:
        await connection_manager.send_personal(
            websocket,
            {
                "type": "connected",
                "message": "Connected to dashboard updates",
            },
        )

        while True:
            data = await websocket.receive_text()

            try:
                message = json.loads(data)
                msg_type = message.get("type")

                if msg_type == WSMessageType.PING:
                    await connection_manager.send_personal(
                        websocket,
                        {
                            "type": WSMessageType.PONG,
                        },
                    )

                elif msg_type == WSMessageType.SUBSCRIBE:
                    scan_id = message.get("scan_id")
                    if scan_id:
                        connection_manager.subscribe(websocket, scan_id)

            except json.JSONDecodeError:
                pass

    except WebSocketDisconnect:
        connection_manager.disconnect(websocket)


# Helper functions to send progress updates


async def send_scan_progress(
    scan_id: str,
    stage: str,
    progress_percent: int,
    message: str = "",
):
    """
    Send a scan progress update to all subscribers.

    Args:
        scan_id: Scan identifier
        stage: Current processing stage
        progress_percent: Progress percentage (0-100)
        message: Optional status message
    """
    await connection_manager.broadcast_to_scan(
        scan_id,
        {
            "type": WSMessageType.PROGRESS,
            "scan_id": scan_id,
            "data": {
                "stage": stage,
                "progress_percent": progress_percent,
                "message": message,
            },
        },
    )


async def send_stage_complete(
    scan_id: str,
    stage: str,
    duration_ms: int,
    next_stage: str | None = None,
):
    """
    Send a stage completion notification.

    Args:
        scan_id: Scan identifier
        stage: Completed stage name
        duration_ms: Stage duration in milliseconds
        next_stage: Next stage name, if any
    """
    await connection_manager.broadcast_to_scan(
        scan_id,
        {
            "type": WSMessageType.STAGE_COMPLETE,
            "scan_id": scan_id,
            "data": {
                "stage": stage,
                "duration_ms": duration_ms,
                "next_stage": next_stage,
            },
        },
    )


async def send_finding_update(
    scan_id: str,
    finding_id: str,
    severity: str,
    title: str,
    category: str,
):
    """
    Send a new finding notification.

    Args:
        scan_id: Scan identifier
        finding_id: Finding identifier
        severity: Finding severity
        title: Finding title
        category: Finding category
    """
    await connection_manager.broadcast_to_scan(
        scan_id,
        {
            "type": WSMessageType.FINDING,
            "scan_id": scan_id,
            "data": {
                "finding_id": finding_id,
                "severity": severity,
                "title": title,
                "category": category,
            },
        },
    )


async def send_scan_complete(
    scan_id: str,
    status: str,
    atss_score: int | None,
    findings_count: int,
    duration_ms: int,
):
    """
    Send a scan completion notification.

    Args:
        scan_id: Scan identifier
        status: Final scan status
        atss_score: Final ATSS score
        findings_count: Total findings count
        duration_ms: Total scan duration
    """
    await connection_manager.broadcast_to_scan(
        scan_id,
        {
            "type": WSMessageType.COMPLETE,
            "scan_id": scan_id,
            "data": {
                "status": status,
                "atss_score": atss_score,
                "findings_count": findings_count,
                "duration_ms": duration_ms,
            },
        },
    )


async def send_scan_error(
    scan_id: str,
    error_message: str,
    error_type: str = "unknown",
):
    """
    Send a scan error notification.

    Args:
        scan_id: Scan identifier
        error_message: Error description
        error_type: Error type/category
    """
    await connection_manager.broadcast_to_scan(
        scan_id,
        {
            "type": WSMessageType.ERROR,
            "scan_id": scan_id,
            "data": {
                "error_message": error_message,
                "error_type": error_type,
            },
        },
    )


# Export for use by scan pipeline
__all__ = [
    "router",
    "connection_manager",
    "send_scan_progress",
    "send_stage_complete",
    "send_finding_update",
    "send_scan_complete",
    "send_scan_error",
]
