"""Stage 1: Fast Regex + Entropy Filter for Secret Detection."""

import re
from dataclasses import dataclass
from typing import Optional

from ..ml_features import SecretFeatures


@dataclass
class Stage1Result:
    """Result from Stage 1 filtering."""

    should_continue: bool  # Pass to Stage 2?
    confidence: float  # 0.0-1.0
    reasoning: list[str]  # Why this decision?


class Stage1Filter:
    """
    Fast filter to eliminate obvious non-secrets using entropy and patterns.

    Targets:
    - Eliminate 85% of candidates
    - 100% recall (no false negatives)
    - <1ms per candidate
    """

    def __init__(
        self,
        entropy_threshold: float = 3.5,
        low_entropy_reject: float = 2.5,
    ):
        self.entropy_threshold = entropy_threshold
        self.low_entropy_reject = low_entropy_reject

        # Known placeholder patterns (from research)
        self.placeholder_patterns = [
            r"your[-_]?(?:api[-_]?key|token|secret|password)",
            r"insert[-_]?(?:here|your|key|token)",
            r"replace[-_]?(?:me|this|with)",
            r"<[A-Z_]+>",
            r"\{\{[^}]+\}\}",
            r"\$\{[^}]+\}",
            r"xxx+",
            r"placeholder",
            r"changeme",
            r"example",
            r"test[-_]?(key|token|secret)",
            r"mock[-_]?",
            r"fake[-_]?",
            r"dummy[-_]?",
        ]

        # Compile patterns for performance
        self.compiled_patterns = [
            re.compile(pattern, re.IGNORECASE) for pattern in self.placeholder_patterns
        ]

        # Known placeholder values
        self.known_placeholders = {
            "your-api-key",
            "your-api-key-here",
            "your-secret-key",
            "your-token-here",
            "insert-key-here",
            "api-key-goes-here",
            "xxxxxxxx",
            "xxxxxxxxxxxxxxxx",
            "xxxxxxxxxxxxxxxxxxxx",
            "changeme",
            "password",
            "secret",
            "token",
            "placeholder",
            "example-key",
            "test-token",
            "your_api_key",
            "your_token",
            "your_secret",
            "api_key_here",
            "token_here",
            "secret_here",
        }

    def filter(self, text: str, features: SecretFeatures) -> Stage1Result:
        """
        Apply Stage 1 filtering.

        Args:
            text: The candidate secret string
            features: Extracted features

        Returns:
            Stage1Result with decision and confidence
        """
        reasoning = []

        # Rule 1: Known placeholder patterns → REJECT
        text_lower = text.lower()
        for pattern in self.compiled_patterns:
            if pattern.search(text_lower):
                reasoning.append(f"Matches placeholder pattern: {pattern.pattern}")
                return Stage1Result(False, 0.0, reasoning)

        # Rule 2: Known placeholder value → REJECT
        if text_lower in self.known_placeholders:
            reasoning.append(f"Matches known placeholder: {text_lower}")
            return Stage1Result(False, 0.0, reasoning)

        # Rule 3: Very low entropy → REJECT
        if features.entropy < self.low_entropy_reject:
            reasoning.append(f"Very low entropy: {features.entropy:.2f}")
            return Stage1Result(False, 0.0, reasoning)

        # Rule 4: Test file with low/medium entropy → LIKELY REJECT
        if features.is_in_test_file and features.entropy < 4.0:
            reasoning.append("Test file with medium entropy")
            return Stage1Result(False, 0.2, reasoning)

        # Rule 5: Value matches variable name → LIKELY REJECT
        if features.variable_name_suggests_secret and features.entropy < 3.8:
            reasoning.append("Value matches variable name")
            return Stage1Result(False, 0.1, reasoning)

        # Rule 6: UUID pattern → REJECT (UUIDs are not secrets)
        if features.is_uuid_like:
            reasoning.append("UUID pattern detected")
            return Stage1Result(False, 0.05, reasoning)

        # Rule 7: High entropy + secret pattern → PASS TO STAGE 2
        if features.entropy > 4.5 and features.has_prefix:
            score = self._calculate_score(features)
            reasoning.append(f"High entropy ({features.entropy:.2f}) + secret prefix pattern")
            return Stage1Result(True, score, reasoning)

        # Rule 8: Medium confidence → PASS TO STAGE 2
        score = self._calculate_score(features)
        if score > 0.3:
            reasoning.append(f"Medium confidence score: {score:.2f}")
            return Stage1Result(True, score, reasoning)
        else:
            reasoning.append(f"Low confidence score: {score:.2f}")
            return Stage1Result(False, score, reasoning)

    def _calculate_score(self, features: SecretFeatures) -> float:
        """Calculate heuristic confidence score."""
        score = 0.0

        # Entropy contribution (0-0.4)
        if features.entropy > 4.5:
            score += 0.4
        elif features.entropy > 3.5:
            score += 0.2
        elif features.entropy > 2.5:
            score += 0.1

        # Pattern match (0-0.3)
        if features.has_prefix:
            score += 0.3

        # Context signals
        if not features.is_in_test_file:  # NOT a test file
            score += 0.1

        # Length signal (very short or very long strings less likely to be secrets)
        if 16 <= features.length <= 128:
            score += 0.1

        # Character diversity (high unique char ratio suggests real secret)
        if features.unique_char_ratio > 0.6:
            score += 0.05

        # Base64-like pattern (common for real secrets)
        if features.is_base64_like and features.entropy > 4.0:
            score += 0.1

        # Penalties
        if features.is_in_test_file:
            score -= 0.3
        if features.is_uuid_like:
            score -= 0.5
        if features.variable_name_suggests_secret and features.entropy < 3.5:
            score -= 0.4

        return max(0.0, min(1.0, score))
