"""
Error Handling Module for Vantage Security Scanner.

US-005: Specific Exception Types
US-006: Error Result Objects
US-007: Partial Scan Results on Failure
US-008: Unparseable File Findings

This module provides comprehensive error handling including:
- Typed exception hierarchy for programmatic error handling
- Structured error result objects
- Support for partial scan results
- Parse error findings

Public API:
    Exceptions:
        - MimicError: Base exception for all Vantage errors
        - ParseError: Base for parsing errors
        - SyntaxParseError: Syntax error in source file
        - EncodingError: File encoding issue
        - ParseTimeoutError: Parsing exceeded time limit
        - FileTooLargeError: File exceeds size limit
        - AnalysisError: Base for analysis errors
        - RuleExecutionError: Rule failed during execution
        - AnalysisTimeoutError: Analysis exceeded time limit
        - MemoryExceededError: Memory limit exceeded
        - InternalAnalysisError: Unexpected internal error
        - ConfigurationError: Invalid configuration
        - MissingConfigError: Required config missing
        - InvalidPathError: Config path invalid
        - RuleValidationError: Invalid rule file
        - DuplicateRuleIdError: Duplicate rule ID
        - RuleLoadError: Failed to load rule
        - FileNotFoundError: File not found
        - PermissionDeniedError: Permission denied
        - FileReadError: Error reading file

    Enums:
        - ErrorCode: Standardized error codes
        - ScanStatus: Overall scan status
        - ErrorSeverity: Error severity levels

    Classes:
        - ErrorContext: Rich error context
        - ScanError: Structured scan error
        - FileResult: Result for single file
        - ScanResult: Complete scan result
        - ParseErrorFinding: Finding for unparseable files

    Functions:
        - create_scan_error_finding: Convert error to finding
"""

# Exceptions
from vantage_core.security.errors.exceptions import (
    # Analysis errors
    AnalysisError,
    AnalysisTimeoutError,
    # Configuration errors
    ConfigurationError,
    DuplicateRuleIdError,
    EncodingError,
    ErrorCode,
    ErrorContext,
    # IO errors
    FileNotFoundError,
    FileReadError,
    FileTooLargeError,
    InternalAnalysisError,
    InvalidPathError,
    MemoryExceededError,
    MimicError,
    MissingConfigError,
    # Parse errors
    ParseError,
    ParseTimeoutError,
    PermissionDeniedError,
    RuleExecutionError,
    RuleLoadError,
    # Rule errors
    RuleValidationError,
    SyntaxParseError,
)

# Result objects
from vantage_core.security.errors.results import (
    ErrorSeverity,
    FileResult,
    ParseErrorFinding,
    ScanError,
    ScanResult,
    ScanStatus,
    create_scan_error_finding,
)

__all__ = [
    # Error codes and context
    "ErrorCode",
    "ErrorContext",
    # Base exception
    "MimicError",
    # Parse errors
    "ParseError",
    "SyntaxParseError",
    "EncodingError",
    "ParseTimeoutError",
    "FileTooLargeError",
    # Analysis errors
    "AnalysisError",
    "RuleExecutionError",
    "AnalysisTimeoutError",
    "MemoryExceededError",
    "InternalAnalysisError",
    # Configuration errors
    "ConfigurationError",
    "MissingConfigError",
    "InvalidPathError",
    # Rule errors
    "RuleValidationError",
    "DuplicateRuleIdError",
    "RuleLoadError",
    # IO errors
    "FileNotFoundError",
    "PermissionDeniedError",
    "FileReadError",
    # Enums
    "ScanStatus",
    "ErrorSeverity",
    # Result objects
    "ScanError",
    "FileResult",
    "ScanResult",
    "ParseErrorFinding",
    # Functions
    "create_scan_error_finding",
]
