"""
Error Result Objects for Vantage Security Scanner.

US-006: Error Result Objects
US-007: Partial Scan Results on Failure
US-008: Unparseable File Findings

Provides structured result objects for scan operations that include
both findings and errors, enabling partial result handling.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

from vantage_core.security.errors.exceptions import MimicError


class ScanStatus(str, Enum):
    """
    Overall scan status.

    Used to indicate whether a scan completed successfully,
    partially, or failed completely.
    """

    SUCCESS = "success"  # All operations completed successfully
    PARTIAL = "partial"  # Some operations failed but results available
    FAILED = "failed"  # Critical failure, no usable results


class ErrorSeverity(str, Enum):
    """
    Severity of scan error.

    Indicates how severe an error is and whether it blocks the scan.
    """

    WARNING = "warning"  # Non-blocking issue, informational
    ERROR = "error"  # Failed operation, but scan continues
    FATAL = "fatal"  # Critical error, scan cannot continue


@dataclass
class ScanError:
    """
    Structured error for inclusion in scan results.

    Represents an error that occurred during scanning,
    with full context for diagnosis and reporting.
    """

    error_type: str
    error_code: str
    message: str
    severity: ErrorSeverity
    file_path: str | None = None
    line_number: int | None = None
    column_number: int | None = None
    recoverable: bool = True
    details: dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    @classmethod
    def from_exception(cls, exc: MimicError) -> "ScanError":
        """
        Create ScanError from MimicError.

        Args:
            exc: The MimicError to convert

        Returns:
            ScanError with data from exception
        """
        # Determine severity based on recoverability
        if not exc.recoverable:
            severity = ErrorSeverity.FATAL
        elif exc.error_code.value.startswith("VANTAGE-3"):  # Config errors
            severity = ErrorSeverity.FATAL
        else:
            severity = ErrorSeverity.ERROR

        return cls(
            error_type=type(exc).__name__,
            error_code=exc.error_code.value,
            message=str(exc),
            severity=severity,
            file_path=exc.context.file_path,
            line_number=exc.context.line_number,
            column_number=exc.context.column_number,
            recoverable=exc.recoverable,
            details=exc.context.additional,
            timestamp=exc.timestamp,
        )

    @classmethod
    def from_generic_exception(
        cls,
        exc: Exception,
        file_path: str | None = None,
        severity: ErrorSeverity = ErrorSeverity.ERROR,
    ) -> "ScanError":
        """
        Create ScanError from a generic exception.

        Args:
            exc: The exception to convert
            file_path: Optional file path for context
            severity: Error severity level

        Returns:
            ScanError with data from exception
        """
        return cls(
            error_type=type(exc).__name__,
            error_code="VANTAGE-000",  # Unknown error
            message=str(exc),
            severity=severity,
            file_path=file_path,
            recoverable=severity != ErrorSeverity.FATAL,
            details={"exception_args": exc.args if exc.args else []},
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "error_type": self.error_type,
            "error_code": self.error_code,
            "message": self.message,
            "severity": self.severity.value,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "column_number": self.column_number,
            "recoverable": self.recoverable,
            "timestamp": self.timestamp,
        }

        if self.details:
            result["details"] = self.details

        return result

    def to_sarif_notification(self) -> dict[str, Any]:
        """
        Convert to SARIF toolExecutionNotification format.

        Returns:
            Dictionary in SARIF notification format
        """
        notification = {
            "message": {"text": self.message},
            "level": "error" if self.severity == ErrorSeverity.FATAL else "warning",
            "descriptor": {"id": self.error_code},
        }

        if self.file_path:
            location = {
                "physicalLocation": {
                    "artifactLocation": {"uri": self.file_path},
                    "region": {
                        "startLine": self.line_number or 1,
                        "startColumn": self.column_number or 1,
                    },
                }
            }
            notification["locations"] = [location]

        return notification


@dataclass
class FileResult:
    """
    Result of scanning a single file.

    Tracks the status, findings, and errors for each file individually
    to support partial result reporting.
    """

    file_path: str
    status: ScanStatus
    findings: list[Any] = field(default_factory=list)  # SecurityFinding
    errors: list[ScanError] = field(default_factory=list)
    duration_ms: int = 0
    lines_scanned: int = 0

    @property
    def is_success(self) -> bool:
        """Check if file was scanned successfully."""
        return self.status == ScanStatus.SUCCESS

    @property
    def has_errors(self) -> bool:
        """Check if file had any errors."""
        return len(self.errors) > 0

    @property
    def finding_count(self) -> int:
        """Get number of findings for this file."""
        return len(self.findings)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "file_path": self.file_path,
            "status": self.status.value,
            "finding_count": self.finding_count,
            "error_count": len(self.errors),
            "errors": [e.to_dict() for e in self.errors],
            "duration_ms": self.duration_ms,
            "lines_scanned": self.lines_scanned,
        }


@dataclass
class ScanResult:
    """
    Complete scan result with findings, errors, and metadata.

    US-006: Provides structured result object containing findings and errors.
    US-007: Supports partial results when some files fail to scan.

    This extends the concept of SecurityScanResult to include
    comprehensive error tracking and partial result support.
    """

    scan_id: str
    status: ScanStatus
    findings: list[Any] = field(default_factory=list)  # SecurityFinding
    errors: list[ScanError] = field(default_factory=list)
    warnings: list[ScanError] = field(default_factory=list)
    file_results: list[FileResult] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def is_complete(self) -> bool:
        """
        Check if results can be considered complete.

        Results are incomplete if the scan failed or has fatal errors.
        """
        if self.status == ScanStatus.FAILED:
            return False

        # Check for fatal errors
        return not any(e.severity == ErrorSeverity.FATAL for e in self.errors)

    @property
    def files_succeeded(self) -> int:
        """Count of successfully scanned files."""
        return sum(1 for r in self.file_results if r.status == ScanStatus.SUCCESS)

    @property
    def files_failed(self) -> int:
        """Count of failed files."""
        return sum(1 for r in self.file_results if r.status == ScanStatus.FAILED)

    @property
    def files_partial(self) -> int:
        """Count of partially scanned files."""
        return sum(1 for r in self.file_results if r.status == ScanStatus.PARTIAL)

    @property
    def total_files(self) -> int:
        """Total number of files processed."""
        return len(self.file_results)

    @property
    def total_findings(self) -> int:
        """Total number of findings."""
        return len(self.findings)

    @property
    def total_errors(self) -> int:
        """Total number of errors."""
        return len(self.errors)

    def get_failed_files(self) -> list[str]:
        """Get list of file paths that failed to scan."""
        return [r.file_path for r in self.file_results if r.status == ScanStatus.FAILED]

    def get_successful_files(self) -> list[str]:
        """Get list of file paths that scanned successfully."""
        return [r.file_path for r in self.file_results if r.status == ScanStatus.SUCCESS]

    def add_file_result(self, file_result: FileResult) -> None:
        """
        Add a file result and update overall status.

        Args:
            file_result: FileResult to add
        """
        self.file_results.append(file_result)

        # Aggregate findings and errors
        self.findings.extend(file_result.findings)
        self.errors.extend(file_result.errors)

        # Update status based on results
        self._update_status()

    def _update_status(self) -> None:
        """Update overall status based on file results."""
        if not self.file_results:
            return

        failed_count = self.files_failed
        total_count = self.total_files

        if failed_count == total_count:
            self.status = ScanStatus.FAILED
        elif failed_count > 0:
            self.status = ScanStatus.PARTIAL
        else:
            self.status = ScanStatus.SUCCESS

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "scan_id": self.scan_id,
            "status": self.status.value,
            "is_complete": self.is_complete,
            "summary": {
                "total_files": self.total_files,
                "files_succeeded": self.files_succeeded,
                "files_failed": self.files_failed,
                "files_partial": self.files_partial,
                "total_findings": self.total_findings,
                "total_errors": self.total_errors,
            },
            "errors": [e.to_dict() for e in self.errors],
            "warnings": [w.to_dict() for w in self.warnings],
            "file_results": [f.to_dict() for f in self.file_results],
            "metadata": self.metadata,
        }

    def __bool__(self) -> bool:
        """Return False if scan failed completely."""
        return self.status != ScanStatus.FAILED


@dataclass
class ParseErrorFinding:
    """
    US-008: Finding for unparseable files.

    Creates a finding when a file cannot be parsed, allowing
    the issue to be tracked and reported alongside security findings.
    """

    file_path: str
    error_message: str
    error_code: str
    line_number: int | None = None
    column_number: int | None = None

    def to_security_finding(self) -> dict[str, Any]:
        """
        Convert to SecurityFinding-compatible dictionary.

        US-008: Report unparseable files as findings so they
        appear in scan results and SARIF output.

        Returns:
            Dictionary that can be used to create a SecurityFinding
        """
        from vantage_core.security.models import (
            OWASPCategory,
            Severity,
            VulnerabilityCategory,
        )

        return {
            "id": f"PARSE-{hash(self.file_path) % 10000:04d}",
            "title": "Unparseable File",
            "description": f"File could not be parsed: {self.error_message}. "
            "Unparseable files may indicate obfuscated or malicious code, "
            "or simply syntax errors that should be fixed.",
            "severity": Severity.INFO,  # INFO severity doesn't fail build
            "confidence": 1.0,
            "owasp_category": OWASPCategory.LLM09,  # Improper Output Handling
            "category": VulnerabilityCategory.CONFIGURATION_WEAKNESS,  # Best match for scan errors
            "file_path": self.file_path,
            "line_number": self.line_number or 1,
            "code_snippet": f"Parse error: {self.error_message}",
            "recommendation": "Review the file for syntax errors. If the file is "
            "intentionally obfuscated, investigate for potential "
            "security concerns.",
            "cwe_id": "CWE-1078",  # Inappropriate Source Code Style or Formatting
            "detection_method": "parse_error",
            "metadata": {
                "error_code": self.error_code,
                "parse_error": True,
            },
        }


def create_scan_error_finding(
    file_path: str,
    error: ScanError,
) -> dict[str, Any]:
    """
    Create a SecurityFinding from a scan error.

    US-008: Allows scan errors to be reported as findings.

    Args:
        file_path: Path to the file
        error: The scan error to convert

    Returns:
        Dictionary that can be used to create a SecurityFinding
    """
    from vantage_core.security.models import (
        OWASPCategory,
        Severity,
        VulnerabilityCategory,
    )

    return {
        "id": f"ERROR-{hash(f'{file_path}{error.error_code}') % 10000:04d}",
        "title": f"Scan Error: {error.error_type}",
        "description": error.message,
        "severity": Severity.INFO,  # INFO severity doesn't fail build
        "confidence": 1.0,
        "owasp_category": OWASPCategory.LLM09,
        "category": VulnerabilityCategory.CONFIGURATION_WEAKNESS,  # Best match for scan errors
        "file_path": file_path,
        "line_number": error.line_number or 1,
        "code_snippet": f"Error: {error.message[:100]}",
        "recommendation": "Review the error details and fix the underlying issue.",
        "cwe_id": "CWE-1078",
        "detection_method": "scan_error",
        "metadata": {
            "error_code": error.error_code,
            "error_type": error.error_type,
            "recoverable": error.recoverable,
        },
    }
