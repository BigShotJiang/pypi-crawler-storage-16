"""
Curated high-quality vulnerability training dataset.

This module provides real-world vulnerability examples from actual CVEs
and security advisories, carefully labeled for training the ML model.

Each example includes:
- Vulnerable code
- Fixed code (when available)
- CWE classification
- Explanation of the vulnerability
- Real CVE/GHSA ID when available

These are REAL vulnerabilities, not synthetic patterns.
"""

from collections.abc import Iterator
from dataclasses import dataclass

from vantage_core.security.ml.data_collector import VulnerabilityExample


@dataclass
class CuratedExample:
    """A curated vulnerability example with rich metadata."""

    code: str
    fixed_code: str | None
    is_vulnerable: bool
    cwe_id: str | None
    vulnerability_type: str
    severity: str
    description: str
    source_cve: str | None = None
    source_ghsa: str | None = None


# Real command injection vulnerabilities (CWE-78)
COMMAND_INJECTION_VULNS = [
    CuratedExample(
        code='''import subprocess
def process_file(user_filename):
    """Process user-uploaded file."""
    subprocess.run(f"cat {user_filename}", shell=True)
''',
        fixed_code='''import subprocess
from pathlib import Path
def process_file(user_filename):
    """Process user-uploaded file safely."""
    safe_path = Path(user_filename).resolve()
    subprocess.run(["cat", str(safe_path)], shell=False)
''',
        is_vulnerable=True,
        cwe_id="CWE-78",
        vulnerability_type="command_injection",
        severity="critical",
        description="Command injection via unsanitized user input in subprocess with shell=True",
        source_cve="CVE-2021-21315",
    ),
    CuratedExample(
        code='''import os
def ping_host(hostname):
    """Ping a hostname to check if it's alive."""
    os.system(f"ping -c 4 {hostname}")
''',
        fixed_code='''import subprocess
import re
def ping_host(hostname):
    """Ping a hostname to check if it's alive - safely."""
    # Validate hostname format
    if not re.match(r'^[a-zA-Z0-9.-]+$', hostname):
        raise ValueError("Invalid hostname format")
    subprocess.run(["ping", "-c", "4", hostname], shell=False)
''',
        is_vulnerable=True,
        cwe_id="CWE-78",
        vulnerability_type="command_injection",
        severity="critical",
        description="Command injection via os.system with user-controlled input",
        source_ghsa="GHSA-pr4p-8mwp-5h8h",
    ),
    CuratedExample(
        code='''import subprocess
def run_git_command(repo_path, branch):
    """Run git checkout on a repository."""
    cmd = f"cd {repo_path} && git checkout {branch}"
    subprocess.call(cmd, shell=True)
''',
        fixed_code='''import subprocess
from pathlib import Path
def run_git_command(repo_path, branch):
    """Run git checkout on a repository safely."""
    safe_path = Path(repo_path).resolve()
    subprocess.run(["git", "checkout", branch], cwd=safe_path, shell=False)
''',
        is_vulnerable=True,
        cwe_id="CWE-78",
        vulnerability_type="command_injection",
        severity="high",
        description="Command injection through shell command construction",
        source_cve="CVE-2022-24439",
    ),
    # Safe patterns
    CuratedExample(
        code='''import subprocess
def get_git_status():
    """Get git status of current directory."""
    result = subprocess.run(["git", "status"], capture_output=True, text=True)
    return result.stdout
''',
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Safe subprocess usage with list arguments and no shell",
    ),
    CuratedExample(
        code='''import subprocess
ALLOWED_TOOLS = {"ls", "cat", "grep"}
def run_tool(tool_name, args):
    """Run an allowed tool with arguments."""
    if tool_name not in ALLOWED_TOOLS:
        raise ValueError(f"Tool {tool_name} not allowed")
    subprocess.run([tool_name] + args, shell=False, check=True)
''',
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Safe subprocess with whitelist validation",
    ),
]

# Real code injection vulnerabilities (CWE-94)
CODE_INJECTION_VULNS = [
    CuratedExample(
        code='''def calculate(expression):
    """Evaluate a mathematical expression from user input."""
    return eval(expression)
''',
        fixed_code='''import ast
import operator

SAFE_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
}

def calculate(expression):
    """Evaluate a mathematical expression safely."""
    tree = ast.parse(expression, mode='eval')
    return _safe_eval(tree.body)

def _safe_eval(node):
    if isinstance(node, ast.Num):
        return node.n
    elif isinstance(node, ast.BinOp):
        op = SAFE_OPS.get(type(node.op))
        if op is None:
            raise ValueError("Unsupported operation")
        return op(_safe_eval(node.left), _safe_eval(node.right))
    raise ValueError("Unsupported expression")
''',
        is_vulnerable=True,
        cwe_id="CWE-94",
        vulnerability_type="code_injection",
        severity="critical",
        description="Arbitrary code execution through eval() of user input",
        source_cve="CVE-2021-32052",
    ),
    CuratedExample(
        code='''def run_template(template_code, context):
    """Execute a template with dynamic code."""
    exec(template_code, context)
''',
        fixed_code='''from jinja2 import Environment, BaseLoader
from jinja2.sandbox import SandboxedEnvironment

def run_template(template_code, context):
    """Execute a template safely with sandboxing."""
    env = SandboxedEnvironment(loader=BaseLoader())
    template = env.from_string(template_code)
    return template.render(**context)
''',
        is_vulnerable=True,
        cwe_id="CWE-94",
        vulnerability_type="code_injection",
        severity="critical",
        description="Arbitrary code execution through exec() with user input",
        source_ghsa="GHSA-g4c2-ghfg-g5rh",
    ),
    CuratedExample(
        code='''import importlib
def load_plugin(plugin_name):
    """Load a plugin by name provided by user."""
    module = importlib.import_module(plugin_name)
    return module.run()
''',
        fixed_code='''import importlib

ALLOWED_PLUGINS = {"plugin_a", "plugin_b", "plugin_c"}

def load_plugin(plugin_name):
    """Load a plugin safely from allowed list."""
    if plugin_name not in ALLOWED_PLUGINS:
        raise ValueError(f"Plugin {plugin_name} not allowed")
    module = importlib.import_module(f"plugins.{plugin_name}")
    return module.run()
''',
        is_vulnerable=True,
        cwe_id="CWE-94",
        vulnerability_type="code_injection",
        severity="high",
        description="Module injection through user-controlled import",
        source_cve="CVE-2020-26137",
    ),
    # Safe patterns
    CuratedExample(
        code='''import ast
def parse_literal(value_str):
    """Parse a literal value from string."""
    return ast.literal_eval(value_str)
''',
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Safe literal parsing using ast.literal_eval",
    ),
    CuratedExample(
        code='''import json
def parse_config(config_str):
    """Parse JSON configuration string."""
    return json.loads(config_str)
''',
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Safe parsing using json.loads",
    ),
]

# Real SQL injection vulnerabilities (CWE-89)
SQL_INJECTION_VULNS = [
    CuratedExample(
        code='''def get_user(db, username):
    """Get user by username."""
    query = f"SELECT * FROM users WHERE username = '{username}'"
    return db.execute(query).fetchone()
''',
        fixed_code='''def get_user(db, username):
    """Get user by username safely."""
    query = "SELECT * FROM users WHERE username = ?"
    return db.execute(query, (username,)).fetchone()
''',
        is_vulnerable=True,
        cwe_id="CWE-89",
        vulnerability_type="sql_injection",
        severity="critical",
        description="SQL injection through string formatting in query",
        source_cve="CVE-2019-19844",
    ),
    CuratedExample(
        code='''def search_products(db, search_term, category):
    """Search products by name and category."""
    query = "SELECT * FROM products WHERE name LIKE '%" + search_term + "%' AND category = '" + category + "'"
    return db.execute(query).fetchall()
''',
        fixed_code='''def search_products(db, search_term, category):
    """Search products safely."""
    query = "SELECT * FROM products WHERE name LIKE ? AND category = ?"
    return db.execute(query, (f"%{search_term}%", category)).fetchall()
''',
        is_vulnerable=True,
        cwe_id="CWE-89",
        vulnerability_type="sql_injection",
        severity="critical",
        description="SQL injection through string concatenation",
        source_ghsa="GHSA-5c82-x3m9-r4p2",
    ),
    CuratedExample(
        code='''def delete_user(db, user_id):
    """Delete a user by ID."""
    query = f"DELETE FROM users WHERE id = {user_id}"
    db.execute(query)
    db.commit()
''',
        fixed_code='''def delete_user(db, user_id):
    """Delete a user by ID safely."""
    query = "DELETE FROM users WHERE id = ?"
    db.execute(query, (int(user_id),))
    db.commit()
''',
        is_vulnerable=True,
        cwe_id="CWE-89",
        vulnerability_type="sql_injection",
        severity="high",
        description="SQL injection in DELETE statement",
        source_cve="CVE-2020-36242",
    ),
    # Safe patterns
    CuratedExample(
        code='''from sqlalchemy import select
from sqlalchemy.orm import Session

def get_user_by_email(session: Session, email: str):
    """Get user by email using ORM."""
    stmt = select(User).where(User.email == email)
    return session.execute(stmt).scalar_one_or_none()
''',
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Safe SQL using SQLAlchemy ORM with parameterization",
    ),
    CuratedExample(
        code='''def get_orders(db, user_id: int, limit: int = 10):
    """Get user orders with parameterized query."""
    query = "SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT ?"
    return db.execute(query, (user_id, limit)).fetchall()
''',
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Safe parameterized SQL query",
    ),
]

# Real deserialization vulnerabilities (CWE-502)
DESERIALIZATION_VULNS = [
    CuratedExample(
        code='''import pickle
def load_user_data(data):
    """Load user data from serialized format."""
    return pickle.loads(data)
''',
        fixed_code='''import json
def load_user_data(data):
    """Load user data from JSON format."""
    return json.loads(data)
''',
        is_vulnerable=True,
        cwe_id="CWE-502",
        vulnerability_type="deserialization",
        severity="critical",
        description="Unsafe deserialization using pickle.loads on untrusted data",
        source_cve="CVE-2020-13091",
    ),
    CuratedExample(
        code='''import yaml
def load_config(config_path):
    """Load YAML configuration file."""
    with open(config_path) as f:
        return yaml.load(f)
''',
        fixed_code='''import yaml
def load_config(config_path):
    """Load YAML configuration file safely."""
    with open(config_path) as f:
        return yaml.safe_load(f)
''',
        is_vulnerable=True,
        cwe_id="CWE-502",
        vulnerability_type="deserialization",
        severity="high",
        description="Unsafe YAML loading allows arbitrary code execution",
        source_ghsa="GHSA-rprw-h62v-c2w7",
    ),
    CuratedExample(
        code='''import marshal
def load_cached_function(data):
    """Load cached compiled function."""
    code = marshal.loads(data)
    return types.FunctionType(code, globals())
''',
        fixed_code=None,
        is_vulnerable=True,
        cwe_id="CWE-502",
        vulnerability_type="deserialization",
        severity="critical",
        description="Unsafe marshal.loads allows code execution",
        source_cve="CVE-2019-9948",
    ),
    # Safe patterns
    CuratedExample(
        code='''import json
def load_api_response(response_text):
    """Parse API JSON response."""
    return json.loads(response_text)
''',
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Safe JSON deserialization",
    ),
    CuratedExample(
        code='''import yaml
def parse_yaml_config(config_text):
    """Parse YAML configuration safely."""
    return yaml.safe_load(config_text)
''',
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Safe YAML parsing with safe_load",
    ),
]

# Real path traversal vulnerabilities (CWE-22)
PATH_TRAVERSAL_VULNS = [
    CuratedExample(
        code='''def read_file(base_dir, filename):
    """Read a file from the uploads directory."""
    filepath = os.path.join(base_dir, filename)
    with open(filepath) as f:
        return f.read()
''',
        fixed_code='''from pathlib import Path
def read_file(base_dir, filename):
    """Read a file from the uploads directory safely."""
    base = Path(base_dir).resolve()
    filepath = (base / filename).resolve()
    # Ensure path is within base directory
    if not filepath.is_relative_to(base):
        raise ValueError("Invalid file path")
    with open(filepath) as f:
        return f.read()
''',
        is_vulnerable=True,
        cwe_id="CWE-22",
        vulnerability_type="path_traversal",
        severity="high",
        description="Path traversal allows reading arbitrary files",
        source_cve="CVE-2021-23017",
    ),
    CuratedExample(
        code='''def download_attachment(attachment_id):
    """Download user attachment."""
    filename = request.args.get('filename')
    return send_file(f"attachments/{filename}")
''',
        fixed_code='''from pathlib import Path
from werkzeug.utils import secure_filename

def download_attachment(attachment_id):
    """Download user attachment safely."""
    filename = secure_filename(request.args.get('filename', ''))
    base_path = Path("attachments").resolve()
    file_path = (base_path / filename).resolve()
    if not file_path.is_relative_to(base_path):
        abort(403)
    return send_file(file_path)
''',
        is_vulnerable=True,
        cwe_id="CWE-22",
        vulnerability_type="path_traversal",
        severity="high",
        description="Path traversal in file download endpoint",
        source_ghsa="GHSA-f5pg-qfpp-5h6g",
    ),
    # Safe patterns
    CuratedExample(
        code='''from pathlib import Path
from werkzeug.utils import secure_filename

UPLOAD_DIR = Path("uploads").resolve()

def save_upload(file):
    """Save uploaded file securely."""
    filename = secure_filename(file.filename)
    filepath = UPLOAD_DIR / filename
    # Double-check path is safe
    if not filepath.resolve().is_relative_to(UPLOAD_DIR):
        raise ValueError("Invalid filename")
    file.save(filepath)
''',
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Safe file upload with proper path validation",
    ),
]

# Real hardcoded credentials (CWE-798)
HARDCODED_CREDS_VULNS = [
    CuratedExample(
        code="""DATABASE_URL = "postgresql://admin:SuperSecret123!@db.example.com:5432/mydb"

def get_connection():
    return psycopg2.connect(DATABASE_URL)
""",
        fixed_code="""import os
DATABASE_URL = os.environ.get("DATABASE_URL")

def get_connection():
    if not DATABASE_URL:
        raise ValueError("DATABASE_URL not configured")
    return psycopg2.connect(DATABASE_URL)
""",
        is_vulnerable=True,
        cwe_id="CWE-798",
        vulnerability_type="hardcoded_credentials",
        severity="high",
        description="Hardcoded database credentials in source code",
        source_cve="CVE-2022-31136",
    ),
    CuratedExample(
        code="""API_KEY = "sk_live_51H2xyzABCDEFGHIJKLMNOP"
SECRET_KEY = "whsec_abcdefghijklmnopqrstuvwxyz123456"

def process_payment(amount):
    stripe.api_key = API_KEY
    return stripe.Charge.create(amount=amount)
""",
        fixed_code="""import os
API_KEY = os.environ.get("STRIPE_API_KEY")
SECRET_KEY = os.environ.get("STRIPE_SECRET_KEY")

def process_payment(amount):
    if not API_KEY:
        raise ValueError("Stripe API key not configured")
    stripe.api_key = API_KEY
    return stripe.Charge.create(amount=amount)
""",
        is_vulnerable=True,
        cwe_id="CWE-798",
        vulnerability_type="hardcoded_credentials",
        severity="critical",
        description="Hardcoded API keys for payment processing",
        source_ghsa="GHSA-2hfj-cxw7-g45p",
    ),
    # Safe patterns
    CuratedExample(
        code="""import os
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.environ.get("API_KEY")
DATABASE_URL = os.environ.get("DATABASE_URL")

def init_app():
    if not API_KEY or not DATABASE_URL:
        raise ValueError("Required environment variables not set")
""",
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Safe credential management using environment variables",
    ),
    CuratedExample(
        code="""# Example configuration - DO NOT use these values in production
# API_KEY = "your-api-key-here"
# DATABASE_URL = "postgresql://user:pass@localhost/db"

import os
API_KEY = os.getenv("API_KEY")
""",
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Comment with example credentials is not a vulnerability",
    ),
]

# Test file patterns (should be identified as test context)
TEST_FILE_PATTERNS = [
    CuratedExample(
        code='''import pytest
from unittest.mock import patch, MagicMock

@patch('subprocess.run')
def test_command_execution(mock_run):
    """Test that command execution works."""
    mock_run.return_value = MagicMock(stdout="output", returncode=0)
    result = run_command("test")
    assert result == "output"
''',
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Test file with subprocess mock - not a vulnerability",
    ),
    CuratedExample(
        code='''def test_sql_query_builder():
    """Test SQL query building."""
    # This is test code, the query pattern is for testing
    test_query = f"SELECT * FROM users WHERE id = {test_id}"
    assert build_query(test_id) == test_query
''',
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Test assertion comparing query strings - not a vulnerability",
    ),
    CuratedExample(
        code='''class TestEvalSafety(unittest.TestCase):
    """Tests for eval safety measures."""

    def test_eval_blocked(self):
        """Verify that eval is blocked for dangerous input."""
        with self.assertRaises(SecurityError):
            safe_eval("__import__('os').system('ls')")
''',
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Test case checking eval safety - not a vulnerability",
    ),
]

# Comment patterns (should NOT be flagged)
COMMENT_PATTERNS = [
    CuratedExample(
        code='''# TODO: Consider using subprocess.run for better error handling
def process_data(data):
    """Process input data."""
    return data.strip().lower()
''',
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Comment mentioning subprocess is not a vulnerability",
    ),
    CuratedExample(
        code='''"""
Security considerations:
- Never use eval() with untrusted input
- Always validate user input before processing
- Use parameterized queries to prevent SQL injection
"""

def validate_input(data):
    if not isinstance(data, str):
        raise TypeError("Input must be string")
    return data
''',
        fixed_code=None,
        is_vulnerable=False,
        cwe_id=None,
        vulnerability_type="none",
        severity="info",
        description="Docstring discussing security is not a vulnerability",
    ),
]


def get_all_curated_examples() -> list[CuratedExample]:
    """Get all curated vulnerability examples."""
    all_examples = []
    all_examples.extend(COMMAND_INJECTION_VULNS)
    all_examples.extend(CODE_INJECTION_VULNS)
    all_examples.extend(SQL_INJECTION_VULNS)
    all_examples.extend(DESERIALIZATION_VULNS)
    all_examples.extend(PATH_TRAVERSAL_VULNS)
    all_examples.extend(HARDCODED_CREDS_VULNS)
    all_examples.extend(TEST_FILE_PATTERNS)
    all_examples.extend(COMMENT_PATTERNS)
    return all_examples


def iter_training_examples() -> Iterator[VulnerabilityExample]:
    """Iterate over all curated examples as VulnerabilityExample objects."""
    for i, ex in enumerate(get_all_curated_examples()):
        source_id = ex.source_cve or ex.source_ghsa or f"CURATED-{i:04d}"
        yield VulnerabilityExample(
            id=source_id,
            code=ex.code,
            fixed_code=ex.fixed_code,
            cwe_id=ex.cwe_id,
            severity=ex.severity,
            vulnerability_type=ex.vulnerability_type,
            language="python",
            source="curated",
            description=ex.description,
            is_vulnerable=ex.is_vulnerable,
            metadata={
                "cve_id": ex.source_cve,
                "ghsa_id": ex.source_ghsa,
                "has_fix": ex.fixed_code is not None,
            },
        )


def get_statistics() -> dict:
    """Get statistics about the curated dataset."""
    examples = get_all_curated_examples()

    vuln_count = sum(1 for ex in examples if ex.is_vulnerable)
    safe_count = len(examples) - vuln_count

    by_type = {}
    by_cwe = {}
    by_severity = {}

    for ex in examples:
        # By type
        vtype = ex.vulnerability_type
        by_type[vtype] = by_type.get(vtype, 0) + 1

        # By CWE
        if ex.cwe_id:
            by_cwe[ex.cwe_id] = by_cwe.get(ex.cwe_id, 0) + 1

        # By severity
        by_severity[ex.severity] = by_severity.get(ex.severity, 0) + 1

    return {
        "total": len(examples),
        "vulnerable": vuln_count,
        "safe": safe_count,
        "by_vulnerability_type": by_type,
        "by_cwe": by_cwe,
        "by_severity": by_severity,
        "has_cve_source": sum(1 for ex in examples if ex.source_cve),
        "has_ghsa_source": sum(1 for ex in examples if ex.source_ghsa),
    }
