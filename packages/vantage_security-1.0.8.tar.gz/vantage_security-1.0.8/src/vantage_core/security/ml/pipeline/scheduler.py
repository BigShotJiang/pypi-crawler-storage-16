"""
Pipeline scheduler for automated daily vulnerability fetching and model training.

Provides:
- Cron-like scheduling for daily runs
- Manual trigger support
- Health monitoring and alerting
- Logging and metrics
"""

import json
import logging
import signal
import sys
import threading
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class PipelineRun:
    """Record of a pipeline run."""

    run_id: str
    start_time: str
    end_time: str | None
    status: str  # running, completed, failed
    fetch_count: int
    training_status: str | None
    metrics: dict | None
    error: str | None


@dataclass
class PipelineConfig:
    """Configuration for the pipeline scheduler."""

    # Scheduling
    fetch_hour: int = 2  # Hour of day to run (UTC)
    fetch_minute: int = 0
    training_hour: int = 3  # Hour to run training (UTC)
    enable_auto_training: bool = True

    # Data fetching
    ecosystems: list[str] | None = None  # None = all
    languages: list[str] = None  # For training data filter

    # Paths
    data_dir: Path = Path.home() / ".cache" / "vantage" / "pipeline"
    model_dir: Path = Path("models/vulnerability_detector")
    log_dir: Path = Path("logs/pipeline")

    # Monitoring
    max_run_history: int = 100
    alert_on_failure: bool = True
    health_check_interval: int = 300  # seconds

    def __post_init__(self):
        if self.languages is None:
            self.languages = ["python", "javascript", "go", "rust"]
        self.data_dir = Path(self.data_dir)
        self.model_dir = Path(self.model_dir)
        self.log_dir = Path(self.log_dir)


class PipelineScheduler:
    """
    Scheduler for the vulnerability data pipeline.

    Runs daily to:
    1. Fetch new vulnerabilities from all sources
    2. Optionally retrain the model with new data
    3. Log metrics and health status
    """

    def __init__(self, config: PipelineConfig | None = None):
        self.config = config or PipelineConfig()

        # Ensure directories exist
        self.config.data_dir.mkdir(parents=True, exist_ok=True)
        self.config.model_dir.mkdir(parents=True, exist_ok=True)
        self.config.log_dir.mkdir(parents=True, exist_ok=True)

        # State
        self.is_running = False
        self.current_run: PipelineRun | None = None
        self.run_history: list[PipelineRun] = []
        self._load_history()

        # Components (lazy loaded)
        self._data_fetcher = None
        self._trainer = None

        # Threading
        self._scheduler_thread: threading.Thread | None = None
        self._stop_event = threading.Event()

    @property
    def data_fetcher(self):
        """Lazy load data fetcher."""
        if self._data_fetcher is None:
            from .data_fetcher import VulnerabilityDataFetcher

            self._data_fetcher = VulnerabilityDataFetcher(
                data_dir=self.config.data_dir,
            )
        return self._data_fetcher

    @property
    def trainer(self):
        """Lazy load trainer."""
        if self._trainer is None:
            from .trainer import ModelTrainer, TrainingConfig

            training_config = TrainingConfig(
                output_dir=self.config.model_dir,
            )
            self._trainer = ModelTrainer(config=training_config)
        return self._trainer

    def _load_history(self):
        """Load run history from disk."""
        history_path = self.config.data_dir / "run_history.json"
        if history_path.exists():
            with open(history_path) as f:
                data = json.load(f)
                self.run_history = [PipelineRun(**r) for r in data]

    def _save_history(self):
        """Save run history to disk."""
        # Trim to max history
        if len(self.run_history) > self.config.max_run_history:
            self.run_history = self.run_history[-self.config.max_run_history :]

        history_path = self.config.data_dir / "run_history.json"
        with open(history_path, "w") as f:
            json.dump([asdict(r) for r in self.run_history], f, indent=2)

    def run_once(self, include_training: bool = True) -> PipelineRun:
        """
        Run the pipeline once.

        Args:
            include_training: Whether to trigger model training

        Returns:
            Pipeline run record
        """
        run_id = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        start_time = datetime.utcnow().isoformat()

        self.current_run = PipelineRun(
            run_id=run_id,
            start_time=start_time,
            end_time=None,
            status="running",
            fetch_count=0,
            training_status=None,
            metrics=None,
            error=None,
        )

        logger.info(f"Starting pipeline run: {run_id}")

        try:
            # Step 1: Fetch new vulnerabilities
            logger.info("Step 1: Fetching vulnerabilities...")
            vulns = self.data_fetcher.fetch_all(
                ecosystems=self.config.ecosystems,
            )
            self.current_run.fetch_count = len(vulns)
            logger.info(f"Fetched {len(vulns)} vulnerabilities")

            # Step 2: Optionally train model
            if include_training and self.config.enable_auto_training:
                logger.info("Step 2: Training model...")
                training_data = self.data_fetcher.get_training_data(
                    languages=self.config.languages,
                )

                if len(training_data) >= 100:  # Minimum for training
                    from random import shuffle

                    shuffle(training_data)
                    split_idx = int(len(training_data) * 0.9)

                    result = self.trainer.train(
                        train_data=training_data[:split_idx],
                        val_data=training_data[split_idx:],
                        incremental=True,
                    )
                    self.current_run.training_status = result.get("status")
                    self.current_run.metrics = result
                else:
                    self.current_run.training_status = "skipped_insufficient_data"

            # Success
            self.current_run.status = "completed"
            self.current_run.end_time = datetime.utcnow().isoformat()

        except Exception as e:
            logger.error(f"Pipeline run failed: {e}", exc_info=True)
            self.current_run.status = "failed"
            self.current_run.error = str(e)
            self.current_run.end_time = datetime.utcnow().isoformat()

            if self.config.alert_on_failure:
                self._send_alert(f"Pipeline run {run_id} failed: {e}")

        # Save to history
        self.run_history.append(self.current_run)
        self._save_history()

        logger.info(f"Pipeline run completed: {self.current_run.status}")
        return self.current_run

    def start(self):
        """Start the scheduler daemon."""
        if self.is_running:
            logger.warning("Scheduler is already running")
            return

        self.is_running = True
        self._stop_event.clear()

        # Set up signal handlers
        signal.signal(signal.SIGINT, self._handle_shutdown)
        signal.signal(signal.SIGTERM, self._handle_shutdown)

        logger.info("Starting pipeline scheduler...")
        logger.info(
            f"  Fetch time: {self.config.fetch_hour:02d}:{self.config.fetch_minute:02d} UTC"
        )
        logger.info(f"  Training enabled: {self.config.enable_auto_training}")

        self._scheduler_thread = threading.Thread(target=self._scheduler_loop, daemon=True)
        self._scheduler_thread.start()

    def stop(self):
        """Stop the scheduler."""
        logger.info("Stopping scheduler...")
        self.is_running = False
        self._stop_event.set()

        if self._scheduler_thread:
            self._scheduler_thread.join(timeout=10)

    def _handle_shutdown(self, signum, frame):
        """Handle shutdown signals."""
        logger.info(f"Received signal {signum}, shutting down...")
        self.stop()
        sys.exit(0)

    def _scheduler_loop(self):
        """Main scheduler loop."""
        while not self._stop_event.is_set():
            now = datetime.utcnow()

            # Check if it's time to run
            if now.hour == self.config.fetch_hour and now.minute == self.config.fetch_minute:
                # Check if we haven't run today
                last_run = self._get_last_successful_run()
                if last_run is None or self._is_different_day(last_run.start_time, now):
                    try:
                        self.run_once()
                    except Exception as e:
                        logger.error(f"Scheduled run failed: {e}")

            # Sleep until next check (every minute)
            self._stop_event.wait(60)

    def _get_last_successful_run(self) -> PipelineRun | None:
        """Get the last successful run."""
        for run in reversed(self.run_history):
            if run.status == "completed":
                return run
        return None

    def _is_different_day(self, timestamp: str, now: datetime) -> bool:
        """Check if timestamp is from a different day than now."""
        run_date = datetime.fromisoformat(timestamp).date()
        return run_date != now.date()

    def _send_alert(self, message: str):
        """Send an alert (placeholder for actual alerting)."""
        logger.error(f"ALERT: {message}")
        # TODO: Implement actual alerting (email, Slack, etc.)

    def get_status(self) -> dict:
        """Get current scheduler status."""
        last_run = self._get_last_successful_run()

        return {
            "is_running": self.is_running,
            "current_run": asdict(self.current_run) if self.current_run else None,
            "last_successful_run": asdict(last_run) if last_run else None,
            "total_runs": len(self.run_history),
            "successful_runs": sum(1 for r in self.run_history if r.status == "completed"),
            "failed_runs": sum(1 for r in self.run_history if r.status == "failed"),
            "fetch_stats": (self.data_fetcher.get_statistics() if self._data_fetcher else None),
            "model_info": self.trainer.get_model_info() if self._trainer else None,
            "config": {
                "fetch_time": f"{self.config.fetch_hour:02d}:{self.config.fetch_minute:02d} UTC",
                "auto_training": self.config.enable_auto_training,
                "languages": self.config.languages,
            },
        }

    def get_recent_runs(self, limit: int = 10) -> list[dict]:
        """Get recent pipeline runs."""
        return [asdict(r) for r in self.run_history[-limit:]]


def run_daily_pipeline():
    """
    Entry point for running the daily pipeline.

    Can be called from cron or systemd timer.
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    config = PipelineConfig()
    scheduler = PipelineScheduler(config)

    # Run once
    result = scheduler.run_once(include_training=True)

    # Return exit code based on status
    return 0 if result.status == "completed" else 1


def run_scheduler_daemon():
    """
    Run the scheduler as a long-running daemon.
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    config = PipelineConfig()
    scheduler = PipelineScheduler(config)

    scheduler.start()

    # Keep main thread alive
    try:
        while scheduler.is_running:
            time.sleep(1)
    except KeyboardInterrupt:
        scheduler.stop()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Vulnerability Pipeline Scheduler")
    parser.add_argument("--daemon", action="store_true", help="Run as daemon")
    parser.add_argument("--once", action="store_true", help="Run once and exit")
    parser.add_argument("--status", action="store_true", help="Show status")

    args = parser.parse_args()

    if args.daemon:
        run_scheduler_daemon()
    elif args.once:
        sys.exit(run_daily_pipeline())
    elif args.status:
        config = PipelineConfig()
        scheduler = PipelineScheduler(config)
        status = scheduler.get_status()
        print(json.dumps(status, indent=2, default=str))
    else:
        parser.print_help()
