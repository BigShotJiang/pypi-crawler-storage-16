"""
Rule execution engine for applying rules to source code.

This module executes rules against AST, handling pattern composition
operators and generating findings from matches.
"""

from __future__ import annotations

import ast
import logging
from dataclasses import dataclass, field
from typing import Any

from vantage_core.security.rules.matcher import PatternMatch, PatternMatcher
from vantage_core.security.rules.schema import (
    Pattern,
    Rule,
)

logger = logging.getLogger(__name__)


@dataclass
class RuleMatch:
    """
    Result of rule execution - a finding location.

    Contains all information needed to generate a security finding.
    """

    rule_id: str
    message: str
    severity: str
    file_path: str
    line: int
    column: int
    end_line: int | None = None
    end_column: int | None = None
    metavariables: dict[str, str] = field(default_factory=dict)
    code_snippet: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    fix: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "rule_id": self.rule_id,
            "message": self.message,
            "severity": self.severity,
            "file_path": self.file_path,
            "line": self.line,
            "column": self.column,
            "end_line": self.end_line,
            "end_column": self.end_column,
            "metavariables": self.metavariables,
            "code_snippet": self.code_snippet,
            "metadata": self.metadata,
            "fix": self.fix,
        }


class RuleExecutor:
    """
    Executes rules against source code.

    Handles pattern composition operators (AND, OR, NOT, INSIDE)
    and taint-mode rules.

    Example:
        executor = RuleExecutor()

        # Execute single rule
        matches = executor.execute(rule, code_ast, "path/to/file.py")

        # Execute multiple rules
        all_matches = executor.execute_rules(rules, code_ast, "path/to/file.py")
    """

    def __init__(self):
        self._matcher = PatternMatcher()

    def execute(
        self, rule: Rule, code_ast: ast.AST, file_path: str, source_code: str = ""
    ) -> list[RuleMatch]:
        """
        Execute a rule against code.

        Args:
            rule: Rule to execute
            code_ast: Parsed AST of the code
            file_path: Path to source file
            source_code: Optional source code for snippets

        Returns:
            List of rule matches (findings)
        """
        try:
            if rule.is_taint_rule:
                return self._execute_taint_rule(rule, code_ast, file_path)
            else:
                return self._execute_pattern_rule(rule, code_ast, file_path, source_code)
        except Exception as e:
            logger.error(f"Error executing rule '{rule.id}' on {file_path}: {e}")
            return []

    def execute_rules(
        self,
        rules: list[Rule],
        code_ast: ast.AST,
        file_path: str,
        source_code: str = "",
        language: str = "python",
    ) -> list[RuleMatch]:
        """
        Execute multiple rules against code.

        Args:
            rules: List of rules to execute
            code_ast: Parsed AST of the code
            file_path: Path to source file
            source_code: Optional source code for snippets
            language: Language to filter rules by

        Returns:
            Combined list of all rule matches
        """
        all_matches: list[RuleMatch] = []

        for rule in rules:
            # Skip rules that don't match the language
            if language.lower() not in [l.lower() for l in rule.languages]:
                continue

            matches = self.execute(rule, code_ast, file_path, source_code)
            all_matches.extend(matches)

        return all_matches

    def _execute_pattern_rule(
        self, rule: Rule, code_ast: ast.AST, file_path: str, source_code: str
    ) -> list[RuleMatch]:
        """Execute a pattern-based rule."""
        matches: list[RuleMatch] = []
        pattern_matches: list[PatternMatch] = []

        # Simple single pattern
        if rule.pattern:
            pattern_matches = self._matcher.match(rule.pattern, code_ast)

        # Pattern composition (AND)
        elif rule.patterns:
            pattern_matches = self._execute_patterns_and(rule.patterns, code_ast)

        # Pattern either (OR)
        elif rule.pattern_either:
            pattern_matches = self._execute_patterns_or(rule.pattern_either, code_ast)

        # Convert pattern matches to rule matches
        for pm in pattern_matches:
            # Apply metavariable filters
            if not self._check_metavariable_filters(rule, pm):
                continue

            match = self._create_rule_match(rule, pm, file_path, source_code)
            matches.append(match)

        return matches

    def _execute_patterns_and(self, patterns: list, code_ast: ast.AST) -> list[PatternMatch]:
        """
        Execute AND composition of patterns.

        All patterns must match at the same location.

        Args:
            patterns: List of pattern operators
            code_ast: AST to search

        Returns:
            List of matches that satisfy all patterns
        """
        if not patterns:
            return []

        # Find the first simple pattern to get initial candidates
        candidates: list[PatternMatch] = []
        remaining_patterns: list = []

        for pattern_op in patterns:
            if hasattr(pattern_op, "pattern") and isinstance(pattern_op, Pattern):
                if not candidates:
                    candidates = self._matcher.match(pattern_op.pattern, code_ast)
                else:
                    remaining_patterns.append(pattern_op)
            elif hasattr(pattern_op, "pattern_either"):
                # Handle nested pattern-either
                either_matches = self._execute_patterns_or(pattern_op.pattern_either, code_ast)
                if not candidates:
                    candidates = either_matches
                else:
                    # Intersect with candidates
                    either_locs = {(m.line, m.column) for m in either_matches}
                    candidates = [c for c in candidates if (c.line, c.column) in either_locs]
            else:
                remaining_patterns.append(pattern_op)

        if not candidates:
            return []

        # Apply remaining patterns as filters
        for pattern_op in remaining_patterns:
            filtered = []
            for match in candidates:
                if self._satisfies_operator(match, pattern_op, code_ast):
                    filtered.append(match)
            candidates = filtered

        return candidates

    def _execute_patterns_or(self, patterns: list, code_ast: ast.AST) -> list[PatternMatch]:
        """
        Execute OR composition of patterns.

        At least one pattern must match.

        Args:
            patterns: List of pattern operators
            code_ast: AST to search

        Returns:
            Union of all matches (deduplicated by location)
        """
        all_matches: list[PatternMatch] = []
        seen_locations: set[tuple[int, int]] = set()

        for pattern_op in patterns:
            matches = self._get_operator_matches(pattern_op, code_ast)
            for match in matches:
                loc = (match.line, match.column)
                if loc not in seen_locations:
                    all_matches.append(match)
                    seen_locations.add(loc)

        return all_matches

    def _get_operator_matches(self, pattern_op, code_ast: ast.AST) -> list[PatternMatch]:
        """Get matches for a single pattern operator."""
        if hasattr(pattern_op, "pattern") and isinstance(pattern_op, Pattern):
            return self._matcher.match(pattern_op.pattern, code_ast)
        elif hasattr(pattern_op, "pattern_regex"):
            return self._match_regex(pattern_op.pattern_regex, code_ast)
        elif hasattr(pattern_op, "patterns"):
            return self._execute_patterns_and(pattern_op.patterns, code_ast)
        elif hasattr(pattern_op, "pattern_either"):
            return self._execute_patterns_or(pattern_op.pattern_either, code_ast)
        return []

    def _satisfies_operator(self, match: PatternMatch, operator, code_ast: ast.AST) -> bool:
        """
        Check if match satisfies a pattern operator.

        Args:
            match: Candidate match
            operator: Pattern operator to check
            code_ast: Full AST for context checks

        Returns:
            True if match satisfies the operator
        """
        # pattern-not: must not match at this location
        if hasattr(operator, "pattern_not"):
            not_matches = self._matcher.match(operator.pattern_not, match.node)
            return len(not_matches) == 0

        # pattern-not-inside: must not be inside this pattern
        if hasattr(operator, "pattern_not_inside"):
            container_matches = self._matcher.match(operator.pattern_not_inside, code_ast)
            # Check if match is inside any container
            for container in container_matches:
                if self._is_inside(match, container):
                    return False
            return True

        # pattern-inside: must be inside this pattern
        if hasattr(operator, "pattern_inside"):
            container_matches = self._matcher.match(operator.pattern_inside, code_ast)
            # Check if match is inside any container
            for container in container_matches:
                if self._is_inside(match, container):
                    return True
            return False

        # For simple patterns, check if they also match
        if hasattr(operator, "pattern"):
            sub_matches = self._matcher.match(operator.pattern, match.node)
            return len(sub_matches) > 0

        return True

    def _is_inside(self, inner: PatternMatch, outer: PatternMatch) -> bool:
        """Check if inner match is inside outer match."""
        # Simple line-based check
        inner_start = inner.line
        inner_end = inner.end_line or inner.line
        outer_start = outer.line
        outer_end = outer.end_line or outer.line

        return inner_start >= outer_start and inner_end <= outer_end

    def _match_regex(self, regex: str, code_ast: ast.AST) -> list[PatternMatch]:
        """
        Match a regex pattern against string constants.

        Args:
            regex: Regular expression pattern
            code_ast: AST to search

        Returns:
            List of matches for string constants matching the regex
        """
        import re

        matches: list[PatternMatch] = []

        try:
            pattern = re.compile(regex)
        except re.error as e:
            logger.warning(f"Invalid regex pattern: {regex} - {e}")
            return matches

        for node in ast.walk(code_ast):
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                if pattern.search(node.value):
                    matches.append(
                        PatternMatch(
                            node=node,
                            metavariables={},
                            line=node.lineno,
                            column=node.col_offset,
                        )
                    )

        return matches

    def _check_metavariable_filters(self, rule: Rule, match: PatternMatch) -> bool:
        """
        Check if match passes metavariable filters.

        Args:
            rule: Rule with filters
            match: Match to check

        Returns:
            True if all filters pass
        """
        import re

        # Check regex filters
        if rule.metavariable_regex:
            for filter_def in rule.metavariable_regex:
                var_name = filter_def.metavariable.lstrip("$")
                if var_name not in match.metavariables:
                    return False

                value = match.get_metavariable_str(var_name)
                if value and filter_def.regex:
                    if not re.search(filter_def.regex, value):
                        return False

        # Check comparison filters
        if rule.metavariable_comparison:
            for filter_def in rule.metavariable_comparison:
                var_name = filter_def.metavariable.lstrip("$")
                if var_name not in match.metavariables:
                    return False

                # Try to evaluate comparison
                value = match.get_metavariable_str(var_name)
                if value and filter_def.comparison:
                    try:
                        # Only support simple numeric comparisons
                        num_value = float(value)
                        comparison = filter_def.comparison.strip()
                        if comparison.startswith(">"):
                            threshold = float(comparison[1:].strip())
                            if not num_value > threshold:
                                return False
                        elif comparison.startswith("<"):
                            threshold = float(comparison[1:].strip())
                            if not num_value < threshold:
                                return False
                        elif comparison.startswith("=="):
                            threshold = float(comparison[2:].strip())
                            if not num_value == threshold:
                                return False
                    except (ValueError, TypeError):
                        # Not a numeric comparison, skip
                        pass

        return True

    def _create_rule_match(
        self, rule: Rule, pattern_match: PatternMatch, file_path: str, source_code: str
    ) -> RuleMatch:
        """
        Create a RuleMatch from a PatternMatch.

        Args:
            rule: Rule that matched
            pattern_match: Pattern match result
            file_path: Path to source file
            source_code: Source code for snippet extraction

        Returns:
            RuleMatch with all finding information
        """
        # Interpolate metavariables in message
        message = self._interpolate_message(rule.message, pattern_match)

        # Extract code snippet
        snippet = ""
        if source_code:
            snippet = self._extract_snippet(
                source_code,
                pattern_match.line,
                pattern_match.end_line or pattern_match.line,
            )

        # Convert metavariables to strings
        metavar_strs = {}
        for name, node in pattern_match.metavariables.items():
            try:
                metavar_strs[name] = ast.unparse(node)
            except Exception:
                metavar_strs[name] = ast.dump(node)

        return RuleMatch(
            rule_id=rule.id,
            message=message,
            severity=rule.severity.to_normalized(),
            file_path=file_path,
            line=pattern_match.line,
            column=pattern_match.column,
            end_line=pattern_match.end_line,
            end_column=pattern_match.end_column,
            metavariables=metavar_strs,
            code_snippet=snippet,
            metadata=rule.metadata,
            fix=rule.fix,
        )

    def _interpolate_message(self, message: str, match: PatternMatch) -> str:
        """
        Interpolate metavariables in message.

        Replaces $VAR_NAME with actual values.

        Args:
            message: Message template
            match: Match with metavariables

        Returns:
            Interpolated message
        """
        result = message

        for name, node in match.metavariables.items():
            try:
                value = ast.unparse(node)
            except Exception:
                value = f"<{name}>"

            # Replace $NAME with value
            result = result.replace(f"${name}", value)

        return result

    def _extract_snippet(
        self, source_code: str, start_line: int, end_line: int, context_lines: int = 2
    ) -> str:
        """
        Extract code snippet with context.

        Args:
            source_code: Full source code
            start_line: Starting line number (1-indexed)
            end_line: Ending line number (1-indexed)
            context_lines: Number of context lines before/after

        Returns:
            Code snippet string
        """
        lines = source_code.splitlines()

        # Calculate range
        snippet_start = max(0, start_line - context_lines - 1)
        snippet_end = min(len(lines), end_line + context_lines)

        return "\n".join(lines[snippet_start:snippet_end])

    def _execute_taint_rule(self, rule: Rule, code_ast: ast.AST, file_path: str) -> list[RuleMatch]:
        """
        Execute a taint-mode rule.

        This is a simplified taint analysis that finds source-to-sink
        patterns. For full taint analysis, use the taint module.

        Args:
            rule: Taint rule to execute
            code_ast: AST to analyze
            file_path: Path to source file

        Returns:
            List of rule matches
        """
        if not rule.taint:
            return []

        matches: list[RuleMatch] = []

        # Find all sources
        source_matches: list[PatternMatch] = []
        for source_def in rule.taint.sources:
            source_matches.extend(self._matcher.match(source_def.pattern, code_ast))

        # Find all sinks
        sink_matches: list[PatternMatch] = []
        for sink_def in rule.taint.sinks:
            sink_matches.extend(self._matcher.match(sink_def.pattern, code_ast))

        # Find sanitizers
        sanitizer_locations: set[int] = set()
        for sanitizer_def in rule.taint.sanitizers:
            for match in self._matcher.match(sanitizer_def.pattern, code_ast):
                sanitizer_locations.add(match.line)

        # Simple heuristic: if source appears before sink in same function
        # and no sanitizer in between, flag it
        for sink in sink_matches:
            for source in source_matches:
                # Check if source is before sink
                if source.line < sink.line:
                    # Check for sanitizers between
                    has_sanitizer = any(
                        source.line < san_line < sink.line for san_line in sanitizer_locations
                    )

                    if not has_sanitizer:
                        # Create finding at sink location
                        match = RuleMatch(
                            rule_id=rule.id,
                            message=rule.message,
                            severity=rule.severity.to_normalized(),
                            file_path=file_path,
                            line=sink.line,
                            column=sink.column,
                            end_line=sink.end_line,
                            end_column=sink.end_column,
                            metavariables={
                                **{k: ast.unparse(v) for k, v in sink.metavariables.items()},
                                "SOURCE_LINE": str(source.line),
                            },
                            metadata={
                                **rule.metadata,
                                "source_line": source.line,
                                "sink_line": sink.line,
                            },
                            fix=rule.fix,
                        )
                        matches.append(match)
                        break  # Only report once per sink

        return matches
