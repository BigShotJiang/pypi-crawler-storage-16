"""
Rule loader and validator for YAML rule files.

This module provides functionality to load, parse, and validate
security rules from YAML files with comprehensive error reporting.
"""

from __future__ import annotations

import logging
from collections.abc import Iterator
from pathlib import Path

import yaml

from vantage_core.security.rules.schema import Rule, RuleFile

logger = logging.getLogger(__name__)


class RuleValidationError(Exception):
    """Raised when a rule fails validation."""

    def __init__(self, rule_id: str, errors: list[str], file_path: str | None = None):
        self.rule_id = rule_id
        self.errors = errors
        self.file_path = file_path
        message = f"Rule '{rule_id}' validation failed: {'; '.join(errors)}"
        if file_path:
            message = f"{file_path}: {message}"
        super().__init__(message)


class DuplicateRuleError(Exception):
    """Raised when duplicate rule IDs are found."""

    def __init__(self, rule_id: str, files: list[str]):
        self.rule_id = rule_id
        self.files = files
        super().__init__(f"Duplicate rule ID '{rule_id}' found in: {', '.join(files)}")


class RuleLoader:
    """
    Loads and validates rules from YAML files.

    Supports loading from directories, with deduplication
    and comprehensive validation.

    Example:
        loader = RuleLoader()
        rules = loader.load_rules([Path("rules/"), Path("custom-rules/")])

        # Get specific rule
        rule = loader.get_rule("my-rule-id")
    """

    def __init__(self):
        self._rules_cache: dict[str, Rule] = {}
        self._rule_sources: dict[str, str] = {}  # rule_id -> file_path

    def load_rules(self, paths: list[Path]) -> list[Rule]:
        """
        Load rules from multiple paths.

        Args:
            paths: List of file or directory paths

        Returns:
            List of validated Rule objects

        Raises:
            DuplicateRuleError: If duplicate rule IDs are found
        """
        rules: list[Rule] = []
        rule_files: dict[str, list[str]] = {}  # rule_id -> [file_paths]

        for path in paths:
            if not path.exists():
                logger.warning(f"Rule path does not exist: {path}")
                continue

            if path.is_file():
                file_rules = self._load_file(path)
                for rule in file_rules:
                    if rule.id not in rule_files:
                        rule_files[rule.id] = []
                    rule_files[rule.id].append(str(path))
                rules.extend(file_rules)
            elif path.is_dir():
                for yaml_file in self._find_yaml_files(path):
                    file_rules = self._load_file(yaml_file)
                    for rule in file_rules:
                        if rule.id not in rule_files:
                            rule_files[rule.id] = []
                        rule_files[rule.id].append(str(yaml_file))
                    rules.extend(file_rules)

        # Check for duplicates and deduplicate
        seen_ids: set[str] = set()
        unique_rules: list[Rule] = []
        duplicates_warned: set[str] = set()

        for rule in rules:
            if rule.id in seen_ids:
                if rule.id not in duplicates_warned:
                    files = rule_files.get(rule.id, [])
                    logger.warning(
                        f"Duplicate rule ID '{rule.id}' found in: {', '.join(files)}. "
                        f"Using first occurrence."
                    )
                    duplicates_warned.add(rule.id)
                continue

            seen_ids.add(rule.id)
            unique_rules.append(rule)
            self._rules_cache[rule.id] = rule
            if rule_files.get(rule.id):
                self._rule_sources[rule.id] = rule_files[rule.id][0]

        logger.info(f"Loaded {len(unique_rules)} rules from {len(paths)} path(s)")

        return unique_rules

    def _find_yaml_files(self, directory: Path) -> Iterator[Path]:
        """Find all YAML files in directory recursively."""
        for pattern in ["*.yaml", "*.yml"]:
            yield from directory.rglob(pattern)

    def _load_file(self, path: Path) -> list[Rule]:
        """
        Load rules from a single YAML file.

        Args:
            path: Path to YAML file

        Returns:
            List of Rule objects from the file
        """
        try:
            with open(path, encoding="utf-8") as f:
                data = yaml.safe_load(f)

            if not data:
                return []

            if "rules" not in data:
                logger.warning(f"No 'rules' key found in {path}")
                return []

            # Parse using Pydantic model
            rule_file = RuleFile(**data)

            # Validate each rule
            valid_rules: list[Rule] = []
            for rule in rule_file.rules:
                errors = self._validate_rule(rule)
                if errors:
                    logger.warning(f"Invalid rule '{rule.id}' in {path}: {'; '.join(errors)}")
                else:
                    valid_rules.append(rule)

            return valid_rules

        except yaml.YAMLError as e:
            logger.error(f"YAML parse error in {path}: {e}")
            return []
        except Exception as e:
            logger.error(f"Error loading rules from {path}: {e}")
            return []

    def _validate_rule(self, rule: Rule) -> list[str]:
        """
        Validate rule structure and patterns.

        Args:
            rule: Rule to validate

        Returns:
            List of validation error messages
        """
        errors: list[str] = []

        # Must have either patterns or taint mode
        if rule.is_taint_rule:
            if not rule.taint:
                errors.append("Taint rule must have taint configuration")
            elif not rule.taint.sources:
                errors.append("Taint rule must have at least one source")
            elif not rule.taint.sinks:
                errors.append("Taint rule must have at least one sink")
        elif not rule.has_pattern:
            errors.append("Rule must have pattern, patterns, pattern-either, or taint mode")

        # Validate patterns syntax (basic check)
        if rule.pattern:
            error = self._validate_pattern_syntax(rule.pattern)
            if error:
                errors.append(f"Invalid pattern syntax: {error}")

        if rule.patterns:
            for i, pattern_op in enumerate(rule.patterns):
                if hasattr(pattern_op, "pattern"):
                    error = self._validate_pattern_syntax(pattern_op.pattern)
                    if error:
                        errors.append(f"Invalid pattern[{i}] syntax: {error}")
                if hasattr(pattern_op, "pattern_inside"):
                    error = self._validate_pattern_syntax(pattern_op.pattern_inside)
                    if error:
                        errors.append(f"Invalid pattern-inside[{i}] syntax: {error}")
                if hasattr(pattern_op, "pattern_not"):
                    error = self._validate_pattern_syntax(pattern_op.pattern_not)
                    if error:
                        errors.append(f"Invalid pattern-not[{i}] syntax: {error}")

        return errors

    def _validate_pattern_syntax(self, pattern: str) -> str | None:
        """
        Validate pattern syntax is parseable.

        Args:
            pattern: Pattern string to validate

        Returns:
            Error message if invalid, None if valid
        """
        import re

        # Basic validation - check for balanced brackets
        open_count = pattern.count("(") + pattern.count("[") + pattern.count("{")
        close_count = pattern.count(")") + pattern.count("]") + pattern.count("}")

        if open_count != close_count:
            return "Unbalanced brackets"

        # Check metavariable format
        metavars = re.findall(r"\$([A-Za-z_][A-Za-z0-9_]*)", pattern)
        for var in metavars:
            if not var[0].isupper() and not var.startswith("..."):
                # Warning only - metavars should be uppercase but we allow lowercase
                pass

        return None

    def get_rule(self, rule_id: str) -> Rule | None:
        """
        Get a rule by ID from cache.

        Args:
            rule_id: Rule identifier

        Returns:
            Rule object or None if not found
        """
        return self._rules_cache.get(rule_id)

    def get_rule_source(self, rule_id: str) -> str | None:
        """
        Get the file path where a rule was loaded from.

        Args:
            rule_id: Rule identifier

        Returns:
            File path or None if not found
        """
        return self._rule_sources.get(rule_id)

    def get_all_rules(self) -> list[Rule]:
        """Get all cached rules."""
        return list(self._rules_cache.values())

    def clear_cache(self) -> None:
        """Clear the rule cache."""
        self._rules_cache.clear()
        self._rule_sources.clear()

    def reload_rules(self, paths: list[Path]) -> list[Rule]:
        """
        Reload rules from paths, clearing cache first.

        Args:
            paths: List of file or directory paths

        Returns:
            List of validated Rule objects
        """
        self.clear_cache()
        return self.load_rules(paths)
