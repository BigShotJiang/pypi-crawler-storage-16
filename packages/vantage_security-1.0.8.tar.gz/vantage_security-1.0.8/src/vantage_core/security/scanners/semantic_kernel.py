"""
Semantic Kernel Security Scanner.

Detects agents, plugins, and planners in Semantic Kernel-based projects
and identifies function permissions.
"""

import ast
import re
import time
from pathlib import Path

from vantage_core.security.models import (
    AgentCommunication,
    CommunicationType,
    ContentType,
    OWASPCategory,
    SecurityAgent,
    SecurityFinding,
    SecurityScanResult,
    SecurityTool,
    Severity,
    ToolCategory,
    TrustLevel,
    VulnerabilityCategory,
)
from vantage_core.security.scanners.base import SecurityScanner


class SemanticKernelSecurityScanner(SecurityScanner):
    """
    Security scanner for Microsoft Semantic Kernel framework.

    Detects:
    - ChatCompletionAgent and other agent types
    - Native functions and prompt functions
    - Kernel configurations
    - AgentGroupChat setups
    """

    framework_name = "semantic_kernel"

    AGENT_TYPES = [
        "ChatCompletionAgent",
        "OpenAIAssistantAgent",
        "AzureAssistantAgent",
    ]

    def scan(self, path: Path) -> SecurityScanResult:
        """Scan Semantic Kernel project for security issues."""
        start_time = time.time()
        findings: list[SecurityFinding] = []
        agents: list[SecurityAgent] = []
        communications: list[AgentCommunication] = []

        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()

                file_agents = self._extract_agents_from_file(file_path, code)
                agents.extend(file_agents)

                file_communications = self._extract_communications(file_path, code)
                communications.extend(file_communications)

                findings.extend(self.check_hardcoded_secrets(code, str(file_path)))
                findings.extend(self.check_dangerous_code_patterns(code, str(file_path)))
                findings.extend(self._check_sk_patterns(code, str(file_path)))

                for agent in file_agents:
                    agent_findings = self.get_vulnerabilities(agent)
                    findings.extend(agent_findings)

            except Exception:
                continue

        return self.create_scan_result(
            findings=findings,
            agents=agents,
            communications=communications,
            frameworks=["semantic_kernel"],
            start_time=start_time,
        )

    def _extract_communications(self, file_path: Path, code: str) -> list[AgentCommunication]:
        """Extract communications from Semantic Kernel code."""
        communications: list[AgentCommunication] = []
        tree = ast.parse(code)

        class CommunicationVisitor(ast.NodeVisitor):
            def __init__(self):
                self.comms: list[AgentCommunication] = []

            def visit_Call(self, node: ast.Call) -> None:
                func_name = self._get_func_name(node)

                # AgentGroupChat(agents=[...])
                if func_name == "AgentGroupChat":
                    agents = []
                    for keyword in node.keywords:
                        if keyword.arg == "agents":
                            agents = self._extract_agent_names(keyword.value)

                    # Create mesh topology
                    for i, source in enumerate(agents):
                        for j, target in enumerate(agents):
                            if i != j:
                                self.comms.append(
                                    AgentCommunication(
                                        source_id=source,
                                        target_id=target,
                                        communication_type=CommunicationType.BROADCAST.value,
                                        metadata={
                                            "protocol": "agent_group_chat",
                                            "content_type": ContentType.TEXT.value,
                                            "file_path": str(file_path),
                                            "line_number": node.lineno,
                                        },
                                    )
                                )

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return node.func.attr
                return ""

            def _extract_agent_names(self, node: ast.AST) -> list[str]:
                names = []
                if isinstance(node, ast.List):
                    for elt in node.elts:
                        if isinstance(elt, ast.Name):
                            names.append(elt.id)
                return names

        visitor = CommunicationVisitor()
        visitor.visit(tree)
        return visitor.comms

    def get_agents(self, path: Path) -> list[SecurityAgent]:
        """Extract Semantic Kernel agents from path."""
        agents: list[SecurityAgent] = []

        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()
                agents.extend(self._extract_agents_from_file(file_path, code))
            except Exception:
                continue

        return agents

    def get_vulnerabilities(self, agent: SecurityAgent) -> list[SecurityFinding]:
        """Analyze Semantic Kernel agent for vulnerabilities."""
        findings: list[SecurityFinding] = []
        file_path = agent.file_path or "unknown"
        line_number = agent.line_number or 1

        if agent.system_prompt:
            finding = self.check_prompt_injection_risk(
                agent.system_prompt, file_path, line_number, agent.id
            )
            if finding:
                findings.append(finding)

        finding = self.check_excessive_agency(agent, file_path, line_number)
        if finding:
            findings.append(finding)

        # Check plugin security
        findings.extend(self._check_plugin_security(agent, file_path, line_number))

        return findings

    def _extract_agents_from_file(self, file_path: Path, code: str) -> list[SecurityAgent]:
        """Extract Semantic Kernel agents from a single file."""
        agents: list[SecurityAgent] = []
        tree = ast.parse(code)

        class AgentVisitor(ast.NodeVisitor):
            def __init__(self, scanner: SemanticKernelSecurityScanner):
                self.scanner = scanner
                self.agents: list[SecurityAgent] = []
                self.kernel_functions: list[SecurityTool] = []

            def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
                # Check for @kernel_function decorator
                for decorator in node.decorator_list:
                    decorator_name = ""
                    if isinstance(decorator, ast.Name):
                        decorator_name = decorator.id
                    elif isinstance(decorator, ast.Call):
                        if isinstance(decorator.func, ast.Name):
                            decorator_name = decorator.func.id

                    if decorator_name == "kernel_function":
                        tool = self._extract_kernel_function(node)
                        if tool:
                            self.kernel_functions.append(tool)

                self.generic_visit(node)

            def visit_Call(self, node: ast.Call) -> None:
                func_name = self._get_func_name(node)

                if func_name in SemanticKernelSecurityScanner.AGENT_TYPES:
                    agent = self._extract_agent_from_call(node, func_name)
                    if agent:
                        self.agents.append(agent)

                # Check for AgentGroupChat
                if func_name == "AgentGroupChat":
                    agent = self._extract_group_chat(node)
                    if agent:
                        self.agents.append(agent)

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return node.func.attr
                return ""

            def _extract_agent_from_call(
                self, node: ast.Call, agent_type: str
            ) -> SecurityAgent | None:
                name = agent_type
                instructions = None

                for keyword in node.keywords:
                    if keyword.arg == "name":
                        if isinstance(keyword.value, ast.Constant):
                            name = str(keyword.value.value)
                    elif keyword.arg == "instructions":
                        if isinstance(keyword.value, ast.Constant):
                            instructions = str(keyword.value.value)

                agent_id = f"sk-{name}-{node.lineno}"

                return SecurityAgent(
                    id=agent_id,
                    name=name,
                    framework="semantic_kernel",
                    system_prompt=instructions,
                    tools=self.kernel_functions.copy(),
                    file_path=str(file_path),
                    line_number=node.lineno,
                    trust_level=self.scanner.infer_trust_level(
                        {"name": name, "system_prompt": instructions or ""}
                    ),
                    metadata={"agent_type": agent_type},
                )

            def _extract_group_chat(self, node: ast.Call) -> SecurityAgent | None:
                agent_id = f"sk-groupchat-{node.lineno}"

                return SecurityAgent(
                    id=agent_id,
                    name="AgentGroupChat",
                    framework="semantic_kernel",
                    file_path=str(file_path),
                    line_number=node.lineno,
                    trust_level=TrustLevel.INTERNAL,
                    metadata={"type": "group_chat"},
                )

            def _extract_kernel_function(self, node: ast.FunctionDef) -> SecurityTool | None:
                # Analyze function body for dangerous patterns
                categories: list[ToolCategory] = []
                risk_score = 0.0

                code = ast.unparse(node)
                if any(x in code for x in ["subprocess", "os.system", "exec(", "eval("]):
                    categories.append(ToolCategory.CODE_EXECUTION)
                    risk_score = 8.0
                if any(x in code for x in ["open(", "read(", "write("]):
                    categories.append(ToolCategory.FILE_SYSTEM)
                    risk_score = max(risk_score, 5.0)
                if any(x in code for x in ["requests.", "http", "urllib"]):
                    categories.append(ToolCategory.NETWORK)
                    risk_score = max(risk_score, 4.0)

                return SecurityTool(
                    name=node.name,
                    description=f"Kernel function: {node.name}",
                    categories=categories,
                    required_trust_level=(
                        TrustLevel.PRIVILEGED if categories else TrustLevel.INTERNAL
                    ),
                    has_side_effects=bool(categories),
                    risk_score=risk_score,
                )

        visitor = AgentVisitor(self)
        visitor.visit(tree)
        return visitor.agents

    def _check_sk_patterns(self, code: str, file_path: str) -> list[SecurityFinding]:
        """Check for Semantic Kernel-specific security patterns."""
        findings: list[SecurityFinding] = []
        lines = code.split("\n")

        for i, line in enumerate(lines, 1):
            # Check for auto function calling
            if re.search(r"auto_invoke_kernel_functions\s*=\s*True", line):
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Auto Function Invocation Enabled",
                        description="Automatic function invocation allows the model to call any registered function without explicit approval.",
                        severity=Severity.HIGH,
                        confidence=0.9,
                        owasp_category=OWASPCategory.LLM08,
                        category=VulnerabilityCategory.EXCESSIVE_AGENCY,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Implement function call approval or restrict available functions.",
                        cwe_id="CWE-862",
                    )
                )

            # Check for plugins from external sources
            if re.search(r"import_plugin_from_openapi|add_plugin_from_openapi", line):
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="External OpenAPI Plugin Import",
                        description="Importing plugins from external OpenAPI specs can introduce supply chain vulnerabilities.",
                        severity=Severity.MEDIUM,
                        confidence=0.8,
                        owasp_category=OWASPCategory.LLM05,
                        category=VulnerabilityCategory.CONFIGURATION_WEAKNESS,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Verify plugin sources and implement plugin signing.",
                        cwe_id="CWE-494",
                    )
                )

            # Check for planner without constraints
            if re.search(r"(Planner|create_plan)\s*\(", line):
                context = "\n".join(lines[max(0, i - 3) : min(len(lines), i + 3)])
                if "excluded_plugins" not in context and "excluded_functions" not in context:
                    findings.append(
                        SecurityFinding(
                            id=SecurityFinding.generate_id(),
                            title="Planner Without Function Restrictions",
                            description="Planner can access all registered functions without restrictions.",
                            severity=Severity.MEDIUM,
                            confidence=0.7,
                            owasp_category=OWASPCategory.LLM08,
                            category=VulnerabilityCategory.EXCESSIVE_AGENCY,
                            file_path=file_path,
                            line_number=i,
                            code_snippet=line.strip(),
                            recommendation="Use excluded_plugins or excluded_functions to limit planner scope.",
                            cwe_id="CWE-250",
                        )
                    )

        return findings

    def _check_plugin_security(
        self, agent: SecurityAgent, file_path: str, line_number: int
    ) -> list[SecurityFinding]:
        """Check plugin/function security for Semantic Kernel agent."""
        findings: list[SecurityFinding] = []

        high_risk_functions = []
        for tool in agent.tools:
            if tool.risk_score >= 7.0:
                high_risk_functions.append(tool.name)

        if high_risk_functions:
            findings.append(
                SecurityFinding(
                    id=SecurityFinding.generate_id(),
                    title="High-Risk Kernel Functions Detected",
                    description=f"Agent has access to high-risk functions: {', '.join(high_risk_functions)}",
                    severity=Severity.HIGH,
                    confidence=0.85,
                    owasp_category=OWASPCategory.LLM07,
                    category=VulnerabilityCategory.INSECURE_TOOL_USE,
                    file_path=file_path,
                    line_number=line_number,
                    code_snippet=f"Functions: {high_risk_functions}",
                    recommendation="Implement proper authorization checks in kernel functions. Use filters to restrict access.",
                    agent_id=agent.id,
                    cwe_id="CWE-862",
                )
            )

        return findings

    @classmethod
    def can_handle(cls, path: Path) -> bool:
        """Check if this scanner can handle Semantic Kernel projects."""
        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    content = f.read()
                    if any(
                        x in content for x in ["from semantic_kernel", "import semantic_kernel"]
                    ):
                        return True
            except Exception:
                continue

        return False
