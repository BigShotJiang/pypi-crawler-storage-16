"""
Enhanced Scoring Engine with Severity-Weighted Scoring.

This module provides an enhanced scoring engine that integrates grade capping,
exponential penalties, and confidence intervals to provide accurate security grades.

Addresses the "A grade with critical vulnerabilities" problem.
"""

from __future__ import annotations

from dataclasses import dataclass

from vantage_core.security.models import SecurityScanResult
from vantage_core.security.scoring.engine import (
    SCORING_WEIGHTS,
    ATSSResult,
    SecurityScoringEngine,
)
from vantage_core.security.scoring.severity_weighting import (
    ConfidenceInterval,
    ConfidenceIntervalCalculator,
    ExponentialPenaltyCalculator,
    GradeCapEnforcer,
    GradeCapResult,
    PenaltyBreakdown,
)
from vantage_core.security.topology.graph import AgentGraph


@dataclass
class EnhancedATSSResult(ATSSResult):
    """
    Extended ATSS result with severity-weighted scoring features.

    Includes grade capping information, confidence intervals,
    and penalty breakdowns for full transparency.
    """

    # Severity-weighted scoring additions
    grade_capped_from: str | None = None  # Original grade before capping
    confidence_interval: tuple[float, float] | None = None  # (lower, upper) bounds
    severity_penalties: dict[str, float] | None = None  # Breakdown by severity
    is_grade_capped: bool = False
    cap_reason: str | None = None
    penalty_breakdown: PenaltyBreakdown | None = None
    confidence_details: ConfidenceInterval | None = None
    grade_cap_result: GradeCapResult | None = None

    def to_legacy_format(self) -> ATSSResult:
        """
        Convert to legacy ATSSResult for backward compatibility.

        Returns:
            ATSSResult without enhanced fields
        """
        return ATSSResult(
            overall_score=self.overall_score,
            grade=self.grade,
            confidence=self.confidence,
            vulnerability_score=self.vulnerability_score,
            trust_boundary_score=self.trust_boundary_score,
            communication_score=self.communication_score,
            agent_risk_score=self.agent_risk_score,
            components=self.components,
            per_agent_scores=self.per_agent_scores,
            high_risk_agents=self.high_risk_agents,
            explanation=self.explanation,
            recommendations=self.recommendations,
            metadata=self.metadata,
        )


class EnhancedScoringEngine:
    """
    Enhanced ATSS scoring engine with severity-weighted scoring.

    Wraps the existing SecurityScoringEngine and adds:
    - Grade capping based on finding severity
    - Exponential penalties for findings
    - Confidence intervals for scores

    Ensures critical vulnerabilities always result in failing grades.
    """

    def __init__(
        self,
        weights: dict[str, float] | None = None,
        grade_cap_enforcer: GradeCapEnforcer | None = None,
        penalty_calculator: ExponentialPenaltyCalculator | None = None,
        confidence_calculator: ConfidenceIntervalCalculator | None = None,
    ):
        """
        Initialize the enhanced scoring engine.

        Args:
            weights: Custom component weights
            grade_cap_enforcer: Custom grade cap enforcer
            penalty_calculator: Custom penalty calculator
            confidence_calculator: Custom confidence calculator
        """
        # Initialize the base scoring engine
        self.base_engine = SecurityScoringEngine(weights=weights)
        self.weights = weights or SCORING_WEIGHTS

        # Initialize enhanced components
        self.cap_enforcer = grade_cap_enforcer or GradeCapEnforcer()
        self.penalty_calc = penalty_calculator or ExponentialPenaltyCalculator()
        self.confidence_calc = confidence_calculator or ConfidenceIntervalCalculator()

    def calculate_atss(
        self,
        scan_result: SecurityScanResult,
        graph: AgentGraph | None = None,
    ) -> EnhancedATSSResult:
        """
        Calculate the enhanced Agent Topology Security Score.

        Args:
            scan_result: Security scan results with findings and agents
            graph: Agent topology graph (built from agents if not provided)

        Returns:
            EnhancedATSSResult with complete score breakdown and severity weighting
        """
        # Get base result from existing engine
        base_result = self.base_engine.calculate_atss(scan_result, graph)

        # Calculate severity penalties
        penalty_breakdown = self.penalty_calc.calculate(
            scan_result.findings,
            base_score=100.0,
        )

        # Apply penalties to get adjusted score
        # The base engine already computes a score, but we want to apply
        # our exponential penalties for consistency with the PRD
        adjusted_score = penalty_breakdown.adjusted_base_score

        # Ensure score is within bounds
        adjusted_score = round(min(100.0, max(0.0, adjusted_score)), 2)

        # Get grade for adjusted score
        calculated_grade = self.base_engine.grade_converter.get_grade_letter(adjusted_score)

        # Apply grade capping based on finding severity
        grade_cap_result = self.cap_enforcer.evaluate(
            calculated_grade,
            scan_result.findings,
        )
        final_grade = grade_cap_result.capped_grade

        # Calculate confidence interval
        # Use the confidence from base result as coverage proxy
        coverage = base_result.confidence
        confidence_details = self.confidence_calc.calculate_full(
            adjusted_score,
            scan_result.findings,
            coverage,
        )

        # Build enhanced metadata
        enhanced_metadata = {
            **base_result.metadata,
            "severity_weighted": True,
            "penalty_total": penalty_breakdown.total_penalty,
            "grade_capped": grade_cap_result.is_capped,
        }

        # Update explanation if grade was capped
        explanation = base_result.explanation
        if grade_cap_result.is_capped:
            explanation = f"{explanation}\n\nNote: {grade_cap_result.cap_reason}"

        # Add recommendations about grade capping
        recommendations = list(base_result.recommendations)
        if grade_cap_result.is_capped and grade_cap_result.cap_reason:
            recommendations.insert(
                0,
                f"Address {grade_cap_result.capping_severity} severity findings to improve grade",
            )

        return EnhancedATSSResult(
            # Base ATSSResult fields
            overall_score=adjusted_score,
            grade=final_grade,
            confidence=confidence_details.confidence,
            vulnerability_score=base_result.vulnerability_score,
            trust_boundary_score=base_result.trust_boundary_score,
            communication_score=base_result.communication_score,
            agent_risk_score=base_result.agent_risk_score,
            components=base_result.components,
            per_agent_scores=base_result.per_agent_scores,
            high_risk_agents=base_result.high_risk_agents,
            explanation=explanation,
            recommendations=recommendations,
            metadata=enhanced_metadata,
            # Enhanced fields
            grade_capped_from=(
                grade_cap_result.original_grade if grade_cap_result.is_capped else None
            ),
            confidence_interval=(
                confidence_details.lower_bound,
                confidence_details.upper_bound,
            ),
            severity_penalties=penalty_breakdown.by_severity,
            is_grade_capped=grade_cap_result.is_capped,
            cap_reason=grade_cap_result.cap_reason,
            penalty_breakdown=penalty_breakdown,
            confidence_details=confidence_details,
            grade_cap_result=grade_cap_result,
        )

    def score_with_penalties_only(
        self,
        scan_result: SecurityScanResult,
    ) -> tuple[float, str, PenaltyBreakdown]:
        """
        Calculate score with penalties but without grade capping.

        Useful for understanding the penalty-adjusted score before capping.

        Args:
            scan_result: Security scan results

        Returns:
            Tuple of (score, grade, penalty_breakdown)
        """
        penalty_breakdown = self.penalty_calc.calculate(
            scan_result.findings,
            base_score=100.0,
        )
        score = penalty_breakdown.adjusted_base_score
        grade = self.base_engine.grade_converter.get_grade_letter(score)
        return (score, grade, penalty_breakdown)

    def get_grade_cap_for_findings(
        self,
        scan_result: SecurityScanResult,
    ) -> GradeCapResult:
        """
        Get the grade cap that would be applied based on findings.

        Args:
            scan_result: Security scan results

        Returns:
            GradeCapResult with cap information
        """
        # Get a baseline grade to evaluate capping
        _, grade, _ = self.score_with_penalties_only(scan_result)
        return self.cap_enforcer.evaluate(grade, scan_result.findings)


def calculate_enhanced_atss(
    scan_result: SecurityScanResult,
    graph: AgentGraph | None = None,
) -> EnhancedATSSResult:
    """
    Convenience function to calculate enhanced ATSS.

    Args:
        scan_result: Security scan results
        graph: Optional topology graph

    Returns:
        EnhancedATSSResult with severity-weighted scoring
    """
    engine = EnhancedScoringEngine()
    return engine.calculate_atss(scan_result, graph)
