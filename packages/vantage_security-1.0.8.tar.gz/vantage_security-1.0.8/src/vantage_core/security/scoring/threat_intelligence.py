"""
Threat intelligence integration for CVSS/EPSS/KEV scoring.

This module integrates external threat intelligence sources to provide
real-world risk assessment beyond basic severity scoring:

- CVSS 4.0: Base metrics for vulnerability impact
- EPSS: Exploit Prediction Scoring System (probability of exploitation)
- CISA KEV: Known Exploited Vulnerabilities catalog

Formula:
Risk Score = Impact(CVSS) × Likelihood(EPSS) × Threat_Multiplier(KEV) × Asset_Factor
"""

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

import httpx

logger = logging.getLogger(__name__)


class ThreatLevel(Enum):
    """Threat level classification."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class CVSSVector:
    """CVSS v4.0 vector components."""

    # Base Metrics
    attack_vector: str = "N"  # N, A, L, P
    attack_complexity: str = "L"  # L, H
    attack_requirements: str = "N"  # N, P
    privileges_required: str = "N"  # N, L, H
    user_interaction: str = "N"  # N, P, A

    # Impact Metrics
    confidentiality: str = "H"  # N, L, H
    integrity: str = "H"  # N, L, H
    availability: str = "H"  # N, L, H

    # Subsequent System Impact (optional)
    subsequent_confidentiality: str = "N"
    subsequent_integrity: str = "N"
    subsequent_availability: str = "N"

    def calculate_score(self) -> float:
        """
        Calculate CVSS 4.0 base score.

        This is a simplified implementation. Full CVSS 4.0 calculation
        is more complex with macro vectors.
        """
        # Attack vector weights
        av_weights = {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.2}
        ac_weights = {"L": 0.77, "H": 0.44}
        ar_weights = {"N": 1.0, "P": 0.9}
        pr_weights = {"N": 0.85, "L": 0.62, "H": 0.27}
        ui_weights = {"N": 0.85, "P": 0.62, "A": 0.27}

        # Impact weights
        impact_weights = {"N": 0.0, "L": 0.22, "H": 0.56}

        # Calculate exploitability
        exploitability = (
            8.22
            * av_weights.get(self.attack_vector, 0.85)
            * ac_weights.get(self.attack_complexity, 0.77)
            * ar_weights.get(self.attack_requirements, 1.0)
            * pr_weights.get(self.privileges_required, 0.85)
            * ui_weights.get(self.user_interaction, 0.85)
        )

        # Calculate impact
        isc_base = 1 - (
            (1 - impact_weights.get(self.confidentiality, 0.56))
            * (1 - impact_weights.get(self.integrity, 0.56))
            * (1 - impact_weights.get(self.availability, 0.56))
        )

        if isc_base <= 0:
            return 0.0

        # Simplified score calculation
        impact = 6.42 * isc_base
        base_score = min(10.0, exploitability + impact)

        return round(base_score, 1)

    def to_string(self) -> str:
        """Convert to CVSS vector string format."""
        return (
            f"CVSS:4.0/AV:{self.attack_vector}/AC:{self.attack_complexity}/"
            f"AT:{self.attack_requirements}/PR:{self.privileges_required}/"
            f"UI:{self.user_interaction}/VC:{self.confidentiality}/"
            f"VI:{self.integrity}/VA:{self.availability}"
        )


@dataclass
class EPSSData:
    """EPSS (Exploit Prediction Scoring System) data."""

    cve_id: str
    epss_score: float  # 0.0 to 1.0 probability
    percentile: float  # Percentile rank
    date: str  # Date of score

    @property
    def exploitation_likelihood(self) -> str:
        """Human-readable exploitation likelihood."""
        if self.epss_score >= 0.7:
            return "Very High"
        elif self.epss_score >= 0.4:
            return "High"
        elif self.epss_score >= 0.1:
            return "Medium"
        elif self.epss_score >= 0.01:
            return "Low"
        else:
            return "Very Low"


@dataclass
class KEVEntry:
    """CISA Known Exploited Vulnerability entry."""

    cve_id: str
    vendor_project: str
    product: str
    vulnerability_name: str
    date_added: str
    short_description: str
    required_action: str
    due_date: str
    known_ransomware_use: bool = False

    @property
    def is_actively_exploited(self) -> bool:
        """All KEV entries are actively exploited by definition."""
        return True


@dataclass
class ThreatIntelligenceResult:
    """Combined threat intelligence for a vulnerability."""

    cve_id: str | None
    cvss_score: float
    cvss_vector: CVSSVector | None
    epss_data: EPSSData | None
    kev_entry: KEVEntry | None

    # Calculated scores
    risk_score: float
    threat_level: ThreatLevel

    # Compliance flags
    requires_immediate_action: bool
    compliance_relevant: bool

    # Metadata
    last_updated: float
    sources: list[str] = field(default_factory=list)

    @property
    def is_in_kev(self) -> bool:
        return self.kev_entry is not None

    @property
    def exploitation_probability(self) -> float:
        if self.epss_data:
            return self.epss_data.epss_score
        return 0.0


class EPSSClient:
    """Client for FIRST.org EPSS API."""

    BASE_URL = "https://api.first.org/data/v1/epss"

    def __init__(self, timeout: float = 30.0):
        self.timeout = timeout
        self._cache: dict[str, tuple[EPSSData, float]] = {}
        self._cache_ttl = 86400  # 24 hours

    async def get_score(self, cve_id: str) -> EPSSData | None:
        """
        Get EPSS score for a CVE.

        Args:
            cve_id: CVE identifier (e.g., CVE-2021-44228)

        Returns:
            EPSSData or None if not found
        """
        # Check cache
        if cve_id in self._cache:
            data, timestamp = self._cache[cve_id]
            if time.time() - timestamp < self._cache_ttl:
                return data

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.BASE_URL}?cve={cve_id}",
                    timeout=self.timeout,
                )

            if response.status_code != 200:
                logger.warning(f"EPSS API returned {response.status_code}")
                return None

            result = response.json()
            if not result.get("data"):
                return None

            item = result["data"][0]
            epss_data = EPSSData(
                cve_id=item["cve"],
                epss_score=float(item["epss"]),
                percentile=float(item["percentile"]),
                date=item.get("date", ""),
            )

            # Cache result
            self._cache[cve_id] = (epss_data, time.time())

            return epss_data

        except Exception as e:
            logger.error(f"EPSS API error: {e}")
            return None

    async def get_scores_batch(
        self,
        cve_ids: list[str],
    ) -> dict[str, EPSSData]:
        """Get EPSS scores for multiple CVEs."""
        # EPSS API supports comma-separated CVEs
        cve_list = ",".join(cve_ids)

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.BASE_URL}?cve={cve_list}",
                    timeout=self.timeout,
                )

            if response.status_code != 200:
                return {}

            result = response.json()
            scores = {}

            for item in result.get("data", []):
                epss_data = EPSSData(
                    cve_id=item["cve"],
                    epss_score=float(item["epss"]),
                    percentile=float(item["percentile"]),
                    date=item.get("date", ""),
                )
                scores[item["cve"]] = epss_data
                self._cache[item["cve"]] = (epss_data, time.time())

            return scores

        except Exception as e:
            logger.error(f"EPSS batch API error: {e}")
            return {}


class KEVCatalog:
    """Client for CISA Known Exploited Vulnerabilities catalog."""

    CATALOG_URL = (
        "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
    )

    def __init__(self):
        self._catalog: dict[str, KEVEntry] = {}
        self._last_update: float = 0
        self._update_interval = 3600  # 1 hour

    async def refresh_catalog(self):
        """Download and parse the KEV catalog."""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    self.CATALOG_URL,
                    timeout=60.0,
                )

            if response.status_code != 200:
                logger.error(f"KEV catalog returned {response.status_code}")
                return

            data = response.json()

            for vuln in data.get("vulnerabilities", []):
                entry = KEVEntry(
                    cve_id=vuln["cveID"],
                    vendor_project=vuln.get("vendorProject", ""),
                    product=vuln.get("product", ""),
                    vulnerability_name=vuln.get("vulnerabilityName", ""),
                    date_added=vuln.get("dateAdded", ""),
                    short_description=vuln.get("shortDescription", ""),
                    required_action=vuln.get("requiredAction", ""),
                    due_date=vuln.get("dueDate", ""),
                    known_ransomware_use=vuln.get("knownRansomwareCampaignUse", "Unknown")
                    == "Known",
                )
                self._catalog[entry.cve_id] = entry

            self._last_update = time.time()
            logger.info(f"Loaded {len(self._catalog)} KEV entries")

        except Exception as e:
            logger.error(f"KEV catalog error: {e}")

    async def is_in_kev(self, cve_id: str) -> KEVEntry | None:
        """Check if CVE is in the KEV catalog."""
        # Refresh if needed
        if time.time() - self._last_update > self._update_interval:
            await self.refresh_catalog()

        return self._catalog.get(cve_id)

    def get_all_entries(self) -> list[KEVEntry]:
        """Get all KEV entries."""
        return list(self._catalog.values())


class ThreatIntelligenceEngine:
    """
    Main engine for threat intelligence integration.

    Combines CVSS, EPSS, and KEV data to calculate real-world risk scores.
    """

    # KEV multiplier - being in KEV significantly increases risk
    KEV_MULTIPLIER = 2.0

    # Ransomware multiplier
    RANSOMWARE_MULTIPLIER = 1.5

    # Asset criticality factors
    ASSET_FACTORS = {
        "crown_jewel": 1.5,
        "business_critical": 1.3,
        "production": 1.2,
        "development": 0.8,
        "test": 0.5,
    }

    def __init__(self):
        self.epss_client = EPSSClient()
        self.kev_catalog = KEVCatalog()

        # Default CVSS vectors for common vulnerability types
        self._default_vectors = self._build_default_vectors()

    def _build_default_vectors(self) -> dict[str, CVSSVector]:
        """Build default CVSS vectors for common vulnerability categories."""
        return {
            "code_injection": CVSSVector(
                attack_vector="N",
                attack_complexity="L",
                privileges_required="N",
                user_interaction="N",
                confidentiality="H",
                integrity="H",
                availability="H",
            ),
            "sql_injection": CVSSVector(
                attack_vector="N",
                attack_complexity="L",
                privileges_required="N",
                user_interaction="N",
                confidentiality="H",
                integrity="H",
                availability="L",
            ),
            "hardcoded_secret": CVSSVector(
                attack_vector="N",
                attack_complexity="L",
                privileges_required="N",
                user_interaction="N",
                confidentiality="H",
                integrity="L",
                availability="N",
            ),
            "privilege_escalation": CVSSVector(
                attack_vector="L",
                attack_complexity="L",
                privileges_required="L",
                user_interaction="N",
                confidentiality="H",
                integrity="H",
                availability="H",
            ),
            "xss": CVSSVector(
                attack_vector="N",
                attack_complexity="L",
                privileges_required="N",
                user_interaction="A",
                confidentiality="L",
                integrity="L",
                availability="N",
            ),
            "path_traversal": CVSSVector(
                attack_vector="N",
                attack_complexity="L",
                privileges_required="N",
                user_interaction="N",
                confidentiality="H",
                integrity="L",
                availability="N",
            ),
            "ssrf": CVSSVector(
                attack_vector="N",
                attack_complexity="L",
                privileges_required="N",
                user_interaction="N",
                confidentiality="L",
                integrity="L",
                availability="N",
            ),
            "default": CVSSVector(
                attack_vector="N",
                attack_complexity="L",
                privileges_required="N",
                user_interaction="N",
                confidentiality="L",
                integrity="L",
                availability="L",
            ),
        }

    async def analyze(
        self,
        cve_id: str | None = None,
        vulnerability_category: str = "default",
        asset_type: str = "production",
        custom_cvss: CVSSVector | None = None,
    ) -> ThreatIntelligenceResult:
        """
        Analyze threat intelligence for a vulnerability.

        Args:
            cve_id: CVE identifier if available
            vulnerability_category: Type of vulnerability
            asset_type: Asset criticality type
            custom_cvss: Custom CVSS vector

        Returns:
            ThreatIntelligenceResult with risk score
        """
        sources = []
        epss_data = None
        kev_entry = None

        # Get CVSS vector
        if custom_cvss:
            cvss_vector = custom_cvss
        else:
            cvss_vector = self._default_vectors.get(
                vulnerability_category, self._default_vectors["default"]
            )

        cvss_score = cvss_vector.calculate_score()
        sources.append("cvss_default")

        # Get EPSS data if CVE available
        if cve_id:
            epss_data = await self.epss_client.get_score(cve_id)
            if epss_data:
                sources.append("epss")

            kev_entry = await self.kev_catalog.is_in_kev(cve_id)
            if kev_entry:
                sources.append("kev")

        # Calculate risk score
        risk_score = self._calculate_risk_score(
            cvss_score=cvss_score,
            epss_data=epss_data,
            kev_entry=kev_entry,
            asset_type=asset_type,
        )

        # Determine threat level
        threat_level = self._classify_threat_level(risk_score)

        # Determine compliance relevance
        requires_immediate = (
            kev_entry is not None or (epss_data and epss_data.epss_score > 0.5) or risk_score >= 8.0
        )

        compliance_relevant = (
            cvss_score >= 7.0 or kev_entry is not None or (epss_data and epss_data.percentile > 0.9)
        )

        return ThreatIntelligenceResult(
            cve_id=cve_id,
            cvss_score=cvss_score,
            cvss_vector=cvss_vector,
            epss_data=epss_data,
            kev_entry=kev_entry,
            risk_score=risk_score,
            threat_level=threat_level,
            requires_immediate_action=requires_immediate,
            compliance_relevant=compliance_relevant,
            last_updated=time.time(),
            sources=sources,
        )

    def _calculate_risk_score(
        self,
        cvss_score: float,
        epss_data: EPSSData | None,
        kev_entry: KEVEntry | None,
        asset_type: str,
    ) -> float:
        """
        Calculate combined risk score.

        Formula:
        Risk = (CVSS * EPSS_weight) * KEV_multiplier * Asset_factor

        Where:
        - EPSS_weight = 0.5 + (0.5 * EPSS) for values 0-1
        - KEV_multiplier = 2.0 if in KEV, 1.0 otherwise
        - Asset_factor = based on asset criticality
        """
        # Base is CVSS score
        base_risk = cvss_score

        # Apply EPSS weighting
        if epss_data:
            # Higher EPSS means more likely to be exploited
            # Weight ranges from 0.5 (EPSS=0) to 1.0 (EPSS=1)
            epss_weight = 0.5 + (0.5 * epss_data.epss_score)
            base_risk *= epss_weight

        # Apply KEV multiplier
        if kev_entry:
            base_risk *= self.KEV_MULTIPLIER

            # Additional multiplier for ransomware
            if kev_entry.known_ransomware_use:
                base_risk *= self.RANSOMWARE_MULTIPLIER

        # Apply asset factor
        asset_factor = self.ASSET_FACTORS.get(asset_type, 1.0)
        base_risk *= asset_factor

        # Normalize to 0-10 scale
        return min(10.0, round(base_risk, 1))

    def _classify_threat_level(self, risk_score: float) -> ThreatLevel:
        """Classify threat level based on risk score."""
        if risk_score >= 9.0:
            return ThreatLevel.CRITICAL
        elif risk_score >= 7.0:
            return ThreatLevel.HIGH
        elif risk_score >= 4.0:
            return ThreatLevel.MEDIUM
        elif risk_score >= 1.0:
            return ThreatLevel.LOW
        else:
            return ThreatLevel.INFO

    async def analyze_batch(
        self,
        vulnerabilities: list[dict[str, Any]],
    ) -> list[ThreatIntelligenceResult]:
        """
        Analyze multiple vulnerabilities.

        Args:
            vulnerabilities: List of dicts with cve_id, category, asset_type

        Returns:
            List of ThreatIntelligenceResults
        """
        # Batch fetch EPSS scores
        cve_ids = [v.get("cve_id") for v in vulnerabilities if v.get("cve_id")]
        if cve_ids:
            await self.epss_client.get_scores_batch(cve_ids)

        # Analyze each vulnerability
        results = []
        for vuln in vulnerabilities:
            result = await self.analyze(
                cve_id=vuln.get("cve_id"),
                vulnerability_category=vuln.get("category", "default"),
                asset_type=vuln.get("asset_type", "production"),
            )
            results.append(result)

        return results

    def generate_compliance_report(
        self,
        results: list[ThreatIntelligenceResult],
        framework: str = "soc2",
    ) -> dict[str, Any]:
        """
        Generate compliance report for audit.

        Args:
            results: List of threat intelligence results
            framework: Compliance framework (soc2, iso27001, pci)

        Returns:
            Compliance report dictionary
        """
        kev_count = sum(1 for r in results if r.is_in_kev)
        critical_count = sum(1 for r in results if r.threat_level == ThreatLevel.CRITICAL)
        high_count = sum(1 for r in results if r.threat_level == ThreatLevel.HIGH)
        requires_action = sum(1 for r in results if r.requires_immediate_action)

        report = {
            "framework": framework,
            "generated_at": datetime.utcnow().isoformat(),
            "summary": {
                "total_vulnerabilities": len(results),
                "critical": critical_count,
                "high": high_count,
                "in_kev_catalog": kev_count,
                "requiring_immediate_action": requires_action,
            },
            "compliance_status": "fail" if kev_count > 0 else "pass",
            "findings": [],
        }

        for r in results:
            if r.compliance_relevant:
                finding = {
                    "cve_id": r.cve_id,
                    "risk_score": r.risk_score,
                    "threat_level": r.threat_level.value,
                    "in_kev": r.is_in_kev,
                    "epss_score": r.exploitation_probability,
                    "requires_immediate_action": r.requires_immediate_action,
                }
                report["findings"].append(finding)

        return report


def create_threat_intelligence_engine() -> ThreatIntelligenceEngine:
    """Create and initialize threat intelligence engine."""
    return ThreatIntelligenceEngine()
