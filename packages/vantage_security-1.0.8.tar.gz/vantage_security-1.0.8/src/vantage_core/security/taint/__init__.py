"""
Intra-Function Taint Analysis Module.

US-013: Variable Assignment Tracking
US-014: Function Call Propagation
US-015: Taint Source/Sink Definitions
US-016: Taint Path Reporting

This module provides intra-procedural taint analysis capabilities for
tracking data flow within Python functions. It identifies when tainted
data (from sources like user input) flows to sensitive sinks (like
code execution or SQL queries).

Example usage:
    from vantage_core.security.taint import analyze_taint

    code = '''
    def process_input():
        user_input = input()
        cmd = "ls " + user_input
        os.system(cmd)
    '''

    findings = analyze_taint(code, "example.py")
    for finding in findings:
        print(f"Taint flow: {finding.source.source_type} -> {finding.sink_type}")
        print(f"  Source: line {finding.source_line}")
        print(f"  Sink: line {finding.sink_line}")
"""

from vantage_core.security.taint.analyzer import (
    IntraProceduralTaintAnalyzer,
    TaintAnalysisConfig,
    TaintFinding,
    TaintPathNode,
    analyze_taint,
)
from vantage_core.security.taint.cfg import (
    CFG,
    BasicBlock,
    CFGBuilder,
    build_cfg,
)
from vantage_core.security.taint.integration import (
    analyze_code_for_taint,
    taint_finding_to_security_finding,
)
from vantage_core.security.taint.lattice import (
    TaintedValue,
    TaintEnv,
    TaintSource,
    TaintState,
    env_equal,
    join_envs,
)
from vantage_core.security.taint.sources import (
    DEFAULT_SANITIZERS,
    DEFAULT_SINKS,
    DEFAULT_SOURCES,
    SanitizerPattern,
    SinkCategory,
    SourceCategory,
    TaintConfiguration,
    TaintSinkPattern,
    TaintSourcePattern,
    get_default_configuration,
)

__all__ = [
    # Lattice
    "TaintState",
    "TaintSource",
    "TaintedValue",
    "TaintEnv",
    "join_envs",
    "env_equal",
    # CFG
    "BasicBlock",
    "CFG",
    "CFGBuilder",
    "build_cfg",
    # Sources
    "SourceCategory",
    "SinkCategory",
    "TaintSourcePattern",
    "TaintSinkPattern",
    "SanitizerPattern",
    "TaintConfiguration",
    "DEFAULT_SOURCES",
    "DEFAULT_SINKS",
    "DEFAULT_SANITIZERS",
    "get_default_configuration",
    # Analyzer
    "TaintPathNode",
    "TaintFinding",
    "TaintAnalysisConfig",
    "IntraProceduralTaintAnalyzer",
    "analyze_taint",
    # Integration
    "taint_finding_to_security_finding",
    "analyze_code_for_taint",
]
