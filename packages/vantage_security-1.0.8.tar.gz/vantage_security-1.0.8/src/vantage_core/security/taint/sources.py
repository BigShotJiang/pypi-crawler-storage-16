"""
Taint Source and Sink Definitions.

US-015: Taint Source/Sink Definitions
Configurable patterns for taint sources, sinks, and sanitizers.
"""

from dataclasses import dataclass, field
from enum import Enum


class SourceCategory(str, Enum):
    """Categories of taint sources."""

    USER_INPUT = "user_input"
    ENVIRONMENT = "environment"
    FILE_READ = "file_read"
    NETWORK = "network"
    DATABASE = "database"
    EXTERNAL_API = "external_api"


class SinkCategory(str, Enum):
    """Categories of sensitive sinks."""

    CODE_EXECUTION = "code_execution"
    COMMAND_INJECTION = "command_injection"
    SQL_INJECTION = "sql_injection"
    FILE_WRITE = "file_write"
    NETWORK_OUTPUT = "network_output"
    DESERIALIZATION = "deserialization"
    XPATH_INJECTION = "xpath_injection"
    LDAP_INJECTION = "ldap_injection"


@dataclass
class TaintSourcePattern:
    """Pattern for identifying taint sources."""

    pattern: str  # Function or method name
    category: SourceCategory
    description: str
    argument_index: int | None = None  # Which argument is tainted (None = return value)


@dataclass
class TaintSinkPattern:
    """Pattern for identifying taint sinks."""

    pattern: str  # Function or method name
    category: SinkCategory
    description: str
    vulnerable_args: list[int] = field(default_factory=lambda: [0])  # Which args are vulnerable


@dataclass
class SanitizerPattern:
    """Pattern for identifying sanitizers."""

    pattern: str  # Function or method name
    description: str
    sanitizes_categories: list[SinkCategory] = field(default_factory=list)  # Empty = all


# Default taint sources
DEFAULT_SOURCES: dict[str, str] = {
    # User input
    "input": "user_input",
    "raw_input": "user_input",
    # Flask/Web framework
    "get": "user_input",  # request.args.get
    "getlist": "user_input",
    # Environment variables
    "getenv": "environment",
    "environ": "environment",
    # File operations
    "read": "file_read",
    "readline": "file_read",
    "readlines": "file_read",
    # Network
    "recv": "network",
    "recvfrom": "network",
    "urlopen": "network",
    # Database
    "fetchone": "database",
    "fetchall": "database",
    "fetchmany": "database",
}


# Default taint sinks
DEFAULT_SINKS: dict[str, str] = {
    # Code execution
    "eval": "code_execution",
    "exec": "code_execution",
    "compile": "code_execution",
    "__import__": "code_execution",
    # Command injection
    "system": "command_injection",
    "popen": "command_injection",
    "call": "command_injection",
    "run": "command_injection",
    "Popen": "command_injection",
    "spawn": "command_injection",
    "execve": "command_injection",
    "execvp": "command_injection",
    # SQL injection
    "execute": "sql_injection",
    "executemany": "sql_injection",
    "executescript": "sql_injection",
    # File operations
    "write": "file_write",
    "writelines": "file_write",
    # Network output
    "send": "network_output",
    "sendall": "network_output",
    # Deserialization
    "loads": "deserialization",
    "load": "deserialization",
}


# Default sanitizers
DEFAULT_SANITIZERS: set[str] = {
    # HTML/XSS
    "escape",
    "html_escape",
    "escape_html",
    "quote",
    "urlencode",
    "htmlspecialchars",
    "markupsafe.escape",
    # SQL
    "quote_identifier",
    "escape_string",
    "parameterize",
    "sanitize_sql",
    # Command
    "shlex.quote",
    "quote",
    "escapeshellarg",
    # General
    "sanitize",
    "clean",
    "validate",
    "strip_tags",
    "bleach.clean",
    # Type conversion (implicit sanitizers)
    "int",
    "float",
    "bool",
}


# Extended source patterns with more context
SOURCE_PATTERNS: list[TaintSourcePattern] = [
    # Flask
    TaintSourcePattern(
        "request.args.get", SourceCategory.USER_INPUT, "Flask request query parameter"
    ),
    TaintSourcePattern("request.form.get", SourceCategory.USER_INPUT, "Flask request form field"),
    TaintSourcePattern("request.json", SourceCategory.USER_INPUT, "Flask request JSON body"),
    TaintSourcePattern("request.data", SourceCategory.USER_INPUT, "Flask raw request data"),
    TaintSourcePattern("request.cookies.get", SourceCategory.USER_INPUT, "Flask request cookie"),
    TaintSourcePattern("request.headers.get", SourceCategory.USER_INPUT, "Flask request header"),
    # Django
    TaintSourcePattern("request.GET.get", SourceCategory.USER_INPUT, "Django GET parameter"),
    TaintSourcePattern("request.POST.get", SourceCategory.USER_INPUT, "Django POST parameter"),
    TaintSourcePattern("request.body", SourceCategory.USER_INPUT, "Django raw request body"),
    # Environment
    TaintSourcePattern("os.getenv", SourceCategory.ENVIRONMENT, "Environment variable"),
    TaintSourcePattern("os.environ.get", SourceCategory.ENVIRONMENT, "Environment variable"),
    # File I/O
    TaintSourcePattern("open", SourceCategory.FILE_READ, "File open operation"),
    TaintSourcePattern("Path.read_text", SourceCategory.FILE_READ, "Pathlib file read"),
    TaintSourcePattern("Path.read_bytes", SourceCategory.FILE_READ, "Pathlib file read"),
    # Network
    TaintSourcePattern("requests.get", SourceCategory.NETWORK, "HTTP GET request"),
    TaintSourcePattern("requests.post", SourceCategory.NETWORK, "HTTP POST request"),
    TaintSourcePattern("urllib.request.urlopen", SourceCategory.NETWORK, "URL open"),
]


# Extended sink patterns with more context
SINK_PATTERNS: list[TaintSinkPattern] = [
    # Code execution
    TaintSinkPattern("eval", SinkCategory.CODE_EXECUTION, "Evaluates string as Python code", [0]),
    TaintSinkPattern("exec", SinkCategory.CODE_EXECUTION, "Executes string as Python code", [0]),
    TaintSinkPattern("compile", SinkCategory.CODE_EXECUTION, "Compiles string to code object", [0]),
    # Command injection
    TaintSinkPattern("os.system", SinkCategory.COMMAND_INJECTION, "Executes shell command", [0]),
    TaintSinkPattern(
        "os.popen", SinkCategory.COMMAND_INJECTION, "Opens pipe to shell command", [0]
    ),
    TaintSinkPattern("subprocess.call", SinkCategory.COMMAND_INJECTION, "Executes command", [0]),
    TaintSinkPattern("subprocess.run", SinkCategory.COMMAND_INJECTION, "Executes command", [0]),
    TaintSinkPattern("subprocess.Popen", SinkCategory.COMMAND_INJECTION, "Executes command", [0]),
    # SQL injection
    TaintSinkPattern("cursor.execute", SinkCategory.SQL_INJECTION, "Executes SQL query", [0]),
    TaintSinkPattern("connection.execute", SinkCategory.SQL_INJECTION, "Executes SQL query", [0]),
    TaintSinkPattern("db.execute", SinkCategory.SQL_INJECTION, "Executes SQL query", [0]),
    TaintSinkPattern("session.execute", SinkCategory.SQL_INJECTION, "Executes SQL query", [0]),
    # File write
    TaintSinkPattern("open", SinkCategory.FILE_WRITE, "Opens file for writing", [0]),
    TaintSinkPattern("Path.write_text", SinkCategory.FILE_WRITE, "Writes to file", [0]),
    # Deserialization
    TaintSinkPattern("pickle.loads", SinkCategory.DESERIALIZATION, "Deserializes pickle data", [0]),
    TaintSinkPattern("yaml.load", SinkCategory.DESERIALIZATION, "Deserializes YAML data", [0]),
    TaintSinkPattern("json.loads", SinkCategory.DESERIALIZATION, "Deserializes JSON data", [0]),
]


# Extended sanitizer patterns
SANITIZER_PATTERNS: list[SanitizerPattern] = [
    SanitizerPattern(
        "markupsafe.escape",
        "Escapes HTML special characters",
        [SinkCategory.CODE_EXECUTION],
    ),
    SanitizerPattern(
        "html.escape", "Escapes HTML special characters", [SinkCategory.CODE_EXECUTION]
    ),
    SanitizerPattern(
        "shlex.quote", "Quotes string for shell use", [SinkCategory.COMMAND_INJECTION]
    ),
    SanitizerPattern("bleach.clean", "Sanitizes HTML content", [SinkCategory.CODE_EXECUTION]),
    SanitizerPattern(
        "int",
        "Converts to integer",
        [SinkCategory.SQL_INJECTION, SinkCategory.COMMAND_INJECTION],
    ),
]


class TaintConfiguration:
    """
    Configuration for taint analysis sources, sinks, and sanitizers.

    Allows customization of what patterns are considered sources,
    sinks, and sanitizers.
    """

    def __init__(self) -> None:
        self.sources: dict[str, str] = DEFAULT_SOURCES.copy()
        self.sinks: dict[str, str] = DEFAULT_SINKS.copy()
        self.sanitizers: set[str] = DEFAULT_SANITIZERS.copy()
        self.source_patterns: list[TaintSourcePattern] = SOURCE_PATTERNS.copy()
        self.sink_patterns: list[TaintSinkPattern] = SINK_PATTERNS.copy()
        self.sanitizer_patterns: list[SanitizerPattern] = SANITIZER_PATTERNS.copy()

    def add_source(self, pattern: str, category: str) -> None:
        """Add a custom taint source."""
        self.sources[pattern] = category

    def add_sink(self, pattern: str, category: str) -> None:
        """Add a custom taint sink."""
        self.sinks[pattern] = category

    def add_sanitizer(self, pattern: str) -> None:
        """Add a custom sanitizer."""
        self.sanitizers.add(pattern)

    def remove_source(self, pattern: str) -> None:
        """Remove a taint source."""
        self.sources.pop(pattern, None)

    def remove_sink(self, pattern: str) -> None:
        """Remove a taint sink."""
        self.sinks.pop(pattern, None)

    def remove_sanitizer(self, pattern: str) -> None:
        """Remove a sanitizer."""
        self.sanitizers.discard(pattern)

    def is_source(self, name: str) -> bool:
        """Check if a function name is a taint source."""
        return name in self.sources

    def is_sink(self, name: str) -> bool:
        """Check if a function name is a taint sink."""
        return name in self.sinks

    def is_sanitizer(self, name: str) -> bool:
        """Check if a function name is a sanitizer."""
        return name in self.sanitizers

    def get_source_type(self, name: str) -> str | None:
        """Get the source type for a function name."""
        return self.sources.get(name)

    def get_sink_type(self, name: str) -> str | None:
        """Get the sink type for a function name."""
        return self.sinks.get(name)


def get_default_configuration() -> TaintConfiguration:
    """
    Get a default taint configuration.

    Returns:
        TaintConfiguration with default sources, sinks, and sanitizers
    """
    return TaintConfiguration()
