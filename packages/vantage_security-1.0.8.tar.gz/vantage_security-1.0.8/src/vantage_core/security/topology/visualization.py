"""
Topology Visualization Data Export.

US-112: Export topology as JSON for visualization in D3.js compatible format.

Provides various export formats for visualizing agent communication graphs,
trust zones, and security findings.
"""

import json
from dataclasses import dataclass, field
from typing import Any

from vantage_core.security.models import Severity, TrustLevel
from vantage_core.security.topology.features import EdgeFeatures, NodeFeatures
from vantage_core.security.topology.graph import AgentGraph, GraphEdge, GraphNode


@dataclass
class VisualizationNode:
    """Node data for visualization."""

    id: str
    label: str
    group: str  # For grouping/coloring
    size: float = 10.0
    color: str = "#666666"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class VisualizationEdge:
    """Edge data for visualization."""

    source: str
    target: str
    weight: float = 1.0
    color: str = "#999999"
    dashed: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class VisualizationZone:
    """Trust zone for visualization."""

    id: str
    name: str
    level: int
    color: str
    nodes: list[str] = field(default_factory=list)


class TopologyVisualizer:
    """
    Export topology graphs in visualization-friendly formats.

    Supports D3.js force-directed graphs, hierarchical layouts,
    and zone-based visualizations.
    """

    # Color schemes for trust levels
    TRUST_COLORS = {
        TrustLevel.EXTERNAL: "#ff6b6b",  # Red
        TrustLevel.USER: "#ffa94d",  # Orange
        TrustLevel.INTERNAL: "#69db7c",  # Green
        TrustLevel.PRIVILEGED: "#4dabf7",  # Blue
        TrustLevel.SYSTEM: "#9775fa",  # Purple
    }

    # Severity colors
    SEVERITY_COLORS = {
        Severity.CRITICAL: "#e03131",
        Severity.HIGH: "#f76707",
        Severity.MEDIUM: "#f59f00",
        Severity.LOW: "#37b24d",
        Severity.INFO: "#1c7ed6",
    }

    def __init__(self, graph: AgentGraph):
        """
        Initialize visualizer with a graph.

        Args:
            graph: AgentGraph to visualize
        """
        self.graph = graph

    def to_d3_force(
        self,
        node_features: dict[str, NodeFeatures] | None = None,
        edge_features: dict[str, EdgeFeatures] | None = None,
    ) -> dict[str, Any]:
        """
        Export graph in D3.js force-directed graph format.

        Args:
            node_features: Optional node features for enhanced visualization
            edge_features: Optional edge features for enhanced visualization

        Returns:
            Dictionary in D3.js format with nodes and links
        """
        nodes = []
        links = []

        # Process nodes
        for node in self.graph.nodes:
            viz_node = {
                "id": node.id,
                "label": node.name,
                "group": node.trust_level.name,
                "framework": node.framework,
                "trustLevel": node.trust_level.value,
                "color": self.TRUST_COLORS.get(node.trust_level, "#666666"),
                "size": self._calculate_node_size(node),
                "metadata": {
                    "toolCount": node.tool_count,
                    "hasCodeExecution": node.has_code_execution,
                    "hasExternalAccess": node.has_external_access,
                    "allowDelegation": node.allow_delegation,
                    "inDegree": node.in_degree,
                    "outDegree": node.out_degree,
                    "isEntryPoint": node.is_entry_point,
                    "isHighRisk": node.is_high_risk,
                },
            }

            # Add features if available
            if node_features and node.id in node_features:
                feat = node_features[node.id]
                viz_node["metadata"]["permissions"] = feat.permissions
                viz_node["metadata"]["trustConfidence"] = feat.trust_confidence

            nodes.append(viz_node)

        # Process edges
        for edge in self.graph.edges:
            viz_link = {
                "source": edge.source_id,
                "target": edge.target_id,
                "type": edge.communication_type.value,
                "weight": edge.weight,
                "color": self._get_edge_color(edge),
                "dashed": edge.crosses_trust_boundary,
                "metadata": {
                    "dataSensitivity": edge.data_sensitivity,
                    "trustDifferential": edge.trust_differential,
                    "crossesBoundary": edge.crosses_trust_boundary,
                    "bidirectional": edge.bidirectional,
                },
            }

            # Add features if available
            if edge_features:
                edge_key = f"{edge.source_id}->{edge.target_id}"
                if edge_key in edge_features:
                    feat = edge_features[edge_key]
                    viz_link["metadata"]["frequency"] = feat.frequency.value
                    viz_link["metadata"]["carriesUserInput"] = feat.carries_user_input

            links.append(viz_link)

        return {
            "nodes": nodes,
            "links": links,
            "metadata": {
                "nodeCount": len(nodes),
                "linkCount": len(links),
                "trustLevels": [level.name for level in TrustLevel],
                "colorScheme": {level.name: color for level, color in self.TRUST_COLORS.items()},
            },
        }

    def to_hierarchical(self) -> dict[str, Any]:
        """
        Export graph in hierarchical tree format.

        Organizes nodes by trust level in a tree structure.

        Returns:
            Dictionary in hierarchical format for tree visualizations
        """
        # Group nodes by trust level
        levels: dict[TrustLevel, list[GraphNode]] = {level: [] for level in TrustLevel}
        for node in self.graph.nodes:
            levels[node.trust_level].append(node)

        # Build hierarchical structure
        children = []
        for level in TrustLevel:
            level_nodes = levels[level]
            if level_nodes:
                level_children = []
                for node in level_nodes:
                    level_children.append(
                        {
                            "id": node.id,
                            "name": node.name,
                            "framework": node.framework,
                            "size": node.tool_count + 1,
                            "metadata": {
                                "hasCodeExecution": node.has_code_execution,
                                "allowDelegation": node.allow_delegation,
                            },
                        }
                    )

                children.append(
                    {
                        "id": f"trust_{level.name}",
                        "name": level.name,
                        "color": self.TRUST_COLORS[level],
                        "children": level_children,
                    }
                )

        return {
            "id": "root",
            "name": "Agent Topology",
            "children": children,
        }

    def to_zone_layout(self, zones: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        """
        Export graph with trust zone groupings.

        Args:
            zones: Optional pre-computed trust zones

        Returns:
            Dictionary with zone-based layout data
        """
        # Default zones based on trust levels
        if zones is None:
            zones = self._create_default_zones()

        # Create zone visualization data
        viz_zones = []
        for zone in zones:
            viz_zone = VisualizationZone(
                id=zone.get("id", f"zone_{len(viz_zones)}"),
                name=zone.get("name", "Unknown"),
                level=zone.get("level", 0),
                color=zone.get("color", "#cccccc"),
                nodes=zone.get("nodes", []),
            )
            viz_zones.append(
                {
                    "id": viz_zone.id,
                    "name": viz_zone.name,
                    "level": viz_zone.level,
                    "color": viz_zone.color,
                    "nodes": viz_zone.nodes,
                    "nodeCount": len(viz_zone.nodes),
                }
            )

        # Get nodes and edges
        d3_data = self.to_d3_force()

        return {
            "zones": viz_zones,
            "nodes": d3_data["nodes"],
            "links": d3_data["links"],
            "metadata": {
                "zoneCount": len(viz_zones),
                **d3_data["metadata"],
            },
        }

    def to_sankey(self) -> dict[str, Any]:
        """
        Export graph in Sankey diagram format.

        Shows data flow volumes between trust levels.

        Returns:
            Dictionary in Sankey format
        """
        # Aggregate flows between trust levels
        flows: dict[tuple[int, int], int] = {}

        for edge in self.graph.edges:
            source_node = self.graph.get_node(edge.source_id)
            target_node = self.graph.get_node(edge.target_id)

            if source_node and target_node:
                key = (source_node.trust_level.value, target_node.trust_level.value)
                flows[key] = flows.get(key, 0) + 1

        # Create Sankey nodes (trust levels)
        nodes = []
        for level in TrustLevel:
            nodes.append(
                {
                    "id": level.value,
                    "name": level.name,
                    "color": self.TRUST_COLORS[level],
                }
            )

        # Create Sankey links
        links = []
        for (source, target), value in flows.items():
            links.append(
                {
                    "source": source,
                    "target": target,
                    "value": value,
                }
            )

        return {
            "nodes": nodes,
            "links": links,
        }

    def to_adjacency_matrix(self) -> dict[str, Any]:
        """
        Export graph as adjacency matrix.

        Returns:
            Dictionary with matrix data for heatmap visualization
        """
        node_ids = [node.id for node in self.graph.nodes]
        n = len(node_ids)
        id_to_index = {id: i for i, id in enumerate(node_ids)}

        # Create matrix
        matrix = [[0] * n for _ in range(n)]

        for edge in self.graph.edges:
            source_idx = id_to_index.get(edge.source_id)
            target_idx = id_to_index.get(edge.target_id)

            if source_idx is not None and target_idx is not None:
                matrix[source_idx][target_idx] = 1
                if edge.bidirectional:
                    matrix[target_idx][source_idx] = 1

        return {
            "labels": node_ids,
            "matrix": matrix,
            "metadata": {
                "size": n,
                "density": sum(sum(row) for row in matrix) / (n * n) if n > 0 else 0,
            },
        }

    def to_json(self, format: str = "d3_force", **kwargs) -> str:
        """
        Export visualization data as JSON string.

        Args:
            format: Export format (d3_force, hierarchical, zone_layout, sankey, adjacency)
            **kwargs: Additional arguments for the specific format

        Returns:
            JSON string
        """
        if format == "d3_force":
            data = self.to_d3_force(**kwargs)
        elif format == "hierarchical":
            data = self.to_hierarchical()
        elif format == "zone_layout":
            data = self.to_zone_layout(**kwargs)
        elif format == "sankey":
            data = self.to_sankey()
        elif format == "adjacency":
            data = self.to_adjacency_matrix()
        else:
            raise ValueError(f"Unknown format: {format}")

        return json.dumps(data, indent=2)

    def _calculate_node_size(self, node: GraphNode) -> float:
        """Calculate visualization size for a node."""
        base_size = 10.0

        # Scale by tool count
        base_size += node.tool_count * 2

        # Larger for high-risk nodes
        if node.is_high_risk:
            base_size *= 1.5

        # Larger for entry points
        if node.is_entry_point:
            base_size *= 1.2

        return min(base_size, 50.0)

    def _get_edge_color(self, edge: GraphEdge) -> str:
        """Determine edge color based on risk."""
        if edge.is_high_risk:
            return "#e03131"  # Red for high risk
        elif edge.crosses_trust_boundary:
            return "#f59f00"  # Yellow for boundary crossing
        else:
            return "#adb5bd"  # Gray for normal

    def _create_default_zones(self) -> list[dict[str, Any]]:
        """Create default trust zones from graph."""
        zones = []

        for level in TrustLevel:
            nodes_in_level = [node.id for node in self.graph.nodes if node.trust_level == level]

            if nodes_in_level:
                zones.append(
                    {
                        "id": f"zone_{level.name.lower()}",
                        "name": f"{level.name} Zone",
                        "level": level.value,
                        "color": self.TRUST_COLORS[level],
                        "nodes": nodes_in_level,
                    }
                )

        return zones


def export_topology_for_d3(
    graph: AgentGraph,
    node_features: dict[str, NodeFeatures] | None = None,
    edge_features: dict[str, EdgeFeatures] | None = None,
) -> str:
    """
    Convenience function to export topology for D3.js visualization.

    Args:
        graph: AgentGraph to export
        node_features: Optional node features
        edge_features: Optional edge features

    Returns:
        JSON string in D3.js format
    """
    visualizer = TopologyVisualizer(graph)
    return visualizer.to_json("d3_force", node_features=node_features, edge_features=edge_features)


def export_topology_for_zones(graph: AgentGraph, zones: list[dict[str, Any]] | None = None) -> str:
    """
    Convenience function to export topology with zone layout.

    Args:
        graph: AgentGraph to export
        zones: Optional pre-computed zones

    Returns:
        JSON string with zone layout
    """
    visualizer = TopologyVisualizer(graph)
    return visualizer.to_json("zone_layout", zones=zones)
