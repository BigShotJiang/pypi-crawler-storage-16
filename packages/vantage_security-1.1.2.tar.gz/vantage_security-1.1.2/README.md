# 🛡️ Vantage Security

**The Enterprise Security Platform for Multi-Agent Systems.**

[![PyPI version](https://badge.fury.io/py/vantage-security.svg)](https://badge.fury.io/py/vantage-security)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Supported Frameworks](https://img.shields.io/badge/Frameworks-CrewAI%20%7C%20LangGraph%20%7C%20AutoGen%20%7C%20LlamaIndex-blue)](https://vantage.security)

**Vantage** is the first security platform purpose-built for the Agentic AI era. It solves the "Shadow AI" problem by discovering hidden agent workflows in your codebase and protecting them at runtime.

---

## 🚀 Why Vantage?

As developers rush to build autonomous agents, organizations are losing visibility into *what* is running and *what permissions* it has.

- **Discovery:** "Where are my agents defined?"
- **Topology:** "Which agent talks to which tool?"
- **Defense:** "Is this agent vulnerable to Prompt Injection?"

Vantage answers these questions instantly.

## ✨ Key Features

### 1. 🕵️‍♂️ Shadow AI Discovery (Static Analysis)
Automatically detect agent definitions, tools, and chains across your entire codebase without running the code.
*   **Multi-Framework:** Supports **LangGraph, CrewAI, AutoGen, LlamaIndex, LangChain**, and more.
*   **Deep Scanning:** Finds agents hidden in sub-classes, configuration files (YAML), and factory functions.
*   **Topology Mapping:** Visualizes how agents connect to tools and other agents.

### 2. 🛡️ Active Defense (Runtime Protection)
Zero-touch instrumentation to block attacks in real-time.
*   **Prompt Injection Firewall:** Blocks jailbreak attempts before they reach the LLM.
*   **PII Redaction:** Prevents sensitive data leakage.
*   **Audit Logging:** records every input/output for compliance.

### 3. 📊 Executive Reporting
Generates professional HTML risk reports for stakeholders.
*   **Inventory:** Complete list of all agents and tools.
*   **Risk Score:** Automated security grading (A-F).
*   **Compliance:** Checks against OWASP Top 10 for LLMs.

---

## 📦 Installation

```bash
pip install vantage-security
```

## ⚡ Quick Start

### 1. Scan your Codebase
Run a static analysis to find agents in your project:

```bash
# Scan current directory
vantage scan directory .

# Generate an HTML Executive Report
vantage scan directory ./my-agent-repo --html
```

### 2. Runtime Protection
Add **one line** to your entry point (e.g., `main.py`) to auto-instrument your agents:

```python
import vantage

# Automatically protects LangChain, CrewAI, and AutoGen
vantage.patch_all()
```

---

## 🛠️ Supported Frameworks

Vantage supports the widest range of agent frameworks in the industry:

| Framework | Discovery | Topology | Runtime Defense |
|-----------|:---------:|:--------:|:---------------:|
| **LangGraph** | ✅ | ✅ | ✅ |
| **CrewAI** | ✅ | ✅ | ✅ |
| **AutoGen** | ✅ | ✅ | ✅ |
| **LlamaIndex** | ✅ | ✅ | 🚧 |
| **LangChain** | ✅ | ✅ | ✅ |
| **PydanticAI**| ✅ | ✅ | 🚧 |
| **Semantic Kernel** | ✅ | 🚧 | 🚧 |

---

## 🔐 Enterprise Edition

The Open Source version provides powerful discovery and basic protection. **Vantage Enterprise** adds:

*   **Deep Resolution:** Traces variables across multiple files (Symbol Table Analysis) to find complex agent definitions.
*   **Centralized Dashboard:** Aggregate risks across all repositories.
*   **Policy Enforcement:** Block deployments that violate security rules.
*   **SSO & RBAC:** Enterprise-grade access control.

[Contact Sales](mailto:sales@vantage.security) for a demo.