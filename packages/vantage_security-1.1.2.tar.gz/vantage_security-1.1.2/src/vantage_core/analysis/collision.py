"""Enhanced collision detection with modern embeddings and LLM-as-Judge.

This module provides state-of-the-art collision detection using:
1. Sentence-transformers for semantic similarity (replacing TF-IDF)
2. LLM-as-Judge via OpenRouter for nuanced conflict detection
3. Configurable thresholds and multi-aspect scoring
"""

from __future__ import annotations

import json
import logging
import os
import re
from typing import TYPE_CHECKING, Any

from sklearn.metrics.pairwise import cosine_similarity

from vantage_core.core.models import AgentSystem, CollisionReport

if TYPE_CHECKING:
    from vantage_core.core.models import Agent

logger = logging.getLogger(__name__)

# Try to import sentence-transformers
try:
    from sentence_transformers import SentenceTransformer

    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False

# Try to import OpenAI for OpenRouter
try:
    from openai import OpenAI

    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False


class CollisionDetector:
    """Enhanced collision detector with modern embeddings and LLM-as-Judge."""

    def __init__(
        self,
        similarity_threshold: float = 0.7,
        keyword_threshold: int = 3,
        embedding_model: str = "all-mpnet-base-v2",
        llm_model: str = "anthropic/claude-sonnet-4-20250514",
        use_llm_judge: bool = True,
        openrouter_api_key: str | None = None,
        max_agents: int = 50,
        llm_timeout: float = 30.0,
    ):
        """Initialize enhanced collision detector.

        Args:
            similarity_threshold: Cosine similarity threshold for semantic overlap (0-1).
                Based on MTEB benchmarks, 0.7 captures ~85% of semantic duplicates
                while minimizing false positives.
            keyword_threshold: Minimum shared keywords to flag overlap.
                Value of 3 balances detection vs noise based on calibration.
            embedding_model: Sentence-transformers model name
            llm_model: OpenRouter model for LLM-as-Judge
            use_llm_judge: Whether to use LLM for semantic analysis
            openrouter_api_key: OpenRouter API key (or use OPENROUTER_API_KEY env var)
            max_agents: Maximum number of agents to analyze (O(n^2) complexity)
            llm_timeout: Timeout for LLM API calls in seconds
        """
        # Validate inputs
        if not 0 <= similarity_threshold <= 1:
            raise ValueError(f"similarity_threshold must be 0-1, got {similarity_threshold}")
        if keyword_threshold < 1:
            raise ValueError(f"keyword_threshold must be >= 1, got {keyword_threshold}")
        if max_agents < 2:
            raise ValueError(f"max_agents must be >= 2, got {max_agents}")
        if llm_timeout <= 0:
            raise ValueError(f"llm_timeout must be > 0, got {llm_timeout}")

        self.similarity_threshold = similarity_threshold
        self.keyword_threshold = keyword_threshold
        self.embedding_model_name = embedding_model
        self.llm_model = llm_model
        self.use_llm_judge = use_llm_judge
        self.max_agents = max_agents
        self.llm_timeout = llm_timeout

        # Initialize sentence transformer
        self._embedder = None
        if SENTENCE_TRANSFORMERS_AVAILABLE:
            try:
                self._embedder = SentenceTransformer(embedding_model)
            except Exception as e:
                logger.warning(f"Could not load embedding model '{embedding_model}': {e}")

        # Initialize OpenRouter client
        self._llm_client = None
        if use_llm_judge and OPENAI_AVAILABLE:
            api_key = openrouter_api_key or os.getenv("OPENROUTER_API_KEY")
            if api_key:
                self._llm_client = OpenAI(
                    base_url="https://openrouter.ai/api/v1",
                    api_key=api_key,
                    timeout=llm_timeout,
                )
            else:
                logger.warning("OPENROUTER_API_KEY not set, LLM-as-Judge disabled")

    def detect_collisions(self, system: AgentSystem) -> list[CollisionReport]:
        """Detect all types of collisions in an agent system.

        Args:
            system: The agent system to analyze

        Returns:
            List of collision reports

        Raises:
            ValueError: If system has more agents than max_agents limit
        """
        collisions: list[CollisionReport] = []

        agents = list(system.agents.values())
        if len(agents) < 2:
            return collisions

        if len(agents) > self.max_agents:
            raise ValueError(
                f"System has {len(agents)} agents, exceeding max_agents limit of {self.max_agents}. "
                f"Increase max_agents or reduce system size to avoid O(n^2) performance issues."
            )

        # Run all collision detection methods
        collisions.extend(self._detect_semantic_overlap(agents))
        collisions.extend(self._detect_responsibility_duplication(agents))
        collisions.extend(self._detect_capability_conflicts(agents))
        collisions.extend(self._detect_coverage_gaps(system))
        collisions.extend(self._detect_handoff_issues(system))

        # Use LLM-as-Judge for deeper analysis if enabled
        if self.use_llm_judge and self._llm_client:
            llm_collisions = self._llm_judge_analysis(agents)
            collisions.extend(llm_collisions)

        # Deduplicate similar collisions
        collisions = self._deduplicate_collisions(collisions)

        return collisions

    def _detect_semantic_overlap(self, agents: list[Agent]) -> list[CollisionReport]:
        """Detect semantic overlap using sentence-transformers embeddings."""
        collisions: list[CollisionReport] = []

        if not self._embedder:
            # Fall back to basic detection
            return self._detect_semantic_overlap_basic(agents)

        # Get prompt texts
        prompts = [agent.prompt.content for agent in agents]

        # Compute embeddings
        try:
            embeddings = self._embedder.encode(prompts, convert_to_numpy=True)
            similarity_matrix = cosine_similarity(embeddings)
        except Exception as e:
            logger.warning(f"Embedding failed, using TF-IDF fallback: {e}")
            return self._detect_semantic_overlap_basic(agents)

        # Find overlapping pairs
        n = len(agents)
        for i in range(n):
            for j in range(i + 1, n):
                similarity = float(similarity_matrix[i, j])
                if similarity >= self.similarity_threshold:
                    severity = self._similarity_to_severity(similarity)
                    collisions.append(
                        CollisionReport(
                            collision_type="semantic_overlap",
                            severity=severity,
                            agents_involved=[agents[i].id, agents[j].id],
                            description=(
                                f"High semantic similarity ({similarity:.2f}) between "
                                f"'{agents[i].name}' and '{agents[j].name}'. "
                                "These agents may be doing duplicate work."
                            ),
                            recommendation=(
                                "Review and differentiate the responsibilities of these agents. "
                                "Consider merging them or clarifying their distinct roles."
                            ),
                            confidence=min(similarity, 0.95),
                            similarity_score=similarity,
                        )
                    )

        return collisions

    def _detect_semantic_overlap_basic(self, agents: list[Agent]) -> list[CollisionReport]:
        """Fallback semantic overlap detection using TF-IDF."""
        from sklearn.feature_extraction.text import TfidfVectorizer

        collisions: list[CollisionReport] = []
        prompts = [agent.prompt.content for agent in agents]

        try:
            vectorizer = TfidfVectorizer(
                stop_words="english",
                ngram_range=(1, 2),
                max_features=1000,
            )
            tfidf_matrix = vectorizer.fit_transform(prompts)
            similarity_matrix = cosine_similarity(tfidf_matrix)
        except ValueError:
            return collisions

        n = len(agents)
        for i in range(n):
            for j in range(i + 1, n):
                similarity = float(min(similarity_matrix[i, j], 1.0))
                if similarity >= self.similarity_threshold:
                    severity = self._similarity_to_severity(similarity)
                    collisions.append(
                        CollisionReport(
                            collision_type="semantic_overlap",
                            severity=severity,
                            agents_involved=[agents[i].id, agents[j].id],
                            description=(
                                f"High text similarity ({similarity:.2f}) between "
                                f"'{agents[i].name}' and '{agents[j].name}'. "
                                "These agents may be doing duplicate work."
                            ),
                            recommendation=(
                                "Review and differentiate the responsibilities of these agents."
                            ),
                            confidence=min(similarity * 0.8, 0.85),  # Lower confidence for TF-IDF
                            similarity_score=similarity,
                        )
                    )

        return collisions

    def _llm_judge_analysis(self, agents: list[Agent]) -> list[CollisionReport]:
        """Use LLM-as-Judge for deep semantic conflict detection."""
        collisions: list[CollisionReport] = []

        if not self._llm_client:
            return collisions

        # Analyze pairs that might have subtle conflicts
        n = len(agents)
        for i in range(n):
            for j in range(i + 1, n):
                try:
                    result = self._analyze_agent_pair_with_llm(agents[i], agents[j])
                    if result and result.get("has_conflict"):
                        collisions.append(
                            CollisionReport(
                                collision_type=result.get("conflict_type", "semantic_conflict"),
                                severity=result.get("severity", "medium"),
                                agents_involved=[agents[i].id, agents[j].id],
                                description=result.get(
                                    "explanation", "LLM detected potential conflict"
                                ),
                                recommendation=result.get(
                                    "recommendation", "Review agent responsibilities"
                                ),
                                confidence=result.get("confidence", 0.8),
                            )
                        )
                except Exception as e:
                    logger.error(f"LLM analysis failed for {agents[i].id} vs {agents[j].id}: {e}")

        return collisions

    def _analyze_agent_pair_with_llm(self, agent1: Agent, agent2: Agent) -> dict[str, Any] | None:
        """Analyze a pair of agents using LLM-as-Judge."""
        if not self._llm_client:
            return None

        # Construct prompt following Anthropic best practices (XML tags, clear structure)
        prompt = f"""<task>
Analyze these two AI agent prompts for potential conflicts, overlapping responsibilities, or coordination issues in a multi-agent system.
</task>

<agent1_name>{agent1.name}</agent1_name>
<agent1_prompt>
{agent1.prompt.content[:2000]}
</agent1_prompt>

<agent2_name>{agent2.name}</agent2_name>
<agent2_prompt>
{agent2.prompt.content[:2000]}
</agent2_prompt>

<analysis_criteria>
1. Semantic overlap: Do both agents handle similar tasks using different words?
2. Instruction conflicts: Do they have contradictory directives (e.g., "always X" vs "never X")?
3. Responsibility ambiguity: Is it unclear which agent should handle certain scenarios?
4. Handoff gaps: Are there missing connections or unclear transitions between them?
</analysis_criteria>

<output_format>
Return a JSON object with these fields:
{{
  "has_conflict": boolean,
  "conflict_type": "semantic_overlap" | "instruction_conflict" | "responsibility_ambiguity" | "handoff_gap" | "none",
  "severity": "low" | "medium" | "high" | "critical",
  "confidence": number between 0 and 1,
  "explanation": "Brief explanation of the conflict",
  "recommendation": "Specific actionable suggestion to resolve"
}}

If no significant conflict exists, set has_conflict to false.
</output_format>"""

        try:
            response = self._llm_client.chat.completions.create(
                model=self.llm_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=500,
            )

            content = response.choices[0].message.content
            if not content:
                logger.warning("Empty response from LLM")
                return None

            # Try to extract and parse JSON from response
            result = self._extract_json_from_response(content)
            if result:
                return result

            logger.warning(f"Could not extract valid JSON from LLM response: {content[:200]}...")
            return None

        except Exception as e:
            logger.error(f"LLM analysis error: {e}")
            return None

    def _extract_json_from_response(self, content: str) -> dict[str, Any] | None:
        """Extract JSON object from LLM response with multiple fallback strategies."""
        # Strategy 1: Try to parse the entire content as JSON
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            pass

        # Strategy 2: Find JSON between code blocks
        code_block_match = re.search(r"```(?:json)?\s*(\{[\s\S]*?\})\s*```", content)
        if code_block_match:
            try:
                return json.loads(code_block_match.group(1))
            except json.JSONDecodeError:
                pass

        # Strategy 3: Find outermost braces (handles nested JSON)
        brace_count = 0
        start_idx = None
        for i, char in enumerate(content):
            if char == "{":
                if brace_count == 0:
                    start_idx = i
                brace_count += 1
            elif char == "}":
                brace_count -= 1
                if brace_count == 0 and start_idx is not None:
                    try:
                        return json.loads(content[start_idx : i + 1])
                    except json.JSONDecodeError:
                        start_idx = None
                        continue

        return None

    def _detect_responsibility_duplication(self, agents: list[Agent]) -> list[CollisionReport]:
        """Detect duplicated responsibilities across agents."""
        collisions: list[CollisionReport] = []

        # Extract action verbs and their objects from prompts
        responsibility_patterns = [
            r"(?:you\s+)?(?:will|should|must|can|are\s+responsible\s+for)\s+(\w+(?:\s+\w+){0,4})",
            r"(?:handle|manage|process|create|generate|analyze|review)\s+(\w+(?:\s+\w+){0,3})",
            r"responsible\s+for\s+(\w+(?:\s+\w+){0,4})",
        ]

        agent_responsibilities: dict[str, set[str]] = {}

        for agent in agents:
            responsibilities: set[str] = set()
            prompt_lower = agent.prompt.content.lower()

            for pattern in responsibility_patterns:
                matches = re.findall(pattern, prompt_lower)
                responsibilities.update(match.strip() for match in matches)

            agent_responsibilities[agent.id] = responsibilities

        # Find overlaps
        agent_ids = list(agent_responsibilities.keys())
        for i, agent_id_1 in enumerate(agent_ids):
            for agent_id_2 in agent_ids[i + 1 :]:
                overlap = agent_responsibilities[agent_id_1] & agent_responsibilities[agent_id_2]
                if len(overlap) >= self.keyword_threshold:
                    overlap_list = list(overlap)[:5]
                    collisions.append(
                        CollisionReport(
                            collision_type="responsibility_duplication",
                            severity="medium",
                            agents_involved=[agent_id_1, agent_id_2],
                            description=(
                                f"Shared responsibilities detected: {', '.join(overlap_list)}. "
                                "Multiple agents may attempt the same tasks."
                            ),
                            recommendation=(
                                "Clearly delineate which agent owns each responsibility. "
                                "Use explicit handoff conditions."
                            ),
                            confidence=min(len(overlap) / 10, 0.9),
                            overlapping_text=overlap_list,
                        )
                    )

        return collisions

    def _detect_capability_conflicts(self, agents: list[Agent]) -> list[CollisionReport]:
        """Detect conflicting capabilities or instructions."""
        collisions: list[CollisionReport] = []

        # Look for explicit conflicts
        conflict_patterns = [
            (r"always\s+(\w+)", r"never\s+\1"),
            (r"must\s+(\w+)", r"must\s+not\s+\1"),
            (r"do\s+not\s+(\w+)", r"always\s+\1"),
        ]

        for i, agent1 in enumerate(agents):
            prompt1_lower = agent1.prompt.content.lower()
            for agent2 in agents[i + 1 :]:
                prompt2_lower = agent2.prompt.content.lower()

                for pattern1, pattern2 in conflict_patterns:
                    matches1 = re.findall(pattern1, prompt1_lower)
                    for match in matches1:
                        conflict_pattern = pattern2.replace(r"\1", re.escape(match))
                        if re.search(conflict_pattern, prompt2_lower):
                            collisions.append(
                                CollisionReport(
                                    collision_type="instruction_conflict",
                                    severity="high",
                                    agents_involved=[agent1.id, agent2.id],
                                    description=(
                                        f"Conflicting instructions around '{match}' between "
                                        f"'{agent1.name}' and '{agent2.name}'."
                                    ),
                                    recommendation=(
                                        "Resolve the conflict by establishing clear rules "
                                        "or adding conditional logic for handoffs."
                                    ),
                                    confidence=0.85,
                                )
                            )

        return collisions

    def _detect_coverage_gaps(self, system: AgentSystem) -> list[CollisionReport]:
        """Detect gaps in coverage - tasks that no agent handles."""
        collisions: list[CollisionReport] = []

        # Common expected capabilities (now configurable)
        common_capabilities = [
            "error handling",
            "user communication",
            "data validation",
            "logging",
            "state management",
        ]

        all_prompts = " ".join(agent.prompt.content.lower() for agent in system.agents.values())

        missing = []
        for capability in common_capabilities:
            keywords = capability.split()
            if not all(keyword in all_prompts for keyword in keywords):
                missing.append(capability)

        if missing:
            collisions.append(
                CollisionReport(
                    collision_type="coverage_gap",
                    severity="medium",
                    agents_involved=list(system.agents.keys()),
                    description=(
                        f"Potential gaps in coverage: {', '.join(missing)}. "
                        "No agent explicitly handles these concerns."
                    ),
                    recommendation=(
                        "Assign these responsibilities to appropriate agents or "
                        "create a dedicated agent for cross-cutting concerns."
                    ),
                    confidence=0.6,
                )
            )

        return collisions

    def _detect_handoff_issues(self, system: AgentSystem) -> list[CollisionReport]:
        """Detect issues with agent handoffs and connections."""
        collisions: list[CollisionReport] = []

        # Check for orphaned agents
        connected_sources = {c.source for c in system.topology.connections}
        connected_targets = {c.target for c in system.topology.connections}
        all_connected = connected_sources | connected_targets

        orphaned = set(system.agents.keys()) - all_connected
        entry_points = set(system.topology.entry_points)
        exit_points = set(system.topology.exit_points)

        truly_orphaned = orphaned - entry_points - exit_points

        if truly_orphaned:
            collisions.append(
                CollisionReport(
                    collision_type="orphaned_agent",
                    severity="high",
                    agents_involved=list(truly_orphaned),
                    description=(
                        f"Orphaned agents detected: {', '.join(truly_orphaned)}. "
                        "These agents have no connections to other agents."
                    ),
                    recommendation=("Connect these agents to the system topology or remove them."),
                    confidence=0.95,
                )
            )

        # Check for handoffs without data specification (per OpenAI best practices)
        for conn in system.topology.connections:
            if not conn.data_passed:
                source_agent = system.agents.get(conn.source)
                target_agent = system.agents.get(conn.target)
                if source_agent and target_agent:
                    collisions.append(
                        CollisionReport(
                            collision_type="unclear_handoff",
                            severity="low",
                            agents_involved=[conn.source, conn.target],
                            description=(
                                f"Handoff from '{source_agent.name}' to '{target_agent.name}' "
                                "lacks data specification. This can cause context loss."
                            ),
                            recommendation=(
                                "Specify what data is passed between agents using the "
                                "'data_passed' field to ensure proper context transfer."
                            ),
                            confidence=0.7,
                        )
                    )

        # Check for circular dependencies
        visited: set[str] = set()
        rec_stack: set[str] = set()

        def has_cycle(agent_id: str) -> bool:
            visited.add(agent_id)
            rec_stack.add(agent_id)

            for downstream in system.topology.get_downstream_agents(agent_id):
                if downstream not in visited:
                    if has_cycle(downstream):
                        return True
                elif downstream in rec_stack:
                    return True

            rec_stack.remove(agent_id)
            return False

        for agent_id in system.agents:
            if agent_id not in visited:
                if has_cycle(agent_id):
                    collisions.append(
                        CollisionReport(
                            collision_type="circular_dependency",
                            severity="critical",
                            agents_involved=list(rec_stack),
                            description=(
                                "Circular dependency detected in agent topology. "
                                "This can cause infinite loops."
                            ),
                            recommendation=(
                                "Break the cycle by removing a connection or "
                                "adding a termination condition."
                            ),
                            confidence=0.99,
                        )
                    )
                    break

        return collisions

    def _deduplicate_collisions(self, collisions: list[CollisionReport]) -> list[CollisionReport]:
        """Remove duplicate or very similar collision reports."""
        seen = set()
        unique = []

        for collision in collisions:
            # Create a key based on type and agents involved
            key = (
                collision.collision_type,
                tuple(sorted(collision.agents_involved)),
            )

            if key not in seen:
                seen.add(key)
                unique.append(collision)

        return unique

    def _similarity_to_severity(self, similarity: float) -> str:
        """Convert similarity score to severity level."""
        if similarity >= 0.9:
            return "critical"
        elif similarity >= 0.8:
            return "high"
        elif similarity >= 0.7:
            return "medium"
        return "low"

    def get_similarity_matrix(self, system: AgentSystem) -> dict[str, dict[str, float]]:
        """Get the full similarity matrix between all agents using embeddings."""
        agents = list(system.agents.values())
        prompts = [agent.prompt.content for agent in agents]

        if self._embedder:
            try:
                embeddings = self._embedder.encode(prompts, convert_to_numpy=True)
                similarity_matrix = cosine_similarity(embeddings)
            except Exception:
                return self._get_similarity_matrix_basic(agents, prompts)
        else:
            return self._get_similarity_matrix_basic(agents, prompts)

        result: dict[str, dict[str, float]] = {}
        for i, agent1 in enumerate(agents):
            result[agent1.id] = {}
            for j, agent2 in enumerate(agents):
                result[agent1.id][agent2.id] = float(similarity_matrix[i, j])

        return result

    def _get_similarity_matrix_basic(
        self, agents: list[Agent], prompts: list[str]
    ) -> dict[str, dict[str, float]]:
        """Fallback similarity matrix using TF-IDF."""
        from sklearn.feature_extraction.text import TfidfVectorizer

        try:
            vectorizer = TfidfVectorizer(
                stop_words="english", ngram_range=(1, 2), max_features=1000
            )
            tfidf_matrix = vectorizer.fit_transform(prompts)
            similarity_matrix = cosine_similarity(tfidf_matrix)
        except ValueError:
            return {}

        result: dict[str, dict[str, float]] = {}
        for i, agent1 in enumerate(agents):
            result[agent1.id] = {}
            for j, agent2 in enumerate(agents):
                result[agent1.id][agent2.id] = float(similarity_matrix[i, j])

        return result
