"""Benchmark suite for Vantage analysis validation.

Provides automated benchmarking with:
- Ground truth dataset evaluation
- Baseline comparisons
- Statistical significance testing
- Results tracking
"""

from vantage_core.benchmark.baselines import RandomBaseline, RuleBasedBaseline
from vantage_core.benchmark.results import BenchmarkResults, ComparisonReport
from vantage_core.benchmark.runner import BenchmarkRunner

__all__ = [
    "BenchmarkRunner",
    "BenchmarkResults",
    "ComparisonReport",
    "RuleBasedBaseline",
    "RandomBaseline",
]
