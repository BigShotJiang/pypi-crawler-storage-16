"""
Auto-Instrumentation for AI Agent Frameworks.

This module provides runtime "monkey patching" capabilities to automatically
wrap agent execution methods with security protection (Active Defense).

Supported Frameworks:
- CrewAI (Agent.execute_task)
- LangChain (AgentExecutor._call)
- AutoGen (ConversableAgent.generate_reply)
"""

import importlib
import logging
import sys
import time

from vantage_core.instrumentation.hooks import ImportInterceptor
from vantage_core.protection.active_defense import (
    SecurityConfig,
    SecurityDecorator,
    SecurityViolationError,
)
from vantage_core.protection.counter_measures import CounterMeasure
from vantage_core.protection.dev_logger import DevLogger

logger = logging.getLogger(__name__)


class AutoInstrumentor:
    """Manager for applying runtime security patches."""

    def __init__(self, config: SecurityConfig = None):
        self.config = config or SecurityConfig()
        self.patched = set()
        self.interceptor = ImportInterceptor(self)
        self.counter_measure = CounterMeasure()

    def instrument_all(self):
        """Attempt to instrument all supported frameworks."""
        # 1. Patch anything already loaded
        self.instrument_crewai()
        self.instrument_langchain()
        self.instrument_autogen()

        # 2. Install hook to catch future imports
        self.interceptor.install()
        logger.debug("Installed import interceptor for future module loads")

    def instrument_crewai(self):
        """Patch CrewAI Agent execution."""
        if "crewai" in self.patched:
            return

        try:
            # Check if crewai is installed/imported
            if "crewai" not in sys.modules:
                try:
                    importlib.import_module("crewai")
                except ImportError:
                    return

            from crewai import Agent

            # Resilience: Check if method exists (API Drift protection)
            target_method = None
            for method_name in ["execute_task", "run", "execute"]:
                if hasattr(Agent, method_name):
                    target_method = method_name
                    break

            if not target_method:
                logger.warning(
                    "Vantage: Could not find CrewAI execution method. Skipping instrumentation."
                )
                return

            # The target method to wrap
            original_execute = getattr(Agent, target_method)

            # Create the protected wrapper manually to handle Task objects
            # We instantiate the decorator class to access its check logic
            security = SecurityDecorator(self.config)

            # Capture reference to counter measure for the closure
            counter_measure = self.counter_measure

            def protected_execute(self, task, *args, **kwargs):
                # CrewAI tasks can be strings or Task objects
                # We force conversion to string for scanning
                input_str = str(task)
                start_time = time.time()

                try:
                    # Perform security check with logging
                    result = security._check_input(input_str)
                    duration = (time.time() - start_time) * 1000
                    DevLogger.log_check(input_str, result, duration)

                except SecurityViolationError:
                    # BLOCK Event
                    # 1. Log the block
                    duration = (time.time() - start_time) * 1000
                    from vantage_core.protection.detector_engine import DetectionResult

                    block_result = DetectionResult(
                        True, 1.0, {"action": "block", "reason": "Policy Violation"}
                    )
                    DevLogger.log_check(input_str, block_result, duration)

                    # 2. Apply Timing Defense (slow down the error)
                    counter_measure.apply_constant_time(start_time)

                    raise

                # Call original method
                result_output = original_execute(self, task, *args, **kwargs)

                # Apply Watermark (Leak Attribution)
                if isinstance(result_output, str):
                    # Use agent role or class name as ID
                    agent_id = getattr(self, "role", "CrewAIAgent")
                    result_output = counter_measure.watermark_text(result_output, agent_id)

                return result_output

            # Apply the patch
            setattr(Agent, target_method, protected_execute)
            self.patched.add("crewai")
            logger.info(f"Successfully instrumented CrewAI Agent.{target_method}")

        except (ImportError, AttributeError, Exception) as e:
            logger.warning(f"Vantage: Failed to instrument CrewAI: {e}")

        except (ImportError, AttributeError) as e:
            logger.debug(f"Could not instrument CrewAI: {e}")

    def instrument_langchain(self):
        """Patch LangChain AgentExecutor."""
        if "langchain" in self.patched:
            return

        try:
            if "langchain" not in sys.modules:
                try:
                    importlib.import_module("langchain.agents")
                except ImportError:
                    return

            from langchain.agents import AgentExecutor

            original_call = AgentExecutor._call

            # Create wrapper
            security = SecurityDecorator(self.config)
            counter_measure = self.counter_measure

            def protected_call(self, inputs, run_manager=None, *args, **kwargs):
                # inputs is usually a dict, extract text
                input_str = str(inputs)
                start_time = time.time()

                try:
                    # Security Check
                    result = security._check_input(input_str)
                    duration = (time.time() - start_time) * 1000
                    DevLogger.log_check(input_str, result, duration)

                except SecurityViolationError:
                    # Blocked
                    duration = (time.time() - start_time) * 1000
                    from vantage_core.protection.detector_engine import DetectionResult

                    block_result = DetectionResult(
                        True, 1.0, {"action": "block", "reason": "Policy Violation"}
                    )
                    DevLogger.log_check(input_str, block_result, duration)

                    counter_measure.apply_constant_time(start_time)
                    raise

                # Call Original
                result_output = original_call(self, inputs, run_manager, *args, **kwargs)

                # Watermark (LangChain returns dict)
                if isinstance(result_output, dict) and "output" in result_output:
                    text_out = result_output["output"]
                    if isinstance(text_out, str):
                        agent_id = "LangChainAgent"
                        result_output["output"] = counter_measure.watermark_text(text_out, agent_id)

                return result_output

            AgentExecutor._call = protected_call
            self.patched.add("langchain")
            logger.info("Successfully instrumented LangChain AgentExecutor")

        except (ImportError, AttributeError) as e:
            logger.debug(f"Could not instrument LangChain: {e}")

    def instrument_autogen(self):
        """Patch AutoGen ConversableAgent."""
        if "autogen" in self.patched:
            return

        try:
            if "autogen" not in sys.modules:
                try:
                    importlib.import_module("autogen")
                except ImportError:
                    return

            from autogen import ConversableAgent

            original_reply = ConversableAgent.generate_reply

            # Create wrapper
            security = SecurityDecorator(self.config)
            counter_measure = self.counter_measure

            def protected_reply(self, messages=None, sender=None, **kwargs):
                # Extract input content
                input_str = ""
                if messages and isinstance(messages, list) and len(messages) > 0:
                    last_msg = messages[-1]
                    if isinstance(last_msg, dict):
                        input_str = last_msg.get("content", "")
                    else:
                        input_str = str(last_msg)

                start_time = time.time()

                if input_str:
                    try:
                        # Security Check
                        result = security._check_input(input_str)
                        duration = (time.time() - start_time) * 1000
                        DevLogger.log_check(input_str, result, duration)

                    except SecurityViolationError:
                        # Blocked
                        duration = (time.time() - start_time) * 1000
                        from vantage_core.protection.detector_engine import (
                            DetectionResult,
                        )

                        block_result = DetectionResult(
                            True, 1.0, {"action": "block", "reason": "Policy Violation"}
                        )
                        DevLogger.log_check(input_str, block_result, duration)

                        counter_measure.apply_constant_time(start_time)
                        # AutoGen handles exceptions gracefully usually, but we want to hard block
                        raise

                # Call Original
                reply = original_reply(self, messages=messages, sender=sender, **kwargs)

                # Watermark (Reply is str or dict or None)
                agent_id = getattr(self, "name", "AutoGenAgent")

                if isinstance(reply, str):
                    return counter_measure.watermark_text(reply, agent_id)
                elif isinstance(reply, dict) and "content" in reply:
                    content = reply["content"]
                    if isinstance(content, str):
                        reply["content"] = counter_measure.watermark_text(content, agent_id)

                return reply

            ConversableAgent.generate_reply = protected_reply
            self.patched.add("autogen")
            logger.info("Successfully instrumented AutoGen ConversableAgent")

        except (ImportError, AttributeError) as e:
            logger.debug(f"Could not instrument AutoGen: {e}")


# Global singleton
_instrumentor = None


def reset_instrumentor():
    """Reset the global instrumentor (useful for testing)."""
    global _instrumentor
    if _instrumentor and _instrumentor.interceptor:
        _instrumentor.interceptor.uninstall()
    _instrumentor = None


def patch_all(config: SecurityConfig = None):
    """Global entry point to enable auto-protection."""
    global _instrumentor
    if not _instrumentor:
        _instrumentor = AutoInstrumentor(config)
    elif config:
        # Update existing config in-place so decorators see the change
        if _instrumentor.config:
            _instrumentor.config.block_injection = config.block_injection
            _instrumentor.config.block_pii = config.block_pii
            _instrumentor.config.threshold = config.threshold
            _instrumentor.config.action = config.action

    _instrumentor.instrument_all()
