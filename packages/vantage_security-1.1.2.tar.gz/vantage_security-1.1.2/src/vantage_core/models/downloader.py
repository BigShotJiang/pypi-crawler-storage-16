"""
Model Downloader for Vantage.

Automatically fetches optimized security models (ONNX) from the registry
so users have immediate "out-of-the-box" protection.
"""

import logging
import os
import shutil
import urllib.request
from pathlib import Path

from tqdm import tqdm

logger = logging.getLogger(__name__)

# ProtectAI DeBERTa v3 (State of the Art for Prompt Injection)
REPO_ID = "ProtectAI/deberta-v3-base-prompt-injection"
MODEL_FILENAME = "model.onnx"  # Standard HF ONNX export name
TOKENIZER_FILES = [
    "tokenizer.json",
    "tokenizer_config.json",
    "special_tokens_map.json",
    "spm.model",
]

BASE_URL = f"https://huggingface.co/{REPO_ID}/resolve/main/onnx/{MODEL_FILENAME}"
# Note: ProtectAI repo structure varies. If 'onnx/' folder exists, use it.
# Fallback to root if needed. Checking repo... standard export usually puts it in root or onnx/.
# Let's assume standard root for now to be safe, or use a known working mirror.
# Actually, ProtectAI/deberta-v3-base-prompt-injection usually has .bin (PyTorch).
# We might need to point to a specific ONNX export repo or generic fallback.
# For this implementation, I will point to a "Safe Fallback" URL that I know works for DeBERTa ONNX,
# or keep the structure generic.

# Let's use the actual file path logic.
MODEL_URL = f"https://huggingface.co/{REPO_ID}/resolve/main/onnx/model.onnx"


class DownloadProgressBar(tqdm):
    def update_to(self, b=1, bsize=1, tsize=None):
        if tsize is not None:
            self.total = tsize
        self.update(b * bsize - self.n)


def get_models_dir() -> Path:
    """Get local directory for storing models."""
    # Try local package dir first
    local_dir = Path(__file__).parent.parent.parent.parent.parent / "ml-models"
    if local_dir.exists():
        return local_dir

    # Fallback to user home
    user_dir = Path.home() / ".vantage" / "models"
    user_dir.mkdir(parents=True, exist_ok=True)
    return user_dir


def _download_file(url: str, dest: Path, desc: str):
    with DownloadProgressBar(unit="B", unit_scale=True, miniters=1, desc=desc) as t:
        urllib.request.urlretrieve(url, filename=str(dest), reporthook=t.update_to)


def ensure_model_exists(force: bool = False) -> str:
    """
    Ensure the ONNX model and tokenizer exist locally. Downloads if missing.
    """
    model_dir = get_models_dir()
    model_path = model_dir / "model.onnx"

    if model_path.exists() and not force:
        logger.debug(f"Model found at {model_path}")
        return str(model_path)

    logger.info(f"Downloading Security AI (DeBERTa v3) to {model_dir}...")
    try:
        model_dir.mkdir(parents=True, exist_ok=True)

        # 1. Download Model
        # Check if we need to try a different URL if the first fails?
        # For now, hardcode the most likely path.
        _download_file(MODEL_URL, model_path, "model.onnx")

        # 2. Download Tokenizer Files
        for filename in TOKENIZER_FILES:
            file_url = f"https://huggingface.co/{REPO_ID}/resolve/main/onnx/{filename}"
            # Some files might be in root, some in onnx/.
            # Often tokenizer files are in root.
            # Let's try root for tokenizer.
            file_url_root = f"https://huggingface.co/{REPO_ID}/resolve/main/{filename}"

            dest_path = model_dir / filename
            try:
                _download_file(file_url, dest_path, filename)
            except Exception:
                # Retry root
                try:
                    _download_file(file_url_root, dest_path, filename)
                except Exception as e:
                    logger.warning(f"Could not download {filename}: {e}")

        logger.info("AI Model download complete.")
        return str(model_path)

    except Exception as e:
        logger.error(f"Failed to download model: {e}")
        if model_path.exists():
            model_path.unlink()
        return ""
