"""Scanner for DSPy framework.

Detects agents from DSPy including Module subclasses, signatures, and common patterns.
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import Any

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult
from vantage_core.scanners.mixins import ASTExtractionMixin

logger = logging.getLogger(__name__)


class DSPyScanner(BaseScanner, ASTExtractionMixin):
    """Scanner for DSPy framework.

    Detects:
    - dspy.Module subclasses
    - Signature definitions
    - ChainOfThought, ReAct, and other patterns
    - Compiled/optimized modules

    Example:
        >>> scanner = DSPyScanner()
        >>> result = scanner.scan_file(Path("pipeline.py"))
        >>> for agent in result.agents:
        ...     print(f"{agent.name}: {agent.system_prompt}")
    """

    framework_name = "DSPy"

    # DSPy module patterns to detect
    DSPY_MODULES = {
        "Predict",
        "ChainOfThought",
        "ChainOfThoughtWithHint",
        "ReAct",
        "ProgramOfThought",
        "MultiChainComparison",
        "Retrieve",
        "RAG",
        "TypedPredictor",
        "TypedChainOfThought",
    }

    # Base classes for custom modules
    MODULE_BASES = {
        "Module",
        "dspy.Module",
    }

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a Python file for DSPy module definitions.

        Args:
            path: Path to Python file

        Returns:
            ScanResult with detected agents and connections
        """
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        errors: list[str] = []

        try:
            tree = self._parse_python_file(path)
        except SyntaxError as e:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[f"Syntax error in {path}: {e}"],
            )

        # Track signatures for context
        signatures: dict[str, dict[str, Any]] = {}

        # First pass: find Signature definitions
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                sig = self._parse_signature_class(node)
                if sig:
                    signatures[node.name] = sig

        # Second pass: find Module subclasses
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                agent = self._parse_module_class(node, path, signatures)
                if agent:
                    agents.append(agent)

        # Third pass: find module instantiations
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        agent = self._parse_module_call(node.value, path, target.id, signatures)
                        if agent:
                            agents.append(agent)

        # Infer connections from forward method calls
        connections = self._infer_module_connections(tree, agents)

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=errors,
        )

    def _parse_signature_class(self, node: ast.ClassDef) -> dict[str, Any] | None:
        """Parse a DSPy Signature class definition.

        Args:
            node: Class definition node

        Returns:
            Signature info dict or None
        """
        # Check if this inherits from Signature
        is_signature = any(
            (isinstance(base, ast.Name) and base.id == "Signature")
            or (isinstance(base, ast.Attribute) and base.attr == "Signature")
            for base in node.bases
        )
        if not is_signature:
            return None

        # Extract docstring as the signature prompt
        docstring = ast.get_docstring(node) or ""

        # Extract input/output fields
        inputs: list[str] = []
        outputs: list[str] = []

        for item in node.body:
            if isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
                field_name = item.target.id
                annotation = item.annotation

                # Check if it's an InputField or OutputField
                if isinstance(annotation, ast.Call):
                    call_name = self._get_call_name(annotation)
                    if call_name == "InputField":
                        inputs.append(field_name)
                    elif call_name == "OutputField":
                        outputs.append(field_name)
                elif isinstance(annotation, ast.Subscript):
                    # Handle typing annotations like str
                    inputs.append(field_name)

        return {
            "docstring": docstring,
            "inputs": inputs,
            "outputs": outputs,
        }

    def _parse_module_class(
        self, node: ast.ClassDef, path: Path, signatures: dict[str, dict[str, Any]]
    ) -> DetectedAgent | None:
        """Parse a DSPy Module subclass.

        Args:
            node: Class definition node
            path: Source file path
            signatures: Known signature definitions

        Returns:
            DetectedAgent or None
        """
        # Check if this inherits from Module
        is_module = any(
            (isinstance(base, ast.Name) and base.id in self.MODULE_BASES)
            or (isinstance(base, ast.Attribute) and base.attr == "Module")
            or (
                isinstance(base, ast.Attribute)
                and hasattr(base, "value")
                and isinstance(base.value, ast.Name)
                and base.value.id == "dspy"
                and base.attr == "Module"
            )
            for base in node.bases
        )
        if not is_module:
            return None

        # Extract class info
        class_name = node.name
        docstring = ast.get_docstring(node) or ""

        # Find components used in __init__
        components = self._extract_module_components(node)

        # Build system prompt
        system_prompt = docstring if docstring else f"DSPy Module: {class_name}"

        if components:
            component_str = ", ".join(components)
            system_prompt = f"{system_prompt}\n\nComponents: {component_str}"

        return DetectedAgent(
            id=self._make_id(class_name),
            name=self._format_display_name(class_name),
            system_prompt=system_prompt.strip(),
            file_path=str(path),
            line_number=node.lineno,
            framework=Framework.DSPY,
            metadata={
                "module_type": "custom",
                "components": components,
                "model": "gpt-4",  # DSPy uses configured LM
            },
        )

    def _extract_module_components(self, node: ast.ClassDef) -> list[str]:
        """Extract component names from a Module's __init__.

        Args:
            node: Class definition node

        Returns:
            List of component names
        """
        components: list[str] = []

        for item in node.body:
            if isinstance(item, ast.FunctionDef) and item.name == "__init__":
                for stmt in ast.walk(item):
                    # Look for self.xxx = dspy.YYY(...) patterns
                    if isinstance(stmt, ast.Assign):
                        for target in stmt.targets:
                            if isinstance(target, ast.Attribute):
                                if isinstance(target.value, ast.Name) and target.value.id == "self":
                                    if isinstance(stmt.value, ast.Call):
                                        call_name = self._get_call_name(stmt.value)
                                        if call_name in self.DSPY_MODULES:
                                            components.append(f"{target.attr}:{call_name}")

        return components

    def _parse_module_call(
        self,
        node: ast.Call,
        path: Path,
        var_name: str,
        signatures: dict[str, dict[str, Any]],
    ) -> DetectedAgent | None:
        """Parse a DSPy module instantiation.

        Args:
            node: AST Call node
            path: Source file path
            var_name: Variable name
            signatures: Known signature definitions

        Returns:
            DetectedAgent or None
        """
        call_name = self._get_call_name(node)

        # Check for built-in DSPy modules
        if call_name not in self.DSPY_MODULES:
            # Also check for dspy.XXX pattern
            full_chain = self._get_full_call_chain(node)
            if not any(mod in full_chain for mod in self.DSPY_MODULES):
                return None

        # Extract signature if provided
        signature_info = None
        if node.args:
            first_arg = self._extract_value(node.args[0])
            if first_arg and isinstance(first_arg, str):
                # Could be inline signature "question -> answer"
                signature_info = {"docstring": first_arg}
            elif first_arg and first_arg in signatures:
                signature_info = signatures[first_arg]

        # Build system prompt
        system_prompt = f"DSPy {call_name}"
        if signature_info:
            if signature_info.get("docstring"):
                system_prompt = signature_info["docstring"]
            if signature_info.get("inputs"):
                system_prompt += f"\n\nInputs: {', '.join(signature_info['inputs'])}"
            if signature_info.get("outputs"):
                system_prompt += f"\n\nOutputs: {', '.join(signature_info['outputs'])}"

        # Add module-specific info
        if call_name == "ChainOfThought":
            system_prompt += "\n\nReasoning: Step-by-step chain of thought"
        elif call_name == "ReAct":
            system_prompt += "\n\nReasoning: ReAct pattern (Reason + Act)"
        elif call_name == "ProgramOfThought":
            system_prompt += "\n\nReasoning: Program of thought with code execution"

        return DetectedAgent(
            id=self._make_id(var_name),
            name=self._format_display_name(var_name),
            system_prompt=system_prompt.strip(),
            file_path=str(path),
            line_number=node.lineno,
            framework=Framework.DSPY,
            metadata={
                "module_type": call_name,
                "model": "gpt-4",
            },
        )

    def _infer_module_connections(
        self, tree: ast.Module, agents: list[DetectedAgent]
    ) -> list[DetectedConnection]:
        """Infer connections between DSPy modules.

        Args:
            tree: AST tree
            agents: Detected agents

        Returns:
            List of inferred connections
        """
        connections: list[DetectedConnection] = []
        agent_ids = {a.id for a in agents}

        # Look for forward method patterns
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                for item in node.body:
                    if isinstance(item, ast.FunctionDef) and item.name == "forward":
                        # Track call order
                        call_order = self._extract_call_order(item, agent_ids)
                        for i in range(len(call_order) - 1):
                            connections.append(
                                DetectedConnection(
                                    source_id=call_order[i],
                                    target_id=call_order[i + 1],
                                    connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                                    confidence=0.70,
                                    confidence_level=ConnectionConfidence.HEURISTIC,
                                    evidence=[
                                        f"DSPy forward() method call order: {call_order[i]} -> {call_order[i + 1]}"
                                    ],
                                )
                            )

        return connections

    def _extract_call_order(self, func: ast.FunctionDef, agent_ids: set[str]) -> list[str]:
        """Extract the order of module calls in a function.

        Args:
            func: Function definition node
            agent_ids: Known agent IDs

        Returns:
            Ordered list of agent IDs that are called
        """
        order: list[str] = []

        for node in ast.walk(func):
            if isinstance(node, ast.Call):
                # Check for self.xxx() calls
                if isinstance(node.func, ast.Attribute):
                    if isinstance(node.func.value, ast.Name) and node.func.value.id == "self":
                        attr_id = self._make_id(node.func.attr)
                        # Note: This is a simplified check
                        # In practice we'd need to track attribute assignments
                        if attr_id in agent_ids or any(attr_id in aid for aid in agent_ids):
                            order.append(attr_id)

        return order
