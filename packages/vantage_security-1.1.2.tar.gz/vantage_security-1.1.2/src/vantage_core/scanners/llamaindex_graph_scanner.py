from pathlib import Path
from vantage_core.models import DetectedAgent, DetectedConnection, Framework, ScanResult, ConnectionType, ConnectionConfidence
from vantage_core.scanners.base import BaseScanner
from vantage_core.graph.builder import CPGBuilder
from vantage_core.graph.query import CPGQuery

class LlamaIndexGraphScanner(BaseScanner):
    """Graph-based Scanner for LlamaIndex."""
    
    framework_name = "LlamaIndex"
    AGENT_CLASSES = {"ReActAgent", "OpenAIAgent", "FunctionCallingAgent"}

    def scan_file(self, path: Path) -> ScanResult:
        with open(path, "r", encoding="utf-8") as f:
            source = f.read()

        builder = CPGBuilder()
        graph = builder.build(source, str(path))
        query = CPGQuery(graph)
        
        agents = []
        connections = []
        
        # 1. Detect Agents via `from_tools` or constructor
        # LlamaIndex agents are often created via class methods: ReActAgent.from_tools(...)
        
        # 2. Detect Query Engines (often behave like agents)
        engine_creators = {
            "ReActAgent", "OpenAIAgent", "FunctionCallingAgent",
            "ContextChatEngine", "CondenseQuestionChatEngine"
        }
        
        # Find calls to agent classes
        for cls_name in engine_creators:
            # Check constructors and factory methods
            calls = query.find_calls_by_name(cls_name)
            calls.extend(query.find_calls_by_name(f"{cls_name}.from_tools"))
            calls.extend(query.find_calls_by_name(f"{cls_name}.from_defaults"))
            
            for call_id, call_node in calls:
                # Resolve args
                system_prompt = query.resolve_argument(call_id, "system_prompt")
                verbose = query.resolve_argument(call_id, "verbose")
                llm = query.resolve_argument(call_id, "llm")
                context = query.resolve_argument(call_id, "context") # ContextChatEngine
                
                # Tools arg
                tools_arg = query.resolve_argument(call_id, "tools")
                tool_names = []
                if isinstance(tools_arg, list):
                    tool_names = [str(t) for t in tools_arg]
                
                # If tools_arg is a variable, trace it?
                # The CPGQuery.resolve_argument already does basic tracing.
                
                name = f"llamaindex_{cls_name.lower()}_{call_node.ast_node.lineno}"
                
                metadata = {}
                if isinstance(llm, dict):
                    metadata["llm_provider"] = llm.get("name")
                
                # Combine prompt sources
                final_prompt = str(system_prompt) if system_prompt else "LlamaIndex Agent"
                if context:
                    final_prompt += f"\nContext: {context}"
                
                agents.append(DetectedAgent(
                    id=self._make_id(name),
                    name=name,
                    framework=Framework.LLAMAINEX, 
                    file_path=str(path),
                    line_number=call_node.ast_node.lineno,
                    system_prompt=final_prompt,
                    tools=tool_names,
                    metadata=metadata
                ))
                
        # 3. Detect Query Engine from Index (index.as_query_engine())
        # This requires tracking method calls on objects.
        # "as_query_engine" calls.
        calls = query.find_calls_by_name("as_query_engine")
        for call_id, call_node in calls:
            # Resolve receiver (the index object)
            receiver = query.resolve_receiver(call_id)
            # Receiver might be "index" variable.
            
            name = f"llamaindex_query_engine_{call_node.ast_node.lineno}"
            agents.append(DetectedAgent(
                id=self._make_id(name),
                name=name,
                framework=Framework.LLAMAINEX,
                file_path=str(path),
                line_number=call_node.ast_node.lineno,
                system_prompt="Query Engine (Index based)",
                tools=[],
                metadata={"source_index": str(receiver) if receiver else "unknown"}
            ))

        return ScanResult(
            agents=agents,
            connections=connections,
            framework=self.framework_name,
            files_scanned=1,
            errors=[]
        )
