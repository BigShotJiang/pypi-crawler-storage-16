"""
Data flow and reachability analysis for security scanning.

This module answers the critical question: "Can an attacker actually exploit
this vulnerability?" by tracking data flow from sources to sinks.

Components:
- TaintTracker: Track tainted data through code
- CallGraphBuilder: Build function call relationships
- ReachabilityAnalyzer: Check if sinks are reachable from entry points

Based on research in dataflow-reachability-analysis-research.md
"""

import ast
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class TaintLabel(Enum):
    """Labels for taint sources."""

    USER_INPUT = "user_input"
    FILE_INPUT = "file_input"
    NETWORK_INPUT = "network_input"
    DATABASE_INPUT = "database_input"
    ENV_VAR = "env_var"
    COMMAND_LINE = "command_line"
    UNTRUSTED = "untrusted"


@dataclass(frozen=True)
class TaintSource:
    """A source of tainted data."""

    label: TaintLabel
    location: tuple[str, int, int]  # file, line, col
    expression: str
    framework: str | None = None

    def __hash__(self):
        return hash((self.label, self.location, self.expression, self.framework))


@dataclass
class Sink:
    """A dangerous sink where tainted data can cause harm."""

    name: str
    sink_type: str  # sql, command, code_exec, file, etc.
    location: tuple[str, int, int]
    expression: str


@dataclass
class DataFlowPath:
    """A path from source to sink."""

    source: TaintSource
    sink: Sink
    path: list[tuple[str, int, str]]  # file, line, description
    confidence: float
    sanitizers: list[str]  # sanitizers applied on path


@dataclass
class ReachabilityResult:
    """Result of reachability analysis."""

    sink_location: tuple[str, int]  # file, line
    is_reachable: bool
    reachable_from: list[str]  # entry point names
    requires_auth: bool
    confidence: float
    attack_paths: list[DataFlowPath]


class SourceRegistry:
    """Registry of known taint sources by framework."""

    SOURCES = {
        "flask": [
            ("request.args", TaintLabel.USER_INPUT),
            ("request.form", TaintLabel.USER_INPUT),
            ("request.json", TaintLabel.USER_INPUT),
            ("request.data", TaintLabel.USER_INPUT),
            ("request.cookies", TaintLabel.USER_INPUT),
            ("request.headers", TaintLabel.USER_INPUT),
            ("request.files", TaintLabel.FILE_INPUT),
        ],
        "fastapi": [
            ("Request", TaintLabel.USER_INPUT),
            ("Body", TaintLabel.USER_INPUT),
            ("Query", TaintLabel.USER_INPUT),
            ("Path", TaintLabel.USER_INPUT),
            ("Header", TaintLabel.USER_INPUT),
        ],
        "django": [
            ("request.GET", TaintLabel.USER_INPUT),
            ("request.POST", TaintLabel.USER_INPUT),
            ("request.body", TaintLabel.USER_INPUT),
            ("request.COOKIES", TaintLabel.USER_INPUT),
            ("request.META", TaintLabel.USER_INPUT),
        ],
        "stdlib": [
            ("sys.argv", TaintLabel.COMMAND_LINE),
            ("os.environ", TaintLabel.ENV_VAR),
            ("input()", TaintLabel.USER_INPUT),
        ],
        "lambda": [
            ("event", TaintLabel.USER_INPUT),
        ],
    }


class SinkRegistry:
    """Registry of known dangerous sinks."""

    SINKS = {
        "sql": [
            "cursor.execute",
            "cursor.executemany",
            "engine.execute",
            "session.execute",
            "connection.execute",
        ],
        "command": [
            "os.system",
            "os.popen",
            "subprocess.run",
            "subprocess.call",
            "subprocess.Popen",
            "commands.getoutput",
        ],
        "code_exec": [
            "eval",
            "exec",
            "compile",
            "__import__",
        ],
        "file": [
            "open",
            "os.path.join",
            "pathlib.Path",
        ],
        "deserialization": [
            "pickle.loads",
            "pickle.load",
            "yaml.load",
            "yaml.unsafe_load",
        ],
        "ssrf": [
            "requests.get",
            "requests.post",
            "urllib.request.urlopen",
            "httpx.get",
            "httpx.post",
        ],
    }


class TaintTracker(ast.NodeVisitor):
    """
    Track tainted data flow through Python AST.

    Performs intra-procedural taint analysis tracking tainted variables
    through assignments and operations.
    """

    def __init__(self, file_path: str, framework: str = "stdlib"):
        self.file_path = file_path
        self.framework = framework

        # Taint state: variable name -> set of TaintSource
        self.taint_state: dict[str, set[TaintSource]] = defaultdict(set)

        # Collected findings
        self.sources_found: list[TaintSource] = []
        self.sinks_found: list[Sink] = []
        self.flows: list[DataFlowPath] = []

        # Source and sink registries
        self._sources = SourceRegistry.SOURCES.get(framework, [])
        self._sources.extend(SourceRegistry.SOURCES.get("stdlib", []))

    def analyze(self, code: str) -> list[DataFlowPath]:
        """
        Analyze code for taint flows.

        Args:
            code: Python source code

        Returns:
            List of detected data flow paths
        """
        try:
            tree = ast.parse(code)
            self.visit(tree)
        except SyntaxError as e:
            logger.warning(f"Syntax error in {self.file_path}: {e}")

        return self.flows

    def visit_Assign(self, node: ast.Assign):
        """Track taint through assignments."""
        # Check if RHS is a source
        source = self._check_source(node.value)
        if source:
            self.sources_found.append(source)

        # Get taint from RHS
        rhs_taint = self._get_taint(node.value)
        if source:
            rhs_taint.add(source)

        # Propagate to LHS
        for target in node.targets:
            if isinstance(target, ast.Name):
                self.taint_state[target.id] = rhs_taint.copy()

        self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        """Check for sinks and track taint."""
        # Check if this is a sink
        sink = self._check_sink(node)
        if sink:
            self.sinks_found.append(sink)

            # Check if any argument is tainted
            for arg in node.args:
                taint = self._get_taint(arg)
                if taint:
                    for source in taint:
                        flow = DataFlowPath(
                            source=source,
                            sink=sink,
                            path=[
                                (
                                    source.location[0],
                                    source.location[1],
                                    f"Source: {source.expression}",
                                ),
                                (
                                    sink.location[0],
                                    sink.location[1],
                                    f"Sink: {sink.expression}",
                                ),
                            ],
                            confidence=0.8,
                            sanitizers=[],
                        )
                        self.flows.append(flow)

        self.generic_visit(node)

    def _check_source(self, node: ast.AST) -> TaintSource | None:
        """Check if node is a taint source."""
        source_text = self._node_to_string(node)

        for pattern, label in self._sources:
            if pattern in source_text:
                return TaintSource(
                    label=label,
                    location=(
                        self.file_path,
                        getattr(node, "lineno", 0),
                        getattr(node, "col_offset", 0),
                    ),
                    expression=source_text,
                    framework=self.framework,
                )

        return None

    def _check_sink(self, node: ast.Call) -> Sink | None:
        """Check if call is a dangerous sink."""
        func_name = self._get_call_name(node)

        for sink_type, patterns in SinkRegistry.SINKS.items():
            for pattern in patterns:
                if pattern in func_name or func_name.endswith(pattern.split(".")[-1]):
                    return Sink(
                        name=func_name,
                        sink_type=sink_type,
                        location=(self.file_path, node.lineno, node.col_offset),
                        expression=self._node_to_string(node),
                    )

        return None

    def _get_taint(self, node: ast.AST) -> set[TaintSource]:
        """Get taint sources that flow to this node."""
        if isinstance(node, ast.Name):
            return self.taint_state.get(node.id, set()).copy()

        elif isinstance(node, ast.BinOp):
            # Taint propagates through operations
            left = self._get_taint(node.left)
            right = self._get_taint(node.right)
            return left | right

        elif isinstance(node, ast.Call):
            # Propagate taint from arguments
            result = set()
            for arg in node.args:
                result |= self._get_taint(arg)
            return result

        elif isinstance(node, ast.JoinedStr):
            # f-strings
            result = set()
            for value in node.values:
                if isinstance(value, ast.FormattedValue):
                    result |= self._get_taint(value.value)
            return result

        return set()

    def _get_call_name(self, node: ast.Call) -> str:
        """Get full name of called function."""
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            parts = []
            current = node.func
            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            if isinstance(current, ast.Name):
                parts.append(current.id)
            return ".".join(reversed(parts))
        return ""

    def _node_to_string(self, node: ast.AST) -> str:
        """Convert AST node to string representation."""
        try:
            return ast.unparse(node)
        except Exception:
            return ""


@dataclass
class EntryPoint:
    """An entry point into the application."""

    name: str
    file_path: str
    line_number: int
    framework: str
    route: str | None = None
    methods: list[str] = field(default_factory=list)
    requires_auth: bool = False


class EntryPointDetector(ast.NodeVisitor):
    """
    Detect entry points in Python code.

    Supports Flask, FastAPI, Django, Lambda, and CLI entry points.
    """

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.entry_points: list[EntryPoint] = []
        self._app_names: set[str] = set()

    def detect(self, code: str) -> list[EntryPoint]:
        """
        Detect entry points in code.

        Args:
            code: Python source code

        Returns:
            List of detected entry points
        """
        try:
            tree = ast.parse(code)
            self.visit(tree)
        except SyntaxError as e:
            logger.warning(f"Syntax error in {self.file_path}: {e}")

        return self.entry_points

    def visit_Assign(self, node: ast.Assign):
        """Track Flask/FastAPI app instances."""
        for target in node.targets:
            if isinstance(target, ast.Name):
                if isinstance(node.value, ast.Call):
                    call_name = self._get_call_name(node.value)
                    if call_name in ("Flask", "FastAPI", "Starlette"):
                        self._app_names.add(target.id)

        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef):
        """Check for decorated route handlers."""
        for decorator in node.decorator_list:
            entry_point = self._check_decorator(node, decorator)
            if entry_point:
                self.entry_points.append(entry_point)

        # Check for Lambda handler pattern
        if self._is_lambda_handler(node):
            self.entry_points.append(
                EntryPoint(
                    name=node.name,
                    file_path=self.file_path,
                    line_number=node.lineno,
                    framework="lambda",
                )
            )

        self.generic_visit(node)

    def visit_If(self, node: ast.If):
        """Check for __main__ entry point."""
        if self._is_main_check(node.test):
            self.entry_points.append(
                EntryPoint(
                    name="__main__",
                    file_path=self.file_path,
                    line_number=node.lineno,
                    framework="cli",
                )
            )

        self.generic_visit(node)

    def _check_decorator(
        self,
        func: ast.FunctionDef,
        decorator: ast.expr,
    ) -> EntryPoint | None:
        """Check if decorator indicates an entry point."""
        if isinstance(decorator, ast.Call):
            dec_name = self._get_call_name(decorator)

            # Flask routes
            if ".route" in dec_name or dec_name in (
                "route",
                "get",
                "post",
                "put",
                "delete",
            ):
                route = self._extract_route(decorator)
                methods = self._extract_methods(decorator)

                # Determine framework
                framework = "flask"
                for app_name in self._app_names:
                    if dec_name.startswith(f"{app_name}."):
                        break

                return EntryPoint(
                    name=func.name,
                    file_path=self.file_path,
                    line_number=func.lineno,
                    framework=framework,
                    route=route,
                    methods=methods,
                )

        elif isinstance(decorator, ast.Attribute):
            # FastAPI-style: @app.get("/path")
            if decorator.attr in ("get", "post", "put", "delete", "patch"):
                return EntryPoint(
                    name=func.name,
                    file_path=self.file_path,
                    line_number=func.lineno,
                    framework="fastapi",
                    methods=[decorator.attr.upper()],
                )

        return None

    def _is_lambda_handler(self, func: ast.FunctionDef) -> bool:
        """Check if function matches Lambda handler pattern."""
        args = func.args.args
        if len(args) >= 2:
            arg_names = [a.arg for a in args]
            if "event" in arg_names or (len(arg_names) >= 2 and arg_names[1] in ("context", "ctx")):
                return True
        return False

    def _is_main_check(self, test: ast.expr) -> bool:
        """Check if this is if __name__ == '__main__'."""
        if isinstance(test, ast.Compare):
            if isinstance(test.left, ast.Name) and test.left.id == "__name__":
                if len(test.comparators) == 1:
                    comp = test.comparators[0]
                    if isinstance(comp, ast.Constant):
                        return comp.value == "__main__"
        return False

    def _extract_route(self, decorator: ast.Call) -> str | None:
        """Extract route path from decorator."""
        if decorator.args:
            if isinstance(decorator.args[0], ast.Constant):
                return str(decorator.args[0].value)
        return None

    def _extract_methods(self, decorator: ast.Call) -> list[str]:
        """Extract HTTP methods from decorator."""
        for keyword in decorator.keywords:
            if keyword.arg == "methods":
                if isinstance(keyword.value, ast.List):
                    return [
                        elt.value for elt in keyword.value.elts if isinstance(elt, ast.Constant)
                    ]
        return ["GET"]

    def _get_call_name(self, node: ast.Call) -> str:
        """Get full name of called function."""
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            parts = []
            current = node.func
            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            if isinstance(current, ast.Name):
                parts.append(current.id)
            return ".".join(reversed(parts))
        return ""


class ReachabilityAnalyzer:
    """
    Analyze reachability from entry points to vulnerabilities.

    Answers: "Can this vulnerability actually be reached by an attacker?"
    """

    def __init__(self):
        self._entry_points: list[EntryPoint] = []
        self._call_graph: dict[str, set[str]] = defaultdict(set)

    def add_entry_points(self, entry_points: list[EntryPoint]):
        """Add entry points to the analyzer."""
        self._entry_points.extend(entry_points)

    def analyze_reachability(
        self,
        sink_file: str,
        sink_line: int,
        sink_function: str | None = None,
    ) -> ReachabilityResult:
        """
        Analyze if a sink is reachable from any entry point.

        Args:
            sink_file: File containing the sink
            sink_line: Line number of the sink
            sink_function: Function containing the sink

        Returns:
            ReachabilityResult with reachability information
        """
        reachable_from = []
        requires_auth = False
        attack_paths = []

        for entry_point in self._entry_points:
            # Simple heuristic: same file = reachable
            # In production, use call graph analysis
            if entry_point.file_path == sink_file:
                reachable_from.append(entry_point.name)

                if entry_point.requires_auth:
                    requires_auth = True

        is_reachable = len(reachable_from) > 0
        confidence = 0.8 if is_reachable else 0.3

        return ReachabilityResult(
            sink_location=(sink_file, sink_line),
            is_reachable=is_reachable,
            reachable_from=reachable_from,
            requires_auth=requires_auth,
            confidence=confidence,
            attack_paths=attack_paths,
        )


def analyze_file(file_path: str, framework: str = "auto") -> dict[str, Any]:
    """
    Analyze a Python file for data flow and entry points.

    Args:
        file_path: Path to Python file
        framework: Framework to assume (auto-detect if 'auto')

    Returns:
        Analysis results
    """
    with open(file_path) as f:
        code = f.read()

    # Auto-detect framework
    if framework == "auto":
        if "flask" in code.lower():
            framework = "flask"
        elif "fastapi" in code.lower():
            framework = "fastapi"
        elif "django" in code.lower():
            framework = "django"
        else:
            framework = "stdlib"

    # Detect entry points
    detector = EntryPointDetector(file_path)
    entry_points = detector.detect(code)

    # Track data flow
    tracker = TaintTracker(file_path, framework)
    flows = tracker.analyze(code)

    return {
        "file_path": file_path,
        "framework": framework,
        "entry_points": entry_points,
        "sources": tracker.sources_found,
        "sinks": tracker.sinks_found,
        "flows": flows,
    }


def create_reachability_analyzer() -> ReachabilityAnalyzer:
    """Create reachability analyzer."""
    return ReachabilityAnalyzer()
