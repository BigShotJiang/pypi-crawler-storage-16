"""
Authentication Service for Vantage Security Platform.

This module implements comprehensive authentication including:
- Email/password registration with bcrypt
- OAuth 2.0 flow for Google and GitHub
- MFA setup and verification (TOTP)
- JWT access tokens with refresh token rotation
- Password requirements validation
"""

import hashlib
import re
import secrets
from datetime import datetime, timedelta
from uuid import uuid4

# bcrypt is REQUIRED - no fallback
try:
    import bcrypt

    BCRYPT_AVAILABLE = True
except ImportError:
    BCRYPT_AVAILABLE = False

try:
    import pyotp

    PYOTP_AVAILABLE = True
except ImportError:
    PYOTP_AVAILABLE = False

try:
    from jose import JWTError, jwt

    JOSE_AVAILABLE = True
except ImportError:
    JOSE_AVAILABLE = False
    jwt = None
    JWTError = Exception

from pydantic import BaseModel, Field, field_validator

# Check if email-validator is installed for EmailStr support
try:
    import email_validator  # noqa: F401
    from pydantic import EmailStr
except ImportError:
    # Fall back to str if email-validator not installed
    EmailStr = str

from vantage_core.security.api.config import get_settings

# Get settings from environment-based configuration
# This will raise an error if required settings (like AUTH_SECRET_KEY) are not set
_settings = get_settings()


class AuthConfig:
    """
    Authentication configuration wrapper.

    All values are loaded from environment variables via Pydantic Settings.
    No hardcoded secrets - application will fail to start if AUTH_SECRET_KEY is not set.
    """

    # JWT Settings - loaded from environment
    SECRET_KEY: str = _settings.auth.secret_key
    ALGORITHM: str = _settings.auth.algorithm
    ACCESS_TOKEN_EXPIRE_MINUTES: int = _settings.auth.access_token_expire_minutes
    REFRESH_TOKEN_EXPIRE_DAYS: int = _settings.auth.refresh_token_expire_days

    # Password Policy
    PASSWORD_MIN_LENGTH: int = _settings.auth.password_min_length
    PASSWORD_REQUIRE_UPPERCASE: bool = _settings.auth.password_require_uppercase
    PASSWORD_REQUIRE_LOWERCASE: bool = _settings.auth.password_require_lowercase
    PASSWORD_REQUIRE_DIGIT: bool = _settings.auth.password_require_digit
    PASSWORD_REQUIRE_SPECIAL: bool = _settings.auth.password_require_special

    # Security Settings
    MAX_LOGIN_ATTEMPTS: int = _settings.auth.max_login_attempts
    LOCKOUT_DURATION_MINUTES: int = _settings.auth.lockout_duration_minutes
    BCRYPT_ROUNDS: int = _settings.auth.bcrypt_rounds
    MFA_ISSUER: str = _settings.auth.mfa_issuer

    # OAuth Configuration - loaded from environment
    GOOGLE_CLIENT_ID: str = _settings.oauth.google_client_id
    GOOGLE_CLIENT_SECRET: str = _settings.oauth.google_client_secret
    GITHUB_CLIENT_ID: str = _settings.oauth.github_client_id
    GITHUB_CLIENT_SECRET: str = _settings.oauth.github_client_secret


config = AuthConfig()


# Request/Response Models
class UserCreate(BaseModel):
    """User registration request."""

    email: EmailStr
    password: str
    name: str = Field(min_length=1, max_length=255)

    @field_validator("password")
    @classmethod
    def validate_password(cls, v: str) -> str:
        """Validate password meets requirements."""
        errors = []

        if len(v) < config.PASSWORD_MIN_LENGTH:
            errors.append(f"Password must be at least {config.PASSWORD_MIN_LENGTH} characters")

        if config.PASSWORD_REQUIRE_UPPERCASE and not re.search(r"[A-Z]", v):
            errors.append("Password must contain at least one uppercase letter")

        if config.PASSWORD_REQUIRE_LOWERCASE and not re.search(r"[a-z]", v):
            errors.append("Password must contain at least one lowercase letter")

        if config.PASSWORD_REQUIRE_DIGIT and not re.search(r"\d", v):
            errors.append("Password must contain at least one digit")

        if config.PASSWORD_REQUIRE_SPECIAL and not re.search(r"[!@#$%^&*(),.?\":{}|<>]", v):
            errors.append("Password must contain at least one special character")

        if errors:
            raise ValueError("; ".join(errors))

        return v


class UserLogin(BaseModel):
    """User login request."""

    email: EmailStr
    password: str


class TokenPair(BaseModel):
    """JWT token pair response."""

    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # Seconds
    requires_mfa: bool = False
    mfa_token: str | None = None


class MFASetupResponse(BaseModel):
    """MFA setup response with QR code data."""

    secret: str
    qr_uri: str
    backup_codes: list[str]


class MFAVerifyRequest(BaseModel):
    """MFA verification request."""

    code: str = Field(min_length=6, max_length=6)
    mfa_token: str | None = None


class RefreshTokenRequest(BaseModel):
    """Refresh token request."""

    refresh_token: str


class OAuthCallbackRequest(BaseModel):
    """OAuth callback request."""

    code: str
    state: str
    redirect_uri: str


class AuthResult(BaseModel):
    """Authentication result."""

    success: bool
    user_id: str | None = None
    tokens: TokenPair | None = None
    requires_mfa: bool = False
    mfa_token: str | None = None
    error: str | None = None


class AuthService:
    """
    Authentication service implementing full auth workflow.

    This service handles all authentication operations including
    registration, login, OAuth, MFA, and token management.
    """

    def __init__(self, db_session=None):
        """
        Initialize auth service.

        Args:
            db_session: Database session (SQLAlchemy)
        """
        self.db = db_session
        # In-memory storage for development (use database in production)
        self._users: dict[str, dict] = {}
        self._refresh_tokens: dict[str, dict] = {}
        self._oauth_accounts: dict[str, dict] = {}
        self._mfa_pending: dict[str, str] = {}  # mfa_token -> user_id
        self._oauth_states: dict[str, dict] = {}  # state -> {provider, redirect_uri, code_verifier}

    def hash_password(self, password: str) -> str:
        """
        Hash password using bcrypt.

        Args:
            password: Plain text password

        Returns:
            Bcrypt hash

        Raises:
            RuntimeError: If bcrypt is not available
        """
        if not BCRYPT_AVAILABLE:
            raise RuntimeError(
                "bcrypt is required for password hashing. " "Install with: pip install bcrypt"
            )

        salt = bcrypt.gensalt(rounds=config.BCRYPT_ROUNDS)
        return bcrypt.hashpw(password.encode(), salt).decode()

    def verify_password(self, password: str, hashed: str) -> bool:
        """
        Verify password against bcrypt hash.

        Args:
            password: Plain text password
            hashed: Bcrypt hash

        Returns:
            True if password matches

        Raises:
            RuntimeError: If bcrypt is not available
        """
        if not BCRYPT_AVAILABLE:
            raise RuntimeError(
                "bcrypt is required for password verification. " "Install with: pip install bcrypt"
            )

        try:
            return bcrypt.checkpw(password.encode(), hashed.encode())
        except Exception:
            return False

    def create_access_token(
        self,
        user_id: str,
        email: str,
        scopes: list[str] = None,
        mfa_verified: bool = False,
    ) -> str:
        """
        Create JWT access token.

        Args:
            user_id: User identifier
            email: User email
            scopes: Token scopes
            mfa_verified: Whether MFA was verified

        Returns:
            JWT access token
        """
        if not JOSE_AVAILABLE:
            # Fallback for testing - create a simple token
            import base64
            import json

            payload = {
                "sub": user_id,
                "email": email,
                "scopes": scopes or ["scan:read", "scan:write"],
                "mfa": mfa_verified,
                "type": "access",
            }
            return base64.b64encode(json.dumps(payload).encode()).decode()

        now = datetime.utcnow()
        expires = now + timedelta(minutes=config.ACCESS_TOKEN_EXPIRE_MINUTES)

        payload = {
            "sub": user_id,
            "email": email,
            "scopes": scopes or ["scan:read", "scan:write"],
            "mfa": mfa_verified,
            "iat": now,
            "exp": expires,
            "jti": str(uuid4()),
            "type": "access",
        }

        return jwt.encode(payload, config.SECRET_KEY, algorithm=config.ALGORITHM)

    def create_refresh_token(
        self, user_id: str, client_ip: str = None, user_agent: str = None
    ) -> tuple[str, str]:
        """
        Create refresh token with family tracking.

        Args:
            user_id: User identifier
            client_ip: Client IP address
            user_agent: Client user agent

        Returns:
            Tuple of (token, family_id)
        """
        now = datetime.utcnow()
        expires = now + timedelta(days=config.REFRESH_TOKEN_EXPIRE_DAYS)

        token = secrets.token_urlsafe(64)
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        family_id = str(uuid4())

        self._refresh_tokens[token_hash] = {
            "user_id": user_id,
            "family": family_id,
            "expires_at": expires,
            "created_at": now,
            "revoked_at": None,
            "client_ip": client_ip,
            "user_agent": user_agent,
        }

        return token, family_id

    def validate_access_token(self, token: str) -> dict | None:
        """
        Validate JWT access token.

        Args:
            token: JWT token

        Returns:
            Token payload if valid, None otherwise
        """
        if not JOSE_AVAILABLE:
            # Fallback for testing - decode simple token
            import base64
            import json

            try:
                payload = json.loads(base64.b64decode(token).decode())
                if payload.get("type") != "access":
                    return None
                return payload
            except Exception:
                return None

        try:
            payload = jwt.decode(token, config.SECRET_KEY, algorithms=[config.ALGORITHM])

            if payload.get("type") != "access":
                return None

            return payload
        except JWTError:
            return None

    async def register(self, data: UserCreate) -> AuthResult:
        """
        Register new user account.

        Args:
            data: Registration data

        Returns:
            Authentication result
        """
        # Check if email already exists
        email_lower = data.email.lower()
        for user in self._users.values():
            if user["email"].lower() == email_lower:
                return AuthResult(success=False, error="Email already registered")

        # Create user
        user_id = str(uuid4())
        password_hash = self.hash_password(data.password)

        self._users[user_id] = {
            "id": user_id,
            "email": data.email,
            "name": data.name,
            "password_hash": password_hash,
            "is_active": True,
            "is_verified": False,
            "is_mfa_enabled": False,
            "mfa_secret": None,
            "created_at": datetime.utcnow(),
            "failed_login_attempts": 0,
            "locked_until": None,
        }

        # TODO: Send verification email

        return AuthResult(success=True, user_id=user_id)

    async def login(
        self, email: str, password: str, client_ip: str = None, user_agent: str = None
    ) -> AuthResult:
        """
        Authenticate user with email/password.

        Args:
            email: User email
            password: User password
            client_ip: Client IP address
            user_agent: Client user agent

        Returns:
            Authentication result
        """
        # Find user
        user = None
        for u in self._users.values():
            if u["email"].lower() == email.lower():
                user = u
                break

        if not user:
            return AuthResult(success=False, error="Invalid email or password")

        # Check account lockout
        if user.get("locked_until"):
            if datetime.utcnow() < user["locked_until"]:
                remaining = (user["locked_until"] - datetime.utcnow()).seconds // 60
                return AuthResult(
                    success=False,
                    error=f"Account locked. Try again in {remaining} minutes",
                )
            else:
                # Reset lockout
                user["locked_until"] = None
                user["failed_login_attempts"] = 0

        # Verify password
        if not self.verify_password(password, user["password_hash"]):
            # Increment failed attempts
            user["failed_login_attempts"] = user.get("failed_login_attempts", 0) + 1

            if user["failed_login_attempts"] >= config.MAX_LOGIN_ATTEMPTS:
                user["locked_until"] = datetime.utcnow() + timedelta(
                    minutes=config.LOCKOUT_DURATION_MINUTES
                )
                return AuthResult(
                    success=False,
                    error="Account locked due to too many failed attempts",
                )

            return AuthResult(success=False, error="Invalid email or password")

        # Reset failed attempts on successful login
        user["failed_login_attempts"] = 0

        # Check if MFA is required
        if user.get("is_mfa_enabled"):
            # Generate temporary MFA token
            mfa_token = secrets.token_urlsafe(32)
            self._mfa_pending[mfa_token] = user["id"]

            return AuthResult(
                success=True, user_id=user["id"], requires_mfa=True, mfa_token=mfa_token
            )

        # Generate tokens
        access_token = self.create_access_token(user["id"], user["email"], mfa_verified=False)
        refresh_token, _ = self.create_refresh_token(user["id"], client_ip, user_agent)

        user["last_login_at"] = datetime.utcnow()

        return AuthResult(
            success=True,
            user_id=user["id"],
            tokens=TokenPair(
                access_token=access_token,
                refresh_token=refresh_token,
                expires_in=config.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            ),
        )

    async def verify_mfa(
        self, mfa_token: str, code: str, client_ip: str = None, user_agent: str = None
    ) -> AuthResult:
        """
        Verify MFA code after login.

        Args:
            mfa_token: Temporary MFA token from login
            code: TOTP code from authenticator
            client_ip: Client IP address
            user_agent: Client user agent

        Returns:
            Authentication result with tokens
        """
        # Get user from MFA pending
        user_id = self._mfa_pending.get(mfa_token)
        if not user_id:
            return AuthResult(success=False, error="Invalid or expired MFA token")

        user = self._users.get(user_id)
        if not user:
            return AuthResult(success=False, error="User not found")

        # Verify TOTP code
        if not user.get("mfa_secret"):
            return AuthResult(success=False, error="MFA not configured")

        if not PYOTP_AVAILABLE:
            return AuthResult(
                success=False,
                error="MFA verification not available (pyotp not installed)",
            )

        totp = pyotp.TOTP(user["mfa_secret"])
        if not totp.verify(code, valid_window=1):
            # Check backup codes
            backup_codes = user.get("mfa_backup_codes", [])
            code_hash = hashlib.sha256(code.encode()).hexdigest()

            if code_hash not in backup_codes:
                return AuthResult(success=False, error="Invalid MFA code")

            # Remove used backup code
            backup_codes.remove(code_hash)
            user["mfa_backup_codes"] = backup_codes

        # Clear MFA pending
        del self._mfa_pending[mfa_token]

        # Generate tokens
        access_token = self.create_access_token(user["id"], user["email"], mfa_verified=True)
        refresh_token, _ = self.create_refresh_token(user["id"], client_ip, user_agent)

        user["last_login_at"] = datetime.utcnow()

        return AuthResult(
            success=True,
            user_id=user["id"],
            tokens=TokenPair(
                access_token=access_token,
                refresh_token=refresh_token,
                expires_in=config.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            ),
        )

    async def setup_mfa(self, user_id: str) -> MFASetupResponse:
        """
        Initialize MFA setup for user.

        Args:
            user_id: User identifier

        Returns:
            MFA setup data with QR code URI
        """
        if not PYOTP_AVAILABLE:
            raise ValueError("MFA setup not available (pyotp not installed)")

        user = self._users.get(user_id)
        if not user:
            raise ValueError("User not found")

        # Generate TOTP secret
        secret = pyotp.random_base32()

        # Generate QR code URI
        totp = pyotp.TOTP(secret)
        qr_uri = totp.provisioning_uri(name=user["email"], issuer_name=config.MFA_ISSUER)

        # Generate backup codes
        backup_codes = []
        backup_codes_plain = []
        for _ in range(10):
            code = secrets.token_hex(4).upper()  # 8 character codes
            backup_codes_plain.append(code)
            backup_codes.append(hashlib.sha256(code.encode()).hexdigest())

        # Store temporarily (commit on verification)
        user["_pending_mfa_secret"] = secret
        user["_pending_backup_codes"] = backup_codes

        return MFASetupResponse(secret=secret, qr_uri=qr_uri, backup_codes=backup_codes_plain)

    async def confirm_mfa_setup(self, user_id: str, code: str) -> bool:
        """
        Confirm MFA setup by verifying first code.

        Args:
            user_id: User identifier
            code: TOTP code to verify

        Returns:
            True if setup confirmed
        """
        if not PYOTP_AVAILABLE:
            raise ValueError("MFA confirmation not available (pyotp not installed)")

        user = self._users.get(user_id)
        if not user:
            raise ValueError("User not found")

        pending_secret = user.get("_pending_mfa_secret")
        if not pending_secret:
            raise ValueError("No MFA setup pending")

        # Verify the code
        totp = pyotp.TOTP(pending_secret)
        if not totp.verify(code, valid_window=1):
            return False

        # Commit MFA setup
        user["mfa_secret"] = pending_secret
        user["mfa_backup_codes"] = user["_pending_backup_codes"]
        user["is_mfa_enabled"] = True

        # Clean up pending
        del user["_pending_mfa_secret"]
        del user["_pending_backup_codes"]

        return True

    async def disable_mfa(self, user_id: str, password: str) -> bool:
        """
        Disable MFA for user (requires password).

        Args:
            user_id: User identifier
            password: User password for verification

        Returns:
            True if MFA disabled
        """
        user = self._users.get(user_id)
        if not user:
            raise ValueError("User not found")

        if not self.verify_password(password, user["password_hash"]):
            return False

        user["is_mfa_enabled"] = False
        user["mfa_secret"] = None
        user["mfa_backup_codes"] = None

        return True

    async def refresh_tokens(
        self, refresh_token: str, client_ip: str = None, user_agent: str = None
    ) -> AuthResult:
        """
        Refresh access token using refresh token.

        Implements token rotation - old refresh token is invalidated.

        Args:
            refresh_token: Refresh token
            client_ip: Client IP address
            user_agent: Client user agent

        Returns:
            Authentication result with new tokens
        """
        token_hash = hashlib.sha256(refresh_token.encode()).hexdigest()
        token_data = self._refresh_tokens.get(token_hash)

        if not token_data:
            return AuthResult(success=False, error="Invalid refresh token")

        # Check if revoked
        if token_data.get("revoked_at"):
            # Token reuse detected - revoke entire family
            family = token_data["family"]
            for hash_key, data in self._refresh_tokens.items():
                if data.get("family") == family:
                    data["revoked_at"] = datetime.utcnow()
                    data["revoked_reason"] = "Token reuse detected"

            return AuthResult(success=False, error="Token has been revoked. Please log in again.")

        # Check expiration
        if datetime.utcnow() > token_data["expires_at"]:
            return AuthResult(success=False, error="Refresh token expired")

        # Revoke old token
        token_data["revoked_at"] = datetime.utcnow()
        token_data["revoked_reason"] = "Rotated"

        # Get user
        user = self._users.get(token_data["user_id"])
        if not user:
            return AuthResult(success=False, error="User not found")

        # Generate new tokens
        access_token = self.create_access_token(
            user["id"], user["email"], mfa_verified=True  # Preserve MFA status
        )
        new_refresh_token, _ = self.create_refresh_token(user["id"], client_ip, user_agent)

        # Link to same family for rotation tracking
        new_hash = hashlib.sha256(new_refresh_token.encode()).hexdigest()
        self._refresh_tokens[new_hash]["family"] = token_data["family"]

        return AuthResult(
            success=True,
            user_id=user["id"],
            tokens=TokenPair(
                access_token=access_token,
                refresh_token=new_refresh_token,
                expires_in=config.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            ),
        )

    async def revoke_all_sessions(self, user_id: str) -> int:
        """
        Revoke all refresh tokens for a user.

        Args:
            user_id: User identifier

        Returns:
            Number of tokens revoked
        """
        count = 0
        for token_data in self._refresh_tokens.values():
            if token_data["user_id"] == user_id and not token_data.get("revoked_at"):
                token_data["revoked_at"] = datetime.utcnow()
                token_data["revoked_reason"] = "User logout all"
                count += 1

        return count

    async def initiate_oauth(self, provider: str, redirect_uri: str) -> str:
        """
        Initiate OAuth flow.

        Args:
            provider: OAuth provider (google, github)
            redirect_uri: Callback URI

        Returns:
            Authorization URL
        """
        state = secrets.token_urlsafe(32)
        code_verifier = secrets.token_urlsafe(64)
        code_challenge = hashlib.sha256(code_verifier.encode()).hexdigest()

        self._oauth_states[state] = {
            "provider": provider,
            "redirect_uri": redirect_uri,
            "code_verifier": code_verifier,
            "created_at": datetime.utcnow(),
        }

        if provider == "google":
            auth_url = (
                f"https://accounts.google.com/o/oauth2/v2/auth?"
                f"client_id={config.GOOGLE_CLIENT_ID}&"
                f"redirect_uri={redirect_uri}&"
                f"response_type=code&"
                f"scope=openid%20email%20profile&"
                f"state={state}&"
                f"code_challenge={code_challenge}&"
                f"code_challenge_method=S256"
            )
        elif provider == "github":
            auth_url = (
                f"https://github.com/login/oauth/authorize?"
                f"client_id={config.GITHUB_CLIENT_ID}&"
                f"redirect_uri={redirect_uri}&"
                f"scope=user:email&"
                f"state={state}"
            )
        else:
            raise ValueError(f"Unsupported OAuth provider: {provider}")

        return auth_url

    async def handle_oauth_callback(
        self,
        provider: str,
        code: str,
        state: str,
        client_ip: str = None,
        user_agent: str = None,
    ) -> AuthResult:
        """
        Handle OAuth callback and create/link account.

        Args:
            provider: OAuth provider
            code: Authorization code
            state: State parameter
            client_ip: Client IP address
            user_agent: Client user agent

        Returns:
            Authentication result
        """
        # Validate state
        state_data = self._oauth_states.get(state)
        if not state_data:
            return AuthResult(success=False, error="Invalid or expired OAuth state")

        if state_data["provider"] != provider:
            return AuthResult(success=False, error="Provider mismatch")

        # Clean up state
        del self._oauth_states[state]

        # In production, exchange code for tokens and get user info
        # This is a simplified mock implementation

        # Mock user info from provider
        provider_user_id = f"{provider}_{secrets.token_hex(8)}"
        email = f"user_{secrets.token_hex(4)}@{provider}.com"
        name = "OAuth User"

        # Check if OAuth account already linked
        oauth_key = f"{provider}:{provider_user_id}"
        existing_oauth = self._oauth_accounts.get(oauth_key)

        if existing_oauth:
            # Log in existing user
            user_id = existing_oauth["user_id"]
            user = self._users.get(user_id)
        else:
            # Check if email already exists
            user = None
            for u in self._users.values():
                if u["email"].lower() == email.lower():
                    user = u
                    break

            if user:
                # Link OAuth to existing account
                user_id = user["id"]
            else:
                # Create new user
                user_id = str(uuid4())
                self._users[user_id] = {
                    "id": user_id,
                    "email": email,
                    "name": name,
                    "password_hash": None,  # OAuth-only user
                    "is_active": True,
                    "is_verified": True,  # OAuth verifies email
                    "is_mfa_enabled": False,
                    "mfa_secret": None,
                    "created_at": datetime.utcnow(),
                    "failed_login_attempts": 0,
                    "locked_until": None,
                }
                user = self._users[user_id]

            # Create OAuth account link
            self._oauth_accounts[oauth_key] = {
                "user_id": user_id,
                "provider": provider,
                "provider_user_id": provider_user_id,
                "provider_email": email,
                "created_at": datetime.utcnow(),
            }

        # Generate tokens
        access_token = self.create_access_token(user["id"], user["email"], mfa_verified=False)
        refresh_token, _ = self.create_refresh_token(user["id"], client_ip, user_agent)

        user["last_login_at"] = datetime.utcnow()

        return AuthResult(
            success=True,
            user_id=user["id"],
            tokens=TokenPair(
                access_token=access_token,
                refresh_token=refresh_token,
                expires_in=config.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            ),
        )

    def get_user(self, user_id: str) -> dict | None:
        """Get user by ID."""
        return self._users.get(user_id)

    def get_user_by_email(self, email: str) -> dict | None:
        """Get user by email."""
        for user in self._users.values():
            if user["email"].lower() == email.lower():
                return user
        return None


# Global auth service instance
auth_service = AuthService()
