"""
Visualization API endpoints for Vantage Security Platform.

This module provides REST API endpoints for topology graphs, trust boundaries,
findings aggregations, and agent risk profiles.
"""

from datetime import datetime
from typing import Any

from fastapi import APIRouter, Query, Request
from pydantic import BaseModel, Field

router = APIRouter(tags=["visualizations"])


# Response Models


class NodePosition(BaseModel):
    """Position for graph node."""

    x: float
    y: float


class GraphNode(BaseModel):
    """Node in topology graph."""

    id: str
    label: str
    type: str = Field(..., description="Type: agent, tool, external")
    trust_level: int = Field(..., ge=0, le=4)
    tools: list[str] = Field(default_factory=list)
    risk_score: int = Field(0, ge=0, le=100)
    findings_count: dict[str, int] = Field(default_factory=dict)
    position: NodePosition | None = None


class GraphEdge(BaseModel):
    """Edge in topology graph."""

    id: str
    source: str
    target: str
    type: str = Field(..., description="Type: direct, broadcast, callback")
    data_sensitivity: str = Field("internal", description="Data sensitivity level")
    frequency: str = Field("medium", description="Communication frequency")


class TopologyResponse(BaseModel):
    """Response for topology graph data."""

    nodes: list[GraphNode]
    edges: list[GraphEdge]
    metadata: dict[str, Any]

    class Config:
        json_schema_extra = {
            "example": {
                "nodes": [
                    {
                        "id": "agent-1",
                        "label": "api_gateway",
                        "type": "agent",
                        "trust_level": 1,
                        "tools": ["http_request", "validate_input"],
                        "risk_score": 24,
                        "findings_count": {"critical": 1, "high": 2},
                    }
                ],
                "edges": [
                    {
                        "id": "edge-1",
                        "source": "agent-1",
                        "target": "agent-2",
                        "type": "direct",
                        "data_sensitivity": "internal",
                    }
                ],
                "metadata": {"layout": "hierarchical", "total_agents": 8},
            }
        }


class FindingAggregate(BaseModel):
    """Aggregated finding statistics."""

    category: str
    count: int
    severity_breakdown: dict[str, int]


class FindingsSummaryResponse(BaseModel):
    """Response for findings summary/aggregations."""

    scan_id: str
    total_findings: int
    by_severity: dict[str, int]
    by_category: list[FindingAggregate]
    by_owasp: dict[str, int]
    by_agent: dict[str, int]


class AgentRiskProfile(BaseModel):
    """Risk profile for a single agent."""

    agent_id: str
    agent_name: str
    risk_score: int
    trust_level: int
    tools: list[dict[str, Any]]
    findings: list[dict[str, Any]]
    connections: dict[str, int]
    risk_factors: list[str]
    recommendations: list[str]


class PaginatedFindingsResponse(BaseModel):
    """Paginated list of findings."""

    items: list[dict[str, Any]]
    total: int
    page: int
    per_page: int


# Endpoints


@router.get(
    "/scans/{scan_id}/topology",
    response_model=TopologyResponse,
    summary="Get topology graph data",
)
async def get_scan_topology(
    request: Request,
    scan_id: str,
    layout: str = Query("hierarchical", description="Layout: hierarchical, force, circular"),
) -> TopologyResponse:
    """
    Get topology graph data for visualization.

    Returns nodes (agents) and edges (communications) with layout positions.
    """
    # TODO: Implement actual scan data retrieval

    # Demo topology data
    nodes = [
        GraphNode(
            id="agent-1",
            label="api_gateway",
            type="agent",
            trust_level=1,
            tools=["http_request", "validate_input"],
            risk_score=24,
            findings_count={"critical": 1, "high": 2},
            position=NodePosition(x=300, y=50),
        ),
        GraphNode(
            id="agent-2",
            label="processor",
            type="agent",
            trust_level=2,
            tools=["transform_data", "validate_schema"],
            risk_score=12,
            findings_count={"medium": 3},
            position=NodePosition(x=150, y=200),
        ),
        GraphNode(
            id="agent-3",
            label="data_agent",
            type="agent",
            trust_level=2,
            tools=["query_db", "cache_result"],
            risk_score=8,
            findings_count={"low": 2},
            position=NodePosition(x=450, y=200),
        ),
        GraphNode(
            id="agent-4",
            label="payment_agent",
            type="agent",
            trust_level=3,
            tools=["process_payment", "validate_card"],
            risk_score=35,
            findings_count={"critical": 1, "high": 1, "medium": 2},
            position=NodePosition(x=300, y=350),
        ),
    ]

    edges = [
        GraphEdge(
            id="edge-1",
            source="agent-1",
            target="agent-2",
            type="direct",
            data_sensitivity="internal",
            frequency="high",
        ),
        GraphEdge(
            id="edge-2",
            source="agent-1",
            target="agent-3",
            type="direct",
            data_sensitivity="internal",
            frequency="high",
        ),
        GraphEdge(
            id="edge-3",
            source="agent-2",
            target="agent-4",
            type="direct",
            data_sensitivity="confidential",
            frequency="medium",
        ),
        GraphEdge(
            id="edge-4",
            source="agent-3",
            target="agent-4",
            type="direct",
            data_sensitivity="confidential",
            frequency="medium",
        ),
    ]

    return TopologyResponse(
        nodes=nodes,
        edges=edges,
        metadata={
            "layout": layout,
            "total_agents": len(nodes),
            "total_tools": sum(len(n.tools) for n in nodes),
            "scan_id": scan_id,
        },
    )


@router.get(
    "/scans/{scan_id}/findings",
    response_model=PaginatedFindingsResponse,
    summary="Get paginated findings",
)
async def get_scan_findings(
    request: Request,
    scan_id: str,
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    severity: str | None = Query(None, description="Filter by severity"),
    category: str | None = Query(None, description="Filter by category"),
    agent_id: str | None = Query(None, description="Filter by agent"),
    sort_by: str = Query("severity", description="Sort field"),
    sort_order: str = Query("desc", description="Sort order"),
) -> PaginatedFindingsResponse:
    """
    Get paginated list of findings for a scan.

    Supports filtering by severity, category, and agent.
    """
    # TODO: Implement actual findings retrieval

    # Demo findings
    all_findings = [
        {
            "id": "finding-1",
            "severity": "critical",
            "category": "prompt_injection",
            "title": "Unvalidated user input in API gateway",
            "description": "User input is passed directly to LLM without validation",
            "agent_id": "agent-1",
            "location": {"file": "agents/api_gateway.py", "line": 42},
            "owasp_mapping": "LLM01",
        },
        {
            "id": "finding-2",
            "severity": "critical",
            "category": "privilege_escalation",
            "title": "Direct database access without authorization",
            "description": "Payment agent accesses database without auth check",
            "agent_id": "agent-4",
            "location": {"file": "agents/payment.py", "line": 78},
            "owasp_mapping": "LLM08",
        },
        {
            "id": "finding-3",
            "severity": "high",
            "category": "excessive_agency",
            "title": "Excessive tool permissions for privileged operations",
            "description": "Agent has more permissions than needed",
            "agent_id": "agent-4",
            "location": {"file": "agents/payment.py", "line": 23},
            "owasp_mapping": "LLM08",
        },
    ]

    # Apply filters
    filtered = all_findings
    if severity:
        filtered = [f for f in filtered if f["severity"] == severity]
    if category:
        filtered = [f for f in filtered if f["category"] == category]
    if agent_id:
        filtered = [f for f in filtered if f["agent_id"] == agent_id]

    # Sort
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    if sort_by == "severity":
        filtered.sort(
            key=lambda x: severity_order.get(x["severity"], 5),
            reverse=(sort_order == "desc"),
        )

    # Paginate
    total = len(filtered)
    start = (page - 1) * per_page
    end = start + per_page
    items = filtered[start:end]

    return PaginatedFindingsResponse(
        items=items,
        total=total,
        page=page,
        per_page=per_page,
    )


@router.get(
    "/scans/{scan_id}/findings/summary",
    response_model=FindingsSummaryResponse,
    summary="Get findings aggregations",
)
async def get_findings_summary(
    request: Request,
    scan_id: str,
) -> FindingsSummaryResponse:
    """
    Get aggregated findings summary for a scan.

    Returns counts by severity, category, OWASP mapping, and agent.
    """
    # TODO: Implement actual aggregation from database

    return FindingsSummaryResponse(
        scan_id=scan_id,
        total_findings=23,
        by_severity={
            "critical": 2,
            "high": 5,
            "medium": 12,
            "low": 4,
        },
        by_category=[
            FindingAggregate(
                category="prompt_injection",
                count=5,
                severity_breakdown={"critical": 1, "high": 2, "medium": 2},
            ),
            FindingAggregate(
                category="privilege_escalation",
                count=4,
                severity_breakdown={"critical": 1, "high": 1, "medium": 2},
            ),
            FindingAggregate(
                category="excessive_agency",
                count=3,
                severity_breakdown={"high": 2, "medium": 1},
            ),
            FindingAggregate(
                category="data_leakage",
                count=6,
                severity_breakdown={"medium": 4, "low": 2},
            ),
            FindingAggregate(
                category="configuration_weakness",
                count=5,
                severity_breakdown={"medium": 3, "low": 2},
            ),
        ],
        by_owasp={
            "LLM01": 5,
            "LLM02": 3,
            "LLM06": 4,
            "LLM07": 3,
            "LLM08": 8,
        },
        by_agent={
            "agent-1": 5,
            "agent-2": 3,
            "agent-3": 4,
            "agent-4": 11,
        },
    )


@router.get(
    "/scans/{scan_id}/agents/{agent_id}/risk-profile",
    response_model=AgentRiskProfile,
    summary="Get agent risk profile",
)
async def get_agent_risk_profile(
    request: Request,
    scan_id: str,
    agent_id: str,
) -> AgentRiskProfile:
    """
    Get detailed risk profile for a specific agent.

    Includes tools, findings, connections, and recommendations.
    """
    # TODO: Implement actual agent data retrieval

    return AgentRiskProfile(
        agent_id=agent_id,
        agent_name="payment_agent",
        risk_score=35,
        trust_level=3,
        tools=[
            {
                "name": "process_payment",
                "category": "external_api",
                "risk_score": 8,
                "description": "Process payment transactions",
            },
            {
                "name": "validate_card",
                "category": "external_api",
                "risk_score": 5,
                "description": "Validate credit card information",
            },
            {
                "name": "query_transactions",
                "category": "database",
                "risk_score": 6,
                "description": "Query transaction history",
            },
        ],
        findings=[
            {
                "id": "finding-2",
                "severity": "critical",
                "category": "privilege_escalation",
                "title": "Direct database access without authorization",
            },
            {
                "id": "finding-3",
                "severity": "high",
                "category": "excessive_agency",
                "title": "Excessive tool permissions",
            },
        ],
        connections={
            "incoming": 2,
            "outgoing": 1,
            "total": 3,
        },
        risk_factors=[
            "High privilege level (PRIVILEGED)",
            "Direct database access",
            "External API calls with sensitive data",
            "Multiple critical findings",
        ],
        recommendations=[
            "Implement authorization checks before database access",
            "Apply principle of least privilege to tool permissions",
            "Add input validation for payment data",
            "Implement rate limiting for external API calls",
        ],
    )


@router.get(
    "/scans/{scan_id}/summary",
    summary="Get scan summary for dashboard",
)
async def get_scan_summary(
    request: Request,
    scan_id: str,
) -> dict[str, Any]:
    """
    Get complete scan summary data for dashboard display.

    Combines score, findings, and topology metadata.
    """
    # TODO: Implement actual scan data retrieval

    return {
        "scan_id": scan_id,
        "status": "completed",
        "atss_score": 72,
        "grade": "C",
        "scores": {
            "topology": 45,
            "agent": 68,
            "interaction": 58,
        },
        "agents": {
            "total": 8,
            "high_risk": 2,
            "medium_risk": 3,
            "low_risk": 3,
        },
        "tools": {
            "total": 14,
            "code_execution": 2,
            "database": 3,
            "external_api": 5,
            "other": 4,
        },
        "findings": {
            "total": 23,
            "critical": 2,
            "high": 5,
            "medium": 12,
            "low": 4,
        },
        "zones": {
            "total": 4,
            "violations": 3,
        },
        "duration_ms": 2340,
        "completed_at": datetime.utcnow().isoformat(),
    }
