"""
Security CLI Commands for Vantage.

This module implements the `vantage security` command group
with subcommands for scanning, reporting, and analysis.
"""

import sys
from pathlib import Path

import click

from vantage_core.security.logging import LoggerFactory
from vantage_core.security.pipeline.orchestrator import (
    PipelineConfig,
    PipelineResult,
    SecurityPipeline,
)
from vantage_core.security.reports import (
    HTMLReportGenerator,
    JSONReportGenerator,
    MarkdownReportGenerator,
    PDFReportGenerator,
    SARIFReportGenerator,
)


def _print_progress(stage: str, progress: int):
    """Print progress update."""
    click.echo(f"  [{progress:3d}%] {stage}", nl=True)


def _print_summary(result: PipelineResult):
    """Print scan summary to console."""
    click.echo("")
    click.echo(click.style("=" * 50, fg="blue"))
    click.echo(click.style("  VANTAGE SECURITY SCAN RESULTS", fg="blue", bold=True))
    click.echo(click.style("=" * 50, fg="blue"))
    click.echo("")

    # Status
    if result.is_success:
        click.echo(click.style("  Status: COMPLETED", fg="green", bold=True))
    else:
        click.echo(click.style(f"  Status: {result.status.upper()}", fg="red", bold=True))

    click.echo(f"  Scan ID: {result.scan_id}")
    click.echo(f"  Duration: {result.duration_ms}ms")
    click.echo("")

    # Score
    if result.atss_result:
        score = result.atss_result.overall_score
        grade = result.atss_result.grade

        # Color based on grade
        if grade in ("A", "B"):
            color = "green"
        elif grade == "C":
            color = "yellow"
        else:
            color = "red"

        click.echo(click.style(f"  Security Score: {score:.1f}/100", fg=color, bold=True))
        click.echo(click.style(f"  Grade: {grade}", fg=color, bold=True))
        click.echo("")

    # Findings
    if result.scan_result:
        click.echo("  Findings:")
        findings = result.scan_result

        if findings.critical_count > 0:
            click.echo(click.style(f"    Critical: {findings.critical_count}", fg="red", bold=True))
        else:
            click.echo("    Critical: 0")

        if findings.high_count > 0:
            click.echo(click.style(f"    High:     {findings.high_count}", fg="red"))
        else:
            click.echo("    High:     0")

        if findings.medium_count > 0:
            click.echo(click.style(f"    Medium:   {findings.medium_count}", fg="yellow"))
        else:
            click.echo("    Medium:   0")

        click.echo(f"    Low:      {findings.low_count}")
        click.echo(f"    Info:     {findings.info_count}")
        click.echo("")

        click.echo(f"  Agents Analyzed: {findings.agents_scanned}")
        click.echo(f"  Frameworks: {', '.join(findings.frameworks_detected)}")

    click.echo("")
    click.echo(click.style("=" * 50, fg="blue"))


@click.group()
def security():
    """
    Security scanning commands for multi-agent AI systems.

    Run scans, generate reports, and analyze security posture
    of your AI agent projects.
    """
    pass


@security.command()
@click.argument("path", type=click.Path(exists=True))
@click.option(
    "--format",
    "-f",
    type=click.Choice(["json", "html", "sarif", "pdf", "markdown"]),
    default="json",
    help="Output report format",
)
@click.option("--output", "-o", type=click.Path(), help="Output file path")
@click.option("--no-simulation", is_flag=True, help="Skip infection simulation")
@click.option("--no-remediation", is_flag=True, help="Skip remediation generation")
@click.option("--timeout", type=int, default=600, help="Maximum scan duration in seconds")
@click.option("--quiet", "-q", is_flag=True, help="Suppress progress output")
@click.option("--fail-on-findings", is_flag=True, help="Exit with error code if findings detected")
@click.option("--min-score", type=float, default=None, help="Minimum acceptable ATSS score")
@click.option("--log-file", type=click.Path(), help="Path to save debug logs")
def scan(
    path: str,
    format: str,
    output: str | None,
    no_simulation: bool,
    no_remediation: bool,
    timeout: int,
    quiet: bool,
    fail_on_findings: bool,
    min_score: float | None,
    log_file: str | None,
):
    """
    Run security scan on a project.

    Analyzes the project at PATH for security vulnerabilities,
    trust boundary violations, and generates remediation recommendations.

    Examples:

        # Basic scan with JSON output
        vantage security scan ./my-project

        # Scan with HTML report
        vantage security scan ./my-project -f html -o report.html

        # CI/CD scan with failure on findings
        vantage security scan . -f sarif --fail-on-findings

        # Quick scan without simulation
        vantage security scan . --no-simulation --no-remediation
    """
    project_path = Path(path).resolve()

    if not quiet:
        click.echo(f"Scanning: {project_path}")
        click.echo("")

    # Configure logging
    LoggerFactory.configure(log_level="INFO", json_output=False, log_file=log_file)

    # Configure pipeline
    config = PipelineConfig(
        skip_simulation=no_simulation,
        skip_remediation=no_remediation,
        timeout_seconds=timeout,
    )

    # Run scan with progress
    pipeline = SecurityPipeline(config)

    def progress_callback(stage: str, progress: int):
        if not quiet:
            _print_progress(stage, progress)

    result = pipeline.scan(project_path, config, progress_callback)

    # Print summary
    if not quiet:
        _print_summary(result)

    # Generate report
    if format == "json":
        generator = JSONReportGenerator()
        report_content = generator.generate(result)
        content_bytes = report_content.encode("utf-8")
    elif format == "html":
        generator = HTMLReportGenerator()
        report_content = generator.generate(result)
        content_bytes = report_content.encode("utf-8")
    elif format == "sarif":
        generator = SARIFReportGenerator()
        report_content = generator.generate(result)
        content_bytes = report_content.encode("utf-8")
    elif format == "pdf":
        generator = PDFReportGenerator()
        content_bytes = generator.generate(result)
    elif format == "markdown":
        generator = MarkdownReportGenerator()
        report_content = generator.generate(result)
        content_bytes = report_content.encode("utf-8")
    else:
        click.echo(f"Unknown format: {format}", err=True)
        sys.exit(1)

    # Write output
    if output:
        output_path = Path(output)
        if format == "pdf":
            output_path.write_bytes(content_bytes)
        else:
            output_path.write_text(report_content)

        if not quiet:
            click.echo(f"Report saved to: {output_path}")
    else:
        # Write to stdout
        if format == "pdf":
            click.echo("PDF output requires --output flag", err=True)
            sys.exit(1)
        else:
            click.echo(report_content)

    # Check exit conditions
    exit_code = 0

    if fail_on_findings and result.scan_result:
        if result.scan_result.critical_count > 0 or result.scan_result.high_count > 0:
            click.echo(click.style("Failing due to critical/high findings", fg="red"), err=True)
            exit_code = 1

    if min_score and result.atss_result:
        if result.atss_result.overall_score < min_score:
            click.echo(
                click.style(
                    f"Score {result.atss_result.overall_score:.1f} below minimum {min_score}",
                    fg="red",
                ),
                err=True,
            )
            exit_code = 1

    sys.exit(exit_code)


@security.command()
@click.argument("scan_id")
@click.option(
    "--format",
    "-f",
    type=click.Choice(["json", "html", "sarif", "pdf"]),
    default="json",
    help="Output report format",
)
@click.option("--output", "-o", type=click.Path(), help="Output file path")
def report(scan_id: str, format: str, output: str | None):
    """
    Generate a report for a completed scan.

    Retrieves results for SCAN_ID and generates a report
    in the specified format.

    Examples:

        # Generate JSON report
        vantage security report SCAN-ABC123

        # Generate PDF report
        vantage security report SCAN-ABC123 -f pdf -o report.pdf
    """
    # This would typically fetch from storage/API
    click.echo(f"Fetching results for scan: {scan_id}")
    click.echo("Report generation for stored scans not yet implemented")
    click.echo("Use 'vantage security scan' to run a new scan with report output")


@security.command()
@click.argument("path", type=click.Path(exists=True))
def analyze(path: str):
    """
    Analyze project structure without full scan.

    Quick analysis to detect frameworks, count agents,
    and identify potential issues.

    Examples:

        vantage security analyze ./my-project
    """
    project_path = Path(path).resolve()

    click.echo(f"Analyzing: {project_path}")
    click.echo("")

    # Count Python files
    py_files = list(project_path.rglob("*.py"))
    click.echo(f"Python files: {len(py_files)}")

    # Detect frameworks
    frameworks = set()
    for py_file in py_files:
        try:
            content = py_file.read_text()
            if "langchain" in content.lower():
                frameworks.add("langchain")
            if "crewai" in content.lower():
                frameworks.add("crewai")
            if "autogen" in content.lower():
                frameworks.add("autogen")
            if "llama_index" in content.lower() or "llamaindex" in content.lower():
                frameworks.add("llamaindex")
            if "semantic_kernel" in content.lower():
                frameworks.add("semantic_kernel")
        except Exception:
            pass

    click.echo(f"Frameworks detected: {', '.join(frameworks) if frameworks else 'None'}")
    click.echo("")

    click.echo("For full security scan, run:")
    click.echo(f"  vantage security scan {path}")


@security.command()
def version():
    """Show version information."""
    click.echo("Vantage Security Scanner v1.0.0")
    click.echo("https://vantage.io")


@security.command()
def frameworks():
    """List supported AI agent frameworks."""
    click.echo("Supported Frameworks:")
    click.echo("")
    click.echo("  - LangChain / LangGraph")
    click.echo("  - CrewAI")
    click.echo("  - AutoGen (Microsoft)")
    click.echo("  - LlamaIndex")
    click.echo("  - Semantic Kernel (Microsoft)")
    click.echo("")
    click.echo("For framework-specific documentation, visit:")
    click.echo("  https://vantage.io/docs/frameworks")


def main():
    """Main entry point for CLI."""
    security()


if __name__ == "__main__":
    main()
