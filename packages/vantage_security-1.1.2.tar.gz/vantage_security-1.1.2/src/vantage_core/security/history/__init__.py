"""
Historical tracking for security scans.

This module provides:
- Scan history storage
- Trend analysis
- Mean time to remediation (MTTR) metrics
- Finding lifecycle tracking
"""

from vantage_core.security.history.models import (
    FindingHistory,
    RemediationTracking,
    ScanHistory,
    TrendData,
)
from vantage_core.security.history.tracker import (
    HistoryTracker,
    TrendAnalyzer,
)

__all__ = [
    "ScanHistory",
    "FindingHistory",
    "RemediationTracking",
    "TrendData",
    "HistoryTracker",
    "TrendAnalyzer",
]
