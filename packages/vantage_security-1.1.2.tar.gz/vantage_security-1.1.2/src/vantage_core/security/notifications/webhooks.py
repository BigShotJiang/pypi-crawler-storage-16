"""
Webhook notification system for Vantage Security Platform.

This module provides webhook registration, event delivery with retry logic,
HMAC-SHA256 payload signing, and delivery history tracking.
"""

import asyncio
import hashlib
import hmac
import json
from datetime import datetime
from enum import Enum
from typing import Any
from uuid import uuid4

import httpx
from pydantic import BaseModel, Field


# Custom exceptions
class WebhookError(Exception):
    """Base exception for webhook errors."""

    pass


class WebhookDeliveryError(WebhookError):
    """Exception raised when webhook delivery fails."""

    pass


class WebhookConfigurationError(WebhookError):
    """Exception raised when webhook configuration is invalid."""

    pass


# Webhook event types
class WebhookEvent(str, Enum):
    """Available webhook event types."""

    SCAN_STARTED = "scan.started"
    SCAN_COMPLETED = "scan.completed"
    SCAN_FAILED = "scan.failed"
    VULNERABILITY_CRITICAL = "vulnerability.critical"
    VULNERABILITY_HIGH = "vulnerability.high"
    SCORE_IMPROVED = "score.improved"
    SCORE_REGRESSION = "score.regression"
    POLICY_VIOLATION = "policy.violation"


WEBHOOK_EVENTS = [e.value for e in WebhookEvent]


# Retry configuration
MAX_RETRY_ATTEMPTS = 3
RETRY_DELAYS = [1, 2, 4]  # Exponential backoff in seconds


class WebhookConfig(BaseModel):
    """Webhook configuration."""

    id: str = Field(default_factory=lambda: str(uuid4()))
    project_id: str
    url: str
    secret: str | None = None
    events: list[str] = Field(default_factory=lambda: ["scan.completed", "scan.failed"])
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)


class DeliveryStatus(str, Enum):
    """Webhook delivery status."""

    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"
    RETRYING = "retrying"


class DeliveryResult(BaseModel):
    """Result of a webhook delivery attempt."""

    delivery_id: str
    webhook_id: str
    event_type: str
    status: DeliveryStatus
    response_code: int | None = None
    response_body: str | None = None
    attempt_number: int = 1
    error_message: str | None = None
    delivered_at: datetime | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


class Webhook(BaseModel):
    """Webhook registration."""

    id: str
    project_id: str
    url: str
    secret_hash: str | None = None
    events: list[str]
    is_active: bool = True
    created_at: datetime
    updated_at: datetime | None = None


class WebhookManager:
    """
    Manager for webhook registration and delivery.

    Handles:
    - Webhook registration and management
    - Event triggering and delivery
    - Retry logic with exponential backoff
    - HMAC-SHA256 payload signing
    - Delivery history tracking
    """

    def __init__(self, db_session=None):
        """Initialize webhook manager."""
        self.db = db_session
        self._webhooks: dict[str, WebhookConfig] = {}
        self._deliveries: dict[str, list[DeliveryResult]] = {}
        self._http_client = httpx.AsyncClient(timeout=30.0)

    async def close(self):
        """Close HTTP client."""
        await self._http_client.aclose()

    def register(
        self,
        project_id: str,
        url: str,
        events: list[str],
        secret: str | None = None,
    ) -> Webhook:
        """
        Register a new webhook.

        Args:
            project_id: Project identifier
            url: Webhook endpoint URL
            events: List of events to subscribe to
            secret: Secret for HMAC signing

        Returns:
            Registered webhook
        """
        # Validate URL
        if not url.startswith(("http://", "https://")):
            raise ValueError("Webhook URL must start with http:// or https://")

        # Validate events
        for event in events:
            if event not in WEBHOOK_EVENTS:
                raise ValueError(f"Invalid event type: {event}. Must be one of: {WEBHOOK_EVENTS}")

        webhook_id = str(uuid4())
        now = datetime.utcnow()

        # Hash secret if provided
        secret_hash = None
        if secret:
            secret_hash = hashlib.sha256(secret.encode()).hexdigest()

        config = WebhookConfig(
            id=webhook_id,
            project_id=project_id,
            url=url,
            secret=secret,
            events=events,
            is_active=True,
            created_at=now,
        )

        self._webhooks[webhook_id] = config
        self._deliveries[webhook_id] = []

        return Webhook(
            id=webhook_id,
            project_id=project_id,
            url=url,
            secret_hash=secret_hash,
            events=events,
            is_active=True,
            created_at=now,
        )

    def update(
        self,
        webhook_id: str,
        url: str | None = None,
        events: list[str] | None = None,
        secret: str | None = None,
        is_active: bool | None = None,
    ) -> Webhook | None:
        """
        Update a webhook configuration.

        Args:
            webhook_id: Webhook identifier
            url: New URL (optional)
            events: New events list (optional)
            secret: New secret (optional)
            is_active: Active status (optional)

        Returns:
            Updated webhook or None if not found
        """
        config = self._webhooks.get(webhook_id)
        if not config:
            return None

        if url is not None:
            config.url = url
        if events is not None:
            config.events = events
        if secret is not None:
            config.secret = secret
        if is_active is not None:
            config.is_active = is_active

        secret_hash = None
        if config.secret:
            secret_hash = hashlib.sha256(config.secret.encode()).hexdigest()

        return Webhook(
            id=config.id,
            project_id=config.project_id,
            url=config.url,
            secret_hash=secret_hash,
            events=config.events,
            is_active=config.is_active,
            created_at=config.created_at,
            updated_at=datetime.utcnow(),
        )

    def delete(self, webhook_id: str) -> bool:
        """
        Delete a webhook.

        Args:
            webhook_id: Webhook identifier

        Returns:
            True if deleted, False if not found
        """
        if webhook_id in self._webhooks:
            del self._webhooks[webhook_id]
            if webhook_id in self._deliveries:
                del self._deliveries[webhook_id]
            return True
        return False

    def get(self, webhook_id: str) -> Webhook | None:
        """
        Get a webhook by ID.

        Args:
            webhook_id: Webhook identifier

        Returns:
            Webhook or None if not found
        """
        config = self._webhooks.get(webhook_id)
        if not config:
            return None

        secret_hash = None
        if config.secret:
            secret_hash = hashlib.sha256(config.secret.encode()).hexdigest()

        return Webhook(
            id=config.id,
            project_id=config.project_id,
            url=config.url,
            secret_hash=secret_hash,
            events=config.events,
            is_active=config.is_active,
            created_at=config.created_at,
        )

    def get_project_webhooks(self, project_id: str) -> list[Webhook]:
        """
        Get all webhooks for a project.

        Args:
            project_id: Project identifier

        Returns:
            List of webhooks
        """
        webhooks = []
        for config in self._webhooks.values():
            if config.project_id == project_id:
                secret_hash = None
                if config.secret:
                    secret_hash = hashlib.sha256(config.secret.encode()).hexdigest()

                webhooks.append(
                    Webhook(
                        id=config.id,
                        project_id=config.project_id,
                        url=config.url,
                        secret_hash=secret_hash,
                        events=config.events,
                        is_active=config.is_active,
                        created_at=config.created_at,
                    )
                )

        return webhooks

    async def trigger(
        self,
        project_id: str,
        event: str,
        payload: dict[str, Any],
    ) -> list[DeliveryResult]:
        """
        Trigger webhooks for an event.

        Args:
            project_id: Project identifier
            event: Event type
            payload: Event payload

        Returns:
            List of delivery results
        """
        results = []

        # Find all active webhooks for this project and event
        for config in self._webhooks.values():
            if config.project_id == project_id and config.is_active and event in config.events:
                result = await self.deliver(config, event, payload)
                results.append(result)

        return results

    async def deliver(
        self,
        webhook: WebhookConfig,
        event: str,
        payload: dict[str, Any],
        attempt: int = 1,
    ) -> DeliveryResult:
        """
        Deliver a webhook payload with retry logic.

        Args:
            webhook: Webhook configuration
            event: Event type
            payload: Event payload
            attempt: Current attempt number

        Returns:
            Delivery result
        """
        delivery_id = str(uuid4())

        # Build full payload
        full_payload = {
            "event_type": event,
            "timestamp": datetime.utcnow().isoformat(),
            "delivery_id": delivery_id,
            "payload": payload,
        }

        payload_json = json.dumps(full_payload, default=str)

        # Build headers
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "Vantage-Webhook/1.0",
            "X-Vantage-Event": event,
            "X-Vantage-Delivery": delivery_id,
        }

        # Add HMAC signature if secret is configured
        if webhook.secret:
            signature = self._sign_payload(payload_json, webhook.secret)
            headers["X-Vantage-Signature-256"] = signature

        try:
            response = await self._http_client.post(
                webhook.url,
                content=payload_json,
                headers=headers,
            )

            result = DeliveryResult(
                delivery_id=delivery_id,
                webhook_id=webhook.id,
                event_type=event,
                status=(DeliveryStatus.SUCCESS if response.is_success else DeliveryStatus.FAILED),
                response_code=response.status_code,
                response_body=response.text[:1000] if response.text else None,
                attempt_number=attempt,
                delivered_at=datetime.utcnow() if response.is_success else None,
            )

            # Retry if failed and attempts remaining
            if not response.is_success and attempt < MAX_RETRY_ATTEMPTS:
                result.status = DeliveryStatus.RETRYING
                await asyncio.sleep(RETRY_DELAYS[attempt - 1])
                return await self.deliver(webhook, event, payload, attempt + 1)

        except Exception as e:
            result = DeliveryResult(
                delivery_id=delivery_id,
                webhook_id=webhook.id,
                event_type=event,
                status=DeliveryStatus.FAILED,
                attempt_number=attempt,
                error_message=str(e),
            )

            # Retry if attempts remaining
            if attempt < MAX_RETRY_ATTEMPTS:
                result.status = DeliveryStatus.RETRYING
                await asyncio.sleep(RETRY_DELAYS[attempt - 1])
                return await self.deliver(webhook, event, payload, attempt + 1)

        # Store delivery result
        if webhook.id not in self._deliveries:
            self._deliveries[webhook.id] = []
        self._deliveries[webhook.id].append(result)

        # Keep only last 100 deliveries
        if len(self._deliveries[webhook.id]) > 100:
            self._deliveries[webhook.id] = self._deliveries[webhook.id][-100:]

        return result

    async def test(self, webhook_id: str) -> DeliveryResult:
        """
        Send a test webhook delivery.

        Args:
            webhook_id: Webhook identifier

        Returns:
            Delivery result
        """
        config = self._webhooks.get(webhook_id)
        if not config:
            raise ValueError(f"Webhook not found: {webhook_id}")

        test_payload = {
            "test": True,
            "message": "This is a test webhook from Vantage",
            "project_id": config.project_id,
            "webhook_id": webhook_id,
        }

        return await self.deliver(config, "test", test_payload)

    def get_deliveries(
        self,
        webhook_id: str,
        limit: int = 50,
    ) -> list[DeliveryResult]:
        """
        Get delivery history for a webhook.

        Args:
            webhook_id: Webhook identifier
            limit: Maximum number of results

        Returns:
            List of delivery results
        """
        deliveries = self._deliveries.get(webhook_id, [])
        return deliveries[-limit:][::-1]  # Most recent first

    def _sign_payload(self, payload: str, secret: str) -> str:
        """
        Sign a payload with HMAC-SHA256.

        Args:
            payload: JSON payload string
            secret: Webhook secret

        Returns:
            Signature string
        """
        signature = hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()
        return f"sha256={signature}"

    @staticmethod
    def verify_signature(payload: str, signature: str, secret: str) -> bool:
        """
        Verify a webhook signature.

        Args:
            payload: JSON payload string
            signature: Received signature
            secret: Webhook secret

        Returns:
            True if signature is valid
        """
        expected = hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()
        expected_sig = f"sha256={expected}"

        return hmac.compare_digest(expected_sig, signature)


# Global webhook manager instance
webhook_manager = WebhookManager()


# Helper functions for triggering events


async def trigger_scan_started(
    project_id: str,
    scan_id: str,
    source_type: str,
    source_ref: str | None = None,
):
    """Trigger scan.started webhook event."""
    await webhook_manager.trigger(
        project_id=project_id,
        event=WebhookEvent.SCAN_STARTED.value,
        payload={
            "scan": {
                "id": scan_id,
                "source_type": source_type,
                "source_ref": source_ref,
            }
        },
    )


async def trigger_scan_completed(
    project_id: str,
    scan_id: str,
    atss_score: int,
    score_change: int,
    findings: dict[str, int],
    duration_seconds: int,
):
    """Trigger scan.completed webhook event."""
    await webhook_manager.trigger(
        project_id=project_id,
        event=WebhookEvent.SCAN_COMPLETED.value,
        payload={
            "scan": {
                "id": scan_id,
                "status": "completed",
                "atss_score": atss_score,
                "score_change": score_change,
                "findings": findings,
                "duration_seconds": duration_seconds,
            }
        },
    )


async def trigger_scan_failed(
    project_id: str,
    scan_id: str,
    error_message: str,
):
    """Trigger scan.failed webhook event."""
    await webhook_manager.trigger(
        project_id=project_id,
        event=WebhookEvent.SCAN_FAILED.value,
        payload={
            "scan": {
                "id": scan_id,
                "status": "failed",
                "error_message": error_message,
            }
        },
    )


async def trigger_vulnerability_found(
    project_id: str,
    scan_id: str,
    severity: str,
    finding_id: str,
    title: str,
    category: str,
):
    """Trigger vulnerability.critical or vulnerability.high webhook event."""
    event = (
        WebhookEvent.VULNERABILITY_CRITICAL.value
        if severity == "critical"
        else WebhookEvent.VULNERABILITY_HIGH.value
    )

    await webhook_manager.trigger(
        project_id=project_id,
        event=event,
        payload={
            "finding": {
                "id": finding_id,
                "severity": severity,
                "title": title,
                "category": category,
            },
            "scan_id": scan_id,
        },
    )


async def trigger_score_change(
    project_id: str,
    scan_id: str,
    old_score: int,
    new_score: int,
):
    """Trigger score.improved or score.regression webhook event."""
    change = new_score - old_score

    if change > 5:
        event = WebhookEvent.SCORE_IMPROVED.value
    elif change < -5:
        event = WebhookEvent.SCORE_REGRESSION.value
    else:
        return  # No significant change

    await webhook_manager.trigger(
        project_id=project_id,
        event=event,
        payload={
            "score": {
                "old_score": old_score,
                "new_score": new_score,
                "change": change,
            },
            "scan_id": scan_id,
        },
    )


# Export
__all__ = [
    "WebhookManager",
    "WebhookConfig",
    "WebhookEvent",
    "Webhook",
    "DeliveryResult",
    "DeliveryStatus",
    "WEBHOOK_EVENTS",
    "webhook_manager",
    "trigger_scan_started",
    "trigger_scan_completed",
    "trigger_scan_failed",
    "trigger_vulnerability_found",
    "trigger_score_change",
    # Exceptions
    "WebhookError",
    "WebhookDeliveryError",
    "WebhookConfigurationError",
]
