"""
Safe dispatch patterns to replace exec/eval usage.

This module provides secure alternatives to dynamic code execution
using dispatch tables and validated method lookup patterns.

Example usage:
    # Instead of:
    # exec(f"result = get_{function_field}_field(node_text)")

    # Use:
    dispatcher = FieldDispatcher()
    dispatcher.register('title', get_title_field)
    dispatcher.register('author', get_author_field)
    result = dispatcher.call('title', node_text)
"""

import re
from collections.abc import Callable
from functools import wraps
from typing import Any, TypeVar

T = TypeVar("T")


class DispatchError(Exception):
    """Error during dispatch operation."""

    pass


class UnknownMethodError(DispatchError):
    """Attempted to call an unregistered method."""

    pass


class InvalidMethodNameError(DispatchError):
    """Method name failed validation."""

    pass


class SafeDispatcher:
    """
    Safe function dispatch using explicit registration.

    Replaces dangerous patterns like:
        exec(f"result = get_{field}_field(data)")

    With secure lookup:
        result = dispatcher.call(field, data)

    Example:
        dispatcher = SafeDispatcher()
        dispatcher.register('title', get_title_field)
        dispatcher.register('author', get_author_field)

        # Safe call
        result = dispatcher.call('title', some_data)

        # Invalid calls raise UnknownMethodError
        result = dispatcher.call('unknown', data)  # raises
    """

    def __init__(
        self,
        name: str = "dispatcher",
        strict: bool = True,
        name_validator: Callable[[str], bool] | None = None,
    ):
        """
        Initialize dispatcher.

        Args:
            name: Name for logging/debugging
            strict: If True, raise on unknown methods. If False, return None.
            name_validator: Optional function to validate method names
        """
        self.name = name
        self.strict = strict
        self._methods: dict[str, Callable] = {}
        self._name_validator = name_validator or self._default_validator

    @staticmethod
    def _default_validator(name: str) -> bool:
        """Validate method name (no special chars, reasonable length)."""
        if not name or len(name) > 100:
            return False
        return bool(re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", name))

    def register(
        self,
        name: str,
        func: Callable,
        aliases: set[str] | None = None,
    ) -> "SafeDispatcher":
        """
        Register a function for dispatch.

        Args:
            name: The dispatch key
            func: The function to call
            aliases: Optional set of alternate names

        Returns:
            Self for chaining

        Raises:
            InvalidMethodNameError: If name fails validation
        """
        if not self._name_validator(name):
            raise InvalidMethodNameError(f"Invalid method name: {name}")

        self._methods[name] = func

        if aliases:
            for alias in aliases:
                if not self._name_validator(alias):
                    raise InvalidMethodNameError(f"Invalid alias: {alias}")
                self._methods[alias] = func

        return self

    def register_many(
        self,
        mapping: dict[str, Callable],
    ) -> "SafeDispatcher":
        """
        Register multiple functions at once.

        Args:
            mapping: Dict of name -> function

        Returns:
            Self for chaining
        """
        for name, func in mapping.items():
            self.register(name, func)
        return self

    def unregister(self, name: str) -> "SafeDispatcher":
        """
        Remove a registered function.

        Args:
            name: The dispatch key to remove

        Returns:
            Self for chaining
        """
        self._methods.pop(name, None)
        return self

    def call(self, name: str, *args, **kwargs) -> Any:
        """
        Dispatch to a registered function.

        Args:
            name: The dispatch key
            *args: Positional arguments to pass
            **kwargs: Keyword arguments to pass

        Returns:
            Result from the called function

        Raises:
            UnknownMethodError: If name not registered (in strict mode)
        """
        if not self._name_validator(name):
            raise InvalidMethodNameError(f"Invalid method name: {name}")

        func = self._methods.get(name)

        if func is None:
            if self.strict:
                available = ", ".join(sorted(self._methods.keys()))
                raise UnknownMethodError(
                    f"Unknown method '{name}' in {self.name}. " f"Available: {available}"
                )
            return None

        return func(*args, **kwargs)

    def has(self, name: str) -> bool:
        """Check if a method is registered."""
        return name in self._methods

    @property
    def methods(self) -> set[str]:
        """Get set of registered method names."""
        return set(self._methods.keys())

    def __contains__(self, name: str) -> bool:
        """Support 'in' operator."""
        return self.has(name)

    def __len__(self) -> int:
        """Number of registered methods."""
        return len(self._methods)


class AttributeDispatcher:
    """
    Safe attribute-based dispatch with allowlist.

    Replaces dangerous patterns like:
        method = getattr(obj, f"process_{type}")
        result = method(data)

    With validated lookup:
        dispatcher = AttributeDispatcher(obj, allowed={'process_text', 'process_image'})
        result = dispatcher.call('process_text', data)

    Example:
        class Processor:
            def process_text(self, data): ...
            def process_image(self, data): ...
            def _internal(self): ...  # Not exposed

        processor = Processor()
        dispatcher = AttributeDispatcher(
            processor,
            allowed={'process_text', 'process_image'}
        )

        # Safe calls
        dispatcher.call('process_text', data)  # Works
        dispatcher.call('_internal', data)     # Raises (not in allowlist)
    """

    def __init__(
        self,
        obj: Any,
        allowed: set[str],
        prefix: str = "",
        suffix: str = "",
    ):
        """
        Initialize attribute dispatcher.

        Args:
            obj: Object to dispatch method calls to
            allowed: Set of allowed method names
            prefix: Optional prefix to add to method names
            suffix: Optional suffix to add to method names
        """
        self.obj = obj
        self.allowed = frozenset(allowed)
        self.prefix = prefix
        self.suffix = suffix

        # Validate all allowed methods exist
        for name in allowed:
            full_name = f"{prefix}{name}{suffix}"
            if not hasattr(obj, full_name):
                raise AttributeError(f"Method '{full_name}' not found on {type(obj).__name__}")

    def call(self, name: str, *args, **kwargs) -> Any:
        """
        Call a method on the wrapped object.

        Args:
            name: The method name (without prefix/suffix)
            *args: Positional arguments
            **kwargs: Keyword arguments

        Returns:
            Result from the called method

        Raises:
            UnknownMethodError: If name not in allowlist
        """
        if name not in self.allowed:
            raise UnknownMethodError(
                f"Method '{name}' not in allowlist. " f"Allowed: {sorted(self.allowed)}"
            )

        full_name = f"{self.prefix}{name}{self.suffix}"
        method = getattr(self.obj, full_name)
        return method(*args, **kwargs)

    def has(self, name: str) -> bool:
        """Check if method is in allowlist."""
        return name in self.allowed


def dispatch_decorator(
    allowed_keys: set[str],
    key_param: str = "action",
    strict: bool = True,
):
    """
    Decorator to create dispatch-based methods.

    Example:
        class Handler:
            @dispatch_decorator({'create', 'update', 'delete'})
            def handle(self, action: str, data: dict):
                # dispatch_decorator routes to handle_create, handle_update, etc.
                pass

            def handle_create(self, data: dict): ...
            def handle_update(self, data: dict): ...
            def handle_delete(self, data: dict): ...

    Args:
        allowed_keys: Set of allowed action keys
        key_param: Name of the parameter containing the dispatch key
        strict: If True, raise on unknown keys

    Returns:
        Decorated method that dispatches based on key
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            # Extract the key parameter
            if key_param in kwargs:
                key = kwargs.pop(key_param)
            elif args:
                key = args[0]
                args = args[1:]
            else:
                raise TypeError(f"Missing required parameter: {key_param}")

            # Validate key
            if key not in allowed_keys:
                if strict:
                    raise UnknownMethodError(
                        f"Unknown {key_param}: '{key}'. " f"Allowed: {sorted(allowed_keys)}"
                    )
                return None

            # Find and call the handler
            handler_name = f"{func.__name__}_{key}"
            if not hasattr(self, handler_name):
                raise AttributeError(f"Handler method '{handler_name}' not found")

            handler = getattr(self, handler_name)
            return handler(*args, **kwargs)

        return wrapper

    return decorator


# Pre-built validators for common patterns
class NameValidators:
    """Collection of name validators for different use cases."""

    @staticmethod
    def alphanumeric(name: str) -> bool:
        """Allow only alphanumeric and underscore."""
        return bool(re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", name))

    @staticmethod
    def lowercase(name: str) -> bool:
        """Allow only lowercase letters and underscore."""
        return bool(re.match(r"^[a-z_][a-z0-9_]*$", name))

    @staticmethod
    def field_name(name: str) -> bool:
        """Validate as a typical field/column name."""
        if not name or len(name) > 64:
            return False
        return bool(re.match(r"^[a-z][a-z0-9_]*$", name))

    @staticmethod
    def safe_identifier(name: str) -> bool:
        """Strict validation for identifiers."""
        if not name or len(name) > 100:
            return False
        # No double underscores (prevent dunder access)
        if "__" in name:
            return False
        return bool(re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", name))


# Example: Field extractor pattern (replaces the LlamaIndex vulnerability)
class FieldExtractor:
    """
    Safe field extraction using dispatch pattern.

    Replaces vulnerable code like:
        exec(f"result = get_{function_field}_field(node_text)")

    With safe dispatch:
        extractor = FieldExtractor()
        result = extractor.extract('title', node_text)
    """

    def __init__(self):
        self._dispatcher = SafeDispatcher(
            name="FieldExtractor",
            strict=True,
            name_validator=NameValidators.field_name,
        )

    def register_extractor(
        self,
        field_name: str,
        extractor_func: Callable[[str], Any],
    ) -> "FieldExtractor":
        """
        Register a field extractor function.

        Args:
            field_name: Name of the field (e.g., 'title', 'author')
            extractor_func: Function that takes node_text and returns extracted value

        Returns:
            Self for chaining
        """
        self._dispatcher.register(field_name, extractor_func)
        return self

    def extract(self, field_name: str, node_text: str) -> Any:
        """
        Extract a field from node text.

        Args:
            field_name: Which field to extract
            node_text: The text to extract from

        Returns:
            Extracted value

        Raises:
            UnknownMethodError: If field_name not registered
        """
        return self._dispatcher.call(field_name, node_text)

    @property
    def available_fields(self) -> set[str]:
        """Get set of registered field names."""
        return self._dispatcher.methods
