"""
LlamaIndex Security Scanner.

Detects agents, tools, and indices in LlamaIndex-based projects
and identifies data access patterns.
"""

import ast
import re
import time
from pathlib import Path

from vantage_core.security.models import (
    AgentCommunication,
    CommunicationType,
    ContentType,
    MAASCategory,
    OWASPCategory,
    SecurityAgent,
    SecurityFinding,
    SecurityScanResult,
    SecurityTool,
    Severity,
    ToolCategory,
    TrustLevel,
    VulnerabilityCategory,
)
from vantage_core.security.scanners.base import SecurityScanner


class LlamaIndexSecurityScanner(SecurityScanner):
    """
    Security scanner for LlamaIndex framework.

    Detects:
    - OpenAIAgent, ReActAgent, and custom agents
    - QueryEngineTool, FunctionTool configurations
    - Index types and embedding models
    - Data access patterns
    """

    framework_name = "llamaindex"

    AGENT_TYPES = [
        "OpenAIAgent",
        "ReActAgent",
        "OpenAIAssistantAgent",
        "FunctionCallingAgent",
        "StructuredPlannerAgent",
    ]

    INDEX_TYPES = [
        "VectorStoreIndex",
        "ListIndex",
        "TreeIndex",
        "KeywordTableIndex",
        "KnowledgeGraphIndex",
    ]

    def scan(self, path: Path) -> SecurityScanResult:
        """Scan LlamaIndex project for security issues."""
        start_time = time.time()
        findings: list[SecurityFinding] = []
        agents: list[SecurityAgent] = []
        communications: list[AgentCommunication] = []

        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()

                file_agents = self._extract_agents_from_file(file_path, code)
                agents.extend(file_agents)

                file_communications = self._extract_communications(file_path, code)
                communications.extend(file_communications)

                findings.extend(self.check_hardcoded_secrets(code, str(file_path)))
                findings.extend(self.check_dangerous_code_patterns(code, str(file_path)))
                findings.extend(self._check_llamaindex_patterns(code, str(file_path)))

                for agent in file_agents:
                    agent_findings = self.get_vulnerabilities(agent)
                    findings.extend(agent_findings)

            except Exception:
                continue

        return self.create_scan_result(
            findings=findings,
            agents=agents,
            communications=communications,
            frameworks=["llamaindex"],
            start_time=start_time,
        )

    def _extract_communications(self, file_path: Path, code: str) -> list[AgentCommunication]:
        """Extract communications from LlamaIndex code."""
        communications: list[AgentCommunication] = []
        tree = ast.parse(code)

        class CommunicationVisitor(ast.NodeVisitor):
            def __init__(self):
                self.comms: list[AgentCommunication] = []
                self.assignments = {}  # var_name -> ast.Node

            def visit_Call(self, node: ast.Call) -> None:
                func_name = self._get_func_name(node)

                # ReActAgent.from_tools(tools=[...])
                if func_name == "from_tools":
                    # Check if it's called on an Agent class
                    if isinstance(node.func, ast.Attribute) and isinstance(
                        node.func.value, ast.Name
                    ):
                        if node.func.value.id in LlamaIndexSecurityScanner.AGENT_TYPES:
                            agent_name = f"llamaindex-{node.func.value.id}-{node.lineno}"

                            # Extract tools
                            tools = []
                            if len(node.args) > 0:
                                tools = self._extract_tool_names(node.args[0])
                            for keyword in node.keywords:
                                if keyword.arg == "tools":
                                    tools = self._extract_tool_names(keyword.value)

                            for tool in tools:
                                # Agent -> Tool
                                self.comms.append(
                                    AgentCommunication(
                                        source_id=agent_name,
                                        target_id=tool,
                                        communication_type=CommunicationType.DELEGATION.value,
                                        metadata={
                                            "protocol": "tool_call",
                                            "content_type": ContentType.TEXT.value,
                                            "file_path": str(file_path),
                                            "line_number": node.lineno,
                                        },
                                    )
                                )
                                # Tool -> Agent (Return)
                                self.comms.append(
                                    AgentCommunication(
                                        source_id=tool,
                                        target_id=agent_name,
                                        communication_type=CommunicationType.DIRECT.value,
                                        metadata={
                                            "protocol": "tool_return",
                                            "content_type": ContentType.TEXT.value,
                                            "file_path": str(file_path),
                                            "line_number": node.lineno,
                                        },
                                    )
                                )

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return node.func.attr
                return ""

            def visit_Assign(self, node: ast.Assign) -> None:
                # Track variable assignments to resolve references later
                if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                    self.assignments[node.targets[0].id] = node.value
                self.generic_visit(node)

            def _extract_tool_names(self, node: ast.AST) -> list[str]:
                names = []
                if isinstance(node, ast.Name):
                    # Resolve variable reference
                    if node.id in self.assignments:
                        return self._extract_tool_names(self.assignments[node.id])

                elif isinstance(node, ast.List):
                    for elt in node.elts:
                        if isinstance(elt, ast.Name):
                            names.append(elt.id)
                        elif isinstance(elt, ast.Call):
                            # Handle QueryEngineTool(...)
                            func_name = self._get_func_name(elt)
                            if func_name == "QueryEngineTool":
                                # Try to find metadata name
                                for kw in elt.keywords:
                                    if kw.arg == "metadata":
                                        # Handle ToolMetadata(name="...")
                                        if isinstance(kw.value, ast.Call):
                                            for meta_kw in kw.value.keywords:
                                                if meta_kw.arg == "name" and isinstance(
                                                    meta_kw.value, ast.Constant
                                                ):
                                                    names.append(meta_kw.value.value)
                                        # Handle metadata={"name": "..."} (if dict)
                                        elif isinstance(kw.value, ast.Dict):
                                            for k, v in zip(kw.value.keys, kw.value.values):
                                                if (
                                                    isinstance(k, ast.Constant)
                                                    and k.value == "name"
                                                ):
                                                    if isinstance(v, ast.Constant):
                                                        names.append(v.value)

                                if not names or names[-1] != "QueryEngineTool":
                                    # Fallback if name not found
                                    names.append("QueryEngineTool")
                return names

        visitor = CommunicationVisitor()
        visitor.visit(tree)
        return visitor.comms

    def get_agents(self, path: Path) -> list[SecurityAgent]:
        """Extract LlamaIndex agents from path."""
        agents: list[SecurityAgent] = []

        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()
                agents.extend(self._extract_agents_from_file(file_path, code))
            except Exception:
                continue

        return agents

    def get_vulnerabilities(self, agent: SecurityAgent) -> list[SecurityFinding]:
        """Analyze LlamaIndex agent for vulnerabilities."""
        findings: list[SecurityFinding] = []
        file_path = agent.file_path or "unknown"
        line_number = agent.line_number or 1

        if agent.system_prompt:
            finding = self.check_prompt_injection_risk(
                agent.system_prompt, file_path, line_number, agent.id
            )
            if finding:
                findings.append(finding)

        finding = self.check_excessive_agency(agent, file_path, line_number)
        if finding:
            findings.append(finding)

        # Check RAG-specific vulnerabilities
        findings.extend(self._check_rag_security(agent, file_path, line_number))

        return findings

    def _extract_agents_from_file(self, file_path: Path, code: str) -> list[SecurityAgent]:
        """Extract LlamaIndex agents from a single file."""
        agents: list[SecurityAgent] = []
        tree = ast.parse(code)

        class AgentVisitor(ast.NodeVisitor):
            def __init__(self, scanner: LlamaIndexSecurityScanner):
                self.scanner = scanner
                self.agents: list[SecurityAgent] = []

            def visit_Call(self, node: ast.Call) -> None:
                func_name = self._get_func_name(node)

                if func_name in LlamaIndexSecurityScanner.AGENT_TYPES:
                    agent = self._extract_agent_from_call(node, func_name)
                    if agent:
                        self.agents.append(agent)

                # Also detect query engines as they can be agent-like
                if "QueryEngine" in func_name or func_name == "SubQuestionQueryEngine":
                    agent = self._extract_query_engine(node, func_name)
                    if agent:
                        self.agents.append(agent)

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return node.func.attr
                return ""

            def _extract_agent_from_call(
                self, node: ast.Call, agent_type: str
            ) -> SecurityAgent | None:
                tools: list[SecurityTool] = []
                system_prompt = None

                for keyword in node.keywords:
                    if keyword.arg == "tools":
                        tools = self._extract_tools(keyword.value)
                    elif keyword.arg == "system_prompt":
                        if isinstance(keyword.value, ast.Constant):
                            system_prompt = str(keyword.value.value)

                agent_id = f"llamaindex-{agent_type}-{node.lineno}"

                return SecurityAgent(
                    id=agent_id,
                    name=agent_type,
                    framework="llamaindex",
                    system_prompt=system_prompt,
                    tools=tools,
                    file_path=str(file_path),
                    line_number=node.lineno,
                    trust_level=self.scanner.infer_trust_level(
                        {"name": agent_type, "system_prompt": system_prompt or ""}
                    ),
                    metadata={"agent_type": agent_type},
                )

            def _extract_query_engine(
                self, node: ast.Call, engine_type: str
            ) -> SecurityAgent | None:
                agent_id = f"llamaindex-{engine_type}-{node.lineno}"

                tools: list[SecurityTool] = []
                # Query engines have implicit data access
                tools.append(
                    SecurityTool(
                        name="index_query",
                        description="Query index/vector store",
                        categories=[ToolCategory.DATABASE],
                        required_trust_level=TrustLevel.INTERNAL,
                    )
                )

                return SecurityAgent(
                    id=agent_id,
                    name=engine_type,
                    framework="llamaindex",
                    tools=tools,
                    file_path=str(file_path),
                    line_number=node.lineno,
                    trust_level=TrustLevel.INTERNAL,
                    metadata={"type": "query_engine"},
                )

            def _extract_tools(self, node: ast.AST) -> list[SecurityTool]:
                tools: list[SecurityTool] = []
                if isinstance(node, ast.List):
                    for elt in node.elts:
                        if isinstance(elt, ast.Name):
                            tools.append(
                                SecurityTool(
                                    name=elt.id,
                                    description=f"LlamaIndex tool: {elt.id}",
                                    categories=[],
                                    required_trust_level=TrustLevel.INTERNAL,
                                )
                            )
                return tools

        visitor = AgentVisitor(self)
        visitor.visit(tree)
        return visitor.agents

    def _check_llamaindex_patterns(self, code: str, file_path: str) -> list[SecurityFinding]:
        """Check for LlamaIndex-specific security patterns."""
        findings: list[SecurityFinding] = []
        lines = code.split("\n")

        for i, line in enumerate(lines, 1):
            # Check for verbose mode
            if re.search(r"verbose\s*=\s*True", line):
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Verbose Mode Enabled",
                        description="Verbose mode can expose retrieval details and internal state.",
                        severity=Severity.LOW,
                        confidence=0.9,
                        owasp_category=OWASPCategory.LLM06,
                        category=VulnerabilityCategory.DATA_LEAKAGE,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Disable verbose mode in production.",
                        cwe_id="CWE-532",
                    )
                )

            # Check for unsafe SQL index
            if re.search(r"SQLStructStoreIndex|NLSQLTableQueryEngine", line):
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="SQL Query Engine Detected",
                        description="SQL query engines can be vulnerable to SQL injection through prompt manipulation.",
                        severity=Severity.HIGH,
                        confidence=0.8,
                        owasp_category=OWASPCategory.LLM01,
                        category=VulnerabilityCategory.PROMPT_INJECTION,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Implement query validation and use parameterized queries.",
                        cwe_id="CWE-89",
                    )
                )

            # Check for PandasQueryEngine (code execution risk)
            if "PandasQueryEngine" in line:
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Pandas Query Engine Code Execution",
                        description="PandasQueryEngine can execute arbitrary Python code.",
                        severity=Severity.HIGH,
                        confidence=0.9,
                        owasp_category=OWASPCategory.LLM02,
                        category=VulnerabilityCategory.CODE_EXECUTION,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Sandbox Pandas operations and validate generated code.",
                        cwe_id="CWE-94",
                    )
                )

            # Check for SimpleDirectoryReader with no filtering
            if re.search(r"SimpleDirectoryReader\s*(", line):
                # Look for exclude patterns
                context = "\n".join(lines[max(0, i - 2) : min(len(lines), i + 3)])
                if "exclude" not in context.lower() and "required_exts" not in context:
                    findings.append(
                        SecurityFinding(
                            id=SecurityFinding.generate_id(),
                            title="Directory Reader Without File Filtering",
                            description="SimpleDirectoryReader may ingest sensitive files without filtering.",
                            severity=Severity.MEDIUM,
                            confidence=0.7,
                            owasp_category=OWASPCategory.LLM06,
                            category=VulnerabilityCategory.DATA_LEAKAGE,
                            file_path=file_path,
                            line_number=i,
                            code_snippet=line.strip(),
                            recommendation="Use exclude patterns or required_exts to filter files.",
                            cwe_id="CWE-200",
                        )
                    )

        return findings

    def _check_rag_security(
        self, agent: SecurityAgent, file_path: str, line_number: int
    ) -> list[SecurityFinding]:
        """Check RAG-specific security issues."""
        findings: list[SecurityFinding] = []

        # Check for query engines with database access
        for tool in agent.tools:
            if ToolCategory.DATABASE in tool.categories:
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="RAG Agent with Data Store Access",
                        description=f"Agent '{agent.name}' has access to data stores which could be vulnerable to poisoning attacks.",
                        severity=Severity.MEDIUM,
                        confidence=0.7,
                        owasp_category=OWASPCategory.LLM03,
                        maas_category=MAASCategory.MAAS04,
                        category=VulnerabilityCategory.DATA_LEAKAGE,
                        file_path=file_path,
                        line_number=line_number,
                        code_snippet=f"Agent: {agent.name}, Tool: {tool.name}",
                        recommendation="Implement data validation and source verification for indexed content.",
                        agent_id=agent.id,
                        cwe_id="CWE-94",
                    )
                )

        return findings

    @classmethod
    def can_handle(cls, path: Path) -> bool:
        """Check if this scanner can handle LlamaIndex projects."""
        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    content = f.read()
                    if any(
                        x in content
                        for x in [
                            "from llama_index",
                            "import llama_index",
                            "from llamaindex",
                        ]
                    ):
                        return True
            except Exception:
                continue

        return False
