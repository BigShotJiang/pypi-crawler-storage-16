"""
Software Composition Analysis (SCA) Scanner.

Scans project dependencies for known vulnerabilities using OSV and other sources.
"""

import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import tomllib

from vantage_core.security.models import (
    OWASPCategory,
    SecurityFinding,
    Severity,
    VulnerabilityCategory,
)
from vantage_core.security.scanners.sca.osv_client import OSVClient, OSVVulnerability


@dataclass
class Dependency:
    """Represents a project dependency."""

    name: str
    version: str | None
    source_file: str
    line_number: int = 0
    is_dev: bool = False
    is_direct: bool = True


@dataclass
class DependencyVulnerability:
    """A vulnerability found in a dependency."""

    dependency: Dependency
    vulnerability: OSVVulnerability
    is_fixable: bool = False
    fixed_version: str | None = None


@dataclass
class SCAResult:
    """Results of SCA scan."""

    dependencies: list[Dependency]
    vulnerabilities: list[DependencyVulnerability]
    findings: list[SecurityFinding]
    scan_duration_ms: int
    ecosystems_scanned: list[str] = field(default_factory=list)


class SCAScanner:
    """
    Scanner for dependency vulnerabilities.

    Supports:
    - requirements.txt
    - pyproject.toml (PEP 621 and Poetry)
    - poetry.lock
    - Pipfile.lock
    """

    def __init__(self):
        """Initialize SCA scanner."""
        self._osv_client = OSVClient()

    def scan(self, path: Path) -> SCAResult:
        """
        Scan project for dependency vulnerabilities.

        Args:
            path: Path to project directory or dependency file

        Returns:
            SCAResult with findings
        """
        start_time = datetime.now()

        # Discover and parse dependencies
        dependencies = self._discover_dependencies(path)

        if not dependencies:
            return SCAResult(
                dependencies=[],
                vulnerabilities=[],
                findings=[],
                scan_duration_ms=0,
                ecosystems_scanned=["PyPI"],
            )

        # Query OSV for vulnerabilities
        vulnerabilities = self._check_vulnerabilities(dependencies)

        # Convert to findings
        findings = self._create_findings(vulnerabilities)

        duration_ms = int((datetime.now() - start_time).total_seconds() * 1000)

        return SCAResult(
            dependencies=dependencies,
            vulnerabilities=vulnerabilities,
            findings=findings,
            scan_duration_ms=duration_ms,
            ecosystems_scanned=["PyPI"],
        )

    def _discover_dependencies(self, path: Path) -> list[Dependency]:
        """Discover all dependencies in the project."""
        dependencies = []

        if path.is_file():
            # Single file
            deps = self._parse_dependency_file(path)
            dependencies.extend(deps)
        else:
            # Directory - look for dependency files
            for pattern in [
                "requirements*.txt",
                "pyproject.toml",
                "poetry.lock",
                "Pipfile.lock",
                "setup.py",
            ]:
                for dep_file in path.glob(pattern):
                    deps = self._parse_dependency_file(dep_file)
                    dependencies.extend(deps)

                # Also check subdirectories (but not too deep)
                for dep_file in path.glob(f"*/{pattern}"):
                    deps = self._parse_dependency_file(dep_file)
                    dependencies.extend(deps)

        # Deduplicate by name (keep first occurrence)
        seen = set()
        unique_deps = []
        for dep in dependencies:
            if dep.name.lower() not in seen:
                seen.add(dep.name.lower())
                unique_deps.append(dep)

        return unique_deps

    def _parse_dependency_file(self, path: Path) -> list[Dependency]:
        """Parse a dependency file."""
        if path.name == "pyproject.toml":
            return self._parse_pyproject(path)
        elif path.name.endswith(".txt"):
            return self._parse_requirements(path)
        elif path.name == "poetry.lock":
            return self._parse_poetry_lock(path)
        elif path.name == "Pipfile.lock":
            return self._parse_pipfile_lock(path)
        return []

    def _parse_requirements(self, path: Path) -> list[Dependency]:
        """Parse requirements.txt file."""
        dependencies = []

        try:
            content = path.read_text()
            lines = content.split("\n")

            for i, line in enumerate(lines, 1):
                line = line.strip()

                # Skip comments and empty lines
                if not line or line.startswith("#"):
                    continue

                # Skip -r includes and other flags
                if line.startswith("-"):
                    continue

                # Parse package specification
                dep = self._parse_requirement_line(line, str(path), i)
                if dep:
                    dependencies.append(dep)

        except Exception as e:
            print(f"Error parsing {path}: {e}")

        return dependencies

    def _parse_requirement_line(
        self, line: str, source_file: str, line_number: int
    ) -> Dependency | None:
        """Parse a single requirement line."""
        # Handle various formats:
        # package==1.0.0
        # package>=1.0.0
        # package[extra]==1.0.0
        # package @ URL

        # Remove comments
        if "#" in line:
            line = line.split("#")[0].strip()

        if not line:
            return None

        # Skip URL-based requirements for now
        if "@" in line:
            return None

        # Parse package name and version
        match = re.match(
            r"^([a-zA-Z0-9_-]+)(?:\[[^\]]+\])?\s*([<>=!~]+)?\s*([0-9a-zA-Z.*]+)?", line
        )

        if match:
            name = match.group(1)
            version = match.group(3) if match.group(3) else None

            return Dependency(
                name=name,
                version=version,
                source_file=source_file,
                line_number=line_number,
            )

        return None

    def _parse_pyproject(self, path: Path) -> list[Dependency]:
        """Parse pyproject.toml file."""
        dependencies = []

        try:
            content = path.read_text()
            data = tomllib.loads(content)

            # PEP 621 dependencies
            if "project" in data:
                project = data["project"]

                # Main dependencies
                for dep_str in project.get("dependencies", []):
                    dep = self._parse_pep508(dep_str, str(path))
                    if dep:
                        dependencies.append(dep)

                # Optional dependencies
                for group_deps in project.get("optional-dependencies", {}).values():
                    for dep_str in group_deps:
                        dep = self._parse_pep508(dep_str, str(path))
                        if dep:
                            dep.is_dev = True
                            dependencies.append(dep)

            # Poetry dependencies
            if "tool" in data and "poetry" in data["tool"]:
                poetry = data["tool"]["poetry"]

                for name, spec in poetry.get("dependencies", {}).items():
                    if name.lower() == "python":
                        continue
                    version = self._extract_poetry_version(spec)
                    dependencies.append(
                        Dependency(
                            name=name,
                            version=version,
                            source_file=str(path),
                        )
                    )

                for name, spec in poetry.get("dev-dependencies", {}).items():
                    version = self._extract_poetry_version(spec)
                    dependencies.append(
                        Dependency(
                            name=name,
                            version=version,
                            source_file=str(path),
                            is_dev=True,
                        )
                    )

        except Exception as e:
            print(f"Error parsing {path}: {e}")

        return dependencies

    def _parse_pep508(self, dep_str: str, source_file: str) -> Dependency | None:
        """Parse PEP 508 dependency specifier."""
        # package>=1.0.0
        # package[extra]>=1.0.0
        # package>=1.0.0; python_version >= "3.8"

        # Remove markers
        if ";" in dep_str:
            dep_str = dep_str.split(";")[0].strip()

        match = re.match(
            r"^([a-zA-Z0-9_-]+)(?:\[[^\]]+\])?\s*([<>=!~]+)?\s*([0-9a-zA-Z.*]+)?",
            dep_str,
        )

        if match:
            return Dependency(
                name=match.group(1),
                version=match.group(3) if match.group(3) else None,
                source_file=source_file,
            )

        return None

    def _extract_poetry_version(self, spec) -> str | None:
        """Extract version from Poetry dependency spec."""
        if isinstance(spec, str):
            # Remove ^ and ~ prefixes
            return spec.lstrip("^~")
        elif isinstance(spec, dict):
            version = spec.get("version", "")
            return version.lstrip("^~") if version else None
        return None

    def _parse_poetry_lock(self, path: Path) -> list[Dependency]:
        """Parse poetry.lock file."""
        dependencies = []

        try:
            content = path.read_text()
            data = tomllib.loads(content)

            for package in data.get("package", []):
                dependencies.append(
                    Dependency(
                        name=package["name"],
                        version=package.get("version"),
                        source_file=str(path),
                        is_direct=package.get("category") == "main",
                    )
                )

        except Exception as e:
            print(f"Error parsing {path}: {e}")

        return dependencies

    def _parse_pipfile_lock(self, path: Path) -> list[Dependency]:
        """Parse Pipfile.lock file."""
        import json

        dependencies = []

        try:
            content = path.read_text()
            data = json.loads(content)

            for name, spec in data.get("default", {}).items():
                version = spec.get("version", "").lstrip("=")
                dependencies.append(
                    Dependency(
                        name=name,
                        version=version if version else None,
                        source_file=str(path),
                    )
                )

            for name, spec in data.get("develop", {}).items():
                version = spec.get("version", "").lstrip("=")
                dependencies.append(
                    Dependency(
                        name=name,
                        version=version if version else None,
                        source_file=str(path),
                        is_dev=True,
                    )
                )

        except Exception as e:
            print(f"Error parsing {path}: {e}")

        return dependencies

    def _check_vulnerabilities(
        self, dependencies: list[Dependency]
    ) -> list[DependencyVulnerability]:
        """Check dependencies for vulnerabilities using OSV."""
        vulnerabilities = []

        # Prepare batch query
        packages = []
        for dep in dependencies:
            pkg = {
                "ecosystem": "PyPI",
                "name": dep.name,
            }
            if dep.version:
                pkg["version"] = dep.version
            packages.append(pkg)

        # Query OSV
        results = self._osv_client.query_batch(packages)

        # Match results with dependencies
        for dep in dependencies:
            vulns = results.get(dep.name, [])
            for vuln in vulns:
                # Determine if there's a fix available
                fixed_version = None
                if vuln.fixed_versions:
                    fixed_version = vuln.fixed_versions[0]

                vulnerabilities.append(
                    DependencyVulnerability(
                        dependency=dep,
                        vulnerability=vuln,
                        is_fixable=bool(fixed_version),
                        fixed_version=fixed_version,
                    )
                )

        return vulnerabilities

    def _create_findings(
        self, vulnerabilities: list[DependencyVulnerability]
    ) -> list[SecurityFinding]:
        """Convert vulnerabilities to security findings."""
        findings = []

        for vuln in vulnerabilities:
            # Map OSV severity to our severity
            severity = self._map_severity(vuln.vulnerability.severity)

            # Build recommendation
            recommendation = "Update the dependency to a patched version."
            if vuln.fixed_version:
                recommendation = (
                    f"Update {vuln.dependency.name} to version {vuln.fixed_version} or later."
                )

            # Build description
            description = vuln.vulnerability.summary or vuln.vulnerability.details
            if not description:
                description = (
                    f"Vulnerability {vuln.vulnerability.id} found in {vuln.dependency.name}"
                )

            # Add CVE if available
            cve_id = None
            for alias in vuln.vulnerability.aliases:
                if alias.startswith("CVE-"):
                    cve_id = alias
                    break

            # Store external references in metadata
            metadata = {
                "vulnerability_id": vuln.vulnerability.id,
                "references": vuln.vulnerability.references[:5],
                "aliases": vuln.vulnerability.aliases,
            }
            if cve_id:
                metadata["cve_id"] = cve_id

            findings.append(
                SecurityFinding(
                    id=SecurityFinding.generate_id(),
                    title=f"Vulnerable Dependency: {vuln.dependency.name}",
                    description=(description[:500] if len(description) > 500 else description),
                    severity=severity,
                    confidence=0.95,  # OSV data is highly reliable
                    owasp_category=OWASPCategory.LLM06,  # Using for supply chain
                    category=VulnerabilityCategory.SUPPLY_CHAIN,
                    file_path=vuln.dependency.source_file,
                    line_number=vuln.dependency.line_number,
                    code_snippet=f"{vuln.dependency.name}=={vuln.dependency.version or '*'}",
                    recommendation=recommendation,
                    cwe_id="CWE-1395",  # Dependency on Vulnerable Third-Party Component
                    severity_factors=[
                        f"Vulnerability ID: {vuln.vulnerability.id}",
                        f"CVSS Score: {vuln.vulnerability.cvss_score or 'N/A'}",
                        f"Package: {vuln.dependency.name}@{vuln.dependency.version or 'any'}",
                        f"Fix available: {'Yes' if vuln.is_fixable else 'No'}",
                    ],
                    detection_method="sca",
                    metadata=metadata,
                )
            )

        return findings

    def _map_severity(self, osv_severity: str) -> Severity:
        """Map OSV severity to our severity enum."""
        mapping = {
            "CRITICAL": Severity.CRITICAL,
            "HIGH": Severity.HIGH,
            "MEDIUM": Severity.MEDIUM,
            "LOW": Severity.LOW,
        }
        return mapping.get(osv_severity, Severity.MEDIUM)

    def close(self):
        """Close resources."""
        self._osv_client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
