"""
Security Scoring Module for Vantage.

Implements the Agent Topology Security Score (ATSS) system providing
quantifiable security metrics for multi-agent systems.
"""

from vantage_core.security.scoring.agent_risk import (
    AgentRiskProfile,
    AgentRiskScorer,
)
from vantage_core.security.scoring.aggregation import (
    AggregatedVulnerabilityScore,
    VulnerabilityAggregator,
)
from vantage_core.security.scoring.engine import (
    ATSSResult,
    ScoreComponent,
    SecurityScoringEngine,
)
from vantage_core.security.scoring.enhanced_engine import (
    EnhancedATSSResult,
    EnhancedScoringEngine,
    calculate_enhanced_atss,
)
from vantage_core.security.scoring.explanation import (
    ContributingFactor,
    ScoreExplainer,
    ScoreExplanation,
)
from vantage_core.security.scoring.grades import (
    GRADE_THRESHOLDS,
    GradeConverter,
    SecurityGrade,
)
from vantage_core.security.scoring.history import (
    ScoreHistoryEntry,
    ScoreHistoryTracker,
    ScoreTrend,
)
from vantage_core.security.scoring.pattern_score import (
    CommunicationPatternScorer,
    PatternScore,
    TopologyPattern,
)
from vantage_core.security.scoring.scorecard import (
    DimensionScore,
    RiskLevel,
    ScorecardGenerator,
    SecurityScorecard,
    generate_security_scorecard,
)
from vantage_core.security.scoring.severity_weighting import (
    ConfidenceFactors,
    ConfidenceInterval,
    ConfidenceIntervalCalculator,
    ExponentialPenaltyCalculator,
    GradeCapEnforcer,
    GradeCapResult,
    PenaltyBreakdown,
)
from vantage_core.security.scoring.trust_score import (
    TrustBoundaryScore,
    TrustBoundaryScorer,
)

__all__ = [
    # Core engine
    "SecurityScoringEngine",
    "ATSSResult",
    "ScoreComponent",
    # Aggregation
    "VulnerabilityAggregator",
    "AggregatedVulnerabilityScore",
    # Trust scoring
    "TrustBoundaryScorer",
    "TrustBoundaryScore",
    # Pattern scoring
    "CommunicationPatternScorer",
    "PatternScore",
    "TopologyPattern",
    # Agent risk
    "AgentRiskScorer",
    "AgentRiskProfile",
    # History
    "ScoreHistoryTracker",
    "ScoreHistoryEntry",
    "ScoreTrend",
    # Explanation
    "ScoreExplainer",
    "ScoreExplanation",
    "ContributingFactor",
    # Grades
    "GradeConverter",
    "SecurityGrade",
    "GRADE_THRESHOLDS",
    # Severity weighting
    "GradeCapEnforcer",
    "GradeCapResult",
    "ExponentialPenaltyCalculator",
    "PenaltyBreakdown",
    "ConfidenceIntervalCalculator",
    "ConfidenceInterval",
    "ConfidenceFactors",
    # Enhanced engine
    "EnhancedScoringEngine",
    "EnhancedATSSResult",
    "calculate_enhanced_atss",
    # Scorecard
    "ScorecardGenerator",
    "SecurityScorecard",
    "DimensionScore",
    "RiskLevel",
    "generate_security_scorecard",
]
