"""
Vulnerability Score Aggregation (US-121).

Aggregates finding severities with weighting by confidence and exploitability
to produce a normalized vulnerability score component.
"""

from dataclasses import dataclass, field

from vantage_core.security.models import (
    SecurityFinding,
    SecurityScanResult,
    Severity,
)

# Severity weights for aggregation
SEVERITY_WEIGHTS = {
    Severity.CRITICAL: 10.0,
    Severity.HIGH: 7.0,
    Severity.MEDIUM: 4.0,
    Severity.LOW: 1.5,
    Severity.INFO: 0.5,
}

# Exploitability factors based on category
EXPLOITABILITY_FACTORS = {
    "prompt_injection": 0.9,
    "privilege_escalation": 0.85,
    "data_leakage": 0.8,
    "code_execution": 0.95,
    "hardcoded_secret": 0.7,
    "trust_boundary_violation": 0.75,
    "excessive_agency": 0.6,
    "insecure_tool_use": 0.7,
    "configuration_weakness": 0.5,
    "unsafe_delegation": 0.65,
}


@dataclass
class AggregatedVulnerabilityScore:
    """
    Aggregated vulnerability score from all findings.

    Contains the final score (0-100 where higher is more secure)
    and breakdown by severity and category.
    """

    score: float  # 0-100, higher is more secure
    total_findings: int
    weighted_sum: float
    max_possible_risk: float
    by_severity: dict[str, int] = field(default_factory=dict)
    by_category: dict[str, float] = field(default_factory=dict)
    confidence: float = 1.0

    @property
    def risk_level(self) -> str:
        """Get risk level description."""
        if self.score >= 90:
            return "minimal"
        elif self.score >= 70:
            return "low"
        elif self.score >= 50:
            return "moderate"
        elif self.score >= 30:
            return "high"
        else:
            return "critical"


class VulnerabilityAggregator:
    """
    Aggregates vulnerability findings into a single score.

    Uses weighted scoring based on severity, confidence,
    and exploitability to produce a normalized 0-100 score.
    """

    def __init__(
        self,
        severity_weights: dict[Severity, float] | None = None,
        exploitability_factors: dict[str, float] | None = None,
    ):
        """
        Initialize the aggregator.

        Args:
            severity_weights: Custom severity weights
            exploitability_factors: Custom exploitability factors
        """
        self.severity_weights = severity_weights or SEVERITY_WEIGHTS
        self.exploitability_factors = exploitability_factors or EXPLOITABILITY_FACTORS

    def aggregate(
        self,
        findings: list[SecurityFinding],
        agent_count: int = 1,
    ) -> AggregatedVulnerabilityScore:
        """
        Aggregate findings into a vulnerability score.

        Args:
            findings: List of security findings
            agent_count: Number of agents scanned (for normalization)

        Returns:
            AggregatedVulnerabilityScore with final score and breakdown
        """
        if not findings:
            return AggregatedVulnerabilityScore(
                score=100.0,
                total_findings=0,
                weighted_sum=0.0,
                max_possible_risk=0.0,
                by_severity={sev.name: 0 for sev in Severity},
                confidence=1.0,
            )

        # Calculate weighted sum
        weighted_sum = 0.0
        by_severity: dict[str, int] = {sev.name: 0 for sev in Severity}
        by_category: dict[str, float] = {}
        total_confidence = 0.0

        for finding in findings:
            # Get base weight from severity
            base_weight = self.severity_weights.get(finding.severity, 1.0)

            # Apply confidence factor
            confidence_factor = finding.confidence

            # Apply exploitability factor
            category_name = (
                finding.category.value
                if hasattr(finding.category, "value")
                else str(finding.category)
            )
            exploitability = self.exploitability_factors.get(category_name, 0.5)

            # Calculate finding risk score
            finding_risk = base_weight * confidence_factor * exploitability
            weighted_sum += finding_risk

            # Track by severity
            by_severity[finding.severity.name] += 1

            # Track by category
            if category_name not in by_category:
                by_category[category_name] = 0.0
            by_category[category_name] += finding_risk

            total_confidence += confidence_factor

        # Calculate max possible risk (worst case)
        max_possible_risk = agent_count * self.severity_weights[Severity.CRITICAL] * 3
        max_possible_risk = max(max_possible_risk, 10.0)  # Minimum baseline

        # Normalize to 0-100 where higher is better (more secure)
        raw_risk_ratio = weighted_sum / max_possible_risk
        score = max(0.0, min(100.0, 100.0 * (1.0 - raw_risk_ratio)))

        # Calculate average confidence
        avg_confidence = total_confidence / len(findings) if findings else 1.0

        return AggregatedVulnerabilityScore(
            score=round(score, 2),
            total_findings=len(findings),
            weighted_sum=round(weighted_sum, 2),
            max_possible_risk=round(max_possible_risk, 2),
            by_severity=by_severity,
            by_category={k: round(v, 2) for k, v in by_category.items()},
            confidence=round(avg_confidence, 2),
        )

    def aggregate_from_result(
        self,
        scan_result: SecurityScanResult,
    ) -> AggregatedVulnerabilityScore:
        """
        Aggregate from a complete scan result.

        Args:
            scan_result: Security scan result

        Returns:
            AggregatedVulnerabilityScore
        """
        return self.aggregate(
            scan_result.findings,
            agent_count=max(scan_result.agents_scanned, 1),
        )

    def get_top_risk_findings(
        self,
        findings: list[SecurityFinding],
        limit: int = 5,
    ) -> list[tuple[SecurityFinding, float]]:
        """
        Get top risk findings by weighted score.

        Args:
            findings: List of findings
            limit: Maximum number to return

        Returns:
            List of (finding, risk_score) tuples
        """
        scored_findings = []

        for finding in findings:
            base_weight = self.severity_weights.get(finding.severity, 1.0)
            category_name = (
                finding.category.value
                if hasattr(finding.category, "value")
                else str(finding.category)
            )
            exploitability = self.exploitability_factors.get(category_name, 0.5)
            risk_score = base_weight * finding.confidence * exploitability
            scored_findings.append((finding, risk_score))

        # Sort by risk score descending
        scored_findings.sort(key=lambda x: x[1], reverse=True)

        return scored_findings[:limit]


def aggregate_vulnerability_scores(
    findings: list[SecurityFinding],
    agent_count: int = 1,
) -> AggregatedVulnerabilityScore:
    """
    Convenience function to aggregate vulnerability scores.

    Args:
        findings: List of security findings
        agent_count: Number of agents

    Returns:
        AggregatedVulnerabilityScore
    """
    aggregator = VulnerabilityAggregator()
    return aggregator.aggregate(findings, agent_count)
