"""
Score Thresholds & Grades (US-127).

Converts numeric scores to letter grades with configurable thresholds.
"""

from dataclasses import dataclass
from enum import Enum

# Default grade thresholds
GRADE_THRESHOLDS = {
    "A": 90,  # Excellent
    "B": 80,  # Good
    "C": 70,  # Acceptable
    "D": 60,  # Poor
    "F": 0,  # Failing
}


class SecurityGrade(str, Enum):
    """Security grade levels."""

    A = "A"
    B = "B"
    C = "C"
    D = "D"
    F = "F"


@dataclass
class GradeResult:
    """
    Result of grade conversion.

    Contains the grade, label, description, and color code.
    """

    grade: SecurityGrade
    label: str
    description: str
    color: str  # For UI display
    min_score: float
    max_score: float

    @property
    def is_passing(self) -> bool:
        """Check if grade is passing (C or better)."""
        return self.grade in [SecurityGrade.A, SecurityGrade.B, SecurityGrade.C]


# Grade metadata
GRADE_INFO = {
    SecurityGrade.A: {
        "label": "Excellent",
        "description": "Security posture is excellent with minimal risk",
        "color": "#22c55e",  # Green
    },
    SecurityGrade.B: {
        "label": "Good",
        "description": "Security posture is good with minor improvements possible",
        "color": "#84cc16",  # Lime
    },
    SecurityGrade.C: {
        "label": "Acceptable",
        "description": "Security posture is acceptable but requires attention",
        "color": "#eab308",  # Yellow
    },
    SecurityGrade.D: {
        "label": "Poor",
        "description": "Security posture is poor with significant vulnerabilities",
        "color": "#f97316",  # Orange
    },
    SecurityGrade.F: {
        "label": "Failing",
        "description": "Security posture is critical and requires immediate action",
        "color": "#ef4444",  # Red
    },
}


class GradeConverter:
    """
    Converts numeric security scores to letter grades.

    Supports configurable thresholds and provides grade metadata.
    """

    def __init__(
        self,
        thresholds: dict[str, int] | None = None,
    ):
        """
        Initialize the converter.

        Args:
            thresholds: Custom grade thresholds
        """
        self.thresholds = thresholds or GRADE_THRESHOLDS

    def convert(self, score: float) -> GradeResult:
        """
        Convert a numeric score to a letter grade.

        Args:
            score: Numeric score (0-100)

        Returns:
            GradeResult with grade and metadata
        """
        # Ensure score is in valid range
        score = max(0, min(100, score))

        # Determine grade based on thresholds
        if score >= self.thresholds["A"]:
            grade = SecurityGrade.A
            min_score = self.thresholds["A"]
            max_score = 100
        elif score >= self.thresholds["B"]:
            grade = SecurityGrade.B
            min_score = self.thresholds["B"]
            max_score = self.thresholds["A"] - 0.01
        elif score >= self.thresholds["C"]:
            grade = SecurityGrade.C
            min_score = self.thresholds["C"]
            max_score = self.thresholds["B"] - 0.01
        elif score >= self.thresholds["D"]:
            grade = SecurityGrade.D
            min_score = self.thresholds["D"]
            max_score = self.thresholds["C"] - 0.01
        else:
            grade = SecurityGrade.F
            min_score = 0
            max_score = self.thresholds["D"] - 0.01

        info = GRADE_INFO[grade]

        return GradeResult(
            grade=grade,
            label=info["label"],
            description=info["description"],
            color=info["color"],
            min_score=min_score,
            max_score=max_score,
        )

    def get_grade_letter(self, score: float) -> str:
        """
        Get just the letter grade for a score.

        Args:
            score: Numeric score (0-100)

        Returns:
            Letter grade string
        """
        return self.convert(score).grade.value

    def get_score_for_grade(self, grade: str) -> float:
        """
        Get minimum score required for a grade.

        Args:
            grade: Letter grade (A-F)

        Returns:
            Minimum score for that grade
        """
        return self.thresholds.get(grade.upper(), 0)

    def points_to_next_grade(self, score: float) -> tuple[str, float]:
        """
        Calculate points needed to reach next grade.

        Args:
            score: Current score

        Returns:
            Tuple of (next_grade, points_needed)
        """
        current = self.convert(score)

        # Already at A
        if current.grade == SecurityGrade.A:
            return ("A", 0)

        # Find next grade
        grades = ["F", "D", "C", "B", "A"]
        current_idx = grades.index(current.grade.value)
        next_grade = grades[current_idx + 1]
        next_threshold = self.thresholds[next_grade]

        points_needed = next_threshold - score

        return (next_grade, round(points_needed, 2))

    def validate_thresholds(self) -> list[str]:
        """
        Validate that thresholds are properly configured.

        Returns:
            List of validation error messages (empty if valid)
        """
        errors = []

        # Check all grades are present
        required = ["A", "B", "C", "D", "F"]
        for grade in required:
            if grade not in self.thresholds:
                errors.append(f"Missing threshold for grade {grade}")

        if errors:
            return errors

        # Check thresholds are in descending order
        if not (
            self.thresholds["A"]
            > self.thresholds["B"]
            > self.thresholds["C"]
            > self.thresholds["D"]
            > self.thresholds["F"]
        ):
            errors.append("Thresholds must be in descending order (A > B > C > D > F)")

        # Check values are in valid range
        for grade, threshold in self.thresholds.items():
            if not 0 <= threshold <= 100:
                errors.append(f"Threshold for {grade} must be between 0 and 100")

        return errors

    def get_all_grades(self) -> list[GradeResult]:
        """
        Get information for all grades.

        Returns:
            List of GradeResult for each grade
        """
        grades = []

        for letter in ["A", "B", "C", "D", "F"]:
            grade = SecurityGrade(letter)
            info = GRADE_INFO[grade]

            if letter == "A":
                min_score = self.thresholds["A"]
                max_score = 100
            elif letter == "F":
                min_score = 0
                max_score = self.thresholds["D"] - 0.01
            else:
                min_score = self.thresholds[letter]
                next_idx = ["F", "D", "C", "B", "A"].index(letter) + 1
                next_letter = ["F", "D", "C", "B", "A"][next_idx]
                max_score = self.thresholds[next_letter] - 0.01

            grades.append(
                GradeResult(
                    grade=grade,
                    label=info["label"],
                    description=info["description"],
                    color=info["color"],
                    min_score=min_score,
                    max_score=max_score,
                )
            )

        return grades


def score_to_grade(score: float) -> str:
    """
    Convenience function to convert score to grade letter.

    Args:
        score: Numeric score (0-100)

    Returns:
        Letter grade
    """
    converter = GradeConverter()
    return converter.get_grade_letter(score)


def get_grade_info(score: float) -> GradeResult:
    """
    Convenience function to get full grade information.

    Args:
        score: Numeric score (0-100)

    Returns:
        GradeResult with full details
    """
    converter = GradeConverter()
    return converter.convert(score)
