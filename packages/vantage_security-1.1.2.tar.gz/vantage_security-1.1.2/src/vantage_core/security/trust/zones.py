"""
Trust Zone Detection and Management.

US-114: Trust Zone Detection - Group agents into trust zones
and detect zone boundaries.

Uses clustering algorithms and communication patterns to identify
natural trust zone groupings in agent topologies.
"""

from dataclasses import dataclass, field
from typing import Any

from vantage_core.security.models import TrustLevel
from vantage_core.security.topology.graph import AgentGraph


@dataclass
class TrustZone:
    """
    Represents a trust zone containing agents at similar trust levels.

    Zones provide a logical grouping for security boundary enforcement.
    """

    id: str
    name: str
    trust_level: TrustLevel
    agents: list[str] = field(default_factory=list)  # Agent IDs
    description: str = ""
    is_custom: bool = False  # True if manually defined

    @property
    def size(self) -> int:
        """Get the number of agents in this zone."""
        return len(self.agents)

    def contains(self, agent_id: str) -> bool:
        """Check if an agent is in this zone."""
        return agent_id in self.agents


@dataclass
class ZoneConnection:
    """Represents a connection between two trust zones."""

    source_zone: str
    target_zone: str
    edge_count: int  # Number of edges between zones
    data_flows: list[str] = field(default_factory=list)  # Descriptions of data flows
    trust_differential: int = 0
    is_high_risk: bool = False


class ZoneDetector:
    """
    Detect and manage trust zones in agent topologies.

    Supports both automatic detection based on trust levels and
    custom zone definitions.
    """

    # Default zone names for each trust level
    DEFAULT_ZONE_NAMES = {
        TrustLevel.EXTERNAL: "External Zone",
        TrustLevel.USER: "User Interface Zone",
        TrustLevel.INTERNAL: "Internal Processing Zone",
        TrustLevel.PRIVILEGED: "Privileged Operations Zone",
        TrustLevel.SYSTEM: "System Core Zone",
    }

    def __init__(self, graph: AgentGraph):
        """
        Initialize the zone detector.

        Args:
            graph: AgentGraph to analyze
        """
        self.graph = graph
        self._zones: dict[str, TrustZone] = {}
        self._agent_zones: dict[str, str] = {}  # agent_id -> zone_id

    def detect_zones(self) -> list[TrustZone]:
        """
        Automatically detect trust zones based on agent trust levels.

        Returns:
            List of detected TrustZone objects
        """
        # Group agents by trust level
        level_groups: dict[TrustLevel, list[str]] = {level: [] for level in TrustLevel}

        for node in self.graph.nodes:
            level_groups[node.trust_level].append(node.id)

        # Create zones for non-empty groups
        zones = []
        for level, agents in level_groups.items():
            if agents:
                zone_id = f"zone_{level.name.lower()}"
                zone = TrustZone(
                    id=zone_id,
                    name=self.DEFAULT_ZONE_NAMES[level],
                    trust_level=level,
                    agents=agents,
                    description=f"Auto-detected zone for {level.name} trust level agents",
                )
                zones.append(zone)
                self._zones[zone_id] = zone

                # Update agent-zone mapping
                for agent_id in agents:
                    self._agent_zones[agent_id] = zone_id

        return zones

    def detect_zones_with_clustering(self, min_zone_size: int = 1) -> list[TrustZone]:
        """
        Detect zones using communication density clustering.

        Groups agents that communicate frequently together, while
        respecting trust level boundaries.

        Args:
            min_zone_size: Minimum agents required to form a zone

        Returns:
            List of detected TrustZone objects
        """
        # Start with basic trust level grouping
        base_zones = self.detect_zones()

        # For each base zone, check if it should be split
        refined_zones = []

        for zone in base_zones:
            if len(zone.agents) <= min_zone_size:
                refined_zones.append(zone)
                continue

            # Analyze internal connectivity
            subgroups = self._find_connected_subgroups(zone.agents)

            if len(subgroups) == 1:
                refined_zones.append(zone)
            else:
                # Split into multiple zones
                for i, subgroup in enumerate(subgroups):
                    if len(subgroup) >= min_zone_size:
                        sub_zone = TrustZone(
                            id=f"{zone.id}_{i}",
                            name=f"{zone.name} ({i + 1})",
                            trust_level=zone.trust_level,
                            agents=list(subgroup),
                            description=f"Sub-zone {i + 1} of {zone.name}",
                        )
                        refined_zones.append(sub_zone)
                        self._zones[sub_zone.id] = sub_zone

                        for agent_id in subgroup:
                            self._agent_zones[agent_id] = sub_zone.id

        return refined_zones

    def add_custom_zone(self, zone: TrustZone):
        """
        Add a custom-defined trust zone.

        Args:
            zone: Custom TrustZone to add
        """
        zone.is_custom = True
        self._zones[zone.id] = zone

        for agent_id in zone.agents:
            self._agent_zones[agent_id] = zone.id

    def get_zone(self, zone_id: str) -> TrustZone | None:
        """Get a zone by ID."""
        return self._zones.get(zone_id)

    def get_agent_zone(self, agent_id: str) -> TrustZone | None:
        """Get the zone containing an agent."""
        zone_id = self._agent_zones.get(agent_id)
        if zone_id:
            return self._zones.get(zone_id)
        return None

    def get_all_zones(self) -> list[TrustZone]:
        """Get all detected/defined zones."""
        return list(self._zones.values())

    def get_zone_connections(self) -> list[ZoneConnection]:
        """
        Analyze connections between zones.

        Returns:
            List of ZoneConnection objects describing inter-zone communication
        """
        connections: dict[tuple[str, str], ZoneConnection] = {}

        for edge in self.graph.edges:
            source_zone_id = self._agent_zones.get(edge.source_id)
            target_zone_id = self._agent_zones.get(edge.target_id)

            if not source_zone_id or not target_zone_id:
                continue

            if source_zone_id == target_zone_id:
                continue  # Skip intra-zone edges

            key = (source_zone_id, target_zone_id)

            if key not in connections:
                source_zone = self._zones[source_zone_id]
                target_zone = self._zones[target_zone_id]

                trust_diff = source_zone.trust_level.value - target_zone.trust_level.value

                connections[key] = ZoneConnection(
                    source_zone=source_zone_id,
                    target_zone=target_zone_id,
                    edge_count=0,
                    trust_differential=trust_diff,
                    is_high_risk=abs(trust_diff) > 1,
                )

            connections[key].edge_count += 1
            connections[key].data_flows.append(
                f"{edge.source_id} -> {edge.target_id} ({edge.data_sensitivity})"
            )

        return list(connections.values())

    def get_boundary_zones(self) -> list[tuple[TrustZone, TrustZone]]:
        """
        Get pairs of zones that share a boundary.

        Returns:
            List of (zone1, zone2) tuples representing boundaries
        """
        boundaries = set()

        for conn in self.get_zone_connections():
            zone1 = self._zones.get(conn.source_zone)
            zone2 = self._zones.get(conn.target_zone)

            if zone1 and zone2:
                # Normalize order
                if zone1.id < zone2.id:
                    boundaries.add((zone1.id, zone2.id))
                else:
                    boundaries.add((zone2.id, zone1.id))

        return [(self._zones[z1], self._zones[z2]) for z1, z2 in boundaries]

    def get_zone_metrics(self, zone_id: str) -> dict[str, Any]:
        """
        Get metrics for a specific zone.

        Args:
            zone_id: Zone identifier

        Returns:
            Dictionary of zone metrics
        """
        zone = self._zones.get(zone_id)
        if not zone:
            return {}

        # Calculate internal connectivity
        internal_edges = 0
        external_edges = 0

        for edge in self.graph.edges:
            source_in_zone = edge.source_id in zone.agents
            target_in_zone = edge.target_id in zone.agents

            if source_in_zone and target_in_zone:
                internal_edges += 1
            elif source_in_zone or target_in_zone:
                external_edges += 1

        # Calculate density
        max_internal = len(zone.agents) * (len(zone.agents) - 1)
        density = internal_edges / max_internal if max_internal > 0 else 0

        return {
            "zone_id": zone_id,
            "name": zone.name,
            "size": len(zone.agents),
            "trust_level": zone.trust_level.name,
            "internal_edges": internal_edges,
            "external_edges": external_edges,
            "density": density,
            "isolation_score": 1 - (external_edges / (internal_edges + external_edges + 1)),
        }

    def suggest_zone_improvements(self) -> list[dict[str, Any]]:
        """
        Suggest improvements to zone definitions.

        Returns:
            List of improvement suggestions
        """
        suggestions = []

        # Check for overly connected zones
        for zone_id, zone in self._zones.items():
            metrics = self.get_zone_metrics(zone_id)

            # Low isolation suggests agents should be moved
            if metrics.get("isolation_score", 1) < 0.3 and zone.size > 1:
                suggestions.append(
                    {
                        "type": "low_isolation",
                        "zone_id": zone_id,
                        "message": f"Zone '{zone.name}' has low isolation ({metrics['isolation_score']:.2f}). "
                        "Consider splitting or reassigning agents.",
                        "severity": "medium",
                    }
                )

            # Check for mismatched trust levels
            for agent_id in zone.agents:
                node = self.graph.get_node(agent_id)
                if node and node.trust_level != zone.trust_level:
                    suggestions.append(
                        {
                            "type": "trust_mismatch",
                            "zone_id": zone_id,
                            "agent_id": agent_id,
                            "message": f"Agent '{node.name}' has trust level {node.trust_level.name} "
                            f"but is in zone with level {zone.trust_level.name}.",
                            "severity": "high",
                        }
                    )

        # Check for high-risk cross-zone connections
        for conn in self.get_zone_connections():
            if conn.is_high_risk:
                suggestions.append(
                    {
                        "type": "high_risk_connection",
                        "source_zone": conn.source_zone,
                        "target_zone": conn.target_zone,
                        "message": f"High-risk connection between zones with trust differential of {conn.trust_differential}. "
                        f"Consider adding validation layer.",
                        "severity": "high",
                    }
                )

        return suggestions

    def _find_connected_subgroups(self, agent_ids: list[str]) -> list[set[str]]:
        """
        Find connected subgroups within a set of agents.

        Uses depth-first search to identify connected components.
        """
        agent_set = set(agent_ids)
        visited = set()
        subgroups = []

        def dfs(agent_id: str, group: set[str]):
            if agent_id in visited or agent_id not in agent_set:
                return
            visited.add(agent_id)
            group.add(agent_id)

            # Check neighbors
            for neighbor in self.graph.get_neighbors(agent_id):
                if neighbor in agent_set:
                    dfs(neighbor, group)

            # Check predecessors
            for predecessor in self.graph.get_predecessors(agent_id):
                if predecessor in agent_set:
                    dfs(predecessor, group)

        for agent_id in agent_ids:
            if agent_id not in visited:
                group: set[str] = set()
                dfs(agent_id, group)
                if group:
                    subgroups.append(group)

        return subgroups

    def to_dict(self) -> dict[str, Any]:
        """Export zones to dictionary format."""
        return {
            "zones": [
                {
                    "id": zone.id,
                    "name": zone.name,
                    "trust_level": zone.trust_level.name,
                    "agents": zone.agents,
                    "size": zone.size,
                    "is_custom": zone.is_custom,
                }
                for zone in self._zones.values()
            ],
            "connections": [
                {
                    "source": conn.source_zone,
                    "target": conn.target_zone,
                    "edge_count": conn.edge_count,
                    "trust_differential": conn.trust_differential,
                    "is_high_risk": conn.is_high_risk,
                }
                for conn in self.get_zone_connections()
            ],
        }


def detect_trust_zones(graph: AgentGraph) -> list[TrustZone]:
    """
    Convenience function to detect trust zones.

    Args:
        graph: AgentGraph to analyze

    Returns:
        List of detected TrustZone objects
    """
    detector = ZoneDetector(graph)
    return detector.detect_zones()
