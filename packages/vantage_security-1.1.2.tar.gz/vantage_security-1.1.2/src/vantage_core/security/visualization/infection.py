"""
Infection Visualization Data Generator (US-407).

Generates animation timeline data for frontend rendering of infection
spread simulations including frame-by-frame state transitions.
"""

import json
import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from vantage_core.security.simulation.propagation import (
    AgentState,
    InfectionState,
    SimulationResult,
)
from vantage_core.security.topology.graph import AgentGraph


class ExportFormat(str, Enum):
    """Supported export formats."""

    JSON = "json"
    CSV = "csv"


@dataclass
class Position:
    """2D position for visualization."""

    x: float
    y: float

    def to_dict(self) -> dict[str, float]:
        return {"x": self.x, "y": self.y}


@dataclass
class InfectionEvent:
    """
    Represents an infection transmission event.

    Captures source, target, and timing of infection spread.
    """

    source_agent: str
    target_agent: str
    timestamp_ms: int
    frame_number: int
    transmission_probability: float
    payload_type: str = "self_replicating"

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_agent": self.source_agent,
            "target_agent": self.target_agent,
            "timestamp_ms": self.timestamp_ms,
            "frame_number": self.frame_number,
            "transmission_probability": self.transmission_probability,
            "payload_type": self.payload_type,
        }


@dataclass
class AgentVisualState:
    """
    Visual state of an agent for a single frame.

    Includes state, color, and hover information.
    """

    agent_id: str
    state: InfectionState
    color: str
    infected_at: int
    infected_by: str | None
    position: Position

    def to_dict(self) -> dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "state": self.state.value,
            "color": self.color,
            "infected_at": self.infected_at,
            "infected_by": self.infected_by,
            "position": self.position.to_dict(),
        }


@dataclass
class FrameData:
    """
    Data for a single animation frame.

    Contains agent states and active infections for rendering.
    """

    frame_number: int
    timestamp_ms: int
    agent_states: dict[str, AgentVisualState]
    active_infections: list[InfectionEvent]
    metrics: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "frame_number": self.frame_number,
            "timestamp_ms": self.timestamp_ms,
            "agent_states": {k: v.to_dict() for k, v in self.agent_states.items()},
            "active_infections": [e.to_dict() for e in self.active_infections],
            "metrics": self.metrics,
        }


@dataclass
class AnimationData:
    """
    Complete animation data for infection visualization.

    Contains all frames, positions, and metadata for rendering.
    """

    frames: list[FrameData]
    duration_ms: int
    fps: int
    agent_positions: dict[str, Position]
    entry_point: str
    total_agents: int
    blast_radius: int
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "frames": [f.to_dict() for f in self.frames],
            "duration_ms": self.duration_ms,
            "fps": self.fps,
            "agent_positions": {k: v.to_dict() for k, v in self.agent_positions.items()},
            "entry_point": self.entry_point,
            "total_agents": self.total_agents,
            "blast_radius": self.blast_radius,
            "metadata": self.metadata,
        }


class InfectionVisualizer:
    """
    Generates animation data for infection spread visualization.

    Converts simulation results into frame-by-frame data for
    frontend rendering with D3.js or similar libraries.
    """

    # State color mapping per UX design
    STATE_COLORS = {
        InfectionState.SUSCEPTIBLE: "#4CAF50",  # Green
        InfectionState.EXPOSED: "#FFC107",  # Yellow
        InfectionState.INFECTED: "#F44336",  # Red
        InfectionState.CONTAINED: "#2196F3",  # Blue
    }

    def __init__(
        self,
        fps: int = 30,
        ms_per_step: int = 500,
    ):
        """
        Initialize the visualizer.

        Args:
            fps: Frames per second for animation
            ms_per_step: Milliseconds per simulation step
        """
        self.fps = fps
        self.ms_per_step = ms_per_step
        self._animation_data: AnimationData | None = None

    def generate_animation_data(
        self,
        simulation_result: SimulationResult,
        graph: AgentGraph | None = None,
        payload_type: str = "self_replicating",
    ) -> AnimationData:
        """
        Generate complete animation data from simulation results.

        Args:
            simulation_result: Result from infection simulation
            graph: Optional graph for position calculation
            payload_type: Type of payload used in simulation

        Returns:
            AnimationData ready for frontend rendering
        """
        # Calculate agent positions
        positions = self._calculate_positions(
            simulation_result.time_steps,
            graph,
        )

        # Generate frames
        frames = []
        total_ms = 0

        for step_idx, step_states in enumerate(simulation_result.time_steps):
            # Find infection events in this step
            infections = self._extract_infection_events(
                step_idx,
                step_states,
                simulation_result.time_steps[step_idx - 1] if step_idx > 0 else {},
                total_ms,
                payload_type,
            )

            # Create frame with visual states
            agent_visual_states = {}
            for agent_id, state in step_states.items():
                agent_visual_states[agent_id] = AgentVisualState(
                    agent_id=agent_id,
                    state=state.state,
                    color=self.STATE_COLORS.get(state.state, "#9E9E9E"),
                    infected_at=state.infected_at,
                    infected_by=state.infected_by,
                    position=positions.get(agent_id, Position(0, 0)),
                )

            # Calculate frame metrics
            metrics = self._calculate_frame_metrics(step_states)

            frame = FrameData(
                frame_number=step_idx,
                timestamp_ms=total_ms,
                agent_states=agent_visual_states,
                active_infections=infections,
                metrics=metrics,
            )
            frames.append(frame)
            total_ms += self.ms_per_step

        # Create animation data
        self._animation_data = AnimationData(
            frames=frames,
            duration_ms=total_ms,
            fps=self.fps,
            agent_positions=positions,
            entry_point=simulation_result.entry_point,
            total_agents=len(positions),
            blast_radius=simulation_result.blast_radius,
            metadata={
                "total_steps": simulation_result.total_steps,
                "peak_infection": simulation_result.peak_infection,
                "peak_step": simulation_result.peak_step,
                "containment_points": simulation_result.containment_points,
                "payload_type": payload_type,
            },
        )

        return self._animation_data

    def get_frame(self, frame_number: int) -> FrameData | None:
        """
        Get a specific frame by number.

        Args:
            frame_number: Zero-based frame index

        Returns:
            FrameData or None if not found
        """
        if not self._animation_data:
            return None

        if 0 <= frame_number < len(self._animation_data.frames):
            return self._animation_data.frames[frame_number]

        return None

    def get_frame_range(
        self,
        start: int,
        end: int,
    ) -> list[FrameData]:
        """
        Get a range of frames for incremental loading.

        Args:
            start: Start frame index (inclusive)
            end: End frame index (exclusive)

        Returns:
            List of FrameData in range
        """
        if not self._animation_data:
            return []

        return self._animation_data.frames[start:end]

    def export_timeline(self, format: ExportFormat | str) -> bytes:
        """
        Export animation timeline in specified format.

        Args:
            format: Export format (json, csv)

        Returns:
            Exported data as bytes
        """
        if not self._animation_data:
            raise ValueError("No animation data generated. Call generate_animation_data first.")

        if isinstance(format, str):
            format = ExportFormat(format.lower())

        if format == ExportFormat.JSON:
            return json.dumps(
                self._animation_data.to_dict(),
                indent=2,
            ).encode("utf-8")

        elif format == ExportFormat.CSV:
            return self._export_csv()

        else:
            raise ValueError(f"Unsupported format: {format}")

    def get_hover_data(
        self,
        agent_id: str,
        frame_number: int,
    ) -> dict[str, Any] | None:
        """
        Get hover detail data for an agent at a specific frame.

        Args:
            agent_id: Agent identifier
            frame_number: Frame number

        Returns:
            Hover data dictionary or None
        """
        frame = self.get_frame(frame_number)
        if not frame:
            return None

        agent_state = frame.agent_states.get(agent_id)
        if not agent_state:
            return None

        return {
            "agent_id": agent_id,
            "state": agent_state.state.value,
            "state_label": self._get_state_label(agent_state.state),
            "color": agent_state.color,
            "infected_at": (
                f"Step {agent_state.infected_at}"
                if agent_state.infected_at >= 0
                else "Not infected"
            ),
            "infected_by": agent_state.infected_by or "N/A",
            "position": agent_state.position.to_dict(),
            "is_entry_point": self._animation_data and agent_id == self._animation_data.entry_point,
        }

    def generate_summary(self) -> dict[str, Any]:
        """
        Generate a summary of the animation data.

        Returns:
            Summary dictionary with key metrics
        """
        if not self._animation_data:
            return {}

        return {
            "total_frames": len(self._animation_data.frames),
            "duration_ms": self._animation_data.duration_ms,
            "fps": self._animation_data.fps,
            "entry_point": self._animation_data.entry_point,
            "total_agents": self._animation_data.total_agents,
            "blast_radius": self._animation_data.blast_radius,
            "infection_rate": (
                self._animation_data.blast_radius / self._animation_data.total_agents
                if self._animation_data.total_agents > 0
                else 0
            ),
            "containment_points": self._animation_data.metadata.get("containment_points", []),
        }

    def _calculate_positions(
        self,
        time_steps: list[dict[str, AgentState]],
        graph: AgentGraph | None = None,
    ) -> dict[str, Position]:
        """Calculate positions for all agents."""
        positions = {}

        if not time_steps:
            return positions

        # Get agent IDs from first time step
        agent_ids = list(time_steps[0].keys())

        if graph:
            # Use graph layout if available
            positions = self._layout_from_graph(graph, agent_ids)
        else:
            # Circular layout as fallback
            positions = self._circular_layout(agent_ids)

        return positions

    def _circular_layout(
        self,
        agent_ids: list[str],
        radius: float = 200,
        center_x: float = 300,
        center_y: float = 300,
    ) -> dict[str, Position]:
        """Arrange agents in a circle."""
        positions = {}
        n = len(agent_ids)

        for i, agent_id in enumerate(agent_ids):
            angle = (2 * math.pi * i) / n
            x = center_x + radius * math.cos(angle)
            y = center_y + radius * math.sin(angle)
            positions[agent_id] = Position(x=x, y=y)

        return positions

    def _layout_from_graph(
        self,
        graph: AgentGraph,
        agent_ids: list[str],
    ) -> dict[str, Position]:
        """Use graph structure for hierarchical layout."""
        positions = {}

        # Group by trust level for hierarchical layout
        trust_groups: dict[int, list[str]] = {}
        for node in graph.nodes:
            if node.id in agent_ids:
                level = node.trust_level.value
                if level not in trust_groups:
                    trust_groups[level] = []
                trust_groups[level].append(node.id)

        # Position by trust level (rows) and index within level (columns)
        row_height = 120
        col_width = 150
        start_y = 100

        for level in sorted(trust_groups.keys()):
            agents_at_level = trust_groups[level]
            y = start_y + (level * row_height)

            # Center agents horizontally
            total_width = len(agents_at_level) * col_width
            start_x = 300 - (total_width / 2)

            for i, agent_id in enumerate(agents_at_level):
                x = start_x + (i * col_width) + (col_width / 2)
                positions[agent_id] = Position(x=x, y=y)

        return positions

    def _extract_infection_events(
        self,
        step_idx: int,
        current_states: dict[str, AgentState],
        previous_states: dict[str, AgentState],
        timestamp_ms: int,
        payload_type: str,
    ) -> list[InfectionEvent]:
        """Extract infection events that occurred in this step."""
        events = []

        for agent_id, state in current_states.items():
            # Check if this agent was infected in this step
            if state.infected_at == step_idx and state.infected_by:
                # Estimate transmission probability
                prob = 0.7  # Default

                events.append(
                    InfectionEvent(
                        source_agent=state.infected_by,
                        target_agent=agent_id,
                        timestamp_ms=timestamp_ms,
                        frame_number=step_idx,
                        transmission_probability=prob,
                        payload_type=payload_type,
                    )
                )

        return events

    def _calculate_frame_metrics(
        self,
        step_states: dict[str, AgentState],
    ) -> dict[str, Any]:
        """Calculate metrics for a single frame."""
        susceptible = 0
        exposed = 0
        infected = 0
        contained = 0

        for state in step_states.values():
            if state.state == InfectionState.SUSCEPTIBLE:
                susceptible += 1
            elif state.state == InfectionState.EXPOSED:
                exposed += 1
            elif state.state == InfectionState.INFECTED:
                infected += 1
            elif state.state == InfectionState.CONTAINED:
                contained += 1

        total = len(step_states)
        return {
            "susceptible": susceptible,
            "exposed": exposed,
            "infected": infected,
            "contained": contained,
            "infection_rate": (infected + exposed) / total if total > 0 else 0,
        }

    def _export_csv(self) -> bytes:
        """Export animation data as CSV."""
        if not self._animation_data:
            return b""

        lines = ["frame,timestamp_ms,agent_id,state,infected_at,infected_by"]

        for frame in self._animation_data.frames:
            for agent_id, state in frame.agent_states.items():
                line = f"{frame.frame_number},{frame.timestamp_ms},{agent_id},{state.state.value},{state.infected_at},{state.infected_by or ''}"
                lines.append(line)

        return "\n".join(lines).encode("utf-8")

    def _get_state_label(self, state: InfectionState) -> str:
        """Get human-readable label for state."""
        labels = {
            InfectionState.SUSCEPTIBLE: "Not yet affected",
            InfectionState.EXPOSED: "Received malicious message",
            InfectionState.INFECTED: "Actively propagating",
            InfectionState.CONTAINED: "Blocked by defense",
        }
        return labels.get(state, "Unknown")


def generate_infection_animation(
    simulation_result: SimulationResult,
    graph: AgentGraph | None = None,
    fps: int = 30,
) -> AnimationData:
    """
    Convenience function to generate infection animation data.

    Args:
        simulation_result: Result from infection simulation
        graph: Optional graph for position calculation
        fps: Frames per second

    Returns:
        AnimationData ready for rendering
    """
    visualizer = InfectionVisualizer(fps=fps)
    return visualizer.generate_animation_data(simulation_result, graph)
