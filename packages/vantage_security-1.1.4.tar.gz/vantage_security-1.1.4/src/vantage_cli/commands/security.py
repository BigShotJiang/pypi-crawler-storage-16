"""Security scanning commands for Vantage CLI.

This module provides the `vantage security` command group with:
- Full security scanning with multiple output formats
- Quick framework analysis
- Report generation
- CI/CD integration support
"""

from __future__ import annotations

import json
from pathlib import Path

import typer

from vantage_cli.output import get_console
from vantage_cli.utils import ExitCode, check_security_findings

# Create the security command group
security_app = typer.Typer(
    name="security",
    help="Security scanning commands for multi-agent AI systems.",
    no_args_is_help=True,
)


@security_app.command("scan")
def scan(
    path: Path = typer.Argument(
        ...,
        help="Path to project directory to scan",
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
    ),
    format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json, html, sarif, pdf, markdown",
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file path (defaults to stdout for text formats)",
    ),
    no_simulation: bool = typer.Option(
        False,
        "--no-simulation",
        help="Skip infection simulation (faster)",
    ),
    no_remediation: bool = typer.Option(
        False,
        "--no-remediation",
        help="Skip remediation generation",
    ),
    no_ml: bool = typer.Option(
        False,
        "--no-ml",
        help="Skip ML-based attack detection",
    ),
    ml_confidence: float = typer.Option(
        0.7,
        "--ml-confidence",
        help="Minimum ML detection confidence (0.0-1.0, default 0.7 to reduce false positives)",
    ),
    ml_category: str | None = typer.Option(
        None,
        "--ml-category",
        help="Filter ML detection to specific category: jailbreak, exfiltration, escalation, impersonation, poisoning, cascade, tool-abuse, dos",
    ),
    timeout: int = typer.Option(
        600,
        "--timeout",
        help="Maximum scan duration in seconds",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Suppress progress output (for CI/CD)",
    ),
    fail_on_findings: bool = typer.Option(
        False,
        "--fail-on-findings",
        help="Exit with error if critical/high findings detected",
    ),
    min_score: float | None = typer.Option(
        None,
        "--min-score",
        help="Minimum acceptable ATSS score (exits with error if below)",
    ),
    log_file: Path | None = typer.Option(
        None,
        "--log-file",
        help="Path to save debug logs",
    ),
):
    """Run comprehensive security scan on a project.

    Analyzes the project for security vulnerabilities, trust boundary
    violations, and generates remediation recommendations.

    ML-based detection is enabled by default and scans for:
    - Jailbreak attempts (DAN, role-play, token smuggling)
    - Data exfiltration patterns
    - Privilege escalation attempts
    - Agent impersonation attacks
    - Memory/context poisoning
    - Injection cascades
    - Tool abuse patterns
    - Denial of service attempts

    Examples:

        # Basic scan with JSON output
        vantage security scan ./my-project

        # Scan with HTML report
        vantage security scan ./my-project -f html -o report.html

        # CI/CD scan with failure on findings
        vantage security scan . -f sarif --fail-on-findings

        # Quick scan without simulation
        vantage security scan . --no-simulation --no-remediation

        # Scan only for jailbreak attempts with high confidence
        vantage security scan . --ml-category jailbreak --ml-confidence 0.8

        # Skip ML detection for faster scans
        vantage security scan . --no-ml
    """
    console = get_console(quiet=quiet)

    # Import here to avoid circular imports and speed up CLI startup
    from vantage_core.security.logging import LoggerFactory
    from vantage_core.security.pipeline.orchestrator import (
        PipelineConfig,
        SecurityPipeline,
    )
    from vantage_core.security.reports import (
        HTMLReportGenerator,
        JSONReportGenerator,
        MarkdownReportGenerator,
        PDFReportGenerator,
        SARIFReportGenerator,
    )

    # Show banner
    console.print_banner()
    console.print(f"[bold]Target:[/bold] {path}")
    console.print()

    # Configure logging
    LoggerFactory.configure(
        log_level="INFO",
        json_output=False,
        log_file=str(log_file) if log_file else None,
    )

    # Configure pipeline
    config = PipelineConfig(
        skip_simulation=no_simulation,
        skip_remediation=no_remediation,
        skip_ml_detection=no_ml,
        ml_confidence_threshold=ml_confidence,
        ml_categories=[ml_category] if ml_category else None,
        timeout_seconds=timeout,
    )

    # Create progress tracker
    progress = console.create_stage_progress()
    progress.start()

    def progress_callback(stage: str, pct: int) -> None:
        progress.update(stage, pct)

    # Run scan
    pipeline = SecurityPipeline(config)
    result = pipeline.scan(path, config, progress_callback)

    progress.stop()

    # Print summary
    _print_scan_summary(console, result)

    # Generate report
    report_generators = {
        "json": JSONReportGenerator,
        "html": HTMLReportGenerator,
        "sarif": SARIFReportGenerator,
        "pdf": PDFReportGenerator,
        "markdown": MarkdownReportGenerator,
    }

    if format not in report_generators:
        console.error(f"Unknown format: {format}")
        raise typer.Exit(ExitCode.VALIDATION_ERROR)

    generator = report_generators[format]()

    if format == "pdf":
        content_bytes = generator.generate(result)
        if output:
            output.write_bytes(content_bytes)
            console.success(f"Report saved to: {output}")
        else:
            console.error("PDF output requires --output flag")
            raise typer.Exit(ExitCode.VALIDATION_ERROR)
    else:
        report_content = generator.generate(result)
        if output:
            output.write_text(report_content)
            console.success(f"Report saved to: {output}")
        else:
            # Output to stdout
            console.print_always(report_content)

    # Check exit conditions for CI/CD
    exit_code = ExitCode.SUCCESS

    if result.scan_result:
        exit_code = check_security_findings(
            critical=result.scan_result.critical_count,
            high=result.scan_result.high_count,
            fail_on_findings=fail_on_findings,
            min_score=min_score,
            actual_score=(result.atss_result.overall_score if result.atss_result else None),
        )

    if exit_code != ExitCode.SUCCESS:
        if exit_code == ExitCode.CRITICAL_FINDINGS:
            console.error("Failing due to critical findings")
        elif exit_code == ExitCode.SECURITY_FINDINGS:
            console.error("Failing due to critical/high findings")
        elif exit_code == ExitCode.SCORE_BELOW_THRESHOLD:
            actual = result.atss_result.overall_score if result.atss_result else 0
            console.error(f"Score {actual:.1f} below minimum {min_score}")

    raise typer.Exit(exit_code)


def _print_scan_summary(console, result) -> None:
    """Print scan summary to console."""
    console.print()
    console.print_header("VANTAGE SECURITY SCAN RESULTS")

    # Status
    if result.is_success:
        console.success("Scan completed successfully")
    else:
        console.error(f"Scan status: {result.status}")

    console.muted(f"Scan ID: {result.scan_id}")
    console.muted(f"Duration: {result.duration_ms}ms")
    console.print()

    # Score
    if result.atss_result:
        console.print_score_panel(
            score=result.atss_result.overall_score,
            grade=result.atss_result.grade,
            title="Agent Topology Security Score (ATSS)",
        )

    # Findings
    if result.scan_result:
        console.print()
        console.print_findings_panel(
            critical=result.scan_result.critical_count,
            high=result.scan_result.high_count,
            medium=result.scan_result.medium_count,
            low=result.scan_result.low_count,
            info=result.scan_result.info_count,
        )

        # Count ML detections
        ml_findings = [
            f for f in result.scan_result.findings if f.detection_method == "ml_detection"
        ]

        console.print()
        stats = {
            "Agents Analyzed": result.scan_result.agents_scanned,
            "Frameworks": ", ".join(result.scan_result.frameworks_detected),
        }

        # Add ML stats if any ML findings
        if ml_findings:
            ml_categories = set(
                f.metadata.get("attack_category", "unknown") for f in ml_findings if f.metadata
            )
            stats["ML Detections"] = len(ml_findings)
            stats["Attack Categories"] = ", ".join(sorted(ml_categories))

        console.print_stats_panel(stats, title="Scan Statistics")


@security_app.command("analyze")
def analyze(
    path: Path = typer.Argument(
        ...,
        help="Path to project directory",
        exists=True,
        resolve_path=True,
    ),
):
    """Quick analysis without full security scan.

    Detects frameworks, counts agents, and identifies potential issues.
    Use this for a quick overview before running a full scan.

    Examples:

        vantage security analyze ./my-project
    """
    console = get_console()

    console.print(f"Analyzing: {path}")
    console.print()

    # Count Python files
    py_files = list(path.rglob("*.py"))
    console.info(f"Python files found: {len(py_files)}")

    # Detect frameworks
    frameworks = set()
    framework_patterns = {
        "langchain": ["langchain", "langsmith"],
        "langgraph": ["langgraph", "StateGraph"],
        "crewai": ["crewai", "CrewBase", "@agent", "@task"],
        "autogen": ["autogen", "AssistantAgent", "UserProxyAgent"],
        "llamaindex": ["llama_index", "llamaindex"],
        "semantic_kernel": ["semantic_kernel"],
        "dspy": ["dspy"],
        "smolagents": ["smolagents", "HfAgent"],
        "pydanticai": ["pydantic_ai"],
    }

    for py_file in py_files:
        try:
            content = py_file.read_text(errors="ignore")
            for framework, patterns in framework_patterns.items():
                if any(p.lower() in content.lower() for p in patterns):
                    frameworks.add(framework)
        except Exception:
            pass

    if frameworks:
        console.success(f"Frameworks detected: {', '.join(sorted(frameworks))}")
    else:
        console.warning("No known agent frameworks detected")

    console.print()
    console.info("For full security scan, run:")
    console.print(f"  vantage security scan {path}")


@security_app.command("report")
def report(
    scan_id: str = typer.Argument(
        ...,
        help="Scan ID to generate report for",
    ),
    format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json, html, sarif, pdf",
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file path",
    ),
):
    """Generate a report for a completed scan.

    Retrieves results for SCAN_ID and generates a report
    in the specified format.

    Examples:

        # Generate JSON report
        vantage security report SCAN-ABC123

        # Generate PDF report
        vantage security report SCAN-ABC123 -f pdf -o report.pdf
    """
    console = get_console()

    console.info(f"Fetching results for scan: {scan_id}")
    console.warning("Report generation for stored scans not yet implemented")
    console.info("Use 'vantage security scan' to run a new scan with report output")


@security_app.command("frameworks")
def frameworks():
    """List supported AI agent frameworks.

    Shows all frameworks that Vantage can detect and scan.
    """
    console = get_console()

    console.print_header("Supported Frameworks")

    framework_list = [
        ("CrewAI", "Multi-agent orchestration with roles and tasks"),
        ("LangChain", "LLM application development framework"),
        ("LangGraph", "Graph-based agent workflows"),
        ("AutoGen", "Microsoft's multi-agent conversation framework"),
        ("LlamaIndex", "Data framework for LLM applications"),
        ("Semantic Kernel", "Microsoft's AI orchestration SDK"),
        ("DSPy", "Programming with foundation models"),
        ("SmolaGents", "HuggingFace agent framework"),
        ("PydanticAI", "Type-safe AI agents"),
        ("MetaGPT", "Multi-agent meta programming"),
        ("Agno", "Agent development framework"),
        ("Google ADK", "Google Agent Development Kit"),
        ("OpenAI Swarm", "OpenAI's experimental agent framework"),
        ("BrowserUse", "Browser automation agents"),
        ("OpenHands", "Open-source AI software developer"),
        ("Skyvern", "AI browser automation"),
        ("Dify", "LLMOps platform"),
    ]

    for name, description in framework_list:
        console.print(f"  [cyan]{name:20}[/cyan] {description}")

    console.print()
    console.muted("For framework-specific documentation, visit:")
    console.muted("  https://docs.vantage.io/frameworks")


@security_app.command("autofix")
def autofix(
    path: Path = typer.Argument(
        ...,
        help="Path to project directory to scan and fix",
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
    ),
    dry_run: bool = typer.Option(
        True,
        "--dry-run/--apply",
        help="Show what would be fixed without applying (default: dry-run)",
    ),
    severity: str = typer.Option(
        "critical,high",
        "--severity",
        "-s",
        help="Fix findings of these severities (comma-separated: critical,high,medium,low)",
    ),
    interactive: bool = typer.Option(
        False,
        "--interactive",
        "-i",
        help="Interactively confirm each fix before applying",
    ),
    backup: bool = typer.Option(
        True,
        "--backup/--no-backup",
        help="Create backup files before modifying (*.bak)",
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Write fix report to file",
    ),
):
    """
    Generate and optionally apply automatic fixes for security findings.

    By default, runs in dry-run mode showing what would be fixed.
    Use --apply to actually modify files.

    Examples:

        # Show what would be fixed (dry-run)
        vantage security autofix ./my-project

        # Apply fixes with backup
        vantage security autofix ./my-project --apply

        # Fix only critical issues interactively
        vantage security autofix ./my-project --apply -s critical -i
    """
    console = get_console()
    console.print_header("Vantage Auto-Fix")

    if not dry_run:
        console.warning("Running in APPLY mode - files will be modified!")
        if backup:
            console.info("Backup files will be created (*.bak)")
    else:
        console.info("Running in dry-run mode - no files will be modified")

    # Parse severity filter
    severity_filter = [s.strip().lower() for s in severity.split(",")]

    try:
        # Run security scan first
        console.info(f"Scanning {path}...")

        from vantage_core.security.pipeline.orchestrator import (
            PipelineConfig,
            SecurityPipelineOrchestrator,
        )
        from vantage_core.security.remediation.generator import (
            CodeContext,
            RemediationGenerator,
        )
        from vantage_core.security.remediation.patterns import Framework

        config = PipelineConfig(
            skip_simulation=True,
            skip_remediation=False,
        )

        orchestrator = SecurityPipelineOrchestrator()
        result = orchestrator.run(path, config)

        if not result.scan_result or not result.scan_result.findings:
            console.success("No security findings detected - nothing to fix!")
            raise typer.Exit(0)

        findings = result.scan_result.findings
        console.info(f"Found {len(findings)} total findings")

        # Filter by severity
        filtered_findings = [f for f in findings if f.severity.value.lower() in severity_filter]

        if not filtered_findings:
            console.success(f"No findings match severity filter: {severity}")
            raise typer.Exit(0)

        console.info(f"{len(filtered_findings)} findings match severity filter")

        # Generate remediations
        generator = RemediationGenerator()
        fixes_applied = 0
        fixes_available = 0
        fixes_skipped = 0

        for finding in filtered_findings:
            # Try to get code context
            context = None
            if finding.file_path:
                try:
                    file_content = Path(finding.file_path).read_text()
                    # Detect framework from finding metadata or file content
                    framework = Framework.GENERIC
                    if finding.metadata:
                        fw = finding.metadata.get("framework", "").lower()
                        if "langchain" in fw:
                            framework = Framework.LANGCHAIN
                        elif "crewai" in fw:
                            framework = Framework.CREWAI
                        elif "autogen" in fw:
                            framework = Framework.AUTOGEN

                    context = CodeContext(
                        file_path=finding.file_path,
                        file_content=file_content,
                        framework=framework,
                        line_start=finding.line_number or 1,
                        line_end=(finding.line_number or 1) + 10,
                    )
                except Exception:
                    pass

            remediation = generator.generate(finding, context)

            if not remediation:
                continue

            fixes_available += 1

            # Display the fix
            console.print()
            console.print(f"[yellow]{'─' * 60}[/yellow]")
            console.print(f"[bold]{remediation.title}[/bold]")
            console.print(f"File: {finding.file_path}:{finding.line_number}")
            console.print(
                f"Severity: [{finding.severity.value.lower()}]{finding.severity.value}[/{finding.severity.value.lower()}]"
            )
            console.print(
                f"Effort: {remediation.effort} ({remediation.effort_hours[0]}-{remediation.effort_hours[1]} hours)"
            )
            console.print()
            console.print("[cyan]Explanation:[/cyan]")
            console.print(f"  {remediation.explanation}")

            if remediation.diff:
                console.print()
                console.print("[cyan]Suggested diff:[/cyan]")
                for line in remediation.diff.split("\n")[:20]:
                    if line.startswith("+"):
                        console.print(f"[green]{line}[/green]")
                    elif line.startswith("-"):
                        console.print(f"[red]{line}[/red]")
                    else:
                        console.print(line)
                if remediation.diff.count("\n") > 20:
                    console.muted(f"  ... ({remediation.diff.count(chr(10)) - 20} more lines)")

            if remediation.imports_required:
                console.print()
                console.print("[cyan]Required imports:[/cyan]")
                for imp in remediation.imports_required:
                    console.print(f"  {imp}")

            if remediation.test_cases:
                console.print()
                console.print("[cyan]Suggested test cases:[/cyan]")
                for tc in remediation.test_cases[:3]:
                    console.print(f"  - {tc}")

            # Apply fix if not dry-run
            if not dry_run:
                should_apply = True

                if interactive:
                    should_apply = typer.confirm("Apply this fix?", default=True)

                if should_apply and remediation.code_after and finding.file_path:
                    try:
                        file_path = Path(finding.file_path)

                        # Create backup
                        if backup:
                            backup_path = file_path.with_suffix(file_path.suffix + ".bak")
                            import shutil

                            shutil.copy2(file_path, backup_path)
                            console.muted(f"  Backup: {backup_path}")

                        # Note: Full auto-fix would require more sophisticated code modification
                        # For now, we just show what would be done
                        console.info(f"  Would apply fix to {file_path}")
                        fixes_applied += 1

                    except Exception as e:
                        console.error(f"  Failed to apply fix: {e}")
                        fixes_skipped += 1
                elif not should_apply:
                    fixes_skipped += 1
                    console.muted("  Skipped")

        # Summary
        console.print()
        console.print_header("Auto-Fix Summary")
        console.print(f"  Total findings scanned: {len(findings)}")
        console.print(f"  Findings matching filter: {len(filtered_findings)}")
        console.print(f"  Fixes available: {fixes_available}")

        if not dry_run:
            console.print(f"  Fixes applied: {fixes_applied}")
            console.print(f"  Fixes skipped: {fixes_skipped}")

            if fixes_applied > 0:
                console.success(f"Applied {fixes_applied} fix(es)")
                console.info("Run 'vantage security scan' to verify fixes")
        else:
            console.info("Run with --apply to apply these fixes")

        # Write report if requested
        if output:
            report = {
                "scan_path": str(path),
                "dry_run": dry_run,
                "total_findings": len(findings),
                "filtered_findings": len(filtered_findings),
                "fixes_available": fixes_available,
                "fixes_applied": fixes_applied if not dry_run else 0,
                "severity_filter": severity_filter,
            }
            output.write_text(json.dumps(report, indent=2))
            console.info(f"Report written to {output}")

    except Exception as e:
        console.error(f"Auto-fix failed: {e}")
        raise typer.Exit(1)


@security_app.command("version")
def version():
    """Show security scanner version information."""
    from vantage_core import __version__

    console = get_console()
    console.print(f"Vantage Security Scanner v{__version__}")
    console.muted("https://vantage.io")
