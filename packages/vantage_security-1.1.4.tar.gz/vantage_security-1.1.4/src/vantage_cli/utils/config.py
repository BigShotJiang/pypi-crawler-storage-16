"""CLI configuration management for Vantage.

Handles configuration loading, defaults, and environment variables.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Try to import TOML support
try:
    import tomllib
except ImportError:
    tomllib = None  # type: ignore


@dataclass
class OutputConfig:
    """Output configuration."""

    format: str = "text"  # text, json, sarif, html, pdf, markdown
    quiet: bool = False
    verbose: bool = False
    color: bool = True
    theme: str = "default"


@dataclass
class ScanConfig:
    """Scan configuration."""

    timeout: int = 600
    skip_simulation: bool = False
    skip_remediation: bool = False
    skip_sca: bool = False
    max_files: int = 10000
    exclude_patterns: list[str] = field(
        default_factory=lambda: [
            "node_modules",
            ".git",
            "__pycache__",
            ".venv",
            "venv",
            "dist",
            "build",
        ]
    )


@dataclass
class SecurityConfig:
    """Security scanning configuration."""

    min_score: float | None = None
    fail_on_findings: bool = False
    severity_threshold: str = "medium"  # minimum severity to report
    confidence_threshold: float = 0.5


@dataclass
class AnalysisConfig:
    """Analysis configuration."""

    similarity_threshold: float = 0.7
    embedding_model: str = "all-mpnet-base-v2"
    use_llm_judge: bool = False
    llm_model: str = "anthropic/claude-sonnet-4-20250514"


@dataclass
class CLIConfig:
    """Complete CLI configuration."""

    output: OutputConfig = field(default_factory=OutputConfig)
    scan: ScanConfig = field(default_factory=ScanConfig)
    security: SecurityConfig = field(default_factory=SecurityConfig)
    analysis: AnalysisConfig = field(default_factory=AnalysisConfig)

    # API keys from environment
    anthropic_api_key: str | None = None
    openrouter_api_key: str | None = None

    @classmethod
    def from_file(cls, path: Path) -> CLIConfig:
        """Load configuration from TOML file."""
        config = cls()

        if not path.exists():
            return config

        if tomllib is None:
            return config

        with open(path, "rb") as f:
            data = tomllib.load(f)

        # Update output config
        if "output" in data:
            for key, value in data["output"].items():
                if hasattr(config.output, key):
                    setattr(config.output, key, value)

        # Update scan config
        if "scan" in data:
            for key, value in data["scan"].items():
                if hasattr(config.scan, key):
                    setattr(config.scan, key, value)

        # Update security config
        if "security" in data:
            for key, value in data["security"].items():
                if hasattr(config.security, key):
                    setattr(config.security, key, value)

        # Update analysis config
        if "analysis" in data:
            for key, value in data["analysis"].items():
                if hasattr(config.analysis, key):
                    setattr(config.analysis, key, value)

        return config

    @classmethod
    def from_environment(cls) -> CLIConfig:
        """Load configuration from environment variables."""
        config = cls()

        # API keys
        config.anthropic_api_key = os.getenv("ANTHROPIC_API_KEY")
        config.openrouter_api_key = os.getenv("OPENROUTER_API_KEY")

        # Output settings
        if os.getenv("MIMIC_QUIET"):
            config.output.quiet = True
        if os.getenv("MIMIC_VERBOSE"):
            config.output.verbose = True
        if os.getenv("NO_COLOR") or os.getenv("MIMIC_NO_COLOR"):
            config.output.color = False
        if theme := os.getenv("MIMIC_THEME"):
            config.output.theme = theme

        # Scan settings
        if timeout := os.getenv("MIMIC_TIMEOUT"):
            try:
                config.scan.timeout = int(timeout)
            except ValueError:
                pass

        # Security settings
        if min_score := os.getenv("MIMIC_MIN_SCORE"):
            try:
                config.security.min_score = float(min_score)
            except ValueError:
                pass

        if os.getenv("MIMIC_FAIL_ON_FINDINGS"):
            config.security.fail_on_findings = True

        return config

    @classmethod
    def load(cls, config_path: Path | None = None) -> CLIConfig:
        """Load configuration from file and environment.

        Priority (highest to lowest):
        1. Command-line arguments (handled by caller)
        2. Environment variables
        3. Config file (vantage.toml)
        4. Default values
        """
        # Start with defaults
        config = cls()

        # Load from file if exists
        if config_path and config_path.exists():
            config = cls.from_file(config_path)
        else:
            # Check default locations
            for default_path in [
                Path("vantage.toml"),
                Path(".vantage.toml"),
                Path.home() / ".config" / "vantage" / "config.toml",
            ]:
                if default_path.exists():
                    config = cls.from_file(default_path)
                    break

        # Override with environment variables
        env_config = cls.from_environment()

        # Merge environment config
        if env_config.anthropic_api_key:
            config.anthropic_api_key = env_config.anthropic_api_key
        if env_config.openrouter_api_key:
            config.openrouter_api_key = env_config.openrouter_api_key

        if env_config.output.quiet:
            config.output.quiet = True
        if env_config.output.verbose:
            config.output.verbose = True
        if not env_config.output.color:
            config.output.color = False

        if env_config.security.min_score:
            config.security.min_score = env_config.security.min_score
        if env_config.security.fail_on_findings:
            config.security.fail_on_findings = True

        return config

    def to_dict(self) -> dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "output": {
                "format": self.output.format,
                "quiet": self.output.quiet,
                "verbose": self.output.verbose,
                "color": self.output.color,
                "theme": self.output.theme,
            },
            "scan": {
                "timeout": self.scan.timeout,
                "skip_simulation": self.scan.skip_simulation,
                "skip_remediation": self.scan.skip_remediation,
                "max_files": self.scan.max_files,
                "exclude_patterns": self.scan.exclude_patterns,
            },
            "security": {
                "min_score": self.security.min_score,
                "fail_on_findings": self.security.fail_on_findings,
                "severity_threshold": self.security.severity_threshold,
                "confidence_threshold": self.security.confidence_threshold,
            },
            "analysis": {
                "similarity_threshold": self.analysis.similarity_threshold,
                "embedding_model": self.analysis.embedding_model,
                "use_llm_judge": self.analysis.use_llm_judge,
                "llm_model": self.analysis.llm_model,
            },
        }


# Default config instance
_default_config: CLIConfig | None = None


def get_config(config_path: Path | None = None) -> CLIConfig:
    """Get the CLI configuration."""
    global _default_config
    if _default_config is None:
        _default_config = CLIConfig.load(config_path)
    return _default_config


def reset_config() -> None:
    """Reset configuration (for testing)."""
    global _default_config
    _default_config = None
