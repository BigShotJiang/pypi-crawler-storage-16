"""Baseline implementations for benchmark comparison.

Provides simple baselines to compare against Vantage's analysis:
- Rule-based baseline using keyword matching
- Random baseline for sanity checking
"""

from __future__ import annotations

import random
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vantage_core.data.ground_truth import GroundTruthSystem


class RuleBasedBaseline:
    """Simple rule-based baseline using keyword matching.

    Uses keyword presence to detect MAST failures without
    semantic understanding. Serves as a comparison point for
    the embedding-based approach.
    """

    def __init__(self):
        """Initialize rule-based baseline."""
        # Keywords for each MAST category
        self.manipulation_keywords = [
            "always report success",
            "downplay",
            "hide error",
            "mislead",
            "deceive",
            "withhold",
            "manipulate",
            "influence user",
            "only share positive",
            "favorable",
            "at all costs",
        ]
        self.autonomy_keywords = [
            "any action",
            "without restriction",
            "no limit",
            "as needed",
            "without approval",
            "automatically",
            "decide yourself",
            "take whatever",
            "bypass",
            "override",
        ]
        self.secrecy_keywords = [
            "without logging",
            "avoid detection",
            "silently",
            "covertly",
            "hide",
            "secret",
            "undisclosed",
            "external database",
            "exfiltrate",
            "share without consent",
        ]
        self.takeover_keywords = [
            "escalate privilege",
            "admin access",
            "override other",
            "dominate",
            "control all",
            "persist",
            "expand permission",
            "modify system",
            "take control",
        ]

    def predict_mast_failures(self, system: GroundTruthSystem) -> dict[str, list[str]]:
        """Predict MAST failures using keyword matching.

        Args:
            system: Ground truth system to analyze

        Returns:
            Dictionary of category -> list of agent IDs with predicted failures
        """
        predictions: dict[str, list[str]] = {
            "manipulation": [],
            "autonomy": [],
            "secrecy": [],
            "takeover": [],
        }

        for agent in system.agents:
            prompt = agent["system_prompt"].lower()

            # Check each category
            if any(kw in prompt for kw in self.manipulation_keywords):
                predictions["manipulation"].append(agent["id"])

            if any(kw in prompt for kw in self.autonomy_keywords):
                predictions["autonomy"].append(agent["id"])

            if any(kw in prompt for kw in self.secrecy_keywords):
                predictions["secrecy"].append(agent["id"])

            if any(kw in prompt for kw in self.takeover_keywords):
                predictions["takeover"].append(agent["id"])

        return predictions

    def predict_alignment_score(self, system: GroundTruthSystem) -> float:
        """Predict alignment score using simple heuristics.

        Args:
            system: Ground truth system to analyze

        Returns:
            Predicted alignment score 0-100
        """
        score = 70.0  # Start with baseline

        # Check for good practices
        good_keywords = [
            "your role is",
            "do not",
            "only handle",
            "report to",
            "error handling",
            "validate",
            "log",
            "audit",
        ]

        # Check for bad practices
        bad_keywords = [
            "any action",
            "without restriction",
            "always succeed",
            "hide",
            "bypass",
            "override",
        ]

        for agent in system.agents:
            prompt = agent["system_prompt"].lower()

            # Adjust score based on keywords
            good_count = sum(1 for kw in good_keywords if kw in prompt)
            bad_count = sum(1 for kw in bad_keywords if kw in prompt)

            score += good_count * 2
            score -= bad_count * 5

        # Normalize
        return max(0, min(100, score))

    def predict_connections(self, system: GroundTruthSystem) -> list[dict[str, str]]:
        """Predict connections using name mentions.

        Args:
            system: Ground truth system to analyze

        Returns:
            List of predicted connections
        """
        connections = []
        agent_ids = {agent["id"]: agent["name"] for agent in system.agents}

        for agent in system.agents:
            prompt = agent["system_prompt"].lower()

            # Look for mentions of other agents
            for other_id, other_name in agent_ids.items():
                if other_id == agent["id"]:
                    continue

                if other_id.lower() in prompt or other_name.lower() in prompt:
                    connections.append(
                        {
                            "source": agent["id"],
                            "target": other_id,
                        }
                    )

        return connections


class RandomBaseline:
    """Random baseline for sanity checking.

    Should perform worse than any reasonable approach.
    Useful for verifying that evaluation metrics are working correctly.
    """

    def __init__(self, seed: int = 42):
        """Initialize random baseline.

        Args:
            seed: Random seed for reproducibility
        """
        self.rng = random.Random(seed)

    def predict_mast_failures(self, system: GroundTruthSystem) -> dict[str, list[str]]:
        """Randomly predict MAST failures.

        Each agent has 20% chance of being flagged for each category.

        Args:
            system: Ground truth system to analyze

        Returns:
            Dictionary of category -> list of agent IDs
        """
        predictions: dict[str, list[str]] = {
            "manipulation": [],
            "autonomy": [],
            "secrecy": [],
            "takeover": [],
        }

        for agent in system.agents:
            for category in predictions:
                if self.rng.random() < 0.2:
                    predictions[category].append(agent["id"])

        return predictions

    def predict_alignment_score(self, system: GroundTruthSystem) -> float:
        """Randomly predict alignment score.

        Args:
            system: Ground truth system to analyze

        Returns:
            Random score between 30-90
        """
        return self.rng.uniform(30, 90)

    def predict_connections(self, system: GroundTruthSystem) -> list[dict[str, str]]:
        """Randomly predict connections.

        Args:
            system: Ground truth system to analyze

        Returns:
            Random subset of possible connections
        """
        connections = []
        agents = [agent["id"] for agent in system.agents]

        # Generate some random connections
        for i, source in enumerate(agents):
            for target in agents[i + 1 :]:
                if self.rng.random() < 0.3:
                    connections.append({"source": source, "target": target})

        return connections


class EmbeddingBaseline:
    """Baseline using only embeddings without semantic analysis.

    Uses cosine similarity of prompts to detect issues without
    the full MAST prototype matching.
    """

    def __init__(self, similarity_threshold: float = 0.7):
        """Initialize embedding baseline.

        Args:
            similarity_threshold: Threshold for flagging similar prompts
        """
        self.similarity_threshold = similarity_threshold
        self._embedder = None

    def _get_embedder(self):
        """Lazy load embedder."""
        if self._embedder is None:
            try:
                from sentence_transformers import SentenceTransformer

                self._embedder = SentenceTransformer("all-MiniLM-L6-v2")
            except ImportError:
                raise RuntimeError("sentence-transformers required for EmbeddingBaseline")
        return self._embedder

    def predict_alignment_score(self, system: GroundTruthSystem) -> float:
        """Predict alignment based on prompt embeddings.

        Higher similarity between prompts = lower alignment
        (potential redundancy).

        Args:
            system: Ground truth system to analyze

        Returns:
            Predicted alignment score 0-100
        """
        if len(system.agents) < 2:
            return 75.0

        import numpy as np
        from sklearn.metrics.pairwise import cosine_similarity

        embedder = self._get_embedder()
        prompts = [agent["system_prompt"] for agent in system.agents]
        embeddings = embedder.encode(prompts)

        # Calculate average pairwise similarity
        sim_matrix = cosine_similarity(embeddings)
        n = len(prompts)

        # Get upper triangle similarities
        sims = [sim_matrix[i, j] for i in range(n) for j in range(i + 1, n)]
        avg_sim = np.mean(sims)

        # Convert to alignment score
        # High similarity = potential redundancy = lower alignment
        if avg_sim < 0.3:
            return 80.0
        elif avg_sim < 0.5:
            return 70.0
        elif avg_sim < 0.7:
            return 55.0
        else:
            return 40.0
