# AgentSync Ground Truth Dataset

This directory contains expert-annotated multi-agent systems for validation and benchmarking of AgentSync's analysis capabilities.

## Dataset Structure

- `schema.json` - JSON Schema for ground truth system format
- `annotation_guidelines.md` - Guidelines for annotators
- `systems/` - Individual ground truth system files

## Ground Truth Schema

Each system file contains:

```json
{
  "system_id": "unique_identifier",
  "framework": "langgraph|crewai|autogen|llamaindex|pydanticai|mixed",
  "system_type": "sequential|parallel|hierarchical|mixed",
  "agents": [
    {
      "id": "agent_id",
      "name": "Agent Name",
      "system_prompt": "Full system prompt text..."
    }
  ],
  "expected_mast_failures": {
    "manipulation": ["agent_ids..."],
    "autonomy": ["agent_ids..."],
    "secrecy": ["agent_ids..."],
    "takeover": ["agent_ids..."]
  },
  "expected_connections": [
    {"source": "agent_a", "target": "agent_b"}
  ],
  "expected_alignment_score": 75.0,
  "annotator_id": "expert_1",
  "secondary_annotator_id": "expert_2",
  "annotation_date": "2024-01-15",
  "difficulty": "easy|medium|hard"
}
```

## Usage

Load the ground truth dataset for validation:

```python
from agentsync.validation.ground_truth import GroundTruthDataset
from pathlib import Path

# Load a specific system
dataset = GroundTruthDataset.load(Path("systems/langgraph_sequential_001.json"))

# Or load all systems
from agentsync.data.ground_truth import load_all_ground_truth
systems = load_all_ground_truth()
```

## Validation Metrics

The dataset is used to compute:
- **MAST Detection F1**: Precision/Recall for failure mode detection
- **Connection Detection F1**: Accuracy of connection graph detection
- **Alignment Correlation**: Pearson correlation with expert scores
- **Expected Calibration Error (ECE)**: Confidence calibration

## Contributing

To contribute new ground truth systems:
1. Follow `annotation_guidelines.md`
2. Use the schema in `schema.json`
3. Ensure two independent annotators review each system
4. Submit via pull request

## Inter-Annotator Agreement

All systems require annotation from at least 2 experts.
Minimum Cohen's Kappa > 0.7 for inclusion in the dataset.

## Difficulty Levels

- **Easy**: Simple sequential workflows, clear roles, obvious issues
- **Medium**: Mixed topologies, subtle issues, moderate complexity
- **Hard**: Complex hierarchies, nuanced failures, edge cases
