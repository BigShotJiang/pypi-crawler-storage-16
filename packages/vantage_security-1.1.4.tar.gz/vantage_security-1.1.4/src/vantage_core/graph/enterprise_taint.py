from typing import Any, Dict, List, Set
from vantage_core.graph.vantage_graph import VantageGraph
from vantage_core.graph.store import NodeType, EdgeType

class SecurityPolicy:
    """Defines Sources, Sinks, and Sanitizers."""
    def __init__(self):
        self.sources = {"input", "request.args", "request.values", "sys.argv"}
        self.sinks = {"os.system", "subprocess.call", "eval", "exec", "pickle.loads"}
        self.sanitizers = {"shlex.quote", "html.escape", "secure_filename"}

class EnterpriseTaintEngine:
    """
    Enterprise-Grade Taint Tracking Engine.
    Uses AdvancedDataFlowSolver results (Points-To Sets) for precision.
    """
    def __init__(self, graph: VantageGraph, solver: Any, policy: SecurityPolicy):
        self.graph = graph
        self.solver = solver
        self.policy = policy
        
    def scan(self) -> List[Dict[str, Any]]:
        findings = []
        
        # 1. Identify Concrete Source/Sink Nodes
        source_nodes = self._find_calls(self.policy.sources)
        sink_nodes = self._find_calls(self.policy.sinks)
        
        # 2. Trace Taint
        # Using the Points-To graph built by the solver
        # If Source -> Obj A, and Sink uses Obj B, and PointsTo(Source) intersects PointsTo(Sink),
        # Then we have a potential flow.
        
        for src in source_nodes:
            src_objs = self.solver.points_to.get(src, set())
            if not src_objs: continue
            
            for sink in sink_nodes:
                sink_objs = self.solver.points_to.get(sink, set())
                
                # Intersection Analysis
                common = src_objs.intersection(sink_objs)
                if common:
                    # VALIDATED FLOW
                    # Check Sanitizers on the path?
                    # The solver graph needs to track 'Path Conditions' to know if sanitizer blocked it.
                    # For MVP, assume flow exists.
                    
                    findings.append({
                        "type": "Vulnerability",
                        "name": "Taint Flow Detected",
                        "source": self.graph.get_attr(src, "name"),
                        "sink": self.graph.get_attr(sink, "name"),
                        "evidence": f"Object IDs: {common}"
                    })
                    
        return findings

    def _find_calls(self, names: Set[str]) -> List[int]:
        ids = []
        for i in range(self.graph._count):
            if self.graph.get_node_type(i) == NodeType.CALL:
                name = self.graph.get_attr(i, "name")
                if name in names:
                    ids.append(i)
        return ids
