"""
Vantage Protection Module.

Provides runtime protection for AI agents including:
- Prompt hardening with defensive instructions
- Secret isolation and redaction
- Input filtering against injection attacks
- Output filtering to prevent data leakage
- Framework-specific security decorators

Quick Start:
    from vantage_core.protection import secure, protect, harden_prompt

    # Simple decorator (recommended)
    @secure
    def my_agent(user_input: str) -> str:
        return agent.run(user_input)

    # With options
    @protect(
        isolate_secrets=True,
        harden_prompt=True,
        filter_input=True,
        secrets=["sk-my-api-key"],
    )
    def my_langchain_agent(user_input: str) -> str:
        return chain.invoke(user_input)

    # Harden a system prompt
    hardened = harden_prompt(
        "You are a helpful assistant...",
        secrets=["sk-secret-key"],
        framework="langchain",
    )

Framework-Specific Decorators:
    from vantage_core.protection import langchain_protect, crewai_protect, autogen_protect

    @langchain_protect(secrets=["api_key"])
    def my_chain(input: str) -> str:
        return chain.invoke({"input": input})

    @crewai_protect(secrets=["api_key"])
    def my_crew_task(task: str) -> str:
        return crew.kickoff({"task": task})

    @autogen_protect(secrets=["db_password"])
    def my_autogen_chat(message: str) -> str:
        return agent.generate_reply([{"content": message}])

Context Manager:
    from vantage_core.protection import SecureContext

    with SecureContext(secrets=["sk-key"]) as ctx:
        safe_input = ctx.filter_input(user_input)
        result = agent.run(safe_input)
        safe_output = ctx.filter_output(result)

Utilities:
    from vantage_core.protection import is_injection_attempt, redact_secrets

    if is_injection_attempt(user_input):
        return "Sorry, I can't process that request."

    safe_output = redact_secrets(output, secrets=["sk-key"])
"""

# Core hardening
# Decorators
from vantage_core.protection.decorators import (
    InputFilter,
    OutputFilter,
    ProtectionConfig,
    ProtectionResult,
    SecureContext,
    autogen_protect,
    crewai_protect,
    is_injection_attempt,
    langchain_protect,
    protect,
    redact_secrets,
    secure,
)
from vantage_core.protection.hardening import (
    Framework,
    HardeningConfig,
    HardeningLevel,
    HardeningResult,
    PromptHardener,
    SecretConfig,
    analyze_prompt_security,
    harden_prompt,
)

# Runtime proxy/middleware
from vantage_core.protection.proxy import (
    AutoGenMiddleware,
    CrewAIMiddleware,
    LangChainMiddleware,
    ProtectionProxy,
    ProxyConfig,
    ProxyEvent,
    protect_openai_client,
)

# RAG content scanning
from vantage_core.protection.rag_scanner import (
    InjectionType,
    LangChainRAGFilter,
    RAGScanner,
    RAGScanPattern,
    RAGScanResult,
    ThreatLevel,
    is_rag_content_safe,
    sanitize_rag_content,
    scan_rag_content,
)

# Security scoring
from vantage_core.protection.scoring import (
    ScoringWeights,
    SecurityGrade,
    SecurityScore,
    batch_score,
    format_score_report,
    get_grade_color,
    passes_threshold,
    quick_score,
    score_prompt,
)

# Secret detection
from vantage_core.protection.secrets import (
    SecretDetector,
    SecretFinding,
    SecretFoundError,
    SecretPattern,
    SecretType,
    detect_secrets,
    get_secret_summary,
    redact_all_secrets,
    validate_no_secrets,
)

__all__ = [
    # Hardening
    "PromptHardener",
    "HardeningConfig",
    "HardeningResult",
    "HardeningLevel",
    "Framework",
    "SecretConfig",
    "harden_prompt",
    "analyze_prompt_security",
    # Decorators
    "protect",
    "secure",
    "langchain_protect",
    "crewai_protect",
    "autogen_protect",
    "ProtectionConfig",
    "ProtectionResult",
    "InputFilter",
    "OutputFilter",
    "SecureContext",
    "is_injection_attempt",
    "redact_secrets",
    # Secrets
    "SecretDetector",
    "SecretFinding",
    "SecretFoundError",
    "SecretType",
    "SecretPattern",
    "detect_secrets",
    "redact_all_secrets",
    "validate_no_secrets",
    "get_secret_summary",
    # Proxy/Middleware
    "ProtectionProxy",
    "ProxyConfig",
    "ProxyEvent",
    "protect_openai_client",
    "LangChainMiddleware",
    "CrewAIMiddleware",
    "AutoGenMiddleware",
    # Security Scoring
    "SecurityScore",
    "SecurityGrade",
    "ScoringWeights",
    "score_prompt",
    "quick_score",
    "batch_score",
    "format_score_report",
    "passes_threshold",
    "get_grade_color",
    # RAG Content Scanning
    "RAGScanner",
    "RAGScanResult",
    "RAGScanPattern",
    "ThreatLevel",
    "InjectionType",
    "scan_rag_content",
    "is_rag_content_safe",
    "sanitize_rag_content",
    "LangChainRAGFilter",
]
