"""Scanner for Google ADK (Agent Development Kit) definitions.

Google's Agent Development Kit for building agents with Gemini models,
featuring structured outputs and multi-modal capabilities.

Example detection targets:

    # LLM Agent
    from google.adk.agents import LlmAgent
    from google.adk.tools import google_search

    research_agent = LlmAgent(
        name="researcher",
        model="gemini-1.5-pro",
        instruction="You are a research assistant.",
        tools=[google_search],
    )

    # Sequential Agent
    from google.adk.agents import SequentialAgent

    pipeline = SequentialAgent(
        name="research_pipeline",
        sub_agents=[research_agent, summarizer_agent, writer_agent],
    )
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult
from vantage_core.scanners.mixins import ASTExtractionMixin

logger = logging.getLogger(__name__)


class GoogleADKScanner(BaseScanner, ASTExtractionMixin):
    """Scanner for Google ADK agent definitions.

    Detects:
    - LlmAgent, SequentialAgent, ParallelAgent, LoopAgent
    - Agent configurations and tools
    - Sub-agent hierarchies and connections
    """

    framework_name = "GoogleADK"

    # Agent classes to detect
    AGENT_CLASSES = {
        "Agent",
        "LlmAgent",
        "SequentialAgent",
        "ParallelAgent",
        "LoopAgent",
        "BaseAgent",
    }

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a Python file for Google ADK agent definitions.

        Args:
            path: Path to Python file

        Returns:
            ScanResult with detected agents and connections
        """
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        errors: list[str] = []

        try:
            tree = self._parse_python_file(path)
        except SyntaxError as e:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[f"Syntax error in {path}: {e}"],
            )

        # Track agent names for connection resolution
        agent_names: dict[str, str] = {}  # var_name -> agent_id

        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                # Parse agent instantiation
                agent = self._parse_agent_call(node, path)
                if agent:
                    agents.append(agent)

                # Track assignment for connection resolution
                if isinstance(node, ast.Call):
                    parent = self._find_assignment_target(tree, node)
                    if parent and agent:
                        agent_names[parent] = agent.id

            # Also handle assignments directly
            if isinstance(node, ast.Assign):
                if isinstance(node.value, ast.Call):
                    agent = self._parse_agent_call(node.value, path)
                    if agent:
                        # Check if we already added this agent
                        if not any(a.line_number == agent.line_number for a in agents):
                            agents.append(agent)
                        for target in node.targets:
                            if isinstance(target, ast.Name):
                                agent_names[target.id] = agent.id

        # Second pass: parse composite agents for connections
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                conns = self._parse_composite_agent(node, agent_names)
                connections.extend(conns)

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=errors,
        )

    def _parse_agent_call(self, node: ast.Call, path: Path) -> DetectedAgent | None:
        """Parse Google ADK agent constructors.

        Args:
            node: AST Call node
            path: Source file path

        Returns:
            DetectedAgent or None if not an agent call
        """
        func_name = self._get_call_name(node)
        if func_name not in self.AGENT_CLASSES:
            return None

        # Name from keyword or first positional arg
        name = self._extract_keyword_arg(node, "name")
        if not name and node.args:
            first_arg = self._extract_value(node.args[0])
            if isinstance(first_arg, str):
                name = first_arg
        name = name or func_name

        # Ensure name is a string
        if not isinstance(name, str):
            name = str(name)

        # System instruction from various possible parameter names
        system_prompt = (
            self._extract_keyword_arg(node, "instruction")
            or self._extract_keyword_arg(node, "system_instruction")
            or self._extract_keyword_arg(node, "preamble")
            or self._extract_keyword_arg(node, "description")
            or f"Google ADK {func_name}"
        )

        if not isinstance(system_prompt, str):
            system_prompt = f"Google ADK {func_name}"

        # Model (default to Gemini)
        model = self._extract_keyword_arg(node, "model") or "gemini-1.5-pro"
        if not isinstance(model, str):
            model = "gemini-1.5-pro"

        # Tools extraction
        tools: list[str] = []
        tools_arg = self._extract_keyword_arg(node, "tools") or []
        if tools_arg and isinstance(tools_arg, list):
            for t in tools_arg:
                if isinstance(t, str):
                    tools.append(t)
                else:
                    tools.append("tool")

        # Add agent type context for composite agents
        if func_name == "SequentialAgent":
            system_prompt = f"Sequential pipeline agent.\n\n{system_prompt}"
        elif func_name == "ParallelAgent":
            system_prompt = f"Parallel execution agent.\n\n{system_prompt}"
        elif func_name == "LoopAgent":
            system_prompt = f"Iterative loop agent.\n\n{system_prompt}"

        return DetectedAgent(
            id=self._make_id(name),
            name=name,
            framework=Framework.GOOGLE_ADK,
            file_path=str(path),
            line_number=node.lineno,
            system_prompt=system_prompt,
            tools=tools,
            metadata={
                "model": model,
                "agent_type": func_name,
            },
        )

    def _parse_composite_agent(
        self, node: ast.Call, agent_names: dict[str, str]
    ) -> list[DetectedConnection]:
        """Parse SequentialAgent/ParallelAgent for sub-agent connections.

        Args:
            node: AST Call node
            agent_names: Map of variable names to agent IDs

        Returns:
            List of detected connections
        """
        connections: list[DetectedConnection] = []
        func_name = self._get_call_name(node)

        if func_name == "SequentialAgent":
            # Sub-agents run in sequence
            sub_agents = self._extract_keyword_arg(node, "sub_agents") or []

            if isinstance(sub_agents, list):
                # Resolve variable names to agent IDs
                agent_ids = []
                for sub in sub_agents:
                    if isinstance(sub, str):
                        # It's a variable name, resolve to ID
                        if sub in agent_names:
                            agent_ids.append(agent_names[sub])
                        else:
                            agent_ids.append(self._make_id(sub))

                # Create sequential connections
                for i in range(len(agent_ids) - 1):
                    connections.append(
                        DetectedConnection(
                            source_id=agent_ids[i],
                            target_id=agent_ids[i + 1],
                            connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                            confidence=0.95,
                            confidence_level=ConnectionConfidence.FRAMEWORK,
                            evidence=["SequentialAgent sub_agents list"],
                        )
                    )

        elif func_name == "ParallelAgent":
            # Parallel agents don't have linear connections
            # but we could model the parent-child relationship
            pass

        elif func_name == "LoopAgent":
            # Loop agents iterate
            sub_agent = self._extract_keyword_arg(node, "sub_agent")
            if sub_agent and isinstance(sub_agent, str):
                agent_id = agent_names.get(sub_agent, self._make_id(sub_agent))
                # Create self-loop connection
                connections.append(
                    DetectedConnection(
                        source_id=agent_id,
                        target_id=agent_id,
                        connection_type=ConnectionType.DELEGATION,
                        confidence=0.95,
                        confidence_level=ConnectionConfidence.FRAMEWORK,
                        evidence=["LoopAgent self-reference"],
                        metadata={"condition": "loop"},
                    )
                )

        return connections

    def _find_assignment_target(self, tree: ast.Module, call_node: ast.Call) -> str | None:
        """Find the variable name that a call is assigned to.

        Args:
            tree: AST module
            call_node: Call node to find assignment for

        Returns:
            Variable name or None
        """
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                if node.value is call_node:
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            return target.id
        return None
