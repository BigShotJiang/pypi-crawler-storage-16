"""Scanner for MetaGPT role and team definitions.

MetaGPT implements SOP-driven multi-agent teams with predefined roles
(ProductManager, Architect, Engineer, etc.) and custom role definitions.

Example detection targets:

    # Built-in roles
    from metagpt.roles import ProductManager, Architect, Engineer
    from metagpt.team import Team

    team = Team()
    team.hire([
        ProductManager(),
        Architect(),
        Engineer(n_borg=3),
    ])

    # Custom role
    from metagpt.roles import Role
    from metagpt.actions import Action

    class DataAnalyst(Role):
        name: str = "Alice"
        profile: str = "Data Analyst"
        goal: str = "Analyze data and provide insights"
        constraints: str = "Use only provided datasets"
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult
from vantage_core.scanners.mixins import ASTExtractionMixin

logger = logging.getLogger(__name__)


class MetaGPTScanner(BaseScanner, ASTExtractionMixin):
    """Scanner for MetaGPT role and team definitions.

    Detects:
    - Built-in role instantiations (ProductManager, Architect, etc.)
    - Custom Role subclasses
    - Team compositions and connections
    """

    framework_name = "MetaGPT"

    # Built-in MetaGPT roles with their descriptions
    BUILTIN_ROLES: dict[str, str] = {
        "ProductManager": "Product Manager who creates PRDs and user stories",
        "Architect": "Software Architect who designs system architecture",
        "ProjectManager": "Project Manager who manages tasks and schedules",
        "Engineer": "Software Engineer who writes code",
        "QaEngineer": "QA Engineer who writes tests",
        "Searcher": "Research agent that searches for information",
        "Researcher": "Research agent that analyzes information",
        "Sales": "Sales representative agent",
        "CustomerService": "Customer service agent",
        "Programmer": "Programmer who implements features",
    }

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a Python file for MetaGPT role definitions.

        Args:
            path: Path to Python file

        Returns:
            ScanResult with detected agents and connections
        """
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        errors: list[str] = []

        try:
            tree = self._parse_python_file(path)
        except SyntaxError as e:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[f"Syntax error in {path}: {e}"],
            )

        # First pass: find custom Role subclasses
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                agent = self._parse_role_class(node, path)
                if agent:
                    agents.append(agent)

        # Second pass: find built-in role instantiations
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                agent = self._parse_role_call(node, path)
                if agent:
                    agents.append(agent)

        # Third pass: parse Team for connections
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                conns = self._parse_team_call(node, agents)
                connections.extend(conns)

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=errors,
        )

    def _parse_role_class(self, node: ast.ClassDef, path: Path) -> DetectedAgent | None:
        """Parse custom Role subclass.

        Args:
            node: AST ClassDef node
            path: Source file path

        Returns:
            DetectedAgent or None if not a Role subclass
        """
        # Check if inherits from Role
        is_role = any(
            (isinstance(base, ast.Name) and base.id == "Role")
            or (isinstance(base, ast.Attribute) and base.attr == "Role")
            for base in node.bases
        )

        if not is_role:
            return None

        # Extract class-level attributes
        name = node.name
        profile = ""
        goal = ""
        constraints = ""
        actions: list[str] = []

        for item in node.body:
            # Handle annotated assignments (name: str = "value")
            if isinstance(item, ast.AnnAssign):
                if isinstance(item.target, ast.Name):
                    attr_name = item.target.id
                    if item.value:
                        value = self._extract_value(item.value)
                        if attr_name == "name" and isinstance(value, str):
                            name = value
                        elif attr_name == "profile" and isinstance(value, str):
                            profile = value
                        elif attr_name == "goal" and isinstance(value, str):
                            goal = value
                        elif attr_name == "constraints" and isinstance(value, str):
                            constraints = value

            # Handle simple assignments
            elif isinstance(item, ast.Assign):
                for target in item.targets:
                    if isinstance(target, ast.Name):
                        value = self._extract_value(item.value)
                        if target.id == "name" and isinstance(value, str):
                            name = value
                        elif target.id == "profile" and isinstance(value, str):
                            profile = value
                        elif target.id == "goal" and isinstance(value, str):
                            goal = value
                        elif target.id == "constraints" and isinstance(value, str):
                            constraints = value

            # Look for actions in __init__ or set_actions
            elif isinstance(item, ast.FunctionDef):
                if item.name == "__init__":
                    for stmt in ast.walk(item):
                        if isinstance(stmt, ast.Call):
                            call_name = self._get_call_name(stmt)
                            if call_name in ["set_actions", "_set_react_mode"]:
                                # Extract action names
                                if stmt.args:
                                    arg = self._extract_value(stmt.args[0])
                                    if isinstance(arg, list):
                                        actions.extend(
                                            a if isinstance(a, str) else str(a) for a in arg
                                        )

        # Build system prompt
        system_prompt = f"Role: {profile or name}"
        if goal:
            system_prompt += f"\n\nGoal: {goal}"
        if constraints:
            system_prompt += f"\n\nConstraints: {constraints}"
        if actions:
            system_prompt += f"\n\nActions: {', '.join(actions)}"

        return DetectedAgent(
            id=self._make_id(name),
            name=name,
            framework=Framework.METAGPT,
            file_path=str(path),
            line_number=node.lineno,
            system_prompt=system_prompt,
            tools=actions,
            metadata={
                "profile": profile,
                "goal": goal,
                "constraints": constraints,
            },
        )

    def _parse_role_call(self, node: ast.Call, path: Path) -> DetectedAgent | None:
        """Parse built-in role instantiation.

        Args:
            node: AST Call node
            path: Source file path

        Returns:
            DetectedAgent or None if not a built-in role
        """
        func_name = self._get_call_name(node)
        if func_name not in self.BUILTIN_ROLES:
            return None

        # Get custom name if provided
        name = self._extract_keyword_arg(node, "name")
        if not name or not isinstance(name, str):
            name = func_name

        # Use built-in description as base
        system_prompt = self.BUILTIN_ROLES[func_name]

        # Override with custom profile/goal if provided
        profile = self._extract_keyword_arg(node, "profile")
        goal = self._extract_keyword_arg(node, "goal")
        constraints = self._extract_keyword_arg(node, "constraints")

        if profile or goal:
            system_prompt = f"Role: {profile or func_name}"
            if goal:
                system_prompt += f"\n\nGoal: {goal}"
        if constraints and isinstance(constraints, str):
            system_prompt += f"\n\nConstraints: {constraints}"

        # Check for n_borg (multiple instances)
        n_borg = self._extract_keyword_arg(node, "n_borg")
        if n_borg and isinstance(n_borg, int) and n_borg > 1:
            system_prompt += f"\n\nInstances: {n_borg}"

        return DetectedAgent(
            id=self._make_id(name),
            name=name,
            framework=Framework.METAGPT,
            file_path=str(path),
            line_number=node.lineno,
            system_prompt=system_prompt,
            metadata={
                "role_type": func_name,
                "n_borg": n_borg if isinstance(n_borg, int) else 1,
            },
        )

    def _parse_team_call(
        self, node: ast.Call, agents: list[DetectedAgent]
    ) -> list[DetectedConnection]:
        """Parse Team() and team.hire() for agent connections.

        MetaGPT teams use hierarchical handoff by default:
        ProductManager -> Architect -> Engineer -> QA

        Args:
            node: AST Call node
            agents: List of already detected agents

        Returns:
            List of detected connections
        """
        connections: list[DetectedConnection] = []

        func_name = self._get_call_name(node)

        # Check for team.hire() pattern
        if func_name == "hire":
            # Extract agents from the list argument
            if node.args:
                arg = self._extract_value(node.args[0])
                if isinstance(arg, list):
                    # These are variable names or class instantiations
                    pass

        # If we have agents from this file, create hierarchical connections
        if len(agents) > 1 and func_name in ["Team", "hire"]:
            # MetaGPT default hierarchy
            hierarchy_order = [
                "productmanager",
                "architect",
                "projectmanager",
                "engineer",
                "qaengineer",
            ]

            # Sort agents by hierarchy
            def get_hierarchy_index(agent: DetectedAgent) -> int:
                agent_id_lower = agent.id.lower()
                for i, role in enumerate(hierarchy_order):
                    if role in agent_id_lower:
                        return i
                return 100  # Custom roles at end

            sorted_agents = sorted(agents, key=get_hierarchy_index)
            agent_ids = [a.id for a in sorted_agents]

            # Create sequential connections
            for i in range(len(agent_ids) - 1):
                connections.append(
                    DetectedConnection(
                        source_id=agent_ids[i],
                        target_id=agent_ids[i + 1],
                        connection_type=ConnectionType.HIERARCHICAL,
                        confidence=0.95,
                        confidence_level=ConnectionConfidence.FRAMEWORK,
                        evidence=["MetaGPT Team hierarchy"],
                    )
                )

        return connections
