"""Scanner for Hugging Face smolagents framework.

Detects agents from smolagents including CodeAgent, ToolCallingAgent, and ManagedAgent.
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult
from vantage_core.scanners.mixins import ASTExtractionMixin

logger = logging.getLogger(__name__)


class SmolagentsScanner(BaseScanner, ASTExtractionMixin):
    """Scanner for Hugging Face smolagents framework.

    Detects:
    - CodeAgent instantiations
    - ToolCallingAgent instantiations
    - ManagedAgent for multi-agent setups

    Example:
        >>> scanner = SmolagentsScanner()
        >>> result = scanner.scan_file(Path("agents.py"))
        >>> for agent in result.agents:
        ...     print(f"{agent.name}: {agent.system_prompt}")
    """

    framework_name = "smolagents"

    # Agent classes to detect
    AGENT_CLASSES = {
        "CodeAgent",
        "ToolCallingAgent",
        "ManagedAgent",
        "MultiStepAgent",
    }

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a Python file for smolagents agent definitions.

        Args:
            path: Path to Python file

        Returns:
            ScanResult with detected agents and connections
        """
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        errors: list[str] = []

        try:
            tree = self._parse_python_file(path)
        except SyntaxError as e:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[f"Syntax error in {path}: {e}"],
            )

        # Track agent variable names for ManagedAgent parsing
        agent_vars: dict[str, str] = {}

        # First pass: find agent instantiations
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        agent = self._parse_agent_call(node.value, path, target.id)
                        if agent:
                            agents.append(agent)
                            agent_vars[target.id] = agent.id

                            # Check for ManagedAgent connections
                            if self._get_call_name(node.value) == "ManagedAgent":
                                conns = self._parse_managed_agent_connections(
                                    node.value, agent.id, agent_vars
                                )
                                connections.extend(conns)

            # Also handle standalone calls without assignment
            elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
                agent = self._parse_agent_call(node.value, path, None)
                if agent:
                    agents.append(agent)

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=errors,
        )

    def _parse_agent_call(
        self, node: ast.Call, path: Path, var_name: str | None
    ) -> DetectedAgent | None:
        """Parse smolagents agent constructor call.

        Args:
            node: AST Call node
            path: Source file path
            var_name: Variable name if assigned

        Returns:
            DetectedAgent or None if not a recognized agent
        """
        call_name = self._get_call_name(node)
        if call_name not in self.AGENT_CLASSES:
            return None

        # Extract name from variable or call
        name = var_name or call_name
        agent_id = self._make_id(name)

        # Extract system prompt
        system_prompt = self._extract_keyword_arg(node, "system_prompt")
        if not system_prompt:
            system_prompt = f"smolagents {call_name}"

        # Extract model configuration
        model = self._extract_model_config(node)

        # Extract tools
        tools = self._extract_tools(node)
        if tools:
            tool_str = ", ".join(tools)
            system_prompt = f"{system_prompt}\n\nTools: {tool_str}"

        # For ManagedAgent, extract managed agent info
        if call_name == "ManagedAgent":
            agent_ref = self._extract_keyword_arg(node, "agent")
            description = self._extract_keyword_arg(node, "description")
            managed_name = self._extract_keyword_arg(node, "name")

            if managed_name:
                name = managed_name
                agent_id = self._make_id(name)

            if description:
                system_prompt = f"{description}\n\n{system_prompt}"

            if agent_ref and isinstance(agent_ref, str):
                system_prompt = f"{system_prompt}\n\nManages: {agent_ref}"

        return DetectedAgent(
            id=agent_id,
            name=self._format_display_name(name),
            system_prompt=system_prompt,
            file_path=str(path),
            line_number=node.lineno,
            framework=Framework.SMOLAGENTS,
            tools=tools,
            metadata={
                "agent_type": call_name,
                "model": model,
            },
        )

    def _extract_model_config(self, node: ast.Call) -> str:
        """Extract model configuration from agent call.

        Args:
            node: AST Call node

        Returns:
            Model string
        """
        # Check for model keyword
        model = self._extract_keyword_arg(node, "model")

        if model:
            if isinstance(model, str):
                return model
            elif isinstance(model, dict) and "model_id" in model:
                return model["model_id"]

        # Check for llm_engine
        llm_engine = self._extract_keyword_arg(node, "llm_engine")
        if llm_engine and isinstance(llm_engine, str):
            return llm_engine

        return "HfApiModel"  # Default smolagents model

    def _extract_tools(self, node: ast.Call) -> list[str]:
        """Extract tool names from agent call.

        Args:
            node: AST Call node

        Returns:
            List of tool names
        """
        tools: list[str] = []

        tools_arg = self._extract_keyword_arg(node, "tools")
        if isinstance(tools_arg, list):
            for tool in tools_arg:
                if isinstance(tool, str):
                    tools.append(tool)
                elif isinstance(tool, dict) and "name" in tool:
                    tools.append(tool["name"])

        # Also check additional_tools
        additional = self._extract_keyword_arg(node, "additional_tools")
        if isinstance(additional, list):
            for tool in additional:
                if isinstance(tool, str):
                    tools.append(tool)

        return tools

    def _parse_managed_agent_connections(
        self, node: ast.Call, managed_agent_id: str, agent_vars: dict[str, str]
    ) -> list[DetectedConnection]:
        """Parse connections for ManagedAgent.

        ManagedAgent wraps another agent to be called by a manager.

        Args:
            node: AST Call node for ManagedAgent
            managed_agent_id: ID of the ManagedAgent
            agent_vars: Mapping of variable names to agent IDs

        Returns:
            List of connections
        """
        connections: list[DetectedConnection] = []

        # Get the wrapped agent
        agent_ref = self._extract_keyword_arg(node, "agent")
        if agent_ref and isinstance(agent_ref, str) and agent_ref in agent_vars:
            # Connection from ManagedAgent to the wrapped agent
            connections.append(
                DetectedConnection(
                    source_id=managed_agent_id,
                    target_id=agent_vars[agent_ref],
                    connection_type=ConnectionType.DELEGATION,
                    confidence=0.95,
                    confidence_level=ConnectionConfidence.FRAMEWORK,
                    evidence=[f"ManagedAgent wraps agent '{agent_ref}'"],
                )
            )

        return connections
