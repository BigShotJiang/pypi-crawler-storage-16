"""
Severity adjustment for security findings based on context.

Adjusts finding severity based on file location (test, example, documentation)
to reduce false positive noise while maintaining visibility.
"""

import re
from dataclasses import dataclass, field
from enum import Enum

from vantage_core.security.models import SecurityFinding, Severity

# Severity ordering (higher number = more severe)
SEVERITY_ORDER = {
    Severity.INFO: 0,
    Severity.LOW: 1,
    Severity.MEDIUM: 2,
    Severity.HIGH: 3,
    Severity.CRITICAL: 4,
}


def severity_value(sev: Severity) -> int:
    """Get numeric severity value for comparison."""
    return SEVERITY_ORDER.get(sev, 0)


class SeverityAdjustmentReason(str, Enum):
    """Reasons for severity adjustment."""

    TEST_FILE = "test_file"
    EXAMPLE_CODE = "example_code"
    DOCUMENTATION = "documentation"
    MOCK_DATA = "mock_data"
    COMMENTED_CODE = "commented_code"
    FIXTURE = "fixture"


@dataclass
class SeverityAdjustmentConfig:
    """Configuration for severity adjustment."""

    # Enable/disable adjustment
    enabled: bool = True

    # Adjust test files
    adjust_test_files: bool = True

    # Adjust example code
    adjust_examples: bool = True

    # Adjust documentation
    adjust_docs: bool = True

    # Custom patterns
    custom_test_patterns: list[str] = field(default_factory=list)
    custom_example_patterns: list[str] = field(default_factory=list)

    # Minimum severity to report (after adjustment)
    min_severity: Severity = Severity.INFO

    # Suppress findings entirely in certain contexts
    suppress_in_docs: bool = True  # Don't report findings in docs


# Severity downgrade rules - how much to downgrade for each reason
DOWNGRADE_RULES: dict[SeverityAdjustmentReason, dict[Severity, Severity]] = {
    SeverityAdjustmentReason.TEST_FILE: {
        Severity.CRITICAL: Severity.HIGH,
        Severity.HIGH: Severity.MEDIUM,
        Severity.MEDIUM: Severity.LOW,
        Severity.LOW: Severity.INFO,
    },
    SeverityAdjustmentReason.EXAMPLE_CODE: {
        Severity.CRITICAL: Severity.MEDIUM,
        Severity.HIGH: Severity.LOW,
        Severity.MEDIUM: Severity.INFO,
        Severity.LOW: Severity.INFO,
    },
    SeverityAdjustmentReason.DOCUMENTATION: {
        Severity.CRITICAL: Severity.INFO,
        Severity.HIGH: Severity.INFO,
        Severity.MEDIUM: Severity.INFO,
        Severity.LOW: Severity.INFO,
    },
    SeverityAdjustmentReason.MOCK_DATA: {
        Severity.CRITICAL: Severity.HIGH,
        Severity.HIGH: Severity.MEDIUM,
        Severity.MEDIUM: Severity.LOW,
        Severity.LOW: Severity.INFO,
    },
    SeverityAdjustmentReason.FIXTURE: {
        Severity.CRITICAL: Severity.HIGH,
        Severity.HIGH: Severity.MEDIUM,
        Severity.MEDIUM: Severity.LOW,
        Severity.LOW: Severity.INFO,
    },
}


class SeverityAdjuster:
    """
    Adjust finding severity based on context.

    Reduces severity for findings in test files, examples, and documentation
    to reduce alert fatigue while maintaining visibility.
    """

    # Test file patterns
    TEST_PATTERNS = [
        r"/tests?/",  # /test/ or /tests/
        r"/test_",  # /test_something.py
        r"_test\.py$",  # something_test.py
        r"/conftest\.py$",  # pytest config
        r"/fixtures/",  # fixture data
        r"/mocks?/",  # mock files
        r"test-repos",  # test repositories
        r"/testing/",  # testing folder
        r"_tests?\.py$",  # file_test.py or file_tests.py
    ]

    # Example/sample patterns
    EXAMPLE_PATTERNS = [
        r"/examples?/",  # /example/ or /examples/
        r"/samples?/",  # /sample/ or /samples/
        r"/demo/",  # demo folder
        r"_example\.py$",  # file_example.py
        r"/quickstart/",  # quickstart guides
        r"/tutorials?/",  # tutorials
        r"/getting[_-]?started/",  # getting started
        r"/cookbook/",  # cookbook examples
    ]

    # Documentation patterns
    DOC_PATTERNS = [
        r"/docs?/",  # /doc/ or /docs/
        r"\.md$",  # markdown files
        r"\.rst$",  # restructured text
        r"\.txt$",  # text files (often docs)
        r"/tutorials?/",  # tutorials (also docs)
        r"README",  # readme files
        r"CHANGELOG",  # changelogs
        r"CONTRIBUTING",  # contributing guides
    ]

    # Mock context indicators in code
    MOCK_INDICATORS = [
        "mock.",
        "Mock(",
        "MagicMock",
        "@patch",
        "@mock",
        "with patch",
        "with mock",
        "pytest.fixture",
        "@pytest.",
        "unittest.mock",
        "monkeypatch",
        "faker.",
        "factory_boy",
    ]

    def __init__(self, config: SeverityAdjustmentConfig | None = None):
        """
        Initialize severity adjuster.

        Args:
            config: Optional configuration for adjustment behavior
        """
        self.config = config or SeverityAdjustmentConfig()

        # Compile patterns for efficiency
        self._test_patterns = [re.compile(p, re.IGNORECASE) for p in self.TEST_PATTERNS]
        self._example_patterns = [re.compile(p, re.IGNORECASE) for p in self.EXAMPLE_PATTERNS]
        self._doc_patterns = [re.compile(p, re.IGNORECASE) for p in self.DOC_PATTERNS]

        # Add custom patterns
        if self.config.custom_test_patterns:
            self._test_patterns.extend(
                [re.compile(p, re.IGNORECASE) for p in self.config.custom_test_patterns]
            )
        if self.config.custom_example_patterns:
            self._example_patterns.extend(
                [re.compile(p, re.IGNORECASE) for p in self.config.custom_example_patterns]
            )

    def adjust_severity(
        self, finding: SecurityFinding, source_code: str | None = None
    ) -> SecurityFinding:
        """
        Adjust finding severity based on context.

        Args:
            finding: The security finding to adjust
            source_code: Optional source code for additional context analysis

        Returns:
            The finding with adjusted severity (modified in place)
        """
        if not self.config.enabled:
            return finding

        reasons: list[SeverityAdjustmentReason] = []

        # Check file path context
        if self.config.adjust_test_files and self._matches_patterns(
            finding.file_path, self._test_patterns
        ):
            reasons.append(SeverityAdjustmentReason.TEST_FILE)

        if self.config.adjust_examples and self._matches_patterns(
            finding.file_path, self._example_patterns
        ):
            reasons.append(SeverityAdjustmentReason.EXAMPLE_CODE)

        if self.config.adjust_docs and self._matches_patterns(
            finding.file_path, self._doc_patterns
        ):
            reasons.append(SeverityAdjustmentReason.DOCUMENTATION)

        # Check code context for mocks
        if source_code and self._is_in_mock_context(source_code, finding.line_number):
            reasons.append(SeverityAdjustmentReason.MOCK_DATA)

        # Check for fixture files
        if "/fixtures/" in finding.file_path.lower() or "conftest" in finding.file_path.lower():
            reasons.append(SeverityAdjustmentReason.FIXTURE)

        if not reasons:
            return finding

        # Apply severity downgrades
        original_severity = finding.severity
        adjusted_severity = finding.severity

        for reason in reasons:
            rule = DOWNGRADE_RULES.get(reason, {})
            adjusted_severity = rule.get(adjusted_severity, adjusted_severity)

        # Update finding if severity changed
        if adjusted_severity != original_severity:
            finding.severity = adjusted_severity

            # Add metadata about adjustment
            if not finding.metadata:
                finding.metadata = {}
            finding.metadata["original_severity"] = original_severity.value
            finding.metadata["adjustment_reasons"] = [r.value for r in reasons]

            # Add to severity factors if available
            if hasattr(finding, "severity_factors") and finding.severity_factors is not None:
                reason_str = ", ".join(r.value for r in reasons)
                finding.severity_factors.append(
                    f"Severity downgraded from {original_severity.value} to {adjusted_severity.value}: {reason_str}"
                )

        return finding

    def should_suppress(self, finding: SecurityFinding) -> bool:
        """
        Check if a finding should be suppressed entirely.

        Args:
            finding: The finding to check

        Returns:
            True if the finding should be suppressed
        """
        # Suppress documentation findings if configured
        if self.config.suppress_in_docs and self._matches_patterns(
            finding.file_path, self._doc_patterns
        ):
            return True

        # Suppress findings below minimum severity
        if severity_value(finding.severity) < severity_value(self.config.min_severity):
            return True

        return False

    def _matches_patterns(self, path: str, patterns: list[re.Pattern]) -> bool:
        """Check if path matches any compiled pattern."""
        return any(p.search(path) for p in patterns)

    def _is_in_mock_context(self, source_code: str, line_number: int) -> bool:
        """
        Check if the line is in a mock/test context.

        Args:
            source_code: The full source code
            line_number: The line number to check

        Returns:
            True if the line appears to be in a mock context
        """
        lines = source_code.split("\n")

        if line_number < 1 or line_number > len(lines):
            return False

        # Get surrounding context (10 lines before and after)
        start = max(0, line_number - 11)
        end = min(len(lines), line_number + 10)
        context = "\n".join(lines[start:end])

        return any(indicator in context for indicator in self.MOCK_INDICATORS)

    def get_adjustment_summary(self, finding: SecurityFinding) -> str | None:
        """
        Get a human-readable summary of any severity adjustment.

        Args:
            finding: The finding to summarize

        Returns:
            Summary string or None if no adjustment
        """
        if not finding.metadata or "original_severity" not in finding.metadata:
            return None

        original = finding.metadata["original_severity"]
        reasons = finding.metadata.get("adjustment_reasons", [])

        return (
            f"Severity adjusted from {original} to {finding.severity.value} "
            f"due to: {', '.join(reasons)}"
        )


def adjust_findings(
    findings: list[SecurityFinding],
    config: SeverityAdjustmentConfig | None = None,
    source_codes: dict[str, str] | None = None,
) -> list[SecurityFinding]:
    """
    Adjust severity for a list of findings.

    Convenience function to adjust multiple findings at once.

    Args:
        findings: List of findings to adjust
        config: Optional configuration
        source_codes: Optional dict mapping file paths to source code

    Returns:
        List of adjusted findings (same objects, modified in place)
    """
    adjuster = SeverityAdjuster(config)
    source_codes = source_codes or {}

    adjusted = []
    for finding in findings:
        source = source_codes.get(finding.file_path)
        adjuster.adjust_severity(finding, source)

        if not adjuster.should_suppress(finding):
            adjusted.append(finding)

    return adjusted
