"""
Base Repository for Vantage Security Platform.

This module provides a generic base repository with common CRUD operations
that can be extended for specific entity repositories.
"""

from collections.abc import Sequence
from typing import Any, Generic, TypeVar
from uuid import UUID

from sqlalchemy import delete, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from vantage_core.security.api.database.models import Base

ModelType = TypeVar("ModelType", bound=Base)


class BaseRepository(Generic[ModelType]):
    """
    Base repository with generic CRUD operations.

    This class provides common database operations that can be
    inherited by entity-specific repositories.

    Example:
        class UserRepository(BaseRepository[User]):
            def __init__(self):
                super().__init__(User)

            async def get_by_email(self, db: AsyncSession, email: str) -> User | None:
                result = await db.execute(
                    select(User).where(User.email.ilike(email))
                )
                return result.scalar_one_or_none()
    """

    def __init__(self, model: type[ModelType]):
        """
        Initialize repository with model class.

        Args:
            model: SQLAlchemy model class
        """
        self.model = model

    async def create(
        self,
        db: AsyncSession,
        obj_in: dict[str, Any],
    ) -> ModelType:
        """
        Create a new entity.

        Args:
            db: Database session
            obj_in: Dictionary of entity attributes

        Returns:
            Created entity instance
        """
        db_obj = self.model(**obj_in)
        db.add(db_obj)
        await db.commit()
        await db.refresh(db_obj)
        return db_obj

    async def get_by_id(
        self,
        db: AsyncSession,
        id: UUID | str,
    ) -> ModelType | None:
        """
        Get entity by ID.

        Args:
            db: Database session
            id: Entity UUID

        Returns:
            Entity if found, None otherwise
        """
        if isinstance(id, str):
            id = UUID(id)

        result = await db.execute(select(self.model).where(self.model.id == id))
        return result.scalar_one_or_none()

    async def get_all(
        self,
        db: AsyncSession,
        skip: int = 0,
        limit: int = 100,
    ) -> Sequence[ModelType]:
        """
        Get all entities with pagination.

        Args:
            db: Database session
            skip: Number of records to skip
            limit: Maximum number of records to return

        Returns:
            List of entities
        """
        result = await db.execute(select(self.model).offset(skip).limit(limit))
        return result.scalars().all()

    async def get_multi(
        self,
        db: AsyncSession,
        ids: list[UUID | str],
    ) -> Sequence[ModelType]:
        """
        Get multiple entities by IDs.

        Args:
            db: Database session
            ids: List of entity UUIDs

        Returns:
            List of found entities
        """
        # Convert string IDs to UUIDs
        uuid_ids = [UUID(id) if isinstance(id, str) else id for id in ids]

        result = await db.execute(select(self.model).where(self.model.id.in_(uuid_ids)))
        return result.scalars().all()

    async def update(
        self,
        db: AsyncSession,
        id: UUID | str,
        obj_in: dict[str, Any],
    ) -> ModelType | None:
        """
        Update entity by ID.

        Args:
            db: Database session
            id: Entity UUID
            obj_in: Dictionary of attributes to update

        Returns:
            Updated entity if found, None otherwise
        """
        if isinstance(id, str):
            id = UUID(id)

        # Remove None values to avoid overwriting with nulls
        update_data = {k: v for k, v in obj_in.items() if v is not None}

        if not update_data:
            return await self.get_by_id(db, id)

        await db.execute(update(self.model).where(self.model.id == id).values(**update_data))
        await db.commit()
        return await self.get_by_id(db, id)

    async def delete(
        self,
        db: AsyncSession,
        id: UUID | str,
    ) -> bool:
        """
        Delete entity by ID.

        Args:
            db: Database session
            id: Entity UUID

        Returns:
            True if entity was deleted, False if not found
        """
        if isinstance(id, str):
            id = UUID(id)

        result = await db.execute(delete(self.model).where(self.model.id == id))
        await db.commit()
        return result.rowcount > 0

    async def count(
        self,
        db: AsyncSession,
    ) -> int:
        """
        Count total entities.

        Args:
            db: Database session

        Returns:
            Total count of entities
        """
        result = await db.execute(select(func.count()).select_from(self.model))
        return result.scalar() or 0

    async def exists(
        self,
        db: AsyncSession,
        id: UUID | str,
    ) -> bool:
        """
        Check if entity exists by ID.

        Args:
            db: Database session
            id: Entity UUID

        Returns:
            True if entity exists
        """
        if isinstance(id, str):
            id = UUID(id)

        result = await db.execute(
            select(func.count()).select_from(self.model).where(self.model.id == id)
        )
        return (result.scalar() or 0) > 0

    async def get_or_create(
        self,
        db: AsyncSession,
        defaults: dict[str, Any],
        **kwargs,
    ) -> tuple[ModelType, bool]:
        """
        Get existing entity or create new one.

        Args:
            db: Database session
            defaults: Default values for new entity
            **kwargs: Filter criteria

        Returns:
            Tuple of (entity, created) where created is True if new
        """
        # Build filter conditions
        conditions = [getattr(self.model, key) == value for key, value in kwargs.items()]

        result = await db.execute(select(self.model).where(*conditions))
        instance = result.scalar_one_or_none()

        if instance:
            return instance, False

        # Merge kwargs and defaults for new entity
        create_data = {**defaults, **kwargs}
        instance = await self.create(db, create_data)
        return instance, True

    async def bulk_create(
        self,
        db: AsyncSession,
        objects_in: list[dict[str, Any]],
    ) -> list[ModelType]:
        """
        Create multiple entities in bulk.

        Args:
            db: Database session
            objects_in: List of entity attribute dictionaries

        Returns:
            List of created entities
        """
        db_objs = [self.model(**obj) for obj in objects_in]
        db.add_all(db_objs)
        await db.commit()

        # Refresh all objects to get generated values
        for obj in db_objs:
            await db.refresh(obj)

        return db_objs

    async def bulk_delete(
        self,
        db: AsyncSession,
        ids: list[UUID | str],
    ) -> int:
        """
        Delete multiple entities by IDs.

        Args:
            db: Database session
            ids: List of entity UUIDs

        Returns:
            Number of deleted entities
        """
        uuid_ids = [UUID(id) if isinstance(id, str) else id for id in ids]

        result = await db.execute(delete(self.model).where(self.model.id.in_(uuid_ids)))
        await db.commit()
        return result.rowcount
