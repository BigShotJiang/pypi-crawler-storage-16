"""
API Routes for Vantage Security Platform.

This module defines all REST API endpoints for scanning,
results retrieval, and report generation.
"""

from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from fastapi.responses import HTMLResponse

from vantage_core.security.api.async_scan import (
    ScanJob,
    ScanJobManager,
)
from vantage_core.security.api.auth import (
    rate_limit,
    verify_api_key,
)
from vantage_core.security.api.models import (
    AsyncScanResponse,
    FindingSummary,
    ReportFormat,
    ScanRequest,
    ScanResponse,
    ScanStatus,
    WebhookConfig,
)
from vantage_core.security.pipeline.orchestrator import (
    PipelineConfig,
    PipelineResult,
    SecurityPipeline,
)

router = APIRouter(tags=["security"])

# Global job manager instance
job_manager = ScanJobManager()


def _pipeline_result_to_response(
    result: PipelineResult,
    job: ScanJob | None = None,
) -> ScanResponse:
    """Convert pipeline result to API response."""
    findings = []
    if result.scan_result:
        for finding in result.scan_result.findings:
            findings.append(
                FindingSummary(
                    id=finding.id,
                    title=finding.title,
                    severity=finding.severity.value,
                    category=finding.category.value,
                    file_path=finding.file_path,
                    line_number=finding.line_number,
                    owasp_category=finding.owasp_category.value,
                )
            )

    return ScanResponse(
        scan_id=result.scan_id,
        status=ScanStatus.COMPLETED if result.is_success else ScanStatus.FAILED,
        atss_score=result.atss_result.overall_score if result.atss_result else None,
        grade=result.atss_result.grade if result.atss_result else None,
        findings_count=len(result.scan_result.findings) if result.scan_result else 0,
        critical_count=result.scan_result.critical_count if result.scan_result else 0,
        high_count=result.scan_result.high_count if result.scan_result else 0,
        medium_count=result.scan_result.medium_count if result.scan_result else 0,
        low_count=result.scan_result.low_count if result.scan_result else 0,
        agents_scanned=result.scan_result.agents_scanned if result.scan_result else 0,
        frameworks_detected=(result.scan_result.frameworks_detected if result.scan_result else []),
        duration_ms=result.duration_ms,
        created_at=result.started_at,
        completed_at=result.completed_at,
        findings=findings,
        message="; ".join(result.errors) if result.errors else None,
    )


@router.post(
    "/scan",
    response_model=ScanResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Run synchronous security scan",
    description="Run a complete security scan on the specified project path",
)
async def run_scan(
    request: ScanRequest,
    key_data: dict = Depends(rate_limit),
) -> ScanResponse:
    """
    Run a synchronous security scan.

    This endpoint blocks until the scan is complete.
    For long-running scans, use /scan/async instead.
    """
    # Validate and sanitize path to prevent traversal attacks
    try:
        path = Path(request.path).resolve(strict=True)
    except (ValueError, RuntimeError, OSError):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid path provided",
        )

    # Validate path exists and is accessible
    if not path.exists():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Path does not exist",
        )

    # Configure pipeline
    config = PipelineConfig(
        skip_simulation=not request.include_simulation,
        skip_remediation=not request.include_remediation,
        timeout_seconds=request.timeout_seconds,
    )

    # Run scan
    pipeline = SecurityPipeline(config)
    result = pipeline.scan(path, config)

    return _pipeline_result_to_response(result)


@router.post(
    "/scan/async",
    response_model=AsyncScanResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Submit asynchronous security scan",
    description="Queue a security scan job and return immediately",
)
async def submit_async_scan(
    request: ScanRequest,
    webhook: WebhookConfig | None = None,
    key_data: dict = Depends(rate_limit),
) -> AsyncScanResponse:
    """
    Submit an asynchronous security scan.

    Returns immediately with a job ID that can be polled for results.
    """
    # Validate and sanitize path to prevent traversal attacks
    try:
        path = Path(request.path).resolve(strict=True)
    except (ValueError, RuntimeError, OSError):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid path provided",
        )

    # Validate path exists and is accessible
    if not path.exists():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Path does not exist",
        )

    # Configure pipeline
    config = PipelineConfig(
        skip_simulation=not request.include_simulation,
        skip_remediation=not request.include_remediation,
        timeout_seconds=request.timeout_seconds,
    )

    # Submit job
    job = job_manager.submit(
        path=path,
        config=config,
        webhook=webhook,
    )

    return AsyncScanResponse(
        scan_id=job.scan_id,
        status=ScanStatus(job.status),
        status_url=f"/api/v1/scan/{job.scan_id}",
        webhook_url=webhook.url if webhook else None,
        estimated_duration_seconds=60,
        message="Scan queued successfully",
    )


@router.get(
    "/scan/{scan_id}",
    response_model=ScanResponse,
    summary="Get scan results",
    description="Retrieve results for a specific scan by ID",
)
async def get_scan_result(
    scan_id: str,
    key_data: dict = Depends(verify_api_key),
) -> ScanResponse:
    """
    Get results for a specific scan.

    Returns current status and results if available.
    """
    job = job_manager.get_job(scan_id)

    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scan not found: {scan_id}",
        )

    if job.result:
        return _pipeline_result_to_response(job.result, job)

    # Return status for pending/running jobs
    return ScanResponse(
        scan_id=job.scan_id,
        status=ScanStatus(job.status),
        atss_score=None,
        grade=None,
        findings_count=0,
        critical_count=0,
        high_count=0,
        medium_count=0,
        low_count=0,
        agents_scanned=0,
        frameworks_detected=[],
        duration_ms=0,
        created_at=job.created_at,
        completed_at=None,
        message=job.error if job.error else f"Scan {job.status}",
    )


@router.get(
    "/scan/{scan_id}/report",
    summary="Get scan report",
    description="Generate and retrieve a report for a completed scan",
)
async def get_scan_report(
    scan_id: str,
    format: ReportFormat = Query(ReportFormat.JSON, description="Report format"),
    key_data: dict = Depends(verify_api_key),
):
    """
    Generate a report for a completed scan.

    Supports JSON, HTML, SARIF, and PDF formats.
    """
    job = job_manager.get_job(scan_id)

    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scan not found: {scan_id}",
        )

    if job.status != "completed" or not job.result:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Scan not completed: {scan_id}",
        )

    # Import report generators
    from vantage_core.security.reports import (
        HTMLReportGenerator,
        JSONReportGenerator,
        PDFReportGenerator,
        SARIFReportGenerator,
    )

    if format == ReportFormat.JSON:
        generator = JSONReportGenerator()
        content = generator.generate(job.result)
        return Response(
            content=content,
            media_type="application/json",
            headers={"Content-Disposition": f"attachment; filename={scan_id}-report.json"},
        )

    elif format == ReportFormat.HTML:
        generator = HTMLReportGenerator()
        content = generator.generate(job.result)
        return HTMLResponse(
            content=content,
            headers={"Content-Disposition": f"attachment; filename={scan_id}-report.html"},
        )

    elif format == ReportFormat.SARIF:
        generator = SARIFReportGenerator()
        content = generator.generate(job.result)
        return Response(
            content=content,
            media_type="application/json",
            headers={"Content-Disposition": f"attachment; filename={scan_id}-report.sarif"},
        )

    elif format == ReportFormat.PDF:
        generator = PDFReportGenerator()
        content = generator.generate(job.result)
        return Response(
            content=content,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={scan_id}-report.pdf"},
        )


@router.get(
    "/scans",
    response_model=list[ScanResponse],
    summary="List all scans",
    description="Retrieve a list of all scans for the authenticated user",
)
async def list_scans(
    status: ScanStatus | None = Query(None, description="Filter by status"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum results"),
    offset: int = Query(0, ge=0, description="Results offset"),
    key_data: dict = Depends(verify_api_key),
) -> list[ScanResponse]:
    """
    List all scans for the authenticated user.
    """
    jobs = job_manager.list_jobs()

    # Filter by status if specified
    if status:
        jobs = [j for j in jobs if j.status == status.value]

    # Apply pagination
    jobs = jobs[offset : offset + limit]

    # Convert to responses
    responses = []
    for job in jobs:
        if job.result:
            responses.append(_pipeline_result_to_response(job.result, job))
        else:
            responses.append(
                ScanResponse(
                    scan_id=job.scan_id,
                    status=ScanStatus(job.status),
                    atss_score=None,
                    grade=None,
                    findings_count=0,
                    created_at=job.created_at,
                )
            )

    return responses


@router.delete(
    "/scan/{scan_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Cancel or delete scan",
    description="Cancel a running scan or delete a completed scan",
)
async def delete_scan(
    scan_id: str,
    key_data: dict = Depends(rate_limit),
):
    """
    Cancel a running scan or delete a completed scan.
    """
    job = job_manager.get_job(scan_id)

    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scan not found: {scan_id}",
        )

    if job.status == "running":
        job_manager.cancel_job(scan_id)
    else:
        job_manager.delete_job(scan_id)

    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get(
    "/frameworks",
    summary="List supported frameworks",
    description="Get list of supported AI agent frameworks",
)
async def list_frameworks() -> dict[str, list[str]]:
    """
    List all supported AI agent frameworks.
    """
    return {
        "frameworks": [
            "langchain",
            "langgraph",
            "crewai",
            "autogen",
            "llamaindex",
            "semantic_kernel",
        ]
    }


@router.get(
    "/score/{scan_id}",
    summary="Get ATSS score details",
    description="Get detailed ATSS score breakdown for a scan",
)
async def get_score_details(
    scan_id: str,
    key_data: dict = Depends(verify_api_key),
) -> dict[str, Any]:
    """
    Get detailed ATSS score breakdown.
    """
    job = job_manager.get_job(scan_id)

    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Scan not found: {scan_id}",
        )

    if not job.result or not job.result.atss_result:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Score not available for this scan",
        )

    atss = job.result.atss_result

    return {
        "scan_id": scan_id,
        "overall_score": atss.overall_score,
        "grade": atss.grade,
        "confidence": atss.confidence,
        "breakdown": {
            "trust_score": atss.trust_score,
            "pattern_score": atss.pattern_score,
            "agent_risk_score": atss.agent_risk_score,
        },
        "recommendations": (atss.recommendations if hasattr(atss, "recommendations") else []),
    }
