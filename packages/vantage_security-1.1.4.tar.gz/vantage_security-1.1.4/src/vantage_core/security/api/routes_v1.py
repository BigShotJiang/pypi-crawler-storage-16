"""
API Routes for Vantage Security Platform - Sprint 1 Features.

This module implements API endpoints for:
- Authentication (US-606)
- File uploads (US-603)
- GitHub repository integration (US-604)
- Webhook handling
"""

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel, EmailStr, Field

from vantage_core.security.api.auth_service import (
    MFASetupResponse,
    MFAVerifyRequest,
    RefreshTokenRequest,
    UserCreate,
    auth_service,
)
from vantage_core.security.api.uploads import (
    PresignRequest,
    PresignResponse,
    UploadCompleteRequest,
    UploadStatusResponse,
    upload_service,
)
from vantage_core.security.integrations.github import (
    ConnectRepositoryRequest,
    ConnectRepositoryResponse,
    ScanRepositoryRequest,
    ScanRepositoryResponse,
    github_service,
)

# Create router for v1 API
router = APIRouter(prefix="/api/v1")

# OAuth2 scheme
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)


# =========================================================================
# Authentication Endpoints (US-606)
# =========================================================================


@router.post(
    "/auth/register",
    response_model=dict,
    status_code=status.HTTP_201_CREATED,
    tags=["authentication"],
    summary="Create new user account",
    description="Register a new user with email and password. Password must meet security requirements.",
)
async def register(request: Request, data: UserCreate) -> dict:
    """
    Register a new user account.

    - Email must be unique
    - Password must be at least 12 characters with uppercase, lowercase, digit, and special character
    - Returns user ID on success
    """
    result = await auth_service.register(data)

    if not result.success:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=result.error)

    return {
        "user_id": result.user_id,
        "message": "Registration successful. Please check your email to verify your account.",
    }


class LoginRequest(BaseModel):
    """Login request model."""

    email: EmailStr
    password: str


class LoginResponse(BaseModel):
    """Login response model."""

    access_token: str | None = None
    refresh_token: str | None = None
    token_type: str = "bearer"
    expires_in: int | None = None
    requires_mfa: bool = False
    mfa_token: str | None = None


@router.post(
    "/auth/login",
    response_model=LoginResponse,
    tags=["authentication"],
    summary="Authenticate with email/password",
    description="Login with email and password. Returns JWT tokens or MFA challenge.",
)
async def login(request: Request, data: LoginRequest) -> LoginResponse:
    """
    Authenticate user with email and password.

    If MFA is enabled, returns mfa_token for verification step.
    Otherwise returns access and refresh tokens.
    """
    result = await auth_service.login(
        data.email,
        data.password,
        client_ip=request.client.host if request.client else None,
        user_agent=request.headers.get("User-Agent"),
    )

    if not result.success:
        if result.requires_mfa:
            return LoginResponse(requires_mfa=True, mfa_token=result.mfa_token)

        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=result.error)

    if result.tokens:
        return LoginResponse(
            access_token=result.tokens.access_token,
            refresh_token=result.tokens.refresh_token,
            expires_in=result.tokens.expires_in,
        )

    return LoginResponse(requires_mfa=result.requires_mfa, mfa_token=result.mfa_token)


@router.post(
    "/auth/mfa/verify",
    response_model=LoginResponse,
    tags=["authentication"],
    summary="Verify MFA code",
    description="Complete login by verifying TOTP code from authenticator app.",
)
async def verify_mfa(request: Request, data: MFAVerifyRequest) -> LoginResponse:
    """
    Verify MFA code after initial login.

    Requires mfa_token from login response and 6-digit TOTP code.
    """
    if not data.mfa_token:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="MFA token required")

    result = await auth_service.verify_mfa(
        data.mfa_token,
        data.code,
        client_ip=request.client.host if request.client else None,
        user_agent=request.headers.get("User-Agent"),
    )

    if not result.success:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=result.error)

    return LoginResponse(
        access_token=result.tokens.access_token,
        refresh_token=result.tokens.refresh_token,
        expires_in=result.tokens.expires_in,
    )


@router.post(
    "/auth/mfa/setup",
    response_model=MFASetupResponse,
    tags=["authentication"],
    summary="Initialize MFA setup",
    description="Generate TOTP secret and QR code for authenticator app enrollment.",
)
async def setup_mfa(request: Request, token: str = Depends(oauth2_scheme)) -> MFASetupResponse:
    """
    Initialize MFA setup for authenticated user.

    Returns TOTP secret, QR code URI, and backup codes.
    User must verify with a code to complete setup.
    """
    # Validate token
    payload = auth_service.validate_access_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token"
        )

    return await auth_service.setup_mfa(payload["sub"])


class MFAConfirmRequest(BaseModel):
    """MFA setup confirmation request."""

    code: str = Field(min_length=6, max_length=6)


@router.post(
    "/auth/mfa/confirm",
    tags=["authentication"],
    summary="Confirm MFA setup",
    description="Confirm MFA setup by verifying first TOTP code.",
)
async def confirm_mfa_setup(
    request: Request, data: MFAConfirmRequest, token: str = Depends(oauth2_scheme)
) -> dict:
    """
    Confirm MFA setup with verification code.

    Must be called after /mfa/setup with valid TOTP code.
    """
    payload = auth_service.validate_access_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token"
        )

    success = await auth_service.confirm_mfa_setup(payload["sub"], data.code)

    if not success:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid verification code"
        )

    return {"message": "MFA enabled successfully"}


@router.post(
    "/auth/refresh",
    response_model=LoginResponse,
    tags=["authentication"],
    summary="Refresh access token",
    description="Get new access token using refresh token. Implements token rotation.",
)
async def refresh_token(request: Request, data: RefreshTokenRequest) -> LoginResponse:
    """
    Refresh access token using refresh token.

    The old refresh token is invalidated and a new one is issued.
    """
    result = await auth_service.refresh_tokens(
        data.refresh_token,
        client_ip=request.client.host if request.client else None,
        user_agent=request.headers.get("User-Agent"),
    )

    if not result.success:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=result.error)

    return LoginResponse(
        access_token=result.tokens.access_token,
        refresh_token=result.tokens.refresh_token,
        expires_in=result.tokens.expires_in,
    )


@router.post(
    "/auth/logout",
    tags=["authentication"],
    summary="Logout current session",
    description="Revoke current session's refresh token.",
)
async def logout(request: Request, token: str = Depends(oauth2_scheme)) -> dict:
    """
    Logout and revoke current session.
    """
    # In a full implementation, revoke the specific refresh token
    return {"message": "Logged out successfully"}


@router.post(
    "/auth/logout/all",
    tags=["authentication"],
    summary="Logout all sessions",
    description="Revoke all refresh tokens for user (sign out everywhere).",
)
async def logout_all(request: Request, token: str = Depends(oauth2_scheme)) -> dict:
    """
    Logout from all sessions by revoking all refresh tokens.
    """
    payload = auth_service.validate_access_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token"
        )

    count = await auth_service.revoke_all_sessions(payload["sub"])

    return {"message": f"Logged out from {count} session(s)"}


@router.get(
    "/auth/oauth/{provider}",
    tags=["authentication"],
    summary="Initiate OAuth flow",
    description="Start OAuth authentication flow for Google or GitHub.",
)
async def oauth_initiate(provider: str, redirect_uri: str, request: Request) -> dict:
    """
    Initiate OAuth authentication flow.

    Supported providers: google, github
    """
    if provider not in ["google", "github"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported OAuth provider: {provider}",
        )

    auth_url = await auth_service.initiate_oauth(provider, redirect_uri)

    return {"auth_url": auth_url, "provider": provider}


@router.post(
    "/auth/oauth/{provider}/callback",
    response_model=LoginResponse,
    tags=["authentication"],
    summary="Handle OAuth callback",
    description="Complete OAuth flow and create/link account.",
)
async def oauth_callback(provider: str, code: str, state: str, request: Request) -> LoginResponse:
    """
    Handle OAuth callback and complete authentication.
    """
    result = await auth_service.handle_oauth_callback(
        provider,
        code,
        state,
        client_ip=request.client.host if request.client else None,
        user_agent=request.headers.get("User-Agent"),
    )

    if not result.success:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=result.error)

    return LoginResponse(
        access_token=result.tokens.access_token,
        refresh_token=result.tokens.refresh_token,
        expires_in=result.tokens.expires_in,
    )


# =========================================================================
# File Upload Endpoints (US-603)
# =========================================================================


@router.post(
    "/uploads/presign",
    response_model=PresignResponse,
    tags=["uploads"],
    summary="Get pre-signed upload URL",
    description="Generate pre-signed URL for direct file upload. Supports .zip, .tar.gz, and .py files up to 100MB.",
)
async def get_presigned_url(
    request: Request, data: PresignRequest, token: str = Depends(oauth2_scheme)
) -> PresignResponse:
    """
    Generate pre-signed URL for file upload.

    For S3 storage, returns POST URL with required fields.
    For local storage, returns PUT URL to API endpoint.
    """
    payload = auth_service.validate_access_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token"
        )

    return await upload_service.generate_presign_url(payload["sub"], data)


@router.put(
    "/uploads/{upload_id}/file",
    tags=["uploads"],
    summary="Upload file (local storage)",
    description="Direct file upload endpoint for local storage backend.",
)
async def upload_file(upload_id: str, request: Request, token: str = Depends(oauth2_scheme)):
    """
    Upload file content directly (for local storage).

    Used when storage backend is local instead of S3.
    """
    payload = auth_service.validate_access_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token"
        )

    # Read request body
    content = await request.body()

    if not await upload_service.save_file(upload_id, content):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Upload not found")

    return {"message": "File uploaded successfully"}


@router.post(
    "/uploads/{upload_id}/complete",
    response_model=UploadStatusResponse,
    tags=["uploads"],
    summary="Mark upload complete",
    description="Mark upload as complete and trigger processing (validation, malware scan, extraction).",
)
async def complete_upload(
    upload_id: str,
    request: Request,
    data: UploadCompleteRequest = None,
    token: str = Depends(oauth2_scheme),
) -> UploadStatusResponse:
    """
    Mark upload as complete and start processing.

    Triggers validation, malware scanning, and archive extraction.
    """
    payload = auth_service.validate_access_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token"
        )

    try:
        return await upload_service.complete_upload(upload_id, payload["sub"], data)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except PermissionError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.get(
    "/uploads/{upload_id}/status",
    response_model=UploadStatusResponse,
    tags=["uploads"],
    summary="Get upload status",
    description="Check the processing status of an upload.",
)
async def get_upload_status(
    upload_id: str, request: Request, token: str = Depends(oauth2_scheme)
) -> UploadStatusResponse:
    """
    Get current status of upload processing.

    Status values: pending, uploading, scanning, processing, completed, failed, malware_detected
    """
    payload = auth_service.validate_access_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token"
        )

    try:
        return await upload_service.get_upload_status(upload_id, payload["sub"])
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except PermissionError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


# =========================================================================
# GitHub Repository Endpoints (US-604)
# =========================================================================


@router.post(
    "/repositories/connect",
    response_model=ConnectRepositoryResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["repositories"],
    summary="Connect GitHub repository",
    description="Connect a GitHub repository for scanning. Supports public and private repos.",
)
async def connect_repository(
    request: Request,
    data: ConnectRepositoryRequest,
    token: str = Depends(oauth2_scheme),
) -> ConnectRepositoryResponse:
    """
    Connect a GitHub repository.

    For private repositories, provide a Personal Access Token with repo scope.
    Returns webhook secret for configuring GitHub webhooks.
    """
    payload = auth_service.validate_access_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token"
        )

    try:
        return await github_service.connect_repository(payload["sub"], data)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/repositories",
    tags=["repositories"],
    summary="List connected repositories",
    description="List all repositories connected by the authenticated user.",
)
async def list_repositories(request: Request, token: str = Depends(oauth2_scheme)) -> list[dict]:
    """
    List user's connected repositories.
    """
    payload = auth_service.validate_access_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token"
        )

    repos = await github_service.list_repositories(payload["sub"])

    # Remove sensitive fields
    return [
        {
            "id": r["id"],
            "name": r["name"],
            "owner": r["owner"],
            "url": r["url"],
            "default_branch": r["default_branch"],
            "is_private": r["is_private"],
            "created_at": r["created_at"].isoformat(),
        }
        for r in repos
    ]


@router.post(
    "/repositories/{repo_id}/scan",
    response_model=ScanRepositoryResponse,
    tags=["repositories"],
    summary="Trigger repository scan",
    description="Trigger a security scan on a connected repository branch, tag, or commit.",
)
async def scan_repository(
    repo_id: str,
    request: Request,
    data: ScanRepositoryRequest = None,
    token: str = Depends(oauth2_scheme),
) -> ScanRepositoryResponse:
    """
    Trigger a scan on the repository.

    Specify branch, tag, or commit SHA. Defaults to repository's default branch.
    """
    payload = auth_service.validate_access_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token"
        )

    if data is None:
        data = ScanRepositoryRequest()

    try:
        return await github_service.trigger_scan(repo_id, payload["sub"], data)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except PermissionError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


@router.delete(
    "/repositories/{repo_id}",
    tags=["repositories"],
    summary="Disconnect repository",
    description="Disconnect a repository and remove all associated data.",
)
async def disconnect_repository(
    repo_id: str, request: Request, token: str = Depends(oauth2_scheme)
) -> dict:
    """
    Disconnect a repository.

    Removes repository connection and cleans up cloned files.
    """
    payload = auth_service.validate_access_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token"
        )

    try:
        await github_service.disconnect_repository(repo_id, payload["sub"])
        return {"message": "Repository disconnected successfully"}
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except PermissionError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))


# =========================================================================
# Webhook Endpoints
# =========================================================================


@router.post(
    "/webhooks/github",
    tags=["webhooks"],
    summary="Receive GitHub webhook",
    description="Endpoint for GitHub webhook events. Triggers auto-scan on push.",
)
async def github_webhook(request: Request) -> dict:
    """
    Handle GitHub webhook events.

    Verifies webhook signature and triggers scan for push events.
    """
    # Get webhook headers
    event_type = request.headers.get("X-GitHub-Event", "")
    delivery_id = request.headers.get("X-GitHub-Delivery", "")
    signature = request.headers.get("X-Hub-Signature-256", "")

    if not event_type:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing X-GitHub-Event header",
        )

    # Read payload
    payload = await request.body()

    try:
        scan_id = await github_service.handle_webhook(event_type, delivery_id, signature, payload)

        if scan_id:
            return {"status": "scan_triggered", "scan_id": scan_id}

        return {"status": "processed"}

    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
