"""
Webhook management API endpoints.

This module provides REST API endpoints for webhook registration,
configuration, testing, and delivery history.
"""

from datetime import datetime

from fastapi import APIRouter, HTTPException, Query, Request, status
from pydantic import BaseModel, Field

from vantage_core.security.notifications.webhooks import (
    WEBHOOK_EVENTS,
    DeliveryStatus,
    webhook_manager,
)

router = APIRouter(prefix="/webhooks", tags=["webhooks"])


# Request/Response Models


class WebhookCreate(BaseModel):
    """Request to create a webhook."""

    url: str = Field(..., description="Webhook endpoint URL")
    events: list[str] = Field(..., description="Events to subscribe to")
    secret: str | None = Field(None, description="Secret for HMAC signing")

    class Config:
        json_schema_extra = {
            "example": {
                "url": "https://example.com/webhook",
                "events": ["scan.completed", "scan.failed"],
                "secret": "my-webhook-secret",
            }
        }


class WebhookUpdate(BaseModel):
    """Request to update a webhook."""

    url: str | None = None
    events: list[str] | None = None
    secret: str | None = None
    is_active: bool | None = None


class WebhookResponse(BaseModel):
    """Response for a webhook."""

    id: str
    project_id: str
    url: str
    events: list[str]
    is_active: bool
    created_at: datetime
    updated_at: datetime | None = None

    class Config:
        json_schema_extra = {
            "example": {
                "id": "webhook-uuid",
                "project_id": "project-uuid",
                "url": "https://example.com/webhook",
                "events": ["scan.completed", "scan.failed"],
                "is_active": True,
                "created_at": "2025-11-21T10:00:00Z",
            }
        }


class DeliveryResponse(BaseModel):
    """Response for a webhook delivery."""

    delivery_id: str
    event_type: str
    status: str
    response_code: int | None
    attempt_number: int
    error_message: str | None
    delivered_at: datetime | None
    created_at: datetime


class TestWebhookResponse(BaseModel):
    """Response for webhook test."""

    success: bool
    delivery_id: str
    response_code: int | None
    error_message: str | None


# Endpoints


@router.get(
    "/events",
    summary="List available webhook events",
)
async def list_webhook_events() -> dict[str, list[str]]:
    """
    Get list of available webhook event types.
    """
    return {
        "events": WEBHOOK_EVENTS,
        "descriptions": {
            "scan.started": "Triggered when a scan is started",
            "scan.completed": "Triggered when a scan completes successfully",
            "scan.failed": "Triggered when a scan fails",
            "vulnerability.critical": "Triggered when a critical vulnerability is found",
            "vulnerability.high": "Triggered when a high severity vulnerability is found",
            "score.improved": "Triggered when ATSS score improves significantly",
            "score.regression": "Triggered when ATSS score declines significantly",
            "policy.violation": "Triggered when a policy violation is detected",
        },
    }


@router.post(
    "/projects/{project_id}",
    response_model=WebhookResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Register a webhook",
)
async def create_webhook(
    request: Request,
    project_id: str,
    webhook: WebhookCreate,
) -> WebhookResponse:
    """
    Register a new webhook for a project.

    The webhook will receive notifications for the specified events.
    """
    try:
        result = webhook_manager.register(
            project_id=project_id,
            url=webhook.url,
            events=webhook.events,
            secret=webhook.secret,
        )

        return WebhookResponse(
            id=result.id,
            project_id=result.project_id,
            url=result.url,
            events=result.events,
            is_active=result.is_active,
            created_at=result.created_at,
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/projects/{project_id}",
    response_model=list[WebhookResponse],
    summary="List project webhooks",
)
async def list_project_webhooks(
    request: Request,
    project_id: str,
) -> list[WebhookResponse]:
    """
    Get all webhooks registered for a project.
    """
    webhooks = webhook_manager.get_project_webhooks(project_id)

    return [
        WebhookResponse(
            id=w.id,
            project_id=w.project_id,
            url=w.url,
            events=w.events,
            is_active=w.is_active,
            created_at=w.created_at,
            updated_at=w.updated_at,
        )
        for w in webhooks
    ]


@router.get(
    "/{webhook_id}",
    response_model=WebhookResponse,
    summary="Get webhook details",
)
async def get_webhook(
    request: Request,
    webhook_id: str,
) -> WebhookResponse:
    """
    Get details of a specific webhook.
    """
    webhook = webhook_manager.get(webhook_id)

    if not webhook:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Webhook not found: {webhook_id}",
        )

    return WebhookResponse(
        id=webhook.id,
        project_id=webhook.project_id,
        url=webhook.url,
        events=webhook.events,
        is_active=webhook.is_active,
        created_at=webhook.created_at,
        updated_at=webhook.updated_at,
    )


@router.put(
    "/{webhook_id}",
    response_model=WebhookResponse,
    summary="Update webhook",
)
async def update_webhook(
    request: Request,
    webhook_id: str,
    update: WebhookUpdate,
) -> WebhookResponse:
    """
    Update webhook configuration.
    """
    webhook = webhook_manager.update(
        webhook_id=webhook_id,
        url=update.url,
        events=update.events,
        secret=update.secret,
        is_active=update.is_active,
    )

    if not webhook:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Webhook not found: {webhook_id}",
        )

    return WebhookResponse(
        id=webhook.id,
        project_id=webhook.project_id,
        url=webhook.url,
        events=webhook.events,
        is_active=webhook.is_active,
        created_at=webhook.created_at,
        updated_at=webhook.updated_at,
    )


@router.delete(
    "/{webhook_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete webhook",
)
async def delete_webhook(
    request: Request,
    webhook_id: str,
):
    """
    Delete a webhook registration.
    """
    if not webhook_manager.delete(webhook_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Webhook not found: {webhook_id}",
        )

    return None


@router.post(
    "/{webhook_id}/test",
    response_model=TestWebhookResponse,
    summary="Test webhook",
)
async def test_webhook(
    request: Request,
    webhook_id: str,
) -> TestWebhookResponse:
    """
    Send a test payload to a webhook.

    This verifies the webhook URL is reachable and properly configured.
    """
    try:
        result = await webhook_manager.test(webhook_id)

        return TestWebhookResponse(
            success=result.status == DeliveryStatus.SUCCESS,
            delivery_id=result.delivery_id,
            response_code=result.response_code,
            error_message=result.error_message,
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.get(
    "/{webhook_id}/deliveries",
    response_model=list[DeliveryResponse],
    summary="Get delivery history",
)
async def get_webhook_deliveries(
    request: Request,
    webhook_id: str,
    limit: int = Query(50, ge=1, le=100, description="Maximum results"),
) -> list[DeliveryResponse]:
    """
    Get delivery history for a webhook.

    Returns recent delivery attempts with status and response information.
    """
    # Check webhook exists
    if not webhook_manager.get(webhook_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Webhook not found: {webhook_id}",
        )

    deliveries = webhook_manager.get_deliveries(webhook_id, limit=limit)

    return [
        DeliveryResponse(
            delivery_id=d.delivery_id,
            event_type=d.event_type,
            status=d.status.value,
            response_code=d.response_code,
            attempt_number=d.attempt_number,
            error_message=d.error_message,
            delivered_at=d.delivered_at,
            created_at=d.created_at,
        )
        for d in deliveries
    ]
