"""
Scalable deduplication using Locality-Sensitive Hashing (LSH).

This replaces the O(n^2) pairwise comparison with O(n) LSH-based
deduplication that can handle millions of findings efficiently.

Techniques:
- MinHash for Jaccard similarity on code tokens
- Banded LSH for approximate nearest neighbor search
- Incremental updates without full recomputation
"""

import hashlib
import random
import re
from collections import defaultdict
from dataclasses import dataclass
from typing import Any

from vantage_core.security.models import SecurityFinding, Severity


@dataclass
class MinHashSignature:
    """MinHash signature for a code snippet."""

    finding_id: str
    signature: list[int]
    num_permutations: int


@dataclass
class LSHBucket:
    """Bucket of similar items in LSH index."""

    band_id: int
    hash_value: int
    finding_ids: list[str]


@dataclass
class DuplicateGroup:
    """Group of duplicate/similar findings."""

    group_id: str
    primary_finding: SecurityFinding
    duplicates: list[SecurityFinding]
    similarity_scores: dict[str, float]  # finding_id -> similarity
    consolidation_reason: str


class MinHasher:
    """
    MinHash signature generator for code snippets.

    Uses multiple hash permutations to estimate Jaccard similarity
    between code token sets.
    """

    def __init__(
        self,
        num_permutations: int = 128,
        ngram_size: int = 3,
        seed: int = 42,
    ):
        """
        Initialize MinHasher.

        Args:
            num_permutations: Number of hash permutations (more = higher accuracy)
            ngram_size: Size of n-grams for tokenization
            seed: Random seed for reproducibility
        """
        self.num_permutations = num_permutations
        self.ngram_size = ngram_size

        # Generate hash function coefficients
        random.seed(seed)
        self._a = [random.randint(1, 2**31 - 1) for _ in range(num_permutations)]
        self._b = [random.randint(0, 2**31 - 1) for _ in range(num_permutations)]
        self._prime = 2**31 - 1  # Mersenne prime

    def compute_signature(self, text: str) -> list[int]:
        """
        Compute MinHash signature for text.

        Args:
            text: Code snippet text

        Returns:
            List of MinHash values
        """
        # Tokenize to n-grams
        tokens = self._tokenize(text)

        if not tokens:
            return [0] * self.num_permutations

        # Hash all tokens
        token_hashes = [self._hash_token(t) for t in tokens]

        # Compute minimum hash for each permutation
        signature = []
        for i in range(self.num_permutations):
            min_hash = float("inf")
            for h in token_hashes:
                # Apply permutation: (a*x + b) mod p
                permuted = (self._a[i] * h + self._b[i]) % self._prime
                min_hash = min(min_hash, permuted)
            signature.append(int(min_hash))

        return signature

    def estimate_similarity(
        self,
        sig1: list[int],
        sig2: list[int],
    ) -> float:
        """
        Estimate Jaccard similarity from MinHash signatures.

        Args:
            sig1: First signature
            sig2: Second signature

        Returns:
            Estimated Jaccard similarity (0.0 to 1.0)
        """
        if len(sig1) != len(sig2):
            raise ValueError("Signatures must have same length")

        matches = sum(1 for a, b in zip(sig1, sig2) if a == b)
        return matches / len(sig1)

    def _tokenize(self, text: str) -> set[str]:
        """Tokenize text into n-grams."""
        # Normalize
        text = text.lower()
        text = re.sub(r"\s+", " ", text)
        text = text.strip()

        # Generate character n-grams
        if len(text) < self.ngram_size:
            return {text} if text else set()

        ngrams = set()
        for i in range(len(text) - self.ngram_size + 1):
            ngrams.add(text[i : i + self.ngram_size])

        return ngrams

    def _hash_token(self, token: str) -> int:
        """Hash a token to integer."""
        return int(hashlib.md5(token.encode()).hexdigest()[:8], 16)


class LSHIndex:
    """
    Locality-Sensitive Hashing index for approximate nearest neighbor search.

    Uses banded MinHash for efficient similarity search.
    """

    def __init__(
        self,
        num_permutations: int = 128,
        num_bands: int = 16,
        similarity_threshold: float = 0.7,
    ):
        """
        Initialize LSH index.

        Args:
            num_permutations: Number of MinHash permutations
            num_bands: Number of bands for LSH
            similarity_threshold: Minimum similarity to be considered duplicate

        Note: threshold approximately equals (1/num_bands)^(1/(num_permutations/num_bands))
        """
        self.num_permutations = num_permutations
        self.num_bands = num_bands
        self.rows_per_band = num_permutations // num_bands
        self.similarity_threshold = similarity_threshold

        self.minhasher = MinHasher(num_permutations)

        # Storage
        self._signatures: dict[str, list[int]] = {}
        self._buckets: dict[tuple[int, int], set[str]] = defaultdict(set)
        self._findings: dict[str, SecurityFinding] = {}

    def insert(self, finding: SecurityFinding) -> list[str]:
        """
        Insert finding into index and return potential duplicates.

        Args:
            finding: Security finding to index

        Returns:
            List of finding IDs that are potential duplicates
        """
        # Compute signature
        signature = self.minhasher.compute_signature(finding.code_snippet)
        self._signatures[finding.id] = signature
        self._findings[finding.id] = finding

        # Find candidates before inserting
        candidates = self._find_candidates(signature)

        # Insert into buckets
        for band_id in range(self.num_bands):
            start = band_id * self.rows_per_band
            end = start + self.rows_per_band
            band_signature = tuple(signature[start:end])
            bucket_key = (band_id, hash(band_signature))
            self._buckets[bucket_key].add(finding.id)

        return [c for c in candidates if c != finding.id]

    def query(self, finding: SecurityFinding) -> list[tuple[str, float]]:
        """
        Query for similar findings.

        Args:
            finding: Finding to search for

        Returns:
            List of (finding_id, similarity) tuples above threshold
        """
        # Compute signature
        signature = self.minhasher.compute_signature(finding.code_snippet)

        # Find candidates
        candidates = self._find_candidates(signature)

        # Verify with actual similarity
        results = []
        for candidate_id in candidates:
            if candidate_id == finding.id:
                continue

            candidate_sig = self._signatures.get(candidate_id)
            if candidate_sig:
                similarity = self.minhasher.estimate_similarity(signature, candidate_sig)
                if similarity >= self.similarity_threshold:
                    results.append((candidate_id, similarity))

        # Sort by similarity
        results.sort(key=lambda x: x[1], reverse=True)
        return results

    def _find_candidates(self, signature: list[int]) -> set[str]:
        """Find candidate matches by checking bucket collisions."""
        candidates = set()

        for band_id in range(self.num_bands):
            start = band_id * self.rows_per_band
            end = start + self.rows_per_band
            band_signature = tuple(signature[start:end])
            bucket_key = (band_id, hash(band_signature))

            if bucket_key in self._buckets:
                candidates.update(self._buckets[bucket_key])

        return candidates

    def remove(self, finding_id: str):
        """Remove finding from index."""
        if finding_id not in self._signatures:
            return

        signature = self._signatures[finding_id]

        # Remove from buckets
        for band_id in range(self.num_bands):
            start = band_id * self.rows_per_band
            end = start + self.rows_per_band
            band_signature = tuple(signature[start:end])
            bucket_key = (band_id, hash(band_signature))

            if bucket_key in self._buckets:
                self._buckets[bucket_key].discard(finding_id)

        # Remove from storage
        del self._signatures[finding_id]
        if finding_id in self._findings:
            del self._findings[finding_id]


class ScalableDeduplicator:
    """
    Scalable finding deduplication using LSH.

    Replaces O(n^2) pairwise comparison with O(n) LSH-based approach.
    Can handle millions of findings efficiently.
    """

    def __init__(
        self,
        similarity_threshold: float = 0.7,
        num_permutations: int = 128,
        num_bands: int = 16,
    ):
        """
        Initialize scalable deduplicator.

        Args:
            similarity_threshold: Minimum similarity for deduplication
            num_permutations: MinHash permutations (higher = more accurate)
            num_bands: LSH bands (higher = fewer false negatives)
        """
        self.similarity_threshold = similarity_threshold
        self.lsh_index = LSHIndex(
            num_permutations=num_permutations,
            num_bands=num_bands,
            similarity_threshold=similarity_threshold,
        )

    def deduplicate(
        self,
        findings: list[SecurityFinding],
    ) -> list[DuplicateGroup]:
        """
        Deduplicate findings using LSH.

        Time complexity: O(n) average case
        Space complexity: O(n)

        Args:
            findings: List of findings to deduplicate

        Returns:
            List of DuplicateGroup objects
        """
        if not findings:
            return []

        # Track which findings have been grouped
        grouped: set[str] = set()
        groups: list[DuplicateGroup] = []

        # Index all findings and track candidates
        candidates_map: dict[str, list[str]] = {}

        for finding in findings:
            candidates = self.lsh_index.insert(finding)
            candidates_map[finding.id] = candidates

        # Build groups from candidates
        for finding in findings:
            if finding.id in grouped:
                continue

            # Find all similar findings
            similar = self.lsh_index.query(finding)
            duplicate_ids = [fid for fid, _ in similar if fid not in grouped]

            if not duplicate_ids:
                # No duplicates, single-item group
                group = DuplicateGroup(
                    group_id=f"GRP-{finding.id[:8]}",
                    primary_finding=finding,
                    duplicates=[],
                    similarity_scores={},
                    consolidation_reason="unique",
                )
                groups.append(group)
                grouped.add(finding.id)
                continue

            # Get duplicate findings
            duplicates = []
            similarity_scores = {}

            for dup_id, score in similar:
                if dup_id in grouped:
                    continue
                dup_finding = self.lsh_index._findings.get(dup_id)
                if dup_finding:
                    duplicates.append(dup_finding)
                    similarity_scores[dup_id] = score
                    grouped.add(dup_id)

            # Select primary (highest severity)
            all_in_group = [finding] + duplicates
            all_in_group.sort(
                key=lambda f: (
                    -self._severity_rank(f.severity),
                    f.line_number,
                )
            )

            primary = all_in_group[0]
            related = all_in_group[1:]

            group = DuplicateGroup(
                group_id=f"GRP-{primary.id[:8]}",
                primary_finding=primary,
                duplicates=related,
                similarity_scores=similarity_scores,
                consolidation_reason="lsh_similarity",
            )
            groups.append(group)
            grouped.add(finding.id)

        return groups

    def deduplicate_incremental(
        self,
        new_findings: list[SecurityFinding],
    ) -> tuple[list[DuplicateGroup], list[str]]:
        """
        Incrementally add new findings and deduplicate.

        Useful for streaming/continuous scanning.

        Args:
            new_findings: New findings to add

        Returns:
            Tuple of (new groups, merged group IDs)
        """
        new_groups = []
        merged_groups = []

        for finding in new_findings:
            # Check for existing similar findings
            similar = self.lsh_index.query(finding)

            if similar:
                # Merge with existing group
                most_similar_id, similarity = similar[0]
                merged_groups.append(most_similar_id)
            else:
                # Create new group
                self.lsh_index.insert(finding)
                group = DuplicateGroup(
                    group_id=f"GRP-{finding.id[:8]}",
                    primary_finding=finding,
                    duplicates=[],
                    similarity_scores={},
                    consolidation_reason="new_unique",
                )
                new_groups.append(group)

        return new_groups, merged_groups

    def get_statistics(self) -> dict[str, Any]:
        """Get deduplication statistics."""
        return {
            "total_indexed": len(self.lsh_index._signatures),
            "num_buckets": len(self.lsh_index._buckets),
            "similarity_threshold": self.similarity_threshold,
            "num_permutations": self.lsh_index.num_permutations,
            "num_bands": self.lsh_index.num_bands,
        }

    def _severity_rank(self, severity: Severity) -> int:
        """Get numeric rank for severity."""
        ranks = {
            Severity.CRITICAL: 4,
            Severity.HIGH: 3,
            Severity.MEDIUM: 2,
            Severity.LOW: 1,
            Severity.INFO: 0,
        }
        return ranks.get(severity, 0)


class HybridDeduplicator:
    """
    Hybrid deduplication combining exact match, LSH, and semantic grouping.

    Three-tier approach:
    1. Exact hash match (fastest)
    2. LSH similarity match (fast)
    3. Semantic category grouping (slowest)
    """

    def __init__(
        self,
        exact_match_enabled: bool = True,
        lsh_enabled: bool = True,
        semantic_grouping_enabled: bool = True,
        similarity_threshold: float = 0.7,
    ):
        self.exact_match_enabled = exact_match_enabled
        self.lsh_enabled = lsh_enabled
        self.semantic_grouping_enabled = semantic_grouping_enabled

        self.lsh_deduplicator = ScalableDeduplicator(similarity_threshold=similarity_threshold)

        # Related categories that should be grouped
        self.related_categories = {
            ("prompt_injection", "code_execution"),
            ("data_leakage", "hardcoded_secret"),
            ("privilege_escalation", "excessive_agency"),
        }

    def deduplicate(
        self,
        findings: list[SecurityFinding],
    ) -> list[DuplicateGroup]:
        """
        Deduplicate using hybrid approach.

        Args:
            findings: Findings to deduplicate

        Returns:
            Deduplicated groups
        """
        if not findings:
            return []

        groups = []
        remaining = list(findings)
        grouped: set[str] = set()

        # Tier 1: Exact hash match
        if self.exact_match_enabled:
            exact_groups, remaining = self._exact_match_pass(remaining)
            for g in exact_groups:
                grouped.add(g.primary_finding.id)
                for d in g.duplicates:
                    grouped.add(d.id)
            groups.extend(exact_groups)

        # Tier 2: LSH similarity match
        if self.lsh_enabled and remaining:
            lsh_groups = self.lsh_deduplicator.deduplicate(remaining)
            for g in lsh_groups:
                if g.duplicates:  # Only add groups with duplicates
                    grouped.add(g.primary_finding.id)
                    for d in g.duplicates:
                        grouped.add(d.id)
                    groups.append(g)
            remaining = [f for f in remaining if f.id not in grouped]

        # Tier 3: Create individual groups for remaining
        for f in remaining:
            if f.id not in grouped:
                groups.append(
                    DuplicateGroup(
                        group_id=f"GRP-{f.id[:8]}",
                        primary_finding=f,
                        duplicates=[],
                        similarity_scores={},
                        consolidation_reason="unique",
                    )
                )

        return groups

    def _exact_match_pass(
        self,
        findings: list[SecurityFinding],
    ) -> tuple[list[DuplicateGroup], list[SecurityFinding]]:
        """Find exact duplicates by code hash."""
        hash_to_findings: dict[str, list[SecurityFinding]] = defaultdict(list)

        for finding in findings:
            # Hash normalized code
            code_hash = self._hash_code(finding.code_snippet)
            hash_to_findings[code_hash].append(finding)

        groups = []
        remaining = []

        for code_hash, similar_findings in hash_to_findings.items():
            if len(similar_findings) > 1:
                # Sort by severity
                similar_findings.sort(
                    key=lambda f: (
                        -self._severity_rank(f.severity),
                        f.line_number,
                    )
                )
                primary = similar_findings[0]
                duplicates = similar_findings[1:]

                groups.append(
                    DuplicateGroup(
                        group_id=f"GRP-{code_hash[:8]}",
                        primary_finding=primary,
                        duplicates=duplicates,
                        similarity_scores={d.id: 1.0 for d in duplicates},
                        consolidation_reason="exact_match",
                    )
                )
            else:
                remaining.append(similar_findings[0])

        return groups, remaining

    def _hash_code(self, code: str) -> str:
        """Hash normalized code."""
        # Normalize
        normalized = re.sub(r"\s+", " ", code.lower().strip())
        return hashlib.sha256(normalized.encode()).hexdigest()[:16]

    def _severity_rank(self, severity: Severity) -> int:
        """Get numeric rank for severity."""
        ranks = {
            Severity.CRITICAL: 4,
            Severity.HIGH: 3,
            Severity.MEDIUM: 2,
            Severity.LOW: 1,
            Severity.INFO: 0,
        }
        return ranks.get(severity, 0)


def create_deduplicator(
    scalable: bool = True,
    similarity_threshold: float = 0.7,
) -> ScalableDeduplicator | HybridDeduplicator:
    """
    Create appropriate deduplicator.

    Args:
        scalable: Use scalable LSH-based deduplication
        similarity_threshold: Minimum similarity threshold

    Returns:
        Deduplicator instance
    """
    if scalable:
        return ScalableDeduplicator(similarity_threshold=similarity_threshold)
    else:
        return HybridDeduplicator(similarity_threshold=similarity_threshold)
