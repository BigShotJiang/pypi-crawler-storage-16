"""
Audit trail logging for Vantage security scanner.

Provides immutable audit logging with hash chain integrity
for SOC 2 compliance (US-004).
"""

from __future__ import annotations

import hashlib
import json
import os
import threading
from abc import ABC, abstractmethod
from collections.abc import Iterator
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from vantage_core.security.logging.categories import AuditEventType, LogCategory
from vantage_core.security.logging.factory import LoggerFactory


@dataclass
class AuditEntry:
    """
    Immutable audit log entry with integrity hash.

    Provides a tamper-evident record of security-relevant
    operations for compliance requirements.
    """

    sequence: int
    timestamp: str
    event_type: str
    actor: str
    resource_type: str
    resource_id: str
    action: str
    outcome: str
    details: dict[str, Any]
    previous_hash: str
    entry_hash: str = ""

    def __post_init__(self):
        """Compute hash after initialization."""
        if not self.entry_hash:
            self.entry_hash = self.compute_hash()

    def compute_hash(self) -> str:
        """Compute SHA-256 hash of entry data for integrity verification."""
        data = {
            "sequence": self.sequence,
            "timestamp": self.timestamp,
            "event_type": self.event_type,
            "actor": self.actor,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "action": self.action,
            "outcome": self.outcome,
            "details": self.details,
            "previous_hash": self.previous_hash,
        }
        json_str = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(json_str.encode()).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "sequence": self.sequence,
            "timestamp": self.timestamp,
            "event_type": self.event_type,
            "actor": self.actor,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "action": self.action,
            "outcome": self.outcome,
            "details": self.details,
            "previous_hash": self.previous_hash,
            "entry_hash": self.entry_hash,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AuditEntry:
        """Create AuditEntry from dictionary."""
        return cls(
            sequence=data["sequence"],
            timestamp=data["timestamp"],
            event_type=data["event_type"],
            actor=data["actor"],
            resource_type=data["resource_type"],
            resource_id=data["resource_id"],
            action=data["action"],
            outcome=data["outcome"],
            details=data.get("details", {}),
            previous_hash=data["previous_hash"],
            entry_hash=data.get("entry_hash", ""),
        )


class AuditStorage(ABC):
    """Abstract interface for audit log storage backends."""

    @abstractmethod
    def append(self, entry: AuditEntry) -> None:
        """Append an audit entry to storage."""
        pass

    @abstractmethod
    def get_entries(
        self,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        event_type: str | None = None,
        actor: str | None = None,
        limit: int | None = None,
    ) -> Iterator[AuditEntry]:
        """Query audit entries with filters."""
        pass

    @abstractmethod
    def verify_integrity(self) -> tuple[bool, list[str]]:
        """
        Verify hash chain integrity.

        Returns:
            Tuple of (is_valid, list of error messages)
        """
        pass

    @abstractmethod
    def get_last_entry(self) -> AuditEntry | None:
        """Get the most recent audit entry."""
        pass


class FileAuditStorage(AuditStorage):
    """
    File-based audit storage with JSONL format.

    Uses append-only writes with fsync for durability and
    hash chaining for integrity verification.
    """

    def __init__(self, file_path: str | Path):
        """
        Initialize file-based audit storage.

        Args:
            file_path: Path to the audit log file
        """
        self.file_path = Path(file_path)
        self._sequence = 0
        self._last_hash = "genesis"
        self._lock = threading.Lock()
        self._logger = LoggerFactory.get_logger(LogCategory.AUDIT)

        # Ensure directory exists
        self.file_path.parent.mkdir(parents=True, exist_ok=True)

        # Load state from existing file
        self._load_state()

    def _load_state(self) -> None:
        """Load sequence and last hash from existing log file."""
        if not self.file_path.exists():
            return

        try:
            last_entry = self.get_last_entry()
            if last_entry:
                self._sequence = last_entry.sequence
                self._last_hash = last_entry.entry_hash
        except Exception as e:
            self._logger.error(
                "audit_state_load_failed",
                error=str(e),
                file_path=str(self.file_path),
            )

    def append(self, entry: AuditEntry) -> None:
        """
        Append entry to JSONL file with fsync.

        Thread-safe with file locking.
        """
        with self._lock:
            # Update entry with current state
            entry.sequence = self._sequence + 1
            entry.previous_hash = self._last_hash
            entry.entry_hash = entry.compute_hash()

            try:
                with open(self.file_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(entry.to_dict(), default=str) + "\n")
                    f.flush()
                    os.fsync(f.fileno())

                # Update state
                self._sequence = entry.sequence
                self._last_hash = entry.entry_hash

                self._logger.debug(
                    "audit_entry_written",
                    sequence=entry.sequence,
                    event_type=entry.event_type,
                )

            except Exception as e:
                self._logger.error(
                    "audit_write_failed",
                    error=str(e),
                    sequence=entry.sequence,
                    exc_info=True,
                )
                raise

    def get_entries(
        self,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        event_type: str | None = None,
        actor: str | None = None,
        limit: int | None = None,
    ) -> Iterator[AuditEntry]:
        """Query audit entries with filters."""
        if not self.file_path.exists():
            return

        count = 0
        with open(self.file_path, encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue

                try:
                    data = json.loads(line)
                    entry = AuditEntry.from_dict(data)

                    # Apply filters
                    if start_time:
                        entry_time = datetime.fromisoformat(entry.timestamp.replace("Z", "+00:00"))
                        if entry_time < start_time:
                            continue

                    if end_time:
                        entry_time = datetime.fromisoformat(entry.timestamp.replace("Z", "+00:00"))
                        if entry_time > end_time:
                            continue

                    if event_type and entry.event_type != event_type:
                        continue

                    if actor and entry.actor != actor:
                        continue

                    yield entry
                    count += 1

                    if limit and count >= limit:
                        break

                except json.JSONDecodeError as e:
                    self._logger.warning(
                        "audit_entry_parse_failed",
                        line=line[:100],
                        error=str(e),
                    )
                    continue

    def get_last_entry(self) -> AuditEntry | None:
        """Get the most recent audit entry."""
        if not self.file_path.exists():
            return None

        last_line = None
        with open(self.file_path, encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    last_line = line

        if last_line:
            try:
                data = json.loads(last_line)
                return AuditEntry.from_dict(data)
            except json.JSONDecodeError:
                return None

        return None

    def verify_integrity(self) -> tuple[bool, list[str]]:
        """
        Verify hash chain integrity.

        Returns:
            Tuple of (is_valid, list of error messages)
        """
        errors: list[str] = []

        if not self.file_path.exists():
            return True, []

        previous_hash = "genesis"
        expected_sequence = 1

        for entry in self.get_entries():
            # Check sequence
            if entry.sequence != expected_sequence:
                errors.append(f"Sequence gap: expected {expected_sequence}, got {entry.sequence}")

            # Check previous hash
            if entry.previous_hash != previous_hash:
                errors.append(
                    f"Hash chain broken at sequence {entry.sequence}: "
                    f"expected previous_hash {previous_hash[:16]}..., "
                    f"got {entry.previous_hash[:16]}..."
                )

            # Verify entry hash
            computed_hash = entry.compute_hash()
            if entry.entry_hash != computed_hash:
                errors.append(
                    f"Entry hash mismatch at sequence {entry.sequence}: "
                    f"stored {entry.entry_hash[:16]}..., "
                    f"computed {computed_hash[:16]}..."
                )

            previous_hash = entry.entry_hash
            expected_sequence = entry.sequence + 1

        is_valid = len(errors) == 0

        if not is_valid:
            self._logger.warning(
                "audit_integrity_check_failed",
                error_count=len(errors),
                errors=errors[:5],  # Log first 5 errors
            )
        else:
            self._logger.info(
                "audit_integrity_verified",
                entries_checked=expected_sequence - 1,
            )

        return is_valid, errors


class AuditLogger:
    """
    High-level audit logging interface.

    Provides convenient methods for logging common audit events
    with automatic context and integrity tracking.
    """

    def __init__(
        self,
        storage: AuditStorage | None = None,
        actor: str | None = None,
    ):
        """
        Initialize audit logger.

        Args:
            storage: Audit storage backend (defaults to file-based)
            actor: Default actor for audit entries
        """
        if storage is None:
            audit_file = os.environ.get("MIMIC_AUDIT_FILE", "audit.jsonl")
            storage = FileAuditStorage(audit_file)

        self._storage = storage
        self._default_actor = actor or os.environ.get("USER", "system")
        self._logger = LoggerFactory.get_logger(LogCategory.AUDIT)

    def log_scan_started(
        self,
        scan_id: str,
        target_path: str,
        config: dict[str, Any] | None = None,
        actor: str | None = None,
    ) -> None:
        """Log scan start event."""
        entry = AuditEntry(
            sequence=0,  # Will be set by storage
            timestamp=datetime.utcnow().isoformat() + "Z",
            event_type=AuditEventType.SCAN_STARTED.value,
            actor=actor or self._default_actor,
            resource_type="scan",
            resource_id=scan_id,
            action="start",
            outcome="initiated",
            details={
                "target_path": target_path,
                "config": self._sanitize_config(config) if config else {},
            },
            previous_hash="",  # Will be set by storage
        )
        self._storage.append(entry)

    def log_scan_completed(
        self,
        scan_id: str,
        findings_count: int,
        duration_ms: float,
        status: str = "success",
        actor: str | None = None,
    ) -> None:
        """Log scan completion event."""
        entry = AuditEntry(
            sequence=0,
            timestamp=datetime.utcnow().isoformat() + "Z",
            event_type=AuditEventType.SCAN_COMPLETED.value,
            actor=actor or self._default_actor,
            resource_type="scan",
            resource_id=scan_id,
            action="complete",
            outcome=status,
            details={
                "findings_count": findings_count,
                "duration_ms": round(duration_ms, 2),
            },
            previous_hash="",
        )
        self._storage.append(entry)

    def log_scan_failed(
        self,
        scan_id: str,
        error: str,
        error_code: str | None = None,
        actor: str | None = None,
    ) -> None:
        """Log scan failure event."""
        entry = AuditEntry(
            sequence=0,
            timestamp=datetime.utcnow().isoformat() + "Z",
            event_type=AuditEventType.SCAN_FAILED.value,
            actor=actor or self._default_actor,
            resource_type="scan",
            resource_id=scan_id,
            action="complete",
            outcome="failed",
            details={
                "error": error,
                "error_code": error_code,
            },
            previous_hash="",
        )
        self._storage.append(entry)

    def log_config_changed(
        self,
        key: str,
        old_value: Any,
        new_value: Any,
        source: str = "api",
        actor: str | None = None,
    ) -> None:
        """Log configuration change event."""
        entry = AuditEntry(
            sequence=0,
            timestamp=datetime.utcnow().isoformat() + "Z",
            event_type=AuditEventType.CONFIG_CHANGED.value,
            actor=actor or self._default_actor,
            resource_type="config",
            resource_id=key,
            action="change",
            outcome="success",
            details={
                "old_value": self._sanitize_value(old_value),
                "new_value": self._sanitize_value(new_value),
                "source": source,
            },
            previous_hash="",
        )
        self._storage.append(entry)

    def log_finding_suppressed(
        self,
        finding_id: str,
        reason: str,
        scan_id: str | None = None,
        actor: str | None = None,
    ) -> None:
        """Log finding suppression event."""
        entry = AuditEntry(
            sequence=0,
            timestamp=datetime.utcnow().isoformat() + "Z",
            event_type=AuditEventType.FINDING_SUPPRESSED.value,
            actor=actor or self._default_actor,
            resource_type="finding",
            resource_id=finding_id,
            action="suppress",
            outcome="success",
            details={
                "reason": reason,
                "scan_id": scan_id,
            },
            previous_hash="",
        )
        self._storage.append(entry)

    def verify_integrity(self) -> tuple[bool, list[str]]:
        """Verify audit log integrity."""
        return self._storage.verify_integrity()

    @staticmethod
    def _sanitize_config(config: dict[str, Any]) -> dict[str, Any]:
        """Sanitize configuration to remove sensitive values."""
        sanitized = {}
        sensitive_keys = {"password", "secret", "token", "key", "credential"}

        for key, value in config.items():
            key_lower = key.lower()
            if any(s in key_lower for s in sensitive_keys):
                sanitized[key] = "***REDACTED***"
            elif isinstance(value, dict):
                sanitized[key] = AuditLogger._sanitize_config(value)
            else:
                sanitized[key] = value

        return sanitized

    @staticmethod
    def _sanitize_value(value: Any) -> Any:
        """Sanitize a single value."""
        if isinstance(value, dict):
            return AuditLogger._sanitize_config(value)
        return value
