"""
Lightweight vulnerability detector using biLSTM.

This is a fast alternative to transformer-based models:
- Model size: ~2MB (vs 500MB for CodeBERT)
- Inference time: ~10ms (vs ~45s for CodeBERT)
- Training time: ~1 minute (vs ~1 hour for CodeBERT)

Based on the SOARSMU Compressor research which showed biLSTM
can achieve competitive accuracy with much smaller size.
"""

import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

# Optional ML imports
try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch.utils.data import DataLoader, Dataset

    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    import onnxruntime as ort

    ONNX_AVAILABLE = True
except ImportError:
    ONNX_AVAILABLE = False


@dataclass
class LightweightPrediction:
    """Prediction result from lightweight detector."""

    is_vulnerable: bool
    confidence: float
    vulnerability_type: str | None = None
    cwe_id: str | None = None
    explanation: str = ""


class BiLSTMVulnerabilityModel(nn.Module):
    """
    Bidirectional LSTM for vulnerability detection.

    Architecture:
    - Embedding layer (vocab_size -> 128)
    - 2-layer BiLSTM (128 -> 64 hidden)
    - Dense layer (128 -> 64)
    - Output layer (64 -> 2)

    Total params: ~2M (vs 125M for CodeBERT)
    """

    def __init__(
        self,
        vocab_size: int = 10000,
        embedding_dim: int = 128,
        hidden_dim: int = 64,
        n_layers: int = 2,
        dropout: float = 0.2,
    ):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.lstm = nn.LSTM(
            input_size=embedding_dim,
            hidden_size=hidden_dim,
            num_layers=n_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if n_layers > 1 else 0,
        )
        self.dense = nn.Linear(hidden_dim * 2, 64)
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(64, 2)

    def forward(self, input_ids, labels=None):
        # input_ids: (batch, seq_len)
        embed = self.embedding(input_ids)  # (batch, seq_len, embed_dim)

        # LSTM
        outputs, (hidden, _) = self.lstm(embed)

        # Concatenate forward and backward hidden states
        hidden = hidden.permute(1, 0, 2)  # (batch, n_layers*2, hidden)
        hidden = torch.cat((hidden[:, -1, :], hidden[:, -2, :]), dim=1)  # (batch, hidden*2)

        # Dense layers
        x = F.relu(self.dense(hidden))
        x = self.dropout(x)
        logits = self.fc(x)  # (batch, 2)

        prob = F.softmax(logits, dim=1)

        if labels is not None:
            loss = F.cross_entropy(logits, labels)
            return loss, prob
        return prob


class SimpleTokenizer:
    """
    Simple tokenizer for code.

    Uses basic word tokenization with special handling for:
    - Python/JavaScript keywords
    - Common vulnerability patterns
    - Code structure tokens
    """

    SPECIAL_TOKENS = {
        "<PAD>": 0,
        "<UNK>": 1,
        "<CLS>": 2,
        "<SEP>": 3,
    }

    # Common code tokens to preserve
    CODE_TOKENS = [
        "def",
        "class",
        "return",
        "if",
        "else",
        "for",
        "while",
        "try",
        "except",
        "import",
        "from",
        "as",
        "with",
        "lambda",
        "yield",
        "raise",
        "pass",
        "function",
        "var",
        "let",
        "const",
        "async",
        "await",
        "new",
        "this",
        # Security-relevant tokens
        "eval",
        "exec",
        "system",
        "shell",
        "subprocess",
        "os",
        "cmd",
        "sql",
        "query",
        "select",
        "insert",
        "update",
        "delete",
        "where",
        "pickle",
        "yaml",
        "json",
        "load",
        "loads",
        "dump",
        "dumps",
        "input",
        "request",
        "user",
        "password",
        "secret",
        "key",
        "token",
        "file",
        "open",
        "read",
        "write",
        "path",
        "url",
        "http",
    ]

    def __init__(self, vocab_size: int = 10000):
        self.vocab_size = vocab_size
        self.word2idx = dict(self.SPECIAL_TOKENS)
        self.idx2word = {v: k for k, v in self.word2idx.items()}

        # Add code tokens
        for token in self.CODE_TOKENS:
            if token not in self.word2idx:
                idx = len(self.word2idx)
                self.word2idx[token] = idx
                self.idx2word[idx] = token

    def tokenize(self, code: str) -> list[str]:
        """Tokenize code into tokens."""
        # Normalize
        code = code.lower()

        # Split on whitespace and punctuation
        tokens = re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*|[0-9]+|[^\s\w]", code)

        return tokens

    def encode(self, code: str, max_length: int = 256) -> list[int]:
        """Encode code to token IDs."""
        tokens = self.tokenize(code)

        # Add special tokens
        tokens = ["<CLS>"] + tokens[: max_length - 2] + ["<SEP>"]

        # Convert to IDs
        ids = []
        for token in tokens:
            if token in self.word2idx:
                ids.append(self.word2idx[token])
            else:
                # Hash unknown tokens to vocab range
                idx = hash(token) % (self.vocab_size - len(self.SPECIAL_TOKENS)) + len(
                    self.SPECIAL_TOKENS
                )
                ids.append(idx)

        # Pad to max_length
        if len(ids) < max_length:
            ids.extend([0] * (max_length - len(ids)))

        return ids[:max_length]

    def build_vocab(self, texts: list[str], min_freq: int = 2):
        """Build vocabulary from texts."""
        word_freq = {}
        for text in texts:
            for token in self.tokenize(text):
                word_freq[token] = word_freq.get(token, 0) + 1

        # Sort by frequency
        sorted_words = sorted(word_freq.items(), key=lambda x: -x[1])

        # Add to vocab
        for word, freq in sorted_words:
            if freq >= min_freq and word not in self.word2idx:
                if len(self.word2idx) >= self.vocab_size:
                    break
                idx = len(self.word2idx)
                self.word2idx[word] = idx
                self.idx2word[idx] = word

    def save(self, path: str):
        """Save tokenizer to file."""
        with open(path, "w") as f:
            json.dump({"word2idx": self.word2idx}, f)

    def load(self, path: str):
        """Load tokenizer from file."""
        with open(path) as f:
            data = json.load(f)
            self.word2idx = data["word2idx"]
            self.idx2word = {int(v): k for k, v in self.word2idx.items()}


class LightweightVulnerabilityDetector:
    """
    Fast, lightweight vulnerability detector.

    Uses biLSTM model (~2MB) for fast inference.
    Falls back to pattern matching if model not available.

    Typical performance:
    - Model loading: <1 second
    - Inference: ~10ms per sample
    """

    def __init__(
        self,
        model_path: str | Path | None = None,
        use_onnx: bool = True,
    ):
        self.model_path = Path(model_path) if model_path else None
        self.use_onnx = use_onnx and ONNX_AVAILABLE

        self.model = None
        self.tokenizer = None
        self.onnx_session = None
        self.device = "cpu"
        self._initialized = False

    def initialize(self) -> bool:
        """Initialize the model."""
        if not TORCH_AVAILABLE:
            logger.warning("PyTorch not available, using pattern matching only")
            return False

        try:
            self.tokenizer = SimpleTokenizer()

            # Try to load ONNX model first (faster)
            if self.use_onnx and self.model_path:
                onnx_path = self.model_path.with_suffix(".onnx")
                if onnx_path.exists():
                    logger.info(f"Loading ONNX model from {onnx_path}")
                    self.onnx_session = ort.InferenceSession(str(onnx_path))
                    self._initialized = True
                    return True

            # Fall back to PyTorch model
            if self.model_path and self.model_path.exists():
                logger.info(f"Loading PyTorch model from {self.model_path}")
                self.model = BiLSTMVulnerabilityModel()
                state_dict = torch.load(self.model_path, map_location=self.device)
                self.model.load_state_dict(state_dict)
                self.model.eval()
                self._initialized = True
                return True

            # No pre-trained model, use pattern matching
            logger.info("No pre-trained model found, using pattern matching")
            return False

        except Exception as e:
            logger.error(f"Error initializing model: {e}")
            return False

    def predict(self, code: str) -> LightweightPrediction:
        """Predict vulnerability in code."""
        # Always try pattern matching first (fast path)
        pattern_result = self._pattern_predict(code)
        if pattern_result.confidence > 0.7:
            return pattern_result

        # If model is available, use it for uncertain cases
        if self._initialized:
            return self._model_predict(code)

        return pattern_result

    def _model_predict(self, code: str) -> LightweightPrediction:
        """Use ML model for prediction."""
        try:
            input_ids = self.tokenizer.encode(code)

            if self.onnx_session:
                # ONNX inference
                input_array = [[input_ids]]
                outputs = self.onnx_session.run(None, {"input_ids": input_array})
                prob = outputs[0][0]
            else:
                # PyTorch inference
                input_tensor = torch.tensor([input_ids], dtype=torch.long)
                with torch.no_grad():
                    prob = self.model(input_tensor).numpy()[0]

            is_vulnerable = prob[1] > prob[0]
            confidence = float(max(prob))

            # Get vulnerability type from patterns
            vuln_type, cwe = self._detect_vuln_type(code)

            return LightweightPrediction(
                is_vulnerable=is_vulnerable,
                confidence=confidence,
                vulnerability_type=vuln_type,
                cwe_id=cwe,
                explanation=f"ML model prediction (confidence: {confidence:.1%})",
            )

        except Exception as e:
            logger.error(f"Model prediction error: {e}")
            return self._pattern_predict(code)

    def _pattern_predict(self, code: str) -> LightweightPrediction:
        """Fast pattern-based prediction."""
        code_lower = code.lower()

        # Vulnerability patterns with (pattern, cwe, type, base_confidence)
        # Note: Order matters - more specific patterns should come first
        patterns = [
            # Command injection
            (r"os\.system\s*\([^)]*\+", "CWE-78", "command_injection", 0.85),
            (
                r"os\.system\s*\([^)]*(?:input|user|request|arg)",
                "CWE-78",
                "command_injection",
                0.80,
            ),
            (
                r"subprocess\.[^(]+\([^)]*shell\s*=\s*True",
                "CWE-78",
                "command_injection",
                0.80,
            ),
            # Code injection - eval/exec with dynamic content
            # Match: eval(var), eval(x + y), eval(input), eval(f"...")
            # Skip: eval("literal"), eval('literal')
            (r"eval\s*\([^)]*\+", "CWE-94", "code_injection", 0.90),
            (r'eval\s*\(f["\']', "CWE-94", "code_injection", 0.88),
            (
                r"eval\s*\([^)]*(?:input|user|request|data|var)",
                "CWE-94",
                "code_injection",
                0.85,
            ),
            (r"exec\s*\([^)]*\+", "CWE-94", "code_injection", 0.90),
            (r'exec\s*\(f["\']', "CWE-94", "code_injection", 0.88),
            (
                r"exec\s*\([^)]*(?:input|user|request|data|var)",
                "CWE-94",
                "code_injection",
                0.85,
            ),
            # SQL injection - string concatenation in queries (dangerous)
            (r"execute\s*\([^)]*\+[^)]*\)", "CWE-89", "sql_injection", 0.85),
            (r'execute\s*\(f["\']', "CWE-89", "sql_injection", 0.80),
            (r"select\s+.*\s+from\s+.*\s*\+", "CWE-89", "sql_injection", 0.80),
            (r'f["\']select.*\{', "CWE-89", "sql_injection", 0.80),
            (r'["\']select\s+.*\s*%\s*["\']?\s*%', "CWE-89", "sql_injection", 0.75),
            # Deserialization
            (r"pickle\.loads?\s*\(", "CWE-502", "deserialization", 0.75),
            (
                r"yaml\.load\s*\([^)]*\)(?!\s*,\s*Loader)",
                "CWE-502",
                "deserialization",
                0.70,
            ),
            (r"yaml\.unsafe_load", "CWE-502", "deserialization", 0.85),
            (r"marshal\.loads?\s*\(", "CWE-502", "deserialization", 0.75),
            # Path traversal
            (r"open\s*\([^)]*\+[^)]*\)", "CWE-22", "path_traversal", 0.70),
            (r"open\s*\([^)]*(?:input|user|request)", "CWE-22", "path_traversal", 0.70),
            (r"\.\./", "CWE-22", "path_traversal", 0.60),
            # XSS
            (r"innerHTML\s*=", "CWE-79", "xss", 0.65),
            (r"document\.write\s*\(", "CWE-79", "xss", 0.70),
            (r"v-html\s*=", "CWE-79", "xss", 0.65),
            # Hardcoded secrets
            (r'password\s*=\s*["\'][^"\']+["\']', "CWE-798", "hardcoded_secret", 0.70),
            (r'api_key\s*=\s*["\'][^"\']+["\']', "CWE-798", "hardcoded_secret", 0.70),
            (r'secret\s*=\s*["\'][^"\']+["\']', "CWE-798", "hardcoded_secret", 0.65),
            (
                r'token\s*=\s*["\'][a-zA-Z0-9]{20,}["\']',
                "CWE-798",
                "hardcoded_secret",
                0.70,
            ),
        ]

        best_match = None
        best_confidence = 0.0

        for pattern, cwe, vuln_type, confidence in patterns:
            if re.search(pattern, code_lower):
                if confidence > best_confidence:
                    best_confidence = confidence
                    best_match = (vuln_type, cwe)

        if best_match:
            return LightweightPrediction(
                is_vulnerable=True,
                confidence=best_confidence,
                vulnerability_type=best_match[0],
                cwe_id=best_match[1],
                explanation=f"Pattern match: {best_match[0]}",
            )

        return LightweightPrediction(
            is_vulnerable=False,
            confidence=0.7,
            vulnerability_type=None,
            cwe_id=None,
            explanation="No vulnerability patterns detected",
        )

    def _detect_vuln_type(self, code: str) -> tuple[str | None, str | None]:
        """Detect vulnerability type from code patterns."""
        code_lower = code.lower()

        type_patterns = [
            ("command_injection", "CWE-78", ["os.system", "subprocess", "shell=true"]),
            ("code_injection", "CWE-94", ["eval(", "exec("]),
            (
                "sql_injection",
                "CWE-89",
                ["select", "insert", "update", "delete", "execute"],
            ),
            ("deserialization", "CWE-502", ["pickle", "yaml.load"]),
            ("xss", "CWE-79", ["innerhtml", "document.write"]),
            ("path_traversal", "CWE-22", ["../", "open("]),
        ]

        for vuln_type, cwe, keywords in type_patterns:
            if any(kw in code_lower for kw in keywords):
                return vuln_type, cwe

        return None, None


def train_lightweight_model(
    train_data: list[dict],
    val_data: list[dict] | None = None,
    output_path: str = "models/lightweight_vuln_detector.pt",
    epochs: int = 10,
    batch_size: int = 32,
    learning_rate: float = 1e-3,
) -> dict:
    """
    Train a lightweight biLSTM model.

    Args:
        train_data: List of {"code": str, "is_vulnerable": bool}
        val_data: Optional validation data
        output_path: Where to save the model
        epochs: Number of training epochs
        batch_size: Batch size
        learning_rate: Learning rate

    Returns:
        Training metrics
    """
    if not TORCH_AVAILABLE:
        raise RuntimeError("PyTorch required for training")

    logger.info("Training lightweight vulnerability detector...")

    # Initialize tokenizer and build vocab
    tokenizer = SimpleTokenizer()
    tokenizer.build_vocab([d["code"] for d in train_data])

    # Prepare datasets
    class CodeDataset(Dataset):
        def __init__(self, data, tokenizer, max_length=256):
            self.data = data
            self.tokenizer = tokenizer
            self.max_length = max_length

        def __len__(self):
            return len(self.data)

        def __getitem__(self, idx):
            item = self.data[idx]
            input_ids = self.tokenizer.encode(item["code"], self.max_length)
            label = 1 if item.get("is_vulnerable", False) else 0
            return {
                "input_ids": torch.tensor(input_ids, dtype=torch.long),
                "labels": torch.tensor(label, dtype=torch.long),
            }

    train_dataset = CodeDataset(train_data, tokenizer)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

    val_loader = None
    if val_data:
        val_dataset = CodeDataset(val_data, tokenizer)
        val_loader = DataLoader(val_dataset, batch_size=batch_size)

    # Initialize model
    model = BiLSTMVulnerabilityModel(vocab_size=tokenizer.vocab_size)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    # Training loop
    best_val_acc = 0.0
    history = []

    for epoch in range(epochs):
        model.train()
        total_loss = 0.0
        correct = 0
        total = 0

        for batch in train_loader:
            optimizer.zero_grad()

            input_ids = batch["input_ids"]
            labels = batch["labels"]

            loss, prob = model(input_ids, labels)
            loss.backward()
            optimizer.step()

            total_loss += loss.item()
            preds = prob.argmax(dim=1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)

        train_acc = correct / total
        train_loss = total_loss / len(train_loader)

        # Validation
        val_acc = 0.0
        if val_loader:
            model.eval()
            correct = 0
            total = 0
            with torch.no_grad():
                for batch in val_loader:
                    input_ids = batch["input_ids"]
                    labels = batch["labels"]
                    prob = model(input_ids)
                    preds = prob.argmax(dim=1)
                    correct += (preds == labels).sum().item()
                    total += labels.size(0)
            val_acc = correct / total

        logger.info(
            f"Epoch {epoch+1}/{epochs}: loss={train_loss:.4f}, acc={train_acc:.2%}, val_acc={val_acc:.2%}"
        )

        history.append(
            {
                "epoch": epoch + 1,
                "train_loss": train_loss,
                "train_acc": train_acc,
                "val_acc": val_acc,
            }
        )

        # Save best model
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(model.state_dict(), output_path)
            tokenizer.save(str(Path(output_path).with_suffix(".vocab.json")))
            logger.info(f"Saved best model (val_acc={val_acc:.2%})")

    return {
        "status": "completed",
        "epochs": epochs,
        "best_val_acc": best_val_acc,
        "history": history,
    }


def export_to_onnx(
    model_path: str,
    output_path: str | None = None,
    max_length: int = 256,
):
    """Export PyTorch model to ONNX for faster inference."""
    if not TORCH_AVAILABLE:
        raise RuntimeError("PyTorch required for export")

    if output_path is None:
        output_path = str(Path(model_path).with_suffix(".onnx"))

    # Load model
    model = BiLSTMVulnerabilityModel()
    model.load_state_dict(torch.load(model_path, map_location="cpu"))
    model.eval()

    # Export
    dummy_input = torch.zeros(1, max_length, dtype=torch.long)
    torch.onnx.export(
        model,
        dummy_input,
        output_path,
        input_names=["input_ids"],
        output_names=["probabilities"],
        dynamic_axes={
            "input_ids": {0: "batch_size"},
            "probabilities": {0: "batch_size"},
        },
        opset_version=11,
    )

    logger.info(f"Exported ONNX model to {output_path}")
    return output_path
