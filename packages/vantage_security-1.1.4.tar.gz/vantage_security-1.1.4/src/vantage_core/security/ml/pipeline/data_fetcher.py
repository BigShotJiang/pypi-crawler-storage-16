"""
Validated vulnerability data fetcher from authoritative sources.

All API endpoints verified as of November 2025.

Sources:
- OSV API (https://api.osv.dev) - Aggregates PyPI, npm, Go, Rust, Ruby, etc.
- NVD API 2.0 (https://services.nvd.nist.gov) - National Vulnerability Database
- GitHub Advisory API (https://api.github.com/advisories) - GHSA database
- Go Vulnerability Database (https://vuln.go.dev) - Official Go vulns

Documentation:
- OSV: https://google.github.io/osv.dev/api/
- NVD: https://nvd.nist.gov/developers/vulnerabilities
- GitHub: https://docs.github.com/en/rest/security-advisories/global-advisories
- Go: https://go.dev/security/vuln/database
"""

import json
import logging
import os
import sqlite3
import time
from collections.abc import Iterator
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path

import requests

logger = logging.getLogger(__name__)


@dataclass
class Vulnerability:
    """A vulnerability from any source."""

    id: str
    source: str  # osv, nvd, ghsa, go-vuln
    cve_id: str | None
    cwe_ids: list[str]
    cvss_score: float | None
    severity: str
    title: str
    description: str
    code_sample: str | None
    fixed_code: str | None
    affected_packages: list[dict]
    references: list[str]
    published_at: str
    updated_at: str
    language: str
    vulnerability_type: str
    is_vulnerable: bool = True
    metadata: dict = field(default_factory=dict)

    def to_training_format(self) -> dict:
        """Convert to model training format."""
        return {
            "id": self.id,
            "code": self.code_sample or self.description[:500],
            "fixed_code": self.fixed_code,
            "cwe_id": self.cwe_ids[0] if self.cwe_ids else None,
            "severity": self.severity,
            "vulnerability_type": self.vulnerability_type,
            "language": self.language,
            "source": self.source,
            "description": self.description,
            "is_vulnerable": self.is_vulnerable,
        }


class VulnerabilityDataFetcher:
    """
    Fetches vulnerability data from all validated authoritative sources.

    Validated API Endpoints:
    - OSV: POST https://api.osv.dev/v1/query
    - OSV: POST https://api.osv.dev/v1/querybatch
    - OSV: GET https://api.osv.dev/v1/vulns/{id}
    - NVD: GET https://services.nvd.nist.gov/rest/json/cves/2.0
    - GitHub: GET https://api.github.com/advisories
    - Go: GET https://vuln.go.dev/index/vulns.json
    - Go: GET https://vuln.go.dev/ID/{id}.json
    """

    # Validated API endpoints
    OSV_API_QUERY = "https://api.osv.dev/v1/query"
    OSV_API_BATCH = "https://api.osv.dev/v1/querybatch"
    OSV_API_VULN = "https://api.osv.dev/v1/vulns"
    NVD_API = "https://services.nvd.nist.gov/rest/json/cves/2.0"
    GITHUB_API = "https://api.github.com/advisories"
    GO_VULN_INDEX = "https://vuln.go.dev/index/vulns.json"
    GO_VULN_DETAIL = "https://vuln.go.dev/ID"

    # OSV ecosystems and their languages
    OSV_ECOSYSTEMS = {
        "PyPI": "python",
        "npm": "javascript",
        "crates.io": "rust",
        "Go": "go",
        "RubyGems": "ruby",
        "Packagist": "php",
        "Maven": "java",
        "NuGet": "csharp",
    }

    # CWE to vulnerability type mapping
    CWE_TYPE_MAP = {
        "CWE-78": "command_injection",
        "CWE-77": "command_injection",
        "CWE-79": "xss",
        "CWE-89": "sql_injection",
        "CWE-94": "code_injection",
        "CWE-95": "code_injection",
        "CWE-22": "path_traversal",
        "CWE-23": "path_traversal",
        "CWE-502": "deserialization",
        "CWE-798": "hardcoded_credentials",
        "CWE-259": "hardcoded_credentials",
        "CWE-200": "information_disclosure",
        "CWE-918": "ssrf",
        "CWE-611": "xxe",
        "CWE-352": "csrf",
        "CWE-287": "authentication_bypass",
        "CWE-269": "privilege_escalation",
        "CWE-434": "unrestricted_upload",
        "CWE-601": "open_redirect",
    }

    def __init__(
        self,
        data_dir: Path | None = None,
        nvd_api_key: str | None = None,
        github_token: str | None = None,
    ):
        self.data_dir = data_dir or Path.home() / ".cache" / "vantage" / "vuln_pipeline"
        self.data_dir.mkdir(parents=True, exist_ok=True)

        self.nvd_api_key = nvd_api_key or os.environ.get("NVD_API_KEY")
        self.github_token = github_token or os.environ.get("GITHUB_TOKEN")

        # Database for tracking fetched vulnerabilities
        self.db_path = self.data_dir / "vulnerabilities.db"
        self._init_db()

        # Session with retry
        self.session = requests.Session()
        self.session.headers.update(
            {
                "User-Agent": "Vantage-VulnFetcher/1.0",
                "Accept": "application/json",
            }
        )

    def _init_db(self):
        """Initialize SQLite database for tracking vulnerabilities."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS vulnerabilities (
                id TEXT PRIMARY KEY,
                source TEXT NOT NULL,
                cve_id TEXT,
                severity TEXT,
                vulnerability_type TEXT,
                language TEXT,
                published_at TEXT,
                updated_at TEXT,
                fetched_at TEXT,
                data JSON
            )
        """
        )

        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS fetch_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT NOT NULL,
                fetch_time TEXT NOT NULL,
                count INTEGER,
                status TEXT,
                error TEXT
            )
        """
        )

        cursor.execute("CREATE INDEX IF NOT EXISTS idx_vuln_source ON vulnerabilities(source)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_vuln_updated ON vulnerabilities(updated_at)")

        conn.commit()
        conn.close()

    def fetch_all(
        self,
        since: datetime | None = None,
        ecosystems: list[str] | None = None,
    ) -> list[Vulnerability]:
        """
        Fetch vulnerabilities from all sources.

        Args:
            since: Only fetch vulnerabilities updated after this date
            ecosystems: List of ecosystems to fetch (default: all)

        Returns:
            List of new/updated vulnerabilities
        """
        if since is None:
            since = self._get_last_fetch_time()

        ecosystems = ecosystems or list(self.OSV_ECOSYSTEMS.keys())
        all_vulns = []

        # 1. Fetch from OSV (covers PyPI, npm, crates.io, Go, RubyGems, etc.)
        logger.info("=" * 60)
        logger.info("Fetching from OSV API...")
        for ecosystem in ecosystems:
            try:
                vulns = list(self._fetch_osv(ecosystem, since))
                all_vulns.extend(vulns)
                self._log_fetch(f"osv-{ecosystem}", len(vulns), "success")
                logger.info(f"  {ecosystem}: {len(vulns)} vulnerabilities")
            except Exception as e:
                logger.error(f"OSV fetch error for {ecosystem}: {e}")
                self._log_fetch(f"osv-{ecosystem}", 0, "error", str(e))

        # 2. Fetch from NVD (for CVE details)
        logger.info("=" * 60)
        logger.info("Fetching from NVD API...")
        try:
            vulns = list(self._fetch_nvd(since))
            all_vulns.extend(vulns)
            self._log_fetch("nvd", len(vulns), "success")
            logger.info(f"  NVD: {len(vulns)} CVEs")
        except Exception as e:
            logger.error(f"NVD fetch error: {e}")
            self._log_fetch("nvd", 0, "error", str(e))

        # 3. Fetch from GitHub Advisory Database
        logger.info("=" * 60)
        logger.info("Fetching from GitHub Advisory API...")
        try:
            vulns = list(self._fetch_ghsa(since, ecosystems))
            all_vulns.extend(vulns)
            self._log_fetch("ghsa", len(vulns), "success")
            logger.info(f"  GHSA: {len(vulns)} advisories")
        except Exception as e:
            logger.error(f"GHSA fetch error: {e}")
            self._log_fetch("ghsa", 0, "error", str(e))

        # 4. Fetch from Go Vulnerability Database
        if "Go" in ecosystems:
            logger.info("=" * 60)
            logger.info("Fetching from Go Vulnerability Database...")
            try:
                vulns = list(self._fetch_go_vulns(since))
                all_vulns.extend(vulns)
                self._log_fetch("go-vuln", len(vulns), "success")
                logger.info(f"  Go: {len(vulns)} vulnerabilities")
            except Exception as e:
                logger.error(f"Go Vuln DB fetch error: {e}")
                self._log_fetch("go-vuln", 0, "error", str(e))

        # Deduplicate and save
        unique_vulns = self._deduplicate(all_vulns)
        self._save_vulnerabilities(unique_vulns)

        logger.info("=" * 60)
        logger.info(f"TOTAL: {len(unique_vulns)} unique vulnerabilities fetched")
        logger.info("=" * 60)

        return unique_vulns

    def _fetch_osv(self, ecosystem: str, since: datetime | None = None) -> Iterator[Vulnerability]:
        """
        Fetch from OSV API using validated endpoints.

        Endpoints:
        - POST https://api.osv.dev/v1/query
        - POST https://api.osv.dev/v1/querybatch
        - GET https://api.osv.dev/v1/vulns/{id}
        """
        # Popular packages to seed queries
        SEED_PACKAGES = {
            "PyPI": [
                "django",
                "flask",
                "requests",
                "numpy",
                "pandas",
                "tensorflow",
                "fastapi",
                "sqlalchemy",
                "pillow",
                "cryptography",
                "jinja2",
                "pyyaml",
                "urllib3",
                "boto3",
                "celery",
                "redis",
            ],
            "npm": [
                "express",
                "lodash",
                "axios",
                "react",
                "vue",
                "angular",
                "webpack",
                "babel",
                "typescript",
                "next",
                "jquery",
                "moment",
            ],
            "crates.io": [
                "serde",
                "tokio",
                "hyper",
                "actix-web",
                "rocket",
                "diesel",
                "reqwest",
                "clap",
                "rand",
                "regex",
            ],
            "Go": [
                "github.com/gin-gonic/gin",
                "github.com/gorilla/mux",
                "github.com/go-chi/chi",
                "github.com/labstack/echo",
                "github.com/stretchr/testify",
            ],
            "RubyGems": [
                "rails",
                "devise",
                "nokogiri",
                "sinatra",
                "rack",
                "activerecord",
                "sidekiq",
            ],
            "Packagist": [
                "laravel/framework",
                "symfony/symfony",
                "guzzlehttp/guzzle",
                "monolog/monolog",
            ],
            "Maven": [
                "org.apache.struts:struts2-core",
                "log4j:log4j",
                "org.springframework:spring-core",
                "com.fasterxml.jackson.core:jackson-databind",
            ],
        }

        packages = SEED_PACKAGES.get(ecosystem, [])
        if not packages:
            return

        seen_vulns = set()

        # Use batch API for efficiency
        batch_size = 10
        for i in range(0, len(packages), batch_size):
            batch = packages[i : i + batch_size]
            queries = [{"package": {"name": pkg, "ecosystem": ecosystem}} for pkg in batch]

            try:
                response = self.session.post(
                    self.OSV_API_BATCH, json={"queries": queries}, timeout=60
                )
                response.raise_for_status()
                data = response.json()

                for result in data.get("results", []):
                    for vuln_summary in result.get("vulns", []):
                        vuln_id = vuln_summary.get("id", "")
                        if vuln_id in seen_vulns:
                            continue
                        seen_vulns.add(vuln_id)

                        # Fetch full vulnerability details
                        vuln = self._fetch_osv_vuln_detail(vuln_id, ecosystem)
                        if vuln:
                            # Filter by date if specified
                            if since and vuln.updated_at:
                                try:
                                    updated = datetime.fromisoformat(
                                        vuln.updated_at.replace("Z", "+00:00")
                                    ).replace(tzinfo=None)
                                    if updated < since:
                                        continue
                                except (ValueError, TypeError):
                                    pass
                            yield vuln

                time.sleep(0.5)  # Rate limiting

            except requests.RequestException as e:
                logger.warning(f"OSV batch query error: {e}")
                continue

    def _fetch_osv_vuln_detail(self, vuln_id: str, ecosystem: str) -> Vulnerability | None:
        """Fetch full vulnerability details from OSV."""
        try:
            response = self.session.get(f"{self.OSV_API_VULN}/{vuln_id}", timeout=30)
            if response.status_code != 200:
                return None

            data = response.json()
            return self._parse_osv_vuln(data, ecosystem)

        except Exception as e:
            logger.debug(f"Error fetching OSV vuln {vuln_id}: {e}")
            return None

    def _parse_osv_vuln(self, data: dict, ecosystem: str) -> Vulnerability | None:
        """Parse OSV format vulnerability."""
        try:
            vuln_id = data.get("id", "")
            aliases = data.get("aliases", [])

            # Get CVE ID if available
            cve_id = next((a for a in aliases if a.startswith("CVE-")), None)

            # Get CWE IDs
            cwe_ids = data.get("database_specific", {}).get("cwe_ids", [])

            # Parse severity
            severity = "medium"
            cvss_score = None
            for sev in data.get("severity", []):
                if sev.get("type") == "CVSS_V3":
                    score_str = sev.get("score", "")
                    # CVSS vector format: CVSS:3.1/AV:N/AC:L/...
                    try:
                        if "CVSS" in score_str and "/" in score_str:
                            parts = score_str.split("/")
                            for part in parts:
                                if part.startswith("AV:") or part.startswith("AC:"):
                                    continue
                    except:
                        pass

            # Get affected packages
            affected_packages = []
            for affected in data.get("affected", []):
                pkg = affected.get("package", {})
                affected_packages.append(
                    {
                        "name": pkg.get("name", ""),
                        "ecosystem": pkg.get("ecosystem", ""),
                        "versions": affected.get("versions", []),
                    }
                )

            # Get description
            summary = data.get("summary", "")
            details = data.get("details", "")
            description = f"{summary}\n\n{details}".strip()

            # Extract code sample from details
            code_sample = self._extract_code(details)

            # Determine vulnerability type
            vuln_type = self._determine_vuln_type(cwe_ids, description)

            # Get references
            references = [
                ref.get("url", "") for ref in data.get("references", []) if ref.get("url")
            ]

            return Vulnerability(
                id=vuln_id,
                source="osv",
                cve_id=cve_id,
                cwe_ids=cwe_ids,
                cvss_score=cvss_score,
                severity=severity,
                title=summary,
                description=description,
                code_sample=code_sample,
                fixed_code=None,
                affected_packages=affected_packages,
                references=references[:10],
                published_at=data.get("published", ""),
                updated_at=data.get("modified", data.get("published", "")),
                language=self.OSV_ECOSYSTEMS.get(ecosystem, "unknown"),
                vulnerability_type=vuln_type,
                metadata={"aliases": aliases, "ecosystem": ecosystem},
            )

        except Exception as e:
            logger.debug(f"Error parsing OSV vuln: {e}")
            return None

    def _fetch_nvd(self, since: datetime | None = None) -> Iterator[Vulnerability]:
        """
        Fetch from NVD API 2.0.

        Endpoint: GET https://services.nvd.nist.gov/rest/json/cves/2.0

        Rate limits:
        - Without API key: 5 requests per 30 seconds
        - With API key: 50 requests per 30 seconds
        """
        headers = {}
        if self.nvd_api_key:
            headers["apiKey"] = self.nvd_api_key

        params = {
            "resultsPerPage": 100,
            "keywordSearch": "python OR django OR flask",  # Focus on Python
        }

        if since:
            params["lastModStartDate"] = since.strftime("%Y-%m-%dT%H:%M:%S.000")
            params["lastModEndDate"] = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000")

        start_index = 0
        max_results = 500  # Limit for reasonable runtime

        while start_index < max_results:
            params["startIndex"] = start_index

            try:
                response = self.session.get(
                    self.NVD_API, headers=headers, params=params, timeout=30
                )

                if response.status_code == 403:
                    logger.warning("NVD rate limit hit, waiting...")
                    time.sleep(30)
                    continue

                response.raise_for_status()
                data = response.json()

                vulns = data.get("vulnerabilities", [])
                if not vulns:
                    break

                for vuln_data in vulns:
                    vuln = self._parse_nvd_cve(vuln_data.get("cve", {}))
                    if vuln:
                        yield vuln

                total_results = data.get("totalResults", 0)
                start_index += len(vulns)

                if start_index >= total_results:
                    break

                # Rate limiting: 6 seconds without key, 0.6 seconds with key
                delay = 0.6 if self.nvd_api_key else 6
                time.sleep(delay)

            except requests.RequestException as e:
                logger.error(f"NVD API error: {e}")
                break

    def _parse_nvd_cve(self, cve_data: dict) -> Vulnerability | None:
        """Parse NVD CVE format."""
        try:
            cve_id = cve_data.get("id", "")

            # Get description
            descriptions = cve_data.get("descriptions", [])
            description = ""
            for desc in descriptions:
                if desc.get("lang") == "en":
                    description = desc.get("value", "")
                    break

            # Get CWE IDs
            cwe_ids = []
            for weakness in cve_data.get("weaknesses", []):
                for desc in weakness.get("description", []):
                    cwe_id = desc.get("value", "")
                    if cwe_id.startswith("CWE-"):
                        cwe_ids.append(cwe_id)

            # Get CVSS score and severity
            metrics = cve_data.get("metrics", {})
            cvss_score = None
            severity = "medium"

            for cvss_key in ["cvssMetricV31", "cvssMetricV30", "cvssMetricV2"]:
                cvss_data = metrics.get(cvss_key, [])
                if cvss_data:
                    cvss_obj = cvss_data[0]
                    cvss_score = cvss_obj.get("cvssData", {}).get("baseScore")
                    severity = cvss_obj.get("baseSeverity", "MEDIUM").lower()
                    break

            # Get references
            references = [
                ref.get("url", "") for ref in cve_data.get("references", []) if ref.get("url")
            ]

            # Determine vulnerability type
            vuln_type = self._determine_vuln_type(cwe_ids, description)

            return Vulnerability(
                id=cve_id,
                source="nvd",
                cve_id=cve_id,
                cwe_ids=cwe_ids,
                cvss_score=cvss_score,
                severity=severity,
                title=(description[:100] + "..." if len(description) > 100 else description),
                description=description,
                code_sample=None,
                fixed_code=None,
                affected_packages=[],
                references=references[:10],
                published_at=cve_data.get("published", ""),
                updated_at=cve_data.get("lastModified", ""),
                language="python",
                vulnerability_type=vuln_type,
                metadata={"vulnStatus": cve_data.get("vulnStatus")},
            )

        except Exception as e:
            logger.debug(f"Error parsing NVD CVE: {e}")
            return None

    def _fetch_ghsa(
        self, since: datetime | None = None, ecosystems: list[str] | None = None
    ) -> Iterator[Vulnerability]:
        """
        Fetch from GitHub Advisory API.

        Endpoint: GET https://api.github.com/advisories

        Parameters:
        - ecosystem: pip, npm, maven, go, rust, rubygems, etc.
        - severity: low, medium, high, critical
        - per_page: max 100
        """
        headers = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        if self.github_token:
            headers["Authorization"] = f"Bearer {self.github_token}"

        # Map ecosystems to GitHub format
        ecosystem_map = {
            "PyPI": "pip",
            "npm": "npm",
            "crates.io": "rust",
            "Go": "go",
            "RubyGems": "rubygems",
            "Maven": "maven",
            "Packagist": "composer",
        }

        target_ecosystems = ecosystems or list(self.OSV_ECOSYSTEMS.keys())

        for eco in target_ecosystems:
            github_eco = ecosystem_map.get(eco)
            if not github_eco:
                continue

            params = {
                "ecosystem": github_eco,
                "per_page": 100,
                "type": "reviewed",
            }

            if since:
                params["updated"] = f">{since.strftime('%Y-%m-%d')}"

            page = 1
            max_pages = 3  # Limit pages per ecosystem

            while page <= max_pages:
                params["page"] = page

                try:
                    response = self.session.get(
                        self.GITHUB_API, headers=headers, params=params, timeout=30
                    )

                    if response.status_code == 403:
                        logger.warning("GitHub rate limit hit")
                        break

                    response.raise_for_status()

                    advisories = response.json()
                    if not advisories:
                        break

                    for advisory in advisories:
                        vuln = self._parse_ghsa_advisory(advisory)
                        if vuln:
                            yield vuln

                    page += 1
                    time.sleep(1)  # Rate limiting

                except requests.RequestException as e:
                    logger.warning(f"GHSA API error for {eco}: {e}")
                    break

    def _parse_ghsa_advisory(self, advisory: dict) -> Vulnerability | None:
        """Parse GitHub Advisory format."""
        try:
            ghsa_id = advisory.get("ghsa_id", "")
            cve_id = advisory.get("cve_id")

            # Get CWEs
            cwes = advisory.get("cwes", [])
            cwe_ids = []
            for cwe in cwes:
                if isinstance(cwe, dict):
                    cwe_ids.append(cwe.get("cwe_id", ""))
                elif isinstance(cwe, str):
                    cwe_ids.append(cwe)

            # Get severity
            severity = advisory.get("severity", "medium").lower()

            # Get CVSS
            cvss_data = advisory.get("cvss", {})
            cvss_score = cvss_data.get("score") if cvss_data else None

            # Get description
            summary = advisory.get("summary", "")
            description = advisory.get("description", "")

            # Get affected packages
            affected_packages = []
            for vuln in advisory.get("vulnerabilities", []):
                pkg = vuln.get("package", {})
                affected_packages.append(
                    {
                        "name": pkg.get("name", ""),
                        "ecosystem": pkg.get("ecosystem", ""),
                    }
                )

            # Determine language from ecosystem
            ecosystem = affected_packages[0].get("ecosystem", "") if affected_packages else ""
            language = self.OSV_ECOSYSTEMS.get(ecosystem, "unknown")
            if ecosystem == "pip":
                language = "python"
            elif ecosystem == "rust":
                language = "rust"

            # Get references (they are strings in GHSA)
            references = advisory.get("references", [])
            if references and isinstance(references[0], dict):
                references = [ref.get("url", "") for ref in references]

            # Extract code sample
            code_sample = self._extract_code(description)

            # Determine vulnerability type
            vuln_type = self._determine_vuln_type(cwe_ids, description)

            return Vulnerability(
                id=ghsa_id,
                source="ghsa",
                cve_id=cve_id,
                cwe_ids=cwe_ids,
                cvss_score=cvss_score,
                severity=severity,
                title=summary,
                description=f"{summary}\n\n{description}",
                code_sample=code_sample,
                fixed_code=None,
                affected_packages=affected_packages,
                references=references[:10],
                published_at=advisory.get("published_at", ""),
                updated_at=advisory.get("updated_at", ""),
                language=language,
                vulnerability_type=vuln_type,
                metadata={"ghsa_id": ghsa_id, "type": advisory.get("type")},
            )

        except Exception as e:
            logger.debug(f"Error parsing GHSA advisory: {e}")
            return None

    def _fetch_go_vulns(self, since: datetime | None = None) -> Iterator[Vulnerability]:
        """
        Fetch from Go Vulnerability Database.

        Endpoints:
        - GET https://vuln.go.dev/index/vulns.json
        - GET https://vuln.go.dev/ID/{id}.json
        """
        try:
            # Get vulnerability index
            response = self.session.get(self.GO_VULN_INDEX, timeout=30)
            response.raise_for_status()
            vuln_list = response.json()

            for vuln_entry in vuln_list[:200]:  # Limit for reasonable runtime
                vuln_id = vuln_entry.get("id", "")
                if not vuln_id:
                    continue

                # Check modification date
                if since:
                    modified = vuln_entry.get("modified", "")
                    if modified:
                        try:
                            mod_date = datetime.fromisoformat(
                                modified.replace("Z", "+00:00")
                            ).replace(tzinfo=None)
                            if mod_date < since:
                                continue
                        except:
                            pass

                # Fetch full details
                try:
                    detail_response = self.session.get(
                        f"{self.GO_VULN_DETAIL}/{vuln_id}.json", timeout=30
                    )
                    if detail_response.status_code == 200:
                        vuln = self._parse_go_vuln(detail_response.json())
                        if vuln:
                            yield vuln
                except:
                    pass

                time.sleep(0.2)

        except Exception as e:
            logger.error(f"Go Vuln DB error: {e}")

    def _parse_go_vuln(self, data: dict) -> Vulnerability | None:
        """Parse Go vulnerability data (OSV format)."""
        try:
            vuln_id = data.get("id", "")

            # Get description
            summary = data.get("summary", "")
            details = data.get("details", "")
            description = f"{summary}\n\n{details}".strip()

            # Get affected modules
            affected_packages = []
            for affected in data.get("affected", []):
                pkg = affected.get("package", {})
                affected_packages.append(
                    {
                        "name": pkg.get("path", ""),
                        "ecosystem": "Go",
                    }
                )

            # Get aliases (CVE IDs)
            aliases = data.get("aliases", [])
            cve_id = next((a for a in aliases if a.startswith("CVE-")), None)

            # Get CWE IDs
            cwe_ids = data.get("database_specific", {}).get("cwe_ids", [])

            # Get references
            references = [
                ref.get("url", "") for ref in data.get("references", []) if ref.get("url")
            ]

            return Vulnerability(
                id=vuln_id,
                source="go-vuln",
                cve_id=cve_id,
                cwe_ids=cwe_ids,
                cvss_score=None,
                severity="medium",
                title=summary,
                description=description,
                code_sample=self._extract_code(details),
                fixed_code=None,
                affected_packages=affected_packages,
                references=references[:10],
                published_at=data.get("published", ""),
                updated_at=data.get("modified", ""),
                language="go",
                vulnerability_type=self._determine_vuln_type(cwe_ids, description),
                metadata={"aliases": aliases},
            )

        except Exception as e:
            logger.debug(f"Error parsing Go vuln: {e}")
            return None

    def _extract_code(self, text: str) -> str | None:
        """Extract code blocks from markdown text."""
        import re

        # Fenced code blocks
        patterns = [
            r"```(?:python|py|javascript|js|ruby|go|rust|java|php)?\n(.*?)```",
            r"```\n(.*?)```",
        ]

        for pattern in patterns:
            matches = re.findall(pattern, text, re.DOTALL | re.IGNORECASE)
            if matches:
                return matches[0].strip()

        return None

    def _determine_vuln_type(self, cwe_ids: list[str], description: str) -> str:
        """Determine vulnerability type from CWEs and description."""
        # Check CWE mapping first
        for cwe in cwe_ids:
            if cwe in self.CWE_TYPE_MAP:
                return self.CWE_TYPE_MAP[cwe]

        # Fallback to description analysis
        desc_lower = description.lower()
        type_keywords = {
            "command_injection": ["command injection", "os command", "shell injection"],
            "code_injection": ["code injection", "eval", "exec", "arbitrary code"],
            "sql_injection": ["sql injection", "sqli"],
            "xss": ["cross-site scripting", "xss", "script injection"],
            "path_traversal": ["path traversal", "directory traversal", "../"],
            "ssrf": ["ssrf", "server-side request"],
            "deserialization": ["deserialization", "pickle", "yaml.load"],
            "hardcoded_credentials": ["hardcoded", "credential", "api key", "secret"],
        }

        for vuln_type, keywords in type_keywords.items():
            if any(kw in desc_lower for kw in keywords):
                return vuln_type

        return "unknown"

    def _deduplicate(self, vulns: list[Vulnerability]) -> list[Vulnerability]:
        """Remove duplicate vulnerabilities, preferring GHSA > OSV > NVD."""
        seen = {}
        cve_to_vuln = {}

        priority = {"ghsa": 0, "osv": 1, "go-vuln": 2, "nvd": 3}

        for vuln in vulns:
            # Check by primary ID
            if vuln.id in seen:
                existing = seen[vuln.id]
                if priority.get(vuln.source, 4) < priority.get(existing.source, 4):
                    seen[vuln.id] = vuln
            else:
                seen[vuln.id] = vuln

            # Also track by CVE ID
            if vuln.cve_id:
                if vuln.cve_id in cve_to_vuln:
                    existing = cve_to_vuln[vuln.cve_id]
                    if priority.get(vuln.source, 4) < priority.get(existing.source, 4):
                        cve_to_vuln[vuln.cve_id] = vuln
                        if existing.id in seen:
                            del seen[existing.id]
                        seen[vuln.id] = vuln
                else:
                    cve_to_vuln[vuln.cve_id] = vuln

        return list(seen.values())

    def _save_vulnerabilities(self, vulns: list[Vulnerability]):
        """Save vulnerabilities to database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        now = datetime.utcnow().isoformat()

        for vuln in vulns:
            cursor.execute(
                """
                INSERT OR REPLACE INTO vulnerabilities
                (id, source, cve_id, severity, vulnerability_type, language,
                 published_at, updated_at, fetched_at, data)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    vuln.id,
                    vuln.source,
                    vuln.cve_id,
                    vuln.severity,
                    vuln.vulnerability_type,
                    vuln.language,
                    vuln.published_at,
                    vuln.updated_at,
                    now,
                    json.dumps(asdict(vuln)),
                ),
            )

        conn.commit()
        conn.close()

    def _log_fetch(self, source: str, count: int, status: str, error: str = None):
        """Log fetch operation."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute(
            """
            INSERT INTO fetch_log (source, fetch_time, count, status, error)
            VALUES (?, ?, ?, ?, ?)
        """,
            (source, datetime.utcnow().isoformat(), count, status, error),
        )

        conn.commit()
        conn.close()

    def _get_last_fetch_time(self) -> datetime | None:
        """Get timestamp of last successful fetch."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT MAX(fetch_time) FROM fetch_log WHERE status = 'success'
        """
        )
        result = cursor.fetchone()
        conn.close()

        if result and result[0]:
            return datetime.fromisoformat(result[0])
        return None

    def get_training_data(
        self,
        languages: list[str] | None = None,
        min_severity: str | None = None,
    ) -> list[dict]:
        """
        Get all vulnerabilities in training format.

        Args:
            languages: Filter by languages (e.g., ["python", "javascript"])
            min_severity: Minimum severity level

        Returns:
            List of training examples
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        query = "SELECT data FROM vulnerabilities WHERE 1=1"
        params = []

        if languages:
            placeholders = ",".join("?" * len(languages))
            query += f" AND language IN ({placeholders})"
            params.extend(languages)

        if min_severity:
            severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
            min_level = severity_order.get(min_severity, 3)
            allowed = [s for s, l in severity_order.items() if l <= min_level]
            placeholders = ",".join("?" * len(allowed))
            query += f" AND severity IN ({placeholders})"
            params.extend(allowed)

        cursor.execute(query, params)
        rows = cursor.fetchall()
        conn.close()

        training_data = []
        for row in rows:
            data = json.loads(row[0])
            vuln = Vulnerability(**data)
            training_data.append(vuln.to_training_format())

        return training_data

    def get_statistics(self) -> dict:
        """Get dataset statistics."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        stats = {}

        cursor.execute("SELECT COUNT(*) FROM vulnerabilities")
        stats["total"] = cursor.fetchone()[0]

        cursor.execute("SELECT source, COUNT(*) FROM vulnerabilities GROUP BY source")
        stats["by_source"] = dict(cursor.fetchall())

        cursor.execute("SELECT severity, COUNT(*) FROM vulnerabilities GROUP BY severity")
        stats["by_severity"] = dict(cursor.fetchall())

        cursor.execute("SELECT language, COUNT(*) FROM vulnerabilities GROUP BY language")
        stats["by_language"] = dict(cursor.fetchall())

        cursor.execute(
            """
            SELECT vulnerability_type, COUNT(*) FROM vulnerabilities
            GROUP BY vulnerability_type ORDER BY COUNT(*) DESC LIMIT 10
        """
        )
        stats["by_type"] = dict(cursor.fetchall())

        cursor.execute(
            """
            SELECT source, fetch_time, count, status
            FROM fetch_log ORDER BY fetch_time DESC LIMIT 10
        """
        )
        stats["recent_fetches"] = [
            {"source": r[0], "time": r[1], "count": r[2], "status": r[3]} for r in cursor.fetchall()
        ]

        conn.close()
        return stats
