"""
Safe code samples for balanced training.

These are secure coding patterns that the model should learn to classify as "safe".
"""

# Safe Python code patterns
SAFE_PYTHON_SAMPLES = [
    # Parameterized queries
    {
        "code": '''
def get_user(db, user_id: int):
    """Safely fetch user with parameterized query."""
    query = "SELECT * FROM users WHERE id = %s"
    return db.execute(query, (user_id,))
''',
        "description": "Parameterized SQL query prevents SQL injection",
        "vulnerability_type": "sql_injection",
    },
    {
        "code": '''
def search_users(db, name: str):
    """Safe user search with parameter binding."""
    return db.execute(
        "SELECT * FROM users WHERE name LIKE ?",
        (f"%{name}%",)
    )
''',
        "description": "Safe LIKE query with parameterized input",
        "vulnerability_type": "sql_injection",
    },
    # Safe subprocess
    {
        "code": '''
import subprocess

def list_directory(path: str) -> list[str]:
    """Safely list directory contents."""
    result = subprocess.run(
        ["ls", "-la", path],
        capture_output=True,
        text=True,
        check=True
    )
    return result.stdout.split("\\n")
''',
        "description": "Safe subprocess call with list arguments",
        "vulnerability_type": "command_injection",
    },
    {
        "code": '''
import shlex
import subprocess

def run_command(command: str) -> str:
    """Run command safely using shlex."""
    args = shlex.split(command)
    allowed_commands = {"ls", "cat", "echo", "pwd"}
    if args[0] not in allowed_commands:
        raise ValueError("Command not allowed")
    return subprocess.check_output(args, text=True)
''',
        "description": "Safe command execution with allowlist",
        "vulnerability_type": "command_injection",
    },
    # Safe path handling
    {
        "code": '''
import os
from pathlib import Path

def read_file(base_dir: str, filename: str) -> str:
    """Safely read file with path validation."""
    base = Path(base_dir).resolve()
    target = (base / filename).resolve()

    if not str(target).startswith(str(base)):
        raise ValueError("Path traversal detected")

    return target.read_text()
''',
        "description": "Safe file read with path traversal prevention",
        "vulnerability_type": "path_traversal",
    },
    {
        "code": '''
from pathlib import Path

def safe_join(base: str, *parts) -> Path:
    """Safely join paths without traversal."""
    base_path = Path(base).resolve()
    full_path = base_path.joinpath(*parts).resolve()

    if not full_path.is_relative_to(base_path):
        raise ValueError("Invalid path")

    return full_path
''',
        "description": "Safe path joining using pathlib",
        "vulnerability_type": "path_traversal",
    },
    # Safe HTML output
    {
        "code": '''
from html import escape

def render_message(user_input: str) -> str:
    """Safely render user content in HTML."""
    safe_content = escape(user_input)
    return f"<div class='message'>{safe_content}</div>"
''',
        "description": "HTML escaping prevents XSS",
        "vulnerability_type": "xss",
    },
    {
        "code": '''
import bleach

def sanitize_html(user_html: str) -> str:
    """Sanitize HTML with bleach library."""
    allowed_tags = ["p", "b", "i", "u", "a", "br"]
    allowed_attrs = {"a": ["href", "title"]}
    return bleach.clean(
        user_html,
        tags=allowed_tags,
        attributes=allowed_attrs,
        strip=True
    )
''',
        "description": "HTML sanitization using bleach",
        "vulnerability_type": "xss",
    },
    # Environment variables for secrets
    {
        "code": '''
import os

def get_database_url() -> str:
    """Get database URL from environment."""
    url = os.environ.get("DATABASE_URL")
    if not url:
        raise ValueError("DATABASE_URL not set")
    return url
''',
        "description": "Secret from environment variable",
        "vulnerability_type": "hardcoded_credentials",
    },
    {
        "code": '''
import os
from functools import lru_cache

@lru_cache
def get_api_key() -> str:
    """Load API key from environment."""
    key = os.getenv("API_KEY")
    if not key:
        raise RuntimeError("API_KEY environment variable required")
    return key
''',
        "description": "API key loaded from environment",
        "vulnerability_type": "hardcoded_credentials",
    },
    # Safe deserialization
    {
        "code": '''
import json

def load_config(config_str: str) -> dict:
    """Safely parse JSON configuration."""
    return json.loads(config_str)
''',
        "description": "Safe JSON parsing instead of pickle",
        "vulnerability_type": "deserialization",
    },
    {
        "code": '''
import yaml

def parse_yaml(content: str) -> dict:
    """Safely load YAML with safe_load."""
    return yaml.safe_load(content)
''',
        "description": "Safe YAML loading",
        "vulnerability_type": "deserialization",
    },
    # Safe URL handling
    {
        "code": '''
from urllib.parse import urlparse

ALLOWED_HOSTS = {"api.example.com", "cdn.example.com"}

def fetch_safe(url: str) -> bytes:
    """Fetch URL with host validation."""
    parsed = urlparse(url)
    if parsed.hostname not in ALLOWED_HOSTS:
        raise ValueError("Host not allowed")
    if parsed.scheme not in ("http", "https"):
        raise ValueError("Invalid scheme")
    import requests
    return requests.get(url, timeout=10).content
''',
        "description": "SSRF prevention with allowlist",
        "vulnerability_type": "ssrf",
    },
    # Safe eval alternatives
    {
        "code": '''
import ast

def safe_eval(expression: str) -> int:
    """Safely evaluate arithmetic expressions."""
    tree = ast.parse(expression, mode='eval')
    # Only allow numbers and basic operations
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Expression, ast.BinOp, ast.Num,
                                  ast.Add, ast.Sub, ast.Mult, ast.Div)):
            raise ValueError("Invalid expression")
    return eval(compile(tree, '<string>', 'eval'))
''',
        "description": "Safe arithmetic evaluation with AST",
        "vulnerability_type": "code_injection",
    },
    # Secure session handling
    {
        "code": '''
import secrets
import hashlib

def generate_session_token() -> str:
    """Generate a cryptographically secure session token."""
    return secrets.token_urlsafe(32)

def hash_password(password: str, salt: bytes = None) -> tuple[bytes, bytes]:
    """Hash password with salt using secure algorithm."""
    if salt is None:
        salt = secrets.token_bytes(16)
    key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
    return key, salt
''',
        "description": "Secure token and password handling",
        "vulnerability_type": "authentication_bypass",
    },
    # Input validation
    {
        "code": '''
import re
from typing import Optional

def validate_email(email: str) -> Optional[str]:
    """Validate email format."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$'
    if re.match(pattern, email):
        return email.lower().strip()
    return None

def validate_username(username: str) -> str:
    """Validate username format."""
    if not re.match(r'^[a-zA-Z0-9_]{3,20}$', username):
        raise ValueError("Invalid username format")
    return username
''',
        "description": "Input validation patterns",
        "vulnerability_type": "code_injection",
    },
    # Rate limiting
    {
        "code": '''
from collections import defaultdict
from time import time

class RateLimiter:
    def __init__(self, max_requests: int = 100, window: int = 60):
        self.max_requests = max_requests
        self.window = window
        self.requests = defaultdict(list)

    def is_allowed(self, client_id: str) -> bool:
        """Check if request is allowed under rate limit."""
        now = time()
        # Clean old requests
        self.requests[client_id] = [
            t for t in self.requests[client_id]
            if now - t < self.window
        ]
        if len(self.requests[client_id]) >= self.max_requests:
            return False
        self.requests[client_id].append(now)
        return True
''',
        "description": "Rate limiting implementation",
        "vulnerability_type": "unknown",
    },
    # Secure file upload
    {
        "code": '''
import os
import uuid
from pathlib import Path

ALLOWED_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.gif', '.pdf'}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB

def save_upload(file_content: bytes, original_name: str, upload_dir: str) -> str:
    """Safely save uploaded file."""
    # Validate extension
    ext = Path(original_name).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ValueError("File type not allowed")

    # Validate size
    if len(file_content) > MAX_FILE_SIZE:
        raise ValueError("File too large")

    # Generate safe filename
    safe_name = f"{uuid.uuid4().hex}{ext}"
    dest_path = Path(upload_dir) / safe_name

    dest_path.write_bytes(file_content)
    return str(dest_path)
''',
        "description": "Secure file upload handling",
        "vulnerability_type": "unrestricted_upload",
    },
    # CSRF protection
    {
        "code": '''
import secrets
import hmac

class CSRFProtection:
    def __init__(self, secret_key: str):
        self.secret_key = secret_key.encode()

    def generate_token(self, session_id: str) -> str:
        """Generate CSRF token for session."""
        random_part = secrets.token_hex(16)
        message = f"{session_id}:{random_part}".encode()
        signature = hmac.new(self.secret_key, message, 'sha256').hexdigest()
        return f"{random_part}:{signature}"

    def validate_token(self, session_id: str, token: str) -> bool:
        """Validate CSRF token."""
        try:
            random_part, signature = token.split(":")
            message = f"{session_id}:{random_part}".encode()
            expected = hmac.new(self.secret_key, message, 'sha256').hexdigest()
            return hmac.compare_digest(signature, expected)
        except ValueError:
            return False
''',
        "description": "CSRF token implementation",
        "vulnerability_type": "csrf",
    },
    # Safe redirect
    {
        "code": '''
from urllib.parse import urlparse

ALLOWED_DOMAINS = {"example.com", "www.example.com"}

def safe_redirect(url: str, default: str = "/") -> str:
    """Safely validate redirect URL."""
    if not url:
        return default

    parsed = urlparse(url)

    # Allow relative URLs
    if not parsed.netloc:
        if url.startswith("/") and not url.startswith("//"):
            return url
        return default

    # Check domain for absolute URLs
    if parsed.hostname in ALLOWED_DOMAINS:
        return url

    return default
''',
        "description": "Safe redirect with domain validation",
        "vulnerability_type": "open_redirect",
    },
]

# Safe JavaScript code patterns
SAFE_JAVASCRIPT_SAMPLES = [
    {
        "code": """
// Safe DOM manipulation with textContent
function displayMessage(message) {
    const element = document.getElementById('output');
    element.textContent = message; // Safe - doesn't parse HTML
}
""",
        "description": "Safe DOM update using textContent",
        "vulnerability_type": "xss",
    },
    {
        "code": """
// Safe query with parameterized values
async function getUser(db, userId) {
    const query = 'SELECT * FROM users WHERE id = $1';
    return await db.query(query, [userId]);
}
""",
        "description": "Parameterized SQL in JavaScript",
        "vulnerability_type": "sql_injection",
    },
    {
        "code": """
// Safe JSON parsing
function parseConfig(jsonString) {
    try {
        return JSON.parse(jsonString);
    } catch (e) {
        console.error('Invalid JSON:', e.message);
        return null;
    }
}
""",
        "description": "Safe JSON parsing in JavaScript",
        "vulnerability_type": "code_injection",
    },
    {
        "code": """
// Safe URL validation
function isValidRedirect(url) {
    try {
        const parsed = new URL(url, window.location.origin);
        return parsed.origin === window.location.origin;
    } catch {
        return false;
    }
}
""",
        "description": "Safe redirect URL validation",
        "vulnerability_type": "open_redirect",
    },
    {
        "code": """
// Environment-based configuration
const config = {
    apiKey: process.env.API_KEY,
    dbUrl: process.env.DATABASE_URL,
    secretKey: process.env.SECRET_KEY
};

if (!config.apiKey || !config.secretKey) {
    throw new Error('Required environment variables not set');
}
""",
        "description": "Secrets from environment",
        "vulnerability_type": "hardcoded_credentials",
    },
]


def get_safe_samples(language: str = None) -> list[dict]:
    """
    Get safe code samples for training.

    Args:
        language: Filter by language (python, javascript, etc.)

    Returns:
        List of safe code samples in training format
    """
    samples = []

    if language is None or language == "python":
        for sample in SAFE_PYTHON_SAMPLES:
            samples.append(
                {
                    "id": f"safe-py-{len(samples)}",
                    "code": sample["code"].strip(),
                    "description": sample["description"],
                    "vulnerability_type": sample["vulnerability_type"],
                    "language": "python",
                    "source": "safe_samples",
                    "is_vulnerable": False,
                    "severity": "none",
                }
            )

    if language is None or language == "javascript":
        for sample in SAFE_JAVASCRIPT_SAMPLES:
            samples.append(
                {
                    "id": f"safe-js-{len(samples)}",
                    "code": sample["code"].strip(),
                    "description": sample["description"],
                    "vulnerability_type": sample["vulnerability_type"],
                    "language": "javascript",
                    "source": "safe_samples",
                    "is_vulnerable": False,
                    "severity": "none",
                }
            )

    return samples


def get_balanced_dataset(
    vulnerable_samples: list[dict],
    safe_multiplier: float = 1.0,
) -> list[dict]:
    """
    Create a balanced dataset with vulnerable and safe samples.

    Args:
        vulnerable_samples: List of vulnerable code samples
        safe_multiplier: Ratio of safe to vulnerable samples (default 1.0 = equal)

    Returns:
        Combined list of vulnerable and safe samples
    """
    import random

    safe_samples = get_safe_samples()

    # Calculate target safe samples
    target_safe = int(len(vulnerable_samples) * safe_multiplier)

    # Duplicate safe samples if needed
    if len(safe_samples) < target_safe:
        multiplier = (target_safe // len(safe_samples)) + 1
        safe_samples = safe_samples * multiplier

    # Sample to target size
    safe_samples = random.sample(safe_samples, min(target_safe, len(safe_samples)))

    # Combine and shuffle
    combined = vulnerable_samples + safe_samples
    random.shuffle(combined)

    return combined
