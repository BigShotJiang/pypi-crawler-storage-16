"""
Security Scanner Registry.

Auto-discovers and registers security scanners, providing framework
detection and scanner selection capabilities.
"""

from pathlib import Path
from typing import TYPE_CHECKING

# Note: SecurityScanner base class needs to be ported to:
# vantage_core.security.scanners.base
# For now, we use a forward reference and late import pattern

if TYPE_CHECKING:
    from vantage_core.security.scanners.base import SecurityScanner


class SecurityScannerRegistry:
    """
    Registry for security scanners.

    Provides auto-discovery of scanners, framework detection,
    and scanner selection based on project content.
    """

    def __init__(self):
        """Initialize the registry with default scanners."""
        self._scanners: dict[str, type[SecurityScanner]] = {}
        self._load_default_scanners()

    def _load_default_scanners(self) -> None:
        """Load all default framework scanners."""
        # Note: Scanner imports are deferred to avoid import errors
        # if the scanners subpackage hasn't been ported yet.
        try:
            from vantage_core.security.scanners.langchain import (
                LangChainSecurityScanner,
            )

            self.register("langchain", LangChainSecurityScanner)
        except ImportError:
            pass

        try:
            from vantage_core.security.scanners.crewai import CrewAISecurityScanner

            self.register("crewai", CrewAISecurityScanner)
        except ImportError:
            pass

        try:
            from vantage_core.security.scanners.autogen import AutoGenSecurityScanner

            self.register("autogen", AutoGenSecurityScanner)
        except ImportError:
            pass

        try:
            from vantage_core.security.scanners.llamaindex import (
                LlamaIndexSecurityScanner,
            )

            self.register("llamaindex", LlamaIndexSecurityScanner)
        except ImportError:
            pass

        try:
            from vantage_core.security.scanners.semantic_kernel import (
                SemanticKernelSecurityScanner,
            )

            self.register("semantic_kernel", SemanticKernelSecurityScanner)
        except ImportError:
            pass

    def register(self, name: str, scanner_class: type["SecurityScanner"]) -> None:
        """
        Register a scanner with the registry.

        Args:
            name: Unique name for the scanner
            scanner_class: Scanner class to register
        """
        self._scanners[name] = scanner_class

    def unregister(self, name: str) -> None:
        """
        Unregister a scanner from the registry.

        Args:
            name: Name of scanner to unregister
        """
        if name in self._scanners:
            del self._scanners[name]

    def get_scanner(self, name: str) -> "SecurityScanner | None":
        """
        Get a scanner instance by name.

        Args:
            name: Scanner name

        Returns:
            Scanner instance or None if not found
        """
        scanner_class = self._scanners.get(name)
        if scanner_class:
            return scanner_class()
        return None

    def get_all_scanners(self) -> list["SecurityScanner"]:
        """
        Get instances of all registered scanners.

        Returns:
            List of scanner instances
        """
        return [scanner_class() for scanner_class in self._scanners.values()]

    def list_scanners(self) -> list[str]:
        """
        List all registered scanner names.

        Returns:
            List of scanner names
        """
        return list(self._scanners.keys())

    def detect_frameworks(self, path: Path) -> list[str]:
        """
        Detect which frameworks are present in a project.

        Args:
            path: Path to project directory or file

        Returns:
            List of detected framework names
        """
        detected = []
        for name, scanner_class in self._scanners.items():
            if scanner_class.can_handle(path):
                detected.append(name)
        return detected

    def get_scanners_for_path(self, path: Path) -> list["SecurityScanner"]:
        """
        Get all scanners that can handle a given path.

        Args:
            path: Path to scan

        Returns:
            List of applicable scanner instances
        """
        scanners = []
        for name, scanner_class in self._scanners.items():
            if scanner_class.can_handle(path):
                scanners.append(scanner_class())
        return scanners

    def scan_all(self, path: Path) -> list:
        """
        Run all applicable scanners on a path.

        Args:
            path: Path to scan

        Returns:
            List of SecurityScanResult objects
        """
        results = []
        scanners = self.get_scanners_for_path(path)

        for scanner in scanners:
            result = scanner.scan(path)
            results.append(result)

        return results

    @property
    def scanner_count(self) -> int:
        """Get number of registered scanners."""
        return len(self._scanners)


# Global registry instance
_default_registry: SecurityScannerRegistry | None = None


def get_default_registry() -> SecurityScannerRegistry:
    """
    Get the default global registry instance.

    Returns:
        Default SecurityScannerRegistry
    """
    global _default_registry
    if _default_registry is None:
        _default_registry = SecurityScannerRegistry()
    return _default_registry


def detect_frameworks(path: Path) -> list[str]:
    """
    Detect frameworks in a project using the default registry.

    Args:
        path: Path to project

    Returns:
        List of detected framework names
    """
    return get_default_registry().detect_frameworks(path)


def scan_project(path: Path) -> list:
    """
    Scan a project using all applicable scanners.

    Args:
        path: Path to project

    Returns:
        List of SecurityScanResult objects
    """
    return get_default_registry().scan_all(path)
