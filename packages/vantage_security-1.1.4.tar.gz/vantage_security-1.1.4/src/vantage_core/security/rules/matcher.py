"""
Pattern matching engine for Semgrep-style patterns.

This module provides a pattern matching DSL that supports:
- Metavariables: $X, $FUNC, $...ARGS (capture and bind)
- Ellipsis: ... for zero or more elements
- Exact matching for literals and operators
- Pattern composition operators
"""

from __future__ import annotations

import ast
import logging
import re
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class PatternMatch:
    """
    Result of a pattern match.

    Contains the matched AST node and any captured metavariables.
    """

    node: ast.AST
    metavariables: dict[str, ast.AST]
    line: int
    column: int
    end_line: int | None = None
    end_column: int | None = None

    def get_metavariable_str(self, name: str) -> str | None:
        """
        Get string representation of a captured metavariable.

        Args:
            name: Metavariable name without $ prefix

        Returns:
            String representation of the captured value
        """
        if name not in self.metavariables:
            return None

        node = self.metavariables[name]
        try:
            return ast.unparse(node)
        except Exception:
            return ast.dump(node)


@dataclass
class MatchContext:
    """Context for tracking matches during pattern matching."""

    metavariables: dict[str, ast.AST] = field(default_factory=dict)
    inside_patterns: list[str] = field(default_factory=list)
    parent_nodes: list[ast.AST] = field(default_factory=list)


class PatternMatcher:
    """
    Matches Semgrep-style patterns against Python AST.

    Supports:
    - Metavariables: $X, $FUNC, $VAR_NAME
    - Spread metavariables: $...ARGS (matches multiple elements)
    - Ellipsis: ... for zero or more arguments/elements
    - Literal matching: exact strings and numbers
    - Structural matching: AST node types and fields

    Example:
        matcher = PatternMatcher()

        # Match any eval call
        matches = matcher.match("eval($X)", code_ast)

        # Match format string injection
        matches = matcher.match("cursor.execute($Q.format(...))", code_ast)

        # Get captured values
        for match in matches:
            arg = match.get_metavariable_str("X")
    """

    # Regex for metavariables: $NAME or $...NAME
    METAVAR_PATTERN = re.compile(r"\$(\.\.\.|)([A-Z_][A-Z0-9_]*)")

    def __init__(self):
        self._context: MatchContext | None = None

    def match(self, pattern: str, code_ast: ast.AST) -> list[PatternMatch]:
        """
        Find all matches of pattern in code.

        Args:
            pattern: Pattern string (e.g., "eval($X)")
            code_ast: AST to search

        Returns:
            List of matches with captured metavariables
        """
        matches = []

        try:
            pattern_ast = self._parse_pattern(pattern)
        except ValueError as e:
            logger.warning(f"Failed to parse pattern '{pattern}': {e}")
            return matches

        for node in ast.walk(code_ast):
            self._context = MatchContext()
            if self._match_node(pattern_ast, node):
                match = PatternMatch(
                    node=node,
                    metavariables=self._context.metavariables.copy(),
                    line=getattr(node, "lineno", 0),
                    column=getattr(node, "col_offset", 0),
                    end_line=getattr(node, "end_lineno", None),
                    end_column=getattr(node, "end_col_offset", None),
                )
                matches.append(match)

        return matches

    def match_at_node(self, pattern: str, node: ast.AST) -> PatternMatch | None:
        """
        Match pattern at a specific node (not descendants).

        Args:
            pattern: Pattern string
            node: AST node to match against

        Returns:
            PatternMatch if matches, None otherwise
        """
        try:
            pattern_ast = self._parse_pattern(pattern)
        except ValueError:
            return None

        self._context = MatchContext()
        if self._match_node(pattern_ast, node):
            return PatternMatch(
                node=node,
                metavariables=self._context.metavariables.copy(),
                line=getattr(node, "lineno", 0),
                column=getattr(node, "col_offset", 0),
            )

        return None

    def _parse_pattern(self, pattern: str) -> ast.AST:
        """
        Parse pattern string into AST.

        Transforms metavariables and ellipsis into valid Python
        identifiers for parsing.

        Args:
            pattern: Pattern string

        Returns:
            Parsed AST

        Raises:
            ValueError: If pattern cannot be parsed
        """
        # Replace spread metavariables: $...ARGS -> __SPREAD_ARGS__
        transformed = self.METAVAR_PATTERN.sub(
            lambda m: f"__{'SPREAD_' if m.group(1) else 'METAVAR_'}{m.group(2)}__",
            pattern,
        )

        # Replace ellipsis: ... -> __ELLIPSIS__
        # But not inside strings or the spread metavar replacement
        transformed = re.sub(r"(?<![_])\.\.\.(?![_])", "__ELLIPSIS__", transformed)

        # Try parsing as expression first, then as statement
        for mode in ["eval", "exec"]:
            try:
                tree = ast.parse(transformed, mode=mode)
                if mode == "eval":
                    return tree.body
                else:
                    if tree.body:
                        return tree.body[0]
                    raise ValueError("Empty pattern")
            except SyntaxError:
                continue

        raise ValueError(f"Invalid pattern syntax: {pattern}")

    def _match_node(self, pattern: ast.AST, node: ast.AST) -> bool:
        """
        Check if pattern matches node.

        Handles metavariable binding and structural matching.

        Args:
            pattern: Pattern AST node
            node: Code AST node to match against

        Returns:
            True if pattern matches node
        """
        # Handle metavariables (represented as Name nodes)
        if isinstance(pattern, ast.Name):
            if pattern.id.startswith("__METAVAR_"):
                return self._handle_metavar(pattern.id, node)
            if pattern.id.startswith("__SPREAD_"):
                # Spread metavariables are handled in list matching
                return self._handle_metavar(pattern.id, node)
            if pattern.id == "__ELLIPSIS__":
                # Ellipsis matches anything as a single element
                return True

        # Type must match
        if type(pattern) is not type(node):
            return False

        # Compare all fields
        for field_name, pattern_value in ast.iter_fields(pattern):
            if not hasattr(node, field_name):
                return False

            node_value = getattr(node, field_name)

            # Handle lists (arguments, elements, targets, etc.)
            if isinstance(pattern_value, list):
                if not isinstance(node_value, list):
                    return False
                if not self._match_list(pattern_value, node_value):
                    return False

            # Handle nested AST nodes
            elif isinstance(pattern_value, ast.AST):
                if not isinstance(node_value, ast.AST):
                    return False
                if not self._match_node(pattern_value, node_value):
                    return False

            # Handle primitive values (strings, numbers, etc.)
            else:
                # Handle string metavariables in constants
                if isinstance(pattern_value, str):
                    if pattern_value.startswith("__METAVAR_"):
                        if not self._handle_metavar(pattern_value, node_value):
                            return False
                        continue

                if pattern_value != node_value:
                    return False

        return True

    def _match_list(self, pattern_list: list[Any], node_list: list[Any]) -> bool:
        """
        Match a list of pattern elements against node elements.

        Handles ellipsis (...) and spread metavariables ($...ARGS).

        Args:
            pattern_list: List from pattern AST
            node_list: List from code AST

        Returns:
            True if lists match
        """
        if not pattern_list:
            return len(node_list) == 0

        # Check for ellipsis or spread metavariables
        has_ellipsis = False
        spread_var = None

        for p in pattern_list:
            if isinstance(p, ast.Name):
                if p.id == "__ELLIPSIS__":
                    has_ellipsis = True
                elif p.id.startswith("__SPREAD_"):
                    spread_var = p.id
                    has_ellipsis = True

        if has_ellipsis:
            return self._match_list_with_ellipsis(pattern_list, node_list, spread_var)

        # Exact length match required
        if len(pattern_list) != len(node_list):
            return False

        for p, n in zip(pattern_list, node_list):
            if isinstance(p, ast.AST) and isinstance(n, ast.AST):
                if not self._match_node(p, n):
                    return False
            elif p != n:
                return False

        return True

    def _match_list_with_ellipsis(
        self, pattern_list: list[Any], node_list: list[Any], spread_var: str | None
    ) -> bool:
        """
        Match pattern list containing ellipsis or spread metavariable.

        The ellipsis can match zero or more elements.

        Args:
            pattern_list: Pattern elements (may contain ellipsis)
            node_list: Code elements
            spread_var: Name of spread metavariable, if any

        Returns:
            True if match succeeds
        """
        # Separate patterns before and after ellipsis
        before: list[ast.AST] = []
        after: list[ast.AST] = []
        found_ellipsis = False

        for p in pattern_list:
            if isinstance(p, ast.Name) and (p.id == "__ELLIPSIS__" or p.id.startswith("__SPREAD_")):
                found_ellipsis = True
                continue

            if not found_ellipsis:
                before.append(p)
            else:
                after.append(p)

        # Check if we have enough elements
        min_required = len(before) + len(after)
        if len(node_list) < min_required:
            return False

        # Match elements before ellipsis
        for i, p in enumerate(before):
            if i >= len(node_list):
                return False
            if isinstance(p, ast.AST) and isinstance(node_list[i], ast.AST):
                if not self._match_node(p, node_list[i]):
                    return False
            elif p != node_list[i]:
                return False

        # Match elements after ellipsis (from end)
        for i, p in enumerate(reversed(after)):
            idx = len(node_list) - 1 - i
            if idx < len(before):
                return False
            if isinstance(p, ast.AST) and isinstance(node_list[idx], ast.AST):
                if not self._match_node(p, node_list[idx]):
                    return False
            elif p != node_list[idx]:
                return False

        # If we have a spread metavariable, capture the matched elements
        if spread_var and self._context:
            start = len(before)
            end = len(node_list) - len(after)
            matched_elements = node_list[start:end]

            # Store as a Tuple node for convenience
            var_name = spread_var[9:-2]  # Remove __SPREAD_ and __
            if matched_elements:
                tuple_node = ast.Tuple(elts=matched_elements, ctx=ast.Load())
                self._context.metavariables[var_name] = tuple_node

        return True

    def _handle_metavar(self, metavar_id: str, value: Any) -> bool:
        """
        Handle metavariable binding.

        If the metavariable is already bound, check that the new value
        matches the bound value. Otherwise, bind the value.

        Args:
            metavar_id: Internal metavariable identifier
            value: Value to bind or check

        Returns:
            True if binding succeeds or matches
        """
        if not self._context:
            return True

        # Extract variable name
        if metavar_id.startswith("__METAVAR_"):
            var_name = metavar_id[10:-2]
        elif metavar_id.startswith("__SPREAD_"):
            var_name = metavar_id[9:-2]
        else:
            return False

        # Check if already bound
        if var_name in self._context.metavariables:
            bound_value = self._context.metavariables[var_name]
            return self._nodes_equal(bound_value, value)

        # Bind new value
        self._context.metavariables[var_name] = value
        return True

    def _nodes_equal(self, a: Any, b: Any) -> bool:
        """
        Check if two AST nodes are structurally equal.

        Args:
            a: First node or value
            b: Second node or value

        Returns:
            True if equal
        """
        if type(a) is not type(b):
            return False

        if isinstance(a, ast.AST):
            return ast.dump(a) == ast.dump(b)

        return a == b

    def find_containing_pattern(
        self, container_pattern: str, inner_pattern: str, code_ast: ast.AST
    ) -> list[PatternMatch]:
        """
        Find matches of inner_pattern that are inside container_pattern.

        This implements pattern-inside semantics.

        Args:
            container_pattern: Pattern for the container
            inner_pattern: Pattern to find inside container
            code_ast: AST to search

        Returns:
            List of inner matches that are inside container matches
        """
        # First find all containers
        container_matches = self.match(container_pattern, code_ast)
        if not container_matches:
            return []

        # Then find inner matches within containers
        result = []
        for container in container_matches:
            inner_matches = self.match(inner_pattern, container.node)
            for inner in inner_matches:
                # Merge metavariables from container and inner
                combined_metavars = {**container.metavariables, **inner.metavariables}
                inner.metavariables = combined_metavars
                result.append(inner)

        return result

    def find_excluding_pattern(
        self, main_pattern: str, exclude_pattern: str, code_ast: ast.AST
    ) -> list[PatternMatch]:
        """
        Find matches of main_pattern that are NOT inside exclude_pattern.

        This implements pattern-not-inside semantics.

        Args:
            main_pattern: Pattern to find
            exclude_pattern: Pattern to exclude
            code_ast: AST to search

        Returns:
            List of main matches that are not inside exclude matches
        """
        main_matches = self.match(main_pattern, code_ast)
        exclude_matches = self.match(exclude_pattern, code_ast)

        # Get locations of exclude matches
        exclude_ranges = set()
        for m in exclude_matches:
            exclude_ranges.add((m.line, m.column, m.end_line or m.line, m.end_column or m.column))

        # Filter main matches
        result = []
        for m in main_matches:
            # Check if this match is inside any exclude range
            is_inside = False
            for ex_start_line, ex_start_col, ex_end_line, ex_end_col in exclude_ranges:
                if m.line >= ex_start_line and (m.end_line or m.line) <= ex_end_line:
                    is_inside = True
                    break

            if not is_inside:
                result.append(m)

        return result
