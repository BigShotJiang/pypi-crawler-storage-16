"""
Dependency Scanner for Vantage Security Platform.

US-111: Dependency Scanner Implementation
Scans project dependencies for known vulnerabilities using OSV and NVD databases.

Features:
- Parse requirements.txt, pyproject.toml, poetry.lock, Pipfile.lock
- Query OSV database for vulnerabilities
- Check NVD for additional CVEs
- Generate SBOM in CycloneDX format
- AI framework-specific vulnerability checks
"""

import asyncio
import json
import logging
import re
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class DependencyFormat(str, Enum):
    """Supported dependency file formats."""

    REQUIREMENTS_TXT = "requirements.txt"
    PYPROJECT_TOML = "pyproject.toml"
    POETRY_LOCK = "poetry.lock"
    PIPFILE_LOCK = "Pipfile.lock"
    SETUP_PY = "setup.py"


class VulnerabilitySeverity(str, Enum):
    """Vulnerability severity levels."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    UNKNOWN = "unknown"


@dataclass
class Dependency:
    """Represents a project dependency."""

    name: str
    version: str | None = None
    version_constraint: str | None = None  # e.g., ">=1.0,<2.0"
    source_file: str | None = None
    is_direct: bool = True
    is_dev: bool = False
    extras: list[str] = field(default_factory=list)
    hashes: list[str] = field(default_factory=list)

    @property
    def package_url(self) -> str:
        """Get package URL (purl) for SBOM."""
        version_str = f"@{self.version}" if self.version else ""
        return f"pkg:pypi/{self.name.lower()}{version_str}"


@dataclass
class Vulnerability:
    """Represents a known vulnerability."""

    id: str  # CVE or OSV ID
    source: str  # "osv" or "nvd"
    severity: VulnerabilitySeverity
    cvss_score: float | None = None
    summary: str = ""
    description: str = ""
    affected_versions: list[str] = field(default_factory=list)
    fixed_versions: list[str] = field(default_factory=list)
    references: list[str] = field(default_factory=list)
    published_date: datetime | None = None
    cwe_ids: list[str] = field(default_factory=list)

    @property
    def is_critical(self) -> bool:
        """Check if this is a critical vulnerability."""
        return self.severity == VulnerabilitySeverity.CRITICAL or (
            self.cvss_score is not None and self.cvss_score >= 9.0
        )


@dataclass
class DependencyVulnerability:
    """A vulnerability associated with a specific dependency."""

    dependency: Dependency
    vulnerability: Vulnerability
    is_exploitable: bool = True
    fix_available: bool = False
    recommended_version: str | None = None


@dataclass
class DependencyScanResult:
    """Complete dependency scan result."""

    dependencies: list[Dependency]
    vulnerabilities: list[DependencyVulnerability]
    scan_timestamp: datetime
    scan_duration_ms: int
    summary: dict[str, Any] = field(default_factory=dict)
    sbom: str | None = None  # CycloneDX JSON

    @property
    def critical_count(self) -> int:
        """Count of critical vulnerabilities."""
        return sum(
            1
            for v in self.vulnerabilities
            if v.vulnerability.severity == VulnerabilitySeverity.CRITICAL
        )

    @property
    def high_count(self) -> int:
        """Count of high severity vulnerabilities."""
        return sum(
            1
            for v in self.vulnerabilities
            if v.vulnerability.severity == VulnerabilitySeverity.HIGH
        )


class VulnerabilityCache:
    """Simple in-memory cache for vulnerability data."""

    def __init__(self, ttl_hours: int = 24):
        """Initialize cache with TTL in hours."""
        self._cache: dict[str, tuple[Any, datetime]] = {}
        self._ttl = timedelta(hours=ttl_hours)

    def get(self, key: str) -> Any | None:
        """Get value from cache if not expired."""
        if key in self._cache:
            value, timestamp = self._cache[key]
            if datetime.now() - timestamp < self._ttl:
                return value
            else:
                del self._cache[key]
        return None

    def set(self, key: str, value: Any):
        """Set value in cache."""
        self._cache[key] = (value, datetime.now())

    def clear(self):
        """Clear all cached data."""
        self._cache.clear()


class DependencyScanner:
    """
    Scan project dependencies for known vulnerabilities.

    Supports requirements.txt, pyproject.toml, poetry.lock, and Pipfile.lock.
    Queries OSV and NVD databases for vulnerability information.
    """

    # AI/ML frameworks to prioritize for vulnerability checks
    AI_FRAMEWORKS = {
        "langchain",
        "langchain-core",
        "langchain-community",
        "openai",
        "anthropic",
        "transformers",
        "torch",
        "tensorflow",
        "crewai",
        "autogen",
        "llama-index",
        "semantic-kernel",
        "chromadb",
        "pinecone-client",
        "weaviate-client",
    }

    def __init__(self):
        """Initialize the dependency scanner."""
        self._cache = VulnerabilityCache(ttl_hours=24)
        self._http_available = False
        self._check_dependencies()

    def _check_dependencies(self):
        """Check for optional HTTP dependencies."""
        try:
            import aiohttp

            self._http_available = True
            self._aiohttp = aiohttp
        except ImportError:
            logger.warning("aiohttp not available, using mock responses for testing")
            self._aiohttp = None

        try:
            import tomllib

            self._tomllib = tomllib
        except ImportError:
            try:
                import tomli as tomllib

                self._tomllib = tomllib
            except ImportError:
                self._tomllib = None

    def scan(self, project_path: Path) -> DependencyScanResult:
        """
        Scan project dependencies for vulnerabilities.

        Args:
            project_path: Path to project directory

        Returns:
            DependencyScanResult with all findings
        """
        start_time = time.time()
        project_path = Path(project_path)

        # Extract dependencies
        dependencies = self._extract_dependencies(project_path)

        # Query for vulnerabilities (synchronous wrapper)
        vulnerabilities = asyncio.run(self._check_all_vulnerabilities(dependencies))

        # Generate SBOM
        sbom = self.generate_sbom(dependencies)

        # Calculate duration
        duration_ms = int((time.time() - start_time) * 1000)

        # Generate summary
        summary = self._generate_summary(dependencies, vulnerabilities)

        return DependencyScanResult(
            dependencies=dependencies,
            vulnerabilities=vulnerabilities,
            scan_timestamp=datetime.now(),
            scan_duration_ms=duration_ms,
            summary=summary,
            sbom=sbom,
        )

    def _extract_dependencies(self, project_path: Path) -> list[Dependency]:
        """Extract dependencies from all supported files."""
        dependencies: list[Dependency] = []
        seen: set[str] = set()

        # Check for requirements.txt
        req_files = [
            "requirements.txt",
            "requirements-dev.txt",
            "requirements/base.txt",
            "requirements/prod.txt",
        ]
        for req_file in req_files:
            req_path = project_path / req_file
            if req_path.exists():
                deps = self._parse_requirements_txt(req_path)
                for dep in deps:
                    key = f"{dep.name}:{dep.version}"
                    if key not in seen:
                        seen.add(key)
                        dependencies.append(dep)

        # Check for pyproject.toml
        pyproject_path = project_path / "pyproject.toml"
        if pyproject_path.exists():
            deps = self._parse_pyproject_toml(pyproject_path)
            for dep in deps:
                key = f"{dep.name}:{dep.version}"
                if key not in seen:
                    seen.add(key)
                    dependencies.append(dep)

        # Check for poetry.lock (has exact versions)
        poetry_lock_path = project_path / "poetry.lock"
        if poetry_lock_path.exists():
            deps = self._parse_poetry_lock(poetry_lock_path)
            for dep in deps:
                # Update version if we have it from lock file
                key = f"{dep.name}:{dep.version}"
                if key not in seen:
                    seen.add(key)
                    dependencies.append(dep)

        # Check for Pipfile.lock
        pipfile_lock_path = project_path / "Pipfile.lock"
        if pipfile_lock_path.exists():
            deps = self._parse_pipfile_lock(pipfile_lock_path)
            for dep in deps:
                key = f"{dep.name}:{dep.version}"
                if key not in seen:
                    seen.add(key)
                    dependencies.append(dep)

        return dependencies

    def _parse_requirements_txt(self, file_path: Path) -> list[Dependency]:
        """Parse requirements.txt file."""
        dependencies: list[Dependency] = []

        try:
            content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            logger.error(f"Failed to read {file_path}: {e}")
            return dependencies

        for line in content.splitlines():
            line = line.strip()

            # Skip comments and empty lines
            if not line or line.startswith("#"):
                continue

            # Skip options like -r, -e, --index-url
            if line.startswith("-"):
                continue

            # Parse the requirement
            dep = self._parse_requirement_line(line)
            if dep:
                dep.source_file = str(file_path)
                dependencies.append(dep)

        return dependencies

    def _parse_requirement_line(self, line: str) -> Dependency | None:
        """Parse a single requirement line."""
        # Handle extras: package[extra1,extra2]
        extras_match = re.match(r"^([a-zA-Z0-9_-]+)\[([^\]]+)\](.*)$", line)
        extras: list[str] = []
        if extras_match:
            name = extras_match.group(1)
            extras = [e.strip() for e in extras_match.group(2).split(",")]
            rest = extras_match.group(3)
        else:
            # Simple name==version or name>=version pattern
            match = re.match(r"^([a-zA-Z0-9_-]+)(.*)$", line)
            if not match:
                return None
            name = match.group(1)
            rest = match.group(2)

        # Parse version constraint
        version = None
        version_constraint = None

        if rest:
            # Remove environment markers
            rest = re.sub(r";.*$", "", rest).strip()

            # Extract version
            version_match = re.match(r"^([><=!~]+)(.+)$", rest)
            if version_match:
                operator = version_match.group(1)
                version_str = version_match.group(2).strip()

                if operator == "==":
                    version = version_str
                    version_constraint = f"=={version_str}"
                else:
                    version_constraint = f"{operator}{version_str}"

        return Dependency(
            name=name,
            version=version,
            version_constraint=version_constraint,
            extras=extras,
        )

    def _parse_pyproject_toml(self, file_path: Path) -> list[Dependency]:
        """Parse pyproject.toml file."""
        dependencies: list[Dependency] = []

        if not self._tomllib:
            logger.warning("TOML parsing not available")
            return dependencies

        try:
            content = file_path.read_text(encoding="utf-8")
            data = self._tomllib.loads(content)
        except Exception as e:
            logger.error(f"Failed to parse {file_path}: {e}")
            return dependencies

        # Check [project.dependencies]
        project_deps = data.get("project", {}).get("dependencies", [])
        for dep_str in project_deps:
            dep = self._parse_requirement_line(dep_str)
            if dep:
                dep.source_file = str(file_path)
                dependencies.append(dep)

        # Check [tool.poetry.dependencies]
        poetry_deps = data.get("tool", {}).get("poetry", {}).get("dependencies", {})
        for name, version_spec in poetry_deps.items():
            if name == "python":
                continue

            version = None
            if isinstance(version_spec, str):
                version = version_spec.lstrip("^~>=<")
            elif isinstance(version_spec, dict):
                version = version_spec.get("version", "").lstrip("^~>=<")

            dep = Dependency(
                name=name,
                version=version if version else None,
                version_constraint=(version_spec if isinstance(version_spec, str) else None),
                source_file=str(file_path),
            )
            dependencies.append(dep)

        # Check dev dependencies
        dev_deps = data.get("tool", {}).get("poetry", {}).get("dev-dependencies", {})
        for name, version_spec in dev_deps.items():
            version = None
            if isinstance(version_spec, str):
                version = version_spec.lstrip("^~>=<")

            dep = Dependency(
                name=name,
                version=version if version else None,
                source_file=str(file_path),
                is_dev=True,
            )
            dependencies.append(dep)

        return dependencies

    def _parse_poetry_lock(self, file_path: Path) -> list[Dependency]:
        """Parse poetry.lock file."""
        dependencies: list[Dependency] = []

        if not self._tomllib:
            logger.warning("TOML parsing not available")
            return dependencies

        try:
            content = file_path.read_text(encoding="utf-8")
            data = self._tomllib.loads(content)
        except Exception as e:
            logger.error(f"Failed to parse {file_path}: {e}")
            return dependencies

        for package in data.get("package", []):
            dep = Dependency(
                name=package.get("name", ""),
                version=package.get("version"),
                source_file=str(file_path),
                is_direct=package.get("category", "main") == "main",
                is_dev=package.get("category") == "dev",
            )
            dependencies.append(dep)

        return dependencies

    def _parse_pipfile_lock(self, file_path: Path) -> list[Dependency]:
        """Parse Pipfile.lock file."""
        dependencies: list[Dependency] = []

        try:
            content = file_path.read_text(encoding="utf-8")
            data = json.loads(content)
        except Exception as e:
            logger.error(f"Failed to parse {file_path}: {e}")
            return dependencies

        # Parse default dependencies
        for name, info in data.get("default", {}).items():
            version = info.get("version", "").lstrip("=")
            hashes = info.get("hashes", [])

            dep = Dependency(
                name=name,
                version=version if version else None,
                source_file=str(file_path),
                hashes=hashes,
            )
            dependencies.append(dep)

        # Parse dev dependencies
        for name, info in data.get("develop", {}).items():
            version = info.get("version", "").lstrip("=")

            dep = Dependency(
                name=name,
                version=version if version else None,
                source_file=str(file_path),
                is_dev=True,
            )
            dependencies.append(dep)

        return dependencies

    async def _check_all_vulnerabilities(
        self, dependencies: list[Dependency]
    ) -> list[DependencyVulnerability]:
        """Check all dependencies for vulnerabilities."""
        all_vulns: list[DependencyVulnerability] = []

        # Prioritize AI frameworks
        ai_deps = [d for d in dependencies if d.name.lower() in self.AI_FRAMEWORKS]
        other_deps = [d for d in dependencies if d.name.lower() not in self.AI_FRAMEWORKS]

        # Check AI frameworks first
        for dep in ai_deps:
            vulns = await self._check_dependency_vulnerabilities(dep)
            all_vulns.extend(vulns)

        # Then check others
        for dep in other_deps:
            vulns = await self._check_dependency_vulnerabilities(dep)
            all_vulns.extend(vulns)

        return all_vulns

    async def _check_dependency_vulnerabilities(
        self, dependency: Dependency
    ) -> list[DependencyVulnerability]:
        """Check a single dependency for vulnerabilities."""
        vulns: list[DependencyVulnerability] = []

        # Check cache first
        cache_key = f"{dependency.name}:{dependency.version}"
        cached = self._cache.get(cache_key)
        if cached:
            return cached

        # Query OSV
        osv_vulns = await self.query_osv(dependency.name, dependency.version or "")
        for vuln in osv_vulns:
            dep_vuln = DependencyVulnerability(
                dependency=dependency,
                vulnerability=vuln,
                fix_available=len(vuln.fixed_versions) > 0,
                recommended_version=(vuln.fixed_versions[0] if vuln.fixed_versions else None),
            )
            vulns.append(dep_vuln)

        # Cache results
        self._cache.set(cache_key, vulns)

        return vulns

    async def query_osv(self, package: str, version: str) -> list[Vulnerability]:
        """
        Query OSV database for known vulnerabilities.

        Args:
            package: Package name
            version: Package version

        Returns:
            List of Vulnerability objects
        """
        vulnerabilities: list[Vulnerability] = []

        if not self._http_available:
            # Return mock data for testing
            return self._get_mock_vulnerabilities(package, version)

        try:
            async with self._aiohttp.ClientSession() as session:
                url = "https://api.osv.dev/v1/query"
                payload = {"package": {"name": package, "ecosystem": "PyPI"}}
                if version:
                    payload["version"] = version

                async with session.post(url, json=payload) as response:
                    if response.status == 200:
                        data = await response.json()
                        vulnerabilities = self._parse_osv_response(data)
                    else:
                        logger.warning(f"OSV query failed for {package}: {response.status}")
        except Exception as e:
            logger.error(f"Error querying OSV for {package}: {e}")

        return vulnerabilities

    def _parse_osv_response(self, data: dict) -> list[Vulnerability]:
        """Parse OSV API response into Vulnerability objects."""
        vulnerabilities: list[Vulnerability] = []

        for vuln_data in data.get("vulns", []):
            severity = VulnerabilitySeverity.UNKNOWN
            cvss_score = None

            # Extract severity from database_specific or severity array
            if "severity" in vuln_data:
                for sev in vuln_data["severity"]:
                    if sev.get("type") == "CVSS_V3":
                        score = sev.get("score", "")
                        try:
                            # Extract numeric score from CVSS string
                            cvss_score = float(score.split("/")[0])
                            severity = self._cvss_to_severity(cvss_score)
                        except (ValueError, IndexError):
                            pass

            # Get affected versions
            affected_versions = []
            fixed_versions = []
            for affected in vuln_data.get("affected", []):
                for version_range in affected.get("ranges", []):
                    for event in version_range.get("events", []):
                        if "introduced" in event:
                            affected_versions.append(f">={event['introduced']}")
                        if "fixed" in event:
                            fixed_versions.append(event["fixed"])

            # Get references
            references = [
                ref.get("url", "") for ref in vuln_data.get("references", []) if ref.get("url")
            ]

            # Get CWE IDs
            cwe_ids = vuln_data.get("database_specific", {}).get("cwe_ids", [])

            vulnerability = Vulnerability(
                id=vuln_data.get("id", ""),
                source="osv",
                severity=severity,
                cvss_score=cvss_score,
                summary=vuln_data.get("summary", ""),
                description=vuln_data.get("details", ""),
                affected_versions=affected_versions,
                fixed_versions=fixed_versions,
                references=references,
                cwe_ids=cwe_ids,
            )
            vulnerabilities.append(vulnerability)

        return vulnerabilities

    def _cvss_to_severity(self, score: float) -> VulnerabilitySeverity:
        """Convert CVSS score to severity level."""
        if score >= 9.0:
            return VulnerabilitySeverity.CRITICAL
        elif score >= 7.0:
            return VulnerabilitySeverity.HIGH
        elif score >= 4.0:
            return VulnerabilitySeverity.MEDIUM
        elif score > 0:
            return VulnerabilitySeverity.LOW
        return VulnerabilitySeverity.UNKNOWN

    def _get_mock_vulnerabilities(self, package: str, version: str) -> list[Vulnerability]:
        """Return mock vulnerabilities for testing."""
        # Known vulnerabilities for common packages (for testing)
        mock_vulns: dict[str, list[dict]] = {
            "requests": [
                {
                    "id": "GHSA-x84v-xcm2-53pg",
                    "summary": "Requests session object doesn't verify SSL certificates",
                    "severity": VulnerabilitySeverity.MEDIUM,
                    "cvss_score": 5.3,
                    "affected": "< 2.32.0",
                    "fixed": "2.32.0",
                }
            ],
            "urllib3": [
                {
                    "id": "CVE-2023-45803",
                    "summary": "Cookie leakage in urllib3",
                    "severity": VulnerabilitySeverity.MEDIUM,
                    "cvss_score": 4.2,
                    "affected": "< 2.0.7",
                    "fixed": "2.0.7",
                }
            ],
        }

        vulns: list[Vulnerability] = []
        if package.lower() in mock_vulns:
            for mock in mock_vulns[package.lower()]:
                vuln = Vulnerability(
                    id=mock["id"],
                    source="mock",
                    severity=mock["severity"],
                    cvss_score=mock.get("cvss_score"),
                    summary=mock["summary"],
                    affected_versions=[mock["affected"]],
                    fixed_versions=[mock["fixed"]],
                )
                vulns.append(vuln)

        return vulns

    def generate_sbom(self, dependencies: list[Dependency]) -> str:
        """
        Generate CycloneDX SBOM in JSON format.

        Args:
            dependencies: List of dependencies

        Returns:
            CycloneDX JSON string
        """
        components = []

        for dep in dependencies:
            component = {
                "type": "library",
                "bom-ref": dep.package_url,
                "name": dep.name,
                "purl": dep.package_url,
            }

            if dep.version:
                component["version"] = dep.version

            if dep.hashes:
                component["hashes"] = [
                    {"alg": "SHA-256", "content": h} for h in dep.hashes if "sha256" in h.lower()
                ]

            components.append(component)

        sbom = {
            "$schema": "http://cyclonedx.org/schema/bom-1.4.schema.json",
            "bomFormat": "CycloneDX",
            "specVersion": "1.4",
            "serialNumber": f"urn:uuid:{uuid.uuid4()}",
            "version": 1,
            "metadata": {
                "timestamp": datetime.now().isoformat(),
                "tools": [
                    {
                        "vendor": "Vantage",
                        "name": "Security Scanner",
                        "version": "1.0.0",
                    }
                ],
            },
            "components": components,
        }

        return json.dumps(sbom, indent=2)

    def _generate_summary(
        self,
        dependencies: list[Dependency],
        vulnerabilities: list[DependencyVulnerability],
    ) -> dict[str, Any]:
        """Generate scan summary statistics."""
        severity_counts = {
            "critical": 0,
            "high": 0,
            "medium": 0,
            "low": 0,
            "unknown": 0,
        }

        for vuln in vulnerabilities:
            severity = vuln.vulnerability.severity.value
            severity_counts[severity] = severity_counts.get(severity, 0) + 1

        # Count AI framework vulnerabilities
        ai_vulns = sum(
            1 for v in vulnerabilities if v.dependency.name.lower() in self.AI_FRAMEWORKS
        )

        return {
            "total_dependencies": len(dependencies),
            "direct_dependencies": sum(1 for d in dependencies if d.is_direct),
            "dev_dependencies": sum(1 for d in dependencies if d.is_dev),
            "total_vulnerabilities": len(vulnerabilities),
            "ai_framework_vulnerabilities": ai_vulns,
            "by_severity": severity_counts,
            "fixable_vulnerabilities": sum(1 for v in vulnerabilities if v.fix_available),
        }


def scan_dependencies(project_path: Path) -> DependencyScanResult:
    """
    Convenience function to scan project dependencies.

    Args:
        project_path: Path to project directory

    Returns:
        DependencyScanResult with all findings
    """
    scanner = DependencyScanner()
    return scanner.scan(project_path)
