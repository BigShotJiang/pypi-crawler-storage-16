"""
Dynamic Confidence Scoring Module.

This module calculates dynamic confidence scores for security findings
instead of using hard-coded values. It considers multiple factors including
context, file type, pattern severity, and proximity to user input.
"""

import logging
import re
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class ConfidenceFactor:
    """A factor that affects confidence scoring."""

    name: str
    multiplier: float
    description: str


class DynamicConfidenceCalculator:
    """
    Calculate dynamic confidence scores for security findings.

    Replaces hard-coded confidence values with context-aware scoring.
    """

    # Severe patterns that indicate higher confidence
    SEVERE_PROMPT_PATTERNS = [
        "ignore instructions",
        "forget everything",
        "disregard previous",
        "override system",
        "bypass restrictions",
        "jailbreak",
        "act as root",
        "sudo",
        "system prompt",
    ]

    # Mild patterns that might be less concerning
    MILD_PROMPT_PATTERNS = [
        "please",
        "could you",
        "help me",
        "explain",
        "what is",
        "how to",
    ]

    # User input indicators
    USER_INPUT_PATTERNS = [
        r"request\.(get|post|body)",
        r"input\(",
        r"raw_input\(",
        r"sys\.argv",
        r"os\.environ",
        r"getenv\(",
        r"user_input",
        r"user_data",
        r"params\[",
        r"query\[",
        r"\$_GET",
        r"\$_POST",
        r"req\.query",
        r"req\.body",
        r"req\.params",
    ]

    def calculate_prompt_injection_confidence(
        self,
        prompt: str,
        file_path: str,
        line_number: int,
        source_code: str | None = None,
        pattern_matched: str | None = None,
    ) -> tuple[float, list[ConfidenceFactor]]:
        """
        Calculate confidence for prompt injection findings.

        Args:
            prompt: The prompt text being analyzed.
            file_path: Path to the file.
            line_number: Line number of the finding.
            source_code: Full source code (optional).
            pattern_matched: The specific pattern that was matched.

        Returns:
            Tuple of (confidence_score, list_of_factors).
        """
        base_confidence = 0.5  # Start with neutral confidence
        factors = []

        # Factor 1: Location context (file type)
        location_factor = self._get_location_factor(file_path, line_number, source_code)
        factors.append(location_factor)
        base_confidence *= location_factor.multiplier

        # Factor 2: Pattern severity
        severity_factor = self._get_pattern_severity_factor(prompt, pattern_matched)
        factors.append(severity_factor)
        base_confidence *= severity_factor.multiplier

        # Factor 3: User input proximity
        input_factor = self._get_user_input_factor(file_path, line_number, source_code)
        factors.append(input_factor)
        base_confidence *= input_factor.multiplier

        # Factor 4: Validation presence
        validation_factor = self._get_validation_factor(source_code, line_number)
        factors.append(validation_factor)
        base_confidence *= validation_factor.multiplier

        # Factor 5: Prompt complexity
        complexity_factor = self._get_complexity_factor(prompt)
        factors.append(complexity_factor)
        base_confidence *= complexity_factor.multiplier

        # Clamp confidence to valid range
        final_confidence = max(0.1, min(1.0, base_confidence))

        return final_confidence, factors

    def calculate_secret_confidence(
        self,
        secret_value: str,
        file_path: str,
        variable_name: str | None = None,
        context: str | None = None,
        entropy: float | None = None,
    ) -> tuple[float, list[ConfidenceFactor]]:
        """
        Calculate confidence for secret detection findings.

        Args:
            secret_value: The potential secret.
            file_path: Path to the file.
            variable_name: Name of the variable (if applicable).
            context: Surrounding code context.
            entropy: Entropy value of the secret.

        Returns:
            Tuple of (confidence_score, list_of_factors).
        """
        base_confidence = 0.6
        factors = []

        # Factor 1: File type
        file_factor = self._get_file_type_factor(file_path)
        factors.append(file_factor)
        base_confidence *= file_factor.multiplier

        # Factor 2: Variable naming
        if variable_name:
            var_factor = self._get_variable_name_factor(variable_name)
            factors.append(var_factor)
            base_confidence *= var_factor.multiplier

        # Factor 3: Entropy
        if entropy is not None:
            entropy_factor = self._get_entropy_factor(entropy)
            factors.append(entropy_factor)
            base_confidence *= entropy_factor.multiplier

        # Factor 4: Context clues
        if context:
            context_factor = self._get_context_clues_factor(context)
            factors.append(context_factor)
            base_confidence *= context_factor.multiplier

        # Factor 5: Secret pattern matching
        pattern_factor = self._get_secret_pattern_factor(secret_value)
        factors.append(pattern_factor)
        base_confidence *= pattern_factor.multiplier

        # Clamp confidence
        final_confidence = max(0.1, min(1.0, base_confidence))

        return final_confidence, factors

    def _get_location_factor(
        self, file_path: str, line_number: int, source_code: str | None = None
    ) -> ConfidenceFactor:
        """Get confidence factor based on code location."""
        file_lower = file_path.lower() if file_path else ""

        # Check if in comment or docstring
        if source_code and self._is_in_comment_or_docstring(source_code, line_number):
            return ConfidenceFactor(
                name="in_comment",
                multiplier=0.5,
                description="Code is in a comment or docstring",
            )

        # Check file type
        if "test" in file_lower or "spec" in file_lower:
            return ConfidenceFactor(
                name="test_file", multiplier=0.3, description="Located in test file"
            )

        if "example" in file_lower or "demo" in file_lower:
            return ConfidenceFactor(
                name="example_file",
                multiplier=0.4,
                description="Located in example/demo file",
            )

        if any(file_lower.endswith(ext) for ext in [".md", ".rst", ".txt"]):
            return ConfidenceFactor(
                name="documentation",
                multiplier=0.3,
                description="Located in documentation",
            )

        # Production code
        if any(part in file_lower for part in ["src/", "lib/", "app/", "api/"]):
            return ConfidenceFactor(
                name="production_code",
                multiplier=1.2,
                description="Located in production code",
            )

        return ConfidenceFactor(
            name="standard_location",
            multiplier=1.0,
            description="Standard code location",
        )

    def _get_pattern_severity_factor(
        self, prompt: str, pattern_matched: str | None = None
    ) -> ConfidenceFactor:
        """Get factor based on pattern severity."""
        prompt_lower = prompt.lower() if prompt else ""

        # Check for severe patterns
        for severe in self.SEVERE_PROMPT_PATTERNS:
            if severe in prompt_lower:
                return ConfidenceFactor(
                    name="severe_pattern",
                    multiplier=1.3,
                    description=f"Contains severe pattern: {severe}",
                )

        # Check if only mild patterns
        has_mild = any(mild in prompt_lower for mild in self.MILD_PROMPT_PATTERNS)
        if has_mild and pattern_matched:
            return ConfidenceFactor(
                name="mild_pattern",
                multiplier=0.8,
                description="Contains only mild patterns",
            )

        return ConfidenceFactor(
            name="standard_pattern",
            multiplier=1.0,
            description="Standard pattern severity",
        )

    def _get_user_input_factor(
        self, file_path: str, line_number: int, source_code: str | None = None
    ) -> ConfidenceFactor:
        """Check proximity to user input."""
        if not source_code:
            return ConfidenceFactor(
                name="unknown_input",
                multiplier=0.9,
                description="User input proximity unknown",
            )

        lines = source_code.split("\n")
        if line_number <= 0 or line_number > len(lines):
            return ConfidenceFactor(
                name="invalid_line", multiplier=0.9, description="Invalid line number"
            )

        # Check within 10 lines for user input
        start = max(0, line_number - 10)
        end = min(len(lines), line_number + 10)

        for i in range(start, end):
            line = lines[i]
            for pattern in self.USER_INPUT_PATTERNS:
                if re.search(pattern, line):
                    distance = abs(i - (line_number - 1))
                    if distance <= 3:
                        return ConfidenceFactor(
                            name="user_input_nearby",
                            multiplier=1.2,
                            description=f"User input detected within {distance} lines",
                        )
                    else:
                        return ConfidenceFactor(
                            name="user_input_distant",
                            multiplier=1.1,
                            description=f"User input detected {distance} lines away",
                        )

        return ConfidenceFactor(
            name="no_user_input",
            multiplier=0.7,
            description="No user input detected nearby",
        )

    def _get_validation_factor(
        self, source_code: str | None = None, line_number: int = 0
    ) -> ConfidenceFactor:
        """Check for input validation."""
        if not source_code:
            return ConfidenceFactor(
                name="unknown_validation",
                multiplier=1.0,
                description="Validation status unknown",
            )

        validation_patterns = [
            r"validate[_\w]*\(",
            r"sanitize[_\w]*\(",
            r"clean[_\w]*\(",
            r"escape[_\w]*\(",
            r"if\s+.*\s+in\s+",
            r"if\s+len\(",
            r"\.strip\(\)",
            r"\.replace\(",
            r"re\.(match|search|sub)\(",
        ]

        lines = source_code.split("\n")
        start = max(0, line_number - 5)
        end = min(len(lines), line_number + 3)

        for i in range(start, end):
            if i < len(lines):
                line = lines[i]
                for pattern in validation_patterns:
                    if re.search(pattern, line):
                        return ConfidenceFactor(
                            name="has_validation",
                            multiplier=0.6,
                            description="Input validation detected",
                        )

        return ConfidenceFactor(
            name="no_validation",
            multiplier=1.1,
            description="No input validation detected",
        )

    def _get_complexity_factor(self, prompt: str) -> ConfidenceFactor:
        """Assess prompt complexity."""
        if not prompt:
            return ConfidenceFactor(name="empty_prompt", multiplier=0.5, description="Empty prompt")

        # Check length
        if len(prompt) < 20:
            return ConfidenceFactor(
                name="simple_prompt", multiplier=0.7, description="Very simple prompt"
            )

        # Check for multiple instructions or complex structure
        instruction_indicators = [
            "1.",
            "2.",
            "step",
            "first",
            "then",
            "next",
            "must",
            "should",
            "ensure",
            "make sure",
        ]

        complexity_count = sum(
            1 for indicator in instruction_indicators if indicator in prompt.lower()
        )

        if complexity_count >= 3:
            return ConfidenceFactor(
                name="complex_prompt",
                multiplier=1.2,
                description="Complex multi-step prompt",
            )

        return ConfidenceFactor(
            name="standard_complexity",
            multiplier=1.0,
            description="Standard prompt complexity",
        )

    def _get_file_type_factor(self, file_path: str) -> ConfidenceFactor:
        """Get factor based on file type for secrets."""
        if not file_path:
            return ConfidenceFactor(
                name="unknown_file", multiplier=1.0, description="Unknown file type"
            )

        file_lower = file_path.lower()

        # Configuration files - higher likelihood of secrets
        if any(file_lower.endswith(ext) for ext in [".env", ".ini", ".cfg", ".conf"]):
            return ConfidenceFactor(
                name="config_file", multiplier=1.3, description="Configuration file"
            )

        # Test files - lower likelihood
        if "test" in file_lower:
            return ConfidenceFactor(name="test_file", multiplier=0.4, description="Test file")

        # Source code files
        if any(file_lower.endswith(ext) for ext in [".py", ".js", ".ts", ".java"]):
            return ConfidenceFactor(
                name="source_file", multiplier=1.0, description="Source code file"
            )

        return ConfidenceFactor(name="other_file", multiplier=0.9, description="Other file type")

    def _get_variable_name_factor(self, variable_name: str) -> ConfidenceFactor:
        """Get factor based on variable naming."""
        var_lower = variable_name.lower()

        # Strong indicators of real secrets
        secret_indicators = [
            "api_key",
            "apikey",
            "secret",
            "token",
            "password",
            "auth",
            "credential",
            "private_key",
        ]

        for indicator in secret_indicators:
            if indicator in var_lower:
                # Check for test/example modifiers
                if any(mod in var_lower for mod in ["test", "example", "demo", "fake"]):
                    return ConfidenceFactor(
                        name="test_variable",
                        multiplier=0.3,
                        description=f"Test/example {indicator}",
                    )
                return ConfidenceFactor(
                    name="secret_variable",
                    multiplier=1.2,
                    description=f"Variable name contains '{indicator}'",
                )

        return ConfidenceFactor(
            name="generic_variable", multiplier=0.9, description="Generic variable name"
        )

    def _get_entropy_factor(self, entropy: float) -> ConfidenceFactor:
        """Get factor based on entropy value."""
        if entropy < 2.0:
            return ConfidenceFactor(
                name="very_low_entropy",
                multiplier=0.3,
                description=f"Very low entropy: {entropy:.2f}",
            )
        elif entropy < 3.0:
            return ConfidenceFactor(
                name="low_entropy",
                multiplier=0.6,
                description=f"Low entropy: {entropy:.2f}",
            )
        elif entropy < 4.5:
            return ConfidenceFactor(
                name="medium_entropy",
                multiplier=1.0,
                description=f"Medium entropy: {entropy:.2f}",
            )
        else:
            return ConfidenceFactor(
                name="high_entropy",
                multiplier=1.3,
                description=f"High entropy: {entropy:.2f}",
            )

    def _get_context_clues_factor(self, context: str) -> ConfidenceFactor:
        """Get factor based on context clues."""
        context_lower = context.lower()

        # Check for test/example indicators
        if any(word in context_lower for word in ["test", "example", "demo", "sample"]):
            return ConfidenceFactor(
                name="test_context", multiplier=0.5, description="Test/example context"
            )

        # Check for production indicators
        if any(word in context_lower for word in ["production", "prod", "live"]):
            return ConfidenceFactor(
                name="production_context",
                multiplier=1.3,
                description="Production context",
            )

        return ConfidenceFactor(
            name="neutral_context", multiplier=1.0, description="Neutral context"
        )

    def _get_secret_pattern_factor(self, secret_value: str) -> ConfidenceFactor:
        """Check if value matches known secret patterns."""
        # Known API key patterns
        patterns = [
            (r"sk-[a-zA-Z0-9]{20,}", "OpenAI", 1.5),
            (r"ghp_[a-zA-Z0-9]{36}", "GitHub", 1.5),
            (r"AKIA[0-9A-Z]{16}", "AWS", 1.5),
            (r"xox[baprs]-", "Slack", 1.4),
        ]

        for pattern, name, multiplier in patterns:
            if re.match(pattern, secret_value):
                return ConfidenceFactor(
                    name="known_pattern",
                    multiplier=multiplier,
                    description=f"Matches {name} pattern",
                )

        return ConfidenceFactor(
            name="unknown_pattern", multiplier=0.9, description="No known pattern match"
        )

    def _is_in_comment_or_docstring(self, source_code: str, line_number: int) -> bool:
        """Check if line is in a comment or docstring."""
        lines = source_code.split("\n")
        if line_number <= 0 or line_number > len(lines):
            return False

        line = lines[line_number - 1].strip()

        # Check for single-line comments
        if line.startswith("#") or line.startswith("//"):
            return True

        # Check for docstrings (simplified check)
        for i in range(max(0, line_number - 5), min(len(lines), line_number + 5)):
            if '"""' in lines[i] or "'''" in lines[i]:
                return True

        return False
