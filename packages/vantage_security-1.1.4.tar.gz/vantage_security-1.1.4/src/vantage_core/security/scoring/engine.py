"""
Rule-Based Scoring Engine (US-120).

Main security scoring engine that computes the Agent Topology Security Score (ATSS)
by aggregating multiple security dimensions into a unified 0-100 score.
"""

from dataclasses import dataclass, field
from typing import Any

from vantage_core.security.models import SecurityAgent, SecurityScanResult
from vantage_core.security.scoring.agent_risk import AgentRiskProfile, AgentRiskScorer
from vantage_core.security.scoring.aggregation import VulnerabilityAggregator
from vantage_core.security.scoring.explanation import ScoreExplainer
from vantage_core.security.scoring.grades import GradeConverter
from vantage_core.security.scoring.pattern_score import CommunicationPatternScorer
from vantage_core.security.scoring.trust_score import TrustBoundaryScorer
from vantage_core.security.topology.graph import AgentGraph

# Default scoring weights
SCORING_WEIGHTS = {
    "vulnerability": 0.40,  # Findings severity
    "trust_boundary": 0.25,  # Boundary violations
    "communication": 0.20,  # Topology patterns
    "agent_risk": 0.15,  # Per-agent risk
}


@dataclass
class ScoreComponent:
    """
    Individual score component with weight and contribution.

    Represents one dimension of the security score.
    """

    name: str
    score: float  # 0-100
    weight: float  # 0-1
    contribution: float  # Weighted contribution to total
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class ATSSResult:
    """
    Complete Agent Topology Security Score result.

    Contains the overall score, grade, component breakdowns,
    per-agent scores, explanation, and recommendations.
    """

    overall_score: float  # 0-100
    grade: str  # A-F
    confidence: float  # 0-1
    vulnerability_score: float  # Component scores
    trust_boundary_score: float
    communication_score: float
    agent_risk_score: float
    components: list[ScoreComponent]
    per_agent_scores: dict[str, float]
    high_risk_agents: list[str]
    explanation: str
    recommendations: list[str]
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def is_passing(self) -> bool:
        """Check if score represents a passing grade (C or better)."""
        return self.grade in ["A", "B", "C"]

    @property
    def risk_level(self) -> str:
        """Get overall risk level description."""
        if self.overall_score >= 90:
            return "minimal"
        elif self.overall_score >= 70:
            return "low"
        elif self.overall_score >= 50:
            return "moderate"
        elif self.overall_score >= 30:
            return "high"
        else:
            return "critical"


class SecurityScoringEngine:
    """
    Main ATSS scoring engine.

    Calculates the Agent Topology Security Score by analyzing
    vulnerability findings, trust boundaries, communication patterns,
    and per-agent risks.
    """

    def __init__(
        self,
        weights: dict[str, float] | None = None,
    ):
        """
        Initialize the scoring engine.

        Args:
            weights: Custom component weights
        """
        self.weights = weights or SCORING_WEIGHTS

        # Validate weights sum to 1.0
        total_weight = sum(self.weights.values())
        if abs(total_weight - 1.0) > 0.01:
            raise ValueError(f"Weights must sum to 1.0, got {total_weight}")

        # Initialize component scorers
        self.vulnerability_aggregator = VulnerabilityAggregator()
        self.trust_scorer = TrustBoundaryScorer()
        self.pattern_scorer = CommunicationPatternScorer()
        self.agent_risk_scorer = AgentRiskScorer()
        self.grade_converter = GradeConverter()
        self.explainer = ScoreExplainer()

    def calculate_atss(
        self,
        scan_result: SecurityScanResult,
        graph: AgentGraph | None = None,
    ) -> ATSSResult:
        """
        Calculate the Agent Topology Security Score.

        Args:
            scan_result: Security scan results with findings and agents
            graph: Agent topology graph (built from agents if not provided)

        Returns:
            ATSSResult with complete score breakdown
        """
        # Build graph if not provided
        if graph is None:
            graph = AgentGraph.from_agents(
                scan_result.agents,
                scan_result.communications,
            )

        # Calculate component scores
        components = []

        # 1. Vulnerability Score
        vuln_result = self.vulnerability_aggregator.aggregate_from_result(scan_result)
        vuln_component = ScoreComponent(
            name="vulnerability",
            score=vuln_result.score,
            weight=self.weights["vulnerability"],
            contribution=vuln_result.score * self.weights["vulnerability"],
            details={
                "total_findings": vuln_result.total_findings,
                "by_severity": vuln_result.by_severity,
                "risk_level": vuln_result.risk_level,
            },
        )
        components.append(vuln_component)

        # 2. Trust Boundary Score
        trust_result = self.trust_scorer.score(graph)
        trust_component = ScoreComponent(
            name="trust_boundary",
            score=trust_result.score,
            weight=self.weights["trust_boundary"],
            contribution=trust_result.score * self.weights["trust_boundary"],
            details={
                "total_crossings": trust_result.total_crossings,
                "high_risk_crossings": trust_result.high_risk_crossings,
                "escalation_paths": trust_result.escalation_paths,
                "penalties": trust_result.penalties,
            },
        )
        components.append(trust_component)

        # 3. Communication Pattern Score
        pattern_result = self.pattern_scorer.score(graph)
        pattern_component = ScoreComponent(
            name="communication",
            score=pattern_result.score,
            weight=self.weights["communication"],
            contribution=pattern_result.score * self.weights["communication"],
            details={
                "primary_pattern": (
                    pattern_result.primary_pattern.value if pattern_result.primary_pattern else None
                ),
                "hub_nodes": pattern_result.hub_nodes,
                "articulation_points": pattern_result.articulation_points,
                "metrics": pattern_result.metrics,
            },
        )
        components.append(pattern_component)

        # 4. Per-Agent Risk Score
        agent_profiles = self.agent_risk_scorer.score_all_agents(
            scan_result.agents,
            graph,
            scan_result.findings,
        )

        # Calculate overall agent risk score (average of individual risks)
        if agent_profiles:
            agent_risks = [p.overall_risk for p in agent_profiles.values()]
            avg_agent_risk = sum(agent_risks) / len(agent_risks)
            agent_risk_score = 100.0 - avg_agent_risk  # Invert: lower risk = higher score
        else:
            agent_risk_score = 100.0

        # Identify high-risk agents
        high_risk_agents = [
            agent_id for agent_id, profile in agent_profiles.items() if profile.is_high_risk
        ]

        agent_component = ScoreComponent(
            name="agent_risk",
            score=agent_risk_score,
            weight=self.weights["agent_risk"],
            contribution=agent_risk_score * self.weights["agent_risk"],
            details={
                "agent_count": len(agent_profiles),
                "high_risk_count": len(high_risk_agents),
                "high_risk_agents": high_risk_agents,
            },
        )
        components.append(agent_component)

        # Calculate overall score
        overall_score = sum(c.contribution for c in components)
        overall_score = round(min(100, max(0, overall_score)), 2)

        # Get grade
        grade = self.grade_converter.get_grade_letter(overall_score)

        # Calculate confidence
        confidence = self._calculate_confidence(scan_result, graph)

        # Generate explanation
        explanation_result = self.explainer.explain(
            overall_score=overall_score,
            grade=grade,
            vulnerability_score=vuln_component.score,
            trust_boundary_score=trust_component.score,
            communication_score=pattern_component.score,
            agent_risk_score=agent_component.score,
            finding_count=vuln_result.total_findings,
            agent_count=len(scan_result.agents),
            high_risk_agents=len(high_risk_agents),
            escalation_paths=trust_result.escalation_paths,
            boundary_crossings=trust_result.total_crossings,
            hub_nodes=len(pattern_result.hub_nodes),
            articulation_points=len(pattern_result.articulation_points),
            critical_findings=scan_result.critical_count + scan_result.high_count,
        )

        # Collect recommendations
        recommendations = []
        recommendations.extend(trust_result.recommendations)
        recommendations.extend(pattern_result.recommendations)
        recommendations.extend(explanation_result.top_recommendations)
        # Deduplicate while preserving order
        seen = set()
        unique_recs = []
        for rec in recommendations:
            if rec not in seen:
                seen.add(rec)
                unique_recs.append(rec)
        recommendations = unique_recs[:10]  # Top 10

        # Build per-agent scores map
        per_agent_scores = {
            agent_id: round(100.0 - profile.overall_risk, 2)
            for agent_id, profile in agent_profiles.items()
        }

        return ATSSResult(
            overall_score=overall_score,
            grade=grade,
            confidence=confidence,
            vulnerability_score=vuln_component.score,
            trust_boundary_score=trust_component.score,
            communication_score=pattern_component.score,
            agent_risk_score=agent_component.score,
            components=components,
            per_agent_scores=per_agent_scores,
            high_risk_agents=high_risk_agents,
            explanation=explanation_result.summary,
            recommendations=recommendations,
            metadata={
                "weights": self.weights,
                "agent_count": len(scan_result.agents),
                "finding_count": len(scan_result.findings),
                "scan_id": scan_result.scan_id,
            },
        )

    def _calculate_confidence(
        self,
        scan_result: SecurityScanResult,
        graph: AgentGraph,
    ) -> float:
        """Calculate confidence in the score."""
        confidence = 1.0

        # Reduce confidence for small sample sizes
        if len(scan_result.agents) < 3:
            confidence -= 0.1

        # Reduce confidence for no communications
        if graph.edge_count == 0:
            confidence -= 0.15

        # Reduce confidence for low finding confidence average
        if scan_result.findings:
            avg_finding_confidence = sum(f.confidence for f in scan_result.findings) / len(
                scan_result.findings
            )
            if avg_finding_confidence < 0.7:
                confidence -= 0.1

        return round(max(0.5, min(1.0, confidence)), 2)

    def score_single_agent(
        self,
        agent: SecurityAgent,
        findings: list | None = None,
    ) -> AgentRiskProfile:
        """
        Score a single agent.

        Args:
            agent: Agent to score
            findings: Associated findings

        Returns:
            AgentRiskProfile for the agent
        """
        return self.agent_risk_scorer.score_agent(agent, None, findings)

    def compare_scores(
        self,
        result1: ATSSResult,
        result2: ATSSResult,
    ) -> dict[str, Any]:
        """
        Compare two ATSS results.

        Args:
            result1: First result
            result2: Second result

        Returns:
            Comparison metrics
        """
        return {
            "overall_change": round(result2.overall_score - result1.overall_score, 2),
            "grade_change": f"{result1.grade} -> {result2.grade}",
            "vulnerability_change": round(
                result2.vulnerability_score - result1.vulnerability_score, 2
            ),
            "trust_boundary_change": round(
                result2.trust_boundary_score - result1.trust_boundary_score, 2
            ),
            "communication_change": round(
                result2.communication_score - result1.communication_score, 2
            ),
            "agent_risk_change": round(result2.agent_risk_score - result1.agent_risk_score, 2),
            "improved": result2.overall_score > result1.overall_score,
        }


def calculate_atss(
    scan_result: SecurityScanResult,
    graph: AgentGraph | None = None,
) -> ATSSResult:
    """
    Convenience function to calculate ATSS.

    Args:
        scan_result: Security scan results
        graph: Optional topology graph

    Returns:
        ATSSResult
    """
    engine = SecurityScoringEngine()
    return engine.calculate_atss(scan_result, graph)
