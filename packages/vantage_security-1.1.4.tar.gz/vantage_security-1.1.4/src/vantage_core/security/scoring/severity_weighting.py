"""
Severity-Weighted Scoring Components for Vantage Security Scanner.

This module implements grade capping, exponential penalties, and confidence
intervals to address the "A grade with critical vulnerabilities" problem.

US-101: Automatic Grade Capping by Severity
US-102: Exponential Severity Penalty Calculation
US-103: Score Confidence Intervals
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

from vantage_core.security.models import SecurityFinding, Severity

# Grade hierarchy for comparison (higher index = better grade)
GRADE_ORDER = ["F", "D", "C", "B", "A"]


@dataclass
class GradeCapResult:
    """Result of grade capping evaluation."""

    original_grade: str
    capped_grade: str
    is_capped: bool
    cap_reason: str | None
    capping_severity: str | None
    capping_finding_ids: list[str] = field(default_factory=list)


class GradeCapEnforcer:
    """
    Enforces grade caps based on finding severity.

    Ensures that repositories with critical vulnerabilities never receive
    passing grades, addressing the core "A grade with critical findings" issue.
    """

    # Default severity caps per PRD requirements
    SEVERITY_CAPS: dict[Severity, str] = {
        Severity.CRITICAL: "F",  # Any critical = F
        Severity.HIGH: "D",  # Any high = D max
        Severity.MEDIUM: "C",  # Any medium = C max
    }

    def __init__(self, caps: dict[Severity, str] | None = None):
        """
        Initialize the grade cap enforcer.

        Args:
            caps: Custom severity-to-grade cap mapping
        """
        self.caps = caps if caps is not None else self.SEVERITY_CAPS

    def enforce_cap(
        self,
        calculated_grade: str,
        findings: list[SecurityFinding],
    ) -> str:
        """
        Apply severity-based grade capping.

        Args:
            calculated_grade: Grade computed from score calculation
            findings: All security findings from scan

        Returns:
            The final grade after applying caps (worst of calculated vs capped)
        """
        result = self.evaluate(calculated_grade, findings)
        return result.capped_grade

    def evaluate(
        self,
        calculated_grade: str,
        findings: list[SecurityFinding],
    ) -> GradeCapResult:
        """
        Evaluate if grade should be capped based on findings.

        Args:
            calculated_grade: Grade from score calculation
            findings: All findings from scan

        Returns:
            GradeCapResult with capping decision and details
        """
        if not findings:
            return GradeCapResult(
                original_grade=calculated_grade,
                capped_grade=calculated_grade,
                is_capped=False,
                cap_reason=None,
                capping_severity=None,
                capping_finding_ids=[],
            )

        # Find the worst cap based on findings
        worst_cap_grade = None
        worst_severity = None
        capping_finding_ids = []

        for finding in findings:
            severity = finding.severity
            if severity in self.caps:
                cap_grade = self.caps[severity]

                # Check if this is a worse (lower) cap than current worst
                if worst_cap_grade is None or self._is_worse_grade(cap_grade, worst_cap_grade):
                    worst_cap_grade = cap_grade
                    worst_severity = severity
                    capping_finding_ids = [finding.id]
                elif cap_grade == worst_cap_grade:
                    capping_finding_ids.append(finding.id)

        # If no findings warrant a cap, return original grade
        if worst_cap_grade is None:
            return GradeCapResult(
                original_grade=calculated_grade,
                capped_grade=calculated_grade,
                is_capped=False,
                cap_reason=None,
                capping_severity=None,
                capping_finding_ids=[],
            )

        # Determine final grade (worst of calculated vs capped)
        severity_name = worst_severity.value.upper() if worst_severity else "UNKNOWN"

        if (
            self._is_worse_grade(calculated_grade, worst_cap_grade)
            or calculated_grade == worst_cap_grade
        ):
            # Calculated grade is already at or worse than cap
            # Cap doesn't change the grade, so is_capped=False
            return GradeCapResult(
                original_grade=calculated_grade,
                capped_grade=calculated_grade,
                is_capped=False,
                cap_reason=None,
                capping_severity=None,
                capping_finding_ids=[],
            )

        # Cap is worse than calculated, apply it
        return GradeCapResult(
            original_grade=calculated_grade,
            capped_grade=worst_cap_grade,
            is_capped=True,
            cap_reason=f"Capped due to {severity_name} severity finding",
            capping_severity=severity_name,
            capping_finding_ids=capping_finding_ids,
        )

    def get_cap_for_severity(self, severity: Severity) -> str | None:
        """
        Get the maximum grade allowed for a severity level.

        Args:
            severity: The severity level to check

        Returns:
            Maximum grade allowed, or None if no cap
        """
        return self.caps.get(severity)

    def _is_worse_grade(self, grade1: str, grade2: str) -> bool:
        """
        Check if grade1 is worse (lower) than grade2.

        Args:
            grade1: First grade to compare
            grade2: Second grade to compare

        Returns:
            True if grade1 is worse than grade2
        """
        try:
            idx1 = GRADE_ORDER.index(grade1)
            idx2 = GRADE_ORDER.index(grade2)
            return idx1 < idx2
        except ValueError:
            # If grade not found, treat as worst
            return True


@dataclass
class PenaltyBreakdown:
    """Breakdown of penalties by severity."""

    total_penalty: float
    by_severity: dict[str, float]
    finding_count_by_severity: dict[str, int]
    adjusted_base_score: float
    penalty_details: list[dict[str, Any]] = field(default_factory=list)


class ExponentialPenaltyCalculator:
    """
    Calculates score penalties with diminishing returns.

    Uses exponential decay formula to apply penalties that have
    diminishing returns for multiple findings of the same severity.
    """

    # Default penalty weights per PRD
    BASE_PENALTIES: dict[Severity, float] = {
        Severity.CRITICAL: 100.0,  # First critical = -100
        Severity.HIGH: 25.0,  # First high = -25
        Severity.MEDIUM: 5.0,  # First medium = -5
        Severity.LOW: 1.0,
        Severity.INFO: 0.0,
    }

    # Decay factor for diminishing returns (used in formula: penalty * (1 - e^(-count/factor)))
    DEFAULT_DECAY_FACTOR = 3.0

    def __init__(
        self,
        weights: dict[Severity, float] | None = None,
        decay_factor: float = DEFAULT_DECAY_FACTOR,
    ):
        """
        Initialize penalty calculator.

        Args:
            weights: Custom penalty weights by severity
            decay_factor: Factor for diminishing returns formula
        """
        self.weights = weights if weights is not None else self.BASE_PENALTIES
        self.decay_factor = decay_factor

    def calculate_penalty(self, findings: list[SecurityFinding]) -> float:
        """
        Calculate total penalty with diminishing returns.

        Uses formula: base_penalty * (1 - e^(-count/decay_factor))
        This provides diminishing returns for multiple findings of same severity.

        Args:
            findings: List of security findings

        Returns:
            Total penalty to apply to score
        """
        breakdown = self.calculate(findings)
        return breakdown.total_penalty

    def calculate(
        self,
        findings: list[SecurityFinding],
        base_score: float = 100.0,
    ) -> PenaltyBreakdown:
        """
        Calculate total penalty from findings with full breakdown.

        Args:
            findings: Security findings
            base_score: Starting score (default 100)

        Returns:
            PenaltyBreakdown with deductions by severity
        """
        # Count findings by severity
        counts: dict[Severity, int] = {severity: 0 for severity in Severity}
        for finding in findings:
            counts[finding.severity] += 1

        # Calculate penalties per severity with diminishing returns
        penalties_by_severity: dict[str, float] = {}
        penalty_details: list[dict[str, Any]] = []
        total_penalty = 0.0

        for severity in Severity:
            count = counts[severity]
            if count == 0:
                penalties_by_severity[severity.value.upper()] = 0.0
                continue

            base_penalty = self.weights.get(severity, 0.0)

            # Apply diminishing returns formula
            # penalty = base * count gives linear scaling
            # penalty = base * (1 - e^(-count/factor)) gives diminishing returns
            # We scale by the base penalty for multiple findings
            penalty = self._apply_diminishing_returns(count, base_penalty)

            penalties_by_severity[severity.value.upper()] = round(penalty, 2)
            total_penalty += penalty

            if count > 0 and base_penalty > 0:
                penalty_details.append(
                    {
                        "severity": severity.value.upper(),
                        "count": count,
                        "base_penalty": base_penalty,
                        "applied_penalty": round(penalty, 2),
                    }
                )

        # Calculate adjusted score (floor at 0)
        adjusted_score = max(0.0, base_score - total_penalty)

        # Convert counts to string keys
        finding_counts = {severity.value.upper(): count for severity, count in counts.items()}

        return PenaltyBreakdown(
            total_penalty=round(total_penalty, 2),
            by_severity=penalties_by_severity,
            finding_count_by_severity=finding_counts,
            adjusted_base_score=round(adjusted_score, 2),
            penalty_details=penalty_details,
        )

    def _apply_diminishing_returns(
        self,
        count: int,
        base_penalty: float,
    ) -> float:
        """
        Apply diminishing returns for multiple findings of same severity.

        Uses formula: base_penalty * count * (1 - e^(-count/decay_factor)) / count
        Simplified: base_penalty * (1 - e^(-count/decay_factor)) * scaling

        For practical purposes, we use:
        base_penalty * (1 - e^(-count/decay_factor)) * max_multiplier

        Where max_multiplier caps the total penalty at a reasonable level.

        Args:
            count: Number of findings
            base_penalty: Base penalty for single finding

        Returns:
            Total penalty with diminishing returns applied
        """
        if count == 0:
            return 0.0

        # For first finding, apply full penalty
        if count == 1:
            return base_penalty

        # Use exponential saturation formula
        # This ensures penalties increase but with diminishing returns
        # max_penalty approaches base_penalty * max_multiplier as count -> infinity
        max_multiplier = 3.0  # Maximum penalty is 3x the base penalty

        # Formula: base * max_mult * (1 - e^(-count/factor))
        saturation = 1.0 - math.exp(-count / self.decay_factor)
        penalty = base_penalty * max_multiplier * saturation

        return penalty


@dataclass
class ConfidenceFactors:
    """Individual factors contributing to confidence."""

    code_coverage: float  # 0-1, lines scanned vs total
    rule_coverage: float  # 0-1, rules executed vs available
    file_type_coverage: float  # 0-1, file types analyzed vs present
    finding_confidence_avg: float  # Average confidence of findings


@dataclass
class ConfidenceInterval:
    """Score confidence interval."""

    score: float
    confidence: float  # 0-1 overall confidence
    lower_bound: float  # Score - uncertainty
    upper_bound: float  # Score + uncertainty
    factors: ConfidenceFactors
    warnings: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)


class ConfidenceIntervalCalculator:
    """
    Calculates confidence intervals for scores.

    Confidence decreases with fewer findings, lower coverage,
    and lower individual finding confidence scores.
    """

    # Weights for confidence factors
    FACTOR_WEIGHTS = {
        "code_coverage": 0.35,
        "rule_coverage": 0.30,
        "file_type_coverage": 0.20,
        "finding_confidence_avg": 0.15,
    }

    # Thresholds for warnings
    LOW_CONFIDENCE_THRESHOLD = 0.5
    WARNING_THRESHOLD = 0.8

    def __init__(self, factor_weights: dict[str, float] | None = None):
        """
        Initialize confidence calculator.

        Args:
            factor_weights: Custom weights for confidence factors
        """
        self.factor_weights = factor_weights or self.FACTOR_WEIGHTS

    def calculate(
        self,
        score: float,
        findings: list[SecurityFinding],
        coverage: float,
    ) -> tuple[float, float, float]:
        """
        Calculate confidence interval for a score.

        Simple interface returning (score, lower_bound, upper_bound).

        Args:
            score: Calculated security score
            findings: List of findings
            coverage: Code coverage ratio (0-1)

        Returns:
            Tuple of (score, lower_bound, upper_bound)
        """
        result = self.calculate_full(score, findings, coverage)
        return (result.score, result.lower_bound, result.upper_bound)

    def calculate_full(
        self,
        score: float,
        findings: list[SecurityFinding],
        coverage: float,
        scan_metadata: dict[str, Any] | None = None,
    ) -> ConfidenceInterval:
        """
        Calculate full confidence interval with factors.

        Args:
            score: Calculated security score
            findings: List of findings
            coverage: Code coverage ratio (0-1)
            scan_metadata: Additional scan metadata

        Returns:
            ConfidenceInterval with bounds and factors
        """
        metadata = scan_metadata or {}

        # Calculate individual confidence factors
        code_coverage = coverage
        rule_coverage = metadata.get("rule_coverage", 0.85)  # Default assumption
        file_type_coverage = metadata.get("file_type_coverage", 0.90)

        # Calculate average finding confidence
        if findings:
            finding_confidence_avg = sum(f.confidence for f in findings) / len(findings)
        else:
            # No findings - could mean clean code or incomplete scan
            # Lower confidence if coverage is also low
            finding_confidence_avg = 0.8 if coverage > 0.7 else 0.5

        factors = ConfidenceFactors(
            code_coverage=code_coverage,
            rule_coverage=rule_coverage,
            file_type_coverage=file_type_coverage,
            finding_confidence_avg=finding_confidence_avg,
        )

        # Calculate overall confidence as weighted average
        overall_confidence = (
            factors.code_coverage * self.factor_weights["code_coverage"]
            + factors.rule_coverage * self.factor_weights["rule_coverage"]
            + factors.file_type_coverage * self.factor_weights["file_type_coverage"]
            + factors.finding_confidence_avg * self.factor_weights["finding_confidence_avg"]
        )

        # Calculate uncertainty (inverse of confidence)
        uncertainty = (1.0 - overall_confidence) * 20  # Scale to reasonable range

        # Calculate bounds (ensure within 0-100)
        lower_bound = max(0.0, score - uncertainty)
        upper_bound = min(100.0, score + uncertainty)

        # Generate warnings and recommendations
        warnings = []
        recommendations = []

        if overall_confidence < self.LOW_CONFIDENCE_THRESHOLD:
            warnings.append(
                "Low confidence score - results may not reflect actual security posture"
            )
            recommendations.append("Increase code coverage to improve confidence")

        if code_coverage < 0.5:
            warnings.append("Limited code coverage")
            recommendations.append("Enable scanning for more file types")

        if finding_confidence_avg < 0.7 and findings:
            warnings.append("Low average finding confidence")
            recommendations.append("Review low-confidence findings manually")

        if not findings and coverage < 0.5:
            warnings.append("No findings with low coverage may indicate incomplete scan")
            recommendations.append("Verify scan configuration and coverage")

        return ConfidenceInterval(
            score=score,
            confidence=round(overall_confidence, 2),
            lower_bound=round(lower_bound, 2),
            upper_bound=round(upper_bound, 2),
            factors=factors,
            warnings=warnings,
            recommendations=recommendations,
        )
