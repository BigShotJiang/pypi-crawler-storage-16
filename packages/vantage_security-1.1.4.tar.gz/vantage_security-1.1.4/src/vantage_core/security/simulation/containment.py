"""
Containment Analysis (US-131).

Identifies natural firewall points and suggests containment
strategies to minimize infection spread.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from vantage_core.security.simulation.propagation import (
    InfectionSimulator,
    SimulationConfig,
)
from vantage_core.security.topology.graph import AgentGraph, GraphNode


class ContainmentType(str, Enum):
    """Types of containment strategies."""

    FIREWALL = "firewall"  # Block all incoming
    FILTER = "filter"  # Filter suspicious content
    RATE_LIMIT = "rate_limit"  # Limit message frequency
    ISOLATION = "isolation"  # Complete isolation
    MONITORING = "monitoring"  # Alert but don't block


@dataclass
class ContainmentPoint:
    """
    A recommended containment point in the topology.

    Contains the agent, strategy, and impact assessment.
    """

    agent_id: str
    agent_name: str
    containment_type: ContainmentType
    effectiveness: float  # 0-100, expected reduction
    blast_reduction: int  # Agents saved
    effort: str  # low, medium, high
    rationale: str
    dependencies: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def priority(self) -> str:
        """Calculate implementation priority."""
        if self.effectiveness >= 80:
            return "critical"
        elif self.effectiveness >= 60:
            return "high"
        elif self.effectiveness >= 40:
            return "medium"
        else:
            return "low"


@dataclass
class ContainmentStrategy:
    """
    Complete containment strategy for a topology.

    Contains recommended containment points and expected impact.
    """

    containment_points: list[ContainmentPoint]
    total_effectiveness: float  # Overall expected reduction
    estimated_blast_reduction: int
    implementation_order: list[str]  # Recommended order
    summary: str
    metadata: dict[str, Any] = field(default_factory=dict)


class ContainmentAnalyzer:
    """
    Analyzes topology for containment opportunities.

    Identifies natural firewall points, articulation points,
    and optimal containment strategies.
    """

    def __init__(
        self,
        simulation_config: SimulationConfig | None = None,
    ):
        """
        Initialize the analyzer.

        Args:
            simulation_config: Configuration for simulations
        """
        self.config = simulation_config or SimulationConfig()
        self.simulator = InfectionSimulator(self.config)

    def analyze(
        self,
        graph: AgentGraph,
        entry_points: list[str] | None = None,
    ) -> ContainmentStrategy:
        """
        Analyze topology for containment opportunities.

        Args:
            graph: Agent topology graph
            entry_points: Optional list of entry point IDs

        Returns:
            ContainmentStrategy with recommendations
        """
        containment_points = []

        # 1. Find articulation points (removing disconnects graph)
        articulation = graph.get_articulation_points()
        for ap_id in articulation:
            node = graph.get_node(ap_id)
            if node:
                point = self._create_containment_point(
                    node,
                    ContainmentType.FIREWALL,
                    effectiveness=85.0,
                    rationale="Single point of failure - blocking here segments the graph",
                    effort="medium",
                )
                containment_points.append(point)

        # 2. Find hub nodes (high centrality)
        hubs = graph.get_hub_nodes(threshold=3)
        for hub in hubs:
            if hub.id not in articulation:  # Avoid duplicates
                point = self._create_containment_point(
                    hub,
                    ContainmentType.FILTER,
                    effectiveness=70.0,
                    rationale="Hub node - filtering here reduces spread to many agents",
                    effort="medium",
                )
                containment_points.append(point)

        # 3. Find trust boundary crossings
        boundary_edges = graph.get_trust_boundary_edges()
        boundary_targets = set()
        for edge in boundary_edges:
            if edge.trust_differential < 0:  # Going to higher trust
                boundary_targets.add(edge.target_id)

        for target_id in boundary_targets:
            if target_id not in articulation and target_id not in [h.id for h in hubs]:
                node = graph.get_node(target_id)
                if node:
                    point = self._create_containment_point(
                        node,
                        ContainmentType.FILTER,
                        effectiveness=60.0,
                        rationale="Trust boundary - validate inputs from lower trust",
                        effort="low",
                    )
                    containment_points.append(point)

        # 4. Find high-risk nodes
        high_risk = graph.get_high_risk_nodes()
        for node in high_risk:
            if (
                node.id not in articulation
                and node.id not in [h.id for h in hubs]
                and node.id not in boundary_targets
            ):
                point = self._create_containment_point(
                    node,
                    ContainmentType.ISOLATION,
                    effectiveness=75.0,
                    rationale="High-risk capabilities - isolate to prevent lateral movement",
                    effort="high",
                )
                containment_points.append(point)

        # Validate containment effectiveness through simulation
        if entry_points and containment_points:
            containment_points = self._validate_effectiveness(
                graph,
                entry_points,
                containment_points,
            )

        # Sort by effectiveness
        containment_points.sort(key=lambda p: p.effectiveness, reverse=True)

        # Calculate total effectiveness
        if containment_points:
            # Diminishing returns: each additional point less effective
            total_eff = 0.0
            remaining = 100.0
            for point in containment_points:
                contribution = (point.effectiveness / 100) * remaining * 0.8
                total_eff += contribution
                remaining -= contribution
            total_effectiveness = min(95, total_eff)
        else:
            total_effectiveness = 0.0

        # Estimated blast reduction
        estimated_reduction = int(graph.node_count * (total_effectiveness / 100))

        # Implementation order
        implementation_order = [p.agent_id for p in containment_points[:5]]

        # Generate summary
        summary = self._generate_summary(containment_points, total_effectiveness)

        return ContainmentStrategy(
            containment_points=containment_points,
            total_effectiveness=round(total_effectiveness, 2),
            estimated_blast_reduction=estimated_reduction,
            implementation_order=implementation_order,
            summary=summary,
            metadata={
                "total_points": len(containment_points),
                "graph_size": graph.node_count,
            },
        )

    def find_optimal_cut(
        self,
        graph: AgentGraph,
        entry_point: str,
        max_cut_size: int = 3,
    ) -> list[str]:
        """
        Find optimal agents to contain to minimize spread.

        Args:
            graph: Agent topology graph
            entry_point: Entry point to protect against
            max_cut_size: Maximum number of containment points

        Returns:
            List of agent IDs for optimal containment
        """
        # Get baseline blast radius
        baseline_result = self.simulator.simulate(graph, entry_point)
        baseline_blast = baseline_result.blast_radius

        # Try each articulation point first
        best_cut = []
        best_reduction = 0

        candidates = graph.get_articulation_points() + [n.id for n in graph.get_hub_nodes()]
        candidates = list(set(candidates))  # Dedupe

        for candidate in candidates:
            if candidate == entry_point:
                continue

            # Simulate with containment
            config = SimulationConfig(
                containment_enabled=True,
                containment_nodes=[candidate],
                transmission_rate=self.config.transmission_rate,
            )
            simulator = InfectionSimulator(config)
            result = simulator.simulate(graph, entry_point)

            reduction = baseline_blast - result.blast_radius
            if reduction > best_reduction:
                best_reduction = reduction
                best_cut = [candidate]

        # Try combinations for larger cuts
        if max_cut_size > 1 and len(candidates) > 1:
            for i, c1 in enumerate(candidates):
                for c2 in candidates[i + 1 :]:
                    if c1 == entry_point or c2 == entry_point:
                        continue

                    config = SimulationConfig(
                        containment_enabled=True,
                        containment_nodes=[c1, c2],
                        transmission_rate=self.config.transmission_rate,
                    )
                    simulator = InfectionSimulator(config)
                    result = simulator.simulate(graph, entry_point)

                    reduction = baseline_blast - result.blast_radius
                    if reduction > best_reduction:
                        best_reduction = reduction
                        best_cut = [c1, c2]

        return best_cut[:max_cut_size]

    def _create_containment_point(
        self,
        node: GraphNode,
        containment_type: ContainmentType,
        effectiveness: float,
        rationale: str,
        effort: str,
    ) -> ContainmentPoint:
        """Create a ContainmentPoint object."""
        # Adjust effectiveness based on node characteristics
        if node.has_code_execution:
            effectiveness = min(100, effectiveness + 5)
        if node.trust_level.value >= 3:  # PRIVILEGED or SYSTEM
            effectiveness = min(100, effectiveness + 10)

        return ContainmentPoint(
            agent_id=node.id,
            agent_name=node.name,
            containment_type=containment_type,
            effectiveness=round(effectiveness, 2),
            blast_reduction=0,  # Calculated later
            effort=effort,
            rationale=rationale,
            metadata={
                "trust_level": node.trust_level.name,
                "in_degree": node.in_degree,
                "out_degree": node.out_degree,
            },
        )

    def _validate_effectiveness(
        self,
        graph: AgentGraph,
        entry_points: list[str],
        containment_points: list[ContainmentPoint],
    ) -> list[ContainmentPoint]:
        """Validate and update effectiveness through simulation."""
        # Get baseline (no containment)
        total_baseline = 0
        for entry in entry_points:
            try:
                result = self.simulator.simulate(graph, entry)
                total_baseline += result.blast_radius
            except Exception:
                continue

        # Test each containment point
        for point in containment_points:
            total_with_containment = 0

            config = SimulationConfig(
                containment_enabled=True,
                containment_nodes=[point.agent_id],
                transmission_rate=self.config.transmission_rate,
            )
            simulator = InfectionSimulator(config)

            for entry in entry_points:
                try:
                    result = simulator.simulate(graph, entry)
                    total_with_containment += result.blast_radius
                except Exception:
                    continue

            # Calculate actual reduction
            if total_baseline > 0:
                reduction = total_baseline - total_with_containment
                point.blast_reduction = reduction
                # Update effectiveness based on actual simulation
                actual_effectiveness = (reduction / total_baseline) * 100
                point.effectiveness = round((point.effectiveness + actual_effectiveness) / 2, 2)

        return containment_points

    def _generate_summary(
        self,
        points: list[ContainmentPoint],
        effectiveness: float,
    ) -> str:
        """Generate summary of containment strategy."""
        if not points:
            return (
                "No containment points identified. Consider adding intermediate validation agents."
            )

        critical = [p for p in points if p.priority == "critical"]
        high = [p for p in points if p.priority == "high"]

        summary = f"Identified {len(points)} containment point(s) "

        if critical:
            summary += f"including {len(critical)} critical point(s). "
        if high:
            summary += f"and {len(high)} high-priority point(s). "

        summary += f"Expected blast radius reduction: {effectiveness:.1f}%. "
        summary += f"Start with: {points[0].agent_name}."

        return summary


def analyze_containment(
    graph: AgentGraph,
    entry_points: list[str] | None = None,
) -> ContainmentStrategy:
    """
    Convenience function to analyze containment.

    Args:
        graph: Agent topology graph
        entry_points: Optional entry point IDs

    Returns:
        ContainmentStrategy
    """
    analyzer = ContainmentAnalyzer()
    return analyzer.analyze(graph, entry_points)
