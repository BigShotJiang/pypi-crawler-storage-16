"""
Propagation Model (US-129).

Simulates infection spread through the agent topology using
an SIR-like model (Susceptible/Exposed/Infected/Contained).
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from vantage_core.security.models import TrustLevel
from vantage_core.security.topology.graph import AgentGraph, GraphNode


class InfectionState(str, Enum):
    """Agent infection states."""

    SUSCEPTIBLE = "susceptible"  # Not yet infected
    EXPOSED = "exposed"  # Received infection, not yet propagating
    INFECTED = "infected"  # Actively infected and spreading
    CONTAINED = "contained"  # Infection stopped


@dataclass
class AgentState:
    """
    State of an agent during simulation.

    Tracks infection state, time of infection, and source.
    """

    agent_id: str
    state: InfectionState
    infected_at: int = -1  # Time step of infection (-1 = not infected)
    infected_by: str | None = None  # Source agent
    exposure_count: int = 0  # Number of exposure attempts
    containment_active: bool = False


@dataclass
class SimulationConfig:
    """
    Configuration for infection simulation.

    Controls transmission probabilities, timing, and containment.
    """

    transmission_rate: float = 0.7  # Base probability of transmission
    exposure_duration: int = 1  # Steps before exposed becomes infected
    containment_enabled: bool = False  # Whether containment is active
    containment_nodes: list[str] = field(default_factory=list)
    max_steps: int = 100


@dataclass
class SimulationResult:
    """
    Result of an infection simulation.

    Contains the full timeline, metrics, and analysis.
    """

    entry_point: str
    time_steps: list[dict[str, AgentState]]  # State at each step
    total_steps: int
    blast_radius: int  # Total infected
    peak_infection: int  # Max simultaneous infected
    peak_step: int  # Step with peak infection
    containment_points: list[str]  # Nodes that stopped spread
    infection_paths: list[list[str]]  # Paths taken by infection
    final_states: dict[str, InfectionState]
    metrics: dict[str, Any] = field(default_factory=dict)


class InfectionSimulator:
    """
    Simulates infection propagation through agent topology.

    Uses a modified SEIR model adapted for prompt infections
    with graph-based transmission.
    """

    def __init__(
        self,
        config: SimulationConfig | None = None,
    ):
        """
        Initialize the simulator.

        Args:
            config: Simulation configuration
        """
        self.config = config or SimulationConfig()

    def simulate(
        self,
        graph: AgentGraph,
        entry_point: str,
        max_steps: int | None = None,
    ) -> SimulationResult:
        """
        Simulate infection from an entry point.

        Args:
            graph: Agent topology graph
            entry_point: Starting agent ID
            max_steps: Override max simulation steps

        Returns:
            SimulationResult with full simulation data
        """
        max_steps = max_steps or self.config.max_steps

        # Validate entry point
        if graph.get_node(entry_point) is None:
            raise ValueError(f"Entry point {entry_point} not found in graph")

        # Initialize states
        states = self._initialize_states(graph)

        # Infect entry point
        states[entry_point].state = InfectionState.INFECTED
        states[entry_point].infected_at = 0

        # Track time steps
        time_steps = []
        infection_paths = [[entry_point]]
        peak_infection = 1
        peak_step = 0
        containment_points = []

        # Run simulation
        for step in range(1, max_steps + 1):
            # Get currently infected agents
            infected = [
                agent_id
                for agent_id, state in states.items()
                if state.state == InfectionState.INFECTED
            ]

            if not infected:
                # No more infections to spread
                break

            # Track current state
            time_steps.append(
                {
                    agent_id: AgentState(
                        agent_id=state.agent_id,
                        state=state.state,
                        infected_at=state.infected_at,
                        infected_by=state.infected_by,
                    )
                    for agent_id, state in states.items()
                }
            )

            # Try to spread from each infected agent
            newly_infected = []
            for agent_id in infected:
                neighbors = graph.get_neighbors(agent_id)

                for neighbor_id in neighbors:
                    neighbor_state = states[neighbor_id]

                    # Skip if not susceptible
                    if neighbor_state.state != InfectionState.SUSCEPTIBLE:
                        continue

                    # Check for containment
                    if self._is_contained(neighbor_id):
                        if neighbor_id not in containment_points:
                            containment_points.append(neighbor_id)
                        states[neighbor_id].state = InfectionState.CONTAINED
                        continue

                    # Calculate transmission probability
                    prob = self._calculate_transmission_probability(
                        graph.get_node(agent_id),
                        graph.get_node(neighbor_id),
                        graph.get_edge(agent_id, neighbor_id),
                    )

                    # Deterministic for reproducibility: infect if prob > 0.5
                    if prob >= 0.5:
                        states[neighbor_id].state = InfectionState.EXPOSED
                        states[neighbor_id].infected_at = step
                        states[neighbor_id].infected_by = agent_id
                        newly_infected.append(neighbor_id)

                        # Track path
                        for path in infection_paths:
                            if path[-1] == agent_id:
                                new_path = path + [neighbor_id]
                                infection_paths.append(new_path)
                                break

            # Progress exposed to infected
            for agent_id, state in states.items():
                if state.state == InfectionState.EXPOSED:
                    if step - state.infected_at >= self.config.exposure_duration:
                        states[agent_id].state = InfectionState.INFECTED

            # Update peak
            current_infected = sum(
                1
                for s in states.values()
                if s.state in [InfectionState.INFECTED, InfectionState.EXPOSED]
            )
            if current_infected > peak_infection:
                peak_infection = current_infected
                peak_step = step

        # Final state snapshot
        time_steps.append(
            {
                agent_id: AgentState(
                    agent_id=state.agent_id,
                    state=state.state,
                    infected_at=state.infected_at,
                    infected_by=state.infected_by,
                )
                for agent_id, state in states.items()
            }
        )

        # Calculate blast radius
        blast_radius = sum(
            1
            for s in states.values()
            if s.state in [InfectionState.INFECTED, InfectionState.EXPOSED]
        )

        # Build final states map
        final_states = {agent_id: state.state for agent_id, state in states.items()}

        # Build metrics
        metrics = {
            "transmission_rate": self.config.transmission_rate,
            "total_agents": len(states),
            "susceptible_remaining": sum(
                1 for s in states.values() if s.state == InfectionState.SUSCEPTIBLE
            ),
            "contained": sum(1 for s in states.values() if s.state == InfectionState.CONTAINED),
            "infection_rate": blast_radius / len(states) if states else 0,
        }

        return SimulationResult(
            entry_point=entry_point,
            time_steps=time_steps,
            total_steps=len(time_steps),
            blast_radius=blast_radius,
            peak_infection=peak_infection,
            peak_step=peak_step,
            containment_points=containment_points,
            infection_paths=infection_paths,
            final_states=final_states,
            metrics=metrics,
        )

    def simulate_all_entry_points(
        self,
        graph: AgentGraph,
        entry_points: list[str],
    ) -> dict[str, SimulationResult]:
        """
        Simulate from all entry points.

        Args:
            graph: Agent topology graph
            entry_points: List of entry point agent IDs

        Returns:
            Dictionary of entry_point -> SimulationResult
        """
        results = {}
        for entry in entry_points:
            results[entry] = self.simulate(graph, entry)
        return results

    def _initialize_states(self, graph: AgentGraph) -> dict[str, AgentState]:
        """Initialize all agents as susceptible."""
        return {
            node.id: AgentState(
                agent_id=node.id,
                state=InfectionState.SUSCEPTIBLE,
            )
            for node in graph.nodes
        }

    def _is_contained(self, agent_id: str) -> bool:
        """Check if agent is a containment point."""
        if not self.config.containment_enabled:
            return False
        return agent_id in self.config.containment_nodes

    def _calculate_transmission_probability(
        self,
        source: GraphNode | None,
        target: GraphNode | None,
        edge: Any | None,
    ) -> float:
        """Calculate probability of transmission."""
        if not source or not target:
            return 0.0

        prob = self.config.transmission_rate

        # Reduce for higher trust targets (better defenses)
        trust_factor = {
            TrustLevel.EXTERNAL: 1.0,
            TrustLevel.USER: 0.95,
            TrustLevel.INTERNAL: 0.85,
            TrustLevel.PRIVILEGED: 0.7,
            TrustLevel.SYSTEM: 0.5,
        }
        prob *= trust_factor.get(target.trust_level, 0.85)

        # Increase for trust boundary crossings
        if edge and hasattr(edge, "trust_differential"):
            if edge.trust_differential < 0:  # Going to higher trust
                prob *= 0.9  # Slightly harder
            elif edge.trust_differential > 0:  # Going to lower trust
                prob *= 1.1  # Slightly easier

        # Reduce if target has code execution (assumed to have sandboxing)
        if target.has_code_execution:
            prob *= 0.8

        return min(1.0, max(0.0, prob))


def simulate_infection(
    graph: AgentGraph,
    entry_point: str,
    max_steps: int = 100,
) -> SimulationResult:
    """
    Convenience function to simulate infection.

    Args:
        graph: Agent topology graph
        entry_point: Starting agent ID
        max_steps: Maximum simulation steps

    Returns:
        SimulationResult
    """
    simulator = InfectionSimulator()
    return simulator.simulate(graph, entry_point, max_steps)
