"""
Verification pipeline that integrates secret verification with the detection pipeline.

This module provides the async pipeline for verifying detected secrets against
provider APIs, with caching, batching, and audit logging.
"""

import asyncio
import hashlib
import logging
import time
from dataclasses import dataclass
from typing import Any

from vantage_core.security.models import SecurityFinding, Severity

from .providers import (
    AWSVerifier,
    GitHubVerifier,
    OpenAIVerifier,
    SlackVerifier,
    StripeVerifier,
)
from .verifier import SecretVerifier, VerificationResult, VerificationStatus

logger = logging.getLogger(__name__)


@dataclass
class VerificationConfig:
    """Configuration for the verification pipeline."""

    # Enable/disable verification
    enabled: bool = True

    # Concurrency limits
    max_concurrent: int = 10

    # Caching
    cache_enabled: bool = True
    cache_ttl_seconds: int = 3600  # 1 hour

    # Filtering based on verification
    filter_invalid: bool = True  # Remove invalid secrets from results
    adjust_severity_on_verified: bool = True  # Boost severity for verified secrets

    # Audit logging
    audit_log_enabled: bool = True

    # Skip verification for certain contexts
    skip_test_files: bool = True
    skip_placeholder_secrets: bool = True


@dataclass
class EnhancedSecretFinding:
    """Security finding enhanced with verification results."""

    finding: SecurityFinding
    verification_result: VerificationResult | None
    original_severity: Severity
    adjusted_severity: Severity
    is_verified_active: bool
    should_filter: bool
    filter_reason: str | None


class VerificationCache:
    """
    In-memory cache for verification results.

    Caches results by secret hash to avoid duplicate API calls.
    """

    def __init__(self, ttl_seconds: int = 3600):
        self._cache: dict[str, tuple[VerificationResult, float]] = {}
        self._ttl = ttl_seconds
        self._lock = asyncio.Lock()

    async def get(self, secret_hash: str) -> VerificationResult | None:
        """Get cached result if not expired."""
        async with self._lock:
            if secret_hash in self._cache:
                result, timestamp = self._cache[secret_hash]
                if time.time() - timestamp < self._ttl:
                    return result
                else:
                    del self._cache[secret_hash]
            return None

    async def set(self, secret_hash: str, result: VerificationResult):
        """Cache a verification result."""
        async with self._lock:
            self._cache[secret_hash] = (result, time.time())

    async def clear_expired(self):
        """Remove expired entries."""
        async with self._lock:
            now = time.time()
            expired = [k for k, (_, ts) in self._cache.items() if now - ts >= self._ttl]
            for k in expired:
                del self._cache[k]


class VerificationPipeline:
    """
    Pipeline for verifying secrets and enhancing findings.

    Integrates with the secret detection pipeline to:
    1. Verify detected secrets against provider APIs
    2. Filter out invalid/expired secrets
    3. Boost severity for confirmed active secrets
    4. Provide audit logging for compliance
    """

    # Severity boost for verified active secrets
    SEVERITY_BOOST = {
        Severity.INFO: Severity.LOW,
        Severity.LOW: Severity.MEDIUM,
        Severity.MEDIUM: Severity.HIGH,
        Severity.HIGH: Severity.CRITICAL,
        Severity.CRITICAL: Severity.CRITICAL,
    }

    def __init__(self, config: VerificationConfig | None = None):
        """Initialize verification pipeline."""
        self.config = config or VerificationConfig()
        self.verifier = SecretVerifier()
        self.cache = VerificationCache(self.config.cache_ttl_seconds)

        # Register default verifiers
        self._register_default_verifiers()

    def _register_default_verifiers(self):
        """Register the default provider verifiers."""
        self.verifier.register_verifier(AWSVerifier())
        self.verifier.register_verifier(GitHubVerifier())
        self.verifier.register_verifier(SlackVerifier())
        self.verifier.register_verifier(StripeVerifier())
        self.verifier.register_verifier(OpenAIVerifier())

    async def verify_finding(
        self,
        finding: SecurityFinding,
    ) -> EnhancedSecretFinding:
        """
        Verify a single finding and enhance it.

        Args:
            finding: Security finding to verify

        Returns:
            EnhancedSecretFinding with verification results
        """
        original_severity = finding.severity
        adjusted_severity = original_severity
        should_filter = False
        filter_reason = None
        verification_result = None
        is_verified_active = False

        # Extract secret value
        secret_value = self._extract_secret(finding)

        if not secret_value:
            return EnhancedSecretFinding(
                finding=finding,
                verification_result=None,
                original_severity=original_severity,
                adjusted_severity=adjusted_severity,
                is_verified_active=False,
                should_filter=False,
                filter_reason="Could not extract secret value",
            )

        # Check if we should skip verification
        if self._should_skip(finding, secret_value):
            return EnhancedSecretFinding(
                finding=finding,
                verification_result=None,
                original_severity=original_severity,
                adjusted_severity=adjusted_severity,
                is_verified_active=False,
                should_filter=False,
                filter_reason="Verification skipped",
            )

        # Check cache first
        secret_hash = hashlib.sha256(secret_value.encode()).hexdigest()
        cached_result = await self.cache.get(secret_hash)

        if cached_result:
            verification_result = cached_result
        else:
            # Perform verification
            verification_result = await self.verifier.verify(secret_value)

            # Cache the result
            if self.config.cache_enabled:
                await self.cache.set(secret_hash, verification_result)

        # Determine actions based on verification result
        if verification_result.status == VerificationStatus.VERIFIED:
            is_verified_active = True

            # Boost severity for verified active secrets
            if self.config.adjust_severity_on_verified:
                adjusted_severity = self.SEVERITY_BOOST.get(original_severity, original_severity)

        elif verification_result.status == VerificationStatus.INVALID:
            # Filter out invalid secrets
            if self.config.filter_invalid:
                should_filter = True
                filter_reason = f"Secret is invalid/expired: {verification_result.error}"

        # Log audit event
        if self.config.audit_log_enabled:
            self._log_audit_event(finding, verification_result)

        return EnhancedSecretFinding(
            finding=finding,
            verification_result=verification_result,
            original_severity=original_severity,
            adjusted_severity=adjusted_severity,
            is_verified_active=is_verified_active,
            should_filter=should_filter,
            filter_reason=filter_reason,
        )

    async def verify_findings(
        self,
        findings: list[SecurityFinding],
    ) -> list[EnhancedSecretFinding]:
        """
        Verify multiple findings concurrently.

        Args:
            findings: List of findings to verify

        Returns:
            List of enhanced findings
        """
        if not self.config.enabled:
            return [
                EnhancedSecretFinding(
                    finding=f,
                    verification_result=None,
                    original_severity=f.severity,
                    adjusted_severity=f.severity,
                    is_verified_active=False,
                    should_filter=False,
                    filter_reason="Verification disabled",
                )
                for f in findings
            ]

        semaphore = asyncio.Semaphore(self.config.max_concurrent)

        async def verify_with_semaphore(finding: SecurityFinding):
            async with semaphore:
                return await self.verify_finding(finding)

        tasks = [verify_with_semaphore(f) for f in findings]
        return await asyncio.gather(*tasks)

    async def filter_verified_findings(
        self,
        findings: list[SecurityFinding],
    ) -> list[SecurityFinding]:
        """
        Verify findings and return only those that pass verification.

        Args:
            findings: List of findings to process

        Returns:
            Filtered list with severities adjusted
        """
        enhanced = await self.verify_findings(findings)

        results = []
        for ef in enhanced:
            if ef.should_filter:
                logger.debug(f"Filtered finding {ef.finding.id}: {ef.filter_reason}")
                continue

            # Apply severity adjustment
            ef.finding.severity = ef.adjusted_severity

            # Add verification metadata
            if ef.verification_result:
                ef.finding.metadata["verification_status"] = ef.verification_result.status.value
                ef.finding.metadata["is_verified_active"] = ef.is_verified_active
                if ef.verification_result.account_info:
                    ef.finding.metadata["provider_account"] = ef.verification_result.account_info

            results.append(ef.finding)

        return results

    def _extract_secret(self, finding: SecurityFinding) -> str | None:
        """Extract secret value from finding."""
        # Check metadata
        if "secret_value" in finding.metadata:
            return finding.metadata["secret_value"]
        if "value" in finding.metadata:
            return finding.metadata["value"]

        # Extract from code snippet
        import re

        code = finding.code_snippet

        patterns = [
            r"['\"]([^'\"]{20,})['\"]",
            r"=\s*([^\s;,\"']{20,})",
        ]

        for pattern in patterns:
            matches = re.findall(pattern, code)
            if matches:
                return max(matches, key=len)

        return None

    def _should_skip(
        self,
        finding: SecurityFinding,
        secret_value: str,
    ) -> bool:
        """Check if verification should be skipped for this finding."""
        # Skip test files
        if self.config.skip_test_files:
            file_path = finding.file_path.lower()
            if any(p in file_path for p in ["test", "spec", "mock", "fixture"]):
                return True

        # Skip placeholder secrets
        if self.config.skip_placeholder_secrets:
            placeholders = [
                "your_",
                "my_",
                "example",
                "test",
                "fake",
                "dummy",
                "replace",
                "change",
                "insert",
                "xxx",
                "todo",
            ]
            secret_lower = secret_value.lower()
            if any(p in secret_lower for p in placeholders):
                return True

        return False

    def _log_audit_event(
        self,
        finding: SecurityFinding,
        result: VerificationResult,
    ):
        """Log verification event for audit trail."""
        audit_entry = result.to_audit_log()
        audit_entry["finding_id"] = finding.id
        audit_entry["file_path"] = finding.file_path
        audit_entry["line_number"] = finding.line_number

        logger.info(f"Secret verification: {audit_entry}")

    def get_statistics(
        self,
        enhanced_findings: list[EnhancedSecretFinding],
    ) -> dict[str, Any]:
        """
        Get statistics about verification results.

        Args:
            enhanced_findings: List of enhanced findings

        Returns:
            Statistics dictionary
        """
        stats = {
            "total": len(enhanced_findings),
            "verified_active": 0,
            "verified_invalid": 0,
            "verification_unknown": 0,
            "verification_skipped": 0,
            "filtered": 0,
            "severity_boosted": 0,
            "by_provider": {},
        }

        for ef in enhanced_findings:
            if ef.verification_result is None:
                stats["verification_skipped"] += 1
                continue

            provider = ef.verification_result.provider
            if provider not in stats["by_provider"]:
                stats["by_provider"][provider] = {
                    "verified": 0,
                    "invalid": 0,
                    "unknown": 0,
                }

            if ef.verification_result.status == VerificationStatus.VERIFIED:
                stats["verified_active"] += 1
                stats["by_provider"][provider]["verified"] += 1
            elif ef.verification_result.status == VerificationStatus.INVALID:
                stats["verified_invalid"] += 1
                stats["by_provider"][provider]["invalid"] += 1
            else:
                stats["verification_unknown"] += 1
                stats["by_provider"][provider]["unknown"] += 1

            if ef.should_filter:
                stats["filtered"] += 1

            if ef.adjusted_severity != ef.original_severity:
                stats["severity_boosted"] += 1

        return stats


def create_default_pipeline() -> VerificationPipeline:
    """Create a pipeline with default configuration."""
    return VerificationPipeline(VerificationConfig())
