"""Lazy loaders for CLI command groups and shared data loaders.

This module provides:
- Lazy loading of command groups to improve CLI startup time
- Shared data loaders for agent system files
"""

from __future__ import annotations

import json
from pathlib import Path

import typer

from vantage_cli.output import console
from vantage_cli.utils import (
    ExitCode,
    file_not_found_error,
    json_parse_error,
    permission_error,
)

# =============================================================================
# Data Loaders
# =============================================================================


def load_agent_system(path: Path):
    """Load an agent system from a JSON file.

    Args:
        path: Path to the JSON file

    Returns:
        Loaded AgentSystem

    Raises:
        typer.Exit: On file or parse errors
    """
    from vantage_core.exceptions import parse_json_error

    if not path.exists():
        file_not_found_error(str(path))

    try:
        with open(path) as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        error = parse_json_error(e, str(path))
        json_parse_error(str(path), str(error), getattr(e, "lineno", None))
    except PermissionError:
        permission_error(str(path))
    except Exception as e:
        console.error(f"Error reading file: {e}")
        raise typer.Exit(ExitCode.GENERAL_ERROR)

    return _parse_agent_system(data)


def _parse_agent_system(data: dict):
    """Parse agent system from dictionary data."""
    from vantage_core.core.models import (
        Agent,
        AgentSystem,
        Connection,
        HandoffPattern,
        Prompt,
        Topology,
    )

    agents = {}

    for agent_data in data.get("agents", []):
        prompt_data = agent_data.get("prompt", {})
        if isinstance(prompt_data, str):
            prompt = Prompt(content=prompt_data)
        else:
            prompt = Prompt(**prompt_data)

        agent = Agent(
            id=agent_data["id"],
            name=agent_data.get("name", agent_data["id"]),
            description=agent_data.get("description", ""),
            prompt=prompt,
            model=agent_data.get("model", "gpt-4"),
            temperature=agent_data.get("temperature", 0.7),
            max_tokens=agent_data.get("max_tokens", 4096),
        )
        agents[agent.id] = agent

    # Parse topology
    topology_data = data.get("topology", {})
    connections = []

    for conn in topology_data.get("connections", []):
        connections.append(
            Connection(
                source=conn["source"],
                target=conn["target"],
                pattern=HandoffPattern(conn.get("pattern", "sequential")),
                condition=conn.get("condition"),
                data_passed=conn.get("data_passed", []),
            )
        )

    topology = Topology(
        connections=connections,
        entry_points=topology_data.get("entry_points", []),
        exit_points=topology_data.get("exit_points", []),
    )

    # Update agent relationships
    for conn in connections:
        if conn.source in agents:
            agents[conn.source].can_delegate_to.append(conn.target)
        if conn.target in agents:
            agents[conn.target].receives_from.append(conn.source)

    return AgentSystem(
        name=data.get("name", "Unnamed System"),
        description=data.get("description", ""),
        agents=agents,
        topology=topology,
        version=data.get("version", "1.0.0"),
        metadata=data.get("metadata", {}),
    )


def load_prompt_file(path: Path) -> str:
    """Load a prompt from a text file.

    Args:
        path: Path to the prompt file

    Returns:
        Prompt content as string

    Raises:
        typer.Exit: On file errors
    """
    if not path.exists():
        file_not_found_error(str(path))

    try:
        return path.read_text()
    except PermissionError:
        permission_error(str(path))
    except Exception as e:
        console.error(f"Error reading file: {e}")
        raise typer.Exit(ExitCode.GENERAL_ERROR)


# =============================================================================
# Command Group Loaders
# =============================================================================


def load_scan_commands() -> typer.Typer:
    """Load scan command group."""
    from vantage_cli.commands.scan import scan_app

    return scan_app


def load_security_commands() -> typer.Typer:
    """Load security command group."""
    from vantage_cli.commands.security import security_app

    return security_app


def load_health_commands() -> typer.Typer:
    """Load health command group."""
    from vantage_cli.commands.health import health_app

    return health_app


def load_verify_commands() -> typer.Typer:
    """Load verify command group."""
    from vantage_cli.commands.verify import verify_app

    return verify_app


def load_compliance_commands() -> typer.Typer:
    """Load compliance command group."""
    from vantage_cli.commands.compliance import compliance_app

    return compliance_app


def load_dashboard_commands() -> typer.Typer:
    """Load dashboard command group."""
    from vantage_cli.commands.dashboard import dashboard_app

    return dashboard_app


def load_license_commands() -> typer.Typer:
    """Load license command group."""
    from vantage_cli.commands.license import license_app

    return license_app


def load_protect_commands() -> typer.Typer:
    """Load protect command group."""
    from vantage_cli.commands.protect import app as protect_app

    return protect_app


def load_ml_commands() -> typer.Typer:
    """Load ML command group."""
    from vantage_cli.commands.ml import ml_app

    return ml_app


def load_web_commands() -> typer.Typer:
    """Load web command group."""
    from vantage_cli.commands.web import web_app

    return web_app


def load_analyze_commands() -> typer.Typer:
    """Load analyze command group."""
    from vantage_cli.commands.analyze import analyze_app

    return analyze_app
