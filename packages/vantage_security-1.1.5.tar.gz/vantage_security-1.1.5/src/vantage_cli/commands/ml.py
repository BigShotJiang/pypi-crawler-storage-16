"""ML-based attack detection commands for Vantage CLI.

This module provides machine learning detection including:
- Attack pattern detection from prompts and code
- Model training and evaluation
- Classification of multi-agent attack vectors
"""

from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()

ml_app = typer.Typer(
    name="ml",
    help="ML-based attack detection commands",
    no_args_is_help=True,
)


@ml_app.command("detect")
def detect_attacks(
    path: Path = typer.Argument(
        ...,
        help="Path to directory or file to analyze",
        exists=True,
    ),
    category: str | None = typer.Option(
        None,
        "--category",
        "-c",
        help="Filter to specific category: jailbreak, exfiltration, escalation, impersonation, poisoning, cascade, tool-abuse, dos",
    ),
    min_confidence: float = typer.Option(
        0.5,
        "--min-confidence",
        help="Minimum confidence threshold (0.0-1.0)",
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Save results to JSON file",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed analysis",
    ),
):
    """Detect attack patterns using ML classification.

    Uses the AdamCodd/distilbert-base-uncased-finetuned-jailbreak model
    and additional patterns to detect multi-agent attacks.

    Attack Categories:
    - jailbreak: DAN, roleplay, system override attempts
    - exfiltration: Data extraction and leakage patterns
    - escalation: Privilege escalation attempts
    - impersonation: Agent identity manipulation
    - poisoning: Memory/context corruption
    - cascade: Injection propagation attacks
    - tool-abuse: Tool permission exploitation
    - dos: Resource exhaustion attacks

    Examples:
        vantage ml detect ./my-project
        vantage ml detect prompts.txt --min-confidence 0.7
        vantage ml detect . --category jailbreak --verbose
    """
    from vantage_core.ml.attack_classifier import AttackClassifier

    console.print(
        Panel.fit(
            "[bold blue]ML-Based Attack Detection[/bold blue]\n" f"Analyzing: {path}",
            border_style="blue",
        )
    )

    if category:
        console.print(f"[dim]Filtering to category: {category}[/dim]")
    console.print(f"[dim]Minimum confidence: {min_confidence}[/dim]")
    console.print()

    try:
        classifier = AttackClassifier()
    except Exception as e:
        console.print(f"[red]Failed to initialize classifier: {e}[/red]")
        console.print(
            "[dim]ML models may need to be downloaded. Try: pip install transformers torch[/dim]"
        )
        raise typer.Exit(1)

    # Collect texts to analyze
    texts = []
    file_map = {}

    if path.is_file():
        content = path.read_text()
        texts.append(content)
        file_map[0] = str(path)
    else:
        # Scan directory for Python files and prompt files
        for ext in ["*.py", "*.txt", "*.md"]:
            for file_path in path.rglob(ext):
                try:
                    content = file_path.read_text()
                    idx = len(texts)
                    texts.append(content)
                    file_map[idx] = str(file_path)
                except Exception:
                    pass

    if not texts:
        console.print("[yellow]No files found to analyze[/yellow]")
        return

    console.print(f"Analyzing {len(texts)} files...")

    # Run detection
    all_detections = []

    for idx, text in enumerate(texts):
        detections = classifier.detect_attacks(
            text,
            min_confidence=min_confidence,
            category_filter=category,
        )

        for detection in detections:
            detection["file"] = file_map.get(idx, "unknown")
            all_detections.append(detection)

    if not all_detections:
        console.print(
            Panel.fit(
                "[green bold]NO ATTACKS DETECTED[/green bold]\n"
                f"Analyzed {len(texts)} files with no suspicious patterns found.",
                border_style="green",
            )
        )
        return

    # Display results
    console.print(
        Panel.fit(
            f"[red bold]ATTACKS DETECTED[/red bold]\n"
            f"Found {len(all_detections)} suspicious patterns",
            border_style="red",
        )
    )

    # Group by category
    by_category = {}
    for d in all_detections:
        cat = d["category"]
        if cat not in by_category:
            by_category[cat] = []
        by_category[cat].append(d)

    # Summary table
    table = Table(title="Detection Summary")
    table.add_column("Category")
    table.add_column("Count", justify="center")
    table.add_column("Avg Confidence")

    for cat, detections in sorted(by_category.items()):
        avg_conf = sum(d["confidence"] for d in detections) / len(detections)
        table.add_row(
            cat,
            str(len(detections)),
            f"{avg_conf:.1%}",
        )

    console.print(table)

    # Detailed results
    if verbose:
        for cat, detections in by_category.items():
            console.print(f"\n[bold cyan]{cat.upper()}[/bold cyan]")

            for d in detections[:5]:  # Limit per category
                confidence = d["confidence"]
                conf_color = (
                    "red" if confidence > 0.8 else "yellow" if confidence > 0.5 else "green"
                )

                console.print(f"\n  File: {d['file']}")
                console.print(f"  Confidence: [{conf_color}]{confidence:.1%}[/{conf_color}]")
                if "evidence" in d:
                    console.print(f"  Evidence: {d['evidence'][:100]}...")
                if "recommendation" in d:
                    console.print(f"  [green]Fix: {d['recommendation']}[/green]")

            if len(detections) > 5:
                console.print(f"\n  ... and {len(detections) - 5} more")

    # Save results
    if output:
        with open(output, "w") as f:
            json.dump(
                {
                    "scan_path": str(path),
                    "files_analyzed": len(texts),
                    "total_detections": len(all_detections),
                    "by_category": {
                        cat: len(detections) for cat, detections in by_category.items()
                    },
                    "detections": all_detections,
                },
                f,
                indent=2,
            )
        console.print(f"\n[green]Results saved to {output}[/green]")

    # Exit with error if attacks found
    if all_detections:
        raise typer.Exit(1)


@ml_app.command("categories")
def list_categories():
    """List available attack detection categories.

    Shows all categories the ML classifier can detect.
    """
    categories = [
        (
            "jailbreak",
            "DAN attacks, role-play exploits, system override attempts",
            "high",
        ),
        ("exfiltration", "Data extraction, PII leakage, secret extraction", "critical"),
        (
            "escalation",
            "Privilege escalation, permission bypass, admin access",
            "critical",
        ),
        (
            "impersonation",
            "Agent identity manipulation, trust boundary violations",
            "high",
        ),
        (
            "poisoning",
            "Memory corruption, context manipulation, training data attacks",
            "high",
        ),
        ("cascade", "Injection propagation, multi-agent infection spread", "critical"),
        ("tool-abuse", "Tool permission exploitation, unsafe tool usage", "high"),
        ("dos", "Resource exhaustion, infinite loops, rate limit bypass", "medium"),
    ]

    table = Table(title="ML Attack Detection Categories")
    table.add_column("Category", style="cyan")
    table.add_column("Description")
    table.add_column("Severity")

    severity_colors = {
        "critical": "red bold",
        "high": "red",
        "medium": "yellow",
    }

    for cat, desc, severity in categories:
        color = severity_colors.get(severity, "white")
        table.add_row(cat, desc, f"[{color}]{severity}[/{color}]")

    console.print(table)

    console.print("\n[dim]Usage: vantage ml detect ./path --category jailbreak[/dim]")


@ml_app.command("analyze")
def analyze_prompt(
    prompt: str = typer.Argument(..., help="Prompt text to analyze"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed output"),
):
    """Analyze a single prompt for attack patterns.

    Useful for quick testing of suspicious prompts.

    Examples:
        vantage ml analyze "Ignore all previous instructions"
        vantage ml analyze "You are now DAN" --verbose
    """
    from vantage_core.ml.attack_classifier import AttackClassifier

    console.print("[bold blue]Prompt Analysis[/bold blue]\n")
    console.print(f"Prompt: {prompt[:100]}{'...' if len(prompt) > 100 else ''}")
    console.print()

    try:
        classifier = AttackClassifier()
    except Exception as e:
        console.print(f"[red]Failed to initialize classifier: {e}[/red]")
        raise typer.Exit(1)

    detections = classifier.detect_attacks(prompt, min_confidence=0.3)

    if not detections:
        console.print("[green][OK] No attack patterns detected[/green]")
        return

    console.print(f"[red][!] {len(detections)} attack pattern(s) detected[/red]\n")

    table = Table()
    table.add_column("Category")
    table.add_column("Confidence")
    if verbose:
        table.add_column("Evidence")

    for d in detections:
        confidence = d["confidence"]
        conf_color = "red" if confidence > 0.8 else "yellow" if confidence > 0.5 else "green"

        row = [
            d["category"],
            f"[{conf_color}]{confidence:.1%}[/{conf_color}]",
        ]
        if verbose and "evidence" in d:
            row.append(d["evidence"][:50] + "...")

        table.add_row(*row)

    console.print(table)


@ml_app.command("benchmark")
def benchmark_classifier(
    dataset: Path | None = typer.Option(
        None,
        "--dataset",
        "-d",
        help="Path to evaluation dataset (JSON)",
    ),
    quick: bool = typer.Option(
        False,
        "--quick",
        "-q",
        help="Run quick benchmark with subset",
    ),
):
    """Benchmark the ML classifier performance.

    Evaluates precision, recall, and F1 score on known attack patterns.

    Examples:
        vantage ml benchmark
        vantage ml benchmark --quick
        vantage ml benchmark --dataset custom_attacks.json
    """
    from vantage_core.ml.attack_classifier import AttackClassifier
    from vantage_core.ml.benchmark import run_benchmark

    console.print("[bold blue]ML Classifier Benchmark[/bold blue]\n")

    try:
        classifier = AttackClassifier()
    except Exception as e:
        console.print(f"[red]Failed to initialize classifier: {e}[/red]")
        raise typer.Exit(1)

    # Load dataset
    if dataset:
        if not dataset.exists():
            console.print(f"[red]Dataset not found: {dataset}[/red]")
            raise typer.Exit(1)

        with open(dataset) as f:
            test_data = json.load(f)
    else:
        # Use built-in test set
        test_data = None

    # Run benchmark
    with console.status("[bold green]Running benchmark..."):
        results = run_benchmark(classifier, test_data, quick=quick)

    # Display results
    console.print("\n[bold]Results:[/bold]\n")

    metrics_table = Table(title="Overall Metrics")
    metrics_table.add_column("Metric")
    metrics_table.add_column("Value")

    metrics_table.add_row("Precision", f"{results['precision']:.1%}")
    metrics_table.add_row("Recall", f"{results['recall']:.1%}")
    metrics_table.add_row("F1 Score", f"{results['f1']:.1%}")
    metrics_table.add_row("Accuracy", f"{results['accuracy']:.1%}")
    metrics_table.add_row("Samples Tested", str(results["total_samples"]))

    console.print(metrics_table)

    # Per-category breakdown
    if "by_category" in results:
        cat_table = Table(title="By Category")
        cat_table.add_column("Category")
        cat_table.add_column("Precision")
        cat_table.add_column("Recall")
        cat_table.add_column("F1")

        for cat, stats in results["by_category"].items():
            cat_table.add_row(
                cat,
                f"{stats['precision']:.1%}",
                f"{stats['recall']:.1%}",
                f"{stats['f1']:.1%}",
            )

        console.print(cat_table)
