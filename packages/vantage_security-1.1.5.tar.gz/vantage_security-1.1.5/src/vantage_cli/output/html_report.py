"""
HTML Report Generator for Vantage.

Creates a standalone, professional compliance report.
"""

from datetime import datetime
from pathlib import Path

from vantage_core.models import ScanResult

from vantage_cli.output.html_template import TEMPLATE


def generate_html_report(result: ScanResult, output_path: str = "vantage_report.html"):
    """Generate a standalone HTML report."""

    high_risk_count = sum(1 for a in result.agents if a.metadata.get("high_risk"))

    # Status Logic
    if high_risk_count > 0:
        overall_status = "ACTION REQUIRED"
        overall_status_class = "status-fail"
        high_risk_color = "#dc3545"
        summary_text = "Critical vulnerabilities detected. Several agents have unrestricted access to sensitive tools (shell, exec). Immediate remediation required."
    else:
        overall_status = "COMPLIANT"
        overall_status_class = "status-pass"
        high_risk_color = "#28a745"
        summary_text = "No high-risk agents detected. All discovered agents are operating within safe parameters."

    # Agent Rows
    rows = []
    for agent in result.agents:
        is_high = agent.metadata.get("high_risk", False)
        risk_class = "risk-high" if is_high else "risk-low"
        risk_text = "CRITICAL" if is_high else "LOW"

        tools = ""
        for tool in agent.tools:
            tools += f'<span class="tool-tag">{tool}</span>'
        if not tools:
            tools = "-"

        file_name = Path(agent.file_path).name

        # Determine framework value
        framework_val = (
            agent.framework.value if hasattr(agent.framework, "value") else str(agent.framework)
        )

        row = "<tr>"
        row += f"<td><strong>{agent.name}</strong></td>"
        row += f"<td>{framework_val}</td>"
        row += f'<td class="{risk_class}">{risk_text}</td>'
        row += f"<td>{tools}</td>"
        row += f'<td style="font-family: monospace;">{file_name}:{agent.line_number}</td>'
        row += "</tr>"

        rows.append(row)

    # Topology Rows
    conn_rows = []
    if result.connections:
        for conn in result.connections:
            # Format connection type
            conn_type = (
                conn.connection_type.value
                if hasattr(conn.connection_type, "value")
                else str(conn.connection_type)
            )
            conn_type = conn_type.replace("_", " ").title()

            # Format confidence
            conf_percent = f"{int(conn.confidence * 100)}%"

            row = f"""
            <tr>
                <td>{conn.source_id}</td>
                <td>{conn.target_id}</td>
                <td><span class="tool-tag">{conn_type}</span></td>
                <td>{conf_percent}</td>
            </tr>
            """
            conn_rows.append(row)
    else:
        conn_rows.append(
            '<tr><td colspan="4" style="text-align: center; color: #999;">No explicit connections detected</td></tr>'
        )

    html = TEMPLATE.format(
        overall_status=overall_status,
        overall_status_class=overall_status_class,
        scan_date=datetime.now().strftime("%Y-%m-%d %H:%M"),
        target_path=result.target_path or "Project Root",
        frameworks=result.framework,
        total_agents=len(result.agents),
        high_risk_count=high_risk_count,
        high_risk_color=high_risk_color,
        files_scanned=result.files_scanned,
        summary_text=summary_text,
        agent_rows="\n".join(rows),
        topology_rows="\n".join(conn_rows),
    )

    # Write to file
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    return output_path
