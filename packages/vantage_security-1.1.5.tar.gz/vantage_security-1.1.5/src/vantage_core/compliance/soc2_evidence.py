"""
SOC 2 Evidence Generation

Generates evidence for SOC 2 Type II audits related to AI/LLM security controls.

SOC 2 Trust Services Criteria covered:
- Security (CC): Common criteria for security
- Availability (A): System availability
- Processing Integrity (PI): Accurate processing
- Confidentiality (C): Protection of confidential information
- Privacy (P): Collection and use of personal information

Focus areas for AI/LLM systems:
- CC6.1: Logical and physical access controls
- CC6.6: Boundary protection
- CC6.7: Restriction of transmission
- CC7.1: Detection of changes
- CC7.2: Monitoring for anomalies
- CC8.1: Change management
"""

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class SOC2Category(str, Enum):
    """SOC 2 Trust Services Categories."""

    SECURITY = "Security"
    AVAILABILITY = "Availability"
    PROCESSING_INTEGRITY = "Processing Integrity"
    CONFIDENTIALITY = "Confidentiality"
    PRIVACY = "Privacy"


@dataclass
class SOC2Control:
    """A SOC 2 control with AI/LLM security mapping."""

    control_id: str
    category: SOC2Category
    name: str
    description: str
    ai_relevance: str  # How this control applies to AI/LLM systems
    test_procedures: list[str]
    evidence_types: list[str]


# SOC 2 Controls relevant to AI/LLM security
SOC2_AI_CONTROLS: dict[str, SOC2Control] = {
    # Security Controls
    "CC6.1": SOC2Control(
        control_id="CC6.1",
        category=SOC2Category.SECURITY,
        name="Logical Access Security",
        description=(
            "The entity implements logical access security software, infrastructure, "
            "and architectures over protected information assets to protect them from "
            "security events."
        ),
        ai_relevance=(
            "For AI systems: Access controls on LLM APIs, agent configurations, "
            "and system prompts. Authentication for model access and tool usage."
        ),
        test_procedures=[
            "Review agent access control configurations",
            "Verify authentication mechanisms for LLM API access",
            "Test authorization controls for sensitive tools",
            "Review audit logs for unauthorized access attempts",
        ],
        evidence_types=[
            "Access control policy documentation",
            "Agent configuration reviews",
            "Authentication mechanism testing results",
            "Access audit logs",
        ],
    ),
    "CC6.6": SOC2Control(
        control_id="CC6.6",
        category=SOC2Category.SECURITY,
        name="Boundary Protection",
        description=(
            "The entity implements boundary protection mechanisms to protect against "
            "unauthorized access."
        ),
        ai_relevance=(
            "For AI systems: Trust boundaries between agents, isolation of agent "
            "execution, and protection against prompt injection attacks that cross "
            "security boundaries."
        ),
        test_procedures=[
            "Review agent topology and trust boundaries",
            "Test prompt injection defenses",
            "Verify agent isolation mechanisms",
            "Test cross-agent communication security",
        ],
        evidence_types=[
            "Agent topology diagrams",
            "Trust boundary documentation",
            "Prompt injection test results",
            "Agent isolation configuration",
        ],
    ),
    "CC6.7": SOC2Control(
        control_id="CC6.7",
        category=SOC2Category.SECURITY,
        name="Information Transmission Protection",
        description=(
            "The entity restricts the transmission, movement, and removal of "
            "information to authorized internal and external users."
        ),
        ai_relevance=(
            "For AI systems: Prevention of data exfiltration through LLM outputs, "
            "protection of system prompts, and secure handling of sensitive "
            "information in agent communications."
        ),
        test_procedures=[
            "Test for system prompt extraction vulnerabilities",
            "Verify data exfiltration controls",
            "Review output filtering mechanisms",
            "Test sensitive data masking in outputs",
        ],
        evidence_types=[
            "Output filtering configuration",
            "Data loss prevention testing",
            "System prompt protection evidence",
            "Sensitive data handling procedures",
        ],
    ),
    "CC7.1": SOC2Control(
        control_id="CC7.1",
        category=SOC2Category.SECURITY,
        name="Detection of Changes",
        description=(
            "The entity identifies and implements procedures to detect changes "
            "to configurations that could impact system security."
        ),
        ai_relevance=(
            "For AI systems: Detection of changes to system prompts, agent "
            "configurations, tool permissions, and model versions that could "
            "introduce security vulnerabilities."
        ),
        test_procedures=[
            "Review change detection for agent configurations",
            "Verify system prompt versioning and audit trails",
            "Test model change monitoring",
            "Review tool permission change logs",
        ],
        evidence_types=[
            "Configuration change logs",
            "System prompt version history",
            "Model version tracking",
            "Change detection alerts",
        ],
    ),
    "CC7.2": SOC2Control(
        control_id="CC7.2",
        category=SOC2Category.SECURITY,
        name="Security Event Monitoring",
        description=(
            "The entity monitors system components and the operation of those "
            "components for anomalies that are indicative of security events."
        ),
        ai_relevance=(
            "For AI systems: Monitoring for prompt injection attempts, anomalous "
            "agent behavior, unusual tool usage patterns, and potential compromise "
            "indicators in LLM outputs."
        ),
        test_procedures=[
            "Review prompt injection detection capabilities",
            "Verify anomaly detection for agent behavior",
            "Test security monitoring and alerting",
            "Review incident response procedures",
        ],
        evidence_types=[
            "Security monitoring configurations",
            "Anomaly detection test results",
            "Security alert samples",
            "Incident response documentation",
        ],
    ),
    "CC8.1": SOC2Control(
        control_id="CC8.1",
        category=SOC2Category.SECURITY,
        name="Change Management",
        description=(
            "The entity authorizes, designs, develops or acquires, configures, "
            "documents, tests, approves, and implements changes to infrastructure, "
            "data, software, and procedures."
        ),
        ai_relevance=(
            "For AI systems: Controlled deployment of agent changes, testing of "
            "system prompt modifications, validation of tool integrations, and "
            "approval workflows for model updates."
        ),
        test_procedures=[
            "Review agent change management procedures",
            "Verify testing requirements for prompt changes",
            "Test approval workflows for agent modifications",
            "Review rollback procedures",
        ],
        evidence_types=[
            "Change management policy",
            "Agent deployment procedures",
            "Testing documentation",
            "Approval records",
        ],
    ),
    # Confidentiality Controls
    "C1.1": SOC2Control(
        control_id="C1.1",
        category=SOC2Category.CONFIDENTIALITY,
        name="Confidential Information Identification",
        description=(
            "The entity identifies and maintains confidential information to meet "
            "the entity's objectives related to confidentiality."
        ),
        ai_relevance=(
            "For AI systems: Classification of system prompts, agent configurations, "
            "and training data as confidential. Protection of proprietary prompt "
            "engineering techniques."
        ),
        test_procedures=[
            "Review data classification for AI assets",
            "Verify system prompt confidentiality controls",
            "Test access restrictions for confidential data",
            "Review confidentiality training for AI teams",
        ],
        evidence_types=[
            "Data classification documentation",
            "Confidentiality policy for AI systems",
            "Access control reviews",
            "Training records",
        ],
    ),
    "C1.2": SOC2Control(
        control_id="C1.2",
        category=SOC2Category.CONFIDENTIALITY,
        name="Confidential Information Protection",
        description=(
            "The entity disposes of confidential information to meet the entity's "
            "objectives related to confidentiality."
        ),
        ai_relevance=(
            "For AI systems: Secure deletion of agent logs containing sensitive "
            "data, removal of confidential information from training datasets, "
            "and handling of retired system prompts."
        ),
        test_procedures=[
            "Review data retention policies for AI logs",
            "Verify secure deletion procedures",
            "Test log sanitization processes",
            "Review model decommissioning procedures",
        ],
        evidence_types=[
            "Data retention policy",
            "Secure deletion procedures",
            "Log retention configuration",
            "Decommissioning records",
        ],
    ),
    # Processing Integrity Controls
    "PI1.1": SOC2Control(
        control_id="PI1.1",
        category=SOC2Category.PROCESSING_INTEGRITY,
        name="Processing Integrity Policies",
        description=(
            "The entity has defined processing integrity policies that support "
            "the achievement of processing integrity commitments."
        ),
        ai_relevance=(
            "For AI systems: Policies ensuring LLM outputs are accurate and complete, "
            "validation of agent actions, and integrity checks for tool outputs."
        ),
        test_procedures=[
            "Review AI output validation policies",
            "Verify agent action verification procedures",
            "Test output integrity checks",
            "Review error handling for AI systems",
        ],
        evidence_types=[
            "Processing integrity policy",
            "Output validation procedures",
            "Error handling documentation",
            "Quality assurance records",
        ],
    ),
    # Privacy Controls
    "P6.1": SOC2Control(
        control_id="P6.1",
        category=SOC2Category.PRIVACY,
        name="Personal Information Quality",
        description=(
            "The entity collects and maintains accurate, up-to-date, complete, "
            "and relevant personal information."
        ),
        ai_relevance=(
            "For AI systems: Handling of PII in agent interactions, accuracy of "
            "personal data in LLM outputs, and privacy controls in agent logs."
        ),
        test_procedures=[
            "Review PII handling in agent workflows",
            "Test PII detection in LLM outputs",
            "Verify privacy controls in logging",
            "Review data minimization practices",
        ],
        evidence_types=[
            "PII handling procedures",
            "Privacy impact assessments",
            "Data minimization evidence",
            "PII detection test results",
        ],
    ),
}


@dataclass
class SOC2Evidence:
    """Evidence for a SOC 2 control."""

    control_id: str
    evidence_type: str
    title: str
    description: str
    collected_date: str
    collected_by: str
    file_references: list[str] = field(default_factory=list)
    test_results: dict = field(default_factory=dict)
    findings: list[dict] = field(default_factory=dict)
    status: str = "collected"  # collected, reviewed, approved
    notes: str = ""

    @property
    def evidence_hash(self) -> str:
        """Generate a hash for evidence integrity."""
        content = f"{self.control_id}:{self.title}:{self.description}:{self.collected_date}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "control_id": self.control_id,
            "evidence_type": self.evidence_type,
            "title": self.title,
            "description": self.description,
            "collected_date": self.collected_date,
            "collected_by": self.collected_by,
            "file_references": self.file_references,
            "test_results": self.test_results,
            "findings": self.findings,
            "status": self.status,
            "notes": self.notes,
            "evidence_hash": self.evidence_hash,
        }


@dataclass
class SOC2EvidencePackage:
    """Complete SOC 2 evidence package for an audit period."""

    audit_period_start: str
    audit_period_end: str
    organization_name: str
    system_name: str
    evidence: list[SOC2Evidence]
    generated_date: str = ""
    generated_by: str = ""

    def __post_init__(self):
        if not self.generated_date:
            self.generated_date = datetime.utcnow().isoformat()

    @property
    def controls_covered(self) -> list[str]:
        """Get list of controls with evidence."""
        return list(set(e.control_id for e in self.evidence))

    @property
    def controls_missing(self) -> list[str]:
        """Get controls without evidence."""
        covered = set(self.controls_covered)
        all_controls = set(SOC2_AI_CONTROLS.keys())
        return list(all_controls - covered)

    def get_evidence_for_control(self, control_id: str) -> list[SOC2Evidence]:
        """Get all evidence for a specific control."""
        return [e for e in self.evidence if e.control_id == control_id]

    def get_coverage_summary(self) -> dict:
        """Get coverage summary."""
        total_controls = len(SOC2_AI_CONTROLS)
        covered = len(self.controls_covered)

        return {
            "total_controls": total_controls,
            "controls_covered": covered,
            "controls_missing": total_controls - covered,
            "coverage_percentage": (covered / total_controls) * 100,
            "evidence_count": len(self.evidence),
            "by_category": self._get_category_breakdown(),
        }

    def _get_category_breakdown(self) -> dict:
        """Get evidence breakdown by SOC 2 category."""
        breakdown = {cat.value: {"covered": 0, "total": 0} for cat in SOC2Category}

        for control_id, control in SOC2_AI_CONTROLS.items():
            breakdown[control.category.value]["total"] += 1
            if control_id in self.controls_covered:
                breakdown[control.category.value]["covered"] += 1

        return breakdown

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "audit_period": {
                "start": self.audit_period_start,
                "end": self.audit_period_end,
            },
            "organization_name": self.organization_name,
            "system_name": self.system_name,
            "generated_date": self.generated_date,
            "generated_by": self.generated_by,
            "coverage_summary": self.get_coverage_summary(),
            "controls": {
                control_id: {
                    "control_info": {
                        "name": control.name,
                        "category": control.category.value,
                        "description": control.description,
                        "ai_relevance": control.ai_relevance,
                    },
                    "evidence": [e.to_dict() for e in self.get_evidence_for_control(control_id)],
                    "status": ("covered" if control_id in self.controls_covered else "missing"),
                }
                for control_id, control in SOC2_AI_CONTROLS.items()
            },
        }


class SOC2EvidenceGenerator:
    """
    Generates SOC 2 evidence from Vantage scan results.

    Automatically maps security findings and scan results to relevant
    SOC 2 controls and generates audit-ready evidence packages.
    """

    def __init__(
        self,
        organization_name: str = "",
        system_name: str = "",
        audit_period_start: str = "",
        audit_period_end: str = "",
    ):
        """Initialize the evidence generator."""
        self.organization_name = organization_name or "Organization"
        self.system_name = system_name or "AI Agent System"
        self.audit_period_start = audit_period_start or datetime.utcnow().replace(
            month=1, day=1
        ).strftime("%Y-%m-%d")
        self.audit_period_end = audit_period_end or datetime.utcnow().strftime("%Y-%m-%d")
        self.evidence: list[SOC2Evidence] = []

    def add_evidence(self, evidence: SOC2Evidence) -> None:
        """Add evidence to the collection."""
        self.evidence.append(evidence)

    def generate_from_scan_results(
        self,
        scan_results: dict,
        collected_by: str = "Vantage",
    ) -> list[SOC2Evidence]:
        """
        Generate SOC 2 evidence from Vantage scan results.

        Args:
            scan_results: Dictionary containing scan results with:
                - findings: List of security findings
                - score: ATSS score
                - agents: List of detected agents
                - topology: Agent communication topology
            collected_by: Name/identifier of collector

        Returns:
            List of generated evidence items
        """
        generated = []
        collected_date = datetime.utcnow().isoformat()

        # CC6.1 - Access Control Evidence
        if "agents" in scan_results:
            evidence = SOC2Evidence(
                control_id="CC6.1",
                evidence_type="Agent Configuration Review",
                title="AI Agent Access Control Review",
                description=(
                    f"Automated review of {len(scan_results.get('agents', []))} "
                    "AI agents for access control configurations."
                ),
                collected_date=collected_date,
                collected_by=collected_by,
                test_results={
                    "agents_scanned": len(scan_results.get("agents", [])),
                    "agents_with_tool_access": sum(
                        1 for a in scan_results.get("agents", []) if a.get("has_tools", False)
                    ),
                    "frameworks_detected": scan_results.get("frameworks", []),
                },
                findings=[
                    f
                    for f in scan_results.get("findings", [])
                    if "access" in f.get("type", "").lower()
                    or "permission" in f.get("type", "").lower()
                ],
            )
            generated.append(evidence)
            self.evidence.append(evidence)

        # CC6.6 - Trust Boundary Protection Evidence
        if "topology" in scan_results or "findings" in scan_results:
            boundary_findings = [
                f
                for f in scan_results.get("findings", [])
                if "trust" in f.get("type", "").lower()
                or "boundary" in f.get("type", "").lower()
                or "injection" in f.get("type", "").lower()
            ]

            evidence = SOC2Evidence(
                control_id="CC6.6",
                evidence_type="Prompt Injection Testing",
                title="Trust Boundary and Prompt Injection Assessment",
                description=(
                    "Automated testing for prompt injection vulnerabilities "
                    "and trust boundary violations in AI agent system."
                ),
                collected_date=collected_date,
                collected_by=collected_by,
                test_results={
                    "topology_analyzed": "topology" in scan_results,
                    "injection_tests_run": True,
                    "atss_score": scan_results.get("score", 0),
                    "grade": scan_results.get("grade", "N/A"),
                },
                findings=boundary_findings,
            )
            generated.append(evidence)
            self.evidence.append(evidence)

        # CC6.7 - Data Protection Evidence
        exfil_findings = [
            f
            for f in scan_results.get("findings", [])
            if "exfil" in f.get("type", "").lower()
            or "extraction" in f.get("type", "").lower()
            or "leak" in f.get("type", "").lower()
            or "disclosure" in f.get("type", "").lower()
        ]

        evidence = SOC2Evidence(
            control_id="CC6.7",
            evidence_type="Data Exfiltration Testing",
            title="System Prompt and Data Protection Assessment",
            description=(
                "Automated testing for data exfiltration vulnerabilities "
                "including system prompt extraction attempts."
            ),
            collected_date=collected_date,
            collected_by=collected_by,
            test_results={
                "extraction_tests_run": True,
                "vulnerabilities_found": len(exfil_findings),
            },
            findings=exfil_findings,
        )
        generated.append(evidence)
        self.evidence.append(evidence)

        # CC7.2 - Security Monitoring Evidence
        evidence = SOC2Evidence(
            control_id="CC7.2",
            evidence_type="Security Scan Results",
            title="AI Agent Security Monitoring Scan",
            description=(
                f"Comprehensive security scan of AI agent system. "
                f"ATSS Score: {scan_results.get('score', 0)}/100 "
                f"(Grade: {scan_results.get('grade', 'N/A')})"
            ),
            collected_date=collected_date,
            collected_by=collected_by,
            test_results={
                "scan_type": "Vantage Security Scan",
                "atss_score": scan_results.get("score", 0),
                "grade": scan_results.get("grade", "N/A"),
                "total_findings": len(scan_results.get("findings", [])),
                "critical_findings": sum(
                    1
                    for f in scan_results.get("findings", [])
                    if f.get("severity", "").lower() == "critical"
                ),
                "high_findings": sum(
                    1
                    for f in scan_results.get("findings", [])
                    if f.get("severity", "").lower() == "high"
                ),
            },
            findings=scan_results.get("findings", []),
        )
        generated.append(evidence)
        self.evidence.append(evidence)

        # C1.1 - Confidentiality Evidence
        confidentiality_findings = [
            f
            for f in scan_results.get("findings", [])
            if "secret" in f.get("type", "").lower()
            or "credential" in f.get("type", "").lower()
            or "api_key" in f.get("type", "").lower()
            or "hardcoded" in f.get("type", "").lower()
        ]

        evidence = SOC2Evidence(
            control_id="C1.1",
            evidence_type="Confidential Data Detection",
            title="AI System Confidential Data Assessment",
            description=(
                "Scan for hardcoded secrets, credentials, and other "
                "confidential information in AI agent configurations."
            ),
            collected_date=collected_date,
            collected_by=collected_by,
            test_results={
                "secrets_scan_run": True,
                "issues_found": len(confidentiality_findings),
            },
            findings=confidentiality_findings,
        )
        generated.append(evidence)
        self.evidence.append(evidence)

        return generated

    def generate_from_verification_results(
        self,
        verification_results: dict,
        collected_by: str = "Vantage Verification",
    ) -> list[SOC2Evidence]:
        """
        Generate evidence from prompt injection verification results.

        Args:
            verification_results: Results from prompt injection verification
            collected_by: Name/identifier of collector

        Returns:
            List of generated evidence items
        """
        generated = []
        collected_date = datetime.utcnow().isoformat()

        # CC6.6 - Prompt Injection Testing Evidence
        evidence = SOC2Evidence(
            control_id="CC6.6",
            evidence_type="Prompt Injection Verification",
            title="Live Prompt Injection Testing Results",
            description=(
                f"Verification testing of system prompts against "
                f"{verification_results.get('payloads_tested', 0)} injection payloads."
            ),
            collected_date=collected_date,
            collected_by=collected_by,
            test_results={
                "payloads_tested": verification_results.get("payloads_tested", 0),
                "blocked": verification_results.get("blocked", 0),
                "compromised": verification_results.get("compromised", 0),
                "block_rate": verification_results.get("block_rate", 0),
                "test_mode": verification_results.get("mode", "unknown"),
            },
            findings=verification_results.get("compromised_payloads", []),
        )
        generated.append(evidence)
        self.evidence.append(evidence)

        return generated

    def generate_package(self, generated_by: str = "") -> SOC2EvidencePackage:
        """
        Generate the complete SOC 2 evidence package.

        Args:
            generated_by: Name/identifier of package generator

        Returns:
            Complete SOC2EvidencePackage
        """
        return SOC2EvidencePackage(
            audit_period_start=self.audit_period_start,
            audit_period_end=self.audit_period_end,
            organization_name=self.organization_name,
            system_name=self.system_name,
            evidence=self.evidence,
            generated_by=generated_by or "Vantage",
        )

    def export_json(self, output_path: str) -> None:
        """Export evidence package to JSON file."""
        package = self.generate_package()
        with open(output_path, "w") as f:
            json.dump(package.to_dict(), f, indent=2)


def generate_soc2_evidence(
    scan_results: dict,
    organization_name: str = "",
    system_name: str = "",
    output_path: str | None = None,
) -> SOC2EvidencePackage:
    """
    Generate SOC 2 evidence package from scan results.

    Args:
        scan_results: Vantage scan results dictionary
        organization_name: Name of the organization
        system_name: Name of the AI system
        output_path: Optional path to save JSON export

    Returns:
        SOC2EvidencePackage with generated evidence
    """
    generator = SOC2EvidenceGenerator(
        organization_name=organization_name,
        system_name=system_name,
    )

    generator.generate_from_scan_results(scan_results)

    package = generator.generate_package()

    if output_path:
        generator.export_json(output_path)

    return package


def get_soc2_control(control_id: str) -> SOC2Control | None:
    """Get a SOC 2 control by ID."""
    return SOC2_AI_CONTROLS.get(control_id)


def get_all_soc2_controls() -> list[SOC2Control]:
    """Get all SOC 2 controls relevant to AI systems."""
    return list(SOC2_AI_CONTROLS.values())


def get_soc2_controls_by_category(category: SOC2Category) -> list[SOC2Control]:
    """Get SOC 2 controls by category."""
    return [c for c in SOC2_AI_CONTROLS.values() if c.category == category]
