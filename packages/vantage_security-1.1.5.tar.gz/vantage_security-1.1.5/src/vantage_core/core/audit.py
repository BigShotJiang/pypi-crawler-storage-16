"""Audit logging for production deployment.

Provides structured audit logging for compliance and security tracking.
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field


class AuditEvent(BaseModel):
    """Structured audit event."""

    event_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    event_type: str
    action: str
    status: str = "success"
    user_id: str = ""
    client_ip: str = ""
    request_id: str = ""
    resource_type: str = ""
    resource_id: str = ""
    details: dict[str, Any] = Field(default_factory=dict)
    duration_ms: float = 0.0
    error_message: str = ""


class AuditLogger:
    """Structured audit logger for production compliance."""

    def __init__(
        self,
        enabled: bool = True,
        log_file: str | None = None,
        log_level: str = "INFO",
        json_format: bool = True,
    ):
        """Initialize audit logger.

        Args:
            enabled: Enable audit logging
            log_file: Path to audit log file
            log_level: Logging level
            json_format: Use JSON format for logs
        """
        self.enabled = enabled
        self.json_format = json_format
        self.logger = logging.getLogger("vantage_core.audit")
        self.logger.setLevel(getattr(logging, log_level.upper()))

        # Clear existing handlers
        self.logger.handlers = []

        if enabled:
            # Create handlers
            handlers: list[logging.Handler] = []

            # Console handler
            console_handler = logging.StreamHandler()
            handlers.append(console_handler)

            # File handler
            if log_file:
                log_path = Path(log_file)
                log_path.parent.mkdir(parents=True, exist_ok=True)
                file_handler = logging.FileHandler(log_file)
                handlers.append(file_handler)

            # Set formatter
            if json_format:
                formatter = logging.Formatter("%(message)s")
            else:
                formatter = logging.Formatter(
                    "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
                )

            for handler in handlers:
                handler.setFormatter(formatter)
                self.logger.addHandler(handler)

    def log(self, event: AuditEvent) -> None:
        """Log an audit event."""
        if not self.enabled:
            return

        if self.json_format:
            message = json.dumps(event.model_dump(), default=str)
        else:
            message = (
                f"{event.event_type} | {event.action} | "
                f"user={event.user_id} | resource={event.resource_type}:{event.resource_id} | "
                f"status={event.status}"
            )

        if event.status == "failure":
            self.logger.error(message)
        elif event.status == "warning":
            self.logger.warning(message)
        else:
            self.logger.info(message)

    def log_analysis(
        self,
        user_id: str,
        system_name: str,
        analysis_id: str,
        duration_ms: float,
        agent_count: int,
        collision_count: int,
        alignment_score: float,
        client_ip: str = "",
        request_id: str = "",
        status: str = "success",
        error_message: str = "",
    ) -> None:
        """Log an analysis operation."""
        event = AuditEvent(
            event_type="analysis",
            action="analyze_system",
            status=status,
            user_id=user_id,
            client_ip=client_ip,
            request_id=request_id,
            resource_type="system",
            resource_id=analysis_id,
            duration_ms=duration_ms,
            error_message=error_message,
            details={
                "system_name": system_name,
                "agent_count": agent_count,
                "collision_count": collision_count,
                "alignment_score": alignment_score,
            },
        )
        self.log(event)

    def log_access(
        self,
        user_id: str,
        resource_type: str,
        resource_id: str,
        action: str,
        client_ip: str = "",
        request_id: str = "",
        status: str = "success",
        error_message: str = "",
    ) -> None:
        """Log a resource access event."""
        event = AuditEvent(
            event_type="access",
            action=action,
            status=status,
            user_id=user_id,
            client_ip=client_ip,
            request_id=request_id,
            resource_type=resource_type,
            resource_id=resource_id,
            error_message=error_message,
        )
        self.log(event)

    def log_auth(
        self,
        user_id: str,
        action: str,
        client_ip: str = "",
        status: str = "success",
        error_message: str = "",
        details: dict[str, Any] | None = None,
    ) -> None:
        """Log an authentication event."""
        event = AuditEvent(
            event_type="authentication",
            action=action,
            status=status,
            user_id=user_id,
            client_ip=client_ip,
            error_message=error_message,
            details=details or {},
        )
        self.log(event)

    def log_config_change(
        self,
        user_id: str,
        config_type: str,
        changes: dict[str, Any],
        client_ip: str = "",
        request_id: str = "",
    ) -> None:
        """Log a configuration change."""
        event = AuditEvent(
            event_type="configuration",
            action="config_change",
            status="success",
            user_id=user_id,
            client_ip=client_ip,
            request_id=request_id,
            resource_type="config",
            resource_id=config_type,
            details={"changes": changes},
        )
        self.log(event)

    def log_feedback(
        self,
        user_id: str,
        analysis_id: str,
        feedback_type: str,
        client_ip: str = "",
        request_id: str = "",
    ) -> None:
        """Log a feedback submission."""
        event = AuditEvent(
            event_type="feedback",
            action="submit_feedback",
            status="success",
            user_id=user_id,
            client_ip=client_ip,
            request_id=request_id,
            resource_type="analysis",
            resource_id=analysis_id,
            details={"feedback_type": feedback_type},
        )
        self.log(event)


# Global audit logger instance
_audit_logger: AuditLogger | None = None


def get_audit_logger() -> AuditLogger:
    """Get or create the global audit logger."""
    global _audit_logger
    if _audit_logger is None:
        _audit_logger = AuditLogger(
            enabled=os.getenv("MIMIC_AUDIT_ENABLED", "true").lower() == "true",
            log_file=os.getenv("MIMIC_AUDIT_FILE"),
            log_level=os.getenv("MIMIC_LOG_LEVEL", "INFO"),
            json_format=os.getenv("MIMIC_LOG_FORMAT", "json") == "json",
        )
    return _audit_logger


def set_audit_logger(logger: AuditLogger) -> None:
    """Set the global audit logger."""
    global _audit_logger
    _audit_logger = logger
