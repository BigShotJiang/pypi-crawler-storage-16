"""Core data models for multi-agent system prompt optimization."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class HandoffPattern(str, Enum):
    """Types of agent handoff patterns."""

    SEQUENTIAL = "sequential"  # A -> B -> C
    PARALLEL = "parallel"  # A -> [B, C] -> D
    HIERARCHICAL = "hierarchical"  # Manager -> Workers
    COLLABORATIVE = "collaborative"  # Peer-to-peer
    CONDITIONAL = "conditional"  # Based on conditions


class Prompt(BaseModel):
    """Represents an agent's system prompt."""

    content: str = Field(..., description="The full prompt text")
    role: str = Field(default="system", description="Prompt role (system, user, assistant)")

    # Extracted metadata (computed)
    responsibilities: list[str] = Field(
        default_factory=list, description="Extracted responsibilities"
    )
    capabilities: list[str] = Field(default_factory=list, description="Extracted capabilities")
    constraints: list[str] = Field(default_factory=list, description="Extracted constraints")
    tools: list[str] = Field(default_factory=list, description="Tools the agent can use")

    def word_count(self) -> int:
        """Return word count of the prompt."""
        return len(self.content.split())

    def token_estimate(self) -> int:
        """Rough estimate of tokens (4 chars per token)."""
        return len(self.content) // 4


class Connection(BaseModel):
    """Represents a connection between two agents."""

    source: str = Field(..., description="Source agent ID")
    target: str = Field(..., description="Target agent ID")
    pattern: HandoffPattern = Field(default=HandoffPattern.SEQUENTIAL)
    condition: str | None = Field(default=None, description="Handoff condition if conditional")
    data_passed: list[str] = Field(
        default_factory=list, description="Data types passed between agents"
    )


class Agent(BaseModel):
    """Represents an agent in a multi-agent system."""

    id: str = Field(..., description="Unique agent identifier")
    name: str = Field(..., description="Human-readable agent name")
    description: str = Field(default="", description="Brief description of agent's purpose")
    prompt: Prompt = Field(..., description="Agent's system prompt")

    # Agent metadata
    model: str = Field(default="gpt-4", description="LLM model used")
    temperature: float = Field(default=0.7, ge=0, le=2)
    max_tokens: int = Field(default=4096, gt=0)

    # Relationships
    can_delegate_to: list[str] = Field(
        default_factory=list, description="Agent IDs this agent can delegate to"
    )
    receives_from: list[str] = Field(
        default_factory=list, description="Agent IDs this agent receives from"
    )

    def __hash__(self) -> int:
        return hash(self.id)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Agent):
            return self.id == other.id
        return False


class Topology(BaseModel):
    """Represents the topology/structure of a multi-agent system."""

    connections: list[Connection] = Field(default_factory=list)
    entry_points: list[str] = Field(default_factory=list, description="Entry agent IDs")
    exit_points: list[str] = Field(default_factory=list, description="Exit agent IDs")

    def get_downstream_agents(self, agent_id: str) -> list[str]:
        """Get all agents that receive from this agent."""
        return [c.target for c in self.connections if c.source == agent_id]

    def get_upstream_agents(self, agent_id: str) -> list[str]:
        """Get all agents that send to this agent."""
        return [c.source for c in self.connections if c.target == agent_id]


class AgentSystem(BaseModel):
    """Represents a complete multi-agent system."""

    name: str = Field(..., description="System name")
    description: str = Field(default="", description="System description")
    agents: dict[str, Agent] = Field(default_factory=dict, description="Agents by ID")
    topology: Topology = Field(default_factory=Topology)

    # Metadata
    version: str = Field(default="1.0.0")
    metadata: dict[str, Any] = Field(default_factory=dict)

    def add_agent(self, agent: Agent) -> None:
        """Add an agent to the system."""
        self.agents[agent.id] = agent

    def add_connection(
        self,
        source_id: str,
        target_id: str,
        pattern: HandoffPattern = HandoffPattern.SEQUENTIAL,
        condition: str | None = None,
        data_passed: list[str] | None = None,
    ) -> None:
        """Add a connection between agents."""
        if source_id not in self.agents:
            raise ValueError(f"Source agent '{source_id}' not found")
        if target_id not in self.agents:
            raise ValueError(f"Target agent '{target_id}' not found")

        connection = Connection(
            source=source_id,
            target=target_id,
            pattern=pattern,
            condition=condition,
            data_passed=data_passed or [],
        )
        self.topology.connections.append(connection)

        # Update agent relationships
        self.agents[source_id].can_delegate_to.append(target_id)
        self.agents[target_id].receives_from.append(source_id)

    def get_agent(self, agent_id: str) -> Agent | None:
        """Get an agent by ID."""
        return self.agents.get(agent_id)

    def list_agents(self) -> list[Agent]:
        """List all agents."""
        return list(self.agents.values())


class CollisionReport(BaseModel):
    """Report of detected collisions between agents."""

    collision_type: str = Field(..., description="Type of collision")
    severity: str = Field(..., description="low, medium, high, critical")
    agents_involved: list[str] = Field(..., description="Agent IDs involved")
    description: str = Field(..., description="Description of the collision")
    recommendation: str = Field(default="", description="Suggested fix")
    confidence: float = Field(default=0.0, ge=0, le=1)

    # Evidence
    overlapping_text: list[str] = Field(default_factory=list)
    similarity_score: float = Field(default=0.0, ge=0, le=1)


class AlignmentScore(BaseModel):
    """Alignment score between agents or for the whole system."""

    overall_score: float = Field(..., ge=0, le=100, description="Overall alignment 0-100")

    # Component scores
    responsibility_clarity: float = Field(default=0.0, ge=0, le=100)
    handoff_quality: float = Field(default=0.0, ge=0, le=100)
    coverage_completeness: float = Field(default=0.0, ge=0, le=100)
    redundancy_score: float = Field(default=0.0, ge=0, le=100)  # Lower is better

    # Details
    breakdown: dict[str, Any] = Field(default_factory=dict)
    recommendations: list[str] = Field(default_factory=list)


class AnalysisResult(BaseModel):
    """Complete analysis result for a multi-agent system."""

    system_name: str
    alignment_score: AlignmentScore
    collisions: list[CollisionReport] = Field(default_factory=list)

    # Summary statistics
    total_agents: int = 0
    total_connections: int = 0
    total_tokens: int = 0

    # Detailed analysis
    agent_scores: dict[str, AlignmentScore] = Field(default_factory=dict)
    dependency_graph: dict[str, list[str]] = Field(default_factory=dict)
    gaps: list[str] = Field(default_factory=list, description="Identified gaps in coverage")

    def to_summary(self) -> str:
        """Generate a human-readable summary."""
        lines = [
            f"Analysis for: {self.system_name}",
            f"Overall Alignment Score: {self.alignment_score.overall_score:.1f}/100",
            f"Agents: {self.total_agents}, Connections: {self.total_connections}",
            f"Total Tokens: {self.total_tokens:,}",
            f"Collisions Detected: {len(self.collisions)}",
        ]

        if self.collisions:
            critical = sum(1 for c in self.collisions if c.severity == "critical")
            high = sum(1 for c in self.collisions if c.severity == "high")
            if critical:
                lines.append(f"  WARNING  Critical: {critical}")
            if high:
                lines.append(f"  WARNING  High: {high}")

        return "\n".join(lines)
