"""Data module for Vantage Core.

Contains ground truth datasets and data utilities for benchmarking
and validation of multi-agent system analysis.
"""

from vantage_core.data.ground_truth import (
    GroundTruthCollection,
    GroundTruthSystem,
    load_all_ground_truth,
    validate_ground_truth_file,
)

__all__ = [
    "GroundTruthSystem",
    "GroundTruthCollection",
    "load_all_ground_truth",
    "validate_ground_truth_file",
]
