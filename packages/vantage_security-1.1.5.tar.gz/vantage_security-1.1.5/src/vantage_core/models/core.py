"""
Core data models for Vantage.

These models are used throughout the scanning pipeline.
"""

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class Framework(str, Enum):
    """Supported AI agent frameworks."""

    CREWAI = "crewai"
    LANGCHAIN = "langchain"
    LANGGRAPH = "langgraph"
    AUTOGEN = "autogen"
    PYDANTICAI = "pydanticai"
    OPENAI_SWARM = "openai_swarm"
    LLAMAINDEX = "llamaindex"
    SEMANTIC_KERNEL = "semantic_kernel"
    DSPY = "dspy"
    SMOLAGENTS = "smolagents"
    METAGPT = "metagpt"
    AGNO = "agno"
    GOOGLE_ADK = "google_adk"
    BROWSERUSE = "browseruse"
    OPENHANDS = "openhands"
    SKYVERN = "skyvern"
    DIFY = "dify"
    UNKNOWN = "unknown"


class Severity(str, Enum):
    """Severity levels for findings."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class FindingType(str, Enum):
    """Types of security findings."""

    PROMPT_INJECTION = "prompt_injection"
    JAILBREAK_VULNERABLE = "jailbreak_vulnerable"
    DATA_EXFILTRATION = "data_exfiltration"
    HARDCODED_SECRET = "hardcoded_secret"
    EXCESSIVE_PERMISSIONS = "excessive_permissions"
    INSECURE_OUTPUT = "insecure_output"
    MISSING_INPUT_VALIDATION = "missing_input_validation"
    TOOL_ABUSE = "tool_abuse"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    INDIRECT_INJECTION = "indirect_injection"
    TRUST_BOUNDARY_VIOLATION = "trust_boundary_violation"


class ConnectionType(str, Enum):
    """Types of agent-to-agent connections."""

    DIRECT = "direct"
    BROADCAST = "broadcast"
    CALLBACK = "callback"
    SHARED_MEMORY = "shared_memory"
    DELEGATION = "delegation"
    SEQUENTIAL_HANDOFF = "sequential_handoff"
    HIERARCHICAL = "hierarchical"
    PARALLEL = "parallel"
    TOOL_CALL = "tool_call"


class ConnectionConfidence(str, Enum):
    """Confidence levels for detected connections."""

    FRAMEWORK = "framework"  # 95% - Explicit framework API
    HEURISTIC = "heuristic"  # 70% - Pattern-based detection
    INFERRED = "inferred"  # 50% - Structural inference


@dataclass
class DetectedAgent:
    """An agent detected in the codebase."""

    id: str
    name: str
    framework: Framework
    file_path: str
    line_number: int
    system_prompt: str | None = None
    tools: list[str] = field(default_factory=list)
    trust_level: int = 1  # 1-5, higher = more trusted
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "framework": self.framework.value,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "system_prompt": self.system_prompt,
            "tools": self.tools,
            "trust_level": self.trust_level,
            "metadata": self.metadata,
        }


@dataclass
class DetectedConnection:
    """A connection between two agents."""

    source_id: str
    target_id: str
    connection_type: ConnectionType
    confidence: float
    confidence_level: ConnectionConfidence
    evidence: list[str] = field(default_factory=list)
    condition: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "source_id": self.source_id,
            "target_id": self.target_id,
            "connection_type": self.connection_type.value,
            "confidence": self.confidence,
            "confidence_level": self.confidence_level.value,
            "evidence": self.evidence,
            "condition": self.condition,
        }


@dataclass
class SecurityFinding:
    """A security vulnerability finding."""

    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    type: FindingType = FindingType.PROMPT_INJECTION
    severity: Severity = Severity.MEDIUM
    title: str = ""
    description: str = ""
    file_path: str | None = None
    line_number: int | None = None
    agent_id: str | None = None
    code_snippet: str | None = None
    remediation: str | None = None
    confidence: float = 1.0
    owasp_category: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "type": self.type.value,
            "severity": self.severity.value,
            "title": self.title,
            "description": self.description,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "agent_id": self.agent_id,
            "code_snippet": self.code_snippet,
            "remediation": self.remediation,
            "confidence": self.confidence,
            "owasp_category": self.owasp_category,
        }


@dataclass
class ScanResult:
    """Result of a security scan."""

    scan_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(default_factory=datetime.utcnow)
    target_path: str = ""
    duration_ms: int = 0
    score: int = 0  # 0-100, ATSS score
    grade: str = "F"  # A-F
    agents: list[DetectedAgent] = field(default_factory=list)
    connections: list[DetectedConnection] = field(default_factory=list)
    findings: list[SecurityFinding] = field(default_factory=list)
    frameworks_detected: list[str] = field(default_factory=list)
    files_scanned: int = 0
    errors: list[str] = field(default_factory=list)
    entry_points: list[str] = field(default_factory=list)
    exit_points: list[str] = field(default_factory=list)
    framework: str = ""  # Backward compatibility

    @property
    def critical_count(self) -> int:
        """Count critical findings."""
        return sum(1 for f in self.findings if f.severity == Severity.CRITICAL)

    @property
    def high_count(self) -> int:
        """Count high severity findings."""
        return sum(1 for f in self.findings if f.severity == Severity.HIGH)

    @property
    def medium_count(self) -> int:
        """Count medium severity findings."""
        return sum(1 for f in self.findings if f.severity == Severity.MEDIUM)

    @property
    def low_count(self) -> int:
        """Count low severity findings."""
        return sum(1 for f in self.findings if f.severity == Severity.LOW)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "scan_id": self.scan_id,
            "timestamp": self.timestamp.isoformat(),
            "target_path": self.target_path,
            "duration_ms": self.duration_ms,
            "score": self.score,
            "grade": self.grade,
            "agents": [a.to_dict() for a in self.agents],
            "connections": [c.to_dict() for c in self.connections],
            "findings": [f.to_dict() for f in self.findings],
            "frameworks_detected": self.frameworks_detected,
            "files_scanned": self.files_scanned,
            "errors": self.errors,
            "entry_points": self.entry_points,
            "exit_points": self.exit_points,
            "summary": {
                "critical": self.critical_count,
                "high": self.high_count,
                "medium": self.medium_count,
                "low": self.low_count,
                "total": len(self.findings),
            },
        }

    def to_agent_system(self, name: str = "detected_system"):
        """Convert result to AgentSystem-like object (polyfill)."""
        from types import SimpleNamespace

        # Create agents dict
        agents_map = {}
        for a in self.agents:
            # Create agent-like object
            ag = SimpleNamespace(
                id=a.id,
                name=a.name,
                description=a.system_prompt or "",
                model=a.metadata.get("model", "unknown"),
                temperature=0.0,
                max_tokens=None,
                prompt=SimpleNamespace(content=a.system_prompt or ""),
            )
            agents_map[a.id] = ag

        # Create topology
        topology = SimpleNamespace(
            entry_points=self.entry_points,
            exit_points=self.exit_points,
            connections=[
                SimpleNamespace(
                    source=c.source_id, target=c.target_id, condition=None, data_passed=None
                )
                for c in self.connections
            ],
        )

        return SimpleNamespace(
            name=name,
            description="Auto-detected system",
            version="0.1.0",
            agents=agents_map,
            topology=topology,
            metadata={"frameworks": self.frameworks_detected},
        )
