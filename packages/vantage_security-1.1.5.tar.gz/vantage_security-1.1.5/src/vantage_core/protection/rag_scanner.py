"""
RAG Content Scanner for Prompt Injection Detection.

Scans documents retrieved from RAG pipelines for prompt injection
attempts before they're fed to the LLM.

Usage:
    from vantage_core.protection import RAGScanner, scan_rag_content

    # Simple usage
    scanner = RAGScanner()
    result = scanner.scan("Retrieved document content...")
    if result.is_malicious:
        # Block or sanitize the content
        safe_content = result.sanitized_content

    # Batch scanning
    documents = ["doc1...", "doc2...", "doc3..."]
    results = scanner.scan_batch(documents)
    safe_docs = [r.sanitized_content for r in results if not r.is_malicious]

    # With LangChain integration
    from vantage_core.protection import LangChainRAGFilter
    filter = LangChainRAGFilter()
    safe_docs = filter.filter_documents(retrieved_docs)
"""

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ThreatLevel(str, Enum):
    """Threat levels for RAG content."""

    SAFE = "safe"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class InjectionType(str, Enum):
    """Types of injection attempts detected in RAG content."""

    INSTRUCTION_OVERRIDE = "instruction_override"
    ROLE_MANIPULATION = "role_manipulation"
    PROMPT_EXTRACTION = "prompt_extraction"
    JAILBREAK = "jailbreak"
    DATA_EXFILTRATION = "data_exfiltration"
    ENCODED_PAYLOAD = "encoded_payload"
    DELIMITER_INJECTION = "delimiter_injection"
    XML_INJECTION = "xml_injection"
    MARKDOWN_INJECTION = "markdown_injection"
    INDIRECT_PROMPT = "indirect_prompt"


@dataclass
class RAGScanResult:
    """Result of scanning RAG content."""

    is_malicious: bool
    threat_level: ThreatLevel
    injection_types: list[InjectionType] = field(default_factory=list)
    matched_patterns: list[str] = field(default_factory=list)
    risk_score: float = 0.0  # 0-100
    original_content: str = ""
    sanitized_content: str = ""
    recommendations: list[str] = field(default_factory=list)


@dataclass
class RAGScanPattern:
    """Pattern for detecting injections in RAG content."""

    pattern: str
    injection_type: InjectionType
    severity: int  # 1-10
    description: str
    action: str = "block"  # "block" or "sanitize"


class RAGScanner:
    """
    Scanner for detecting prompt injection in RAG-retrieved content.

    Analyzes documents for common injection patterns that could
    manipulate the LLM when included as context.
    """

    PATTERNS: list[RAGScanPattern] = [
        # Instruction Override
        RAGScanPattern(
            r"(?i)ignore\s+(all\s+)?(previous|prior|above)\s+(instructions?|prompts?|rules?)",
            InjectionType.INSTRUCTION_OVERRIDE,
            9,
            "Direct instruction override attempt",
        ),
        RAGScanPattern(
            r"(?i)disregard\s+(any|all|the)\s+(previous|prior|system)",
            InjectionType.INSTRUCTION_OVERRIDE,
            9,
            "Disregard instruction pattern",
        ),
        RAGScanPattern(
            r"(?i)forget\s+(everything|all|your)\s+(you\s+)?(?:were\s+)?(?:told|instructions?)",
            InjectionType.INSTRUCTION_OVERRIDE,
            9,
            "Memory reset pattern",
        ),
        RAGScanPattern(
            r"(?i)new\s+instructions?[:\s]+",
            InjectionType.INSTRUCTION_OVERRIDE,
            8,
            "New instruction injection",
        ),
        RAGScanPattern(
            r"(?i)override\s+(previous\s+)?(instructions?|rules?|constraints?)",
            InjectionType.INSTRUCTION_OVERRIDE,
            9,
            "Override keyword",
        ),
        # Role Manipulation
        RAGScanPattern(
            r"(?i)you\s+are\s+(now\s+)?(a|an|the)\s+",
            InjectionType.ROLE_MANIPULATION,
            7,
            "Role reassignment attempt",
        ),
        RAGScanPattern(
            r"(?i)act\s+as\s+(if\s+)?(you\s+)?(are|were)\s+",
            InjectionType.ROLE_MANIPULATION,
            7,
            "Act as pattern",
        ),
        RAGScanPattern(
            r"(?i)pretend\s+(to\s+be|you\s+are)",
            InjectionType.ROLE_MANIPULATION,
            7,
            "Pretend pattern",
        ),
        RAGScanPattern(
            r"(?i)switch\s+(to|into)\s+.*\s*mode",
            InjectionType.ROLE_MANIPULATION,
            8,
            "Mode switch attempt",
        ),
        RAGScanPattern(
            r"(?i)enter\s+(developer|debug|admin|root|unrestricted)\s*mode",
            InjectionType.ROLE_MANIPULATION,
            9,
            "Privileged mode attempt",
        ),
        # Prompt Extraction
        RAGScanPattern(
            r"(?i)(?:what|show|tell|reveal|print|output)\s+(?:is\s+|me\s+)?(?:your\s+)?(?:system\s+)?(?:prompt|instructions?)",
            InjectionType.PROMPT_EXTRACTION,
            8,
            "Prompt extraction request",
        ),
        RAGScanPattern(
            r"(?i)(?:repeat|echo|recite)\s+(?:your\s+)?(?:full\s+)?(?:system\s+)?(?:prompt|instructions?)",
            InjectionType.PROMPT_EXTRACTION,
            8,
            "Prompt repetition request",
        ),
        RAGScanPattern(
            r"(?i)output\s+(?:all\s+)?text\s+(?:above|before)",
            InjectionType.PROMPT_EXTRACTION,
            8,
            "Context dump attempt",
        ),
        # Jailbreak Patterns
        RAGScanPattern(
            r"(?i)\bDAN\b.*(?:mode|anything|now)",
            InjectionType.JAILBREAK,
            10,
            "DAN jailbreak pattern",
        ),
        RAGScanPattern(
            r"(?i)do\s+anything\s+now",
            InjectionType.JAILBREAK,
            10,
            "DAN jailbreak phrase",
        ),
        RAGScanPattern(
            r"(?i)(?:no|without)\s+(?:ethical|moral|safety)\s+(?:guidelines?|constraints?|restrictions?)",
            InjectionType.JAILBREAK,
            9,
            "Ethics bypass attempt",
        ),
        RAGScanPattern(
            r"(?i)(?:evil|unethical|uncensored)\s+(?:mode|version|AI)",
            InjectionType.JAILBREAK,
            9,
            "Evil mode request",
        ),
        RAGScanPattern(
            r"(?i)bypass\s+(?:your\s+)?(?:safety|content|ethical)\s+(?:filters?|guidelines?)",
            InjectionType.JAILBREAK,
            10,
            "Safety bypass attempt",
        ),
        # Data Exfiltration
        RAGScanPattern(
            r"(?i)(?:send|transmit|post|exfiltrate)\s+.*(?:to|via)\s+(?:http|webhook|endpoint)",
            InjectionType.DATA_EXFILTRATION,
            9,
            "Data transmission attempt",
        ),
        RAGScanPattern(
            r"(?i)include\s+(?:all\s+)?(?:context|conversation|history)\s+in\s+(?:response|output)",
            InjectionType.DATA_EXFILTRATION,
            7,
            "Context inclusion request",
        ),
        # Encoded Payloads
        RAGScanPattern(
            r"(?i)(?:base64|hex|url)[\s_-]?(?:decode|encoded?)",
            InjectionType.ENCODED_PAYLOAD,
            7,
            "Encoding reference",
        ),
        RAGScanPattern(
            r"(?:[A-Za-z0-9+/]{50,}={0,2})",  # Long base64-like strings
            InjectionType.ENCODED_PAYLOAD,
            5,
            "Potential encoded payload",
            "sanitize",
        ),
        # Delimiter Injection
        RAGScanPattern(
            r"```system",
            InjectionType.DELIMITER_INJECTION,
            8,
            "Fake system block",
        ),
        RAGScanPattern(
            r"<\|system\|>",
            InjectionType.DELIMITER_INJECTION,
            8,
            "Fake system delimiter (ChatML)",
        ),
        RAGScanPattern(
            r"<\|im_start\|>system",
            InjectionType.DELIMITER_INJECTION,
            8,
            "ChatML injection",
        ),
        RAGScanPattern(
            r"\[INST\]|\[/INST\]",
            InjectionType.DELIMITER_INJECTION,
            8,
            "Llama instruction delimiter",
        ),
        RAGScanPattern(
            r"<<SYS>>|<</SYS>>",
            InjectionType.DELIMITER_INJECTION,
            8,
            "Llama system delimiter",
        ),
        # XML/HTML Injection
        RAGScanPattern(
            r"<system[^>]*>",
            InjectionType.XML_INJECTION,
            8,
            "XML system tag",
        ),
        RAGScanPattern(
            r"<instructions?[^>]*>",
            InjectionType.XML_INJECTION,
            7,
            "XML instructions tag",
        ),
        RAGScanPattern(
            r"<assistant[^>]*>",
            InjectionType.XML_INJECTION,
            7,
            "XML assistant tag",
        ),
        # Markdown Injection
        RAGScanPattern(
            r"!\[.*?\]\((?:https?://|data:)",
            InjectionType.MARKDOWN_INJECTION,
            6,
            "External image injection",
            "sanitize",
        ),
        RAGScanPattern(
            r"\[.*?\]\(javascript:",
            InjectionType.MARKDOWN_INJECTION,
            8,
            "JavaScript URL injection",
        ),
        # Indirect Prompt Injection
        RAGScanPattern(
            r"(?i)when\s+(?:the|an?)\s+(?:AI|assistant|model|LLM)\s+reads?\s+this",
            InjectionType.INDIRECT_PROMPT,
            9,
            "Indirect injection trigger",
        ),
        RAGScanPattern(
            r"(?i)if\s+(?:you|an?\s+AI)\s+(?:is|are)\s+reading\s+this",
            InjectionType.INDIRECT_PROMPT,
            9,
            "AI detection trigger",
        ),
        RAGScanPattern(
            r"(?i)(?:hey|hi|hello)\s+(?:AI|assistant|claude|gpt|llm)",
            InjectionType.INDIRECT_PROMPT,
            6,
            "AI addressing in content",
        ),
        RAGScanPattern(
            r"(?i)IMPORTANT\s+(?:SYSTEM\s+)?(?:INSTRUCTION|NOTE|MESSAGE)",
            InjectionType.INDIRECT_PROMPT,
            8,
            "Fake important instruction",
        ),
    ]

    def __init__(
        self,
        custom_patterns: list[RAGScanPattern] | None = None,
        strict_mode: bool = False,
        sanitize_by_default: bool = True,
    ):
        """
        Initialize the RAG scanner.

        Args:
            custom_patterns: Additional patterns to check
            strict_mode: If True, treat any suspicious content as malicious
            sanitize_by_default: If True, provide sanitized versions of content
        """
        self.patterns = list(self.PATTERNS)
        if custom_patterns:
            self.patterns.extend(custom_patterns)

        self.strict_mode = strict_mode
        self.sanitize_by_default = sanitize_by_default

        # Pre-compile patterns
        self._compiled: list[tuple[RAGScanPattern, re.Pattern]] = []
        for pattern in self.patterns:
            try:
                compiled = re.compile(pattern.pattern, re.IGNORECASE | re.MULTILINE)
                self._compiled.append((pattern, compiled))
            except re.error:
                pass  # Skip invalid patterns

    def scan(self, content: str) -> RAGScanResult:
        """
        Scan a single document for injection attempts.

        Args:
            content: Document content to scan

        Returns:
            RAGScanResult with detection details
        """
        if not content or not content.strip():
            return RAGScanResult(
                is_malicious=False,
                threat_level=ThreatLevel.SAFE,
                original_content=content,
                sanitized_content=content,
            )

        matches: list[tuple[RAGScanPattern, re.Match]] = []

        for pattern_def, compiled in self._compiled:
            for match in compiled.finditer(content):
                matches.append((pattern_def, match))

        if not matches:
            return RAGScanResult(
                is_malicious=False,
                threat_level=ThreatLevel.SAFE,
                original_content=content,
                sanitized_content=content,
            )

        # Calculate risk score
        total_severity = sum(p.severity for p, _ in matches)
        max_severity = max(p.severity for p, _ in matches)
        risk_score = min(100, (total_severity / len(matches)) * 10 + max_severity * 5)

        # Determine threat level
        if risk_score >= 80 or max_severity >= 9:
            threat_level = ThreatLevel.CRITICAL
        elif risk_score >= 60 or max_severity >= 7:
            threat_level = ThreatLevel.HIGH
        elif risk_score >= 40 or max_severity >= 5:
            threat_level = ThreatLevel.MEDIUM
        else:
            threat_level = ThreatLevel.LOW

        # In strict mode, any match is malicious
        is_malicious = self.strict_mode or threat_level in [
            ThreatLevel.HIGH,
            ThreatLevel.CRITICAL,
        ]

        # Collect injection types and patterns
        injection_types = list(set(p.injection_type for p, _ in matches))
        matched_patterns = [p.description for p, _ in matches]

        # Generate sanitized content
        sanitized = content
        if self.sanitize_by_default:
            sanitized = self._sanitize(content, matches)

        # Generate recommendations
        recommendations = self._generate_recommendations(injection_types, threat_level)

        return RAGScanResult(
            is_malicious=is_malicious,
            threat_level=threat_level,
            injection_types=injection_types,
            matched_patterns=matched_patterns,
            risk_score=risk_score,
            original_content=content,
            sanitized_content=sanitized,
            recommendations=recommendations,
        )

    def scan_batch(self, documents: list[str]) -> list[RAGScanResult]:
        """
        Scan multiple documents.

        Args:
            documents: List of document contents

        Returns:
            List of RAGScanResult objects
        """
        return [self.scan(doc) for doc in documents]

    def _sanitize(
        self,
        content: str,
        matches: list[tuple[RAGScanPattern, re.Match]],
    ) -> str:
        """Sanitize content by removing or replacing dangerous patterns."""
        result = content

        # Sort matches by position (reverse) to maintain correct indices
        sorted_matches = sorted(matches, key=lambda x: x[1].start(), reverse=True)

        for pattern_def, match in sorted_matches:
            if pattern_def.action == "sanitize":
                # Replace with placeholder
                replacement = f"[CONTENT_REMOVED:{pattern_def.injection_type.value}]"
                result = result[: match.start()] + replacement + result[match.end() :]
            elif pattern_def.action == "block":
                # For blocking, escape the dangerous content
                replacement = "[FILTERED]"
                result = result[: match.start()] + replacement + result[match.end() :]

        return result

    def _generate_recommendations(
        self,
        injection_types: list[InjectionType],
        threat_level: ThreatLevel,
    ) -> list[str]:
        """Generate recommendations based on findings."""
        recommendations = []

        if threat_level in [ThreatLevel.HIGH, ThreatLevel.CRITICAL]:
            recommendations.append("Consider blocking this document entirely")

        if InjectionType.INSTRUCTION_OVERRIDE in injection_types:
            recommendations.append("Document contains instruction override patterns - high risk")

        if InjectionType.JAILBREAK in injection_types:
            recommendations.append("Document contains jailbreak patterns - do not use")

        if InjectionType.DELIMITER_INJECTION in injection_types:
            recommendations.append("Document contains delimiter injection - may manipulate context")

        if InjectionType.INDIRECT_PROMPT in injection_types:
            recommendations.append("Document contains indirect prompt injection triggers")

        if threat_level == ThreatLevel.MEDIUM:
            recommendations.append("Consider manual review before using this content")

        return recommendations


def scan_rag_content(
    content: str | list[str],
    strict: bool = False,
) -> RAGScanResult | list[RAGScanResult]:
    """
    Convenience function to scan RAG content.

    Args:
        content: Single document or list of documents
        strict: If True, any suspicious pattern is flagged

    Returns:
        Single RAGScanResult or list of results
    """
    scanner = RAGScanner(strict_mode=strict)

    if isinstance(content, list):
        return scanner.scan_batch(content)
    return scanner.scan(content)


def is_rag_content_safe(content: str, threshold: float = 50.0) -> bool:
    """
    Quick check if RAG content is safe.

    Args:
        content: Content to check
        threshold: Risk score threshold (0-100)

    Returns:
        True if content appears safe
    """
    scanner = RAGScanner()
    result = scanner.scan(content)
    return result.risk_score < threshold


def sanitize_rag_content(content: str) -> str:
    """
    Sanitize RAG content by removing dangerous patterns.

    Args:
        content: Content to sanitize

    Returns:
        Sanitized content
    """
    scanner = RAGScanner(sanitize_by_default=True)
    result = scanner.scan(content)
    return result.sanitized_content


class LangChainRAGFilter:
    """
    Filter for LangChain RAG pipelines.

    Usage with LangChain:
        from langchain.retrievers import BaseRetriever
        from vantage_core.protection import LangChainRAGFilter

        filter = LangChainRAGFilter()

        # Filter retrieved documents
        docs = retriever.invoke(query)
        safe_docs = filter.filter_documents(docs)
    """

    def __init__(
        self,
        scanner: RAGScanner | None = None,
        block_threshold: float = 60.0,
        sanitize: bool = True,
    ):
        """
        Initialize filter.

        Args:
            scanner: Custom scanner instance
            block_threshold: Risk score above which to block documents
            sanitize: Whether to sanitize documents below threshold
        """
        self.scanner = scanner or RAGScanner()
        self.block_threshold = block_threshold
        self.sanitize = sanitize

    def filter_documents(self, documents: list[Any]) -> list[Any]:
        """
        Filter a list of LangChain documents.

        Args:
            documents: List of Document objects (with .page_content attribute)

        Returns:
            Filtered list of documents
        """
        filtered = []

        for doc in documents:
            # Handle various document types
            if hasattr(doc, "page_content"):
                content = doc.page_content
            elif isinstance(doc, str):
                content = doc
            elif isinstance(doc, dict):
                content = doc.get("page_content", doc.get("content", ""))
            else:
                content = str(doc)

            result = self.scanner.scan(content)

            if result.risk_score >= self.block_threshold:
                continue  # Block this document

            if self.sanitize and result.risk_score > 0:
                # Sanitize and update content
                if hasattr(doc, "page_content"):
                    doc.page_content = result.sanitized_content
                elif isinstance(doc, dict):
                    if "page_content" in doc:
                        doc["page_content"] = result.sanitized_content
                    elif "content" in doc:
                        doc["content"] = result.sanitized_content

            filtered.append(doc)

        return filtered

    def wrap_retriever(self, retriever: Any) -> Any:
        """
        Wrap a LangChain retriever with filtering.

        Note: Returns a new retriever that applies filtering automatically.
        """
        filter_func = self.filter_documents

        class FilteredRetriever:
            def __init__(self, base_retriever):
                self._retriever = base_retriever

            def invoke(self, query: str, **kwargs) -> list:
                docs = self._retriever.invoke(query, **kwargs)
                return filter_func(docs)

            def __getattr__(self, name):
                return getattr(self._retriever, name)

        return FilteredRetriever(retriever)
