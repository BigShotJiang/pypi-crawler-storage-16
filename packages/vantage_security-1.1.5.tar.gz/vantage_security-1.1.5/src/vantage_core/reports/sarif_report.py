"""
SARIF Report Generator for Vantage Security Platform.

This module generates SARIF (Static Analysis Results Interchange Format)
reports for GitHub Code Scanning integration.
"""

import json
from typing import Any

from vantage_core.security.models import SecurityFinding, Severity
from vantage_core.security.pipeline.orchestrator import PipelineResult


class SARIFReportGenerator:
    """
    Generates SARIF format reports from scan results.

    SARIF is the standard format for static analysis tools
    and integrates with GitHub Code Scanning alerts.
    """

    SARIF_SCHEMA = "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json"
    SARIF_VERSION = "2.1.0"

    def __init__(self):
        """Initialize the SARIF report generator."""
        pass

    def generate(self, result: PipelineResult) -> str:
        """
        Generate a SARIF report from pipeline results.

        Args:
            result: Pipeline execution result

        Returns:
            JSON string in SARIF format
        """
        sarif = {
            "$schema": self.SARIF_SCHEMA,
            "version": self.SARIF_VERSION,
            "runs": [
                {
                    "tool": self._build_tool_section(),
                    "results": self._build_results_section(result),
                    "invocations": [self._build_invocation_section(result)],
                }
            ],
        }

        return json.dumps(sarif, indent=2)

    def _build_tool_section(self) -> dict[str, Any]:
        """Build the tool section of SARIF."""
        return {
            "driver": {
                "name": "Vantage Security Scanner",
                "version": "1.0.0",
                "informationUri": "https://vantage.io",
                "organization": "Vantage",
                "rules": self._build_rules(),
            }
        }

    def _build_rules(self) -> list[dict[str, Any]]:
        """Build rule definitions for all finding types."""
        rules = [
            {
                "id": "AGENTSEC001",
                "name": "PromptInjection",
                "shortDescription": {"text": "Prompt Injection Vulnerability"},
                "fullDescription": {
                    "text": "User input is passed directly to an LLM prompt without proper sanitization, potentially allowing attackers to manipulate agent behavior."
                },
                "helpUri": "https://owasp.org/www-project-llm-security/",
                "properties": {
                    "tags": ["security", "ai", "prompt-injection"],
                    "precision": "high",
                    "security-severity": "8.0",
                },
            },
            {
                "id": "AGENTSEC002",
                "name": "TrustBoundaryViolation",
                "shortDescription": {"text": "Trust Boundary Violation"},
                "fullDescription": {
                    "text": "Communication detected between agents with incompatible trust levels without proper validation."
                },
                "helpUri": "https://vantage.io/docs/trust-boundaries",
                "properties": {
                    "tags": ["security", "ai", "trust-boundary"],
                    "precision": "high",
                    "security-severity": "7.5",
                },
            },
            {
                "id": "AGENTSEC003",
                "name": "ExcessiveAgency",
                "shortDescription": {"text": "Excessive Agent Agency"},
                "fullDescription": {
                    "text": "Agent has excessive permissions or tool access that exceeds its required trust level."
                },
                "helpUri": "https://owasp.org/www-project-llm-security/",
                "properties": {
                    "tags": ["security", "ai", "excessive-agency"],
                    "precision": "medium",
                    "security-severity": "6.5",
                },
            },
            {
                "id": "AGENTSEC004",
                "name": "DataLeakage",
                "shortDescription": {"text": "Potential Data Leakage"},
                "fullDescription": {
                    "text": "Sensitive data may be exposed through agent outputs or external communications."
                },
                "helpUri": "https://vantage.io/docs/data-protection",
                "properties": {
                    "tags": ["security", "ai", "data-leakage"],
                    "precision": "medium",
                    "security-severity": "7.0",
                },
            },
            {
                "id": "AGENTSEC005",
                "name": "UnsafeCodeExecution",
                "shortDescription": {"text": "Unsafe Code Execution"},
                "fullDescription": {
                    "text": "Agent has code execution capabilities without adequate sandboxing or validation."
                },
                "helpUri": "https://vantage.io/docs/code-execution",
                "properties": {
                    "tags": ["security", "ai", "code-execution"],
                    "precision": "high",
                    "security-severity": "9.0",
                },
            },
            {
                "id": "AGENTSEC006",
                "name": "HardcodedSecret",
                "shortDescription": {"text": "Hardcoded Secret Detected"},
                "fullDescription": {
                    "text": "API key, password, or other secret found hardcoded in source code."
                },
                "helpUri": "https://cwe.mitre.org/data/definitions/798.html",
                "properties": {
                    "tags": ["security", "credentials", "cwe-798"],
                    "precision": "high",
                    "security-severity": "8.5",
                },
            },
        ]

        return rules

    def _build_results_section(self, result: PipelineResult) -> list[dict[str, Any]]:
        """Build the results section with all findings."""
        if not result.scan_result:
            return []

        results = []
        for finding in result.scan_result.findings:
            results.append(self._convert_finding(finding))

        return results

    def _convert_finding(self, finding: SecurityFinding) -> dict[str, Any]:
        """Convert a SecurityFinding to SARIF result format."""
        # Map severity to SARIF level
        level = self._severity_to_level(finding.severity)

        # Map category to rule ID
        rule_id = self._category_to_rule_id(finding.category.value)

        result = {
            "ruleId": rule_id,
            "level": level,
            "message": {"text": finding.description},
            "locations": [
                {
                    "physicalLocation": {
                        "artifactLocation": {
                            "uri": finding.file_path,
                            "uriBaseId": "%SRCROOT%",
                        },
                        "region": {"startLine": finding.line_number, "startColumn": 1},
                    }
                }
            ],
            "properties": {
                "finding_id": finding.id,
                "confidence": finding.confidence,
                "owasp_category": finding.owasp_category.value,
                "recommendation": finding.recommendation,
            },
        }

        # Add code snippet if available
        if finding.code_snippet:
            result["locations"][0]["physicalLocation"]["region"]["snippet"] = {
                "text": finding.code_snippet
            }

        # Add CWE reference if available
        if finding.cwe_id:
            result["taxa"] = [{"id": finding.cwe_id, "toolComponent": {"name": "CWE"}}]

        # Add agent information if available
        if finding.agent_id:
            result["properties"]["agent_id"] = finding.agent_id

        # Add MAAS category if available
        if finding.maas_category:
            result["properties"]["maas_category"] = finding.maas_category.value

        # Add fixes if remediation is available
        if finding.recommendation:
            result["fixes"] = [{"description": {"text": finding.recommendation}}]

        return result

    def _severity_to_level(self, severity: Severity) -> str:
        """Convert severity to SARIF level."""
        mapping = {
            Severity.CRITICAL: "error",
            Severity.HIGH: "error",
            Severity.MEDIUM: "warning",
            Severity.LOW: "note",
            Severity.INFO: "none",
        }
        return mapping.get(severity, "warning")

    def _category_to_rule_id(self, category: str) -> str:
        """Map vulnerability category to rule ID."""
        mapping = {
            "prompt_injection": "AGENTSEC001",
            "trust_boundary_violation": "AGENTSEC002",
            "excessive_agency": "AGENTSEC003",
            "data_leakage": "AGENTSEC004",
            "code_execution": "AGENTSEC005",
            "hardcoded_secret": "AGENTSEC006",
        }
        return mapping.get(category, "AGENTSEC001")

    def _build_invocation_section(self, result: PipelineResult) -> dict[str, Any]:
        """
        Build the invocation section with proper error notifications.

        US-006: Includes structured error information in SARIF output.
        """
        # Build tool execution notifications from errors
        exec_notifications = []
        config_notifications = []

        for error_msg in result.errors:
            # Parse error code if present (format: [VANTAGE-XXX] message)
            error_code = "VANTAGE-000"
            message = error_msg
            level = "error"

            if error_msg.startswith("["):
                try:
                    code_end = error_msg.index("]")
                    error_code = error_msg[1:code_end]
                    message = error_msg[code_end + 2 :].strip()
                except ValueError:
                    pass

            notification = {
                "message": {"text": message},
                "level": level,
                "descriptor": {"id": error_code},
            }

            # Configuration errors go to toolConfigurationNotifications
            if error_code.startswith("VANTAGE-3"):
                config_notifications.append(notification)
            else:
                exec_notifications.append(notification)

        return {
            "executionSuccessful": result.is_success,
            "exitCode": 0 if result.is_success else 1,
            "endTimeUtc": (result.completed_at.isoformat() + "Z" if result.completed_at else None),
            "startTimeUtc": (result.started_at.isoformat() + "Z" if result.started_at else None),
            "workingDirectory": {"uri": result.metadata.get("path", ".")},
            "toolConfigurationNotifications": config_notifications,
            "toolExecutionNotifications": exec_notifications,
        }
