"""Scanner for Pydantic AI agent definitions.

Pydantic AI provides type-safe agents with strong typing, dependency injection,
and MCP (Model Context Protocol) support.

Example detection targets:

    # Basic agent with type safety
    from pydantic_ai import Agent
    from pydantic import BaseModel

    class CityInfo(BaseModel):
        name: str
        country: str

    agent = Agent(
        'openai:gpt-4',
        result_type=CityInfo,
        system_prompt="You are a geography expert.",
    )

    # Agent with tools
    support_agent = Agent(
        'anthropic:claude-3-5-sonnet',
        deps_type=SupportDependencies,
        system_prompt="You are a customer support agent.",
    )

    @support_agent.tool
    async def get_customer_info(ctx: RunContext[SupportDependencies], customer_id: int) -> str:
        '''Retrieve customer information from database.'''
        pass
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult
from vantage_core.scanners.mixins import ASTExtractionMixin

logger = logging.getLogger(__name__)


class PydanticAIScanner(BaseScanner, ASTExtractionMixin):
    """Scanner for Pydantic AI agent definitions.

    Detects:
    - Agent() instantiations with type annotations
    - @agent.tool decorated functions
    - @agent.system_prompt dynamic prompt generators
    - Dependencies and result types
    """

    framework_name = "PydanticAI"

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a Python file for Pydantic AI agent definitions."""
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        errors: list[str] = []

        try:
            tree = self._parse_python_file(path)
        except SyntaxError as e:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[f"Syntax error in {path}: {e}"],
            )

        # Track agent variable names for decorator linking
        agent_vars: dict[str, DetectedAgent] = {}

        # First pass: find Agent() instantiations
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        if self._is_agent_creation(node.value, path):
                            agent = self._parse_agent_call(node.value, path, target.id)
                            if agent:
                                agents.append(agent)
                                agent_vars[target.id] = agent

        # Second pass: find tools and dynamic prompts via decorators
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self._parse_agent_decorators(node, agent_vars)

        # Third pass: detect multi-agent patterns (agent.run results passed to another agent)
        connections = self._detect_agent_connections(tree, agent_vars)

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=errors,
        )

    def _is_agent_creation(self, node: ast.Call, path: Path) -> bool:
        """Check if a call instantiates a PydanticAI Agent."""
        func_name = self._get_call_name(node)
        if not func_name:
            return False

        # 1. Direct Match
        if func_name == "Agent":
            return True

        # 2. Alias Resolution
        if hasattr(self, "symbol_table") and self.symbol_table:
            resolved = self.symbol_table.resolve_symbol(str(path), func_name)
            if resolved:
                if resolved.definition_type == "import":
                    orig = resolved.value.get("original_name", "")
                    if orig == "Agent":
                        return True
                elif resolved.definition_type == "assignment":
                    val_str = ""
                    try:
                        if isinstance(resolved.value, ast.AST):
                            val_str = ast.unparse(resolved.value)
                        else:
                            val_str = str(resolved.value)
                    except Exception:
                        val_str = str(resolved.value)

                    if "Agent" in val_str:
                        return True
        return False

    def _parse_agent_call(self, node: ast.Call, path: Path, var_name: str) -> DetectedAgent | None:
        """Parse Agent() constructor.

        Args:
            node: AST Call node
            path: Source file path
            var_name: Variable name the agent is assigned to

        Returns:
            DetectedAgent or None if not an Agent call
        """
        func_name = self._get_call_name(node)

        # Validation moved to _is_agent_creation
        # But we double check roughly or assume validity

        # First positional arg is usually model name
        model = "gpt-4"
        if node.args:
            model_arg = self._extract_value(node.args[0])
            if model_arg and isinstance(model_arg, str):
                model = model_arg

        # System prompt from keyword
        system_prompt = self._extract_keyword_arg(node, "system_prompt") or ""
        if not isinstance(system_prompt, str):
            system_prompt = ""

        # Result type indicates agent's purpose
        result_type = self._extract_keyword_arg(node, "result_type")
        if result_type:
            if isinstance(result_type, str):
                system_prompt += f"\n\nExpected output type: {result_type}"

        # Dependencies indicate context
        deps_type = self._extract_keyword_arg(node, "deps_type")
        if deps_type:
            if isinstance(deps_type, str):
                system_prompt += f"\n\nDependencies: {deps_type}"

        # Retries configuration
        retries = self._extract_keyword_arg(node, "retries")
        if retries:
            system_prompt += f"\n\nRetries: {retries}"

        # Clean up system prompt
        system_prompt = system_prompt.strip()
        if not system_prompt:
            system_prompt = f"Pydantic AI Agent: {var_name}"

        return DetectedAgent(
            id=self._make_id(var_name),
            name=self._format_display_name(var_name),
            framework=Framework.PYDANTICAI,
            file_path=str(path),
            line_number=node.lineno,
            system_prompt=system_prompt,
            metadata={"model": str(model)},
        )

    def _parse_agent_decorators(
        self,
        node: ast.FunctionDef | ast.AsyncFunctionDef,
        agent_vars: dict[str, DetectedAgent],
    ) -> None:
        """Parse @agent.tool and @agent.system_prompt decorators.

        Modifies agent objects in-place to add tool information.

        Args:
            node: Function definition node
            agent_vars: Map of variable names to agent objects
        """
        for decorator in node.decorator_list:
            # Pattern: agent_var.tool or agent_var.system_prompt
            if isinstance(decorator, ast.Attribute):
                if isinstance(decorator.value, ast.Name):
                    agent_name = decorator.value.id
                    if agent_name in agent_vars:
                        agent = agent_vars[agent_name]

                        if decorator.attr in ("tool", "tool_plain"):
                            # Add tool to agent's tools list
                            if node.name not in agent.tools:
                                agent.tools.append(node.name)

                            # Add note to system prompt if needed (optional, keeping for context)
                            if "Tools:" not in agent.system_prompt:
                                agent.system_prompt += f"\n\nTools: {node.name}"
                            else:
                                agent.system_prompt += f", {node.name}"

                        elif decorator.attr == "system_prompt":
                            # This is a dynamic prompt generator
                            doc = ast.get_docstring(node)
                            if doc:
                                agent.system_prompt = doc

            # Pattern: agent_var.tool() with parentheses
            elif isinstance(decorator, ast.Call):
                if isinstance(decorator.func, ast.Attribute):
                    if isinstance(decorator.func.value, ast.Name):
                        agent_name = decorator.func.value.id
                        if agent_name in agent_vars:
                            agent = agent_vars[agent_name]

                            if decorator.func.attr in ("tool", "tool_plain"):
                                # Add tool to agent's tools list
                                if node.name not in agent.tools:
                                    agent.tools.append(node.name)

                                if "Tools:" not in agent.system_prompt:
                                    agent.system_prompt += f"\n\nTools: {node.name}"
                                else:
                                    agent.system_prompt += f", {node.name}"

    def _detect_agent_connections(
        self,
        tree: ast.Module,
        agent_vars: dict[str, DetectedAgent],
    ) -> list[DetectedConnection]:
        """Detect connections between PydanticAI agents.

        Looks for patterns where one agent's result is passed to another:
        - result1 = agent1.run_sync(...)
        - result2 = agent2.run_sync(result1.data, ...)

        Args:
            tree: AST module
            agent_vars: Map of variable names to agent objects

        Returns:
            List of detected connections
        """
        connections: list[DetectedConnection] = []

        # Track which variables hold agent results
        result_vars: dict[str, str] = {}  # result_var -> agent_var

        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        # Check for agent.run_sync() or agent.run() patterns
                        if isinstance(node.value.func, ast.Attribute):
                            if node.value.func.attr in ("run_sync", "run"):
                                if isinstance(node.value.func.value, ast.Name):
                                    agent_name = node.value.func.value.id
                                    if agent_name in agent_vars:
                                        result_vars[target.id] = agent_name

                                        # Check if any argument references a previous result
                                        for arg in node.value.args:
                                            source_agent = self._find_result_source(
                                                arg, result_vars
                                            )
                                            if source_agent and source_agent in agent_vars:
                                                connections.append(
                                                    DetectedConnection(
                                                        source_id=agent_vars[source_agent].id,
                                                        target_id=agent_vars[agent_name].id,
                                                        connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                                                        confidence=0.95,
                                                        confidence_level=ConnectionConfidence.FRAMEWORK,
                                                        evidence=[
                                                            f"PydanticAI agent chain: {source_agent}.run() -> {agent_name}.run()"
                                                        ],
                                                    )
                                                )

        return connections

    def _find_result_source(self, node: ast.AST, result_vars: dict[str, str]) -> str | None:
        """Find if an AST node references a previous agent result.

        Args:
            node: AST node to check
            result_vars: Map of result variables to their source agents

        Returns:
            Source agent name or None
        """
        if isinstance(node, ast.Name):
            return result_vars.get(node.id)
        elif isinstance(node, ast.Attribute):
            # Check for result.data or result.output patterns
            if isinstance(node.value, ast.Name):
                return result_vars.get(node.value.id)
        return None
