"""Scanner registration module for all framework scanners.

This module registers all available scanners with the ScannerRegistry,
including both existing scanners and new Tier 1/Tier 2 scanners.
"""

from __future__ import annotations

from vantage_core.scanners.registry import ScannerMetadata, ScannerRegistry


def register_all_scanners() -> None:
    """Register all available framework scanners with the registry.

    This function registers scanners with their metadata including:
    - Import patterns for framework detection
    - File patterns to scan
    - Priority (lower = higher priority)
    - Config file patterns
    """

    # ==========================================================================
    # Existing Scanners
    # ==========================================================================

    ScannerRegistry.register(
        ScannerMetadata(
            name="crewai",
            scanner_class="vantage_core.scanners.crewai_scanner.CrewAIScanner",
            import_patterns=["from crewai", "import crewai"],
            config_files=["agents.yaml", "tasks.yaml"],
            priority=10,
        )
    )

    ScannerRegistry.register(
        ScannerMetadata(
            name="autogen",
            scanner_class="vantage_core.scanners.autogen_scanner.AutoGenScanner",
            import_patterns=[
                "from autogen",
                "import autogen",
                "from pyautogen",
                "import pyautogen",
            ],
            priority=10,
        )
    )

    ScannerRegistry.register(
        ScannerMetadata(
            name="langgraph",
            scanner_class="vantage_core.scanners.langgraph_scanner.LangGraphScanner",
            import_patterns=["from langgraph", "import langgraph"],
            priority=20,
        )
    )

    ScannerRegistry.register(
        ScannerMetadata(
            name="langchain",
            scanner_class="vantage_core.scanners.langchain_scanner.LangChainScanner",
            import_patterns=[
                "from langchain",
                "import langchain",
                "from langchain_core",
                "from langchain_openai",
            ],
            priority=30,
        )
    )

    ScannerRegistry.register(
        ScannerMetadata(
            name="openai",
            scanner_class="vantage_core.scanners.openai_scanner.OpenAIScanner",
            import_patterns=[
                "from openai",
                "import openai",
                "from swarm",
                "import swarm",
            ],
            file_patterns=["*.py", "*.json"],
            priority=20,
        )
    )

    # Register LlamaIndex
    ScannerRegistry.register(
        ScannerMetadata(
            name="llamaindex",
            scanner_class="vantage_core.scanners.llamaindex_scanner.LlamaIndexScanner",
            import_patterns=[
                "from llama_index",
                "import llama_index",
                "from llama_index.core.agent",
                "from llama_index.agent",
                "from llama_index.core.workflow",
                "from llama_index.core.query_engine",
                "from llama_index.core.chat_engine",
                "from llama_hub",
                "import llama_hub",
            ],
            priority=15,
        )
    )

    # ==========================================================================
    # Tier 1 New Scanners
    # ==========================================================================

    ScannerRegistry.register(
        ScannerMetadata(
            name="pydanticai",
            scanner_class="vantage_core.scanners.pydanticai_scanner.PydanticAIScanner",
            import_patterns=[
                "from pydantic_ai",
                "import pydantic_ai",
                "from pydantic_ai.agent",
                "from pydantic_ai import Agent",
            ],
            priority=15,
        )
    )

    ScannerRegistry.register(
        ScannerMetadata(
            name="googleadk",
            scanner_class="vantage_core.scanners.google_adk_scanner.GoogleADKScanner",
            import_patterns=[
                "from google.adk",
                "import google.adk",
                "from google.adk.agents",
                "from google.adk.tools",
                "from google_adk",
                "import google_adk",
            ],
            priority=15,
        )
    )

    ScannerRegistry.register(
        ScannerMetadata(
            name="metagpt",
            scanner_class="vantage_core.scanners.metagpt_scanner.MetaGPTScanner",
            import_patterns=[
                "from metagpt",
                "import metagpt",
                "from metagpt.roles",
                "from metagpt.team",
                "from metagpt.actions",
            ],
            priority=15,
        )
    )

    ScannerRegistry.register(
        ScannerMetadata(
            name="semantickernel",
            scanner_class="vantage_core.scanners.semantic_kernel_scanner.SemanticKernelScanner",
            import_patterns=[
                "from semantic_kernel",
                "import semantic_kernel",
                "from semantic_kernel.agents",
                "from semantic_kernel.planners",
                "from semantic_kernel.connectors",
            ],
            priority=15,
        )
    )

    # ==========================================================================
    # Tier 2 New Scanners
    # ==========================================================================

    ScannerRegistry.register(
        ScannerMetadata(
            name="smolagents",
            scanner_class="vantage_core.scanners.smolagents_scanner.SmolagentsScanner",
            import_patterns=[
                "from smolagents",
                "import smolagents",
                "from smolagents import",
            ],
            priority=25,
        )
    )

    ScannerRegistry.register(
        ScannerMetadata(
            name="agno",
            scanner_class="vantage_core.scanners.agno_scanner.AgnoScanner",
            import_patterns=[
                "from agno",
                "import agno",
                "from phidata",
                "import phidata",
                "from phi.agent",
                "from phi.assistant",
            ],
            priority=25,
        )
    )

    ScannerRegistry.register(
        ScannerMetadata(
            name="dify",
            scanner_class="vantage_core.scanners.dify_scanner.DifyScanner",
            import_patterns=[
                "from dify",
                "import dify",
                "DifyClient",
            ],
            file_patterns=["*.py", "*.yaml", "*.yml", "*.json"],
            config_files=["dify.yaml", "dify.json"],
            priority=25,
        )
    )

    ScannerRegistry.register(
        ScannerMetadata(
            name="dspy",
            scanner_class="vantage_core.scanners.dspy_scanner.DSPyScanner",
            import_patterns=[
                "from dspy",
                "import dspy",
                "dspy.Module",
                "dspy.Signature",
            ],
            priority=25,
        )
    )

    # ==========================================================================
    # Custom Framework Scanners (Browser Automation & Software Development)
    # ==========================================================================

    ScannerRegistry.register(
        ScannerMetadata(
            name="browseruse",
            scanner_class="vantage_core.scanners.browseruse_scanner.BrowserUseScanner",
            import_patterns=[
                "from browser_use",
                "import browser_use",
                "from browser_use.agent",
                "from browser_use.tools",
                "from browser_use.llm",
            ],
            file_patterns=["*.py"],
            priority=20,
        )
    )

    ScannerRegistry.register(
        ScannerMetadata(
            name="openhands",
            scanner_class="vantage_core.scanners.openhands_scanner.OpenHandsScanner",
            import_patterns=[
                "from openhands",
                "import openhands",
                "from openhands.controller",
                "from openhands.agenthub",
                "from openhands.core.config",
                "from opendevin",
                "import opendevin",
            ],
            file_patterns=["*.py"],
            config_files=["config.toml"],
            priority=20,
        )
    )

    ScannerRegistry.register(
        ScannerMetadata(
            name="skyvern",
            scanner_class="vantage_core.scanners.skyvern_scanner.SkyvernScanner",
            import_patterns=[
                "from skyvern",
                "import skyvern",
                "from skyvern.forge",
                "from skyvern_llamaindex",
                "from skyvern_langchain",
            ],
            file_patterns=["*.py", "*.yaml", "*.yml"],
            config_files=["workflow.yaml", "workflow.yml"],
            priority=20,
        )
    )


# Auto-register on module import
register_all_scanners()
