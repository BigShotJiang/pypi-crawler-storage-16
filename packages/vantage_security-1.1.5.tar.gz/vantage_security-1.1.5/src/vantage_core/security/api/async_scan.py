"""
Asynchronous Scan Job Management for Vantage Security API.

This module provides job queue management for async security scans,
including job submission, status tracking, and result retrieval.
"""

import threading
import uuid
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from vantage_core.security.api.models import WebhookConfig


@dataclass
class ScanJob:
    """Represents an async scan job."""

    scan_id: str
    path: Path
    config: Any  # PipelineConfig
    status: str = "pending"
    result: Any | None = None  # PipelineResult
    error: str | None = None
    created_at: datetime = field(default_factory=datetime.utcnow)
    started_at: datetime | None = None
    completed_at: datetime | None = None
    webhook: WebhookConfig | None = None


class ScanJobManager:
    """
    Manages async scan jobs.

    Provides job submission, status tracking, and result retrieval
    with background execution support.
    """

    def __init__(self, max_workers: int = 4):
        """
        Initialize job manager.

        Args:
            max_workers: Maximum concurrent scan workers
        """
        self._jobs: dict[str, ScanJob] = {}
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        self._lock = threading.Lock()
        self._callbacks: dict[str, list[Callable]] = {}

    def submit(
        self,
        path: Path,
        config: Any,
        webhook: WebhookConfig | None = None,
        scan_id: str | None = None,
    ) -> ScanJob:
        """
        Submit a new scan job.

        Args:
            path: Path to scan
            config: Pipeline configuration
            webhook: Optional webhook for notifications
            scan_id: Optional custom scan ID

        Returns:
            Created scan job
        """
        if scan_id is None:
            scan_id = str(uuid.uuid4())

        job = ScanJob(
            scan_id=scan_id,
            path=path,
            config=config,
            webhook=webhook,
        )

        with self._lock:
            self._jobs[scan_id] = job

        # Submit to executor
        self._executor.submit(self._run_scan, job)

        return job

    def _run_scan(self, job: ScanJob) -> None:
        """
        Execute scan in background thread.

        Args:
            job: Scan job to execute
        """
        try:
            job.status = "running"
            job.started_at = datetime.utcnow()

            # Import here to avoid circular imports
            from vantage_core.security.pipeline.orchestrator import SecurityPipeline

            pipeline = SecurityPipeline(job.config)
            result = pipeline.scan(job.path, job.config)

            job.result = result
            job.status = "completed" if result.is_success else "failed"
            job.completed_at = datetime.utcnow()

            if not result.is_success and result.errors:
                job.error = "; ".join(result.errors)

        except Exception as e:
            job.status = "failed"
            job.error = str(e)
            job.completed_at = datetime.utcnow()

        finally:
            # Trigger webhook if configured
            if job.webhook:
                self._send_webhook(job)

            # Run callbacks
            self._run_callbacks(job.scan_id)

    def _send_webhook(self, job: ScanJob) -> None:
        """
        Send webhook notification for completed job.

        Args:
            job: Completed scan job
        """
        if not job.webhook:
            return

        try:
            import hashlib
            import hmac
            import json

            import httpx

            payload = {
                "event": f"scan.{job.status}",
                "scan_id": job.scan_id,
                "status": job.status,
                "completed_at": (job.completed_at.isoformat() if job.completed_at else None),
            }

            if job.result:
                payload["score"] = (
                    job.result.atss_result.overall_score if job.result.atss_result else None
                )
                payload["grade"] = job.result.atss_result.grade if job.result.atss_result else None
                payload["findings_count"] = (
                    len(job.result.scan_result.findings) if job.result.scan_result else 0
                )

            headers = {"Content-Type": "application/json"}

            # Add signature if secret provided
            if job.webhook.secret:
                body = json.dumps(payload)
                signature = hmac.new(
                    job.webhook.secret.encode(),
                    body.encode(),
                    hashlib.sha256,
                ).hexdigest()
                headers["X-Signature"] = f"sha256={signature}"

            with httpx.Client() as client:
                client.post(
                    job.webhook.url,
                    json=payload,
                    headers=headers,
                    timeout=30,
                )

        except Exception:
            # Log error but don't fail the job
            pass

    def _run_callbacks(self, scan_id: str) -> None:
        """
        Run registered callbacks for a job.

        Args:
            scan_id: Scan ID to run callbacks for
        """
        callbacks = self._callbacks.pop(scan_id, [])
        for callback in callbacks:
            try:
                callback(self._jobs.get(scan_id))
            except Exception:
                pass

    def get_job(self, scan_id: str) -> ScanJob | None:
        """
        Get job by ID.

        Args:
            scan_id: Scan ID to retrieve

        Returns:
            Scan job if found, None otherwise
        """
        return self._jobs.get(scan_id)

    def list_jobs(
        self,
        status: str | None = None,
        limit: int = 100,
    ) -> list[ScanJob]:
        """
        List scan jobs.

        Args:
            status: Optional status filter
            limit: Maximum jobs to return

        Returns:
            List of scan jobs
        """
        with self._lock:
            jobs = list(self._jobs.values())

        if status:
            jobs = [j for j in jobs if j.status == status]

        # Sort by created_at descending
        jobs.sort(key=lambda j: j.created_at, reverse=True)

        return jobs[:limit]

    def cancel_job(self, scan_id: str) -> bool:
        """
        Cancel a running job.

        Args:
            scan_id: Scan ID to cancel

        Returns:
            True if job was cancelled
        """
        job = self._jobs.get(scan_id)
        if not job:
            return False

        if job.status == "running":
            job.status = "cancelled"
            job.completed_at = datetime.utcnow()
            return True

        return False

    def delete_job(self, scan_id: str) -> bool:
        """
        Delete a job from storage.

        Args:
            scan_id: Scan ID to delete

        Returns:
            True if job was deleted
        """
        with self._lock:
            if scan_id in self._jobs:
                del self._jobs[scan_id]
                return True
        return False

    def on_complete(self, scan_id: str, callback: Callable) -> None:
        """
        Register callback for job completion.

        Args:
            scan_id: Scan ID to watch
            callback: Function to call with job on completion
        """
        job = self._jobs.get(scan_id)
        if job and job.status in ("completed", "failed", "cancelled"):
            # Already done, call immediately
            callback(job)
        else:
            if scan_id not in self._callbacks:
                self._callbacks[scan_id] = []
            self._callbacks[scan_id].append(callback)

    def cleanup_old_jobs(self, max_age_hours: int = 24) -> int:
        """
        Remove old completed jobs.

        Args:
            max_age_hours: Maximum age in hours

        Returns:
            Number of jobs removed
        """
        from datetime import timedelta

        cutoff = datetime.utcnow() - timedelta(hours=max_age_hours)
        removed = 0

        with self._lock:
            to_remove = []
            for scan_id, job in self._jobs.items():
                if job.completed_at and job.completed_at < cutoff:
                    to_remove.append(scan_id)

            for scan_id in to_remove:
                del self._jobs[scan_id]
                removed += 1

        return removed

    def shutdown(self) -> None:
        """Shutdown the executor."""
        self._executor.shutdown(wait=True)


# Global job manager instance
job_manager = ScanJobManager()
