"""
Authentication and Authorization for Vantage Security API.

This module provides API key verification, JWT validation,
rate limiting, and scope-based authorization.
"""

import hashlib
import secrets
import time
from collections import defaultdict
from collections.abc import Callable
from datetime import datetime
from typing import Any

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import APIKeyHeader, HTTPAuthorizationCredentials, HTTPBearer

try:
    from jose import JWTError, jwt

    JOSE_AVAILABLE = True
except ImportError:
    JOSE_AVAILABLE = False
    jwt = None
    JWTError = Exception

from vantage_core.security.api.config import get_settings

# Security schemes
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)
bearer_scheme = HTTPBearer(auto_error=False)


# In-memory storage (replace with Redis/database in production)
_api_keys: dict[str, dict] = {}
_rate_limit_buckets: dict[str, dict] = defaultdict(lambda: {"count": 0, "reset_at": 0})


def generate_api_key() -> tuple[str, str]:
    """
    Generate a new API key.

    Returns:
        Tuple of (plain_key, key_hash)
    """
    key = f"ask_{secrets.token_urlsafe(32)}"
    key_hash = hashlib.sha256(key.encode()).hexdigest()
    return key, key_hash


def store_api_key(
    user_id: str,
    key_hash: str,
    name: str,
    scopes: list[str],
    expires_at: datetime | None = None,
) -> dict:
    """
    Store an API key in memory.

    Args:
        user_id: Owner user ID
        key_hash: SHA-256 hash of the key
        name: Key name/description
        scopes: Allowed scopes
        expires_at: Optional expiration datetime

    Returns:
        Key metadata
    """
    key_data = {
        "user_id": user_id,
        "name": name,
        "scopes": scopes,
        "created_at": datetime.utcnow(),
        "expires_at": expires_at,
        "last_used": None,
        "is_active": True,
    }
    _api_keys[key_hash] = key_data
    return key_data


async def verify_api_key(
    api_key: str | None = Security(api_key_header),
) -> dict[str, Any]:
    """
    Verify API key and return key data.

    Args:
        api_key: API key from header

    Returns:
        Dictionary with user_id, scopes, and other key metadata

    Raises:
        HTTPException: If key is invalid, expired, or missing
    """
    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key required",
            headers={"WWW-Authenticate": "ApiKey"},
        )

    key_hash = hashlib.sha256(api_key.encode()).hexdigest()
    key_data = _api_keys.get(key_hash)

    if not key_data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API key",
        )

    if not key_data.get("is_active"):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key has been revoked",
        )

    if key_data.get("expires_at"):
        if datetime.utcnow() > key_data["expires_at"]:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="API key has expired",
            )

    # Update last used
    key_data["last_used"] = datetime.utcnow()

    return {
        "user_id": key_data["user_id"],
        "scopes": key_data["scopes"],
        "key_name": key_data["name"],
    }


async def verify_jwt_token(
    credentials: HTTPAuthorizationCredentials | None = Security(bearer_scheme),
) -> dict[str, Any]:
    """
    Verify JWT bearer token.

    Args:
        credentials: Bearer token credentials

    Returns:
        Token payload

    Raises:
        HTTPException: If token is invalid or expired
    """
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Bearer token required",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not JOSE_AVAILABLE:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="JWT support not available",
        )

    settings = get_settings()

    try:
        payload = jwt.decode(
            credentials.credentials,
            settings.auth.secret_key,
            algorithms=[settings.auth.algorithm],
        )

        if payload.get("type") != "access":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token type",
            )

        return payload

    except JWTError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid token: {str(e)}",
        )


def require_scope(*required_scopes: str) -> Callable:
    """
    Dependency factory for scope-based authorization.

    Args:
        required_scopes: Scopes that are required (any one of them)

    Returns:
        Dependency function
    """

    async def scope_checker(
        key_data: dict = Depends(verify_api_key),
    ) -> dict:
        user_scopes = set(key_data.get("scopes", []))

        # Check if user has any of the required scopes
        if not user_scopes.intersection(required_scopes):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Required scope: {' or '.join(required_scopes)}",
            )

        return key_data

    return scope_checker


async def rate_limit(
    api_key: str | None = Security(api_key_header),
) -> dict[str, Any]:
    """
    Apply rate limiting to requests.

    Args:
        api_key: API key for rate limit tracking

    Returns:
        Key data if rate limit not exceeded

    Raises:
        HTTPException: If rate limit exceeded
    """
    # First verify the key
    key_data = await verify_api_key(api_key)

    settings = get_settings()
    if not settings.rate_limit.enabled:
        return key_data

    # Get rate limit bucket
    key_hash = hashlib.sha256(api_key.encode()).hexdigest()
    bucket = _rate_limit_buckets[key_hash]
    current_time = time.time()

    # Reset bucket if window expired
    if current_time > bucket["reset_at"]:
        bucket["count"] = 0
        bucket["reset_at"] = current_time + 3600  # 1 hour window

    # Check limit
    limit = settings.rate_limit.default_requests_per_hour
    if bucket["count"] >= limit:
        retry_after = int(bucket["reset_at"] - current_time)
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Rate limit exceeded. Retry after {retry_after} seconds.",
            headers={"Retry-After": str(retry_after)},
        )

    # Increment counter
    bucket["count"] += 1

    return key_data


def get_current_user(
    key_data: dict = Depends(verify_api_key),
) -> str:
    """
    Get the current user ID from API key.

    Args:
        key_data: Verified API key data

    Returns:
        User ID string
    """
    return key_data["user_id"]


class AuthMiddleware:
    """
    Middleware for authentication and logging.

    Provides request-level authentication and audit logging.
    """

    def __init__(self, app):
        """Initialize middleware."""
        self.app = app

    async def __call__(self, scope, receive, send):
        """Process request through middleware."""
        if scope["type"] == "http":
            # Could add audit logging here
            pass

        await self.app(scope, receive, send)


# Utility functions for testing
def create_test_api_key(
    user_id: str = "test-user",
    scopes: list[str] | None = None,
) -> str:
    """
    Create a test API key for development/testing.

    Args:
        user_id: User ID to associate with key
        scopes: Scopes to grant (defaults to all)

    Returns:
        Plain text API key
    """
    if scopes is None:
        scopes = ["scan:read", "scan:write", "report:read", "admin"]

    key, key_hash = generate_api_key()
    store_api_key(
        user_id=user_id,
        key_hash=key_hash,
        name="Test Key",
        scopes=scopes,
    )
    return key


def revoke_api_key(key_hash: str) -> bool:
    """
    Revoke an API key.

    Args:
        key_hash: Hash of the key to revoke

    Returns:
        True if key was found and revoked
    """
    if key_hash in _api_keys:
        _api_keys[key_hash]["is_active"] = False
        return True
    return False
