"""
Configuration management using Pydantic Settings.

All configuration is loaded from environment variables with validation.
No hardcoded defaults for secrets - application will fail fast if required
configuration is missing.
"""

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class DatabaseSettings(BaseSettings):
    """Database configuration."""

    model_config = SettingsConfigDict(env_prefix="DATABASE_")

    url: str = Field(
        default="postgresql+asyncpg://user:password@localhost:5432/vantage",
        description="PostgreSQL connection URL",
    )
    pool_size: int = Field(default=5, ge=1, le=20)
    max_overflow: int = Field(default=10, ge=0, le=50)
    echo: bool = Field(default=False, description="Log SQL queries")


class AuthSettings(BaseSettings):
    """Authentication configuration."""

    model_config = SettingsConfigDict(env_prefix="AUTH_")

    # JWT - NO DEFAULT for secret_key - MUST be set via environment
    secret_key: str = Field(
        ...,
        min_length=32,
        description="JWT signing key (min 32 chars) - REQUIRED",
    )
    algorithm: str = Field(default="HS256")
    access_token_expire_minutes: int = Field(default=15, ge=5, le=60)
    refresh_token_expire_days: int = Field(default=7, ge=1, le=30)

    # Password Policy
    password_min_length: int = Field(default=12, ge=8)
    password_require_uppercase: bool = Field(default=True)
    password_require_lowercase: bool = Field(default=True)
    password_require_digit: bool = Field(default=True)
    password_require_special: bool = Field(default=True)
    bcrypt_rounds: int = Field(default=12, ge=10, le=14)

    # Account Security
    max_login_attempts: int = Field(default=5, ge=3, le=10)
    lockout_duration_minutes: int = Field(default=15, ge=5, le=60)

    # MFA
    mfa_issuer: str = Field(default="Vantage")

    @field_validator("secret_key")
    @classmethod
    def validate_secret_key(cls, v: str) -> str:
        """Validate that SECRET_KEY is properly configured."""
        # Check for common placeholder values
        forbidden_values = [
            "your-secret-key-change-in-production",
            "changeme",
            "secret",
            "your-secret-key",
            "change-me",
            "placeholder",
        ]
        if v.lower() in [fv.lower() for fv in forbidden_values]:
            raise ValueError(
                "AUTH_SECRET_KEY must be changed from default placeholder value. "
                'Generate a secure key with: python -c "import secrets; print(secrets.token_urlsafe(32))"'
            )
        if len(v) < 32:
            raise ValueError("AUTH_SECRET_KEY must be at least 32 characters")
        return v


class OAuthSettings(BaseSettings):
    """OAuth provider configuration."""

    model_config = SettingsConfigDict(env_prefix="OAUTH_")

    # GitHub (required for GitHub integration)
    github_client_id: str = Field(default="", description="GitHub OAuth App client ID")
    github_client_secret: str = Field(default="", description="GitHub OAuth App client secret")

    # Google (optional)
    google_client_id: str = Field(default="")
    google_client_secret: str = Field(default="")


class GitHubAppSettings(BaseSettings):
    """GitHub App configuration."""

    model_config = SettingsConfigDict(env_prefix="GITHUB_APP_")

    app_id: str = Field(default="", description="GitHub App ID")
    private_key: str = Field(default="", description="GitHub App private key (PEM)")
    webhook_secret: str = Field(default="", description="Webhook signature secret")


class RedisSettings(BaseSettings):
    """Redis configuration (optional)."""

    model_config = SettingsConfigDict(env_prefix="REDIS_")

    url: str = Field(default="", description="Redis connection URL")
    enabled: bool = Field(default=False)


class RateLimitSettings(BaseSettings):
    """Rate limiting configuration."""

    model_config = SettingsConfigDict(env_prefix="RATE_LIMIT_")

    enabled: bool = Field(default=True)
    default_requests_per_hour: int = Field(default=1000, description="Default requests per hour")
    auth_requests_per_minute: int = Field(
        default=10, description="Auth endpoint requests per minute"
    )


class Settings(BaseSettings):
    """Main application settings."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Application
    app_name: str = Field(default="Vantage")
    debug: bool = Field(default=False)
    environment: Literal["development", "staging", "production"] = Field(default="development")
    log_level: str = Field(default="INFO")

    # API
    api_v1_prefix: str = Field(default="/api/v1")
    cors_origins: list[str] = Field(default_factory=lambda: ["http://localhost:3000"])

    # File Upload
    max_upload_size_mb: int = Field(default=50, ge=1, le=500)
    allowed_upload_extensions: list[str] = Field(default_factory=lambda: [".py", ".zip", ".tar.gz"])

    # Feature Flags
    use_database: bool = Field(default=True, description="Use database instead of in-memory")
    enable_mfa: bool = Field(default=True)
    enable_oauth: bool = Field(default=True)

    # Nested settings
    database: DatabaseSettings = Field(default_factory=DatabaseSettings)
    auth: AuthSettings = Field(default_factory=AuthSettings)
    oauth: OAuthSettings = Field(default_factory=OAuthSettings)
    github_app: GitHubAppSettings = Field(default_factory=GitHubAppSettings)
    redis: RedisSettings = Field(default_factory=RedisSettings)
    rate_limit: RateLimitSettings = Field(default_factory=RateLimitSettings)


@lru_cache
def get_settings() -> Settings:
    """
    Get cached application settings.

    This function will raise a validation error if required settings
    (like AUTH_SECRET_KEY) are not properly configured.

    Returns:
        Settings: Application settings instance

    Raises:
        pydantic.ValidationError: If required settings are missing or invalid
    """
    return Settings()


def validate_settings_at_startup() -> None:
    """
    Validate all settings at application startup.

    Call this function during application initialization to fail fast
    if configuration is invalid.

    Raises:
        RuntimeError: If critical configuration is missing or invalid
    """
    try:
        settings = get_settings()

        # Additional runtime validations
        if settings.environment == "production":
            if not settings.auth.secret_key or len(settings.auth.secret_key) < 32:
                raise RuntimeError("AUTH_SECRET_KEY must be set in production environment")

            if settings.debug:
                raise RuntimeError("DEBUG must be False in production environment")

        return settings

    except Exception as e:
        raise RuntimeError(f"Configuration validation failed: {e}") from e
