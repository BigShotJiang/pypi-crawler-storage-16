"""
Role-Based Access Control (RBAC) for Vantage Security Platform.

This module provides role definitions, permission enforcement middleware,
project-level role assignment, and audit logging for access decisions.
"""

from collections.abc import Callable
from datetime import datetime
from enum import Enum
from functools import wraps
from typing import Any
from uuid import UUID

from fastapi import HTTPException, Request, status


class Role(str, Enum):
    """User roles for RBAC."""

    ADMIN = "admin"
    SECURITY_ENGINEER = "security_engineer"
    DEVELOPER = "developer"
    VIEWER = "viewer"


# Permission definitions per role
PERMISSIONS: dict[Role, list[str]] = {
    Role.ADMIN: ["*"],  # All permissions
    Role.SECURITY_ENGINEER: [
        "scan:create",
        "scan:read",
        "scan:delete",
        "scan:compare",
        "findings:read",
        "findings:triage",
        "findings:export",
        "reports:generate",
        "reports:read",
        "policies:create",
        "policies:read",
        "policies:update",
        "policies:delete",
        "projects:read",
        "projects:update",
        "webhooks:create",
        "webhooks:read",
        "webhooks:update",
        "webhooks:delete",
        "dashboard:read",
        "topology:read",
        "scores:read",
    ],
    Role.DEVELOPER: [
        "scan:create",
        "scan:read",
        "findings:read",
        "reports:read",
        "remediation:read",
        "projects:read",
        "dashboard:read",
        "topology:read",
        "scores:read",
    ],
    Role.VIEWER: [
        "scan:read",
        "findings:read",
        "dashboard:read",
        "topology:read",
        "scores:read",
        "projects:read",
    ],
}


# Webhook event types
WEBHOOK_EVENTS = [
    "scan.started",
    "scan.completed",
    "scan.failed",
    "vulnerability.critical",
    "vulnerability.high",
    "score.improved",
    "score.regression",
    "policy.violation",
]


class RBACService:
    """Service for managing role-based access control."""

    def __init__(self, db_session=None, audit_logger=None):
        """Initialize RBAC service."""
        self.db = db_session
        self.audit_logger = audit_logger or AuditLogger()

    def has_permission(self, role: Role, permission: str) -> bool:
        """
        Check if a role has a specific permission.

        Args:
            role: User role
            permission: Permission string (e.g., "scan:create")

        Returns:
            True if role has permission
        """
        permissions = PERMISSIONS.get(role, [])

        # Admin has all permissions
        if "*" in permissions:
            return True

        # Check exact match
        if permission in permissions:
            return True

        # Check wildcard match (e.g., "scan:*" matches "scan:create")
        permission_parts = permission.split(":")
        if len(permission_parts) == 2:
            wildcard = f"{permission_parts[0]}:*"
            if wildcard in permissions:
                return True

        return False

    def check_permission(
        self,
        user_id: str | UUID,
        permission: str,
        project_id: str | UUID | None = None,
        resource_type: str = "system",
        resource_id: str | UUID | None = None,
    ) -> bool:
        """
        Check if user has permission, with optional project context.

        Args:
            user_id: User identifier
            permission: Permission to check
            project_id: Optional project context
            resource_type: Type of resource being accessed
            resource_id: ID of specific resource

        Returns:
            True if permission granted
        """
        # Get user's role for the context
        role = self._get_user_role(user_id, project_id)

        if role is None:
            self.audit_logger.log_decision(
                user_id=user_id,
                action=permission,
                resource_type=resource_type,
                resource_id=resource_id,
                outcome="denied",
                metadata={
                    "reason": "no_role_assigned",
                    "project_id": str(project_id) if project_id else None,
                },
            )
            return False

        has_perm = self.has_permission(role, permission)

        self.audit_logger.log_decision(
            user_id=user_id,
            action=permission,
            resource_type=resource_type,
            resource_id=resource_id,
            outcome="success" if has_perm else "denied",
            metadata={
                "role": role.value,
                "project_id": str(project_id) if project_id else None,
            },
        )

        return has_perm

    def _get_user_role(
        self,
        user_id: str | UUID,
        project_id: str | UUID | None = None,
    ) -> Role | None:
        """
        Get user's role, considering project-level overrides.

        Args:
            user_id: User identifier
            project_id: Optional project for project-specific role

        Returns:
            User's role or None if not found
        """
        if self.db is None:
            # Default to viewer for testing without DB
            return Role.VIEWER

        # TODO: Implement actual database lookup
        # For now, return a default role
        if project_id:
            # Check project membership
            # member = self.db.query(ProjectMember).filter_by(
            #     project_id=project_id, user_id=user_id
            # ).first()
            # if member:
            #     return Role(member.role)
            pass

        # Fall back to system-wide role (from user table or default)
        return Role.VIEWER

    def get_user_permissions(
        self,
        user_id: str | UUID,
        project_id: str | UUID | None = None,
    ) -> list[str]:
        """
        Get all permissions for a user.

        Args:
            user_id: User identifier
            project_id: Optional project context

        Returns:
            List of permission strings
        """
        role = self._get_user_role(user_id, project_id)
        if role is None:
            return []

        permissions = PERMISSIONS.get(role, [])
        if "*" in permissions:
            # Return all possible permissions for admin
            all_perms = set()
            for role_perms in PERMISSIONS.values():
                for perm in role_perms:
                    if perm != "*":
                        all_perms.add(perm)
            return sorted(all_perms)

        return permissions

    def assign_role(
        self,
        user_id: str | UUID,
        project_id: str | UUID,
        role: Role,
        assigned_by: str | UUID,
    ) -> None:
        """
        Assign a role to a user for a project.

        Args:
            user_id: User to assign role to
            project_id: Project context
            role: Role to assign
            assigned_by: User making the assignment
        """
        if self.db is not None:
            # TODO: Implement actual database update
            # Check if membership exists, update or create
            pass

        # Always log the role assignment
        self.audit_logger.log_decision(
            user_id=assigned_by,
            action="role:assign",
            resource_type="project_member",
            resource_id=user_id,
            outcome="success",
            metadata={
                "project_id": str(project_id),
                "target_user_id": str(user_id),
                "role": role.value,
            },
        )

    def remove_role(
        self,
        user_id: str | UUID,
        project_id: str | UUID,
        removed_by: str | UUID,
    ) -> None:
        """
        Remove a user's role from a project.

        Args:
            user_id: User to remove
            project_id: Project context
            removed_by: User making the removal
        """
        if self.db is not None:
            # TODO: Implement actual database removal
            pass

        # Always log the role removal
        self.audit_logger.log_decision(
            user_id=removed_by,
            action="role:remove",
            resource_type="project_member",
            resource_id=user_id,
            outcome="success",
            metadata={"project_id": str(project_id), "target_user_id": str(user_id)},
        )


class AuditLogger:
    """Logger for RBAC audit decisions."""

    def __init__(self, db_session=None):
        """Initialize audit logger."""
        self.db = db_session
        self._logs: list[dict] = []  # In-memory store for testing

    def log_decision(
        self,
        user_id: str | UUID | None,
        action: str,
        resource_type: str,
        resource_id: str | UUID | None,
        outcome: str,
        metadata: dict[str, Any] | None = None,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> None:
        """
        Log an authorization decision.

        Args:
            user_id: User making the request
            action: Action being attempted
            resource_type: Type of resource
            resource_id: Specific resource ID
            outcome: Decision outcome (success, denied, error)
            metadata: Additional context
            ip_address: Request IP address
            user_agent: Request user agent
        """
        log_entry = {
            "user_id": str(user_id) if user_id else None,
            "action": action,
            "resource_type": resource_type,
            "resource_id": str(resource_id) if resource_id else None,
            "outcome": outcome,
            "ip_address": ip_address,
            "user_agent": user_agent,
            "metadata": metadata or {},
            "created_at": datetime.utcnow().isoformat(),
        }

        # Store in memory for testing
        self._logs.append(log_entry)

        if self.db is not None:
            # TODO: Write to database
            # from .database_models import AuditLog
            # audit_log = AuditLog(**log_entry)
            # self.db.add(audit_log)
            # self.db.commit()
            pass

    def get_logs(
        self,
        user_id: str | UUID | None = None,
        action: str | None = None,
        resource_type: str | None = None,
        limit: int = 100,
    ) -> list[dict]:
        """
        Retrieve audit logs with optional filters.

        Args:
            user_id: Filter by user
            action: Filter by action
            resource_type: Filter by resource type
            limit: Maximum number of logs

        Returns:
            List of audit log entries
        """
        logs = self._logs

        if user_id:
            logs = [l for l in logs if l["user_id"] == str(user_id)]
        if action:
            logs = [l for l in logs if l["action"] == action]
        if resource_type:
            logs = [l for l in logs if l["resource_type"] == resource_type]

        return logs[-limit:]


def require_permission(permission: str):
    """
    Decorator to enforce permission on route handlers.

    Usage:
        @require_permission("scan:create")
        async def create_scan(...):
            ...
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Get request from kwargs or first arg
            request = kwargs.get("request")
            if request is None:
                for arg in args:
                    if isinstance(arg, Request):
                        request = arg
                        break

            if request is None:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Request object not found",
                )

            # Get user from request state (set by auth middleware)
            user = getattr(request.state, "user", None)
            if user is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Authentication required",
                )

            # Get project_id from path or query params
            project_id = kwargs.get("project_id")
            if project_id is None:
                project_id = request.path_params.get("project_id")
            if project_id is None:
                project_id = request.query_params.get("project_id")

            # Get RBAC service from app state
            rbac = getattr(request.app.state, "rbac", None)
            if rbac is None:
                rbac = RBACService()

            # Check permission
            if not rbac.check_permission(
                user_id=user.get("id") or user.get("user_id"),
                permission=permission,
                project_id=project_id,
                resource_type=permission.split(":")[0],
            ):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Permission denied: {permission}",
                )

            return await func(*args, **kwargs)

        return wrapper

    return decorator


def check_project_access(project_id: str | UUID, user_id: str | UUID, rbac: RBACService) -> bool:
    """
    Check if user has any access to a project.

    Args:
        project_id: Project identifier
        user_id: User identifier
        rbac: RBAC service instance

    Returns:
        True if user has access
    """
    return rbac.check_permission(
        user_id=user_id,
        permission="projects:read",
        project_id=project_id,
    )


# Permission constants for type safety
class Permission:
    """Permission string constants."""

    # Scan permissions
    SCAN_CREATE = "scan:create"
    SCAN_READ = "scan:read"
    SCAN_DELETE = "scan:delete"
    SCAN_COMPARE = "scan:compare"

    # Findings permissions
    FINDINGS_READ = "findings:read"
    FINDINGS_TRIAGE = "findings:triage"
    FINDINGS_EXPORT = "findings:export"

    # Reports permissions
    REPORTS_GENERATE = "reports:generate"
    REPORTS_READ = "reports:read"

    # Projects permissions
    PROJECTS_CREATE = "projects:create"
    PROJECTS_READ = "projects:read"
    PROJECTS_UPDATE = "projects:update"
    PROJECTS_DELETE = "projects:delete"

    # Webhooks permissions
    WEBHOOKS_CREATE = "webhooks:create"
    WEBHOOKS_READ = "webhooks:read"
    WEBHOOKS_UPDATE = "webhooks:update"
    WEBHOOKS_DELETE = "webhooks:delete"

    # Policies permissions
    POLICIES_CREATE = "policies:create"
    POLICIES_READ = "policies:read"
    POLICIES_UPDATE = "policies:update"
    POLICIES_DELETE = "policies:delete"

    # Users permissions
    USERS_MANAGE = "users:manage"
    USERS_READ = "users:read"

    # Dashboard permissions
    DASHBOARD_READ = "dashboard:read"

    # Topology permissions
    TOPOLOGY_READ = "topology:read"

    # Scores permissions
    SCORES_READ = "scores:read"

    # Remediation permissions
    REMEDIATION_READ = "remediation:read"
