"""
Cross-framework finding deduplication.

This module provides deduplication of security findings across multiple
framework scanners (LlamaIndex, LangChain, CrewAI, AutoGen, etc.).

Key features:
- Framework-aware priority (prefer framework-specific findings over generic)
- Metadata merging from duplicate findings
- Detection method aggregation
"""

from collections import defaultdict
from dataclasses import dataclass

from vantage_core.security.deduplication.fingerprinting import (
    FindingFingerprint,
    FingerprintGenerator,
)
from vantage_core.security.models import SecurityFinding, Severity


@dataclass
class FrameworkFinding:
    """Finding with framework context."""

    finding: SecurityFinding
    framework: str
    detection_method: str
    confidence: float = 0.8


# Framework priority - lower number = higher priority
# Prefer framework-specific scanners over generic patterns
FRAMEWORK_PRIORITY = {
    "llamaindex": 1,
    "langchain": 1,
    "crewai": 1,
    "autogen": 1,
    "semantic_kernel": 1,
    "langgraph": 1,
    "ast": 2,  # AST-based detection (generic)
    "regex": 3,  # Regex-based detection (generic)
    "entropy_analysis": 3,  # Entropy-based secret detection
    "ml": 2,  # ML-based detection
    "generic": 4,  # Catch-all generic
}


class CrossFrameworkDeduplicator:
    """
    Deduplicate findings across multiple framework scanners.

    This deduplicator:
    1. Groups findings by semantic fingerprint
    2. Selects the primary finding based on framework priority
    3. Merges metadata and detection methods from duplicates
    4. Returns a deduplicated list with enriched context
    """

    def __init__(self, custom_priority: dict[str, int] | None = None):
        """
        Initialize deduplicator.

        Args:
            custom_priority: Optional custom framework priority map
        """
        self.fingerprint_gen = FingerprintGenerator()
        self.framework_priority = {**FRAMEWORK_PRIORITY, **(custom_priority or {})}

    def deduplicate(
        self,
        findings: list[SecurityFinding],
        preserve_all_metadata: bool = True,
    ) -> list[SecurityFinding]:
        """
        Deduplicate findings across frameworks.

        Strategy:
        1. Group by fingerprint
        2. Within each group, prefer findings from framework-specific scanners
        3. Merge metadata from duplicate findings

        Args:
            findings: List of findings to deduplicate
            preserve_all_metadata: If True, merge metadata from all duplicates

        Returns:
            Deduplicated list of findings
        """
        if not findings:
            return []

        # Group findings by fingerprint
        fingerprint_groups: dict[str, list[SecurityFinding]] = defaultdict(list)
        fingerprint_cache: dict[str, FindingFingerprint] = {}

        for finding in findings:
            fp = self.fingerprint_gen.generate(finding)
            fingerprint_cache[finding.id] = fp
            fingerprint_groups[fp.fingerprint].append(finding)

        # Process each group
        deduplicated = []

        for fingerprint, group in fingerprint_groups.items():
            if len(group) == 1:
                # No duplicates
                deduplicated.append(group[0])
            else:
                # Select primary and merge metadata
                primary = self._select_primary(group)

                if preserve_all_metadata:
                    self._merge_metadata(primary, group)

                deduplicated.append(primary)

        return deduplicated

    def deduplicate_with_context(
        self,
        framework_findings: list[FrameworkFinding],
    ) -> list[SecurityFinding]:
        """
        Deduplicate findings with framework context.

        This method provides more accurate deduplication when
        framework information is available.

        Args:
            framework_findings: List of findings with framework context

        Returns:
            Deduplicated list of findings
        """
        if not framework_findings:
            return []

        # Group by fingerprint
        fingerprint_groups: dict[str, list[FrameworkFinding]] = defaultdict(list)

        for fw_finding in framework_findings:
            fp = self.fingerprint_gen.generate(fw_finding.finding)
            fingerprint_groups[fp.fingerprint].append(fw_finding)

        # Process each group
        deduplicated = []

        for fingerprint, group in fingerprint_groups.items():
            if len(group) == 1:
                deduplicated.append(group[0].finding)
            else:
                # Sort by framework priority, then confidence
                sorted_group = sorted(
                    group,
                    key=lambda f: (
                        self._get_priority(f.framework),
                        self._get_priority(f.detection_method),
                        -f.confidence,
                    ),
                )

                primary = sorted_group[0].finding

                # Merge metadata
                self._merge_framework_metadata(primary, sorted_group)

                deduplicated.append(primary)

        return deduplicated

    def _select_primary(self, findings: list[SecurityFinding]) -> SecurityFinding:
        """
        Select the primary finding from a group of duplicates.

        Selection criteria:
        1. Framework-specific scanner > generic
        2. Higher confidence
        3. Higher severity
        4. Earlier detection (by finding ID)
        """

        def score(finding: SecurityFinding) -> tuple:
            # Get detection method from metadata or use default
            detection_method = getattr(finding, "detection_method", "generic")
            if hasattr(finding, "metadata") and finding.metadata:
                detection_method = finding.metadata.get("detection_method", detection_method)

            priority = self._get_priority(detection_method)
            severity_rank = self._severity_rank(finding.severity)
            confidence = getattr(finding, "confidence", 0.5)

            return (priority, -severity_rank, -confidence)

        sorted_findings = sorted(findings, key=score)
        return sorted_findings[0]

    def _merge_metadata(
        self,
        primary: SecurityFinding,
        all_findings: list[SecurityFinding],
    ) -> None:
        """Merge metadata from all findings into primary."""
        if not hasattr(primary, "metadata") or primary.metadata is None:
            primary.metadata = {}

        # Collect detection methods
        detection_methods = set()
        frameworks_detected = set()

        for finding in all_findings:
            method = getattr(finding, "detection_method", None)
            if method:
                detection_methods.add(method)

            if hasattr(finding, "metadata") and finding.metadata:
                if "detection_method" in finding.metadata:
                    detection_methods.add(finding.metadata["detection_method"])
                if "framework" in finding.metadata:
                    frameworks_detected.add(finding.metadata["framework"])

        # Update primary metadata
        primary.metadata["detection_methods"] = list(detection_methods)
        primary.metadata["frameworks_detected"] = list(frameworks_detected)
        primary.metadata["duplicate_count"] = len(all_findings) - 1
        primary.metadata["deduplicated"] = True

    def _merge_framework_metadata(
        self,
        primary: SecurityFinding,
        framework_findings: list[FrameworkFinding],
    ) -> None:
        """Merge framework-aware metadata."""
        if not hasattr(primary, "metadata") or primary.metadata is None:
            primary.metadata = {}

        detection_methods = {f.detection_method for f in framework_findings}
        frameworks = {f.framework for f in framework_findings}

        primary.metadata["detection_methods"] = list(detection_methods)
        primary.metadata["frameworks_detected"] = list(frameworks)
        primary.metadata["duplicate_count"] = len(framework_findings) - 1
        primary.metadata["deduplicated"] = True
        primary.metadata["max_confidence"] = max(f.confidence for f in framework_findings)

    def _get_priority(self, framework_or_method: str) -> int:
        """Get priority for framework or detection method."""
        return self.framework_priority.get(
            framework_or_method.lower(), self.framework_priority.get("generic", 999)
        )

    def _severity_rank(self, severity: Severity) -> int:
        """Get numeric rank for severity."""
        ranks = {
            Severity.CRITICAL: 4,
            Severity.HIGH: 3,
            Severity.MEDIUM: 2,
            Severity.LOW: 1,
            Severity.INFO: 0,
        }
        return ranks.get(severity, 0)


def deduplicate_findings(
    findings: list[SecurityFinding],
    preserve_metadata: bool = True,
) -> list[SecurityFinding]:
    """
    Convenience function to deduplicate findings.

    Args:
        findings: List of findings to deduplicate
        preserve_metadata: If True, merge metadata from duplicates

    Returns:
        Deduplicated list
    """
    deduplicator = CrossFrameworkDeduplicator()
    return deduplicator.deduplicate(findings, preserve_metadata)
