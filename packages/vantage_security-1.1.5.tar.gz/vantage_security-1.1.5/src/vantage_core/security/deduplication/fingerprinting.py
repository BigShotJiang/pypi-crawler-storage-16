"""
Fingerprint generation and similarity matching for finding deduplication.

This module provides:
- FingerprintGenerator: Generate semantic fingerprints for findings
- SimilarityMatcher: Group similar findings together

Fingerprints are stable across:
- Code movement (line number changes)
- Whitespace variations
- Same code in different line positions
"""

import hashlib
import os
import re
from dataclasses import dataclass, field

from vantage_core.security.models import SecurityFinding, Severity


@dataclass
class FindingFingerprint:
    """Semantic fingerprint for a security finding."""

    finding_id: str
    fingerprint: str  # SHA-256 hash (truncated)
    normalized_code: str
    category: str
    filename: str  # Not full path, just filename


class FingerprintGenerator:
    """
    Generate semantic fingerprints for security findings.

    Fingerprints are based on:
    - Normalized code snippet (whitespace/comments removed)
    - Vulnerability category
    - Filename (not full path, not line numbers)

    This ensures identical vulnerabilities at different line numbers
    produce the same fingerprint for deduplication.
    """

    ALGORITHM_VERSION = "1.0"

    def __init__(self):
        """Initialize fingerprint generator with normalization rules."""
        self._comment_pattern = re.compile(r"#.*$", re.MULTILINE)
        self._multiline_string_pattern = re.compile(r'""".*?"""|\'\'\'.*?\'\'\'', re.DOTALL)
        self._whitespace_pattern = re.compile(r"\s+")

    def generate(self, finding: SecurityFinding) -> FindingFingerprint:
        """
        Generate fingerprint from finding.

        Args:
            finding: Security finding to fingerprint

        Returns:
            FindingFingerprint with semantic hash
        """
        # Normalize the code snippet
        normalized = self.normalize_code(finding.code_snippet)

        # Extract filename from path
        filename = os.path.basename(finding.file_path)

        # Get category value
        category = (
            finding.category.value if hasattr(finding.category, "value") else str(finding.category)
        )

        # Generate fingerprint from: normalized_code + category + filename
        fingerprint = self._hash(normalized, category, filename)

        return FindingFingerprint(
            finding_id=finding.id,
            fingerprint=fingerprint,
            normalized_code=normalized,
            category=category,
            filename=filename,
        )

    def normalize_code(self, code: str) -> str:
        """
        Normalize code snippet for comparison.

        Normalization:
        - Remove leading/trailing whitespace per line
        - Remove blank lines
        - Remove single-line comments
        - Collapse multiple whitespace to single space
        - Strip overall leading/trailing whitespace

        Args:
            code: Raw code snippet

        Returns:
            Normalized code string
        """
        if not code:
            return ""

        lines = code.split("\n")
        normalized_lines = []

        for line in lines:
            # Strip whitespace from line
            line = line.strip()

            # Skip empty lines
            if not line:
                continue

            # Skip comment-only lines (Python style)
            if line.startswith("#"):
                continue

            # Remove inline comments
            line = self._comment_pattern.sub("", line).strip()

            # Skip if line becomes empty after removing comments
            if not line:
                continue

            normalized_lines.append(line)

        # Join and collapse multiple spaces
        result = " ".join(normalized_lines)
        result = self._whitespace_pattern.sub(" ", result)

        return result.strip()

    def _hash(self, *components: str) -> str:
        """
        Create SHA-256 hash from components.

        Args:
            components: String components to hash

        Returns:
            Truncated SHA-256 hash (16 characters)
        """
        combined = ":".join(components)
        hash_obj = hashlib.sha256(combined.encode("utf-8"))
        return hash_obj.hexdigest()[:16]


@dataclass
class FindingGroup:
    """Group of correlated/similar findings."""

    group_id: str
    fingerprint: str
    primary_finding: SecurityFinding
    related_findings: list[SecurityFinding] = field(default_factory=list)
    match_reasons: list[str] = field(default_factory=list)


class SimilarityMatcher:
    """
    Group similar findings together based on multiple matching strategies.

    Matching strategies (in priority order):
    1. Exact fingerprint match - identical normalized code
    2. Location proximity - within N lines in same file
    3. Related categories - e.g., prompt_injection variants
    """

    # Related category pairs that should be grouped together
    # Store as frozensets for order-independent comparison
    RELATED_CATEGORIES = {
        frozenset(("prompt_injection", "code_execution")),
        frozenset(("data_leakage", "hardcoded_secret")),
        frozenset(("privilege_escalation", "excessive_agency")),
        frozenset(("trust_boundary_violation", "unsafe_delegation")),
        frozenset(("insecure_tool_use", "code_execution")),
    }

    def __init__(self, location_threshold: int = 5):
        """
        Initialize similarity matcher.

        Args:
            location_threshold: Maximum line distance for proximity matching
        """
        self.location_threshold = location_threshold
        self.fingerprint_gen = FingerprintGenerator()

    def match_findings(self, findings: list[SecurityFinding]) -> list[FindingGroup]:
        """
        Group findings by similarity.

        Algorithm:
        1. Generate fingerprints for all findings
        2. First pass: exact fingerprint match
        3. Second pass: location proximity (same file, within N lines)
        4. Third pass: related categories

        Args:
            findings: List of security findings to group

        Returns:
            List of finding groups
        """
        if not findings:
            return []

        # Generate fingerprints for all findings
        fingerprints: dict[str, FindingFingerprint] = {}
        for finding in findings:
            fp = self.fingerprint_gen.generate(finding)
            fingerprints[finding.id] = fp

        # Track which findings have been grouped
        grouped: set[str] = set()
        groups: list[FindingGroup] = []

        # First pass: exact fingerprint match
        fingerprint_to_findings: dict[str, list[SecurityFinding]] = {}
        for finding in findings:
            fp = fingerprints[finding.id].fingerprint
            if fp not in fingerprint_to_findings:
                fingerprint_to_findings[fp] = []
            fingerprint_to_findings[fp].append(finding)

        for fp_hash, fp_findings in fingerprint_to_findings.items():
            if len(fp_findings) > 1:
                # Sort by severity (highest first) then by line number
                sorted_findings = sorted(
                    fp_findings,
                    key=lambda f: (-self._severity_rank(f.severity), f.line_number),
                )
                primary = sorted_findings[0]
                related = sorted_findings[1:]

                group = FindingGroup(
                    group_id=f"GRP-{fp_hash[:8]}",
                    fingerprint=fp_hash,
                    primary_finding=primary,
                    related_findings=related,
                    match_reasons=["exact_fingerprint_match"],
                )
                groups.append(group)

                for f in fp_findings:
                    grouped.add(f.id)
            elif len(fp_findings) == 1:
                # Single finding, check for proximity/category matches later
                pass

        # Second pass: location proximity for ungrouped findings
        ungrouped = [f for f in findings if f.id not in grouped]

        for i, finding1 in enumerate(ungrouped):
            if finding1.id in grouped:
                continue

            proximity_group = [finding1]
            match_reasons = []

            for finding2 in ungrouped[i + 1 :]:
                if finding2.id in grouped:
                    continue

                # Check location proximity
                if self._are_location_proximate(finding1, finding2):
                    # Also check if categories are related
                    if self._are_related_categories(
                        fingerprints[finding1.id].category,
                        fingerprints[finding2.id].category,
                    ):
                        proximity_group.append(finding2)
                        grouped.add(finding2.id)  # Mark as grouped immediately
                        if "location_proximity" not in match_reasons:
                            match_reasons.append("location_proximity")
                        if "related_categories" not in match_reasons:
                            match_reasons.append("related_categories")

            if len(proximity_group) > 1:
                # Sort by severity
                sorted_findings = sorted(
                    proximity_group,
                    key=lambda f: (-self._severity_rank(f.severity), f.line_number),
                )
                primary = sorted_findings[0]
                related = sorted_findings[1:]

                fp = fingerprints[primary.id]
                group = FindingGroup(
                    group_id=f"GRP-{fp.fingerprint[:8]}-LOC",
                    fingerprint=fp.fingerprint,
                    primary_finding=primary,
                    related_findings=related,
                    match_reasons=match_reasons,
                )
                groups.append(group)

                # Mark primary as grouped too
                grouped.add(finding1.id)

        # Third pass: create single-finding groups for remaining
        for finding in findings:
            if finding.id not in grouped:
                fp = fingerprints[finding.id]
                group = FindingGroup(
                    group_id=f"GRP-{fp.fingerprint[:8]}",
                    fingerprint=fp.fingerprint,
                    primary_finding=finding,
                    related_findings=[],
                    match_reasons=["unique"],
                )
                groups.append(group)

        return groups

    def _are_location_proximate(self, f1: SecurityFinding, f2: SecurityFinding) -> bool:
        """
        Check if two findings are in close proximity.

        Args:
            f1: First finding
            f2: Second finding

        Returns:
            True if findings are within location_threshold lines in same file
        """
        if f1.file_path != f2.file_path:
            return False
        return abs(f1.line_number - f2.line_number) <= self.location_threshold

    def _are_related_categories(self, cat1: str, cat2: str) -> bool:
        """
        Check if two categories are related.

        Args:
            cat1: First category
            cat2: Second category

        Returns:
            True if categories are same or related
        """
        if cat1 == cat2:
            return True

        # Check if the pair is in related categories (order-independent)
        pair = frozenset([cat1, cat2])
        return pair in self.RELATED_CATEGORIES

    def _severity_rank(self, severity: Severity) -> int:
        """
        Get numeric rank for severity (higher = more severe).

        Args:
            severity: Severity enum value

        Returns:
            Numeric rank (0-4)
        """
        ranks = {
            Severity.CRITICAL: 4,
            Severity.HIGH: 3,
            Severity.MEDIUM: 2,
            Severity.LOW: 1,
            Severity.INFO: 0,
        }
        return ranks.get(severity, 0)
