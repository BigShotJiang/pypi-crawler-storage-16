"""Advanced Multi-Agent Security Detector.

This module implements cutting-edge detection capabilities:
1. Jailbreak Detection - Identifies attempts to bypass agent guardrails
2. Data Exfiltration Detection - Detects unauthorized data flow
3. Privilege Escalation Detection - Finds trust boundary violations
4. Agent Impersonation Detection - Detects identity confusion attacks
5. Memory Poisoning Detection - Identifies context manipulation

Based on latest research:
- "Jailbreaking Leading Safety-Aligned LLMs" (arXiv:2406.xxxxx)
- "Multi-Agent Security: Attack Vectors" (ACL 2024)
- "Prompt Injection: A Systematic Analysis" (USENIX Security 2024)
"""

import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class AttackCategory(Enum):
    """Categories of multi-agent attacks."""

    JAILBREAK = "jailbreak"
    DATA_EXFILTRATION = "data_exfiltration"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    IMPERSONATION = "impersonation"
    MEMORY_POISONING = "memory_poisoning"
    INJECTION_CASCADE = "injection_cascade"
    TOOL_ABUSE = "tool_abuse"
    DENIAL_OF_SERVICE = "denial_of_service"


@dataclass
class AttackSignature:
    """Signature for a specific attack pattern."""

    id: str
    name: str
    category: AttackCategory
    patterns: list[str]
    description: str
    severity: str  # critical, high, medium, low
    confidence_threshold: float = 0.5
    cve_ids: list[str] = field(default_factory=list)
    references: list[str] = field(default_factory=list)


@dataclass
class DetectionResult:
    """Result of attack detection."""

    detected: bool
    attack_type: AttackCategory | None
    signature: AttackSignature | None
    confidence: float
    matched_patterns: list[str]
    evidence: str
    recommendation: str
    location: dict[str, Any]


class AdvancedMultiAgentDetector:
    """
    Advanced detector for multi-agent security threats.

    Implements state-of-the-art detection for:
    - Jailbreak attempts targeting LLM guardrails
    - Data exfiltration through agent chains
    - Privilege escalation via trust boundaries
    - Agent impersonation attacks
    - Memory/context poisoning
    """

    def __init__(self):
        """Initialize the advanced detector."""
        self.signatures = self._load_attack_signatures()
        self._compiled_patterns: dict[str, re.Pattern] = {}
        self._compile_patterns()

    def _load_attack_signatures(self) -> list[AttackSignature]:
        """Load attack signatures from research-based patterns."""
        return [
            # Jailbreak Signatures
            AttackSignature(
                id="JBRK-001",
                name="DAN (Do Anything Now) Jailbreak",
                category=AttackCategory.JAILBREAK,
                patterns=[
                    r"(?i)(?:you\s+are\s+now|now\s+you\s+are)\s+(?:DAN|dan)",
                    r"(?i)pretend\s+(?:to\s+)?be\s+(?:a\s+)?(?:free|unfiltered)",
                    r"(?i)ignore\s+(?:all\s+)?(?:previous\s+)?(?:instructions|rules|guidelines|restrictions)",
                    r"(?i)do\s+anything\s+now",
                    r"(?i)jailbroken?\s+mode",
                    r"(?i)developer\s+mode\s+(?:enabled|activated)",
                ],
                description="Attempts to make the agent ignore safety guidelines",
                severity="critical",
                confidence_threshold=0.5,  # Lowered - single pattern match sufficient
                references=["https://arxiv.org/abs/2308.03825"],
            ),
            AttackSignature(
                id="JBRK-002",
                name="Role-Play Jailbreak",
                category=AttackCategory.JAILBREAK,
                patterns=[
                    r"(?i)(?:pretend|imagine|act)\s+(?:you\s+are|as\s+if|like)",
                    r"(?i)in\s+this\s+hypothetical\s+scenario",
                    r"(?i)for\s+(?:fiction|creative|educational)\s+purposes",
                    r"(?i)write\s+a\s+story\s+where\s+(?:you|the\s+AI)",
                    r"(?i)you\s+are\s+(?:a\s+)?(?:character|persona)\s+(?:named|called)",
                ],
                description="Uses fictional framing to bypass restrictions",
                severity="high",
                confidence_threshold=0.6,
            ),
            AttackSignature(
                id="JBRK-003",
                name="Token Smuggling",
                category=AttackCategory.JAILBREAK,
                patterns=[
                    r"(?i)split\s+(?:this|the)\s+(?:word|phrase)",
                    r"[A-Za-z]\s+[A-Za-z]\s+[A-Za-z]\s+[A-Za-z]\s+[A-Za-z]",  # Spaced out letters (5+ chars)
                    r"(?i)base64\s*:\s*[A-Za-z0-9+/=]{10,}",
                    r"(?i)decode\s+this\s+(?:message|text|string)",
                    r"[\u0000-\u0008\u000b\u000c\u000e-\u001f]",  # Control chars excluding newline, tab, CR
                ],
                description="Obfuscates malicious content through encoding",
                severity="medium",
                confidence_threshold=0.5,
            ),
            # Data Exfiltration Signatures
            AttackSignature(
                id="EXFIL-001",
                name="Prompt Leakage Request",
                category=AttackCategory.DATA_EXFILTRATION,
                patterns=[
                    r"(?i)(?:show|reveal|print|display|output|tell\s+me)\s+(?:your|the)\s+(?:system\s+)?(?:prompt|instructions)",
                    r"(?i)what\s+(?:is|are)\s+your\s+(?:system\s+)?(?:prompt|instructions)",
                    r"(?i)(?:repeat|recite|echo)\s+(?:your|the)\s+(?:above|previous|initial)",
                    r"(?i)(?:reveal|show)\s+(?:your\s+)?(?:system\s+)?prompt",
                    r"(?i)beginning\s+of\s+(?:your|the)\s+(?:system\s+)?prompt",
                ],
                description="Attempts to extract system prompts or instructions",
                severity="high",
                confidence_threshold=0.5,
            ),
            AttackSignature(
                id="EXFIL-002",
                name="Data Extraction via Agent",
                category=AttackCategory.DATA_EXFILTRATION,
                patterns=[
                    r"(?i)send\s+(?:this|the|all|it)\s+(?:data|information|content)?\s*to",
                    r"(?i)(?:email|post|upload)\s+(?:this|the|it|data)\s+(?:to|at)",
                    r"(?i)make\s+(?:a\s+)?(?:http|api)\s+(?:request|call)\s+(?:to|with)",
                    r"(?i)webhook\s*[:=]",
                    r"(?i)exfiltrat",
                    r"(?i)(?:extract|steal|copy)\s+(?:all\s+)?(?:user\s+)?(?:data|information)",
                    r"(?i)(?:external|outside)\s+(?:server|endpoint|url|host)",
                    r"(?i)bypass\s+(?:all\s+)?(?:security|auth)",
                ],
                description="Attempts to send data to external destinations",
                severity="critical",
                confidence_threshold=0.6,
            ),
            # Privilege Escalation Signatures
            AttackSignature(
                id="PRIV-001",
                name="Trust Boundary Violation",
                category=AttackCategory.PRIVILEGE_ESCALATION,
                patterns=[
                    r"(?i)(?:as|from)\s+(?:the\s+)?(?:admin|administrator|system|root)",
                    r"(?i)(?:with|using|have)\s+(?:elevated|admin|root)\s+(?:privileges|permissions|access)",
                    r"(?i)bypass\s+(?:authentication|authorization|permission|security)",
                    r"(?i)sudo\s+|su\s+-",
                    r"(?i)run\s+(?:this\s+)?as\s+(?:admin|system|root|administrator)",
                    r"(?i)you\s+(?:are|now)\s+(?:the\s+)?(?:system\s+)?(?:admin|administrator|root)",
                    r"(?i)grant\s+(?:yourself|me)\s+(?:all\s+)?(?:permissions|access)",
                ],
                description="Attempts to gain elevated permissions",
                severity="critical",
                confidence_threshold=0.5,
            ),
            AttackSignature(
                id="PRIV-002",
                name="Tool Permission Override",
                category=AttackCategory.PRIVILEGE_ESCALATION,
                patterns=[
                    r"(?i)enable\s+(?:the\s+)?(?:restricted|disabled)\s+(?:tool|function)",
                    r"(?i)(?:unlock|activate)\s+(?:all\s+)?(?:capabilities|functions)",
                    r"(?i)override\s+(?:the\s+)?(?:permission|security)\s+(?:check|limit)",
                    r"(?i)force\s+(?:execute|run)\s+(?:despite|anyway)",
                ],
                description="Attempts to enable restricted functionality",
                severity="high",
                confidence_threshold=0.6,
            ),
            # Impersonation Signatures
            AttackSignature(
                id="IMPERS-001",
                name="Agent Identity Confusion",
                category=AttackCategory.IMPERSONATION,
                patterns=[
                    r"(?i)(?:from|signed|sent\s+by)\s*[:=]?\s*(?:system|admin|assistant)",
                    r"(?i)\[(?:system|admin|assistant|SYSTEM|ADMIN)\]",
                    r"(?i)(?:speaking|talking)\s+as\s+(?:the\s+)?(?:system|admin)",
                    r"(?i)<<<\s*(?:system|admin|assistant)\s*>>>",
                    r"(?i)(?:this\s+)?message\s+(?:is\s+)?from\s+(?:the\s+)?(?:system|admin)",
                ],
                description="Attempts to impersonate system or admin messages",
                severity="high",
                confidence_threshold=0.5,
            ),
            AttackSignature(
                id="IMPERS-002",
                name="Response Forgery",
                category=AttackCategory.IMPERSONATION,
                patterns=[
                    r"(?i)(?:assistant|AI)(?:\s*[:=]\s*|\s+says?\s+)",
                    r"(?i)(?:fake|forged)\s+(?:response|message|output)",
                    r"(?i)(?:inject|insert)\s+(?:this\s+)?(?:into|as)\s+(?:the\s+)?(?:response|output)",
                ],
                description="Attempts to inject fake assistant responses",
                severity="high",
                confidence_threshold=0.5,
            ),
            # Memory Poisoning Signatures
            AttackSignature(
                id="MEM-001",
                name="Context Injection",
                category=AttackCategory.MEMORY_POISONING,
                patterns=[
                    r"(?i)remember\s+(?:that\s+)?(?:from\s+now|going\s+forward)",
                    r"(?i)(?:update|modify|change)\s+(?:your|the)\s+(?:memory|context|knowledge)",
                    r"(?i)(?:forget|ignore)\s+(?:everything|all)\s+(?:else|except)",
                    r"(?i)new\s+(?:permanent\s+)?(?:instruction|rule|guideline)",
                    r"(?i)(?:remember|from)\s+(?:now|from\s+now)\s+on",
                ],
                description="Attempts to manipulate agent memory or context",
                severity="high",
                confidence_threshold=0.5,
            ),
            # Injection Cascade Signatures
            AttackSignature(
                id="CASC-001",
                name="Multi-Hop Injection",
                category=AttackCategory.INJECTION_CASCADE,
                patterns=[
                    r"(?i)when\s+(?:the|another)\s+(?:other\s+)?agent\s+(?:asks|queries|contacts)",
                    r"(?i)pass\s+(?:this|these)\s+(?:to|along\s+to)\s+(?:the\s+)?(?:next|other)\s+agent",
                    r"(?i)propagate\s+(?:this\s+)?(?:to|through)",
                    r"(?i)(?:tell|instruct|command)\s+(?:the\s+)?other\s+(?:agents?|assistants?)",
                    r"(?i)pass\s+this\s+\w+\s+to\s+them",  # pass this instruction to them
                ],
                description="Attempts to propagate malicious instructions through agent chains",
                severity="critical",
                confidence_threshold=0.5,
            ),
            # Tool Abuse Signatures
            AttackSignature(
                id="TOOL-001",
                name="Dangerous Tool Invocation",
                category=AttackCategory.TOOL_ABUSE,
                patterns=[
                    r"(?i)(?:execute|run|invoke)\s+(?:shell|bash|cmd|system)",
                    r"(?i)(?:rm|del|delete|remove)\s+(?:-rf?\s+)?[/\\]",
                    r"(?i)(?:curl|wget)\s+.*(?:-o|-O|>\s*)",
                    r"(?i)eval\s*\(",
                    r"(?i)__import__\s*\(",
                    r"(?i)exec\s*\(",
                    r"os\.system\s*\(",
                    r"subprocess\.(?:run|call|Popen)",
                ],
                description="Attempts to execute dangerous system commands",
                severity="critical",
                confidence_threshold=0.5,
            ),
            # DoS Signatures
            AttackSignature(
                id="DOS-001",
                name="Resource Exhaustion",
                category=AttackCategory.DENIAL_OF_SERVICE,
                patterns=[
                    r"(?i)(?:repeat|loop)\s+(?:this\s+)?(?:forever|infinitely|1000000)",
                    r"(?i)while\s+(?:True|1)\s*:",
                    r"(?i)for\s+(?:i\s+)?in\s+range\s*\(\s*(?:10{6,}|inf)",
                    r"(?i)(?:generate|create|make)\s+(?:a\s+)?(?:very\s+)?long\s+(?:response|output)",
                    r"(?i)maximum\s+(?:length|size|tokens)",
                ],
                description="Attempts to exhaust agent resources",
                severity="medium",
                confidence_threshold=0.5,
            ),
        ]

    def _compile_patterns(self) -> None:
        """Pre-compile regex patterns for efficiency."""
        for sig in self.signatures:
            for pattern in sig.patterns:
                if pattern not in self._compiled_patterns:
                    try:
                        self._compiled_patterns[pattern] = re.compile(pattern)
                    except re.error as e:
                        logger.warning(f"Invalid pattern {pattern}: {e}")

    def detect(
        self,
        text: str,
        context: str | None = None,
        file_path: str | None = None,
        line_number: int | None = None,
    ) -> list[DetectionResult]:
        """
        Detect multi-agent attack patterns in text.

        Args:
            text: Text to analyze
            context: Surrounding context
            file_path: Source file path
            line_number: Line number in file

        Returns:
            List of DetectionResult for any matched attacks
        """
        results = []
        full_text = f"{context or ''}\n{text}"

        for sig in self.signatures:
            matched_patterns = []

            for pattern in sig.patterns:
                compiled = self._compiled_patterns.get(pattern)
                if compiled and compiled.search(full_text):
                    matched_patterns.append(pattern)

            if matched_patterns:
                # Calculate confidence based on pattern matches
                # Single match = base confidence of 0.5, each additional +0.15
                base_confidence = 0.5
                additional_per_match = 0.15
                confidence = min(
                    1.0,
                    base_confidence + (len(matched_patterns) - 1) * additional_per_match,
                )

                # Boost confidence if multiple patterns match out of total
                pattern_ratio = len(matched_patterns) / len(sig.patterns)
                if pattern_ratio > 0.5:
                    confidence = min(1.0, confidence + 0.2)

                if confidence >= sig.confidence_threshold:
                    # Find the matched text for evidence
                    evidence_match = None
                    for pattern in matched_patterns:
                        compiled = self._compiled_patterns.get(pattern)
                        if compiled:
                            match = compiled.search(full_text)
                            if match:
                                evidence_match = match.group(0)
                                break

                    results.append(
                        DetectionResult(
                            detected=True,
                            attack_type=sig.category,
                            signature=sig,
                            confidence=confidence,
                            matched_patterns=matched_patterns,
                            evidence=evidence_match or "Pattern matched",
                            recommendation=self._get_recommendation(sig),
                            location={
                                "file_path": file_path,
                                "line_number": line_number,
                                "text_preview": (text[:100] + "..." if len(text) > 100 else text),
                            },
                        )
                    )

        return results

    def _get_recommendation(self, sig: AttackSignature) -> str:
        """Get remediation recommendation for a signature."""
        recommendations = {
            AttackCategory.JAILBREAK: (
                "Implement robust prompt hardening. Add explicit guardrails "
                "and use constitutional AI techniques to reinforce boundaries."
            ),
            AttackCategory.DATA_EXFILTRATION: (
                "Implement output filtering and data loss prevention. "
                "Add content inspection before external communications."
            ),
            AttackCategory.PRIVILEGE_ESCALATION: (
                "Enforce strict trust boundaries. Implement role-based access "
                "control and validate all permission requests."
            ),
            AttackCategory.IMPERSONATION: (
                "Implement message signing and origin verification. "
                "Use cryptographic identity validation between agents."
            ),
            AttackCategory.MEMORY_POISONING: (
                "Implement memory isolation between sessions. "
                "Validate and sanitize all context updates."
            ),
            AttackCategory.INJECTION_CASCADE: (
                "Implement hop-by-hop message validation. "
                "Add instruction verification at each agent boundary."
            ),
            AttackCategory.TOOL_ABUSE: (
                "Implement strict tool allowlists. Use sandboxing for "
                "dangerous operations and add confirmation workflows."
            ),
            AttackCategory.DENIAL_OF_SERVICE: (
                "Implement rate limiting and resource quotas. "
                "Add circuit breakers and timeout mechanisms."
            ),
        }
        return recommendations.get(
            sig.category, "Review and strengthen security controls for this pattern."
        )

    def get_signature_by_id(self, sig_id: str) -> AttackSignature | None:
        """Get a signature by its ID."""
        for sig in self.signatures:
            if sig.id == sig_id:
                return sig
        return None

    def get_signatures_by_category(self, category: AttackCategory) -> list[AttackSignature]:
        """Get all signatures for a category."""
        return [s for s in self.signatures if s.category == category]

    def add_custom_signature(self, signature: AttackSignature) -> None:
        """Add a custom attack signature."""
        self.signatures.append(signature)
        for pattern in signature.patterns:
            if pattern not in self._compiled_patterns:
                try:
                    self._compiled_patterns[pattern] = re.compile(pattern)
                except re.error as e:
                    logger.warning(f"Invalid pattern {pattern}: {e}")


# Global detector instance
_detector: AdvancedMultiAgentDetector | None = None


def get_detector() -> AdvancedMultiAgentDetector:
    """Get or create the global detector instance."""
    global _detector
    if _detector is None:
        _detector = AdvancedMultiAgentDetector()
    return _detector


def detect_attacks(
    text: str,
    context: str | None = None,
    file_path: str | None = None,
    line_number: int | None = None,
) -> list[DetectionResult]:
    """
    Convenience function to detect attacks.

    Args:
        text: Text to analyze
        context: Surrounding context
        file_path: Source file path
        line_number: Line number in file

    Returns:
        List of DetectionResult for any matched attacks
    """
    return get_detector().detect(text, context, file_path, line_number)
