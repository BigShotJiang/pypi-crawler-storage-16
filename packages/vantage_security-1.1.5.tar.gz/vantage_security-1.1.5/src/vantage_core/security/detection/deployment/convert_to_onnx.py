"""
ONNX Conversion Script for XGBoost Model.

Converts trained XGBoost model to ONNX format with quantization
for optimized inference performance.

Usage:
    python convert_to_onnx.py --input models/stage2_xgboost.json --output models/stage2_xgboost.onnx
"""

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent))


def convert_xgboost_to_onnx(model_path: str, output_path: str, quantize: bool = True) -> bool:
    """
    Convert XGBoost model to ONNX format.

    Args:
        model_path: Path to trained XGBoost model (.json)
        output_path: Path to save ONNX model
        quantize: Whether to apply INT8 quantization

    Returns:
        True if successful, False otherwise
    """
    try:
        import onnx
        import xgboost as xgb
        from onnxmltools.convert import convert_xgboost
        from onnxmltools.convert.common.data_types import FloatTensorType
    except ImportError as e:
        print(f"ERROR: Required package not installed: {e}")
        print("Install with: pip install xgboost onnx onnxmltools onnxconverter-common")
        return False

    print("=" * 70)
    print("XGBoost → ONNX Conversion")
    print("=" * 70)

    # Load metadata
    metadata_path = Path(model_path).with_suffix(".metadata.json")
    if metadata_path.exists():
        with open(metadata_path) as f:
            metadata = json.load(f)
            num_features = metadata.get("num_features", 20)
            print("\nModel metadata loaded:")
            print(f"  Features: {num_features}")
            print(f"  Precision: {metadata['metrics']['precision']:.3f}")
            print(f"  Recall: {metadata['metrics']['recall']:.3f}")
    else:
        num_features = 20
        print(f"\nNo metadata found, using default: {num_features} features")

    # Load XGBoost model
    print(f"\nLoading XGBoost model from: {model_path}")
    try:
        model = xgb.XGBClassifier()
        model.load_model(model_path)
        print("  Model loaded successfully")
    except Exception as e:
        print(f"ERROR: Failed to load model: {e}")
        return False

    # Define input type (20 features, float32)
    print("\nDefining ONNX input type...")
    initial_type = [("float_input", FloatTensorType([None, num_features]))]

    # Convert to ONNX
    print("Converting to ONNX...")
    try:
        onnx_model = convert_xgboost(
            model,
            initial_types=initial_type,
            target_opset=13,
        )
        print("  Conversion successful")
    except Exception as e:
        print(f"ERROR: ONNX conversion failed: {e}")
        return False

    # Save ONNX model
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    print(f"\nSaving ONNX model to: {output_path}")
    onnx.save_model(onnx_model, str(output_path))

    # Get file sizes
    original_size = Path(model_path).stat().st_size / (1024 * 1024)
    onnx_size = output_path.stat().st_size / (1024 * 1024)

    print(f"  Original model size: {original_size:.2f} MB")
    print(f"  ONNX model size: {onnx_size:.2f} MB")

    # Validate ONNX model
    print("\nValidating ONNX model...")
    try:
        import onnxruntime as ort

        session = ort.InferenceSession(str(output_path), providers=["CPUExecutionProvider"])

        print(f"  Model inputs: {[i.name for i in session.get_inputs()]}")
        print(f"  Model outputs: {[o.name for o in session.get_outputs()]}")

        # Test inference
        print("\nTesting inference...")
        test_input = np.random.randn(1, num_features).astype(np.float32)

        start = time.perf_counter()
        result = session.run(None, {"float_input": test_input})
        elapsed_ms = (time.perf_counter() - start) * 1000

        print("  Inference successful!")
        print(f"  Output shape: {result[1].shape}")
        print(f"  Inference time: {elapsed_ms:.2f} ms")
        print(f"  Sample output: {result[1][0]}")

    except Exception as e:
        print(f"WARNING: ONNX validation failed: {e}")
        print("Model converted but validation failed. Please test manually.")

    # Quantization (optional)
    if quantize:
        print("\nQuantization to INT8...")
        try:
            from onnxruntime.quantization import QuantType, quantize_dynamic

            quantized_path = output_path.with_stem(output_path.stem + "_int8")

            quantize_dynamic(str(output_path), str(quantized_path), weight_type=QuantType.QInt8)

            quantized_size = quantized_path.stat().st_size / (1024 * 1024)
            reduction = (1 - quantized_size / onnx_size) * 100

            print(f"  Quantized model saved to: {quantized_path}")
            print(f"  Quantized size: {quantized_size:.2f} MB")
            print(f"  Size reduction: {reduction:.1f}%")

            # Test quantized model
            print("\nTesting quantized model...")
            quant_session = ort.InferenceSession(
                str(quantized_path), providers=["CPUExecutionProvider"]
            )

            start = time.perf_counter()
            quant_result = quant_session.run(None, {"float_input": test_input})
            quant_elapsed_ms = (time.perf_counter() - start) * 1000

            print(f"  Quantized inference time: {quant_elapsed_ms:.2f} ms")
            print(f"  Speedup: {elapsed_ms / quant_elapsed_ms:.2f}x")

            # Check output similarity
            output_diff = np.abs(result[1] - quant_result[1]).max()
            print(f"  Max output difference: {output_diff:.6f}")

        except Exception as e:
            print(f"WARNING: Quantization failed: {e}")
            print("Original ONNX model is still available.")

    print("\n" + "=" * 70)
    print("Conversion Complete!")
    print("=" * 70)
    print("\nNext steps:")
    print("  1. Benchmark ONNX model: python tests/benchmark_onnx.py")
    print("  2. Integrate with Stage2Classifier")
    print("  3. Run end-to-end tests")

    return True


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Convert XGBoost model to ONNX")
    parser.add_argument("--input", type=str, required=True, help="Path to XGBoost model (.json)")
    parser.add_argument("--output", type=str, required=True, help="Path to save ONNX model (.onnx)")
    parser.add_argument("--no-quantize", action="store_true", help="Disable INT8 quantization")

    args = parser.parse_args()

    success = convert_xgboost_to_onnx(
        model_path=args.input, output_path=args.output, quantize=not args.no_quantize
    )

    return 0 if success else 1


if __name__ == "__main__":
    exit(main())
