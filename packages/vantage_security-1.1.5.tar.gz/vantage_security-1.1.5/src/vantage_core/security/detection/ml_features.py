"""
Machine Learning Feature Extraction for Secret Detection.

This module provides feature extraction for the Stage 2 ML classifier.
It extracts 20 engineered features from potential secrets to enable
high-precision classification.
"""

import logging
import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class SecretFeatures:
    """Features extracted from a potential secret for ML classification."""

    # Basic features
    length: int = 0
    entropy: float = 0.0
    unique_char_ratio: float = 0.0

    # Character type features
    uppercase_ratio: float = 0.0
    lowercase_ratio: float = 0.0
    digit_ratio: float = 0.0
    special_char_ratio: float = 0.0

    # Pattern features
    has_prefix: bool = False
    is_base64_like: bool = False
    is_hex_like: bool = False
    is_uuid_like: bool = False

    # Context features
    is_in_test_file: bool = False
    is_in_example_file: bool = False
    variable_name_suggests_secret: bool = False
    has_secret_keyword_nearby: bool = False

    # Advanced features
    sequential_char_ratio: float = 0.0
    repeated_pattern_ratio: float = 0.0
    char_class_transitions: int = 0
    ngram_score: float = 0.0
    gibberish_score: float = 0.0

    @staticmethod
    def feature_names() -> list[str]:
        """Return list of feature names in order."""
        return [
            "length",
            "entropy",
            "unique_char_ratio",
            "uppercase_ratio",
            "lowercase_ratio",
            "digit_ratio",
            "special_char_ratio",
            "has_prefix",
            "is_base64_like",
            "is_hex_like",
            "is_uuid_like",
            "is_in_test_file",
            "is_in_example_file",
            "variable_name_suggests_secret",
            "has_secret_keyword_nearby",
            "sequential_char_ratio",
            "repeated_pattern_ratio",
            "char_class_transitions",
            "ngram_score",
            "gibberish_score",
        ]

    def to_vector(self) -> list[float]:
        """Convert features to a list of floats for ML model."""
        return [
            float(self.length),
            float(self.entropy),
            float(self.unique_char_ratio),
            float(self.uppercase_ratio),
            float(self.lowercase_ratio),
            float(self.digit_ratio),
            float(self.special_char_ratio),
            float(self.has_prefix),
            float(self.is_base64_like),
            float(self.is_hex_like),
            float(self.is_uuid_like),
            float(self.is_in_test_file),
            float(self.is_in_example_file),
            float(self.variable_name_suggests_secret),
            float(self.has_secret_keyword_nearby),
            float(self.sequential_char_ratio),
            float(self.repeated_pattern_ratio),
            float(self.char_class_transitions),
            float(self.ngram_score),
            float(self.gibberish_score),
        ]

    def to_dict(self) -> dict[str, Any]:
        """Convert features to dictionary."""
        return {
            "length": self.length,
            "entropy": self.entropy,
            "unique_char_ratio": self.unique_char_ratio,
            "uppercase_ratio": self.uppercase_ratio,
            "lowercase_ratio": self.lowercase_ratio,
            "digit_ratio": self.digit_ratio,
            "special_char_ratio": self.special_char_ratio,
            "has_prefix": self.has_prefix,
            "is_base64_like": self.is_base64_like,
            "is_hex_like": self.is_hex_like,
            "is_uuid_like": self.is_uuid_like,
            "is_in_test_file": self.is_in_test_file,
            "is_in_example_file": self.is_in_example_file,
            "variable_name_suggests_secret": self.variable_name_suggests_secret,
            "has_secret_keyword_nearby": self.has_secret_keyword_nearby,
            "sequential_char_ratio": self.sequential_char_ratio,
            "repeated_pattern_ratio": self.repeated_pattern_ratio,
            "char_class_transitions": self.char_class_transitions,
            "ngram_score": self.ngram_score,
            "gibberish_score": self.gibberish_score,
        }


class FeatureExtractor:
    """Extract ML features from potential secrets."""

    # Known secret prefixes
    SECRET_PREFIXES = [
        "sk-",
        "pk-",
        "ghp_",
        "gho_",
        "ghs_",
        "AKIA",
        "ASIA",
        "xox",
        "AIza",
        "ya29.",
        "bearer",
        "token",
        "api_key",
        "apikey",
        "secret",
        "password",
    ]

    # Test file patterns
    TEST_FILE_PATTERNS = [
        r"test[s]?/",
        r"test_",
        r"_test\.",
        r"\.test\.",
        r"\.spec\.",
        r"fixture",
        r"mock",
    ]

    # Example file patterns
    EXAMPLE_FILE_PATTERNS = [
        r"example[s]?/",
        r"demo[s]?/",
        r"sample[s]?/",
        r"\.example\.",
        r"_example\.",
    ]

    # Secret keywords for context analysis
    SECRET_KEYWORDS = [
        "secret",
        "password",
        "token",
        "key",
        "credential",
        "auth",
        "api_key",
        "apikey",
        "access_token",
        "private",
    ]

    # UUID pattern
    UUID_PATTERN = re.compile(
        r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.IGNORECASE
    )

    # Base64 pattern
    BASE64_PATTERN = re.compile(r"^[A-Za-z0-9+/]*={0,2}$")

    # Hex pattern
    HEX_PATTERN = re.compile(r"^[0-9a-fA-F]+$")

    def __init__(self):
        """Initialize the feature extractor."""
        # Common n-grams in English (for gibberish detection)
        self.common_bigrams = set(
            [
                "th",
                "he",
                "in",
                "er",
                "an",
                "re",
                "on",
                "at",
                "en",
                "nd",
                "ti",
                "es",
                "or",
                "te",
                "of",
                "ed",
                "is",
                "it",
                "al",
                "ar",
            ]
        )

    def extract(
        self, text: str, context: str = "", file_path: str = "", variable_name: str = ""
    ) -> SecretFeatures:
        """
        Extract all features from a potential secret.

        Args:
            text: The potential secret value
            context: Surrounding code context
            file_path: Path to the source file
            variable_name: Name of the variable containing the value

        Returns:
            SecretFeatures object with all extracted features
        """
        features = SecretFeatures()

        if not text:
            return features

        # Basic features
        features.length = len(text)
        features.entropy = self._calculate_entropy(text)
        features.unique_char_ratio = len(set(text)) / len(text) if text else 0

        # Character type features
        features.uppercase_ratio = sum(1 for c in text if c.isupper()) / len(text)
        features.lowercase_ratio = sum(1 for c in text if c.islower()) / len(text)
        features.digit_ratio = sum(1 for c in text if c.isdigit()) / len(text)
        features.special_char_ratio = sum(1 for c in text if not c.isalnum()) / len(text)

        # Pattern features
        features.has_prefix = self._has_secret_prefix(text)
        features.is_base64_like = self._is_base64_like(text)
        features.is_hex_like = self._is_hex_like(text)
        features.is_uuid_like = bool(self.UUID_PATTERN.match(text))

        # Context features
        features.is_in_test_file = self._is_test_file(file_path)
        features.is_in_example_file = self._is_example_file(file_path)
        features.variable_name_suggests_secret = self._variable_suggests_secret(variable_name)
        features.has_secret_keyword_nearby = self._has_secret_keyword(context)

        # Advanced features
        features.sequential_char_ratio = self._calculate_sequential_ratio(text)
        features.repeated_pattern_ratio = self._calculate_repeated_pattern_ratio(text)
        features.char_class_transitions = self._count_char_class_transitions(text)
        features.ngram_score = self._calculate_ngram_score(text)
        features.gibberish_score = self._calculate_gibberish_score(text)

        return features

    def _calculate_entropy(self, text: str) -> float:
        """Calculate Shannon entropy of a string."""
        if not text:
            return 0.0

        freq = Counter(text)
        length = len(text)
        entropy = 0.0

        for count in freq.values():
            if count > 0:
                p = count / length
                entropy -= p * math.log2(p)

        return entropy

    def _has_secret_prefix(self, text: str) -> bool:
        """Check if text starts with a known secret prefix."""
        text_lower = text.lower()
        return any(text_lower.startswith(prefix.lower()) for prefix in self.SECRET_PREFIXES)

    def _is_base64_like(self, text: str) -> bool:
        """Check if text looks like base64."""
        if len(text) < 8:
            return False
        return bool(self.BASE64_PATTERN.match(text))

    def _is_hex_like(self, text: str) -> bool:
        """Check if text looks like hex."""
        if len(text) < 16 or len(text) % 2 != 0:
            return False
        return bool(self.HEX_PATTERN.match(text))

    def _is_test_file(self, file_path: str) -> bool:
        """Check if file is a test file."""
        if not file_path:
            return False
        file_lower = file_path.lower()
        return any(re.search(pattern, file_lower) for pattern in self.TEST_FILE_PATTERNS)

    def _is_example_file(self, file_path: str) -> bool:
        """Check if file is an example file."""
        if not file_path:
            return False
        file_lower = file_path.lower()
        return any(re.search(pattern, file_lower) for pattern in self.EXAMPLE_FILE_PATTERNS)

    def _variable_suggests_secret(self, variable_name: str) -> bool:
        """Check if variable name suggests it's meant to hold a secret."""
        if not variable_name:
            return False
        var_lower = variable_name.lower()
        return any(keyword in var_lower for keyword in self.SECRET_KEYWORDS)

    def _has_secret_keyword(self, context: str) -> bool:
        """Check if context contains secret-related keywords."""
        if not context:
            return False
        context_lower = context.lower()
        return any(keyword in context_lower for keyword in self.SECRET_KEYWORDS)

    def _calculate_sequential_ratio(self, text: str) -> float:
        """Calculate ratio of sequential characters."""
        if len(text) < 2:
            return 0.0

        sequential_count = 0
        for i in range(len(text) - 1):
            if abs(ord(text[i + 1]) - ord(text[i])) == 1:
                sequential_count += 1

        return sequential_count / (len(text) - 1)

    def _calculate_repeated_pattern_ratio(self, text: str) -> float:
        """Calculate ratio of repeated patterns."""
        if len(text) < 4:
            return 0.0

        # Check for 2-character and 3-character repeating patterns
        for pattern_len in [2, 3]:
            for i in range(len(text) - pattern_len * 2 + 1):
                pattern = text[i : i + pattern_len]
                if pattern * 2 in text:
                    return 1.0

        # Count character repetition
        max_repeat = 1
        current_repeat = 1
        for i in range(1, len(text)):
            if text[i] == text[i - 1]:
                current_repeat += 1
                max_repeat = max(max_repeat, current_repeat)
            else:
                current_repeat = 1

        return max_repeat / len(text)

    def _count_char_class_transitions(self, text: str) -> int:
        """Count transitions between character classes."""
        if len(text) < 2:
            return 0

        def get_class(c: str) -> int:
            if c.isupper():
                return 0
            if c.islower():
                return 1
            if c.isdigit():
                return 2
            return 3

        transitions = 0
        prev_class = get_class(text[0])

        for i in range(1, len(text)):
            curr_class = get_class(text[i])
            if curr_class != prev_class:
                transitions += 1
            prev_class = curr_class

        return transitions

    def _calculate_ngram_score(self, text: str) -> float:
        """Calculate n-gram commonality score."""
        if len(text) < 2:
            return 0.0

        text_lower = text.lower()
        bigrams = [text_lower[i : i + 2] for i in range(len(text_lower) - 1)]

        if not bigrams:
            return 0.0

        common_count = sum(1 for bg in bigrams if bg in self.common_bigrams)
        return common_count / len(bigrams)

    def _calculate_gibberish_score(self, text: str) -> float:
        """
        Calculate gibberish score (higher = more random/gibberish).

        Real secrets tend to be random, while false positives often
        contain readable text.
        """
        if len(text) < 4:
            return 0.5

        # Factors that indicate gibberish:
        # 1. High entropy
        # 2. Low n-gram score
        # 3. High character class transitions

        entropy = self._calculate_entropy(text)
        ngram_score = self._calculate_ngram_score(text)
        transitions = self._count_char_class_transitions(text)

        # Normalize entropy (max theoretical is log2(len(charset)))
        normalized_entropy = entropy / 6.0  # Approximate max

        # Normalize transitions
        normalized_transitions = transitions / max(1, len(text) - 1)

        # Combine factors (high entropy, low ngram, high transitions = gibberish)
        gibberish_score = (
            normalized_entropy * 0.4 + (1 - ngram_score) * 0.3 + normalized_transitions * 0.3
        )

        return min(1.0, max(0.0, gibberish_score))


class MLSecretClassifier:
    """
    Machine learning classifier for secret detection.

    Uses a trained XGBoost model to classify potential secrets.
    Falls back to heuristics if model is not available.
    """

    def __init__(self, model_path: str | None = None):
        """
        Initialize the ML classifier.

        Args:
            model_path: Path to the trained model file. If None, searches
                       default locations or uses heuristics.
        """
        self.feature_extractor = FeatureExtractor()
        self.model = None
        self.model_loaded = False

        # Try to load the model
        if model_path:
            self._load_model(model_path)
        else:
            self._find_and_load_model()

    def _find_and_load_model(self) -> None:
        """Search for model in default locations."""
        default_locations = [
            Path(__file__).parent / "models" / "stage2_xgboost.json",
            Path(__file__).parent.parent / "models" / "stage2_xgboost.json",
            Path.home() / ".vantage" / "models" / "stage2_xgboost.json",
        ]

        for location in default_locations:
            if location.exists():
                self._load_model(str(location))
                if self.model_loaded:
                    return

        logger.info("No ML model found, using heuristic classification")

    def _load_model(self, model_path: str) -> None:
        """Load the XGBoost model."""
        try:
            import xgboost as xgb

            self.model = xgb.XGBClassifier()
            self.model.load_model(model_path)
            self.model_loaded = True
            logger.info(f"Loaded ML model from {model_path}")
        except ImportError:
            logger.warning("xgboost not installed, using heuristic classification")
        except Exception as e:
            logger.error(f"Failed to load model from {model_path}: {e}")

    def classify(
        self, text: str, context: str = "", file_path: str = "", variable_name: str = ""
    ) -> tuple[bool, float, dict[str, Any]]:
        """
        Classify a potential secret.

        Args:
            text: The potential secret value
            context: Surrounding code context
            file_path: Path to the source file
            variable_name: Name of the variable

        Returns:
            Tuple of (is_secret, confidence, metadata)
        """
        # Extract features
        features = self.feature_extractor.extract(text, context, file_path, variable_name)

        metadata = {
            "features": features.to_dict(),
            "ml_enabled": self.model_loaded,
        }

        if self.model_loaded:
            return self._classify_with_model(features, metadata)
        else:
            return self._classify_with_heuristics(features, metadata)

    def _classify_with_model(
        self, features: SecretFeatures, metadata: dict[str, Any]
    ) -> tuple[bool, float, dict[str, Any]]:
        """Classify using the ML model."""
        try:
            feature_vector = [features.to_vector()]
            prediction = self.model.predict(feature_vector)[0]
            probability = self.model.predict_proba(feature_vector)[0][1]

            metadata["classification_method"] = "ml_model"
            metadata["probability"] = float(probability)

            return bool(prediction), float(probability), metadata
        except Exception as e:
            logger.error(f"ML classification failed: {e}")
            return self._classify_with_heuristics(features, metadata)

    def _classify_with_heuristics(
        self, features: SecretFeatures, metadata: dict[str, Any]
    ) -> tuple[bool, float, dict[str, Any]]:
        """Classify using rule-based heuristics."""
        metadata["classification_method"] = "heuristics"
        confidence = 0.5

        # Positive signals
        if features.entropy > 4.5:
            confidence += 0.15
        if features.has_prefix:
            confidence += 0.2
        if features.gibberish_score > 0.7:
            confidence += 0.1
        if features.variable_name_suggests_secret:
            confidence += 0.1
        if features.has_secret_keyword_nearby:
            confidence += 0.1

        # Negative signals
        if features.is_in_test_file:
            confidence -= 0.25
        if features.is_in_example_file:
            confidence -= 0.2
        if features.is_uuid_like:
            confidence -= 0.4
        if features.sequential_char_ratio > 0.5:
            confidence -= 0.2
        if features.repeated_pattern_ratio > 0.3:
            confidence -= 0.15
        if features.length < 8:
            confidence -= 0.3

        # Clamp to [0, 1]
        confidence = max(0.0, min(1.0, confidence))

        is_secret = confidence > 0.5

        return is_secret, confidence, metadata
