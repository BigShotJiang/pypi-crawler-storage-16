"""
Semantic Secret Validation with Claude API.

This module provides semantic understanding of potential secrets using Claude's
language model to reduce false positives by 25-35%. It understands context,
variable naming, and the semantic meaning of values to determine if something
is a real secret or a false positive.

This is the killer feature - no other tool has semantic understanding at this level.
"""

import hashlib
import json
import logging
import os
import re
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class SemanticClassification:
    """Result of semantic classification of a potential secret."""

    is_secret: bool
    confidence: float  # 0.0-1.0
    reasoning: str
    cached: bool = False


class SemanticSecretClassifier:
    """
    Uses Claude API to understand semantic meaning of potential secrets.

    This is the killer feature - no other tool has semantic understanding.
    """

    # Cache settings
    MAX_CACHE_SIZE = 10000

    # Common placeholders that are definitely NOT secrets
    OBVIOUS_PLACEHOLDERS = [
        "your_api_key_here",
        "your_token_here",
        "placeholder",
        "example",
        "test_key",
        "dummy_key",
        "xxx",
        "todo",
        "changeme",
        "password123",
        "admin",
        "secret",
        "12345",
    ]

    def __init__(self, api_key: str | None = None, cache_enabled: bool = True):
        """
        Initialize semantic classifier.

        Args:
            api_key: Anthropic API key. If None, reads from ANTHROPIC_API_KEY env var.
            cache_enabled: Whether to cache results to reduce API calls.
        """
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        self.cache_enabled = cache_enabled
        self.cache = {}
        self.client = None

        # Only initialize client if API key is available
        if self.api_key:
            try:
                from anthropic import Anthropic

                self.client = Anthropic(api_key=self.api_key)
                logger.info("Semantic classifier initialized with Claude API")
            except ImportError:
                logger.warning("anthropic package not installed, semantic classification disabled")
                self.client = None
            except Exception as e:
                logger.error(f"Failed to initialize Claude API client: {e}")
                self.client = None
        else:
            logger.info("No API key provided, semantic classification disabled")

    def _generate_cache_key(
        self, text: str, context: str, variable_name: str | None, file_path: str
    ) -> str:
        """Generate a cache key for the classification request."""
        # Create a stable hash of the inputs
        content = f"{text}:{context}:{variable_name}:{file_path}"
        return hashlib.sha256(content.encode()).hexdigest()

    def _check_obvious_placeholder(self, text: str) -> SemanticClassification | None:
        """
        Quick check for obvious placeholders without API call.

        Returns:
            SemanticClassification if obvious placeholder, None otherwise.
        """
        text_lower = text.lower()

        # Check exact matches
        if text_lower in self.OBVIOUS_PLACEHOLDERS:
            return SemanticClassification(
                is_secret=False,
                confidence=0.95,
                reasoning=f"Obvious placeholder value: {text}",
                cached=False,
            )

        # Check patterns
        placeholder_patterns = [
            r"^(your|my|the)_[a-z_]+_(here|value|key|token)$",
            r"^xxx+$",
            r"^test_[a-z_]+$",
            r"^dummy_[a-z_]+$",
            r"^example_[a-z_]+$",
            r"^placeholder_?[a-z]*$",
            r"^todo_?[a-z]*$",
        ]

        for pattern in placeholder_patterns:
            if re.match(pattern, text_lower):
                return SemanticClassification(
                    is_secret=False,
                    confidence=0.9,
                    reasoning=f"Matches placeholder pattern: {pattern}",
                    cached=False,
                )

        return None

    def classify_secret(
        self,
        text: str,
        context: str,
        variable_name: str | None = None,
        file_path: str = "",
    ) -> SemanticClassification:
        """
        Classify if this is a real secret or false positive using semantic understanding.

        Args:
            text: The potential secret value.
            context: Surrounding code context (5-10 lines).
            variable_name: Name of the variable containing the value.
            file_path: Path to the file being analyzed.

        Returns:
            SemanticClassification with:
            - is_secret: bool indicating if this is a real secret
            - confidence: 0.0-1.0 confidence score
            - reasoning: Human-readable explanation
        """
        # Quick check for obvious placeholders
        placeholder_result = self._check_obvious_placeholder(text)
        if placeholder_result:
            return placeholder_result

        # Check cache if enabled
        if self.cache_enabled:
            cache_key = self._generate_cache_key(text, context, variable_name, file_path)
            if cache_key in self.cache:
                result = self.cache[cache_key]
                result.cached = True
                return result

        # If no API client, fall back to conservative approach
        if not self.client:
            return SemanticClassification(
                is_secret=True,  # Conservative: assume secret
                confidence=0.5,  # But low confidence
                reasoning="Semantic analysis unavailable (no API key)",
                cached=False,
            )

        # Prepare the prompt for Claude
        prompt = self._build_prompt(text, context, variable_name, file_path)

        try:
            # Call Claude API
            response = self.client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=200,
                temperature=0.0,  # Deterministic for consistency
                messages=[{"role": "user", "content": prompt}],
            )

            # Parse the response
            response_text = response.content[0].text

            # Try to parse as JSON
            try:
                result_json = json.loads(response_text)
                classification = SemanticClassification(
                    is_secret=result_json.get("is_secret", True),
                    confidence=float(result_json.get("confidence", 0.5)),
                    reasoning=result_json.get("reasoning", "No reasoning provided"),
                    cached=False,
                )
            except json.JSONDecodeError:
                # Fallback if response isn't valid JSON
                logger.warning(f"Failed to parse Claude response as JSON: {response_text}")
                classification = SemanticClassification(
                    is_secret=True,
                    confidence=0.5,
                    reasoning="Failed to parse API response",
                    cached=False,
                )

            # Cache the result
            if self.cache_enabled and len(self.cache) < self.MAX_CACHE_SIZE:
                self.cache[cache_key] = classification

            return classification

        except Exception as e:
            logger.error(f"Claude API call failed: {e}")
            # Return conservative result on error
            return SemanticClassification(
                is_secret=True,  # Conservative: assume secret
                confidence=0.5,  # But low confidence
                reasoning=f"Claude API failed: {str(e)}",
                cached=False,
            )

    def _build_prompt(
        self, text: str, context: str, variable_name: str | None, file_path: str
    ) -> str:
        """Build the prompt for Claude API."""
        # Determine file type from path
        file_type = "unknown"
        if file_path:
            if "test" in file_path.lower():
                file_type = "test file"
            elif "example" in file_path.lower():
                file_type = "example/documentation"
            elif file_path.endswith(".md"):
                file_type = "markdown documentation"
            elif file_path.endswith(".yaml") or file_path.endswith(".yml"):
                file_type = "configuration"
            elif file_path.endswith(".py"):
                file_type = "Python source"
            elif file_path.endswith(".js") or file_path.endswith(".ts"):
                file_type = "JavaScript/TypeScript source"

        prompt = f"""You are a security expert analyzing potential secrets in code.

Variable name: {variable_name or "unknown"}
File type: {file_type}
File path: {file_path or "unknown"}
Potential secret value: {text}

Code context:
```
{context}
```

Is this a REAL secret (API key, password, token) or a FALSE POSITIVE (test data, placeholder, example)?

Consider:
1. Is the value obviously fake/placeholder? (e.g., "your_api_key_here", "xxx", "test123", "example_token")
2. Is this in a test file or example code?
3. Does the context suggest this is production code or documentation?
4. Is the entropy/randomness consistent with a real secret?
5. Are there comments indicating this is a placeholder?
6. Does the variable name suggest it's a placeholder (e.g., "example_key", "test_token")?
7. Is this a well-known test value or default credential?

Respond ONLY with valid JSON in this exact format:
{{
    "is_secret": true/false,
    "confidence": 0.0-1.0,
    "reasoning": "brief explanation (max 50 words)"
}}"""

        return prompt

    def clear_cache(self):
        """Clear the cache of semantic classifications."""
        self.cache.clear()
        logger.info("Semantic classifier cache cleared")

    def get_cache_stats(self) -> dict[str, Any]:
        """Get cache statistics."""
        return {
            "enabled": self.cache_enabled,
            "size": len(self.cache),
            "max_size": self.MAX_CACHE_SIZE,
            "hit_rate": 0.0,  # Would need to track hits/misses for this
        }
