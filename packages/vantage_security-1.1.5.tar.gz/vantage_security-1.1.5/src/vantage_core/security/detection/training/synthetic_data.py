"""
Synthetic training data generator for secret detection.

Since SecretBench dataset is not readily available, this generates
realistic training data for Stage 2 XGBoost model training.
"""

import random
import string
from dataclasses import dataclass


@dataclass
class TrainingSample:
    """A single training sample with label."""

    text: str
    context: str
    file_path: str
    is_secret: bool  # Ground truth label
    source: str = "synthetic"  # Data source
    metadata: dict = None  # Additional metadata

    def __post_init__(self):
        """Initialize mutable default."""
        if self.metadata is None:
            self.metadata = {}


class SyntheticDataGenerator:
    """Generate synthetic training data for ML model."""

    def __init__(self, seed: int = 42):
        """Initialize generator with random seed."""
        random.seed(seed)

        # Real secret prefixes
        self.secret_prefixes = [
            "ghp_",  # GitHub Personal Access Token
            "gho_",  # GitHub OAuth Token
            "ghs_",  # GitHub Secret Scanning Token
            "sk-",  # OpenAI/Stripe API Key
            "AKIA",  # AWS Access Key
            "ASIA",  # AWS Temporary Access Key
            "xoxb-",  # Slack Bot Token
            "xoxp-",  # Slack User Token
            "AIza",  # Google API Key
            "ya29.",  # Google OAuth Token
        ]

        # Placeholder patterns
        self.placeholder_patterns = [
            "your-api-key-here",
            "insert-your-token",
            "YOUR_SECRET_KEY",
            "replace-with-your-key",
            "api_key_goes_here",
            "xxxxxxxxxxxxxxxx",
            "placeholder",
            "example-token",
            "test-key-12345",
        ]

        # Secret types for realistic generation
        self.secret_types = {
            "github_pat": {
                "prefix": "ghp_",
                "length": 36,
                "charset": string.ascii_letters + string.digits,
            },
            "openai_key": {
                "prefix": "sk-",
                "length": 48,
                "charset": string.ascii_letters + string.digits,
            },
            "aws_key": {
                "prefix": "AKIA",
                "length": 20,
                "charset": string.ascii_uppercase + string.digits,
            },
            "generic_api": {
                "prefix": "",
                "length": 32,
                "charset": string.ascii_letters + string.digits,
            },
            "hex_secret": {
                "prefix": "",
                "length": 64,
                "charset": string.hexdigits.lower(),
            },
            "base64_token": {
                "prefix": "",
                "length": 44,
                "charset": string.ascii_letters + string.digits + "+/",
            },
        }

    def _generate_random_string(self, length: int, charset: str) -> str:
        """Generate random string for synthetic data (uses random.choice for reproducibility)."""
        return "".join(random.choice(charset) for _ in range(length))

    def generate_real_secret(self, secret_type: str = None) -> str:
        """Generate a realistic-looking real secret."""
        if secret_type is None:
            secret_type = random.choice(list(self.secret_types.keys()))

        config = self.secret_types[secret_type]
        prefix = config["prefix"]
        length = config["length"] - len(prefix)
        charset = config["charset"]

        # Generate high-entropy random string
        secret_part = self._generate_random_string(length, charset)
        return prefix + secret_part

    def generate_placeholder(self) -> str:
        """Generate a placeholder value."""
        pattern = random.choice(self.placeholder_patterns)

        # Add variations
        if random.random() < 0.3:
            # Uppercase variation
            return pattern.upper()
        elif random.random() < 0.3:
            # Add prefix
            prefix = random.choice(["test_", "mock_", "fake_", "example_"])
            return prefix + pattern

        return pattern

    def generate_uuid(self) -> str:
        """Generate a UUID (common false positive)."""
        # Use random.choices for reproducibility instead of uuid.uuid4()
        hex_chars = string.hexdigits.lower()[:16]  # 0-9 and a-f
        parts = [
            "".join(random.choices(hex_chars, k=8)),
            "".join(random.choices(hex_chars, k=4)),
            "".join(random.choices(hex_chars, k=4)),
            "".join(random.choices(hex_chars, k=4)),
            "".join(random.choices(hex_chars, k=12)),
        ]
        return "-".join(parts)

    def generate_hash(self, hash_type: str = "sha256") -> str:
        """Generate a hash (common false positive)."""
        if hash_type == "md5":
            return "".join(random.choices(string.hexdigits.lower(), k=32))
        elif hash_type == "sha1":
            return "".join(random.choices(string.hexdigits.lower(), k=40))
        else:  # sha256
            return "".join(random.choices(string.hexdigits.lower(), k=64))

    def generate_config_key(self) -> str:
        """Generate a config key name (false positive)."""
        key_parts = [
            random.choice(["api", "secret", "token", "key", "password"]),
            random.choice(["_", "-", ""]),
            random.choice(["key", "token", "secret", "value", ""]),
        ]
        return "".join(key_parts)

    def generate_context(self, text: str, is_secret: bool) -> str:
        """Generate code context for the sample."""
        contexts = []

        if is_secret:
            # Real secret contexts
            contexts = [
                f'api_key = "{text}"',
                f'headers = {{"Authorization": "Bearer {text}"}}',
                f'client = Client(api_key="{text}")',
                f'API_TOKEN = "{text}"',
                f'config["secret_key"] = "{text}"',
            ]
        else:
            # Placeholder/FP contexts
            contexts = [
                f'# Example: API_KEY = "{text}"',
                f'assert token == "{text}"  # test',
                f'EXAMPLE_KEY = "{text}"',
                f'mock_token = "{text}"',
                f"# Replace {text} with your actual key",
            ]

        return random.choice(contexts)

    def generate_file_path(self, is_secret: bool) -> str:
        """Generate realistic file path."""
        if is_secret:
            # Real secret file paths
            paths = [
                "src/config/production.py",
                "app/auth.py",
                "services/api_client.py",
                "lib/database.py",
                "config/settings.py",
            ]
        else:
            # Test/example file paths
            paths = [
                "tests/test_auth.py",
                "examples/example_config.py",
                "tests/fixtures/mock_data.py",
                "docs/example_usage.py",
                "tests/integration/test_api.py",
            ]

        return random.choice(paths)

    def generate_dataset(
        self, num_samples: int = 10000, positive_ratio: float = 0.4
    ) -> list[TrainingSample]:
        """
        Generate a synthetic training dataset.

        Args:
            num_samples: Total number of samples to generate
            positive_ratio: Ratio of real secrets (0.4 = 40% real secrets)

        Returns:
            List of TrainingSample objects
        """
        samples = []
        num_positives = int(num_samples * positive_ratio)
        num_negatives = num_samples - num_positives

        # Generate positive samples (real secrets)
        for _ in range(num_positives):
            text = self.generate_real_secret()
            context = self.generate_context(text, is_secret=True)
            file_path = self.generate_file_path(is_secret=True)

            samples.append(
                TrainingSample(text=text, context=context, file_path=file_path, is_secret=True)
            )

        # Generate negative samples (false positives)
        fp_types = ["placeholder", "uuid", "hash", "config_key"]
        for _ in range(num_negatives):
            fp_type = random.choice(fp_types)

            if fp_type == "placeholder":
                text = self.generate_placeholder()
            elif fp_type == "uuid":
                text = self.generate_uuid()
            elif fp_type == "hash":
                text = self.generate_hash(random.choice(["md5", "sha1", "sha256"]))
            else:  # config_key
                text = self.generate_config_key()

            context = self.generate_context(text, is_secret=False)
            file_path = self.generate_file_path(is_secret=False)

            samples.append(
                TrainingSample(text=text, context=context, file_path=file_path, is_secret=False)
            )

        # Shuffle samples
        random.shuffle(samples)

        return samples

    def split_dataset(
        self,
        samples: list[TrainingSample],
        train_ratio: float = 0.7,
        val_ratio: float = 0.15,
        test_ratio: float = 0.15,
    ) -> tuple[list[TrainingSample], list[TrainingSample], list[TrainingSample]]:
        """
        Split dataset into train/val/test sets.

        Args:
            samples: List of training samples
            train_ratio: Ratio for training set
            val_ratio: Ratio for validation set
            test_ratio: Ratio for test set

        Returns:
            Tuple of (train_samples, val_samples, test_samples)
        """
        assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6, "Ratios must sum to 1.0"

        total = len(samples)
        train_end = int(total * train_ratio)
        val_end = train_end + int(total * val_ratio)

        train_samples = samples[:train_end]
        val_samples = samples[train_end:val_end]
        test_samples = samples[val_end:]

        return train_samples, val_samples, test_samples


def main():
    """Generate and save synthetic dataset."""
    print("Generating synthetic training dataset...")

    generator = SyntheticDataGenerator(seed=42)

    # Generate 10,000 samples (40% real secrets, 60% false positives)
    samples = generator.generate_dataset(num_samples=10000, positive_ratio=0.4)

    # Split into train/val/test
    train_samples, val_samples, test_samples = generator.split_dataset(samples)

    print("\nDataset Statistics:")
    print(f"  Total samples: {len(samples)}")
    print(f"  Train samples: {len(train_samples)} ({len(train_samples)/len(samples)*100:.1f}%)")
    print(f"  Val samples: {len(val_samples)} ({len(val_samples)/len(samples)*100:.1f}%)")
    print(f"  Test samples: {len(test_samples)} ({len(test_samples)/len(samples)*100:.1f}%)")

    # Calculate class distribution
    train_positives = sum(1 for s in train_samples if s.is_secret)
    val_positives = sum(1 for s in val_samples if s.is_secret)
    test_positives = sum(1 for s in test_samples if s.is_secret)

    print("\nClass Distribution:")
    print(
        f"  Train: {train_positives}/{len(train_samples)} positives ({train_positives/len(train_samples)*100:.1f}%)"
    )
    print(
        f"  Val: {val_positives}/{len(val_samples)} positives ({val_positives/len(val_samples)*100:.1f}%)"
    )
    print(
        f"  Test: {test_positives}/{len(test_samples)} positives ({test_positives/len(test_samples)*100:.1f}%)"
    )

    # Show sample examples
    print("\nSample Examples:")
    print("\nReal Secrets:")
    for sample in [s for s in train_samples if s.is_secret][:3]:
        print(f"  Text: {sample.text[:50]}...")
        print(f"  Context: {sample.context}")
        print(f"  File: {sample.file_path}")
        print()

    print("False Positives:")
    for sample in [s for s in train_samples if not s.is_secret][:3]:
        print(f"  Text: {sample.text[:50]}...")
        print(f"  Context: {sample.context}")
        print(f"  File: {sample.file_path}")
        print()

    return train_samples, val_samples, test_samples


if __name__ == "__main__":
    main()
