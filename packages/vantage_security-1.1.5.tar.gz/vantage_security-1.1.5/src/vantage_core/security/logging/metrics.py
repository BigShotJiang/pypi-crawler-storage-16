"""
Performance metrics logging for Vantage security scanner.

Provides timing decorators, memory tracking, and metrics aggregation
for monitoring scanner performance (US-003).
"""

from __future__ import annotations

import functools
import gc
import time
import tracemalloc
from collections.abc import Callable
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, TypeVar

import structlog

from vantage_core.security.logging.categories import LogCategory, MetricUnit
from vantage_core.security.logging.factory import LoggerFactory

F = TypeVar("F", bound=Callable[..., Any])


@dataclass
class TimingMetrics:
    """Container for timing metrics."""

    total_ms: float = 0.0
    phase_timings: dict[str, float] = field(default_factory=dict)
    file_timings: dict[str, float] = field(default_factory=dict)


@dataclass
class MemoryMetrics:
    """Container for memory metrics."""

    peak_bytes: int = 0
    current_bytes: int = 0
    allocations: int = 0


@dataclass
class ScanMetrics:
    """
    Aggregate metrics for a complete scan operation.

    Includes timing, memory, and finding counts for
    comprehensive performance monitoring.
    """

    scan_id: str
    timing: TimingMetrics = field(default_factory=TimingMetrics)
    memory: MemoryMetrics = field(default_factory=MemoryMetrics)
    files_scanned: int = 0
    files_failed: int = 0
    lines_analyzed: int = 0
    findings_count: int = 0
    findings_by_severity: dict[str, int] = field(default_factory=dict)
    rules_evaluated: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert metrics to dictionary for logging."""
        return {
            "scan_id": self.scan_id,
            "timing": {
                "total_ms": round(self.timing.total_ms, 2),
                "phases": self.timing.phase_timings,
                "files": {
                    "count": len(self.timing.file_timings),
                    "avg_ms": (
                        round(
                            sum(self.timing.file_timings.values()) / len(self.timing.file_timings),
                            2,
                        )
                        if self.timing.file_timings
                        else 0
                    ),
                    "max_ms": (
                        round(max(self.timing.file_timings.values()), 2)
                        if self.timing.file_timings
                        else 0
                    ),
                },
            },
            "memory": {
                "peak_mb": round(self.memory.peak_bytes / (1024 * 1024), 2),
                "current_mb": round(self.memory.current_bytes / (1024 * 1024), 2),
                "allocations": self.memory.allocations,
            },
            "counts": {
                "files_scanned": self.files_scanned,
                "files_failed": self.files_failed,
                "lines_analyzed": self.lines_analyzed,
                "findings_total": self.findings_count,
                "findings_by_severity": self.findings_by_severity,
                "rules_evaluated": self.rules_evaluated,
            },
        }


class MetricsCollector:
    """
    Collector for aggregating performance metrics during scans.

    Provides methods for timing phases, tracking memory, and
    logging metrics at scan completion.
    """

    def __init__(self, scan_id: str, enable_memory_tracking: bool = False):
        """
        Initialize metrics collector.

        Args:
            scan_id: Unique identifier for the scan
            enable_memory_tracking: Enable tracemalloc (adds ~10% overhead)
        """
        self.scan_id = scan_id
        self.metrics = ScanMetrics(scan_id=scan_id)
        self._start_time: float | None = None
        self._enable_memory = enable_memory_tracking
        self._logger = LoggerFactory.get_logger(LogCategory.METRICS, scan_id=scan_id)

    def start(self) -> None:
        """Start collecting metrics for the scan."""
        self._start_time = time.perf_counter()

        if self._enable_memory:
            tracemalloc.start()

        self._logger.debug("metrics_collection_started", memory_tracking=self._enable_memory)

    def stop(self) -> None:
        """Stop collecting and finalize metrics."""
        if self._start_time:
            self.metrics.timing.total_ms = (time.perf_counter() - self._start_time) * 1000

        if self._enable_memory:
            current, peak = tracemalloc.get_traced_memory()
            self.metrics.memory.current_bytes = current
            self.metrics.memory.peak_bytes = peak
            tracemalloc.stop()

    def record_phase(self, phase_name: str, duration_ms: float) -> None:
        """
        Record timing for a scan phase.

        Args:
            phase_name: Name of the phase (e.g., "parsing", "analysis")
            duration_ms: Duration in milliseconds
        """
        self.metrics.timing.phase_timings[phase_name] = round(duration_ms, 2)
        self._logger.debug(
            "phase_completed",
            phase=phase_name,
            duration_ms=round(duration_ms, 2),
        )

    def record_file(self, file_path: str, duration_ms: float) -> None:
        """
        Record timing for a single file.

        Args:
            file_path: Path to the file
            duration_ms: Duration in milliseconds
        """
        self.metrics.timing.file_timings[file_path] = round(duration_ms, 2)

    def increment_files(self, success: bool = True) -> None:
        """Increment file count."""
        if success:
            self.metrics.files_scanned += 1
        else:
            self.metrics.files_failed += 1

    def add_lines(self, count: int) -> None:
        """Add to total lines analyzed."""
        self.metrics.lines_analyzed += count

    def add_finding(self, severity: str) -> None:
        """
        Record a finding.

        Args:
            severity: Severity level of the finding
        """
        self.metrics.findings_count += 1
        self.metrics.findings_by_severity[severity] = (
            self.metrics.findings_by_severity.get(severity, 0) + 1
        )

    def add_rules_evaluated(self, count: int) -> None:
        """Add to total rules evaluated."""
        self.metrics.rules_evaluated += count

    def log_summary(self) -> dict[str, Any]:
        """
        Log metrics summary and return metrics dict.

        Returns:
            Dictionary of all metrics
        """
        metrics_dict = self.metrics.to_dict()
        self._logger.info(
            "scan_metrics",
            **metrics_dict,
        )
        return metrics_dict

    @contextmanager
    def phase(self, phase_name: str):
        """
        Context manager for timing a phase.

        Example:
            with collector.phase("parsing"):
                # parsing code here
                pass
        """
        start = time.perf_counter()
        try:
            yield
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            self.record_phase(phase_name, duration_ms)

    @contextmanager
    def file(self, file_path: str):
        """
        Context manager for timing a file.

        Example:
            with collector.file("/path/to/file.py"):
                # scanning code here
                pass
        """
        start = time.perf_counter()
        try:
            yield
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            self.record_file(file_path, duration_ms)


def timed(
    phase_name: str | None = None,
    log_level: str = "debug",
) -> Callable[[F], F]:
    """
    Decorator for timing function execution.

    Args:
        phase_name: Optional phase name (defaults to function name)
        log_level: Log level for timing output (debug, info)

    Returns:
        Decorated function

    Example:
        @timed("parsing")
        def parse_file(path):
            ...

        @timed()
        def analyze():
            ...
    """

    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            logger = LoggerFactory.get_logger(LogCategory.METRICS_TIMING)
            name = phase_name or func.__name__
            start = time.perf_counter()

            try:
                result = func(*args, **kwargs)
                duration_ms = (time.perf_counter() - start) * 1000

                log_method = getattr(logger, log_level)
                log_method(
                    "function_timed",
                    function=name,
                    duration_ms=round(duration_ms, 2),
                    unit=MetricUnit.MILLISECONDS.value,
                )

                return result
            except Exception:
                duration_ms = (time.perf_counter() - start) * 1000
                logger.warning(
                    "function_failed",
                    function=name,
                    duration_ms=round(duration_ms, 2),
                    exc_info=True,
                )
                raise

        return wrapper  # type: ignore

    return decorator


def log_memory_usage(func: F) -> F:
    """
    Decorator for logging memory usage of a function.

    Warning: This adds significant overhead and should only be used
    for debugging or in non-production environments.

    Example:
        @log_memory_usage
        def memory_intensive_operation():
            ...
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        logger = LoggerFactory.get_logger(LogCategory.METRICS_MEMORY)

        # Force garbage collection for accurate measurement
        gc.collect()
        tracemalloc.start()

        try:
            result = func(*args, **kwargs)

            current, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()

            logger.debug(
                "memory_usage",
                function=func.__name__,
                current_mb=round(current / (1024 * 1024), 2),
                peak_mb=round(peak / (1024 * 1024), 2),
                unit=MetricUnit.MEGABYTES.value,
            )

            return result
        except Exception:
            tracemalloc.stop()
            raise

    return wrapper  # type: ignore


@contextmanager
def measure_time(name: str, logger: structlog.BoundLogger | None = None):
    """
    Context manager for ad-hoc timing measurements.

    Args:
        name: Name for the timed operation
        logger: Optional logger (uses default if not provided)

    Example:
        with measure_time("database_query"):
            results = db.execute(query)
    """
    if logger is None:
        logger = LoggerFactory.get_logger(LogCategory.METRICS_TIMING)

    start = time.perf_counter()
    try:
        yield
    finally:
        duration_ms = (time.perf_counter() - start) * 1000
        logger.debug(
            "operation_timed",
            operation=name,
            duration_ms=round(duration_ms, 2),
            unit=MetricUnit.MILLISECONDS.value,
        )
