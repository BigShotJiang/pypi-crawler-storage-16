"""
ML-based security detection module.

This module provides machine learning capabilities for vulnerability detection:
- VulnerabilityDetector: GraphCodeBERT-based vulnerability detection
- LightweightVulnerabilityDetector: Fast biLSTM-based detection
- MLSecurityScanner: Integration with the security scanning pipeline
- Data collectors for training data from CVE/GHSA sources
- Training pipeline for model updates
"""

from vantage_core.security.ml.curated_dataset import (
    CuratedExample,
    get_all_curated_examples,
    get_statistics,
    iter_training_examples,
)
from vantage_core.security.ml.data_collector import (
    CVEFixesCollector,
    GHSACollector,
    OWASPBenchmarkCollector,
    SecListsCollector,
    VulnerabilityDataset,
    VulnerabilityExample,
)
from vantage_core.security.ml.integrated_scanner import (
    CodeChunk,
    MLSecurityScanner,
    ScanConfig,
    create_ml_scanner,
)
from vantage_core.security.ml.lightweight_detector import (
    BiLSTMVulnerabilityModel,
    LightweightPrediction,
    LightweightVulnerabilityDetector,
    SimpleTokenizer,
    export_to_onnx,
    train_lightweight_model,
)
from vantage_core.security.ml.real_data_collector import (
    GoVulnDBCollector,
    NVDCollector,
    PyPAAdvisoryCollector,
    RealVulnerability,
    RealVulnerabilityDataset,
    RustSecCollector,
)
from vantage_core.security.ml.vulnerability_model import (
    GraphCodeBERTVulnerabilityModel,
    VulnerabilityDetector,
    VulnerabilityModelTrainer,
    VulnerabilityPrediction,
    get_detector,
)

__all__ = [
    # Vulnerability detection
    "VulnerabilityDetector",
    "VulnerabilityPrediction",
    "GraphCodeBERTVulnerabilityModel",
    "VulnerabilityModelTrainer",
    "get_detector",
    # Lightweight detection
    "LightweightVulnerabilityDetector",
    "LightweightPrediction",
    "BiLSTMVulnerabilityModel",
    "SimpleTokenizer",
    "train_lightweight_model",
    "export_to_onnx",
    # Scanner integration
    "MLSecurityScanner",
    "ScanConfig",
    "CodeChunk",
    "create_ml_scanner",
    # Data collection
    "VulnerabilityExample",
    "VulnerabilityDataset",
    "GHSACollector",
    "CVEFixesCollector",
    "OWASPBenchmarkCollector",
    "SecListsCollector",
    # Curated data
    "CuratedExample",
    "get_all_curated_examples",
    "iter_training_examples",
    "get_statistics",
    # Real data collection
    "RealVulnerability",
    "RealVulnerabilityDataset",
    "PyPAAdvisoryCollector",
    "NVDCollector",
    "RustSecCollector",
    "GoVulnDBCollector",
]
