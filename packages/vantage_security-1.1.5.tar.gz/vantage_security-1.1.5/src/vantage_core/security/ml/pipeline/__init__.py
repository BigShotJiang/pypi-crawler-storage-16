"""
ML Pipeline for Vulnerability Detection.

This package provides automated data collection, training, and model updates
for the vulnerability detection model.

Components:
- data_fetcher: Daily fetching from all vulnerability sources
- trainer: Model training and fine-tuning
- scheduler: Automated scheduling and orchestration
- monitor: Pipeline health and model performance monitoring
"""

from .data_fetcher import VulnerabilityDataFetcher
from .scheduler import PipelineScheduler
from .trainer import ModelTrainer

__all__ = ["VulnerabilityDataFetcher", "ModelTrainer", "PipelineScheduler"]
