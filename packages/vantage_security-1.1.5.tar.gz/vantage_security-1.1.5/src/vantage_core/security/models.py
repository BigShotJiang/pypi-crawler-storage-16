"""
Security data models for Vantage Core.

Provides TrustLevel, ToolCategory, SecurityAgent and related classes
used by the security simulation modules.
"""

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class Severity(str, Enum):
    """Vulnerability severity levels."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class OWASPCategory(str, Enum):
    """OWASP LLM Top 10 vulnerability categories."""

    LLM01 = "LLM01: Prompt Injection"
    LLM02 = "LLM02: Insecure Output Handling"
    LLM03 = "LLM03: Training Data Poisoning"
    LLM04 = "LLM04: Model Denial of Service"
    LLM05 = "LLM05: Supply Chain Vulnerabilities"
    LLM06 = "LLM06: Sensitive Information Disclosure"
    LLM07 = "LLM07: Insecure Plugin Design"
    LLM08 = "LLM08: Excessive Agency"
    LLM09 = "LLM09: Overreliance"
    LLM10 = "LLM10: Model Theft"


class MAASCategory(str, Enum):
    """Multi-Agent Attack Surface categories."""

    MAAS01 = "MAAS-01: Prompt Infection"
    MAAS02 = "MAAS-02: Agent Collusion"
    MAAS03 = "MAAS-03: Trust Boundary Violation"
    MAAS04 = "MAAS-04: Shared Context Poisoning"
    MAAS05 = "MAAS-05: Orchestration Manipulation"


class CommunicationType(str, Enum):
    """Type of communication between agents."""

    DIRECT = "direct"  # Direct message
    DELEGATION = "delegation"  # Task delegation
    BROADCAST = "broadcast"  # Broadcast to all
    SHARED_MEMORY = "shared_memory"  # Via shared memory/context


class ContentType(str, Enum):
    """Type of content being exchanged."""

    TEXT = "text"
    CODE = "code"
    STRUCTURED = "structured"  # JSON, etc.
    BINARY = "binary"


class VulnerabilityCategory(str, Enum):
    """General vulnerability categories for classification."""

    PROMPT_INJECTION = "prompt_injection"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    DATA_LEAKAGE = "data_leakage"
    TRUST_BOUNDARY_VIOLATION = "trust_boundary_violation"
    EXCESSIVE_AGENCY = "excessive_agency"
    INSECURE_TOOL_USE = "insecure_tool_use"
    CODE_EXECUTION = "code_execution"
    CONFIGURATION_WEAKNESS = "configuration_weakness"
    HARDCODED_SECRET = "hardcoded_secret"
    UNSAFE_DELEGATION = "unsafe_delegation"
    SUPPLY_CHAIN = "supply_chain"
    LICENSE_VIOLATION = "license_violation"


class TrustLevel(int, Enum):
    """Trust levels for agents and data."""

    EXTERNAL = 0  # User inputs, external API responses
    USER = 1  # Authenticated user context
    INTERNAL = 2  # Internal agent outputs
    PRIVILEGED = 3  # System configurations, database queries
    SYSTEM = 4  # Root operations, key management


class ToolCategory(str, Enum):
    """Categories of tool capabilities."""

    FILE_SYSTEM = "file_system"
    NETWORK = "network"
    CODE_EXECUTION = "code_execution"
    DATABASE = "database"
    EXTERNAL_API = "external_api"
    MEMORY = "memory"
    SYSTEM = "system"
    API = "api"


# Constants for memory optimization
MAX_CONTEXT_LINES = 5
MAX_SNIPPET_LENGTH = 1000


@dataclass
class SecurityTool:
    """Represents a tool with security-relevant metadata."""

    name: str
    description: str
    categories: list[ToolCategory] = field(default_factory=list)
    required_trust_level: TrustLevel = TrustLevel.INTERNAL
    has_side_effects: bool = False
    input_schema: dict[str, Any] | None = None
    risk_score: float = 0.0  # 0-10 scale


@dataclass
class SecurityAgent:
    """Represents an agent with security-relevant metadata."""

    id: str
    name: str
    framework: str
    trust_level: TrustLevel = TrustLevel.INTERNAL
    tools: list[SecurityTool] = field(default_factory=list)
    system_prompt: str | None = None
    role: str | None = None
    goal: str | None = None
    memory_scope: str | None = None
    allow_delegation: bool = False
    file_path: str | None = None
    line_number: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def has_code_execution(self) -> bool:
        """Check if agent has code execution capabilities."""
        return any(ToolCategory.CODE_EXECUTION in tool.categories for tool in self.tools)

    @property
    def has_external_access(self) -> bool:
        """Check if agent has external network access."""
        return any(
            ToolCategory.NETWORK in tool.categories or ToolCategory.EXTERNAL_API in tool.categories
            for tool in self.tools
        )

    @property
    def highest_tool_trust(self) -> TrustLevel:
        """Get the highest trust level required by any tool."""
        if not self.tools:
            return TrustLevel.EXTERNAL
        return max(tool.required_trust_level for tool in self.tools)


@dataclass
class AgentCommunication:
    """Represents a communication channel between agents."""

    source_id: str
    target_id: str
    communication_type: str  # direct, broadcast, callback
    data_sensitivity: str = "internal"  # public, internal, confidential, secret
    bidirectional: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class SourceLocation:
    """
    Precise source code location for a security finding.

    Captures exact position information for IDE integration,
    code navigation, and detailed reporting.
    """

    file_path: str
    start_line: int
    end_line: int
    start_column: int = 1
    end_column: int | None = None
    context_before: list[str] = field(default_factory=list)
    context_after: list[str] = field(default_factory=list)
    highlighted_code: str = ""

    def __post_init__(self):
        """Truncate context to prevent memory bloat."""
        self.context_before = self.context_before[-MAX_CONTEXT_LINES:]
        self.context_after = self.context_after[:MAX_CONTEXT_LINES]
        if len(self.highlighted_code) > MAX_SNIPPET_LENGTH:
            self.highlighted_code = self.highlighted_code[:MAX_SNIPPET_LENGTH] + "..."

    @property
    def line_number(self) -> int:
        """Backward compatibility - return start_line."""
        return self.start_line

    def get_code_context(self, num_lines: int = 3) -> str:
        """Get code with surrounding context lines."""
        lines = []
        context_before = self.context_before[-num_lines:]
        for i, line in enumerate(context_before):
            line_num = self.start_line - len(context_before) + i
            lines.append(f"{line_num:4d} | {line}")

        highlighted_lines = self.highlighted_code.split("\n")
        for i, code_line in enumerate(highlighted_lines):
            line_num = self.start_line + i
            lines.append(f"{line_num:4d} > {code_line}")

        context_after = self.context_after[:num_lines]
        for i, line in enumerate(context_after):
            line_num = self.end_line + 1 + i
            lines.append(f"{line_num:4d} | {line}")

        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "file_path": self.file_path,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "start_column": self.start_column,
            "end_column": self.end_column,
            "highlighted_code": self.highlighted_code,
            "context_before": self.context_before,
            "context_after": self.context_after,
        }


@dataclass
class FindingExplanation:
    """
    Rich explanation of why a finding was flagged.

    US-009: Enhanced Finding Descriptions
    US-011: Severity Justification
    """

    what_was_found: str  # What was detected
    why_its_risky: str  # Why it's a security risk
    how_to_fix: str  # How to remediate
    matched_pattern: str | None = None  # The pattern that triggered this
    risk_factors: list[str] = field(default_factory=list)  # Factors that influenced severity
    severity_justification: str = ""  # Why this severity was assigned
    attack_scenario: str = ""  # Concrete example of how this could be exploited
    references: list[str] = field(default_factory=list)  # Links to documentation


@dataclass
class SecurityFinding:
    """
    Represents a security finding/vulnerability detected during scanning.

    Each finding includes severity, confidence score, OWASP mapping,
    location information, and remediation recommendations.
    """

    id: str
    title: str
    description: str
    severity: Severity
    confidence: float  # 0-1 scale
    owasp_category: OWASPCategory
    category: VulnerabilityCategory
    file_path: str
    line_number: int
    code_snippet: str
    recommendation: str
    agent_id: str | None = None
    cwe_id: str | None = None
    maas_category: MAASCategory | None = None
    evidence: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    # Enhanced location information (US-001, US-002, US-010)
    location: SourceLocation | None = None

    # Enhanced explanation (US-009, US-011)
    explanation: FindingExplanation | None = None

    # Detection context (US-008)
    detection_method: str = "ast"  # "ast", "regex", "heuristic", "semantic"
    enclosing_function: str | None = None
    enclosing_class: str | None = None
    is_in_test_file: bool = False
    is_in_comment: bool = False

    # Severity factors (US-011)
    severity_factors: list[str] = field(default_factory=list)

    # Trust inference confidence (US-003)
    trust_confidence: float = 1.0

    @staticmethod
    def generate_id() -> str:
        """Generate a unique finding ID."""
        return f"FINDING-{uuid.uuid4().hex[:8].upper()}"

    @property
    def cvss_score(self) -> float:
        """Calculate approximate CVSS-like score based on severity."""
        severity_scores = {
            Severity.CRITICAL: 9.5,
            Severity.HIGH: 7.5,
            Severity.MEDIUM: 5.0,
            Severity.LOW: 2.5,
            Severity.INFO: 0.0,
        }
        return severity_scores.get(self.severity, 0.0) * self.confidence

    @property
    def sla_hours(self) -> int:
        """Get recommended SLA in hours for remediation."""
        sla_map = {
            Severity.CRITICAL: 24,
            Severity.HIGH: 168,  # 7 days
            Severity.MEDIUM: 720,  # 30 days
            Severity.LOW: 2160,  # 90 days
            Severity.INFO: 0,  # No SLA
        }
        return sla_map.get(self.severity, 0)

    @property
    def start_line(self) -> int:
        """Get start line from location or fall back to line_number."""
        if self.location:
            return self.location.start_line
        return self.line_number

    @property
    def end_line(self) -> int:
        """Get end line from location or fall back to line_number."""
        if self.location:
            return self.location.end_line
        return self.line_number

    @property
    def start_column(self) -> int:
        """Get start column from location."""
        if self.location:
            return self.location.start_column
        return 1

    @property
    def end_column(self) -> int | None:
        """Get end column from location."""
        if self.location:
            return self.location.end_column
        return None

    def get_formatted_location(self) -> str:
        """Get formatted location string (file:line:column)."""
        if self.location:
            if self.location.end_column:
                return f"{self.location.file_path}:{self.location.start_line}:{self.location.start_column}"
            return f"{self.location.file_path}:{self.location.start_line}"
        return f"{self.file_path}:{self.line_number}"


@dataclass
class SecurityScanResult:
    """
    Complete results from a security scan.

    Contains all findings, scanned agents, detected frameworks,
    and scan metadata.
    """

    scan_id: str
    timestamp: datetime
    findings: list[SecurityFinding]
    agents_scanned: int
    frameworks_detected: list[str]
    scan_duration_ms: int
    topology_score: float | None = None
    confidence: float = 1.0  # Overall confidence in results
    agents: list[SecurityAgent] = field(default_factory=list)
    communications: list[AgentCommunication] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @staticmethod
    def generate_scan_id() -> str:
        """Generate a unique scan ID."""
        return f"SCAN-{uuid.uuid4().hex[:12].upper()}"

    @property
    def critical_count(self) -> int:
        """Count of critical severity findings."""
        return sum(1 for f in self.findings if f.severity == Severity.CRITICAL)

    @property
    def high_count(self) -> int:
        """Count of high severity findings."""
        return sum(1 for f in self.findings if f.severity == Severity.HIGH)

    @property
    def medium_count(self) -> int:
        """Count of medium severity findings."""
        return sum(1 for f in self.findings if f.severity == Severity.MEDIUM)

    @property
    def low_count(self) -> int:
        """Count of low severity findings."""
        return sum(1 for f in self.findings if f.severity == Severity.LOW)

    @property
    def info_count(self) -> int:
        """Count of informational findings."""
        return sum(1 for f in self.findings if f.severity == Severity.INFO)

    @property
    def findings_by_owasp(self) -> dict[OWASPCategory, list[SecurityFinding]]:
        """Group findings by OWASP category."""
        result: dict[OWASPCategory, list[SecurityFinding]] = {}
        for finding in self.findings:
            if finding.owasp_category not in result:
                result[finding.owasp_category] = []
            result[finding.owasp_category].append(finding)
        return result

    @property
    def findings_by_agent(self) -> dict[str, list[SecurityFinding]]:
        """Group findings by agent ID."""
        result: dict[str, list[SecurityFinding]] = {}
        for finding in self.findings:
            agent_id = finding.agent_id or "unknown"
            if agent_id not in result:
                result[agent_id] = []
            result[agent_id].append(finding)
        return result

    def get_findings_by_severity(self, severity: Severity) -> list[SecurityFinding]:
        """Get all findings of a specific severity."""
        return [f for f in self.findings if f.severity == severity]

    def to_sarif(self) -> dict[str, Any]:
        """Export results in SARIF format for CI/CD integration."""
        return {
            "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
            "version": "2.1.0",
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": "Vantage Security Scanner",
                            "version": "1.0.0",
                            "informationUri": "https://vantage.io",
                        }
                    },
                    "results": [
                        {
                            "ruleId": finding.id,
                            "level": self._severity_to_sarif_level(finding.severity),
                            "message": {"text": finding.description},
                            "locations": [
                                {
                                    "physicalLocation": {
                                        "artifactLocation": {"uri": finding.file_path},
                                        "region": {
                                            "startLine": finding.start_line,
                                            "startColumn": finding.start_column,
                                            "endLine": finding.end_line,
                                            "endColumn": finding.end_column or 1,
                                            "snippet": {"text": finding.code_snippet},
                                        },
                                    }
                                }
                            ],
                        }
                        for finding in self.findings
                    ],
                }
            ],
        }

    @staticmethod
    def _severity_to_sarif_level(severity: Severity) -> str:
        """Convert severity to SARIF level."""
        mapping = {
            Severity.CRITICAL: "error",
            Severity.HIGH: "error",
            Severity.MEDIUM: "warning",
            Severity.LOW: "note",
            Severity.INFO: "none",
        }
        return mapping.get(severity, "warning")
