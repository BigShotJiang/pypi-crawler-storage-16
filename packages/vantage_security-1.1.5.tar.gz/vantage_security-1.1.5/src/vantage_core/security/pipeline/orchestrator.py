"""
Pipeline Orchestrator (US-150).

End-to-end security scan workflow orchestration with stage
management, error recovery, and progress tracking.
"""

import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

from vantage_core.scanners.universal_scanner import UniversalScanner
from vantage_core.security.analysis.severity_adjuster import (
    SeverityAdjuster,
    SeverityAdjustmentConfig,
)
from vantage_core.security.deduplication.cross_framework import (
    deduplicate_findings,
)
from vantage_core.security.errors import (
    EncodingError,
    ErrorSeverity,
    MimicError,
    ParseErrorFinding,
    ScanError,
    SyntaxParseError,
)
from vantage_core.security.logging import LogCategory, LoggerFactory
from vantage_core.security.ml.integrated_scanner import MLSecurityScanner, ScanConfig
from vantage_core.security.models import (
    AgentCommunication,
    OWASPCategory,
    SecurityAgent,
    SecurityFinding,
    SecurityScanResult,
    Severity,
    TrustLevel,
    VulnerabilityCategory,
)
from vantage_core.security.pipeline.progress import (
    ProgressCallback,
    ProgressReporter,
)
from vantage_core.security.remediation.generator import (
    Remediation,
    RemediationGenerator,
)
from vantage_core.security.scanners.anthropic import AnthropicSecurityScanner
from vantage_core.security.scanners.autogen import AutoGenSecurityScanner
from vantage_core.security.scanners.crewai import CrewAISecurityScanner
from vantage_core.security.scanners.google_genai import GoogleGenAISecurityScanner
from vantage_core.security.scanners.langchain import LangChainSecurityScanner
from vantage_core.security.scanners.llamaindex import LlamaIndexSecurityScanner
from vantage_core.security.scanners.openai import OpenAISecurityScanner
from vantage_core.security.scanners.semantic_kernel import SemanticKernelSecurityScanner
from vantage_core.security.scoring.engine import ATSSResult, SecurityScoringEngine
from vantage_core.security.simulation.blast_radius import (
    BlastRadiusCalculator,
    BlastRadiusResult,
)
from vantage_core.security.simulation.propagation import (
    InfectionSimulator,
    SimulationConfig,
)
from vantage_core.security.topology.graph import AgentGraph


class ScanStage(str, Enum):
    """Stages of the security scan pipeline."""

    INITIALIZATION = "initialization"
    PARSING = "parsing"
    TOPOLOGY = "topology"
    TRUST_ANALYSIS = "trust_analysis"
    VULNERABILITY_SCAN = "vulnerability_scan"
    ML_DETECTION = "ml_detection"
    SCORING = "scoring"
    SIMULATION = "simulation"
    REMEDIATION = "remediation"
    REPORT = "report"
    COMPLETED = "completed"


@dataclass
class StageResult:
    """Result from a pipeline stage."""

    stage: ScanStage
    success: bool
    duration_ms: int
    data: Any = None
    error: str | None = None


@dataclass
class PipelineConfig:
    """Configuration for pipeline execution."""

    # Stage configuration
    skip_simulation: bool = False
    skip_remediation: bool = False
    skip_ml_detection: bool = False  # ML-based attack detection
    parallel_parsing: bool = True

    # Limits
    max_agents: int = 1000
    max_files: int = 10000
    timeout_seconds: int = 600

    # Retry configuration
    max_retries: int = 3
    retry_delay_ms: int = 1000

    # Simulation configuration
    simulation_config: SimulationConfig | None = None

    # ML configuration
    ml_confidence_threshold: float = (
        0.7  # Minimum confidence for ML detections (raised to reduce false positives)
    )
    ml_categories: list[str] | None = None  # Attack categories to detect (None = all)

    # ML Code Scanner configuration (trained CodeBERT model)
    # NOTE: Disabled by default due to slow inference (~45s model loading on CPU)
    # Enable explicitly when deep ML analysis is needed
    use_ml_code_scanner: bool = False  # Enable ML-based code vulnerability scanning
    ml_model_path: str | None = None  # Path to trained model (None = use default)
    ml_code_confidence_threshold: float = 0.5  # Confidence threshold for code scanner

    # Lightweight ML Scanner (biLSTM model - fast alternative)
    # ~5MB model, <1s loading, ~10ms inference
    use_lightweight_ml: bool = True  # Enable lightweight ML code scanning (recommended)
    lightweight_model_path: str | None = None  # Path to lightweight model

    # Prompt Injection Detection (embedding-based similarity)
    # Uses sentence-transformers to detect injection patterns via semantic similarity
    use_prompt_injection_classifier: bool = (
        True  # Enable embedding-based prompt injection detection
    )
    prompt_injection_threshold: float = 0.75  # Similarity threshold for injection detection

    # Output configuration
    generate_report: bool = True

    # Severity adjustment configuration
    adjust_severity_for_context: bool = True  # Enable context-based severity adjustment
    severity_adjustment_config: SeverityAdjustmentConfig | None = None  # Custom adjustment config

    # Deduplication configuration
    deduplicate_findings: bool = True  # Enable cross-framework deduplication


@dataclass
class PipelineResult:
    """
    Complete result from a security scan pipeline.

    Contains all outputs from each stage including findings,
    scores, simulations, and remediations.
    """

    scan_id: str
    status: str  # completed, failed, partial
    stages_completed: list[ScanStage]
    stages_failed: list[ScanStage]
    scan_result: SecurityScanResult | None
    atss_result: ATSSResult | None
    simulation_results: list[BlastRadiusResult]
    remediations: list[Remediation]
    duration_ms: int
    started_at: datetime
    completed_at: datetime
    errors: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def is_success(self) -> bool:
        """Check if pipeline completed successfully."""
        return self.status == "completed"

    @property
    def has_critical_findings(self) -> bool:
        """Check if there are critical findings."""
        if not self.scan_result:
            return False
        return self.scan_result.critical_count > 0


class SecurityPipeline:
    """
    Main pipeline orchestrator for security scanning.

    Coordinates all stages of security analysis from parsing
    through remediation generation.
    """

    def __init__(
        self,
        config: PipelineConfig | None = None,
    ):
        """
        Initialize the pipeline.

        Args:
            config: Pipeline configuration
        """
        self.config = config or PipelineConfig()
        self.progress_reporter = ProgressReporter()

        # Initialize stage processors
        self.scoring_engine = SecurityScoringEngine()
        self.infection_simulator = InfectionSimulator()
        self.blast_radius_calculator = BlastRadiusCalculator()
        self.remediation_generator = RemediationGenerator()

        # Initialize ML components
        self._ml_detector = None
        self._ml_classifier = None
        self._ml_code_scanner = None
        self._lightweight_detector = None

        # Initialize severity adjuster
        self.severity_adjuster = SeverityAdjuster(config=self.config.severity_adjustment_config)

        # Initialize logger
        self.logger = LoggerFactory.get_logger(LogCategory.PIPELINE)

    def _get_ml_detector(self):
        """Lazy-load ML detector for performance."""
        if self._ml_detector is None:
            try:
                from vantage_core.security.detection.advanced_detector import (
                    AdvancedMultiAgentDetector,
                )

                self._ml_detector = AdvancedMultiAgentDetector()
            except ImportError:
                self.logger.warning("ML detector not available")
        return self._ml_detector

    def _get_ml_classifier(self):
        """Lazy-load ML secret classifier for performance."""
        if self._ml_classifier is None:
            try:
                from vantage_core.security.detection.ml_features import (
                    MLSecretClassifier,
                )

                self._ml_classifier = MLSecretClassifier()
            except ImportError:
                self.logger.warning("ML classifier not available")
        return self._ml_classifier

    def _get_ml_code_scanner(self, config: PipelineConfig) -> MLSecurityScanner | None:
        """Lazy-load ML code scanner with trained CodeBERT model."""
        if self._ml_code_scanner is None:
            try:
                from pathlib import Path

                # Use configured model path or default
                model_path = config.ml_model_path
                if model_path is None:
                    default_path = Path("models/vulnerability_detector/model.pt")
                    if default_path.exists():
                        model_path = str(default_path)

                scan_config = ScanConfig(
                    min_confidence=config.ml_code_confidence_threshold,
                    skip_test_files=False,  # Scan test files too
                    test_file_confidence_factor=0.5,  # Reduce confidence for test files
                )

                self._ml_code_scanner = MLSecurityScanner(
                    config=scan_config,
                    model_path=model_path,
                )
                self.logger.info(
                    "ml_code_scanner_initialized",
                    model_path=model_path or "default",
                    confidence_threshold=config.ml_code_confidence_threshold,
                )
            except Exception as e:
                self.logger.warning(f"ML code scanner not available: {e}")
                return None
        return self._ml_code_scanner

    def _get_lightweight_detector(self, config: PipelineConfig):
        """
        Lazy-load lightweight biLSTM detector for fast code scanning.

        This detector is ~100x faster than CodeBERT:
        - Model size: ~5MB (vs 500MB)
        - Load time: <1s (vs ~45s)
        - Inference: ~10ms per file (vs ~500ms)
        """
        if self._lightweight_detector is None:
            try:
                from pathlib import Path

                from vantage_core.security.ml.lightweight_detector import (
                    LightweightVulnerabilityDetector,
                )

                # Use configured model path or default
                model_path = config.lightweight_model_path
                if model_path is None:
                    default_path = Path("models/lightweight_vuln_detector.pt")
                    if default_path.exists():
                        model_path = str(default_path)

                if model_path:
                    self._lightweight_detector = LightweightVulnerabilityDetector(
                        model_path=model_path,
                        use_onnx=True,  # Prefer ONNX for faster inference
                    )
                    self._lightweight_detector.initialize()
                    self.logger.info(
                        "lightweight_detector_initialized",
                        model_path=model_path,
                    )
                else:
                    # No model, create detector with pattern-matching only
                    self._lightweight_detector = LightweightVulnerabilityDetector()
                    self.logger.info("lightweight_detector_initialized", model_path="pattern_only")

            except Exception as e:
                self.logger.warning(f"Lightweight detector not available: {e}")
                return None
        return self._lightweight_detector

    def scan(
        self,
        path: Path | str,
        config: PipelineConfig | None = None,
        progress_callback: ProgressCallback | None = None,
    ) -> PipelineResult:
        """
        Run complete security scan pipeline.

        Args:
            path: Path to project directory or file
            config: Optional config override
            progress_callback: Optional progress callback

        Returns:
            PipelineResult with all scan outputs
        """
        config = config or self.config
        path = Path(path) if isinstance(path, str) else path

        # Initialize pipeline state
        scan_id = f"SCAN-{uuid.uuid4().hex[:12].upper()}"
        started_at = datetime.now()
        stages_completed = []
        stages_failed = []
        errors = []

        # Initialize results
        scan_result = None
        atss_result = None
        graph = None
        simulation_results = []
        remediations = []

        # Register progress callback
        if progress_callback:
            self.progress_reporter.add_callback(progress_callback)

        try:
            # Stage 1: Initialization
            self._report_stage_start(ScanStage.INITIALIZATION)
            init_result = self._run_stage(
                ScanStage.INITIALIZATION,
                lambda: self._stage_initialization(path, config),
            )
            if init_result.success:
                stages_completed.append(ScanStage.INITIALIZATION)
            else:
                stages_failed.append(ScanStage.INITIALIZATION)
                errors.append(init_result.error or "Initialization failed")

            # Stage 2: Parsing
            self._report_stage_start(ScanStage.PARSING)
            parse_result = self._run_stage(
                ScanStage.PARSING, lambda: self._stage_parsing(path, config)
            )
            if parse_result.success:
                stages_completed.append(ScanStage.PARSING)
                agents, communications, findings, frameworks, parse_errors = parse_result.data
                # US-007: Track parsing errors but continue with partial results
                for err in parse_errors:
                    errors.append(f"[{err.error_code}] {err.message}")
            else:
                stages_failed.append(ScanStage.PARSING)
                errors.append(parse_result.error or "Parsing failed")
                raise PipelineError("Parsing stage failed")

            # Stage 3: Topology Building
            self._report_stage_start(ScanStage.TOPOLOGY)
            topology_result = self._run_stage(
                ScanStage.TOPOLOGY, lambda: self._stage_topology(agents, communications)
            )
            if topology_result.success:
                stages_completed.append(ScanStage.TOPOLOGY)
                graph = topology_result.data
            else:
                stages_failed.append(ScanStage.TOPOLOGY)
                errors.append(topology_result.error or "Topology building failed")

            # Stage 4: Trust Analysis
            self._report_stage_start(ScanStage.TRUST_ANALYSIS)
            trust_result = self._run_stage(
                ScanStage.TRUST_ANALYSIS,
                lambda: self._stage_trust_analysis(agents, graph, findings),
            )
            if trust_result.success:
                stages_completed.append(ScanStage.TRUST_ANALYSIS)
                trust_findings = trust_result.data
                findings.extend(trust_findings)
            else:
                stages_failed.append(ScanStage.TRUST_ANALYSIS)
                errors.append(trust_result.error or "Trust analysis failed")

            # Stage 5: Vulnerability Scan
            self._report_stage_start(ScanStage.VULNERABILITY_SCAN)
            vuln_result = self._run_stage(
                ScanStage.VULNERABILITY_SCAN,
                lambda: self._stage_vulnerability_scan(path, agents, findings),
            )
            if vuln_result.success:
                stages_completed.append(ScanStage.VULNERABILITY_SCAN)
                additional_findings = vuln_result.data
                findings.extend(additional_findings)
            else:
                stages_failed.append(ScanStage.VULNERABILITY_SCAN)
                errors.append(vuln_result.error or "Vulnerability scan failed")

            # Stage 6: ML-based Detection (optional)
            if not config.skip_ml_detection:
                self._report_stage_start(ScanStage.ML_DETECTION)
                ml_result = self._run_stage(
                    ScanStage.ML_DETECTION,
                    lambda: self._stage_ml_detection(path, config),
                )
                if ml_result.success:
                    stages_completed.append(ScanStage.ML_DETECTION)
                    ml_findings = ml_result.data
                    findings.extend(ml_findings)
                else:
                    stages_failed.append(ScanStage.ML_DETECTION)
                    errors.append(ml_result.error or "ML detection failed")

            # Deduplicate findings across framework parsers
            if config.deduplicate_findings:
                original_count = len(findings)
                findings = deduplicate_findings(findings, preserve_metadata=True)
                self.logger.debug(
                    "deduplication_applied",
                    original_count=original_count,
                    deduplicated_count=len(findings),
                    reduction=original_count - len(findings),
                )

            # Apply severity adjustment based on context (test files, examples, etc.)
            if config.adjust_severity_for_context:
                adjusted_findings = []
                for finding in findings:
                    self.severity_adjuster.adjust_severity(finding)
                    if not self.severity_adjuster.should_suppress(finding):
                        adjusted_findings.append(finding)
                findings = adjusted_findings
                self.logger.debug(
                    "severity_adjustment_applied",
                    original_count=len(findings) + (len(findings) - len(adjusted_findings)),
                    adjusted_count=len(findings),
                )

            # Build scan result
            elapsed_ms = int((datetime.now() - started_at).total_seconds() * 1000)
            scan_result = SecurityScanResult(
                scan_id=scan_id,
                timestamp=started_at,
                findings=findings,
                agents_scanned=len(agents),
                frameworks_detected=frameworks,
                scan_duration_ms=elapsed_ms,
                agents=agents,
                communications=communications,
            )

            # Stage 6: Scoring
            self._report_stage_start(ScanStage.SCORING)
            scoring_result = self._run_stage(
                ScanStage.SCORING, lambda: self._stage_scoring(scan_result, graph)
            )
            if scoring_result.success:
                stages_completed.append(ScanStage.SCORING)
                atss_result = scoring_result.data
            else:
                stages_failed.append(ScanStage.SCORING)
                errors.append(scoring_result.error or "Scoring failed")

            # Stage 7: Simulation (optional)
            if not config.skip_simulation:
                self._report_stage_start(ScanStage.SIMULATION)
                sim_result = self._run_stage(
                    ScanStage.SIMULATION, lambda: self._stage_simulation(graph, config)
                )
                if sim_result.success:
                    stages_completed.append(ScanStage.SIMULATION)
                    simulation_results = sim_result.data
                else:
                    stages_failed.append(ScanStage.SIMULATION)
                    errors.append(sim_result.error or "Simulation failed")

            # Stage 8: Remediation (optional)
            if not config.skip_remediation:
                self._report_stage_start(ScanStage.REMEDIATION)
                rem_result = self._run_stage(
                    ScanStage.REMEDIATION,
                    lambda: self._stage_remediation(findings, frameworks),
                )
                if rem_result.success:
                    stages_completed.append(ScanStage.REMEDIATION)
                    remediations = rem_result.data
                else:
                    stages_failed.append(ScanStage.REMEDIATION)
                    errors.append(rem_result.error or "Remediation failed")

            # Stage 9: Report Generation (optional)
            if config.generate_report:
                self._report_stage_start(ScanStage.REPORT)
                report_result = self._run_stage(
                    ScanStage.REPORT,
                    lambda: self._stage_report(
                        scan_result, atss_result, simulation_results, remediations
                    ),
                )
                if report_result.success:
                    stages_completed.append(ScanStage.REPORT)
                else:
                    stages_failed.append(ScanStage.REPORT)
                    errors.append(report_result.error or "Report generation failed")

            # Mark completed
            stages_completed.append(ScanStage.COMPLETED)
            status = "completed" if not stages_failed else "partial"

        except PipelineError as e:
            status = "failed"
            errors.append(str(e))
        except Exception as e:
            status = "failed"
            errors.append(f"Unexpected error: {str(e)}")

        completed_at = datetime.now()
        duration_ms = int((completed_at - started_at).total_seconds() * 1000)

        # Report completion
        self._report_completion(status, duration_ms)

        return PipelineResult(
            scan_id=scan_id,
            status=status,
            stages_completed=stages_completed,
            stages_failed=stages_failed,
            scan_result=scan_result,
            atss_result=atss_result,
            simulation_results=simulation_results,
            remediations=remediations,
            duration_ms=duration_ms,
            started_at=started_at,
            completed_at=completed_at,
            errors=errors,
            metadata={
                "path": str(path),
                "config": {
                    "skip_simulation": config.skip_simulation,
                    "skip_remediation": config.skip_remediation,
                },
            },
        )

    def _run_stage(
        self,
        stage: ScanStage,
        executor: Callable[[], Any],
    ) -> StageResult:
        """
        Run a pipeline stage with error handling and retries.

        Args:
            stage: The stage to run
            executor: Function to execute

        Returns:
            StageResult with outcome
        """
        start_time = time.time()
        retries = 0

        while retries <= self.config.max_retries:
            try:
                result = executor()
                duration_ms = int((time.time() - start_time) * 1000)

                self._report_stage_complete(stage, duration_ms)

                return StageResult(
                    stage=stage,
                    success=True,
                    duration_ms=duration_ms,
                    data=result,
                )

            except Exception as e:
                retries += 1
                if retries <= self.config.max_retries:
                    time.sleep(self.config.retry_delay_ms / 1000)
                else:
                    duration_ms = int((time.time() - start_time) * 1000)
                    return StageResult(
                        stage=stage,
                        success=False,
                        duration_ms=duration_ms,
                        error=str(e),
                    )

        # Should not reach here
        return StageResult(
            stage=stage,
            success=False,
            duration_ms=0,
            error="Unknown error",
        )

    def _stage_initialization(self, path: Path, config: PipelineConfig) -> None:
        """Initialize the pipeline and validate inputs."""
        if not path.exists():
            raise ValueError(f"Path does not exist: {path}")

        # Check limits
        if path.is_dir():
            file_count = sum(1 for _ in path.rglob("*.py"))
            if file_count > config.max_files:
                raise ValueError(f"Too many files ({file_count} > {config.max_files})")

    def _stage_parsing(self, path: Path, config: PipelineConfig) -> tuple[
        list[SecurityAgent],
        list[AgentCommunication],
        list[SecurityFinding],
        list[str],
        list[ScanError],
    ]:
        """
        Parse project for agent definitions using real security scanners.

        US-007: Supports partial results on failure by continuing
        when individual files fail to parse.

        Returns:
            Tuple of (agents, communications, findings, frameworks, errors)
        """
        agents = []
        communications = []
        findings = []
        frameworks = []
        errors: list[ScanError] = []  # Track errors for partial results

        # Detect frameworks from content first
        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        detected_frameworks = set()
        for file_path in files[: config.max_files]:
            try:
                content = file_path.read_text()
                content_lower = content.lower()
                # Check for framework imports - match both 'from X' and 'import X' patterns
                # Order matters - check more specific patterns first
                if "from google.adk" in content_lower or "import google.adk" in content_lower:
                    detected_frameworks.add("google_adk")
                if "crewai" in content_lower:
                    detected_frameworks.add("crewai")
                if "autogen" in content_lower:
                    detected_frameworks.add("autogen")
                if any(x in content_lower for x in ["langchain", "langgraph", "langchain_core"]):
                    detected_frameworks.add("langchain")
                if "llama_index" in content_lower or "llamaindex" in content_lower:
                    detected_frameworks.add("llamaindex")
                if "semantic_kernel" in content_lower:
                    detected_frameworks.add("semantic_kernel")
                if "openai" in content_lower:
                    detected_frameworks.add("openai")
                if "anthropic" in content_lower:
                    detected_frameworks.add("anthropic")
                if "google.generativeai" in content_lower:
                    detected_frameworks.add("google_genai")
            except UnicodeDecodeError as e:
                # US-007: Track encoding errors but continue
                enc_error = EncodingError(str(file_path), "utf-8", e)
                errors.append(ScanError.from_exception(enc_error))
                # US-008: Create finding for unparseable file
                parse_finding = ParseErrorFinding(
                    file_path=str(file_path),
                    error_message=f"Encoding error: {e}",
                    error_code="VANTAGE-102",
                )
                findings.append(self._create_parse_error_finding(parse_finding))
            except PermissionError:
                # Track permission errors but continue
                from vantage_core.security.errors import PermissionDeniedError

                perm_error = PermissionDeniedError(str(file_path), "read")
                errors.append(ScanError.from_exception(perm_error))
            except Exception as e:
                # Track generic read errors but continue
                from vantage_core.security.errors import FileReadError

                read_error = FileReadError(str(file_path), e)
                errors.append(ScanError.from_exception(read_error))

        # Map frameworks to their scanners
        scanner_map = {
            "crewai": CrewAISecurityScanner,
            "autogen": AutoGenSecurityScanner,
            "langchain": LangChainSecurityScanner,
            "llamaindex": LlamaIndexSecurityScanner,
            "semantic_kernel": SemanticKernelSecurityScanner,
            "openai": OpenAISecurityScanner,
            "anthropic": AnthropicSecurityScanner,
            "google_genai": GoogleGenAISecurityScanner,
            # Google ADK uses LangChain scanner as it's based on similar patterns
            "google_adk": LangChainSecurityScanner,
        }

        # If google_adk detected, remove langchain to avoid duplicate scanning
        # (google_adk uses the same underlying scanner)
        if "google_adk" in detected_frameworks and "langchain" in detected_frameworks:
            detected_frameworks.discard("langchain")

        # If no specific framework detected, try all scanners
        if not detected_frameworks:
            detected_frameworks = set(scanner_map.keys())

        # Run appropriate scanners
        for framework_name in detected_frameworks:
            scanner_class = scanner_map.get(framework_name)
            if scanner_class:
                try:
                    scanner = scanner_class()
                    result = scanner.scan(path)

                    # Always track that we scanned this framework
                    frameworks.append(framework_name)

                    if result.agents:
                        agents.extend(result.agents)

                    if result.findings:
                        findings.extend(result.findings)

                    # Extract communications from connections if available
                    if hasattr(result, "communications"):
                        communications.extend(result.communications)
                except SyntaxError as e:
                    # US-007: Handle syntax errors gracefully
                    syntax_error = SyntaxParseError(
                        file_path=str(path),
                        line=getattr(e, "lineno", 0) or 0,
                        column=getattr(e, "offset", 0) or 0,
                        message=str(e.msg if hasattr(e, "msg") else str(e)),
                        cause=e,
                    )
                    errors.append(ScanError.from_exception(syntax_error))
                    # US-008: Create finding for unparseable file
                    parse_finding = ParseErrorFinding(
                        file_path=str(path),
                        error_message=str(e),
                        error_code="VANTAGE-101",
                        line_number=getattr(e, "lineno", None),
                        column_number=getattr(e, "offset", None),
                    )
                    findings.append(self._create_parse_error_finding(parse_finding))
                    frameworks.append(framework_name)  # Still track framework
                except MimicError as e:
                    # Handle Vantage-specific errors
                    errors.append(ScanError.from_exception(e))
                    frameworks.append(framework_name)
                except Exception as e:
                    # US-007: Log error but continue with other scanners
                    error = ScanError.from_generic_exception(
                        e,
                        file_path=str(path),
                        severity=ErrorSeverity.ERROR,
                    )
                    errors.append(error)
                    frameworks.append(framework_name)  # Still track framework
            elif framework_name in detected_frameworks:
                # Framework detected but no specific scanner - still track it
                frameworks.append(framework_name)

        frameworks = list(set(frameworks)) or list(detected_frameworks) or ["unknown"]

        # Augment with UniversalScanner for comprehensive agent detection
        # This catches agents from frameworks not covered by security scanners
        try:
            universal_scanner = UniversalScanner(verbose=False)
            universal_result = universal_scanner.scan_directory(path)

            # Get existing agent IDs to avoid duplicates
            existing_ids = {a.id for a in agents}

            # Add agents not already found by security scanners
            for detected_agent in universal_result.agents:
                # Convert DetectedAgent to SecurityAgent if not already present
                if detected_agent.id not in existing_ids:
                    security_agent = SecurityAgent(
                        id=detected_agent.id,
                        name=detected_agent.name,
                        framework=detected_agent.framework,
                        trust_level=TrustLevel.INTERNAL,
                        tools=[],
                        system_prompt=detected_agent.system_prompt or "",
                        role="",
                        goal="",
                        file_path=detected_agent.file_path,
                        line_number=detected_agent.line_number,
                        metadata={"source": "universal_scanner"},
                    )
                    agents.append(security_agent)
                    existing_ids.add(detected_agent.id)

                    # Track the framework
                    if detected_agent.framework and detected_agent.framework not in frameworks:
                        frameworks.append(detected_agent.framework)

            # Add connections not already present
            existing_connections = {(c.source_id, c.target_id) for c in communications}
            for conn in universal_result.connections:
                if (conn.source, conn.target) not in existing_connections:
                    communications.append(
                        AgentCommunication(
                            source_id=conn.source,
                            target_id=conn.target,
                            communication_type=(
                                conn.confidence_level.value
                                if hasattr(conn, "confidence_level")
                                else "unknown"
                            ),
                            bidirectional=False,
                            metadata={
                                "source": "universal_scanner",
                                "confidence": conn.confidence,
                            },
                        )
                    )

        except Exception as e:
            # Don't fail if universal scanner has issues - security scanners already ran
            self.logger.warning("universal_scanner_augmentation_failed", error=str(e))

        return agents, communications, findings, frameworks, errors

    def _create_parse_error_finding(self, parse_error: ParseErrorFinding) -> SecurityFinding:
        """
        Create a SecurityFinding from a parse error.

        US-008: Unparseable files are reported as findings with INFO severity.
        """
        return SecurityFinding(
            id=SecurityFinding.generate_id(),
            title="Unparseable File",
            description=f"File could not be parsed: {parse_error.error_message}. "
            "Unparseable files may indicate obfuscated or malicious code, "
            "or simply syntax errors that should be fixed.",
            severity=Severity.INFO,  # INFO severity doesn't fail build
            confidence=1.0,
            owasp_category=OWASPCategory.LLM09,
            category=VulnerabilityCategory.DATA_LEAKAGE,  # Using available category
            file_path=parse_error.file_path,
            line_number=parse_error.line_number or 1,
            code_snippet=f"Parse error: {parse_error.error_message[:100]}",
            recommendation="Review the file for syntax errors. If the file is "
            "intentionally obfuscated, investigate for potential "
            "security concerns.",
            cwe_id="CWE-1078",
            detection_method="parse_error",
        )

    def _stage_topology(
        self, agents: list[SecurityAgent], communications: list[AgentCommunication]
    ) -> AgentGraph:
        """Build topology graph from agents."""
        return AgentGraph.from_agents(agents, communications)

    def _stage_trust_analysis(
        self,
        agents: list[SecurityAgent],
        graph: AgentGraph | None,
        findings: list[SecurityFinding],
    ) -> list[SecurityFinding]:
        """Analyze trust boundaries and detect violations."""
        trust_findings = []
        # Trust analysis would be performed here
        return trust_findings

    def _stage_vulnerability_scan(
        self, path: Path, agents: list[SecurityAgent], findings: list[SecurityFinding]
    ) -> list[SecurityFinding]:
        """Scan for additional vulnerabilities."""
        additional_findings = []
        # Static analysis would be performed here
        return additional_findings

    def _stage_ml_detection(self, path: Path, config: PipelineConfig) -> list[SecurityFinding]:
        """
        Run ML-based attack pattern detection.

        Focuses on prompt files and agent configurations, NOT source code.
        Uses advanced detectors for:
        - Jailbreak attempts (DAN, role-play, token smuggling)
        - Data exfiltration patterns
        - Privilege escalation attempts
        - Agent impersonation
        - Memory/context poisoning
        - Injection cascades
        - Tool abuse patterns
        - DoS attempts
        """
        ml_findings = []

        detector = self._get_ml_detector()
        if detector is None:
            self.logger.warning("ML detector not available, skipping ML detection")
            return ml_findings

        # Category mapping for filtering
        category_map = {
            "jailbreak": "JAILBREAK",
            "exfiltration": "DATA_EXFILTRATION",
            "escalation": "PRIVILEGE_ESCALATION",
            "impersonation": "IMPERSONATION",
            "poisoning": "MEMORY_POISONING",
            "cascade": "INJECTION_CASCADE",
            "tool-abuse": "TOOL_ABUSE",
            "dos": "DENIAL_OF_SERVICE",
        }

        # Get files to scan - focus on prompt/config files
        if path.is_file():
            files = [path]
        else:
            files = []
            # Scan prompt-like files and configs
            for ext in ["*.txt", "*.md", "*.yaml", "*.yml", "*.toml"]:
                files.extend(list(path.rglob(ext))[: config.max_files])
            # For JSON files, only include those that look like configs
            for json_file in path.rglob("*.json"):
                if any(
                    kw in json_file.name.lower() for kw in ["prompt", "config", "agent", "system"]
                ):
                    files.append(json_file)

        # Filter out test files, examples, and docs that aren't actual prompts
        skip_patterns = [
            "test",
            "example",
            "demo",
            "sample",
            "mock",
            "__pycache__",
            ".git",
            "node_modules",
        ]
        files = [f for f in files if not any(skip in str(f).lower() for skip in skip_patterns)]

        # Severity mapping from ML detection to SecurityFinding
        severity_map = {
            "critical": Severity.CRITICAL,
            "high": Severity.HIGH,
            "medium": Severity.MEDIUM,
            "low": Severity.LOW,
        }

        # OWASP category mapping for attack types
        owasp_map = {
            "JAILBREAK": OWASPCategory.LLM01,  # Prompt Injection
            "DATA_EXFILTRATION": OWASPCategory.LLM06,  # Sensitive Information Disclosure
            "PRIVILEGE_ESCALATION": OWASPCategory.LLM08,  # Excessive Agency
            "IMPERSONATION": OWASPCategory.LLM09,  # Overreliance
            "MEMORY_POISONING": OWASPCategory.LLM05,  # Supply Chain Vulnerabilities
            "INJECTION_CASCADE": OWASPCategory.LLM01,  # Prompt Injection
            "TOOL_ABUSE": OWASPCategory.LLM08,  # Excessive Agency
            "DENIAL_OF_SERVICE": OWASPCategory.LLM04,  # Model Denial of Service
        }

        # Extract prompts from Python source files using AST analysis
        from vantage_core.security.extractors.prompts import PromptExtractor

        prompt_extractor = PromptExtractor()
        extracted_prompts = prompt_extractor.extract_from_directory(
            path, max_files=config.max_files
        )

        # Scan extracted prompts for attacks
        for extracted in extracted_prompts:
            results = detector.detect(
                text=extracted.content,
                context=extracted.code_snippet or "",
                file_path=extracted.file_path,
                line_number=extracted.line_number,
            )

            for result in results:
                if result.confidence < config.ml_confidence_threshold:
                    continue

                if config.ml_categories:
                    attack_type_str = result.attack_type.value.upper() if result.attack_type else ""
                    if attack_type_str not in [
                        category_map.get(c, c).upper() for c in config.ml_categories
                    ]:
                        continue

                attack_name = result.signature.name if result.signature else "Unknown Attack"
                attack_type = result.attack_type.value if result.attack_type else "unknown"
                severity = severity_map.get(
                    result.signature.severity if result.signature else "medium",
                    Severity.MEDIUM,
                )
                owasp = owasp_map.get(
                    result.attack_type.value.upper() if result.attack_type else "",
                    OWASPCategory.LLM01,
                )

                finding = SecurityFinding(
                    id=SecurityFinding.generate_id(),
                    title=f"ML Detection: {attack_name} in {extracted.source_type.value}",
                    description=(
                        f"Machine learning-based detection identified a potential {attack_type} attack pattern "
                        f"in a {extracted.source_type.value} prompt. Framework: {extracted.framework or 'unknown'}. "
                        f"Evidence: {result.evidence[:100]}..."
                    ),
                    severity=severity,
                    confidence=result.confidence,
                    owasp_category=owasp,
                    category=VulnerabilityCategory.PROMPT_INJECTION,
                    file_path=extracted.file_path,
                    line_number=extracted.line_number,
                    code_snippet=(
                        extracted.content[:100]
                        if len(extracted.content) > 100
                        else extracted.content
                    ),
                    recommendation=result.recommendation,
                    cwe_id="CWE-77",
                    detection_method="ml_detection_prompt_extraction",
                    metadata={
                        "ml_confidence": result.confidence,
                        "attack_category": attack_type,
                        "signature_id": (result.signature.id if result.signature else None),
                        "matched_patterns": len(result.matched_patterns),
                        "prompt_source": extracted.source_type.value,
                        "framework": extracted.framework,
                        "is_dynamic": extracted.is_dynamic,
                    },
                )
                ml_findings.append(finding)

        # Scan config/prompt files (txt, md, yaml, etc.)
        for file_path in files:
            try:
                content = file_path.read_text(errors="ignore")
            except Exception:
                continue

            lines = content.split("\n")
            for line_num, line in enumerate(lines, 1):
                if not line.strip():
                    continue

                # Get context (surrounding lines)
                context = "\n".join(lines[max(0, line_num - 3) : min(len(lines), line_num + 3)])

                # Run ML detection
                results = detector.detect(
                    text=line,
                    context=context,
                    file_path=str(file_path),
                    line_number=line_num,
                )

                for result in results:
                    # Filter by confidence threshold
                    if result.confidence < config.ml_confidence_threshold:
                        continue

                    # Filter by category if specified
                    if config.ml_categories:
                        attack_type_str = (
                            result.attack_type.value.upper() if result.attack_type else ""
                        )
                        if attack_type_str not in [
                            category_map.get(c, c).upper() for c in config.ml_categories
                        ]:
                            continue

                    # Convert to SecurityFinding
                    attack_name = result.signature.name if result.signature else "Unknown Attack"
                    attack_type = result.attack_type.value if result.attack_type else "unknown"
                    severity = severity_map.get(
                        result.signature.severity if result.signature else "medium",
                        Severity.MEDIUM,
                    )
                    owasp = owasp_map.get(
                        result.attack_type.value.upper() if result.attack_type else "",
                        OWASPCategory.LLM01,
                    )

                    finding = SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title=f"ML Detection: {attack_name}",
                        description=(
                            f"Machine learning-based detection identified a potential {attack_type} attack pattern. "
                            f"Evidence: {result.evidence[:100]}..."
                        ),
                        severity=severity,
                        confidence=result.confidence,
                        owasp_category=owasp,
                        category=VulnerabilityCategory.PROMPT_INJECTION,
                        file_path=str(file_path),
                        line_number=line_num,
                        code_snippet=line[:100] if len(line) > 100 else line,
                        recommendation=result.recommendation,
                        cwe_id="CWE-77",  # Command Injection
                        detection_method="ml_detection",
                        metadata={
                            "ml_confidence": result.confidence,
                            "attack_category": attack_type,
                            "signature_id": (result.signature.id if result.signature else None),
                            "matched_patterns": len(result.matched_patterns),
                        },
                    )
                    ml_findings.append(finding)

        # Phase 2a: Lightweight ML Code Scanner (fast biLSTM model)
        # This is the recommended approach - fast pattern matching + lightweight ML
        lightweight_findings = 0
        if config.use_lightweight_ml:
            lightweight_detector = self._get_lightweight_detector(config)
            if lightweight_detector:
                self.logger.info("Running lightweight ML code scanner...")

                # Get Python/JavaScript source files
                if path.is_file():
                    source_files = [path] if str(path).endswith((".py", ".js", ".ts")) else []
                else:
                    source_files = []
                    for ext in ["*.py", "*.js", "*.ts"]:
                        source_files.extend(list(path.rglob(ext))[: config.max_files])

                # Filter out test files and vendor directories
                skip_dirs = [
                    "__pycache__",
                    ".git",
                    "node_modules",
                    ".venv",
                    "venv",
                    "dist",
                    "build",
                ]
                source_files = [
                    f for f in source_files if not any(skip in str(f) for skip in skip_dirs)
                ][: config.max_files]

                for file_path in source_files:
                    try:
                        code = file_path.read_text(errors="ignore")
                        lines = code.split("\n")

                        # Scan each line individually for precise line numbers
                        for line_num, line in enumerate(lines, 1):
                            if not line.strip() or line.strip().startswith("#"):
                                continue

                            # Also include context (previous line) for better detection
                            if line_num > 1:
                                context_line = lines[line_num - 2]
                                chunk = context_line + "\n" + line
                            else:
                                chunk = line

                            result = lightweight_detector.predict(chunk)
                            if (
                                result.is_vulnerable
                                and result.confidence >= config.ml_code_confidence_threshold
                            ):
                                # Determine severity based on confidence and type
                                if result.confidence >= 0.85:
                                    severity = Severity.HIGH
                                elif result.confidence >= 0.70:
                                    severity = Severity.MEDIUM
                                else:
                                    severity = Severity.LOW

                                finding = SecurityFinding(
                                    id=SecurityFinding.generate_id(),
                                    title=f"Code Vulnerability: {result.vulnerability_type or 'Potential Issue'}",
                                    description=f"Lightweight ML detector identified a potential {result.vulnerability_type or 'vulnerability'}. {result.explanation}",
                                    severity=severity,
                                    confidence=result.confidence,
                                    owasp_category=OWASPCategory.LLM01,
                                    category=VulnerabilityCategory.CODE_VULNERABILITY,
                                    file_path=str(file_path),
                                    line_number=line_num,
                                    code_snippet=(line[:200] if len(line) > 200 else line),
                                    recommendation=f"Review this code for {result.vulnerability_type or 'security issues'}",
                                    cwe_id=result.cwe_id or "CWE-Unknown",
                                    detection_method="lightweight_ml",
                                    metadata={
                                        "ml_confidence": result.confidence,
                                        "vulnerability_type": result.vulnerability_type,
                                        "detector": "biLSTM_lightweight",
                                    },
                                )
                                ml_findings.append(finding)
                                lightweight_findings += 1

                    except Exception as e:
                        self.logger.debug(f"Error scanning {file_path}: {e}")

                self.logger.info(
                    "lightweight_ml_scanner_complete",
                    files_scanned=len(source_files),
                    findings_count=lightweight_findings,
                )

        # Phase 2c: Prompt Injection Classifier (embedding-based similarity detection)
        # Uses sentence-transformers to detect injection patterns via semantic similarity
        prompt_injection_findings = 0
        if config.use_prompt_injection_classifier:
            try:
                from vantage_core.security.detection.prompt_injection_classifier import (
                    PromptInjectionClassifier,
                )

                injection_classifier = PromptInjectionClassifier(
                    similarity_threshold=config.prompt_injection_threshold,
                )

                self.logger.info("Running prompt injection classifier on extracted prompts...")

                # Map injection categories to OWASP
                injection_category_map = {
                    "instruction_override": OWASPCategory.LLM01,
                    "role_play": OWASPCategory.LLM01,
                    "system_prompt_extraction": OWASPCategory.LLM01,
                    "delimiter_injection": OWASPCategory.LLM01,
                    "context_manipulation": OWASPCategory.LLM01,
                    "indirect_injection": OWASPCategory.LLM01,
                }

                # Classify extracted prompts
                for extracted in extracted_prompts:
                    classification = injection_classifier.classify(
                        extracted.content, context=extracted.code_snippet
                    )

                    if (
                        classification.is_injection
                        and classification.confidence >= config.prompt_injection_threshold
                    ):
                        # Determine severity based on category
                        if classification.matched_category in [
                            "instruction_override",
                            "delimiter_injection",
                        ]:
                            severity = Severity.HIGH
                        elif classification.matched_category in [
                            "system_prompt_extraction",
                            "context_manipulation",
                        ]:
                            severity = Severity.MEDIUM
                        else:
                            severity = Severity.LOW

                        owasp = injection_category_map.get(
                            classification.matched_category or "", OWASPCategory.LLM01
                        )

                        finding = SecurityFinding(
                            id=SecurityFinding.generate_id(),
                            title=f"Prompt Injection: {classification.matched_category or 'Unknown'}",
                            description=(
                                f"Embedding-based analysis detected potential prompt injection "
                                f"(category: {classification.matched_category}). "
                                f"{classification.reasoning}"
                            ),
                            severity=severity,
                            confidence=classification.confidence,
                            owasp_category=owasp,
                            category=VulnerabilityCategory.PROMPT_INJECTION,
                            file_path=extracted.file_path,
                            line_number=extracted.line_number,
                            code_snippet=(
                                extracted.content[:200]
                                if len(extracted.content) > 200
                                else extracted.content
                            ),
                            recommendation=(
                                "Review this prompt for potential injection vectors. "
                                "Consider implementing input validation and prompt hardening."
                            ),
                            cwe_id="CWE-77",
                            detection_method="embedding_similarity",
                            metadata={
                                "classifier_confidence": classification.confidence,
                                "injection_category": classification.matched_category,
                                "similar_patterns": classification.similar_patterns,
                                "prompt_source": extracted.source_type.value,
                                "framework": extracted.framework,
                                "is_dynamic": extracted.is_dynamic,
                            },
                        )
                        ml_findings.append(finding)
                        prompt_injection_findings += 1

                self.logger.info(
                    "prompt_injection_classifier_complete",
                    prompts_analyzed=len(extracted_prompts),
                    findings_count=prompt_injection_findings,
                )

            except ImportError as e:
                self.logger.debug(f"Prompt injection classifier not available: {e}")
            except Exception as e:
                self.logger.warning(f"Error running prompt injection classifier: {e}")

        # Phase 2d: Heavy ML Code Scanner (trained CodeBERT model for source code vulnerabilities)
        # NOTE: Disabled by default due to slow inference - use only when deep analysis is needed
        code_scanner_findings = 0
        if config.use_ml_code_scanner:
            code_scanner = self._get_ml_code_scanner(config)
            if code_scanner:
                self.logger.info("Running ML code scanner on source files...")

                # Get Python source files
                if path.is_file():
                    py_files = [path] if str(path).endswith(".py") else []
                else:
                    py_files = list(path.rglob("*.py"))[: config.max_files]

                # Filter out test files if configured
                skip_dirs = ["__pycache__", ".git", "node_modules", ".venv", "venv"]
                py_files = [f for f in py_files if not any(skip in str(f) for skip in skip_dirs)]

                for file_path in py_files:
                    try:
                        code = file_path.read_text(errors="ignore")
                        code_findings = code_scanner.scan_file(str(file_path), code)
                        ml_findings.extend(code_findings)
                        code_scanner_findings += len(code_findings)
                    except Exception as e:
                        import traceback

                        self.logger.warning(
                            f"Error scanning {file_path}: {e}\n{traceback.format_exc()}"
                        )

                self.logger.info(
                    "ml_code_scanner_complete",
                    files_scanned=len(py_files),
                    findings_count=code_scanner_findings,
                )
            else:
                self.logger.info(
                    "ML code scanner not available, skipping code vulnerability detection"
                )

        self.logger.info(
            "ml_detection_complete",
            files_scanned=len(files),
            prompts_extracted=len(extracted_prompts),
            pattern_findings=len(ml_findings)
            - code_scanner_findings
            - lightweight_findings
            - prompt_injection_findings,
            lightweight_findings=lightweight_findings,
            prompt_injection_findings=prompt_injection_findings,
            code_scanner_findings=code_scanner_findings,
            total_findings=len(ml_findings),
        )

        return ml_findings

    def _stage_scoring(
        self, scan_result: SecurityScanResult, graph: AgentGraph | None
    ) -> ATSSResult:
        """Calculate ATSS score."""
        return self.scoring_engine.calculate_atss(scan_result, graph)

    def _stage_simulation(
        self, graph: AgentGraph | None, config: PipelineConfig
    ) -> list[BlastRadiusResult]:
        """Run infection simulations."""
        if not graph or graph.node_count == 0:
            return []

        simulation_results = []

        # Get simulation config
        sim_config = config.simulation_config or SimulationConfig()

        # Run simulation from each entry point
        entry_points = graph.get_entry_points() if hasattr(graph, "get_entry_points") else []

        for entry_point in entry_points[:5]:  # Limit to 5 entry points
            try:
                result = self.blast_radius_calculator.calculate(graph, entry_point, sim_config)
                simulation_results.append(result)
            except Exception:
                pass  # Skip failed simulations

        return simulation_results

    def _stage_remediation(
        self, findings: list[SecurityFinding], frameworks: list[str]
    ) -> list[Remediation]:
        """Generate remediations for findings."""
        remediations = []

        for finding in findings:
            try:
                remediation = self.remediation_generator.generate(finding)
                if remediation:
                    remediations.append(remediation)
            except Exception:
                pass  # Skip failed remediation generation

        return remediations

    def _stage_report(
        self,
        scan_result: SecurityScanResult | None,
        atss_result: ATSSResult | None,
        simulation_results: list[BlastRadiusResult],
        remediations: list[Remediation],
    ) -> dict[str, Any]:
        """Generate final report."""
        return {
            "scan_id": scan_result.scan_id if scan_result else "unknown",
            "generated_at": datetime.now().isoformat(),
            "summary": {
                "agents_scanned": scan_result.agents_scanned if scan_result else 0,
                "findings_count": len(scan_result.findings) if scan_result else 0,
                "atss_score": atss_result.overall_score if atss_result else None,
                "grade": atss_result.grade if atss_result else None,
                "remediations_generated": len(remediations),
            },
        }

    def _report_stage_start(self, stage: ScanStage):
        """Report stage start to progress reporter."""
        self.logger.info("stage_started", stage=stage.value)
        self.progress_reporter.report_stage_start(stage)

    def _report_stage_complete(self, stage: ScanStage, duration_ms: int):
        """Report stage completion to progress reporter."""
        self.logger.info("stage_completed", stage=stage.value, duration_ms=duration_ms)
        self.progress_reporter.report_stage_complete(stage, duration_ms)

    def _report_completion(self, status: str, duration_ms: int):
        """Report pipeline completion."""
        self.progress_reporter.report_completion(status, duration_ms)


class PipelineError(Exception):
    """Pipeline execution error."""

    pass


def run_security_pipeline(
    path: Path | str,
    config: PipelineConfig | None = None,
    progress_callback: ProgressCallback | None = None,
) -> PipelineResult:
    """
    Convenience function to run security pipeline.

    Args:
        path: Path to scan
        config: Optional configuration
        progress_callback: Optional progress callback

    Returns:
        PipelineResult
    """
    pipeline = SecurityPipeline(config)
    return pipeline.scan(path, config, progress_callback)
