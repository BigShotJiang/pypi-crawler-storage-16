"""
Progress Reporting (US-151).

Real-time progress updates and stage completion tracking
for the security scan pipeline.
"""

from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Protocol


class StageStatus(str, Enum):
    """Status of a pipeline stage."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class StageProgress:
    """Progress information for a single stage."""

    stage_name: str
    status: StageStatus
    progress_percent: float  # 0-100
    started_at: datetime | None = None
    completed_at: datetime | None = None
    duration_ms: int = 0
    message: str = ""
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class PipelineProgress:
    """Overall pipeline progress."""

    scan_id: str
    overall_percent: float  # 0-100
    current_stage: str
    stages: list[StageProgress]
    started_at: datetime
    estimated_remaining_ms: int = 0
    errors: list[str] = field(default_factory=list)


class ProgressCallback(Protocol):
    """Protocol for progress callbacks."""

    def __call__(self, progress: PipelineProgress) -> None:
        """Called when progress updates."""
        ...


class ProgressReporter:
    """
    Reports progress for pipeline execution.

    Tracks stage completion and provides real-time updates
    through registered callbacks.
    """

    # Stage weights for progress calculation
    STAGE_WEIGHTS = {
        "initialization": 0.02,
        "parsing": 0.15,
        "topology": 0.10,
        "trust_analysis": 0.15,
        "vulnerability_scan": 0.15,
        "scoring": 0.10,
        "simulation": 0.15,
        "remediation": 0.10,
        "report": 0.05,
        "completed": 0.03,
    }

    def __init__(self):
        """Initialize the progress reporter."""
        self.callbacks: list[ProgressCallback] = []
        self.stages: dict[str, StageProgress] = {}
        self.scan_id: str = ""
        self.started_at: datetime | None = None
        self._stage_order = list(self.STAGE_WEIGHTS.keys())

    def add_callback(self, callback: ProgressCallback):
        """
        Register a progress callback.

        Args:
            callback: Function to call on progress updates
        """
        self.callbacks.append(callback)

    def remove_callback(self, callback: ProgressCallback):
        """
        Remove a progress callback.

        Args:
            callback: Callback to remove
        """
        if callback in self.callbacks:
            self.callbacks.remove(callback)

    def start_pipeline(self, scan_id: str):
        """
        Start tracking pipeline progress.

        Args:
            scan_id: Unique scan identifier
        """
        self.scan_id = scan_id
        self.started_at = datetime.now()
        self.stages = {}

        # Initialize all stages as pending
        for stage_name in self._stage_order:
            self.stages[stage_name] = StageProgress(
                stage_name=stage_name,
                status=StageStatus.PENDING,
                progress_percent=0.0,
            )

    def report_stage_start(self, stage):
        """
        Report that a stage has started.

        Args:
            stage: Stage enum or string
        """
        stage_name = stage.value if hasattr(stage, "value") else str(stage)

        if stage_name not in self.stages:
            self.stages[stage_name] = StageProgress(
                stage_name=stage_name,
                status=StageStatus.PENDING,
                progress_percent=0.0,
            )

        self.stages[stage_name].status = StageStatus.RUNNING
        self.stages[stage_name].started_at = datetime.now()
        self.stages[stage_name].message = f"Running {stage_name}..."

        self._notify_callbacks()

    def report_stage_progress(
        self,
        stage,
        percent: float,
        message: str = "",
        details: dict[str, Any] | None = None,
    ):
        """
        Report progress within a stage.

        Args:
            stage: Stage enum or string
            percent: Progress percentage (0-100)
            message: Optional status message
            details: Optional details dict
        """
        stage_name = stage.value if hasattr(stage, "value") else str(stage)

        if stage_name in self.stages:
            self.stages[stage_name].progress_percent = min(100.0, max(0.0, percent))
            if message:
                self.stages[stage_name].message = message
            if details:
                self.stages[stage_name].details.update(details)

            self._notify_callbacks()

    def report_stage_complete(
        self,
        stage,
        duration_ms: int = 0,
        message: str = "",
        details: dict[str, Any] | None = None,
    ):
        """
        Report that a stage has completed.

        Args:
            stage: Stage enum or string
            duration_ms: Stage duration in milliseconds
            message: Optional completion message
            details: Optional details dict
        """
        stage_name = stage.value if hasattr(stage, "value") else str(stage)

        if stage_name in self.stages:
            self.stages[stage_name].status = StageStatus.COMPLETED
            self.stages[stage_name].progress_percent = 100.0
            self.stages[stage_name].completed_at = datetime.now()
            self.stages[stage_name].duration_ms = duration_ms
            self.stages[stage_name].message = message or f"{stage_name} completed"
            if details:
                self.stages[stage_name].details.update(details)

            self._notify_callbacks()

    def report_stage_failed(self, stage, error: str, duration_ms: int = 0):
        """
        Report that a stage has failed.

        Args:
            stage: Stage enum or string
            error: Error message
            duration_ms: Stage duration before failure
        """
        stage_name = stage.value if hasattr(stage, "value") else str(stage)

        if stage_name in self.stages:
            self.stages[stage_name].status = StageStatus.FAILED
            self.stages[stage_name].completed_at = datetime.now()
            self.stages[stage_name].duration_ms = duration_ms
            self.stages[stage_name].message = f"Failed: {error}"

            self._notify_callbacks()

    def report_stage_skipped(self, stage, reason: str = ""):
        """
        Report that a stage was skipped.

        Args:
            stage: Stage enum or string
            reason: Reason for skipping
        """
        stage_name = stage.value if hasattr(stage, "value") else str(stage)

        if stage_name in self.stages:
            self.stages[stage_name].status = StageStatus.SKIPPED
            self.stages[stage_name].progress_percent = 100.0
            self.stages[stage_name].message = reason or f"{stage_name} skipped"

            self._notify_callbacks()

    def report_completion(self, status: str, duration_ms: int):
        """
        Report pipeline completion.

        Args:
            status: Final status (completed, failed, partial)
            duration_ms: Total duration
        """
        if "completed" in self.stages:
            self.stages["completed"].status = StageStatus.COMPLETED
            self.stages["completed"].progress_percent = 100.0
            self.stages["completed"].duration_ms = duration_ms
            self.stages["completed"].message = f"Pipeline {status}"

        self._notify_callbacks()

    def get_progress(self) -> PipelineProgress:
        """
        Get current pipeline progress.

        Returns:
            PipelineProgress with current state
        """
        # Calculate overall progress
        overall_percent = 0.0
        current_stage = ""

        for stage_name in self._stage_order:
            if stage_name not in self.stages:
                continue

            stage = self.stages[stage_name]
            weight = self.STAGE_WEIGHTS.get(stage_name, 0.0)

            if stage.status == StageStatus.COMPLETED:
                overall_percent += weight * 100
            elif stage.status == StageStatus.SKIPPED:
                overall_percent += weight * 100
            elif stage.status == StageStatus.RUNNING:
                overall_percent += weight * stage.progress_percent
                current_stage = stage_name
            elif stage.status == StageStatus.PENDING:
                if not current_stage:
                    current_stage = stage_name
                break

        # Collect errors
        errors = [
            stage.message for stage in self.stages.values() if stage.status == StageStatus.FAILED
        ]

        # Estimate remaining time
        estimated_remaining = self._estimate_remaining_time(overall_percent)

        return PipelineProgress(
            scan_id=self.scan_id,
            overall_percent=round(overall_percent, 1),
            current_stage=current_stage,
            stages=list(self.stages.values()),
            started_at=self.started_at or datetime.now(),
            estimated_remaining_ms=estimated_remaining,
            errors=errors,
        )

    def _estimate_remaining_time(self, overall_percent: float) -> int:
        """Estimate remaining time based on progress."""
        if not self.started_at or overall_percent <= 0:
            return 0

        elapsed_ms = int((datetime.now() - self.started_at).total_seconds() * 1000)

        if overall_percent >= 100:
            return 0

        # Linear estimate
        rate = elapsed_ms / overall_percent
        remaining_percent = 100 - overall_percent
        estimated = int(rate * remaining_percent)

        return estimated

    def _notify_callbacks(self):
        """Notify all registered callbacks."""
        progress = self.get_progress()

        for callback in self.callbacks:
            try:
                callback(progress)
            except Exception:
                pass  # Don't fail on callback errors


class ConsoleProgressCallback:
    """
    Console-based progress callback.

    Prints progress updates to the console.
    """

    def __init__(self, show_details: bool = False):
        """
        Initialize console callback.

        Args:
            show_details: Whether to show detailed progress
        """
        self.show_details = show_details
        self._last_stage = ""

    def __call__(self, progress: PipelineProgress):
        """Print progress to console."""
        # Only print when stage changes or every 10%
        if progress.current_stage != self._last_stage:
            self._last_stage = progress.current_stage
            print(f"\n[{progress.overall_percent:.0f}%] {progress.current_stage}")

            if self.show_details:
                for stage in progress.stages:
                    status_char = {
                        StageStatus.PENDING: " ",
                        StageStatus.RUNNING: ">",
                        StageStatus.COMPLETED: "+",
                        StageStatus.FAILED: "!",
                        StageStatus.SKIPPED: "-",
                    }.get(stage.status, "?")

                    print(f"  {status_char} {stage.stage_name}: {stage.message}")


class JSONProgressCallback:
    """
    JSON-based progress callback.

    Outputs progress as JSON for machine consumption.
    """

    def __init__(self, output_callback: Callable[[str], None] | None = None):
        """
        Initialize JSON callback.

        Args:
            output_callback: Function to call with JSON string
        """
        self.output_callback = output_callback or print

    def __call__(self, progress: PipelineProgress):
        """Output progress as JSON."""
        import json

        data = {
            "scan_id": progress.scan_id,
            "overall_percent": progress.overall_percent,
            "current_stage": progress.current_stage,
            "stages": [
                {
                    "name": stage.stage_name,
                    "status": stage.status.value,
                    "percent": stage.progress_percent,
                    "duration_ms": stage.duration_ms,
                    "message": stage.message,
                }
                for stage in progress.stages
            ],
            "estimated_remaining_ms": progress.estimated_remaining_ms,
            "errors": progress.errors,
        }

        self.output_callback(json.dumps(data))


class WebSocketProgressCallback:
    """
    WebSocket-based progress callback.

    Sends progress updates over WebSocket connection.
    """

    def __init__(self, websocket_send: Callable[[dict], None]):
        """
        Initialize WebSocket callback.

        Args:
            websocket_send: Function to send data over WebSocket
        """
        self.websocket_send = websocket_send

    def __call__(self, progress: PipelineProgress):
        """Send progress over WebSocket."""
        data = {
            "type": "progress",
            "payload": {
                "scan_id": progress.scan_id,
                "overall_percent": progress.overall_percent,
                "current_stage": progress.current_stage,
                "estimated_remaining_ms": progress.estimated_remaining_ms,
                "errors": progress.errors,
            },
        }

        try:
            self.websocket_send(data)
        except Exception:
            pass  # Handle WebSocket errors silently
