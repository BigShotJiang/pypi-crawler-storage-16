"""
Fix Validation (US-138).

Validates that remediation fixes resolve the original issue
without introducing new vulnerabilities.
"""

import ast
import re
from dataclasses import dataclass, field
from typing import Any

from vantage_core.security.models import (
    SecurityFinding,
    VulnerabilityCategory,
)
from vantage_core.security.remediation.generator import CodeContext, Remediation
from vantage_core.security.remediation.patterns import RemediationType


@dataclass
class ValidationResult:
    """Result of fix validation."""

    is_valid: bool
    original_fixed: bool
    new_vulnerabilities: list[str]
    syntax_valid: bool
    warnings: list[str]
    confidence: float
    details: dict[str, Any] = field(default_factory=dict)


class RemediationValidator:
    """
    Validates remediation fixes.

    Checks that:
    1. Fix resolves the original vulnerability
    2. Fix doesn't introduce new vulnerabilities
    3. Code is syntactically valid
    4. Best practices are followed
    """

    def __init__(self):
        """Initialize the validator."""
        self.syntax_checker = SyntaxChecker()
        self.vulnerability_detector = VulnerabilityDetector()

    def validate(
        self,
        finding: SecurityFinding,
        remediation: Remediation,
        original_context: CodeContext | None = None,
    ) -> ValidationResult:
        """
        Validate a remediation fix.

        Args:
            finding: Original security finding
            remediation: Proposed remediation
            original_context: Original code context

        Returns:
            ValidationResult with validation details
        """
        warnings = []
        new_vulnerabilities = []

        # Check syntax
        syntax_valid = True
        if remediation.code_after:
            syntax_result = self.syntax_checker.check(remediation.code_after)
            syntax_valid = syntax_result.is_valid
            if not syntax_valid:
                warnings.extend(syntax_result.errors)

        # Check if original vulnerability is addressed
        original_fixed = self._check_vulnerability_fixed(finding, remediation)
        # For config/architecture changes without code, assume fixed
        if not remediation.code_after and remediation.remedy_type in [
            RemediationType.CONFIG_CHANGE,
            RemediationType.ARCHITECTURE,
        ]:
            original_fixed = True
        if not original_fixed:
            warnings.append(f"Remediation may not fully address {finding.category.value}")

        # Check for new vulnerabilities
        if remediation.code_after:
            new_vulns = self.vulnerability_detector.detect(remediation.code_after)
            new_vulnerabilities = [v for v in new_vulns if v != finding.category.value]
            if new_vulnerabilities:
                warnings.append(f"Potential new vulnerabilities: {', '.join(new_vulnerabilities)}")

        # Check best practices
        best_practice_warnings = self._check_best_practices(remediation)
        warnings.extend(best_practice_warnings)

        # Calculate overall validity
        is_valid = syntax_valid and original_fixed and len(new_vulnerabilities) == 0

        # Calculate confidence
        confidence = self._calculate_confidence(
            is_valid, original_fixed, new_vulnerabilities, warnings
        )

        return ValidationResult(
            is_valid=is_valid,
            original_fixed=original_fixed,
            new_vulnerabilities=new_vulnerabilities,
            syntax_valid=syntax_valid,
            warnings=warnings,
            confidence=confidence,
            details={
                "finding_id": finding.id,
                "pattern_id": remediation.pattern_id,
                "checks_performed": [
                    "syntax_check",
                    "vulnerability_fix_check",
                    "new_vulnerability_scan",
                    "best_practice_check",
                ],
            },
        )

    def validate_batch(
        self,
        fixes: list[tuple[SecurityFinding, Remediation]],
    ) -> list[ValidationResult]:
        """
        Validate multiple fixes.

        Args:
            fixes: List of (finding, remediation) tuples

        Returns:
            List of ValidationResults
        """
        return [self.validate(finding, remediation) for finding, remediation in fixes]

    def _check_vulnerability_fixed(
        self, finding: SecurityFinding, remediation: Remediation
    ) -> bool:
        """Check if the fix addresses the vulnerability."""
        if not remediation.code_after:
            # Configuration or architecture changes assumed valid
            return True

        code = remediation.code_after.lower()

        # Check for fix indicators based on vulnerability type
        fix_indicators = {
            VulnerabilityCategory.PROMPT_INJECTION: [
                "sanitize",
                "validate",
                "escape",
                "strip",
                "re.sub",
                "replace",
                "injection",
            ],
            VulnerabilityCategory.EXCESSIVE_AGENCY: [
                "permission",
                "allowed",
                "restrict",
                "allowlist",
                "delegation=false",
                "limit",
            ],
            VulnerabilityCategory.DATA_LEAKAGE: [
                "mask",
                "redact",
                "sanitize",
                "filter",
                "pii",
                "sensitive",
            ],
            VulnerabilityCategory.TRUST_BOUNDARY_VIOLATION: [
                "trust",
                "boundary",
                "validate",
                "check",
                "authorize",
                "permission",
            ],
            VulnerabilityCategory.CODE_EXECUTION: [
                "docker",
                "sandbox",
                "timeout",
                "isolate",
                "secure",
            ],
            VulnerabilityCategory.HARDCODED_SECRET: [
                "environ",
                "getenv",
                "secret",
                "config",
                "settings",
            ],
        }

        indicators = fix_indicators.get(finding.category, [])
        return any(indicator in code for indicator in indicators)

    def _check_best_practices(self, remediation: Remediation) -> list[str]:
        """Check if remediation follows best practices."""
        warnings = []

        if not remediation.code_after:
            return warnings

        code = remediation.code_after

        # Check for common anti-patterns
        if "eval(" in code or "exec(" in code:
            warnings.append("Code contains eval/exec which can be dangerous")

        if "shell=True" in code:
            warnings.append("shell=True in subprocess can be a security risk")

        if re.search(r'password\s*=\s*["\'][^"\']+["\']', code):
            warnings.append("Possible hardcoded password detected")

        if "__import__(" in code:
            warnings.append("Dynamic imports can be a security risk")

        # Check for missing error handling
        if "try:" not in code and any(
            keyword in code for keyword in ["open(", "request", "connect"]
        ):
            warnings.append("Consider adding error handling for I/O operations")

        return warnings

    def _calculate_confidence(
        self,
        is_valid: bool,
        original_fixed: bool,
        new_vulnerabilities: list[str],
        warnings: list[str],
    ) -> float:
        """Calculate confidence in validation result."""
        confidence = 1.0

        if not is_valid:
            confidence = 0.3

        if not original_fixed:
            confidence -= 0.3

        confidence -= len(new_vulnerabilities) * 0.2
        confidence -= len(warnings) * 0.05

        return max(0.0, min(1.0, confidence))


class SyntaxChecker:
    """Checks Python code syntax validity."""

    @dataclass
    class Result:
        is_valid: bool
        errors: list[str] = field(default_factory=list)

    def check(self, code: str) -> Result:
        """
        Check if code has valid Python syntax.

        Args:
            code: Python code string

        Returns:
            Result with validity and errors
        """
        errors = []

        try:
            ast.parse(code)
        except SyntaxError as e:
            errors.append(f"Syntax error at line {e.lineno}: {e.msg}")
            return self.Result(is_valid=False, errors=errors)

        return self.Result(is_valid=True)


class VulnerabilityDetector:
    """Detects potential vulnerabilities in code."""

    VULNERABILITY_PATTERNS = {
        "prompt_injection": [
            r'f["\'].*\{.*user.*\}',  # F-string with user input
            r"\.format\(.*user",  # Format with user input
            r"\+.*user.*\+",  # Concatenation with user
        ],
        "code_execution": [
            r"\beval\s*\(",
            r"\bexec\s*\(",
            r"subprocess.*shell\s*=\s*True",
            r"os\.system\s*\(",
        ],
        "hardcoded_secret": [
            r'api_key\s*=\s*["\'][a-zA-Z0-9_-]{15,}["\']',
            r'password\s*=\s*["\'][^"\']+["\']',
            r'secret\s*=\s*["\'][^"\']+["\']',
            r"sk-[a-zA-Z0-9]{10,}",
        ],
        "sql_injection": [
            r"execute\s*\([^)]*\+",
            r"execute\s*\([^)]*%\s*",
            r'execute\s*\(.*f["\']',
        ],
        "path_traversal": [
            r"open\s*\([^)]*\+",
            r"\.\./",
        ],
    }

    def detect(self, code: str) -> list[str]:
        """
        Detect potential vulnerabilities in code.

        Args:
            code: Python code string

        Returns:
            List of detected vulnerability types
        """
        detected = []

        for vuln_type, patterns in self.VULNERABILITY_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, code, re.IGNORECASE):
                    if vuln_type not in detected:
                        detected.append(vuln_type)
                    break

        return detected


def validate_remediation(
    finding: SecurityFinding,
    remediation: Remediation,
) -> ValidationResult:
    """
    Convenience function to validate a remediation.

    Args:
        finding: Original finding
        remediation: Proposed fix

    Returns:
        ValidationResult
    """
    validator = RemediationValidator()
    return validator.validate(finding, remediation)
