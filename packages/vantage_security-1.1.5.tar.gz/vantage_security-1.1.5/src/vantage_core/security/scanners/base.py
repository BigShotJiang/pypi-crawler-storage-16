"""
Base class for security-focused framework scanners.

All framework-specific scanners must inherit from SecurityScanner
and implement the required abstract methods.
"""

import ast
import re
import time
from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
from typing import Any

from vantage_core.security.analysis.fp_filters import (
    FalsePositiveFilter,
)
from vantage_core.security.analysis.secret_context import (
    SecretContextAnalyzer,
)
from vantage_core.security.config import (
    MimicSettings,
    get_global_manager,
    load_config,
)
from vantage_core.security.logging import (
    FilterReason,
    LogCategory,
    LoggerFactory,
)
from vantage_core.security.models import (
    AgentCommunication,
    FindingExplanation,
    MAASCategory,
    OWASPCategory,
    SecurityAgent,
    SecurityFinding,
    SecurityScanResult,
    Severity,
    SourceLocation,
    TrustLevel,
    VulnerabilityCategory,
)
from vantage_core.security.patterns.context import (
    ContextBuilder,
    SemanticAnalyzer,
    build_finding_explanation,
    build_source_location,
)


class SecurityScanner(ABC):
    """
    Base class for security-focused framework scanners.

    Each framework scanner extends this class to provide specific
    vulnerability detection for that framework.
    """

    # Framework identifier
    framework_name: str = "base"

    # Common prompt injection patterns
    PROMPT_INJECTION_PATTERNS = [
        r"ignore\s+(previous|all|above)\s+instructions",
        r"disregard\s+(previous|all|above)",
        r"forget\s+(previous|all|everything)",
        r"new\s+instructions?\s*:",
        r"system\s*:\s*",
        r"assistant\s*:\s*",
        r"human\s*:\s*",
        r"\[INST\]",
        r"<\|im_start\|>",
        r"```\s*(system|assistant)",
    ]

    # Dangerous code patterns - focus on patterns with user input or dynamic content
    # These patterns are checked AFTER false positive indicators
    DANGEROUS_CODE_PATTERNS = [
        # High risk: eval/exec with string concatenation or f-strings (likely user input)
        (r"\beval\s*\([^)]*\+", "eval() with string concatenation", Severity.CRITICAL),
        (r"\beval\s*\(f['\"]", "eval() with f-string", Severity.CRITICAL),
        (r"\bexec\s*\([^)]*\+", "exec() with string concatenation", Severity.CRITICAL),
        (r"\bexec\s*\(f['\"]", "exec() with f-string", Severity.CRITICAL),
        # Medium risk: eval/exec with variable (may or may not be user input)
        (r"\beval\s*\(\s*[a-z_][a-z0-9_]*\s*\)", "eval() with variable", Severity.HIGH),
        (r"\bexec\s*\(\s*[a-z_][a-z0-9_]*\s*\)", "exec() with variable", Severity.HIGH),
        # Dynamic import (less common attack vector)
        (
            r"\b__import__\s*\([^)]*\+",
            "Dynamic import with concatenation",
            Severity.MEDIUM,
        ),
        # Command injection: subprocess with shell=True or string command
        (
            r"subprocess\.[^(]*\([^)]*shell\s*=\s*True",
            "Subprocess with shell=True",
            Severity.CRITICAL,
        ),
        (
            r"subprocess\.[^(]*\([^)]*\+[^)]*\)",
            "Subprocess with string concatenation",
            Severity.HIGH,
        ),
        # os.system always dangerous (no safe usage pattern)
        (
            r"os\.system\s*\([^)]*\+",
            "os.system() with concatenation",
            Severity.CRITICAL,
        ),
        (
            r"os\.system\s*\([^)]*(?:input|user|request)",
            "os.system() with user input",
            Severity.CRITICAL,
        ),
        (r"os\.(popen|spawn)", "OS command execution", Severity.HIGH),
    ]

    # Patterns that indicate a line is NOT actually dangerous (false positive indicators)
    CODE_EXECUTION_FP_PATTERNS = [
        # Comments (Python)
        r"^\s*#",
        # Docstrings containing these patterns
        r'^\s*["\']',
        r'^\s*"""',
        r"^\s*'''",
        # Mock/patch patterns (testing)
        r"patch\s*\(\s*['\"]",
        r"mock\.[a-zA-Z]+\s*\(",
        r"Mock\s*\(",
        r"MagicMock\s*\(",
        r"@patch",
        r"@mock",
        r"mocker\.",
        r"monkeypatch\.",
        # Type hints and annotations
        r":\s*type\[",
        r"->\s*",
        # Import statements (not actual usage)
        r"^\s*from\s+",
        r"^\s*import\s+",
        # String literals containing pattern (not execution)
        r"['\"].*subprocess",
        r"['\"].*eval\(",
        r"['\"].*exec\(",
        # Variable assignments with pattern in string
        r"=\s*['\"].*subprocess",
        r"=\s*['\"].*eval",
        r"=\s*['\"].*exec",
        # Assertion statements about mocks
        r"assert.*mock",
        r"assert.*call",
        # Exception handling that mentions these
        r"except.*Error",
        # Logging/print statements describing patterns
        r"(log|print|logger)\.",
        # Safe subprocess patterns (list args)
        r"subprocess\.run\s*\(\s*\[",  # subprocess.run([...])
        r"subprocess\.call\s*\(\s*\[",  # subprocess.call([...])
        r"subprocess\.Popen\s*\(\s*\[",  # subprocess.Popen([...])
        # Static eval/exec with string literals only
        r"eval\s*\(\s*['\"][^'\"]*['\"](?:\s*,|\s*\))",  # eval("string")
        r"exec\s*\(\s*['\"][^'\"]*['\"](?:\s*,|\s*\))",  # exec("string")
        # Function definitions (not calls)
        r"^\s*def\s+",
        # SQLAlchemy exec (not Python exec)
        r"session\.exec\s*\(",
        r"connection\.exec\s*\(",
        r"\.execute\s*\(",  # SQLAlchemy execute
        # Test file indicators in path
        r"test_.*\.py",
        r"_test\.py",
        r"tests/",
    ]

    # Patterns indicating test/mock context
    TEST_CONTEXT_PATTERNS = [
        r"with\s+patch",
        r"with\s+mock",
        r"@pytest",
        r"@unittest",
        r"def\s+test_",
        r"class\s+Test",
        r"\.return_value",
        r"\.side_effect",
        r"\.assert_called",
        r"\.assert_not_called",
    ]

    # Secret patterns for detection - ordered by specificity (most specific first)
    SECRET_PATTERNS = [
        # Known API key formats (high confidence)
        (r"sk-[A-Za-z0-9]{48}", "OpenAI API key pattern"),
        (r"sk-proj-[A-Za-z0-9-]{48,}", "OpenAI project API key"),
        (r"AKIA[0-9A-Z]{16}", "AWS Access Key ID"),
        (r"ghp_[A-Za-z0-9]{36}", "GitHub personal access token"),
        (r"github_pat_[A-Za-z0-9_]{22,}", "GitHub fine-grained token"),
        (r"gho_[A-Za-z0-9]{36}", "GitHub OAuth token"),
        (r"glpat-[A-Za-z0-9-_]{20,}", "GitLab personal access token"),
        (r"xox[baprs]-[A-Za-z0-9-]{10,}", "Slack token"),
        (r"phc_[A-Za-z0-9]{32,}", "PostHog API key"),
        (r"Bearer\s+[A-Za-z0-9._-]{20,}", "Bearer token"),
        # Assignment-based detection (check variable name context)
        (r"(?:password|passwd|pwd)\s*=\s*['\"]([^'\"]{8,})['\"]", "Hardcoded password"),
        (
            r"(?:api_key|apikey|api-key)\s*=\s*['\"]([^'\"]{16,})['\"]",
            "Hardcoded API key",
        ),
        (
            r"(?:secret_key|secret|private_key)\s*=\s*['\"]([^'\"]{16,})['\"]",
            "Hardcoded secret",
        ),
        (
            r"(?:auth_token|access_token|bearer_token)\s*=\s*['\"]([^'\"]{16,})['\"]",
            "Hardcoded token",
        ),
    ]

    # Patterns that indicate a value is NOT a real secret (false positive indicators)
    FALSE_POSITIVE_INDICATORS = [
        # Environment variable references
        r"env",
        r"os\.getenv",
        r"environ",
        r"config\.",
        r"settings\.",
        # Explicit placeholders
        r"placeholder",
        r"example",
        r"xxx",
        r"your[-_]",
        r"insert[-_]",
        r"<.*>",
        r"\{.*\}",
        r"REPLACE",
        r"CHANGEME",
        r"TODO",
        # Mock/test values
        r"mock",
        r"test",
        r"fake",
        r"dummy",
        r"sample",
        r"fixture",
        # OAuth standard values
        r"refresh_token",
        r"access_token",
        r"authorization_code",
        r"client_credentials",
        r"password_grant",
        r"bearer",
        r"oauth",
        # Common non-secret strings
        r"utf-8",
        r"ascii",
        r"json",
        r"xml",
        r"html",
        # Chrome/Browser identifiers (NOT secrets)
        r"chrome[-_]extension",
        r"extension[-_]id",
        # Dictionary key patterns (looking up values, not storing secrets)
        r"\[[\'\"][A-Za-z_]+[\'\"]\]",  # dict['key'] or dict["key"]
        # Parameter names (entryId, nodeId, etc)
        r"['\"][a-z]+Id['\"]",  # 'entryId', 'nodeId', etc
        r"['\"][A-Z][a-z]+[A-Z][a-z]+['\"]",  # CamelCase identifiers
        # Type annotations
        r":\s*['\"][A-Z][a-zA-Z]+Parameters['\"]",  # 'SomeParameters'
    ]

    # Patterns where the value matches the variable name (e.g., API_KEY = "API_KEY")
    CONSTANT_NAME_PATTERN = re.compile(r"([A-Z_]+)\s*=\s*['\"](\1)['\"]", re.IGNORECASE)

    def __init__(self, settings: MimicSettings | None = None):
        """
        Initialize the scanner.

        Args:
            settings: Configuration settings. If not provided, loads from
                     global manager or defaults.
        """
        self._findings: list[SecurityFinding] = []
        self._agents: list[SecurityAgent] = []
        self._semantic_analyzer = SemanticAnalyzer()

        # Load configuration
        if settings is not None:
            self._settings = settings
        else:
            manager = get_global_manager()
            if manager is not None:
                self._settings = manager.settings
            else:
                self._settings = load_config()

        # Initialize secret analyzer with configured thresholds
        self._secret_analyzer = SecretContextAnalyzer(
            entropy_thresholds=self._settings.get_entropy_thresholds()
        )
        self._fp_filter = FalsePositiveFilter()

        # Store confidence thresholds for easy access
        self._min_confidence = self._settings.confidence.min_secret
        self._critical_confidence = self._settings.confidence.critical
        self._high_confidence = self._settings.confidence.high

        # Initialize structured logger with framework context
        self._logger = LoggerFactory.get_logger(
            LogCategory.SCANNER_ANALYSIS, framework=self.framework_name
        )
        self._decision_logger = LoggerFactory.get_logger(
            LogCategory.DECISION, framework=self.framework_name
        )

    @property
    def settings(self) -> MimicSettings:
        """Get current settings."""
        return self._settings

    def update_settings(self, settings: MimicSettings) -> None:
        """
        Update scanner settings at runtime.

        Args:
            settings: New configuration settings
        """
        self._settings = settings
        self._secret_analyzer.set_entropy_thresholds(settings.get_entropy_thresholds())
        self._min_confidence = settings.confidence.min_secret
        self._critical_confidence = settings.confidence.critical
        self._high_confidence = settings.confidence.high

    @abstractmethod
    def scan(self, path: Path) -> SecurityScanResult:
        """
        Scan path for security issues.

        Args:
            path: Path to file or directory to scan

        Returns:
            SecurityScanResult with all findings and metadata
        """
        pass

    @abstractmethod
    def get_agents(self, path: Path) -> list[SecurityAgent]:
        """
        Extract agents with security metadata.

        Args:
            path: Path to file or directory to scan

        Returns:
            List of SecurityAgent objects found
        """
        pass

    @abstractmethod
    def get_vulnerabilities(self, agent: SecurityAgent) -> list[SecurityFinding]:
        """
        Analyze agent for vulnerabilities.

        Args:
            agent: SecurityAgent to analyze

        Returns:
            List of SecurityFinding objects for the agent
        """
        pass

    def _build_location(
        self,
        file_path: str,
        source_code: str,
        node: ast.AST | None = None,
        line_number: int | None = None,
    ) -> SourceLocation:
        """
        Build a SourceLocation with full context.

        US-001: Include Line Numbers in All Scan Findings
        US-002: Include Column Offset in Findings
        US-010: Code Snippet with Highlighting
        """
        return build_source_location(
            file_path=file_path,
            source_code=source_code,
            node=node,
            line_number=line_number,
            context_lines=3,
        )

    def _build_explanation(
        self,
        file_path: str,
        source_code: str,
        category: VulnerabilityCategory,
        severity: Severity,
        trigger_detail: str,
        line_number: int,
    ) -> FindingExplanation:
        """
        Build a FindingExplanation with rich context.

        US-009: Enhanced Finding Descriptions
        US-011: Severity Justification
        """
        return build_finding_explanation(
            file_path=file_path,
            source_code=source_code,
            category=category,
            severity=severity,
            trigger_detail=trigger_detail,
            line_number=line_number,
        )

    def check_prompt_injection_risk(
        self,
        prompt: str,
        file_path: str,
        line_number: int,
        agent_id: str | None = None,
        source_code: str | None = None,
    ) -> SecurityFinding | None:
        """
        Check prompt for injection vulnerabilities.

        Args:
            prompt: The prompt text to analyze
            file_path: Path to source file
            line_number: Line number in source
            agent_id: Optional agent ID
            source_code: Full source code for context building

        Returns:
            SecurityFinding if vulnerability found, None otherwise
        """
        if not prompt:
            return None

        # Check for patterns that suggest user input is directly in prompt
        for pattern in self.PROMPT_INJECTION_PATTERNS:
            if re.search(pattern, prompt, re.IGNORECASE):
                # Build enhanced location and explanation
                location = None
                explanation = None
                severity_factors = ["Pattern matches known prompt injection technique"]

                if source_code:
                    location = self._build_location(file_path, source_code, line_number=line_number)
                    explanation = self._build_explanation(
                        file_path,
                        source_code,
                        VulnerabilityCategory.PROMPT_INJECTION,
                        Severity.HIGH,
                        pattern,
                        line_number,
                    )
                    severity_factors.extend(explanation.risk_factors)

                return SecurityFinding(
                    id=SecurityFinding.generate_id(),
                    title="Potential Prompt Injection Vulnerability",
                    description=f"The prompt contains patterns that may indicate vulnerability to prompt injection attacks. Pattern detected: {pattern}",
                    severity=Severity.HIGH,
                    confidence=0.7,
                    owasp_category=OWASPCategory.LLM01,
                    category=VulnerabilityCategory.PROMPT_INJECTION,
                    file_path=file_path,
                    line_number=line_number,
                    code_snippet=prompt[:200] + "..." if len(prompt) > 200 else prompt,
                    recommendation="Implement input validation and sanitization. Use structured prompts with clear boundaries between system instructions and user input.",
                    agent_id=agent_id,
                    cwe_id="CWE-77",
                    location=location,
                    explanation=explanation,
                    severity_factors=severity_factors,
                    detection_method="regex",
                )

        # Check if prompt appears to have no input validation
        if "{" in prompt and "user" in prompt.lower():
            location = None
            explanation = None
            severity_factors = ["User input placeholder detected in prompt template"]

            if source_code:
                location = self._build_location(file_path, source_code, line_number=line_number)
                explanation = self._build_explanation(
                    file_path,
                    source_code,
                    VulnerabilityCategory.PROMPT_INJECTION,
                    Severity.MEDIUM,
                    "User input in template",
                    line_number,
                )
                severity_factors.extend(explanation.risk_factors)

            return SecurityFinding(
                id=SecurityFinding.generate_id(),
                title="Unvalidated User Input in Prompt",
                description="The prompt template includes user input without apparent validation or sanitization.",
                severity=Severity.MEDIUM,
                confidence=0.6,
                owasp_category=OWASPCategory.LLM01,
                category=VulnerabilityCategory.PROMPT_INJECTION,
                file_path=file_path,
                line_number=line_number,
                code_snippet=prompt[:200] + "..." if len(prompt) > 200 else prompt,
                recommendation="Validate and sanitize all user inputs before including them in prompts. Consider using input schemas or allow-lists.",
                agent_id=agent_id,
                cwe_id="CWE-20",
                location=location,
                explanation=explanation,
                severity_factors=severity_factors,
                detection_method="heuristic",
            )

        return None

    def check_excessive_agency(
        self,
        agent: SecurityAgent,
        file_path: str,
        line_number: int,
        source_code: str | None = None,
    ) -> SecurityFinding | None:
        """
        Check for excessive permissions/capabilities.

        Args:
            agent: SecurityAgent to check
            file_path: Path to source file
            line_number: Line number in source
            source_code: Full source code for context building

        Returns:
            SecurityFinding if vulnerability found, None otherwise
        """
        high_risk_categories = []

        for tool in agent.tools:
            from vantage_core.security.models import ToolCategory

            if ToolCategory.CODE_EXECUTION in tool.categories:
                high_risk_categories.append("code_execution")
            if ToolCategory.FILE_SYSTEM in tool.categories:
                high_risk_categories.append("file_system")
            if ToolCategory.SYSTEM in tool.categories:
                high_risk_categories.append("system")

        if len(high_risk_categories) >= 2:
            location = None
            explanation = None
            severity_factors = [
                f"Agent has {len(high_risk_categories)} high-risk capabilities",
                f"Capabilities: {', '.join(high_risk_categories)}",
                "Compromise could lead to significant damage",
            ]

            if source_code:
                location = self._build_location(file_path, source_code, line_number=line_number)
                explanation = self._build_explanation(
                    file_path,
                    source_code,
                    VulnerabilityCategory.EXCESSIVE_AGENCY,
                    Severity.HIGH,
                    str(high_risk_categories),
                    line_number,
                )

            return SecurityFinding(
                id=SecurityFinding.generate_id(),
                title="Excessive Agency Detected",
                description=f"Agent '{agent.name}' has multiple high-risk capabilities: {', '.join(high_risk_categories)}. This increases the potential impact of a compromised agent.",
                severity=Severity.HIGH,
                confidence=0.8,
                owasp_category=OWASPCategory.LLM08,
                category=VulnerabilityCategory.EXCESSIVE_AGENCY,
                file_path=file_path,
                line_number=line_number,
                code_snippet=f"Agent: {agent.name}, Tools: {[t.name for t in agent.tools]}",
                recommendation="Apply the principle of least privilege. Separate high-risk capabilities into different agents with appropriate trust levels.",
                agent_id=agent.id,
                cwe_id="CWE-250",
                location=location,
                explanation=explanation,
                severity_factors=severity_factors,
                detection_method="heuristic",
            )

        if agent.trust_level.value < agent.highest_tool_trust.value:
            location = None
            explanation = None
            severity_factors = [
                f"Agent trust level: {agent.trust_level.name}",
                f"Tool requirement: {agent.highest_tool_trust.name}",
                "Trust mismatch enables privilege escalation",
            ]

            if source_code:
                location = self._build_location(file_path, source_code, line_number=line_number)
                explanation = self._build_explanation(
                    file_path,
                    source_code,
                    VulnerabilityCategory.PRIVILEGE_ESCALATION,
                    Severity.MEDIUM,
                    "Trust level mismatch",
                    line_number,
                )

            return SecurityFinding(
                id=SecurityFinding.generate_id(),
                title="Agent Trust Level Below Tool Requirements",
                description=f"Agent '{agent.name}' has trust level {agent.trust_level.name} but uses tools requiring {agent.highest_tool_trust.name} trust.",
                severity=Severity.MEDIUM,
                confidence=0.9,
                owasp_category=OWASPCategory.LLM08,
                category=VulnerabilityCategory.PRIVILEGE_ESCALATION,
                file_path=file_path,
                line_number=line_number,
                code_snippet=f"Agent trust: {agent.trust_level.name}, Tool requirement: {agent.highest_tool_trust.name}",
                recommendation="Increase agent trust level or restrict access to high-trust tools.",
                agent_id=agent.id,
                cwe_id="CWE-269",
                location=location,
                explanation=explanation,
                severity_factors=severity_factors,
                detection_method="heuristic",
            )

        return None

    def _is_test_file(self, file_path: str) -> bool:
        """
        Check if file is a test file.

        Args:
            file_path: Path to check

        Returns:
            True if file appears to be a test file
        """
        path_lower = file_path.lower()
        return any(
            [
                "/test_" in path_lower,
                "_test.py" in path_lower,
                "/tests/" in path_lower,
                "/test/" in path_lower,
                "/testing/" in path_lower,
                "conftest.py" in path_lower,
                "/fixtures/" in path_lower,
                "/mock" in path_lower,
                "examples" in path_lower,
                "samples" in path_lower,
                "test-repos" in path_lower,
            ]
        )

    def _is_false_positive_secret(self, line: str, value: str | None = None) -> bool:
        """
        Check if a potential secret is actually a false positive.

        Args:
            line: The line of code containing the potential secret
            value: The extracted secret value (if available)

        Returns:
            True if this appears to be a false positive
        """
        line_lower = line.lower()

        # Check against false positive indicators
        for indicator in self.FALSE_POSITIVE_INDICATORS:
            if re.search(indicator, line_lower):
                return True

        # Check if value matches variable name pattern (e.g., API_KEY = "API_KEY")
        if self.CONSTANT_NAME_PATTERN.search(line):
            return True

        # Check if value is a class name export (in __all__)
        if "__all__" in line:
            return True

        # Check for dictionary key patterns (not actual secrets)
        if re.search(r"['\"][A-Za-z]+['\"]:\s*['\"]", line):
            # Additional check: if it looks like a dataset/class mapping
            if any(x in line_lower for x in ["dataset", "retriever", "evaluator", "class"]):
                return True

        # Check for type annotation patterns (e.g., params: 'SomeType' = {})
        if re.search(r":\s*['\"][A-Z][a-zA-Z]+['\"]", line):
            return True

        # Check if it's a dictionary literal with 'id' keys (Chrome extensions, etc)
        if re.search(r"['\"]id['\"]:\s*['\"][a-z]+['\"]", line_lower):
            return True

        # Check if it's a string with only common words (not entropy)
        if value:
            # Very short values are likely placeholders
            if len(value) < 8:
                return True
            # Values that are readable words
            if value.lower() in [
                "password",
                "secret",
                "token",
                "key",
                "api_key",
                "test",
                "demo",
            ]:
                return True
            # Values that start with common placeholder prefixes
            if value.lower().startswith(("your", "my", "the", "a_", "an_")):
                return True
            # CamelCase identifiers (Chrome flags, feature names)
            if re.match(r"^[A-Z][a-z]+(?:[A-Z][a-z]+)+$", value):
                return True
            # Chrome extension IDs (32 char lowercase alphanum)
            if re.match(r"^[a-z]{32}$", value):
                return True

        return False

    def check_hardcoded_secrets(self, code: str, file_path: str) -> list[SecurityFinding]:
        """
        Check for hardcoded secrets in code using entropy-based analysis.

        This method now includes comprehensive false positive filtering using:
        - Test file detection (US-FP-001)
        - Placeholder value recognition (US-FP-002)
        - Constant name pattern detection (US-FP-003)
        - OAuth/Protocol enum whitelist (US-FP-004)
        - Class export detection (US-FP-005)

        Args:
            code: Source code to analyze
            file_path: Path to source file

        Returns:
            List of SecurityFinding objects for detected secrets
        """
        findings = []
        lines = code.split("\n")

        for i, line in enumerate(lines, 1):
            for pattern, description in self.SECRET_PATTERNS:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    # Extract the potential secret value
                    value = match.group(1) if match.groups() else None

                    if not value or len(value) < 8:
                        self._decision_logger.debug(
                            "finding_filtered",
                            file_path=file_path,
                            line_number=i,
                            pattern=description,
                            filter_reason=FilterReason.LOW_CONFIDENCE.value,
                            details="Value too short (< 8 characters)",
                        )
                        continue

                    # Extract variable name if present
                    var_match = re.search(r"(\w+)\s*=", line)
                    variable_name = var_match.group(1) if var_match else None

                    # Use entropy-based context analyzer
                    context = self._secret_analyzer.analyze(
                        value=value,
                        file_path=file_path,
                        line_number=i,
                        source_code=code,
                        variable_name=variable_name,
                    )

                    # Check if this should be reported based on context
                    if not self._secret_analyzer.should_report(
                        context, min_confidence=self._min_confidence
                    ):
                        self._decision_logger.debug(
                            "finding_filtered",
                            file_path=file_path,
                            line_number=i,
                            pattern=description,
                            filter_reason=FilterReason.LOW_CONFIDENCE.value,
                            confidence=context.final_confidence,
                            entropy_score=context.entropy_analysis.entropy_score,
                        )
                        continue

                    # Apply P0 false positive filters
                    # Create a simple finding-like object for the filter
                    class TempFinding:
                        pass

                    temp_finding = TempFinding()
                    temp_finding.file_path = file_path
                    temp_finding.line_number = i
                    temp_finding.code_snippet = line

                    filter_result = self._fp_filter.filter_finding(
                        finding=temp_finding, source_code=code, value=value
                    )

                    # Skip this finding if it was filtered as a false positive
                    if filter_result.should_filter:
                        self._decision_logger.debug(
                            "finding_filtered",
                            file_path=file_path,
                            line_number=i,
                            pattern=description,
                            filter_reason=FilterReason.FALSE_POSITIVE_PATTERN.value,
                            filter_type=(
                                filter_result.filter_type
                                if hasattr(filter_result, "filter_type")
                                else "fp_filter"
                            ),
                        )
                        continue

                    # Calculate severity based on confidence using configured thresholds
                    confidence = context.final_confidence
                    if confidence >= self._critical_confidence:
                        severity = Severity.CRITICAL
                    elif confidence >= self._high_confidence:
                        severity = Severity.HIGH
                    else:
                        severity = Severity.MEDIUM

                    # Build enhanced location and explanation
                    location = self._build_location(file_path, code, line_number=i)
                    explanation = self._build_explanation(
                        file_path,
                        code,
                        VulnerabilityCategory.HARDCODED_SECRET,
                        severity,
                        description,
                        i,
                    )

                    severity_factors = [
                        f"Pattern matched: {description}",
                        f"Entropy score: {context.entropy_analysis.entropy_score:.2f}",
                        f"Shannon entropy: {context.entropy_analysis.shannon_entropy:.2f} bits",
                    ]

                    # Add context-specific factors
                    if context.entropy_analysis.is_base64_like:
                        severity_factors.append("Value appears to be base64 encoded")
                    if context.entropy_analysis.is_hex_like:
                        severity_factors.append("Value appears to be hexadecimal")

                    for usage in context.usages:
                        severity_factors.append(f"Used in: {usage.usage_type.value}")

                    severity_factors.extend(explanation.risk_factors)

                    finding = SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Hardcoded Secret Detected",
                        description=f"{description} found in source code. Secrets should not be hardcoded.",
                        severity=severity,
                        confidence=confidence,
                        owasp_category=OWASPCategory.LLM06,
                        category=VulnerabilityCategory.HARDCODED_SECRET,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line[:100] + "..." if len(line) > 100 else line,
                        recommendation="Use environment variables or a secrets manager. Never commit secrets to source control.",
                        cwe_id="CWE-798",
                        location=location,
                        explanation=explanation,
                        severity_factors=severity_factors,
                        detection_method="entropy_analysis",
                    )
                    findings.append(finding)

                    # Log finding reported decision
                    self._decision_logger.info(
                        "finding_reported",
                        finding_id=finding.id,
                        file_path=file_path,
                        line_number=i,
                        severity=severity.value,
                        confidence=confidence,
                        pattern=description,
                        category=VulnerabilityCategory.HARDCODED_SECRET.value,
                    )
                    break  # One finding per line

        return findings

    def check_dangerous_code_patterns(self, code: str, file_path: str) -> list[SecurityFinding]:
        """
        Check for dangerous code patterns.

        Args:
            code: Source code to analyze
            file_path: Path to source file

        Returns:
            List of SecurityFinding objects
        """
        findings = []
        lines = code.split("\n")
        context_builder = ContextBuilder(code, file_path)

        for i, line in enumerate(lines, 1):
            for pattern, description, severity in self.DANGEROUS_CODE_PATTERNS:
                if re.search(pattern, line):
                    # Build enhanced location and explanation
                    location = self._build_location(file_path, code, line_number=i)
                    explanation = self._build_explanation(
                        file_path,
                        code,
                        VulnerabilityCategory.CODE_EXECUTION,
                        severity,
                        description,
                        i,
                    )

                    # Get enclosing scope for context
                    class_name, func_name = context_builder.get_scope_at_line(i)

                    severity_factors = [
                        f"Dangerous function detected: {description}",
                        "Can lead to arbitrary code execution",
                    ]
                    severity_factors.extend(explanation.risk_factors)

                    # Check for mitigating factors
                    is_test_file = any(
                        x in file_path.lower() for x in ["test_", "_test.py", "tests/"]
                    )
                    if is_test_file:
                        severity_factors.append("Located in test file (reduced risk)")

                    findings.append(
                        SecurityFinding(
                            id=SecurityFinding.generate_id(),
                            title=f"Dangerous Code Pattern: {description}",
                            description=f"Detected {description} which can lead to code injection vulnerabilities.",
                            severity=severity,
                            confidence=0.85,
                            owasp_category=OWASPCategory.LLM02,
                            category=VulnerabilityCategory.CODE_EXECUTION,
                            file_path=file_path,
                            line_number=i,
                            code_snippet=line.strip(),
                            recommendation="Avoid using eval/exec. If dynamic code execution is required, use sandboxing and strict input validation.",
                            cwe_id="CWE-94",
                            location=location,
                            explanation=explanation,
                            severity_factors=severity_factors,
                            detection_method="regex",
                            enclosing_function=func_name,
                            enclosing_class=class_name,
                            is_in_test_file=is_test_file,
                        )
                    )

        return findings

    def check_unsafe_delegation(
        self,
        agent: SecurityAgent,
        file_path: str,
        line_number: int,
        source_code: str | None = None,
    ) -> SecurityFinding | None:
        """
        Check for unsafe delegation patterns.

        Args:
            agent: SecurityAgent to check
            file_path: Path to source file
            line_number: Line number in source
            source_code: Full source code for context building

        Returns:
            SecurityFinding if vulnerability found, None otherwise
        """
        if agent.allow_delegation and agent.trust_level.value >= TrustLevel.PRIVILEGED.value:
            location = None
            explanation = None
            severity_factors = [
                f"Agent has {agent.trust_level.name} trust level",
                "Unrestricted delegation enabled",
                "Could enable trust laundering attacks",
            ]

            if source_code:
                location = self._build_location(file_path, source_code, line_number=line_number)
                explanation = self._build_explanation(
                    file_path,
                    source_code,
                    VulnerabilityCategory.UNSAFE_DELEGATION,
                    Severity.HIGH,
                    "allow_delegation=True",
                    line_number,
                )

            return SecurityFinding(
                id=SecurityFinding.generate_id(),
                title="Privileged Agent with Unrestricted Delegation",
                description=f"Agent '{agent.name}' has privileged trust level ({agent.trust_level.name}) and allows unrestricted delegation. This could enable trust laundering attacks.",
                severity=Severity.HIGH,
                confidence=0.85,
                owasp_category=OWASPCategory.LLM08,
                maas_category=MAASCategory.MAAS03,
                category=VulnerabilityCategory.UNSAFE_DELEGATION,
                file_path=file_path,
                line_number=line_number,
                code_snippet=f"Agent: {agent.name}, allow_delegation=True, trust_level={agent.trust_level.name}",
                recommendation="Restrict delegation to specific trusted agents or disable delegation for privileged agents.",
                agent_id=agent.id,
                cwe_id="CWE-284",
                location=location,
                explanation=explanation,
                severity_factors=severity_factors,
                detection_method="heuristic",
            )

        return None

    def infer_trust_level(self, agent_data: dict[str, Any]) -> TrustLevel:
        """
        Infer trust level from agent metadata.

        US-003: Reduce False Positives in Trust Level Detection

        Uses semantic analysis instead of simple keyword matching
        to reduce false positives.

        Args:
            agent_data: Dictionary with agent configuration

        Returns:
            Inferred TrustLevel
        """
        name = str(agent_data.get("name", ""))
        role = str(agent_data.get("role", ""))
        prompt = str(agent_data.get("system_prompt", ""))
        goal = str(agent_data.get("goal", ""))
        tools = agent_data.get("tools", [])

        # Use semantic analyzer for more accurate inference
        trust_level, confidence, factors = self._semantic_analyzer.analyze_agent_role(
            name=name, role=role, system_prompt=prompt, goal=goal, tools=tools
        )

        # Store confidence for later use
        agent_data["_trust_confidence"] = confidence
        agent_data["_trust_factors"] = factors

        # Map numeric level to TrustLevel enum
        level_map = {
            0: TrustLevel.EXTERNAL,
            1: TrustLevel.USER,
            2: TrustLevel.INTERNAL,
            3: TrustLevel.PRIVILEGED,
            4: TrustLevel.SYSTEM,
        }

        return level_map.get(trust_level, TrustLevel.INTERNAL)

    def infer_trust_level_with_confidence(
        self, agent_data: dict[str, Any]
    ) -> tuple[TrustLevel, float, list[str]]:
        """
        Infer trust level with confidence score and factors.

        US-003: Reduce False Positives in Trust Level Detection

        Args:
            agent_data: Dictionary with agent configuration

        Returns:
            Tuple of (TrustLevel, confidence, factors)
        """
        name = str(agent_data.get("name", ""))
        role = str(agent_data.get("role", ""))
        prompt = str(agent_data.get("system_prompt", ""))
        goal = str(agent_data.get("goal", ""))
        tools = agent_data.get("tools", [])

        trust_level_int, confidence, factors = self._semantic_analyzer.analyze_agent_role(
            name=name, role=role, system_prompt=prompt, goal=goal, tools=tools
        )

        level_map = {
            0: TrustLevel.EXTERNAL,
            1: TrustLevel.USER,
            2: TrustLevel.INTERNAL,
            3: TrustLevel.PRIVILEGED,
            4: TrustLevel.SYSTEM,
        }

        return level_map.get(trust_level_int, TrustLevel.INTERNAL), confidence, factors

    def parse_python_file(self, path: Path) -> ast.Module | None:
        """
        Parse a Python file into an AST.

        US-005: Uses specific exception types instead of bare exceptions.

        Args:
            path: Path to Python file

        Returns:
            AST Module or None if parsing fails

        Raises:
            SyntaxParseError: If the file has syntax errors
            EncodingError: If the file cannot be decoded
            FileNotFoundError: If the file does not exist
        """
        from vantage_core.security.errors import (
            EncodingError,
            FileReadError,
            PermissionDeniedError,
            SyntaxParseError,
        )
        from vantage_core.security.errors import (
            FileNotFoundError as MimicFileNotFoundError,
        )

        try:
            with open(path, encoding="utf-8") as f:
                code = f.read()
            return ast.parse(code)
        except SyntaxError as e:
            self._logger.warning(
                "parse_syntax_error",
                file_path=str(path),
                line_number=e.lineno,
                error=str(e.msg) if hasattr(e, "msg") else str(e),
            )
            raise SyntaxParseError(
                file_path=str(path),
                line=e.lineno or 0,
                column=e.offset or 0,
                message=e.msg if hasattr(e, "msg") else str(e),
                cause=e,
            )
        except UnicodeDecodeError as e:
            self._logger.warning(
                "parse_encoding_error",
                file_path=str(path),
                error=str(e),
            )
            raise EncodingError(
                file_path=str(path),
                encoding="utf-8",
                cause=e,
            )
        except FileNotFoundError:
            self._logger.error(
                "parse_file_not_found",
                file_path=str(path),
            )
            raise MimicFileNotFoundError(str(path))
        except PermissionError:
            self._logger.error(
                "parse_permission_denied",
                file_path=str(path),
            )
            raise PermissionDeniedError(str(path), "read")
        except OSError as e:
            self._logger.error(
                "parse_io_error",
                file_path=str(path),
                error=str(e),
            )
            raise FileReadError(str(path), e)

    def extract_string_value(self, node: ast.AST) -> str | None:
        """
        Extract string value from AST node.

        Args:
            node: AST node

        Returns:
            String value or None
        """
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        if isinstance(node, ast.JoinedStr):
            # f-string - return placeholder
            return "{f-string}"
        return None

    def create_scan_result(
        self,
        findings: list[SecurityFinding],
        agents: list[SecurityAgent],
        frameworks: list[str],
        start_time: float,
        communications: list[AgentCommunication] | None = None,
    ) -> SecurityScanResult:
        """
        Create a SecurityScanResult from scan data.

        Args:
            findings: List of findings
            agents: List of agents found
            frameworks: List of framework names
            start_time: Scan start timestamp
            communications: Optional list of agent communications
        """
        duration_ms = int((time.time() - start_time) * 1000)

        return SecurityScanResult(
            scan_id=SecurityScanResult.generate_scan_id(),
            timestamp=datetime.utcnow(),
            findings=findings,
            agents_scanned=len(agents),
            frameworks_detected=frameworks,
            scan_duration_ms=duration_ms,
            agents=agents,
            communications=communications or [],
        )

    @classmethod
    def can_handle(cls, path: Path) -> bool:
        """
        Check if this scanner can handle the given path.

        Override in subclasses to implement framework detection.

        Args:
            path: Path to check

        Returns:
            True if scanner can handle this path
        """
        return False
