"""
Google GenAI Security Scanner.

Detects GenerativeModel usage, chat sessions, and tool configurations in Google GenAI-based projects.
"""

import ast
import time
from pathlib import Path

from vantage_core.security.models import (
    AgentCommunication,
    CommunicationType,
    ContentType,
    SecurityAgent,
    SecurityFinding,
    SecurityScanResult,
    SecurityTool,
    ToolCategory,
    TrustLevel,
)
from vantage_core.security.scanners.base import SecurityScanner


class GoogleGenAISecurityScanner(SecurityScanner):
    """
    Security scanner for Google Generative AI SDK (Gemini).

    Detects:
    - GenerativeModel instantiation
    - Chat sessions (start_chat)
    - Function declarations (Tools)
    """

    framework_name = "google_genai"

    def scan(self, path: Path) -> SecurityScanResult:
        """Scan Google GenAI project for security issues."""
        start_time = time.time()
        findings: list[SecurityFinding] = []
        agents: list[SecurityAgent] = []
        communications: list[AgentCommunication] = []

        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()

                file_agents = self._extract_agents_from_file(file_path, code)
                agents.extend(file_agents)

                file_communications = self._extract_communications(file_path, code)
                communications.extend(file_communications)

                findings.extend(self.check_hardcoded_secrets(code, str(file_path)))
                findings.extend(self.check_dangerous_code_patterns(code, str(file_path)))

                for agent in file_agents:
                    agent_findings = self.get_vulnerabilities(agent)
                    findings.extend(agent_findings)

            except Exception:
                continue

        return self.create_scan_result(
            findings=findings,
            agents=agents,
            communications=communications,
            frameworks=["google_genai"],
            start_time=start_time,
        )

    def get_agents(self, path: Path) -> list[SecurityAgent]:
        """Extract Google GenAI agents from path."""
        agents: list[SecurityAgent] = []
        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()
                agents.extend(self._extract_agents_from_file(file_path, code))
            except Exception:
                continue
        return agents

    def get_vulnerabilities(self, agent: SecurityAgent) -> list[SecurityFinding]:
        """Analyze Google GenAI agent for vulnerabilities."""
        findings: list[SecurityFinding] = []
        file_path = agent.file_path or "unknown"
        line_number = agent.line_number or 1

        if agent.system_prompt:
            finding = self.check_prompt_injection_risk(
                agent.system_prompt, file_path, line_number, agent.id
            )
            if finding:
                findings.append(finding)

        return findings

    def _extract_agents_from_file(self, file_path: Path, code: str) -> list[SecurityAgent]:
        """Extract Google GenAI agents from a single file."""
        agents: list[SecurityAgent] = []
        tree = ast.parse(code)

        class AgentVisitor(ast.NodeVisitor):
            def __init__(self, scanner: GoogleGenAISecurityScanner):
                self.scanner = scanner
                self.agents: list[SecurityAgent] = []

            def visit_Call(self, node: ast.Call) -> None:
                func_name = self._get_func_name(node)

                # genai.GenerativeModel
                if "GenerativeModel" in func_name:
                    agent = self._extract_agent_from_call(node)
                    if agent:
                        self.agents.append(agent)

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return self._get_attr_name(node.func)
                return ""

            def _get_attr_name(self, node: ast.Attribute) -> str:
                if isinstance(node.value, ast.Name):
                    return f"{node.value.id}.{node.attr}"
                elif isinstance(node.value, ast.Attribute):
                    return f"{self._get_attr_name(node.value)}.{node.attr}"
                return node.attr

            def _extract_agent_from_call(self, node: ast.Call) -> SecurityAgent | None:
                name = "Gemini Model"
                system_prompt = None
                tools: list[SecurityTool] = []

                if len(node.args) > 0 and isinstance(node.args[0], ast.Constant):
                    name = f"Gemini ({node.args[0].value})"

                for keyword in node.keywords:
                    if keyword.arg == "system_instruction":
                        if isinstance(keyword.value, ast.Constant):
                            system_prompt = str(keyword.value.value)
                    elif keyword.arg == "tools":
                        tools = self._extract_tools(keyword.value)

                agent_id = f"google_genai-{name}-{node.lineno}"

                return SecurityAgent(
                    id=agent_id,
                    name=name,
                    framework="google_genai",
                    system_prompt=system_prompt,
                    tools=tools,
                    file_path=str(file_path),
                    line_number=node.lineno,
                    trust_level=self.scanner.infer_trust_level(
                        {"name": name, "system_prompt": system_prompt or ""}
                    ),
                    metadata={"type": "generative_model"},
                )

            def _extract_tools(self, node: ast.AST) -> list[SecurityTool]:
                tools: list[SecurityTool] = []
                if isinstance(node, ast.List):
                    for elt in node.elts:
                        if isinstance(elt, ast.Dict):
                            # Handle tool dict definition
                            function_declarations = []
                            for k, v in zip(elt.keys, elt.values):
                                if (
                                    isinstance(k, ast.Constant)
                                    and k.value == "function_declarations"
                                ):
                                    function_declarations = v

                            if isinstance(function_declarations, ast.List):
                                for func in function_declarations.elts:
                                    if isinstance(func, ast.Dict):
                                        tool_name = "unknown"
                                        for fk, fv in zip(func.keys, func.values):
                                            if isinstance(fk, ast.Constant) and fk.value == "name":
                                                if isinstance(fv, ast.Constant):
                                                    tool_name = fv.value

                                        tools.append(
                                            SecurityTool(
                                                name=tool_name,
                                                description=f"Google Function: {tool_name}",
                                                categories=[ToolCategory.API],
                                                required_trust_level=TrustLevel.INTERNAL,
                                            )
                                        )
                return tools

        visitor = AgentVisitor(self)
        visitor.visit(tree)
        return visitor.agents

    def _extract_communications(self, file_path: Path, code: str) -> list[AgentCommunication]:
        """Extract communications from Google GenAI code."""
        communications: list[AgentCommunication] = []
        tree = ast.parse(code)

        class CommunicationVisitor(ast.NodeVisitor):
            def __init__(self):
                self.comms: list[AgentCommunication] = []
                self.models = {}  # var_name -> model_name

            def visit_Assign(self, node: ast.Assign) -> None:
                if isinstance(node.value, ast.Call):
                    func_name = self._get_func_name(node.value)

                    if "GenerativeModel" in func_name:
                        model_name = "Gemini Model"
                        if len(node.value.args) > 0 and isinstance(
                            node.value.args[0], ast.Constant
                        ):
                            model_name = f"Gemini ({node.value.args[0].value})"

                        for target in node.targets:
                            if isinstance(target, ast.Name):
                                self.models[target.id] = model_name

                self.generic_visit(node)

            def visit_Call(self, node: ast.Call) -> None:
                func_name = self._get_func_name(node)

                # start_chat
                if "start_chat" in func_name:
                    model_var = None
                    if isinstance(node.func, ast.Attribute) and isinstance(
                        node.func.value, ast.Name
                    ):
                        model_var = node.func.value.id

                    if model_var and model_var in self.models:
                        model_name = self.models[model_var]
                        # Agent -> Chat Session
                        self.comms.append(
                            AgentCommunication(
                                source_id=model_name,
                                target_id="chat_session",
                                communication_type=CommunicationType.DIRECT.value,
                                metadata={
                                    "protocol": "chat_session",
                                    "content_type": ContentType.TEXT.value,
                                    "file_path": str(file_path),
                                    "line_number": node.lineno,
                                },
                            )
                        )

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return self._get_attr_name(node.func)
                return ""

            def _get_attr_name(self, node: ast.Attribute) -> str:
                if isinstance(node.value, ast.Name):
                    return f"{node.value.id}.{node.attr}"
                elif isinstance(node.value, ast.Attribute):
                    return f"{self._get_attr_name(node.value)}.{node.attr}"
                return node.attr

        visitor = CommunicationVisitor()
        visitor.visit(tree)
        return visitor.comms

    @classmethod
    def can_handle(cls, path: Path) -> bool:
        """Check if this scanner can handle Google GenAI projects."""
        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    content = f.read()
                    if any(
                        x in content
                        for x in [
                            "import google.generativeai",
                            "from google.generativeai",
                        ]
                    ):
                        return True
            except Exception:
                continue

        return False
