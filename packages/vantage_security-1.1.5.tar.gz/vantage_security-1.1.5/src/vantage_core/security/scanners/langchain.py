"""
LangChain/LangGraph Security Scanner.

Detects agents, tools, chains, and graphs in LangChain-based projects
and identifies security-relevant patterns.
"""

import ast
import re
import time
from pathlib import Path

from vantage_core.security.models import (
    AgentCommunication,
    CommunicationType,
    ContentType,
    MAASCategory,
    OWASPCategory,
    SecurityAgent,
    SecurityFinding,
    SecurityScanResult,
    SecurityTool,
    Severity,
    ToolCategory,
    TrustLevel,
    VulnerabilityCategory,
)
from vantage_core.security.scanners.base import SecurityScanner


class LangChainSecurityScanner(SecurityScanner):
    """
    Security scanner for LangChain and LangGraph frameworks.

    Detects:
    - AgentExecutor, create_react_agent patterns
    - LangGraph StateGraph nodes and edges
    - Tool definitions and bindings
    - Memory configurations
    - Chain compositions
    """

    framework_name = "langchain"

    # LangChain-specific patterns
    AGENT_PATTERNS = [
        "AgentExecutor",
        "create_react_agent",
        "create_openai_functions_agent",
        "create_structured_chat_agent",
        "create_xml_agent",
        "create_json_agent",
        "create_tool_calling_agent",
    ]

    LANGGRAPH_PATTERNS = [
        "StateGraph",
        "MessageGraph",
        "add_node",
        "add_edge",
        "add_conditional_edges",
        "set_entry_point",
        "set_finish_point",
    ]

    MEMORY_TYPES = [
        "ConversationBufferMemory",
        "ConversationSummaryMemory",
        "VectorStoreMemory",
        "ConversationBufferWindowMemory",
        "ConversationTokenBufferMemory",
    ]

    DANGEROUS_TOOLS = [
        ("ShellTool", ToolCategory.CODE_EXECUTION, TrustLevel.SYSTEM),
        ("PythonREPLTool", ToolCategory.CODE_EXECUTION, TrustLevel.PRIVILEGED),
        ("RequestsTool", ToolCategory.NETWORK, TrustLevel.INTERNAL),
        ("FileManagementTool", ToolCategory.FILE_SYSTEM, TrustLevel.PRIVILEGED),
        ("SQLDatabaseTool", ToolCategory.DATABASE, TrustLevel.PRIVILEGED),
    ]

    def scan(self, path: Path) -> SecurityScanResult:
        """Scan LangChain project for security issues."""
        start_time = time.time()
        findings: list[SecurityFinding] = []
        agents: list[SecurityAgent] = []
        communications: list[AgentCommunication] = []

        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()

                # Parse and extract agents
                file_agents = self._extract_agents_from_file(file_path, code)
                agents.extend(file_agents)

                # Extract communications (Topology Discovery)
                file_communications = self._extract_communications(file_path, code)
                communications.extend(file_communications)

                # Check for vulnerabilities
                findings.extend(self.check_hardcoded_secrets(code, str(file_path)))
                findings.extend(self.check_dangerous_code_patterns(code, str(file_path)))
                findings.extend(self._check_langchain_patterns(code, str(file_path)))

                # Check each agent
                for agent in file_agents:
                    agent_findings = self.get_vulnerabilities(agent)
                    findings.extend(agent_findings)

            except SyntaxError as e:
                self._logger.warning(
                    "file_parse_error",
                    file_path=str(file_path),
                    line_number=e.lineno,
                    error=str(e.msg),
                )
                continue
            except UnicodeDecodeError as e:
                self._logger.warning(
                    "file_encoding_error",
                    file_path=str(file_path),
                    error=str(e),
                )
                continue
            except Exception as e:
                self._logger.error(
                    "file_scan_error",
                    file_path=str(file_path),
                    error_type=type(e).__name__,
                    error=str(e),
                    exc_info=True,
                )
                continue

        return self.create_scan_result(
            findings=findings,
            agents=agents,
            communications=communications,
            frameworks=["langchain"],
            start_time=start_time,
        )

    def _extract_communications(self, file_path: Path, code: str) -> list[AgentCommunication]:
        """Extract communications from LangChain code."""
        communications: list[AgentCommunication] = []
        tree = ast.parse(code)

        class CommunicationVisitor(ast.NodeVisitor):
            def __init__(self):
                self.comms: list[AgentCommunication] = []
                self.current_graph = None

            def visit_Call(self, node: ast.Call) -> None:
                func_name = self._get_func_name(node)

                # LangGraph: add_edge(source, target)
                if func_name == "add_edge":
                    if len(node.args) >= 2:
                        source = self._get_arg_value(node.args[0])
                        target = self._get_arg_value(node.args[1])
                        if source and target:
                            self.comms.append(
                                AgentCommunication(
                                    source_id=source,
                                    target_id=target,
                                    communication_type=CommunicationType.DIRECT.value,
                                    metadata={
                                        "protocol": "langgraph_edge",
                                        "content_type": ContentType.TEXT.value,
                                        "file_path": str(file_path),
                                        "line_number": node.lineno,
                                    },
                                )
                            )

                # LangGraph: set_entry_point(node)
                elif func_name == "set_entry_point":
                    if len(node.args) >= 1:
                        target = self._get_arg_value(node.args[0])
                        if target:
                            self.comms.append(
                                AgentCommunication(
                                    source_id="user",
                                    target_id=target,
                                    communication_type=CommunicationType.DIRECT.value,
                                    metadata={
                                        "protocol": "entry_point",
                                        "content_type": ContentType.TEXT.value,
                                        "file_path": str(file_path),
                                        "line_number": node.lineno,
                                    },
                                )
                            )

                # AgentExecutor: Agent <-> Tools
                elif func_name in LangChainSecurityScanner.AGENT_PATTERNS:
                    # Find tools argument
                    tools = []
                    for keyword in node.keywords:
                        if keyword.arg == "tools":
                            tools = self._extract_tool_names(keyword.value)

                    agent_name = f"langchain-{func_name}-{node.lineno}"
                    for tool in tools:
                        # Agent -> Tool
                        self.comms.append(
                            AgentCommunication(
                                source_id=agent_name,
                                target_id=tool,
                                communication_type=CommunicationType.DELEGATION.value,
                                metadata={
                                    "protocol": "tool_call",
                                    "content_type": ContentType.TEXT.value,
                                    "file_path": str(file_path),
                                    "line_number": node.lineno,
                                },
                            )
                        )
                        # Tool -> Agent (Return)
                        self.comms.append(
                            AgentCommunication(
                                source_id=tool,
                                target_id=agent_name,
                                communication_type=CommunicationType.DIRECT.value,
                                metadata={
                                    "protocol": "tool_return",
                                    "content_type": ContentType.TEXT.value,
                                    "file_path": str(file_path),
                                    "line_number": node.lineno,
                                },
                            )
                        )

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return node.func.attr
                return ""

            def _get_arg_value(self, node: ast.AST) -> str | None:
                if isinstance(node, ast.Constant):
                    return str(node.value)
                return None

            def _extract_tool_names(self, node: ast.AST) -> list[str]:
                names = []
                if isinstance(node, ast.List):
                    for elt in node.elts:
                        if isinstance(elt, ast.Name):
                            names.append(elt.id)
                return names

        visitor = CommunicationVisitor()
        visitor.visit(tree)
        return visitor.comms

    def get_agents(self, path: Path) -> list[SecurityAgent]:
        """Extract LangChain agents from path."""
        agents: list[SecurityAgent] = []

        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()
                agents.extend(self._extract_agents_from_file(file_path, code))
            except SyntaxError as e:
                self._logger.warning(
                    "agent_extraction_parse_error",
                    file_path=str(file_path),
                    error=str(e.msg),
                )
                continue
            except Exception as e:
                self._logger.error(
                    "agent_extraction_error",
                    file_path=str(file_path),
                    error_type=type(e).__name__,
                    error=str(e),
                )
                continue

        return agents

    def get_vulnerabilities(self, agent: SecurityAgent) -> list[SecurityFinding]:
        """Analyze LangChain agent for vulnerabilities."""
        findings: list[SecurityFinding] = []
        file_path = agent.file_path or "unknown"
        line_number = agent.line_number or 1

        # Check prompt injection risk
        if agent.system_prompt:
            finding = self.check_prompt_injection_risk(
                agent.system_prompt, file_path, line_number, agent.id
            )
            if finding:
                findings.append(finding)

        # Check excessive agency
        finding = self.check_excessive_agency(agent, file_path, line_number)
        if finding:
            findings.append(finding)

        # Check for dangerous tool combinations
        findings.extend(self._check_tool_security(agent, file_path, line_number))

        # Check memory security
        findings.extend(self._check_memory_security(agent, file_path, line_number))

        return findings

    def _extract_agents_from_file(self, file_path: Path, code: str) -> list[SecurityAgent]:
        """Extract agents from a single file."""
        agents: list[SecurityAgent] = []
        tree = ast.parse(code)

        class AgentVisitor(ast.NodeVisitor):
            def __init__(self, scanner: LangChainSecurityScanner):
                self.scanner = scanner
                self.agents: list[SecurityAgent] = []

            def visit_Call(self, node: ast.Call) -> None:
                # Check for agent creation patterns
                func_name = self._get_func_name(node)

                if func_name in LangChainSecurityScanner.AGENT_PATTERNS:
                    agent = self._extract_agent_from_call(node, func_name)
                    if agent:
                        self.agents.append(agent)

                # Check for StateGraph (LangGraph)
                if func_name == "StateGraph":
                    agent = self._extract_langgraph_agent(node)
                    if agent:
                        self.agents.append(agent)

                self.generic_visit(node)

            def visit_Assign(self, node: ast.Assign) -> None:
                # Check for tool definitions
                if isinstance(node.value, ast.Call):
                    func_name = self._get_func_name(node.value)
                    if func_name and "tool" in func_name.lower():
                        pass  # Tool tracking would go here

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return node.func.attr
                return ""

            def _extract_agent_from_call(
                self, node: ast.Call, func_name: str
            ) -> SecurityAgent | None:
                agent_id = f"langchain-{func_name}-{node.lineno}"
                tools: list[SecurityTool] = []
                system_prompt = None

                # Extract tools from arguments
                for keyword in node.keywords:
                    if keyword.arg == "tools":
                        tools = self._extract_tools(keyword.value)
                    elif keyword.arg == "prompt" and isinstance(keyword.value, ast.Constant):
                        system_prompt = str(keyword.value.value)
                    elif keyword.arg == "system_message" and isinstance(
                        keyword.value, ast.Constant
                    ):
                        system_prompt = str(keyword.value.value)

                return SecurityAgent(
                    id=agent_id,
                    name=func_name,
                    framework="langchain",
                    tools=tools,
                    system_prompt=system_prompt,
                    file_path=str(file_path),
                    line_number=node.lineno,
                    trust_level=self.scanner.infer_trust_level(
                        {"name": func_name, "system_prompt": system_prompt or ""}
                    ),
                )

            def _extract_langgraph_agent(self, node: ast.Call) -> SecurityAgent | None:
                agent_id = f"langgraph-stategraph-{node.lineno}"

                return SecurityAgent(
                    id=agent_id,
                    name="StateGraph",
                    framework="langgraph",
                    file_path=str(file_path),
                    line_number=node.lineno,
                    trust_level=TrustLevel.INTERNAL,
                    metadata={"type": "state_graph"},
                )

            def _extract_tools(self, node: ast.AST) -> list[SecurityTool]:
                tools: list[SecurityTool] = []

                if isinstance(node, ast.List):
                    for elt in node.elts:
                        if isinstance(elt, ast.Name):
                            tool = self._create_tool_from_name(elt.id)
                            if tool:
                                tools.append(tool)

                return tools

            def _create_tool_from_name(self, name: str) -> SecurityTool | None:
                # Check if it's a known dangerous tool
                for (
                    tool_name,
                    category,
                    trust,
                ) in LangChainSecurityScanner.DANGEROUS_TOOLS:
                    if tool_name.lower() in name.lower():
                        return SecurityTool(
                            name=name,
                            description=f"LangChain {tool_name}",
                            categories=[category],
                            required_trust_level=trust,
                            has_side_effects=True,
                        )

                # Default tool
                return SecurityTool(
                    name=name,
                    description=f"LangChain tool: {name}",
                    categories=[],
                    required_trust_level=TrustLevel.INTERNAL,
                )

        visitor = AgentVisitor(self)
        visitor.visit(tree)
        return visitor.agents

    def _check_langchain_patterns(self, code: str, file_path: str) -> list[SecurityFinding]:
        """Check for LangChain-specific security patterns."""
        findings: list[SecurityFinding] = []
        lines = code.split("\n")

        for i, line in enumerate(lines, 1):
            # Check for verbose=True which can leak information
            if re.search(r"verbose\s*=\s*True", line):
                # Skip if it's a test file or example
                if self._is_test_file(file_path):
                    continue

                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Verbose Mode Enabled",
                        description="Verbose mode can leak sensitive information in logs including prompts and tool outputs.",
                        severity=Severity.LOW,
                        confidence=0.9,
                        owasp_category=OWASPCategory.LLM06,
                        category=VulnerabilityCategory.DATA_LEAKAGE,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Disable verbose mode in production environments.",
                        cwe_id="CWE-532",
                    )
                )

            # Check for handle_parsing_errors that might expose internals
            if re.search(r"handle_parsing_errors\s*=\s*True", line):
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Parsing Error Handling May Expose Internals",
                        description="Automatic parsing error handling might expose internal error details to users.",
                        severity=Severity.LOW,
                        confidence=0.7,
                        owasp_category=OWASPCategory.LLM06,
                        category=VulnerabilityCategory.DATA_LEAKAGE,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Implement custom error handling that sanitizes error messages.",
                        cwe_id="CWE-209",
                    )
                )

            # Check for return_intermediate_steps which can leak data
            if re.search(r"return_intermediate_steps\s*=\s*True", line):
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Intermediate Steps Exposed",
                        description="Returning intermediate steps can expose internal reasoning and tool outputs to end users.",
                        severity=Severity.MEDIUM,
                        confidence=0.8,
                        owasp_category=OWASPCategory.LLM06,
                        category=VulnerabilityCategory.DATA_LEAKAGE,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Filter or sanitize intermediate steps before exposing to users.",
                        cwe_id="CWE-200",
                    )
                )

            # Check for allow_dangerous_requests
            if re.search(r"allow_dangerous_requests\s*=\s*True", line):
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Dangerous Requests Allowed",
                        description="The agent is configured to allow dangerous requests which could lead to security vulnerabilities.",
                        severity=Severity.HIGH,
                        confidence=0.95,
                        owasp_category=OWASPCategory.LLM08,
                        category=VulnerabilityCategory.EXCESSIVE_AGENCY,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Disable dangerous requests or implement strict validation.",
                        cwe_id="CWE-250",
                    )
                )

        return findings

    def _check_tool_security(
        self, agent: SecurityAgent, file_path: str, line_number: int
    ) -> list[SecurityFinding]:
        """Check for insecure tool usage patterns."""
        findings: list[SecurityFinding] = []

        for tool in agent.tools:
            # Check for shell/code execution tools
            if ToolCategory.CODE_EXECUTION in tool.categories:
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Code Execution Tool Without Sandboxing",
                        description=f"Tool '{tool.name}' provides code execution capabilities. Ensure proper sandboxing is in place.",
                        severity=Severity.HIGH,
                        confidence=0.85,
                        owasp_category=OWASPCategory.LLM07,
                        category=VulnerabilityCategory.INSECURE_TOOL_USE,
                        file_path=file_path,
                        line_number=line_number,
                        code_snippet=f"Tool: {tool.name}",
                        recommendation="Use Docker, gVisor, or similar sandboxing for code execution. Implement timeouts and resource limits.",
                        agent_id=agent.id,
                        cwe_id="CWE-94",
                    )
                )

        return findings

    def _check_memory_security(
        self, agent: SecurityAgent, file_path: str, line_number: int
    ) -> list[SecurityFinding]:
        """Check for memory-related security issues."""
        findings: list[SecurityFinding] = []

        memory_scope = agent.memory_scope or ""

        # Check for shared memory without isolation
        if "shared" in memory_scope.lower() or "global" in memory_scope.lower():
            findings.append(
                SecurityFinding(
                    id=SecurityFinding.generate_id(),
                    title="Shared Memory Without Isolation",
                    description="Agent uses shared memory which could lead to data leakage between conversations or users.",
                    severity=Severity.MEDIUM,
                    confidence=0.75,
                    owasp_category=OWASPCategory.LLM06,
                    maas_category=MAASCategory.MAAS04,
                    category=VulnerabilityCategory.DATA_LEAKAGE,
                    file_path=file_path,
                    line_number=line_number,
                    code_snippet=f"Memory scope: {memory_scope}",
                    recommendation="Implement memory isolation per user/session. Clear sensitive data after use.",
                    agent_id=agent.id,
                    cwe_id="CWE-200",
                )
            )

        return findings

    @classmethod
    def can_handle(cls, path: Path) -> bool:
        """Check if this scanner can handle LangChain projects."""
        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    content = f.read()
                    if any(
                        pattern in content
                        for pattern in [
                            "from langchain",
                            "import langchain",
                            "from langgraph",
                            "import langgraph",
                        ]
                    ):
                        return True
            except (OSError, UnicodeDecodeError):
                # Silently skip files that cannot be read during detection
                continue

        return False
