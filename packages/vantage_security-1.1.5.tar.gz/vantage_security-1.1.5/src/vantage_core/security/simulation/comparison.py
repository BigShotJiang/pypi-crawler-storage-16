"""
Multi-Scenario Comparison (US-133).

Compares different attack scenarios with side-by-side metrics
for security analysis and planning.
"""

from dataclasses import dataclass, field
from typing import Any

from vantage_core.security.simulation.propagation import (
    InfectionSimulator,
    SimulationConfig,
    SimulationResult,
)
from vantage_core.security.topology.graph import AgentGraph


@dataclass
class ScenarioResult:
    """
    Result of a single scenario simulation.

    Contains key metrics for comparison.
    """

    scenario_name: str
    entry_point: str
    blast_radius: int
    blast_percentage: float
    time_to_peak: int
    peak_infection: int
    containment_effective: bool
    total_steps: int
    infection_rate: float
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ComparisonReport:
    """
    Complete comparison of multiple scenarios.

    Contains all scenario results and comparative analysis.
    """

    scenarios: list[ScenarioResult]
    best_scenario: str  # Lowest blast radius
    worst_scenario: str  # Highest blast radius
    average_blast_radius: float
    spread_range: int  # Max - min blast radius
    comparison_matrix: dict[str, dict[str, Any]]
    recommendations: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


class ScenarioComparator:
    """
    Compares multiple attack scenarios.

    Runs simulations with different parameters and
    produces comparative analysis.
    """

    def __init__(
        self,
        base_config: SimulationConfig | None = None,
    ):
        """
        Initialize the comparator.

        Args:
            base_config: Base simulation configuration
        """
        self.base_config = base_config or SimulationConfig()

    def compare_entry_points(
        self,
        graph: AgentGraph,
        entry_points: list[str],
        scenario_names: list[str] | None = None,
    ) -> ComparisonReport:
        """
        Compare different entry points.

        Args:
            graph: Agent topology graph
            entry_points: List of entry point agent IDs
            scenario_names: Optional names for scenarios

        Returns:
            ComparisonReport with comparison
        """
        if scenario_names is None:
            scenario_names = [f"Entry: {ep}" for ep in entry_points]

        scenarios = []
        simulator = InfectionSimulator(self.base_config)

        for i, entry in enumerate(entry_points):
            name = scenario_names[i] if i < len(scenario_names) else f"Scenario {i+1}"

            try:
                result = simulator.simulate(graph, entry)
                scenario = self._result_to_scenario(name, entry, result, graph)
                scenarios.append(scenario)
            except Exception as e:
                # Create failed scenario
                scenarios.append(
                    ScenarioResult(
                        scenario_name=name,
                        entry_point=entry,
                        blast_radius=0,
                        blast_percentage=0,
                        time_to_peak=0,
                        peak_infection=0,
                        containment_effective=False,
                        total_steps=0,
                        infection_rate=0,
                        metadata={"error": str(e)},
                    )
                )

        return self._build_report(scenarios)

    def compare_containment_strategies(
        self,
        graph: AgentGraph,
        entry_point: str,
        containment_options: list[list[str]],
        scenario_names: list[str] | None = None,
    ) -> ComparisonReport:
        """
        Compare different containment strategies.

        Args:
            graph: Agent topology graph
            entry_point: Entry point for infection
            containment_options: List of containment point lists
            scenario_names: Optional names for scenarios

        Returns:
            ComparisonReport with comparison
        """
        if scenario_names is None:
            scenario_names = [
                f"Contain: {', '.join(opts)}" if opts else "No containment"
                for opts in containment_options
            ]

        scenarios = []

        for i, containment in enumerate(containment_options):
            name = scenario_names[i] if i < len(scenario_names) else f"Strategy {i+1}"

            config = SimulationConfig(
                transmission_rate=self.base_config.transmission_rate,
                containment_enabled=bool(containment),
                containment_nodes=containment,
                max_steps=self.base_config.max_steps,
            )
            simulator = InfectionSimulator(config)

            try:
                result = simulator.simulate(graph, entry_point)
                scenario = self._result_to_scenario(name, entry_point, result, graph)
                scenario.containment_effective = (
                    len(containment) > 0 and result.blast_radius < graph.node_count
                )
                scenarios.append(scenario)
            except Exception as e:
                scenarios.append(
                    ScenarioResult(
                        scenario_name=name,
                        entry_point=entry_point,
                        blast_radius=0,
                        blast_percentage=0,
                        time_to_peak=0,
                        peak_infection=0,
                        containment_effective=False,
                        total_steps=0,
                        infection_rate=0,
                        metadata={"error": str(e)},
                    )
                )

        return self._build_report(scenarios)

    def compare_transmission_rates(
        self,
        graph: AgentGraph,
        entry_point: str,
        rates: list[float],
    ) -> ComparisonReport:
        """
        Compare different transmission rates.

        Args:
            graph: Agent topology graph
            entry_point: Entry point for infection
            rates: List of transmission rates to test

        Returns:
            ComparisonReport with comparison
        """
        scenario_names = [f"Rate: {rate:.0%}" for rate in rates]
        scenarios = []

        for i, rate in enumerate(rates):
            config = SimulationConfig(
                transmission_rate=rate,
                max_steps=self.base_config.max_steps,
            )
            simulator = InfectionSimulator(config)

            try:
                result = simulator.simulate(graph, entry_point)
                scenario = self._result_to_scenario(
                    scenario_names[i],
                    entry_point,
                    result,
                    graph,
                )
                scenarios.append(scenario)
            except Exception:
                continue

        return self._build_report(scenarios)

    def _result_to_scenario(
        self,
        name: str,
        entry_point: str,
        result: SimulationResult,
        graph: AgentGraph,
    ) -> ScenarioResult:
        """Convert SimulationResult to ScenarioResult."""
        total = graph.node_count
        return ScenarioResult(
            scenario_name=name,
            entry_point=entry_point,
            blast_radius=result.blast_radius,
            blast_percentage=round(result.blast_radius / total * 100 if total else 0, 2),
            time_to_peak=result.peak_step,
            peak_infection=result.peak_infection,
            containment_effective=bool(result.containment_points),
            total_steps=result.total_steps,
            infection_rate=result.metrics.get("infection_rate", 0),
            metadata={
                "containment_points": result.containment_points,
            },
        )

    def _build_report(self, scenarios: list[ScenarioResult]) -> ComparisonReport:
        """Build comparison report from scenarios."""
        if not scenarios:
            return ComparisonReport(
                scenarios=[],
                best_scenario="",
                worst_scenario="",
                average_blast_radius=0,
                spread_range=0,
                comparison_matrix={},
            )

        # Find best and worst
        sorted_by_blast = sorted(scenarios, key=lambda s: s.blast_radius)
        best = sorted_by_blast[0].scenario_name
        worst = sorted_by_blast[-1].scenario_name

        # Calculate averages
        blasts = [s.blast_radius for s in scenarios]
        avg_blast = sum(blasts) / len(blasts)
        spread = max(blasts) - min(blasts)

        # Build comparison matrix
        matrix = {}
        for scenario in scenarios:
            matrix[scenario.scenario_name] = {
                "blast_radius": scenario.blast_radius,
                "blast_percentage": scenario.blast_percentage,
                "time_to_peak": scenario.time_to_peak,
                "peak_infection": scenario.peak_infection,
                "containment_effective": scenario.containment_effective,
                "relative_to_avg": round(scenario.blast_radius - avg_blast, 2),
            }

        # Generate recommendations
        recommendations = self._generate_recommendations(scenarios, avg_blast)

        return ComparisonReport(
            scenarios=scenarios,
            best_scenario=best,
            worst_scenario=worst,
            average_blast_radius=round(avg_blast, 2),
            spread_range=spread,
            comparison_matrix=matrix,
            recommendations=recommendations,
            metadata={
                "scenario_count": len(scenarios),
            },
        )

    def _generate_recommendations(
        self,
        scenarios: list[ScenarioResult],
        avg_blast: float,
    ) -> list[str]:
        """Generate recommendations from comparison."""
        recommendations = []

        # Check for highly variable results
        blasts = [s.blast_radius for s in scenarios]
        if len(blasts) > 1:
            variance = sum((b - avg_blast) ** 2 for b in blasts) / len(blasts)
            if variance > avg_blast:
                recommendations.append(
                    "High variance between scenarios - some entry points are much more dangerous"
                )

        # Find containment effectiveness
        with_containment = [s for s in scenarios if s.containment_effective]
        without = [s for s in scenarios if not s.containment_effective]

        if with_containment and without:
            avg_with = sum(s.blast_radius for s in with_containment) / len(with_containment)
            avg_without = sum(s.blast_radius for s in without) / len(without)
            reduction = ((avg_without - avg_with) / avg_without * 100) if avg_without > 0 else 0

            if reduction > 20:
                recommendations.append(
                    f"Containment strategies reduce blast radius by {reduction:.1f}% on average"
                )

        # Check for fast-spreading scenarios
        fast = [s for s in scenarios if s.time_to_peak <= 3]
        if fast:
            recommendations.append(
                f"{len(fast)} scenario(s) reach peak in 3 steps - add rate limiting"
            )

        # Best scenario analysis
        best = min(scenarios, key=lambda s: s.blast_radius)
        if best.blast_radius < avg_blast * 0.5:
            recommendations.append(
                f"'{best.scenario_name}' has significantly lower impact - analyze why"
            )

        return recommendations

    def to_table(self, report: ComparisonReport) -> str:
        """
        Format comparison as a text table.

        Args:
            report: ComparisonReport

        Returns:
            Formatted table string
        """
        if not report.scenarios:
            return "No scenarios to compare"

        # Headers
        headers = ["Scenario", "Blast", "%", "Peak", "Steps", "Contained"]
        rows = []

        for scenario in report.scenarios:
            row = [
                scenario.scenario_name[:20],
                str(scenario.blast_radius),
                f"{scenario.blast_percentage:.1f}%",
                str(scenario.peak_infection),
                str(scenario.total_steps),
                "Yes" if scenario.containment_effective else "No",
            ]
            rows.append(row)

        # Calculate column widths
        widths = [
            max(len(headers[i]), max(len(row[i]) for row in rows)) for i in range(len(headers))
        ]

        # Build table
        lines = []

        # Header
        header_line = " | ".join(headers[i].ljust(widths[i]) for i in range(len(headers)))
        lines.append(header_line)
        lines.append("-" * len(header_line))

        # Rows
        for row in rows:
            row_line = " | ".join(row[i].ljust(widths[i]) for i in range(len(row)))
            lines.append(row_line)

        # Summary
        lines.append("")
        lines.append(f"Best: {report.best_scenario}")
        lines.append(f"Worst: {report.worst_scenario}")
        lines.append(f"Average blast radius: {report.average_blast_radius:.1f}")

        return "\n".join(lines)


def compare_scenarios(
    graph: AgentGraph,
    entry_points: list[str],
) -> ComparisonReport:
    """
    Convenience function to compare scenarios.

    Args:
        graph: Agent topology graph
        entry_points: Entry point agent IDs

    Returns:
        ComparisonReport
    """
    comparator = ScenarioComparator()
    return comparator.compare_entry_points(graph, entry_points)
