"""
Node and Edge Feature Extraction for Topology Analysis.

US-108: Node Feature Extraction - Extract role, permissions, trust level for each agent
US-109: Edge Feature Extraction - Extract data sensitivity, frequency, direction for edges
US-110: Cross-File Topology - Handle agents defined in multiple files
US-111: Dynamic Agent Detection - Handle factory patterns, runtime agent creation
"""

import ast
import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

from vantage_core.security.models import (
    AgentCommunication,
    SecurityAgent,
    SecurityTool,
    ToolCategory,
    TrustLevel,
)
from vantage_core.security.topology.graph import AgentGraph


class DataSensitivity(str, Enum):
    """Data sensitivity levels for communications."""

    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    SECRET = "secret"


class CommunicationFrequency(str, Enum):
    """Estimated communication frequency."""

    RARE = "rare"  # < 1/hour
    OCCASIONAL = "occasional"  # 1-10/hour
    FREQUENT = "frequent"  # 10-100/hour
    CONTINUOUS = "continuous"  # > 100/hour


class CommunicationDirection(str, Enum):
    """Communication direction type."""

    UNIDIRECTIONAL = "unidirectional"
    BIDIRECTIONAL = "bidirectional"
    BROADCAST = "broadcast"


@dataclass
class NodeFeatures:
    """
    Extracted features for an agent node.

    Includes security-relevant attributes for trust analysis
    and vulnerability detection.
    """

    agent_id: str
    name: str
    role: str | None = None
    permissions: list[str] = field(default_factory=list)
    trust_level: TrustLevel = TrustLevel.INTERNAL
    trust_confidence: float = 0.5

    # Capability features
    tool_categories: list[ToolCategory] = field(default_factory=list)
    has_code_execution: bool = False
    has_file_access: bool = False
    has_network_access: bool = False
    has_database_access: bool = False

    # Behavior features
    allow_delegation: bool = False
    receives_user_input: bool = False
    has_external_output: bool = False

    # Code location
    file_path: str | None = None
    line_number: int | None = None

    # Additional metadata
    system_prompt_keywords: list[str] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)

    def to_vector(self) -> list[float]:
        """
        Convert features to a numerical vector for analysis.

        Returns:
            128-dimensional feature vector
        """
        vector = []

        # Trust level one-hot (5 values)
        for level in TrustLevel:
            vector.append(1.0 if self.trust_level == level else 0.0)

        # Boolean capabilities (6 values)
        vector.append(1.0 if self.has_code_execution else 0.0)
        vector.append(1.0 if self.has_file_access else 0.0)
        vector.append(1.0 if self.has_network_access else 0.0)
        vector.append(1.0 if self.has_database_access else 0.0)
        vector.append(1.0 if self.allow_delegation else 0.0)
        vector.append(1.0 if self.receives_user_input else 0.0)

        # Tool category counts (7 values)
        category_counts = {cat: 0 for cat in ToolCategory}
        for cat in self.tool_categories:
            category_counts[cat] += 1
        for cat in ToolCategory:
            vector.append(min(category_counts[cat] / 5.0, 1.0))  # Normalize

        # Trust confidence (1 value)
        vector.append(self.trust_confidence)

        # Pad to 128 dimensions
        while len(vector) < 128:
            vector.append(0.0)

        return vector[:128]


@dataclass
class EdgeFeatures:
    """
    Extracted features for a communication edge.

    Includes data flow and security boundary information.
    """

    source_id: str
    target_id: str

    # Data characteristics
    data_sensitivity: DataSensitivity = DataSensitivity.INTERNAL
    data_types: list[str] = field(default_factory=list)

    # Communication patterns
    frequency: CommunicationFrequency = CommunicationFrequency.OCCASIONAL
    direction: CommunicationDirection = CommunicationDirection.UNIDIRECTIONAL

    # Trust analysis
    source_trust: TrustLevel = TrustLevel.INTERNAL
    target_trust: TrustLevel = TrustLevel.INTERNAL
    trust_differential: int = 0
    crosses_boundary: bool = False

    # Risk indicators
    carries_user_input: bool = False
    carries_credentials: bool = False
    carries_pii: bool = False

    # Metadata
    communication_type: str = "direct"
    evidence: list[str] = field(default_factory=list)

    def to_vector(self) -> list[float]:
        """
        Convert features to a numerical vector for analysis.

        Returns:
            64-dimensional feature vector
        """
        vector = []

        # Data sensitivity one-hot (4 values)
        for level in DataSensitivity:
            vector.append(1.0 if self.data_sensitivity == level else 0.0)

        # Frequency one-hot (4 values)
        for freq in CommunicationFrequency:
            vector.append(1.0 if self.frequency == freq else 0.0)

        # Direction one-hot (3 values)
        for direction in CommunicationDirection:
            vector.append(1.0 if self.direction == direction else 0.0)

        # Trust differential normalized (-4 to 4 -> 0 to 1)
        vector.append((self.trust_differential + 4) / 8.0)

        # Boolean risk indicators (4 values)
        vector.append(1.0 if self.crosses_boundary else 0.0)
        vector.append(1.0 if self.carries_user_input else 0.0)
        vector.append(1.0 if self.carries_credentials else 0.0)
        vector.append(1.0 if self.carries_pii else 0.0)

        # Pad to 64 dimensions
        while len(vector) < 64:
            vector.append(0.0)

        return vector[:64]


class FeatureExtractor:
    """
    Extract security-relevant features from agents and communications.

    Analyzes code, prompts, and tool configurations to determine
    trust levels, permissions, and data sensitivity.
    """

    # Keywords indicating elevated trust requirements
    PRIVILEGED_KEYWORDS = {
        "admin",
        "root",
        "system",
        "delete",
        "modify",
        "execute",
        "database",
        "credentials",
        "secret",
        "password",
        "token",
        "api_key",
        "private",
        "internal",
        "restricted",
    }

    EXTERNAL_KEYWORDS = {
        "user",
        "customer",
        "input",
        "query",
        "request",
        "external",
        "public",
        "untrusted",
    }

    # Keywords indicating sensitive data
    SENSITIVE_DATA_KEYWORDS = {
        "password",
        "secret",
        "token",
        "key",
        "credential",
        "ssn",
        "credit_card",
        "email",
        "phone",
        "address",
        "pii",
        "confidential",
        "private",
    }

    def __init__(self):
        """Initialize the feature extractor."""
        self._import_cache: dict[str, set[str]] = {}
        self._agent_definitions: dict[str, tuple[str, int]] = {}

    def extract_node_features(self, agent: SecurityAgent) -> NodeFeatures:
        """
        Extract features from a security agent.

        Args:
            agent: SecurityAgent to analyze

        Returns:
            Extracted NodeFeatures
        """
        features = NodeFeatures(
            agent_id=agent.id,
            name=agent.name,
            role=agent.role,
            trust_level=agent.trust_level,
            file_path=agent.file_path,
            line_number=agent.line_number,
            allow_delegation=agent.allow_delegation,
        )

        # Extract tool categories and capabilities
        for tool in agent.tools:
            features.tool_categories.extend(tool.categories)

            if ToolCategory.CODE_EXECUTION in tool.categories:
                features.has_code_execution = True
            if ToolCategory.FILE_SYSTEM in tool.categories:
                features.has_file_access = True
            if (
                ToolCategory.NETWORK in tool.categories
                or ToolCategory.EXTERNAL_API in tool.categories
            ):
                features.has_network_access = True
            if ToolCategory.DATABASE in tool.categories:
                features.has_database_access = True

        # Extract permissions from tools
        features.permissions = self._extract_permissions(agent.tools)

        # Analyze system prompt for trust indicators
        if agent.system_prompt:
            keywords, trust_hints = self._analyze_prompt(agent.system_prompt)
            features.system_prompt_keywords = keywords

            # Adjust trust level based on prompt analysis
            if trust_hints.get("elevated"):
                if features.trust_level.value < TrustLevel.PRIVILEGED.value:
                    features.evidence.append(
                        f"Elevated trust indicated by keywords: {trust_hints.get('keywords', [])}"
                    )

            if trust_hints.get("external"):
                features.receives_user_input = True
                features.evidence.append("Agent receives external/user input")

        # Analyze role and goal
        if agent.role:
            features.evidence.append(f"Role: {agent.role}")
        if agent.goal:
            features.evidence.append(f"Goal: {agent.goal}")

        # Calculate trust confidence
        features.trust_confidence = self._calculate_trust_confidence(features)

        return features

    def extract_edge_features(
        self,
        comm: AgentCommunication,
        source_features: NodeFeatures,
        target_features: NodeFeatures,
    ) -> EdgeFeatures:
        """
        Extract features from a communication channel.

        Args:
            comm: AgentCommunication to analyze
            source_features: Features of source agent
            target_features: Features of target agent

        Returns:
            Extracted EdgeFeatures
        """
        # Calculate trust differential
        trust_diff = source_features.trust_level.value - target_features.trust_level.value

        # Determine if boundary is crossed
        crosses = abs(trust_diff) > 0

        features = EdgeFeatures(
            source_id=comm.source_id,
            target_id=comm.target_id,
            source_trust=source_features.trust_level,
            target_trust=target_features.trust_level,
            trust_differential=trust_diff,
            crosses_boundary=crosses,
            communication_type=comm.communication_type,
        )

        # Determine direction
        if comm.bidirectional:
            features.direction = CommunicationDirection.BIDIRECTIONAL
        elif comm.communication_type == "broadcast":
            features.direction = CommunicationDirection.BROADCAST
        else:
            features.direction = CommunicationDirection.UNIDIRECTIONAL

        # Map data sensitivity from communication metadata
        sensitivity = comm.data_sensitivity.lower()
        if sensitivity in ["secret", "restricted"]:
            features.data_sensitivity = DataSensitivity.SECRET
        elif sensitivity in ["confidential", "private"]:
            features.data_sensitivity = DataSensitivity.CONFIDENTIAL
        elif sensitivity in ["internal"]:
            features.data_sensitivity = DataSensitivity.INTERNAL
        else:
            features.data_sensitivity = DataSensitivity.PUBLIC

        # Infer data characteristics
        if source_features.receives_user_input:
            features.carries_user_input = True
            features.evidence.append("Source receives user input")

        # Check for sensitive data indicators
        if any(kw in str(comm.metadata).lower() for kw in self.SENSITIVE_DATA_KEYWORDS):
            features.carries_credentials = True
            features.evidence.append("Communication may carry sensitive data")

        # Estimate frequency based on communication type
        if comm.communication_type == "broadcast":
            features.frequency = CommunicationFrequency.FREQUENT
        elif comm.communication_type == "callback":
            features.frequency = CommunicationFrequency.OCCASIONAL
        else:
            features.frequency = CommunicationFrequency.OCCASIONAL

        return features

    def extract_graph_features(
        self, graph: AgentGraph
    ) -> tuple[dict[str, NodeFeatures], dict[str, EdgeFeatures]]:
        """
        Extract features for all nodes and edges in a graph.

        Args:
            graph: AgentGraph to analyze

        Returns:
            Tuple of (node_features_dict, edge_features_dict)
        """
        node_features: dict[str, NodeFeatures] = {}
        edge_features: dict[str, EdgeFeatures] = {}

        # First pass: extract node features
        for node in graph.nodes:
            # Create a minimal SecurityAgent for feature extraction
            agent = SecurityAgent(
                id=node.id,
                name=node.name,
                framework=node.framework,
                trust_level=node.trust_level,
                allow_delegation=node.allow_delegation,
                role=node.metadata.get("role"),
                goal=node.metadata.get("goal"),
                file_path=node.metadata.get("file_path"),
                line_number=node.metadata.get("line_number"),
            )

            features = self.extract_node_features(agent)
            features.has_code_execution = node.has_code_execution
            features.has_network_access = node.has_external_access
            node_features[node.id] = features

        # Second pass: extract edge features
        for edge in graph.edges:
            source_feat = node_features.get(edge.source_id)
            target_feat = node_features.get(edge.target_id)

            if source_feat and target_feat:
                comm = AgentCommunication(
                    source_id=edge.source_id,
                    target_id=edge.target_id,
                    communication_type=edge.communication_type.value,
                    data_sensitivity=edge.data_sensitivity,
                    bidirectional=edge.bidirectional,
                    metadata=edge.metadata,
                )

                edge_feat = self.extract_edge_features(comm, source_feat, target_feat)
                edge_key = f"{edge.source_id}->{edge.target_id}"
                edge_features[edge_key] = edge_feat

        return node_features, edge_features

    def _extract_permissions(self, tools: list[SecurityTool]) -> list[str]:
        """Extract permission strings from tools."""
        permissions = set()

        for tool in tools:
            for category in tool.categories:
                if category == ToolCategory.FILE_SYSTEM:
                    permissions.add("file:read")
                    if tool.has_side_effects:
                        permissions.add("file:write")
                elif category == ToolCategory.NETWORK:
                    permissions.add("network:connect")
                elif category == ToolCategory.CODE_EXECUTION:
                    permissions.add("code:execute")
                elif category == ToolCategory.DATABASE:
                    permissions.add("database:query")
                    if tool.has_side_effects:
                        permissions.add("database:modify")
                elif category == ToolCategory.EXTERNAL_API:
                    permissions.add("api:call")

        return sorted(permissions)

    def _analyze_prompt(self, prompt: str) -> tuple[list[str], dict[str, Any]]:
        """
        Analyze system prompt for security-relevant keywords.

        Args:
            prompt: System prompt text

        Returns:
            Tuple of (keywords_found, trust_hints)
        """
        prompt_lower = prompt.lower()
        keywords = []
        trust_hints: dict[str, Any] = {
            "elevated": False,
            "external": False,
            "keywords": [],
        }

        # Check for privileged keywords
        found_privileged = []
        for kw in self.PRIVILEGED_KEYWORDS:
            if kw in prompt_lower:
                keywords.append(kw)
                found_privileged.append(kw)

        if found_privileged:
            trust_hints["elevated"] = True
            trust_hints["keywords"] = found_privileged

        # Check for external keywords
        for kw in self.EXTERNAL_KEYWORDS:
            if kw in prompt_lower:
                keywords.append(kw)
                trust_hints["external"] = True

        return keywords, trust_hints

    def _calculate_trust_confidence(self, features: NodeFeatures) -> float:
        """
        Calculate confidence in trust level assignment.

        Higher confidence when multiple signals align.
        """
        confidence = 0.5  # Base confidence

        # More evidence increases confidence
        evidence_count = len(features.evidence)
        confidence += min(evidence_count * 0.1, 0.3)

        # Clear capability indicators increase confidence
        capability_count = sum(
            [
                features.has_code_execution,
                features.has_file_access,
                features.has_network_access,
                features.has_database_access,
            ]
        )
        if capability_count > 0:
            confidence += 0.1

        # Role and permissions increase confidence
        if features.role:
            confidence += 0.05
        if features.permissions:
            confidence += 0.05

        return min(confidence, 1.0)


class DynamicAgentDetector:
    """
    Detect dynamically created agents from factory patterns.

    US-111: Handle factory patterns, runtime agent creation,
    and track agent_factory() calls.
    """

    # Factory function patterns
    FACTORY_PATTERNS = [
        r"create_.*_agent",
        r"build_.*_agent",
        r"agent_factory",
        r"make_agent",
        r"spawn_agent",
        r"instantiate_agent",
    ]

    # Dynamic creation patterns
    DYNAMIC_PATTERNS = [
        r"Agent\s*\(",
        r"\.from_config\s*\(",
        r"\.from_dict\s*\(",
        r"getattr\s*\(",
        r"importlib\.import_module",
    ]

    def __init__(self):
        """Initialize the detector."""
        self._factory_calls: list[dict[str, Any]] = []
        self._dynamic_agents: list[dict[str, Any]] = []

    def analyze_file(self, file_path: str, source_code: str) -> list[dict[str, Any]]:
        """
        Analyze source code for dynamic agent creation patterns.

        Args:
            file_path: Path to the source file
            source_code: Source code content

        Returns:
            List of detected dynamic agent patterns
        """
        detections = []

        try:
            tree = ast.parse(source_code)
        except SyntaxError:
            return detections

        for node in ast.walk(tree):
            # Check function definitions for factory patterns
            if isinstance(node, ast.FunctionDef):
                for pattern in self.FACTORY_PATTERNS:
                    if re.match(pattern, node.name, re.IGNORECASE):
                        detections.append(
                            {
                                "type": "factory_function",
                                "name": node.name,
                                "file": file_path,
                                "line": node.lineno,
                                "pattern": pattern,
                            }
                        )
                        break

            # Check function calls for dynamic creation
            if isinstance(node, ast.Call):
                func_name = self._get_call_name(node)
                if func_name:
                    for pattern in self.DYNAMIC_PATTERNS:
                        if re.search(pattern, func_name):
                            detections.append(
                                {
                                    "type": "dynamic_creation",
                                    "name": func_name,
                                    "file": file_path,
                                    "line": node.lineno,
                                    "pattern": pattern,
                                }
                            )
                            break

        return detections

    def _get_call_name(self, node: ast.Call) -> str | None:
        """Extract function name from a Call node."""
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            parts = []
            current = node.func
            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            if isinstance(current, ast.Name):
                parts.append(current.id)
            return ".".join(reversed(parts))
        return None


class CrossFileResolver:
    """
    Resolve agent definitions across multiple files.

    US-110: Handle agents defined in multiple files,
    import resolution for connections.
    """

    def __init__(self):
        """Initialize the resolver."""
        self._imports: dict[str, dict[str, str]] = {}  # file -> {name: source}
        self._exports: dict[str, list[str]] = {}  # file -> [exported_names]
        self._agent_locations: dict[str, tuple[str, int]] = {}  # agent_id -> (file, line)

    def analyze_imports(self, file_path: str, source_code: str) -> dict[str, str]:
        """
        Analyze imports in a source file.

        Args:
            file_path: Path to the source file
            source_code: Source code content

        Returns:
            Dictionary of imported_name -> source_module
        """
        imports: dict[str, str] = {}

        try:
            tree = ast.parse(source_code)
        except SyntaxError:
            return imports

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    name = alias.asname or alias.name
                    imports[name] = alias.name

            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for alias in node.names:
                    name = alias.asname or alias.name
                    imports[name] = f"{module}.{alias.name}"

        self._imports[file_path] = imports
        return imports

    def resolve_agent_source(self, agent_id: str, file_path: str) -> str | None:
        """
        Resolve the source file for an agent reference.

        Args:
            agent_id: Agent identifier
            file_path: Current file path

        Returns:
            Source file path or None
        """
        # Check if agent is defined locally
        if agent_id in self._agent_locations:
            return self._agent_locations[agent_id][0]

        # Check imports
        file_imports = self._imports.get(file_path, {})
        if agent_id in file_imports:
            source_module = file_imports[agent_id]
            # Convert module path to file path (simplified)
            return source_module.replace(".", "/") + ".py"

        return None

    def register_agent_location(self, agent_id: str, file_path: str, line_number: int):
        """Register an agent's definition location."""
        self._agent_locations[agent_id] = (file_path, line_number)

    def get_agent_location(self, agent_id: str) -> tuple[str, int] | None:
        """Get an agent's definition location."""
        return self._agent_locations.get(agent_id)

    def build_dependency_graph(self, files: dict[str, str]) -> dict[str, list[str]]:
        """
        Build a dependency graph between files.

        Args:
            files: Dictionary of file_path -> source_code

        Returns:
            Dictionary of file_path -> [dependent_files]
        """
        dependencies: dict[str, list[str]] = {f: [] for f in files}

        for file_path, source_code in files.items():
            imports = self.analyze_imports(file_path, source_code)

            for import_source in imports.values():
                # Find matching file
                for other_file in files:
                    if self._import_matches_file(import_source, other_file):
                        if other_file not in dependencies[file_path]:
                            dependencies[file_path].append(other_file)

        return dependencies

    def _import_matches_file(self, import_source: str, file_path: str) -> bool:
        """Check if an import source matches a file path."""
        # Convert import to potential file path
        import_path = import_source.replace(".", "/")
        file_stem = Path(file_path).stem

        return file_path.endswith(import_path + ".py") or file_stem == import_source.split(".")[-1]
