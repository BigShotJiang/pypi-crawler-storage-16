"""
Agent Communication Graph Builder.

Builds directed graphs from parsed agents for security analysis,
with node and edge attributes for vulnerability detection.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from vantage_core.security.models import (
    AgentCommunication,
    SecurityAgent,
    TrustLevel,
)


class CommunicationType(str, Enum):
    """Types of agent communication."""

    DIRECT = "direct"
    BROADCAST = "broadcast"
    CALLBACK = "callback"
    SHARED_MEMORY = "shared_memory"
    DELEGATION = "delegation"
    SEQUENTIAL_HANDOFF = "sequential_handoff"
    HIERARCHICAL = "hierarchical"
    PARALLEL = "parallel"
    TOOL_CALL = "tool_call"
    HANDOFF = "handoff"


@dataclass
class GraphNode:
    """
    Represents an agent node in the communication graph.

    Includes security-relevant attributes for analysis.
    """

    id: str
    name: str
    framework: str
    trust_level: TrustLevel
    tool_count: int = 0
    has_code_execution: bool = False
    has_external_access: bool = False
    allow_delegation: bool = False
    in_degree: int = 0
    out_degree: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def is_entry_point(self) -> bool:
        """Check if node is a potential entry point."""
        return self.in_degree == 0 or self.trust_level == TrustLevel.EXTERNAL

    @property
    def is_high_risk(self) -> bool:
        """Check if node is high risk based on capabilities."""
        return self.has_code_execution or (
            self.allow_delegation and self.trust_level.value >= TrustLevel.PRIVILEGED.value
        )


@dataclass
class GraphEdge:
    """
    Represents a communication edge between agents.

    Includes attributes for security and data flow analysis.
    """

    source_id: str
    target_id: str
    communication_type: CommunicationType
    data_sensitivity: str = "internal"  # public, internal, confidential, secret
    bidirectional: bool = False
    trust_differential: int = 0  # Difference in trust levels
    weight: float = 1.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def crosses_trust_boundary(self) -> bool:
        """Check if edge crosses a trust boundary."""
        return abs(self.trust_differential) > 0

    @property
    def is_high_risk(self) -> bool:
        """Check if edge represents a high-risk communication."""
        return self.trust_differential < -1 or self.data_sensitivity in [  # Low trust to high trust
            "confidential",
            "secret",
        ]


class AgentGraph:
    """
    Directed graph of agent communications for security analysis.

    Provides graph construction, querying, and security analysis features.
    """

    def __init__(self):
        """Initialize empty graph."""
        self._nodes: dict[str, GraphNode] = {}
        self._edges: dict[str, GraphEdge] = {}
        self._adjacency: dict[str, list[str]] = {}  # node_id -> [target_ids]
        self._reverse_adjacency: dict[str, list[str]] = {}  # node_id -> [source_ids]

    def add_node(
        self,
        id: str,
        name: str,
        trust_level: TrustLevel = TrustLevel.INTERNAL,
        framework: str = "unknown",
        tool_count: int = 0,
        has_code_execution: bool = False,
        has_external_access: bool = False,
        allow_delegation: bool = False,
        is_entry_point: bool = False,
        **kwargs,
    ) -> GraphNode:
        """
        Add a node to the graph with explicit parameters.

        Args:
            id: Node identifier
            name: Node name
            trust_level: Trust level of the node
            framework: Agent framework
            tool_count: Number of tools
            has_code_execution: Whether node can execute code
            has_external_access: Whether node has external network access
            allow_delegation: Whether node can delegate
            is_entry_point: Hint that this is an entry point
            **kwargs: Additional metadata

        Returns:
            Created GraphNode
        """
        node = GraphNode(
            id=id,
            name=name,
            framework=framework,
            trust_level=trust_level,
            tool_count=tool_count,
            has_code_execution=has_code_execution,
            has_external_access=has_external_access,
            allow_delegation=allow_delegation,
            metadata=kwargs if kwargs else {},
        )

        # Override in_degree for entry points
        if is_entry_point:
            node.in_degree = 0

        self._nodes[id] = node
        self._adjacency[id] = []
        self._reverse_adjacency[id] = []

        return node

    def add_edge(
        self,
        source_id: str,
        target_id: str,
        communication_type: str | CommunicationType = "direct",
        data_sensitivity: str = "internal",
        bidirectional: bool = False,
        **kwargs,
    ) -> GraphEdge | None:
        """
        Add an edge between two nodes.

        Args:
            source_id: Source node ID
            target_id: Target node ID
            communication_type: Type of communication
            data_sensitivity: Data sensitivity level
            bidirectional: Whether edge is bidirectional
            **kwargs: Additional metadata

        Returns:
            Created GraphEdge or None if nodes don't exist
        """
        if source_id not in self._nodes or target_id not in self._nodes:
            return None

        source_node = self._nodes[source_id]
        target_node = self._nodes[target_id]

        trust_diff = source_node.trust_level.value - target_node.trust_level.value

        # Convert string to enum if needed
        if isinstance(communication_type, str):
            try:
                comm_type = CommunicationType(communication_type)
            except ValueError:
                comm_type = CommunicationType.DIRECT
        else:
            comm_type = communication_type

        edge = GraphEdge(
            source_id=source_id,
            target_id=target_id,
            communication_type=comm_type,
            data_sensitivity=data_sensitivity,
            bidirectional=bidirectional,
            trust_differential=trust_diff,
            metadata=kwargs if kwargs else {},
        )

        edge_key = f"{source_id}->{target_id}"
        self._edges[edge_key] = edge

        # Update adjacency
        if target_id not in self._adjacency[source_id]:
            self._adjacency[source_id].append(target_id)
        if source_id not in self._reverse_adjacency[target_id]:
            self._reverse_adjacency[target_id].append(source_id)

        # Update degrees
        source_node.out_degree = len(self._adjacency[source_id])
        target_node.in_degree = len(self._reverse_adjacency[target_id])

        return edge

    def add_agent(self, agent: SecurityAgent) -> GraphNode:
        """
        Add an agent as a node in the graph.

        Args:
            agent: SecurityAgent to add

        Returns:
            Created GraphNode
        """
        node = GraphNode(
            id=agent.id,
            name=agent.name,
            framework=agent.framework,
            trust_level=agent.trust_level,
            tool_count=len(agent.tools),
            has_code_execution=agent.has_code_execution,
            has_external_access=agent.has_external_access,
            allow_delegation=agent.allow_delegation,
            metadata={
                "role": agent.role,
                "goal": agent.goal,
                "file_path": agent.file_path,
                "line_number": agent.line_number,
            },
        )

        self._nodes[agent.id] = node
        self._adjacency[agent.id] = []
        self._reverse_adjacency[agent.id] = []

        return node

    def add_communication(self, comm: AgentCommunication) -> GraphEdge | None:
        """
        Add a communication channel as an edge.

        Args:
            comm: AgentCommunication to add

        Returns:
            Created GraphEdge or None if nodes don't exist
        """
        if comm.source_id not in self._nodes or comm.target_id not in self._nodes:
            return None

        source_node = self._nodes[comm.source_id]
        target_node = self._nodes[comm.target_id]

        trust_diff = source_node.trust_level.value - target_node.trust_level.value

        edge = GraphEdge(
            source_id=comm.source_id,
            target_id=comm.target_id,
            communication_type=CommunicationType(comm.communication_type),
            data_sensitivity=comm.data_sensitivity,
            bidirectional=comm.bidirectional,
            trust_differential=trust_diff,
            metadata=comm.metadata,
        )

        edge_key = f"{comm.source_id}->{comm.target_id}"
        self._edges[edge_key] = edge

        # Update adjacency
        if comm.target_id not in self._adjacency[comm.source_id]:
            self._adjacency[comm.source_id].append(comm.target_id)
        if comm.source_id not in self._reverse_adjacency[comm.target_id]:
            self._reverse_adjacency[comm.target_id].append(comm.source_id)

        # Update degrees
        source_node.out_degree = len(self._adjacency[comm.source_id])
        target_node.in_degree = len(self._reverse_adjacency[comm.target_id])

        # Add reverse edge if bidirectional
        if comm.bidirectional:
            reverse_key = f"{comm.target_id}->{comm.source_id}"
            if reverse_key not in self._edges:
                reverse_edge = GraphEdge(
                    source_id=comm.target_id,
                    target_id=comm.source_id,
                    communication_type=CommunicationType(comm.communication_type),
                    data_sensitivity=comm.data_sensitivity,
                    bidirectional=True,
                    trust_differential=-trust_diff,
                    metadata=comm.metadata,
                )
                self._edges[reverse_key] = reverse_edge

                if comm.source_id not in self._adjacency[comm.target_id]:
                    self._adjacency[comm.target_id].append(comm.source_id)
                if comm.target_id not in self._reverse_adjacency[comm.source_id]:
                    self._reverse_adjacency[comm.source_id].append(comm.target_id)

        return edge

    def get_node(self, node_id: str) -> GraphNode | None:
        """Get a node by ID."""
        return self._nodes.get(node_id)

    def get_edge(self, source_id: str, target_id: str) -> GraphEdge | None:
        """Get an edge between two nodes."""
        return self._edges.get(f"{source_id}->{target_id}")

    def get_neighbors(self, node_id: str) -> list[str]:
        """Get outgoing neighbor IDs for a node."""
        return self._adjacency.get(node_id, [])

    def get_predecessors(self, node_id: str) -> list[str]:
        """Get incoming neighbor IDs for a node."""
        return self._reverse_adjacency.get(node_id, [])

    @property
    def nodes(self) -> list[GraphNode]:
        """Get all nodes in the graph."""
        return list(self._nodes.values())

    @property
    def edges(self) -> list[GraphEdge]:
        """Get all edges in the graph."""
        return list(self._edges.values())

    @property
    def node_count(self) -> int:
        """Get number of nodes."""
        return len(self._nodes)

    @property
    def edge_count(self) -> int:
        """Get number of edges."""
        return len(self._edges)

    def get_entry_points(self) -> list[GraphNode]:
        """Get all potential entry point nodes."""
        return [n for n in self._nodes.values() if n.is_entry_point]

    def get_high_risk_nodes(self) -> list[GraphNode]:
        """Get all high-risk nodes."""
        return [n for n in self._nodes.values() if n.is_high_risk]

    def get_trust_boundary_edges(self) -> list[GraphEdge]:
        """Get all edges that cross trust boundaries."""
        return [e for e in self._edges.values() if e.crosses_trust_boundary]

    def get_high_risk_edges(self) -> list[GraphEdge]:
        """Get all high-risk edges."""
        return [e for e in self._edges.values() if e.is_high_risk]

    def find_paths(self, source_id: str, target_id: str, max_depth: int = 10) -> list[list[str]]:
        """
        Find all paths between two nodes.

        Args:
            source_id: Starting node ID
            target_id: Ending node ID
            max_depth: Maximum path length

        Returns:
            List of paths, where each path is a list of node IDs
        """
        paths = []

        def dfs(current: str, target: str, path: list[str], depth: int):
            if depth > max_depth:
                return
            if current == target:
                paths.append(path.copy())
                return

            for neighbor in self._adjacency.get(current, []):
                if neighbor not in path:  # Avoid cycles
                    path.append(neighbor)
                    dfs(neighbor, target, path, depth + 1)
                    path.pop()

        dfs(source_id, target_id, [source_id], 0)
        return paths

    def find_escalation_paths(self) -> list[list[str]]:
        """
        Find all privilege escalation paths.

        Returns:
            List of paths from low-trust to high-trust nodes
        """
        escalation_paths = []

        # Find low-trust entry points
        low_trust_nodes = [
            n for n in self._nodes.values() if n.trust_level.value <= TrustLevel.USER.value
        ]

        # Find high-trust targets
        high_trust_nodes = [
            n for n in self._nodes.values() if n.trust_level.value >= TrustLevel.PRIVILEGED.value
        ]

        for source in low_trust_nodes:
            for target in high_trust_nodes:
                paths = self.find_paths(source.id, target.id)
                escalation_paths.extend(paths)

        return escalation_paths

    def get_hub_nodes(self, threshold: int = 3) -> list[GraphNode]:
        """
        Get nodes that act as hubs (high connectivity).

        Args:
            threshold: Minimum total degree to be considered a hub

        Returns:
            List of hub nodes
        """
        return [n for n in self._nodes.values() if (n.in_degree + n.out_degree) >= threshold]

    def get_articulation_points(self) -> list[str]:
        """
        Find articulation points (nodes whose removal disconnects the graph).

        Returns:
            List of articulation point node IDs
        """
        if not self._nodes:
            return []

        visited = set()
        disc = {}
        low = {}
        parent = {}
        ap = set()
        time_counter = [0]

        def dfs(u: str):
            children = 0
            visited.add(u)
            disc[u] = low[u] = time_counter[0]
            time_counter[0] += 1

            for v in self._adjacency.get(u, []):
                if v not in visited:
                    children += 1
                    parent[v] = u
                    dfs(v)
                    low[u] = min(low[u], low[v])

                    # u is an articulation point if:
                    # 1. u is root and has two or more children
                    # 2. u is not root and low[v] >= disc[u]
                    if parent.get(u) is None and children > 1:
                        ap.add(u)
                    if parent.get(u) is not None and low[v] >= disc[u]:
                        ap.add(u)
                elif v != parent.get(u):
                    low[u] = min(low[u], disc[v])

        for node_id in self._nodes:
            if node_id not in visited:
                dfs(node_id)

        return list(ap)

    def compute_centrality(self) -> dict[str, float]:
        """
        Compute degree centrality for all nodes.

        Returns:
            Dictionary of node_id -> centrality score
        """
        if len(self._nodes) <= 1:
            return {n: 0.0 for n in self._nodes}

        max_possible = len(self._nodes) - 1
        centrality = {}

        for node_id, node in self._nodes.items():
            total_degree = node.in_degree + node.out_degree
            centrality[node_id] = total_degree / (2 * max_possible)

        return centrality

    def to_dict(self) -> dict[str, Any]:
        """
        Export graph to dictionary format.

        Returns:
            Dictionary representation of the graph
        """
        return {
            "nodes": [
                {
                    "id": n.id,
                    "name": n.name,
                    "framework": n.framework,
                    "trust_level": n.trust_level.name,
                    "tool_count": n.tool_count,
                    "has_code_execution": n.has_code_execution,
                    "has_external_access": n.has_external_access,
                    "allow_delegation": n.allow_delegation,
                    "in_degree": n.in_degree,
                    "out_degree": n.out_degree,
                }
                for n in self._nodes.values()
            ],
            "edges": [
                {
                    "source": e.source_id,
                    "target": e.target_id,
                    "type": e.communication_type.value,
                    "data_sensitivity": e.data_sensitivity,
                    "trust_differential": e.trust_differential,
                }
                for e in self._edges.values()
            ],
        }

    def to_networkx(self):
        """
        Export graph to NetworkX format.

        Returns:
            NetworkX DiGraph object

        Raises:
            ImportError if NetworkX is not installed
        """
        try:
            import networkx as nx
        except ImportError:
            raise ImportError(
                "NetworkX is required for this feature. Install with: pip install networkx"
            )

        G = nx.DiGraph()

        # Add nodes with attributes
        for node in self._nodes.values():
            G.add_node(
                node.id,
                name=node.name,
                framework=node.framework,
                trust_level=node.trust_level.value,
                tool_count=node.tool_count,
                has_code_execution=node.has_code_execution,
                has_external_access=node.has_external_access,
            )

        # Add edges with attributes
        for edge in self._edges.values():
            G.add_edge(
                edge.source_id,
                edge.target_id,
                communication_type=edge.communication_type.value,
                data_sensitivity=edge.data_sensitivity,
                trust_differential=edge.trust_differential,
                weight=edge.weight,
            )

        return G

    @classmethod
    def from_agents(
        cls,
        agents: list[SecurityAgent],
        communications: list[AgentCommunication] | None = None,
    ) -> "AgentGraph":
        """
        Build graph from lists of agents and communications.

        Args:
            agents: List of SecurityAgent objects
            communications: Optional list of AgentCommunication objects

        Returns:
            Constructed AgentGraph
        """
        graph = cls()

        for agent in agents:
            graph.add_agent(agent)

        if communications:
            for comm in communications:
                graph.add_communication(comm)

        # Infer communications from delegation settings
        for agent in agents:
            if agent.allow_delegation:
                # Can potentially communicate with all other agents
                for other in agents:
                    if other.id != agent.id:
                        comm = AgentCommunication(
                            source_id=agent.id,
                            target_id=other.id,
                            communication_type="delegation",
                            data_sensitivity="internal",
                        )
                        graph.add_communication(comm)

        return graph
