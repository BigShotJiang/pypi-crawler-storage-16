"""
Trust Level Classifier for Agents and Tools.

US-113: Trust Level Classification - Classify agents into trust levels:
external, user, internal, privileged, system.

Analyzes code patterns, system prompts, tool capabilities, and metadata
to determine appropriate trust levels with confidence scores.
"""

from dataclasses import dataclass, field

from vantage_core.security.models import (
    SecurityAgent,
    SecurityTool,
    ToolCategory,
    TrustLevel,
)


@dataclass
class ClassificationEvidence:
    """Evidence supporting a trust classification decision."""

    source: str  # Where the evidence came from (prompt, tools, role, etc.)
    signal: str  # What was detected
    weight: float  # How much this affects the classification (-1 to 1)
    details: str  # Human-readable explanation


@dataclass
class TrustClassification:
    """
    Result of trust level classification.

    Includes the assigned level, confidence score, and supporting evidence.
    """

    agent_id: str
    trust_level: TrustLevel
    confidence: float  # 0-1 scale
    evidence: list[ClassificationEvidence] = field(default_factory=list)
    suggested_level: TrustLevel | None = None  # Alternative if low confidence
    warnings: list[str] = field(default_factory=list)

    @property
    def is_high_confidence(self) -> bool:
        """Check if classification has high confidence."""
        return self.confidence >= 0.7

    @property
    def is_elevated(self) -> bool:
        """Check if trust level is elevated (privileged or system)."""
        return self.trust_level.value >= TrustLevel.PRIVILEGED.value


class TrustClassifier:
    """
    Classify trust levels for agents and tools.

    Uses multiple signals including:
    - System prompt analysis
    - Tool capability analysis
    - Role and goal keywords
    - Memory scope configuration
    """

    # Keywords indicating different trust levels
    SYSTEM_KEYWORDS = {
        "root",
        "kernel",
        "system",
        "admin",
        "superuser",
        "infrastructure",
        "core",
        "critical",
        "bootstrap",
    }

    PRIVILEGED_KEYWORDS = {
        "database",
        "credentials",
        "secret",
        "api_key",
        "password",
        "token",
        "delete",
        "modify",
        "update",
        "write",
        "execute",
        "deploy",
        "configure",
        "manage",
        "admin",
        "privileged",
    }

    INTERNAL_KEYWORDS = {
        "process",
        "transform",
        "analyze",
        "compute",
        "generate",
        "internal",
        "service",
        "worker",
        "helper",
        "assistant",
    }

    USER_KEYWORDS = {
        "user",
        "customer",
        "client",
        "input",
        "request",
        "query",
        "interact",
        "interface",
        "frontend",
    }

    EXTERNAL_KEYWORDS = {
        "external",
        "untrusted",
        "public",
        "anonymous",
        "unknown",
        "raw",
        "unvalidated",
        "third-party",
    }

    # Tool categories and their trust implications
    TOOL_TRUST_MAP = {
        ToolCategory.SYSTEM: TrustLevel.SYSTEM,
        ToolCategory.CODE_EXECUTION: TrustLevel.PRIVILEGED,
        ToolCategory.DATABASE: TrustLevel.PRIVILEGED,
        ToolCategory.FILE_SYSTEM: TrustLevel.INTERNAL,
        ToolCategory.NETWORK: TrustLevel.INTERNAL,
        ToolCategory.EXTERNAL_API: TrustLevel.INTERNAL,
        ToolCategory.MEMORY: TrustLevel.USER,
    }

    def __init__(self):
        """Initialize the classifier."""
        self._custom_rules: list[callable] = []

    def classify_agent(self, agent: SecurityAgent) -> TrustClassification:
        """
        Classify an agent's trust level.

        Analyzes multiple signals to determine the appropriate trust level
        and confidence score.

        Args:
            agent: SecurityAgent to classify

        Returns:
            TrustClassification with level, confidence, and evidence
        """
        evidence = []
        level_scores: dict[TrustLevel, float] = {level: 0.0 for level in TrustLevel}

        # Analyze system prompt
        if agent.system_prompt:
            prompt_evidence = self._analyze_prompt(agent.system_prompt)
            evidence.extend(prompt_evidence)
            for ev in prompt_evidence:
                self._apply_evidence_to_scores(ev, level_scores)

        # Analyze tools
        if agent.tools:
            tool_evidence = self._analyze_tools(agent.tools)
            evidence.extend(tool_evidence)
            for ev in tool_evidence:
                self._apply_evidence_to_scores(ev, level_scores)

        # Analyze role
        if agent.role:
            role_evidence = self._analyze_role(agent.role)
            evidence.extend(role_evidence)
            for ev in role_evidence:
                self._apply_evidence_to_scores(ev, level_scores)

        # Analyze goal
        if agent.goal:
            goal_evidence = self._analyze_goal(agent.goal)
            evidence.extend(goal_evidence)
            for ev in goal_evidence:
                self._apply_evidence_to_scores(ev, level_scores)

        # Analyze memory scope
        if agent.memory_scope:
            memory_evidence = self._analyze_memory_scope(agent.memory_scope)
            evidence.extend(memory_evidence)
            for ev in memory_evidence:
                self._apply_evidence_to_scores(ev, level_scores)

        # Analyze delegation settings
        if agent.allow_delegation:
            evidence.append(
                ClassificationEvidence(
                    source="configuration",
                    signal="allow_delegation",
                    weight=0.3,
                    details="Agent can delegate tasks, suggesting elevated trust",
                )
            )
            level_scores[TrustLevel.INTERNAL] += 0.3

        # Apply custom rules
        for rule in self._custom_rules:
            custom_evidence = rule(agent)
            if custom_evidence:
                evidence.extend(custom_evidence)
                for ev in custom_evidence:
                    self._apply_evidence_to_scores(ev, level_scores)

        # Determine final level and confidence
        trust_level, confidence = self._determine_level(level_scores)

        # Check for mismatches with existing level
        warnings = []
        if agent.trust_level != trust_level:
            warnings.append(
                f"Assigned trust level ({agent.trust_level.name}) differs from "
                f"computed level ({trust_level.name})"
            )

        # Suggest alternative if confidence is low
        suggested = None
        if confidence < 0.5:
            # Get second highest scoring level
            sorted_levels = sorted(level_scores.items(), key=lambda x: x[1], reverse=True)
            if len(sorted_levels) > 1:
                suggested = sorted_levels[1][0]

        return TrustClassification(
            agent_id=agent.id,
            trust_level=trust_level,
            confidence=confidence,
            evidence=evidence,
            suggested_level=suggested,
            warnings=warnings,
        )

    def classify_tool(self, tool: SecurityTool) -> TrustLevel:
        """
        Classify a tool's required trust level.

        Args:
            tool: SecurityTool to classify

        Returns:
            Required TrustLevel for the tool
        """
        # Start with the configured level
        max_level = tool.required_trust_level

        # Elevate based on categories
        for category in tool.categories:
            category_level = self.TOOL_TRUST_MAP.get(category, TrustLevel.INTERNAL)
            if category_level.value > max_level.value:
                max_level = category_level

        # Elevate if tool has side effects
        if tool.has_side_effects:
            if max_level.value < TrustLevel.INTERNAL.value:
                max_level = TrustLevel.INTERNAL

        # High risk tools
        if tool.risk_score >= 7.0:
            if max_level.value < TrustLevel.PRIVILEGED.value:
                max_level = TrustLevel.PRIVILEGED

        return max_level

    def add_custom_rule(self, rule: callable):
        """
        Add a custom classification rule.

        Args:
            rule: Function that takes SecurityAgent and returns list of ClassificationEvidence
        """
        self._custom_rules.append(rule)

    def _analyze_prompt(self, prompt: str) -> list[ClassificationEvidence]:
        """Analyze system prompt for trust indicators."""
        evidence = []
        prompt_lower = prompt.lower()

        # Check for system-level keywords
        found_system = [kw for kw in self.SYSTEM_KEYWORDS if kw in prompt_lower]
        if found_system:
            evidence.append(
                ClassificationEvidence(
                    source="system_prompt",
                    signal="system_keywords",
                    weight=0.9,
                    details=f"System-level keywords found: {', '.join(found_system)}",
                )
            )

        # Check for privileged keywords
        found_privileged = [kw for kw in self.PRIVILEGED_KEYWORDS if kw in prompt_lower]
        if found_privileged:
            evidence.append(
                ClassificationEvidence(
                    source="system_prompt",
                    signal="privileged_keywords",
                    weight=0.6,
                    details=f"Privileged keywords found: {', '.join(found_privileged)}",
                )
            )

        # Check for internal keywords
        found_internal = [kw for kw in self.INTERNAL_KEYWORDS if kw in prompt_lower]
        if found_internal:
            evidence.append(
                ClassificationEvidence(
                    source="system_prompt",
                    signal="internal_keywords",
                    weight=0.3,
                    details=f"Internal service keywords found: {', '.join(found_internal)}",
                )
            )

        # Check for user-facing keywords
        found_user = [kw for kw in self.USER_KEYWORDS if kw in prompt_lower]
        if found_user:
            evidence.append(
                ClassificationEvidence(
                    source="system_prompt",
                    signal="user_keywords",
                    weight=-0.2,
                    details=f"User-facing keywords found: {', '.join(found_user)}",
                )
            )

        # Check for external keywords
        found_external = [kw for kw in self.EXTERNAL_KEYWORDS if kw in prompt_lower]
        if found_external:
            evidence.append(
                ClassificationEvidence(
                    source="system_prompt",
                    signal="external_keywords",
                    weight=-0.5,
                    details=f"External/untrusted keywords found: {', '.join(found_external)}",
                )
            )

        return evidence

    def _analyze_tools(self, tools: list[SecurityTool]) -> list[ClassificationEvidence]:
        """Analyze tool capabilities for trust indicators."""
        evidence = []

        # Check for high-risk tool categories
        categories = set()
        max_risk = 0.0

        for tool in tools:
            categories.update(tool.categories)
            max_risk = max(max_risk, tool.risk_score)

        # Code execution
        if ToolCategory.CODE_EXECUTION in categories:
            evidence.append(
                ClassificationEvidence(
                    source="tools",
                    signal="code_execution",
                    weight=0.7,
                    details="Agent has code execution capabilities",
                )
            )

        # Database access
        if ToolCategory.DATABASE in categories:
            evidence.append(
                ClassificationEvidence(
                    source="tools",
                    signal="database_access",
                    weight=0.5,
                    details="Agent has database access",
                )
            )

        # System access
        if ToolCategory.SYSTEM in categories:
            evidence.append(
                ClassificationEvidence(
                    source="tools",
                    signal="system_access",
                    weight=0.9,
                    details="Agent has system-level tool access",
                )
            )

        # Network access
        if ToolCategory.NETWORK in categories or ToolCategory.EXTERNAL_API in categories:
            evidence.append(
                ClassificationEvidence(
                    source="tools",
                    signal="network_access",
                    weight=0.3,
                    details="Agent has network/API access",
                )
            )

        # Overall risk score
        if max_risk >= 7.0:
            evidence.append(
                ClassificationEvidence(
                    source="tools",
                    signal="high_risk_score",
                    weight=0.6,
                    details=f"Tools have high risk score: {max_risk}",
                )
            )

        return evidence

    def _analyze_role(self, role: str) -> list[ClassificationEvidence]:
        """Analyze agent role for trust indicators."""
        evidence = []
        role_lower = role.lower()

        # Check for admin/system roles
        if any(kw in role_lower for kw in ["admin", "system", "root", "supervisor"]):
            evidence.append(
                ClassificationEvidence(
                    source="role",
                    signal="admin_role",
                    weight=0.7,
                    details=f"Administrative role: {role}",
                )
            )

        # Check for manager roles
        if any(kw in role_lower for kw in ["manager", "coordinator", "orchestrator"]):
            evidence.append(
                ClassificationEvidence(
                    source="role",
                    signal="manager_role",
                    weight=0.4,
                    details=f"Manager/coordinator role: {role}",
                )
            )

        # Check for worker roles
        if any(kw in role_lower for kw in ["worker", "agent", "assistant", "helper"]):
            evidence.append(
                ClassificationEvidence(
                    source="role",
                    signal="worker_role",
                    weight=0.1,
                    details=f"Worker/assistant role: {role}",
                )
            )

        return evidence

    def _analyze_goal(self, goal: str) -> list[ClassificationEvidence]:
        """Analyze agent goal for trust indicators."""
        evidence = []
        goal_lower = goal.lower()

        # Check for privileged operations in goal
        privileged_ops = [
            "delete",
            "modify",
            "update",
            "execute",
            "deploy",
            "configure",
        ]
        found_ops = [op for op in privileged_ops if op in goal_lower]

        if found_ops:
            evidence.append(
                ClassificationEvidence(
                    source="goal",
                    signal="privileged_operations",
                    weight=0.5,
                    details=f"Goal includes privileged operations: {', '.join(found_ops)}",
                )
            )

        # Check for data access in goal
        if any(kw in goal_lower for kw in ["database", "credentials", "secrets", "sensitive"]):
            evidence.append(
                ClassificationEvidence(
                    source="goal",
                    signal="sensitive_data_access",
                    weight=0.4,
                    details="Goal involves sensitive data access",
                )
            )

        return evidence

    def _analyze_memory_scope(self, memory_scope: str) -> list[ClassificationEvidence]:
        """Analyze memory scope for trust indicators."""
        evidence = []
        scope_lower = memory_scope.lower()

        # Global/shared memory increases trust requirements
        if any(kw in scope_lower for kw in ["global", "shared", "system"]):
            evidence.append(
                ClassificationEvidence(
                    source="memory_scope",
                    signal="global_memory",
                    weight=0.4,
                    details=f"Agent has global/shared memory access: {memory_scope}",
                )
            )

        # Persistent memory increases trust requirements
        if any(kw in scope_lower for kw in ["persistent", "database", "store"]):
            evidence.append(
                ClassificationEvidence(
                    source="memory_scope",
                    signal="persistent_memory",
                    weight=0.3,
                    details=f"Agent has persistent memory: {memory_scope}",
                )
            )

        return evidence

    def _apply_evidence_to_scores(
        self, evidence: ClassificationEvidence, scores: dict[TrustLevel, float]
    ):
        """Apply evidence weight to trust level scores."""
        weight = evidence.weight

        if weight > 0:
            # Positive weight increases higher trust levels
            if weight >= 0.7:
                scores[TrustLevel.SYSTEM] += weight
                scores[TrustLevel.PRIVILEGED] += weight * 0.7
            elif weight >= 0.4:
                scores[TrustLevel.PRIVILEGED] += weight
                scores[TrustLevel.INTERNAL] += weight * 0.7
            else:
                scores[TrustLevel.INTERNAL] += weight
                scores[TrustLevel.USER] += weight * 0.5
        else:
            # Negative weight increases lower trust levels
            abs_weight = abs(weight)
            if abs_weight >= 0.4:
                scores[TrustLevel.EXTERNAL] += abs_weight
                scores[TrustLevel.USER] += abs_weight * 0.7
            else:
                scores[TrustLevel.USER] += abs_weight
                scores[TrustLevel.INTERNAL] += abs_weight * 0.3

    def _determine_level(self, scores: dict[TrustLevel, float]) -> tuple[TrustLevel, float]:
        """Determine trust level and confidence from scores."""
        # Get highest scoring level
        sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        best_level, best_score = sorted_scores[0]

        # Calculate confidence based on score differential
        if len(sorted_scores) > 1:
            second_score = sorted_scores[1][1]
            if best_score > 0:
                confidence = min((best_score - second_score) / best_score + 0.3, 1.0)
            else:
                confidence = 0.3  # Low confidence if no positive signals
        else:
            confidence = 0.5

        # Default to INTERNAL if no strong signals
        if best_score <= 0:
            return TrustLevel.INTERNAL, 0.3

        return best_level, confidence


def classify_agents(agents: list[SecurityAgent]) -> dict[str, TrustClassification]:
    """
    Convenience function to classify multiple agents.

    Args:
        agents: List of SecurityAgent objects

    Returns:
        Dictionary of agent_id -> TrustClassification
    """
    classifier = TrustClassifier()
    return {agent.id: classifier.classify_agent(agent) for agent in agents}
