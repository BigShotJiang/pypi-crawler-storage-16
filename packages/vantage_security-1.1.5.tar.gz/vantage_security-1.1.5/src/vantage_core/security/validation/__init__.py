"""
Security Validation Module for Vantage.

Provides validators for securing AI agent operations:
- SQL query validation for NL-to-SQL systems
- Pandas query sanitization
- File type filtering for directory readers

Example usage:
    from vantage_core.security.validation import (
        SQLValidator,
        PandasQueryValidator,
        FileValidator,
    )

    # Validate SQL from LLM
    sql_validator = SQLValidator()
    result = sql_validator.validate(llm_generated_sql)
    if not result.is_valid:
        raise ValueError(f"Invalid SQL: {result.errors}")

    # Validate Pandas query
    pandas_validator = PandasQueryValidator()
    result = pandas_validator.validate(user_query)

    # Validate files before loading
    file_validator = FileValidator()
    safe_files = file_validator.get_safe_files("/path/to/docs")
"""

from vantage_core.security.validation.file_validator import (
    BlockedExtensionError,
    ContentTypeMismatchError,
    DocumentFileValidator,
    FileCategory,
    FileSizeError,
    FileValidationConfig,
    FileValidationError,
    FileValidationResult,
    FileValidator,
    PathTraversalError,
    StrictFileValidator,
    validate_file,
)
from vantage_core.security.validation.pandas_validator import (
    DangerousExpressionError,
    PandasQueryValidator,
    PandasValidationConfig,
    PandasValidationError,
    PandasValidationResult,
    SafeDataFrameFilter,
    UnsupportedOperationError,
    validate_pandas_query,
)
from vantage_core.security.validation.sql_validator import (
    BlockedFunctionError,
    ComplexityError,
    DangerousStatementError,
    ReadOnlySQLValidator,
    RestrictedSQLValidator,
    SchemaViolationError,
    SQLStatementType,
    SQLValidationConfig,
    SQLValidationError,
    SQLValidator,
    validate_sql,
)
from vantage_core.security.validation.sql_validator import (
    ValidationResult as SQLValidationResult,
)

__all__ = [
    # SQL Validation
    "SQLValidator",
    "SQLValidationConfig",
    "SQLValidationError",
    "SQLStatementType",
    "SQLValidationResult",
    "ReadOnlySQLValidator",
    "RestrictedSQLValidator",
    "validate_sql",
    "DangerousStatementError",
    "BlockedFunctionError",
    "SchemaViolationError",
    "ComplexityError",
    # Pandas Validation
    "PandasQueryValidator",
    "PandasValidationConfig",
    "PandasValidationError",
    "PandasValidationResult",
    "SafeDataFrameFilter",
    "validate_pandas_query",
    "DangerousExpressionError",
    "UnsupportedOperationError",
    # File Validation
    "FileValidator",
    "FileValidationConfig",
    "FileValidationError",
    "FileValidationResult",
    "FileCategory",
    "DocumentFileValidator",
    "StrictFileValidator",
    "validate_file",
    "BlockedExtensionError",
    "PathTraversalError",
    "FileSizeError",
    "ContentTypeMismatchError",
]
