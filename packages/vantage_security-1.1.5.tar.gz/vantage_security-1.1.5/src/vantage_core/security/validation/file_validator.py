"""
File Type Validation for Directory Readers.

Provides security validation for file loading operations
to prevent loading of dangerous file types and path traversal.

Key features:
- Extension allowlist/blocklist
- Magic number validation (file content type detection)
- Path traversal prevention
- Size limits

This is designed to secure document loaders like LlamaIndex's
SimpleDirectoryReader and LangChain's DirectoryLoader.
"""

import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class FileValidationError(Exception):
    """Error during file validation."""

    pass


class BlockedExtensionError(FileValidationError):
    """File has a blocked extension."""

    pass


class PathTraversalError(FileValidationError):
    """Potential path traversal attack detected."""

    pass


class FileSizeError(FileValidationError):
    """File exceeds size limit."""

    pass


class ContentTypeMismatchError(FileValidationError):
    """File content doesn't match extension."""

    pass


class FileCategory(str, Enum):
    """Categories of file types."""

    DOCUMENT = "document"
    IMAGE = "image"
    CODE = "code"
    DATA = "data"
    ARCHIVE = "archive"
    EXECUTABLE = "executable"
    SCRIPT = "script"
    CONFIG = "config"
    UNKNOWN = "unknown"


# Magic numbers (file signatures) for common file types
MAGIC_NUMBERS: dict[bytes, tuple[str, FileCategory]] = {
    # Documents
    b"%PDF": ("pdf", FileCategory.DOCUMENT),
    b"PK\x03\x04": ("docx/xlsx/pptx/zip", FileCategory.DOCUMENT),  # ZIP-based formats
    b"\xd0\xcf\x11\xe0": ("doc/xls/ppt", FileCategory.DOCUMENT),  # OLE compound
    b"{\rtf": ("rtf", FileCategory.DOCUMENT),
    # Images
    b"\xff\xd8\xff": ("jpg", FileCategory.IMAGE),
    b"\x89PNG": ("png", FileCategory.IMAGE),
    b"GIF87a": ("gif", FileCategory.IMAGE),
    b"GIF89a": ("gif", FileCategory.IMAGE),
    b"BM": ("bmp", FileCategory.IMAGE),
    b"RIFF": ("webp", FileCategory.IMAGE),
    # Archives
    b"\x1f\x8b": ("gzip", FileCategory.ARCHIVE),
    b"BZh": ("bzip2", FileCategory.ARCHIVE),
    b"Rar!": ("rar", FileCategory.ARCHIVE),
    b"\xfd7zXZ": ("xz", FileCategory.ARCHIVE),
    # Executables - DANGEROUS
    b"MZ": ("exe/dll", FileCategory.EXECUTABLE),
    b"\x7fELF": ("elf", FileCategory.EXECUTABLE),
    b"\xca\xfe\xba\xbe": ("macho", FileCategory.EXECUTABLE),
    b"\xfe\xed\xfa\xce": ("macho", FileCategory.EXECUTABLE),
    # Scripts - DANGEROUS
    b"#!": ("script", FileCategory.SCRIPT),
    b"<?php": ("php", FileCategory.SCRIPT),
    b"<script": ("html/js", FileCategory.SCRIPT),
}


@dataclass
class FileValidationConfig:
    """Configuration for file validation."""

    # Allowed file extensions (lowercase, with dot)
    allowed_extensions: set[str] = field(
        default_factory=lambda: {
            # Documents
            ".txt",
            ".pdf",
            ".doc",
            ".docx",
            ".rtf",
            ".md",
            ".markdown",
            ".rst",
            # Data files
            ".csv",
            ".json",
            ".xml",
            ".yaml",
            ".yml",
            # Common document formats
            ".html",
            ".htm",
        }
    )

    # Blocked extensions (takes precedence over allowed)
    blocked_extensions: set[str] = field(
        default_factory=lambda: {
            # Executables
            ".exe",
            ".dll",
            ".so",
            ".dylib",
            ".bin",
            ".com",
            ".bat",
            ".cmd",
            ".msi",
            ".app",
            # Scripts
            ".sh",
            ".bash",
            ".zsh",
            ".ps1",
            ".psm1",
            ".py",
            ".pyw",
            ".rb",
            ".pl",
            ".php",
            ".js",
            ".vbs",
            ".vbe",
            ".wsf",
            ".wsh",
            # Archives (potential zip bombs, embedded malware)
            ".zip",
            ".rar",
            ".7z",
            ".tar",
            ".gz",
            ".bz2",
            # Other dangerous
            ".jar",
            ".war",
            ".ear",
            ".class",
            ".apk",
            ".ipa",
            ".deb",
            ".rpm",
        }
    )

    # Blocked file categories
    blocked_categories: set[FileCategory] = field(
        default_factory=lambda: {
            FileCategory.EXECUTABLE,
            FileCategory.SCRIPT,
            FileCategory.ARCHIVE,
        }
    )

    # Maximum file size in bytes (default: 50MB)
    max_file_size: int = 50 * 1024 * 1024

    # Maximum total size for all files (default: 500MB)
    max_total_size: int = 500 * 1024 * 1024

    # Validate magic numbers (file content)
    validate_magic_numbers: bool = True

    # Require extension to match content type
    require_content_match: bool = False

    # Allow hidden files (starting with .)
    allow_hidden_files: bool = False

    # Allow symlinks
    allow_symlinks: bool = False

    # Blocked filename patterns
    blocked_patterns: list[str] = field(
        default_factory=lambda: [
            r"\.\./",  # Path traversal
            r"\.\.\\",  # Windows path traversal
            r"~/",  # Home directory
            r"\$\(",  # Shell expansion
            r"`",  # Backtick execution
            r"\|",  # Pipe
            r";",  # Command separator
            r"<|>",  # Redirection
        ]
    )


@dataclass
class FileValidationResult:
    """Result of file validation."""

    is_valid: bool
    file_path: str
    file_size: int = 0
    extension: str = ""
    detected_type: str = ""
    category: FileCategory = FileCategory.UNKNOWN
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


class FileValidator:
    """
    Validate files for secure loading.

    Example:
        validator = FileValidator()
        result = validator.validate("/path/to/document.pdf")
        if not result.is_valid:
            raise ValueError(f"Invalid file: {result.errors}")

    For directory validation:
        safe_files = validator.validate_directory("/path/to/docs")
    """

    def __init__(self, config: FileValidationConfig | None = None):
        """
        Initialize validator.

        Args:
            config: Validation configuration
        """
        self.config = config or FileValidationConfig()
        self._compile_patterns()

    def _compile_patterns(self):
        """Compile blocked patterns."""
        self._blocked_patterns = [re.compile(p) for p in self.config.blocked_patterns]

    def validate(self, file_path: str) -> FileValidationResult:
        """
        Validate a single file.

        Args:
            file_path: Path to file to validate

        Returns:
            FileValidationResult with validation status
        """
        result = FileValidationResult(
            is_valid=True,
            file_path=file_path,
        )

        path = Path(file_path)

        # Check for blocked patterns in path
        for pattern in self._blocked_patterns:
            if pattern.search(str(file_path)):
                result.errors.append(f"Blocked path pattern: {pattern.pattern}")
                result.is_valid = False

        # Check for path traversal
        try:
            resolved = path.resolve()
            # Ensure the resolved path doesn't escape expected directory
            # This is a basic check; caller should verify against base directory
        except (OSError, ValueError) as e:
            result.errors.append(f"Path resolution error: {e}")
            result.is_valid = False
            return result

        # Check if file exists
        if not path.exists():
            result.errors.append("File does not exist")
            result.is_valid = False
            return result

        # Check for symlinks
        if path.is_symlink() and not self.config.allow_symlinks:
            result.errors.append("Symlinks not allowed")
            result.is_valid = False

        # Check for hidden files
        if path.name.startswith(".") and not self.config.allow_hidden_files:
            result.errors.append("Hidden files not allowed")
            result.is_valid = False

        # Get extension
        result.extension = path.suffix.lower()

        # Check blocked extensions (highest priority)
        if result.extension in self.config.blocked_extensions:
            result.errors.append(f"Blocked extension: {result.extension}")
            result.is_valid = False

        # Check allowed extensions
        if self.config.allowed_extensions:
            if result.extension not in self.config.allowed_extensions:
                result.errors.append(
                    f"Extension {result.extension} not in allowed list: "
                    f"{sorted(self.config.allowed_extensions)}"
                )
                result.is_valid = False

        # Check file size
        try:
            result.file_size = path.stat().st_size
            if result.file_size > self.config.max_file_size:
                result.errors.append(
                    f"File size ({result.file_size}) exceeds limit ({self.config.max_file_size})"
                )
                result.is_valid = False
        except OSError as e:
            result.errors.append(f"Cannot read file stats: {e}")
            result.is_valid = False

        # Validate magic numbers
        if self.config.validate_magic_numbers and result.is_valid:
            try:
                detected = self._detect_file_type(path)
                if detected:
                    result.detected_type, result.category = detected

                    # Check if category is blocked
                    if result.category in self.config.blocked_categories:
                        result.errors.append(f"Blocked file category: {result.category.value}")
                        result.is_valid = False
            except Exception as e:
                result.warnings.append(f"Could not detect file type: {e}")

        return result

    def validate_or_raise(self, file_path: str) -> str:
        """
        Validate file and return path, or raise exception.

        Args:
            file_path: Path to validate

        Returns:
            The validated path

        Raises:
            FileValidationError: If validation fails
        """
        result = self.validate(file_path)
        if not result.is_valid:
            raise FileValidationError("; ".join(result.errors))
        return file_path

    def validate_directory(
        self,
        directory: str,
        recursive: bool = True,
        base_path: str | None = None,
    ) -> list[FileValidationResult]:
        """
        Validate all files in a directory.

        Args:
            directory: Directory to scan
            recursive: Whether to scan recursively
            base_path: Base path for traversal checking

        Returns:
            List of validation results for all files
        """
        results = []
        dir_path = Path(directory)
        base = Path(base_path) if base_path else dir_path

        if not dir_path.exists():
            return [
                FileValidationResult(
                    is_valid=False,
                    file_path=str(dir_path),
                    errors=["Directory does not exist"],
                )
            ]

        if not dir_path.is_dir():
            return [
                FileValidationResult(
                    is_valid=False,
                    file_path=str(dir_path),
                    errors=["Path is not a directory"],
                )
            ]

        total_size = 0

        if recursive:
            files = dir_path.rglob("*")
        else:
            files = dir_path.glob("*")

        for file_path in files:
            if not file_path.is_file():
                continue

            # Check for path traversal
            try:
                resolved = file_path.resolve()
                if not str(resolved).startswith(str(base.resolve())):
                    results.append(
                        FileValidationResult(
                            is_valid=False,
                            file_path=str(file_path),
                            errors=["Path traversal detected"],
                        )
                    )
                    continue
            except (OSError, ValueError):
                continue

            result = self.validate(str(file_path))
            results.append(result)

            if result.is_valid:
                total_size += result.file_size

        # Check total size
        if total_size > self.config.max_total_size:
            # Mark last valid file as invalid due to total size
            for result in reversed(results):
                if result.is_valid:
                    result.warnings.append(
                        f"Total directory size ({total_size}) exceeds limit ({self.config.max_total_size})"
                    )
                    break

        return results

    def get_safe_files(
        self,
        directory: str,
        recursive: bool = True,
    ) -> list[str]:
        """
        Get list of safe files from directory.

        Args:
            directory: Directory to scan
            recursive: Whether to scan recursively

        Returns:
            List of validated file paths
        """
        results = self.validate_directory(directory, recursive)
        return [r.file_path for r in results if r.is_valid]

    def _detect_file_type(self, path: Path) -> tuple[str, FileCategory] | None:
        """
        Detect file type from magic numbers.

        Args:
            path: Path to file

        Returns:
            Tuple of (type_name, category) or None
        """
        try:
            with open(path, "rb") as f:
                header = f.read(16)  # Read first 16 bytes

            for magic, (type_name, category) in MAGIC_NUMBERS.items():
                if header.startswith(magic):
                    return (type_name, category)

            return None
        except Exception:
            return None


def validate_file(
    file_path: str,
    allowed_extensions: set[str] | None = None,
    max_size: int | None = None,
) -> FileValidationResult:
    """
    Convenience function to validate a file.

    Args:
        file_path: Path to file
        allowed_extensions: Optional set of allowed extensions
        max_size: Optional maximum file size

    Returns:
        FileValidationResult
    """
    config = FileValidationConfig()
    if allowed_extensions:
        config.allowed_extensions = allowed_extensions
    if max_size:
        config.max_file_size = max_size

    validator = FileValidator(config)
    return validator.validate(file_path)


# Pre-configured validators for common use cases
class DocumentFileValidator(FileValidator):
    """Validator for document files only."""

    def __init__(self):
        config = FileValidationConfig(
            allowed_extensions={
                ".txt",
                ".pdf",
                ".doc",
                ".docx",
                ".rtf",
                ".md",
                ".markdown",
                ".rst",
                ".html",
                ".htm",
                ".csv",
                ".json",
                ".xml",
                ".yaml",
                ".yml",
            },
            max_file_size=100 * 1024 * 1024,  # 100MB
        )
        super().__init__(config)


class StrictFileValidator(FileValidator):
    """
    Very strict validator - only plain text files.

    Use this when security is paramount.
    """

    def __init__(self):
        config = FileValidationConfig(
            allowed_extensions={".txt", ".md", ".csv", ".json"},
            blocked_categories={
                FileCategory.EXECUTABLE,
                FileCategory.SCRIPT,
                FileCategory.ARCHIVE,
                FileCategory.IMAGE,
            },
            max_file_size=10 * 1024 * 1024,  # 10MB
            validate_magic_numbers=True,
            allow_hidden_files=False,
            allow_symlinks=False,
        )
        super().__init__(config)
