"""
Provider-specific secret verifiers.

Each verifier implements the verification logic for a specific provider
(AWS, GitHub, Slack, etc.) using their respective APIs.
"""

import logging
import re
import time

import httpx

from .verifier import (
    ProviderVerifier,
    VerificationResult,
    VerificationStatus,
)

logger = logging.getLogger(__name__)


class AWSVerifier(ProviderVerifier):
    """
    Verify AWS credentials using STS GetCallerIdentity.

    This is the gold standard for AWS credential verification:
    - Requires no permissions (cannot be denied by IAM)
    - Read-only, no side effects
    - Returns account ID and ARN
    """

    @property
    def provider_name(self) -> str:
        return "aws"

    @property
    def supported_patterns(self) -> list[str]:
        return [
            r"^AKIA[0-9A-Z]{16}$",  # Access Key ID
            r"^ASIA[0-9A-Z]{16}$",  # Temporary Access Key ID
        ]

    async def verify(self, secret: str) -> VerificationResult:
        """
        Verify AWS access key using STS GetCallerIdentity.

        Note: This requires both access key ID and secret access key.
        For standalone access key ID, we can only validate format.
        """
        secret_hash = self.hash_secret(secret)
        start_time = time.time()

        # If only access key ID, we can't fully verify without secret
        if re.match(r"^A[KS]IA[0-9A-Z]{16}$", secret):
            latency_ms = (time.time() - start_time) * 1000
            return VerificationResult(
                status=VerificationStatus.UNKNOWN,
                provider=self.provider_name,
                secret_type="aws_access_key_id",
                secret_hash=secret_hash,
                verified_at=time.time(),
                latency_ms=latency_ms,
                error="Cannot verify access key ID without secret access key",
                metadata={"format_valid": True},
            )

        # For full credential pair, use boto3/STS
        # This is a simplified implementation
        latency_ms = (time.time() - start_time) * 1000
        return VerificationResult(
            status=VerificationStatus.UNSUPPORTED,
            provider=self.provider_name,
            secret_type="aws_credential",
            secret_hash=secret_hash,
            verified_at=time.time(),
            latency_ms=latency_ms,
            error="Full AWS verification requires access key pair",
        )

    def _detect_secret_type(self, secret: str) -> str:
        if secret.startswith("AKIA"):
            return "aws_access_key_id"
        if secret.startswith("ASIA"):
            return "aws_temporary_access_key_id"
        return "aws_credential"


class GitHubVerifier(ProviderVerifier):
    """
    Verify GitHub tokens using the /user endpoint.

    Supports all GitHub token types:
    - Personal Access Tokens (ghp_)
    - OAuth App Tokens (gho_)
    - GitHub App User Tokens (ghu_)
    - GitHub App Installation Tokens (ghs_)
    """

    API_URL = "https://api.github.com/user"

    @property
    def provider_name(self) -> str:
        return "github"

    @property
    def supported_patterns(self) -> list[str]:
        return [
            r"^ghp_[A-Za-z0-9]{36}$",  # Personal Access Token
            r"^gho_[A-Za-z0-9]{36}$",  # OAuth App Token
            r"^ghu_[A-Za-z0-9]{36}$",  # GitHub App User Token
            r"^ghs_[A-Za-z0-9]{36}$",  # GitHub App Installation Token
            r"^ghr_[A-Za-z0-9]{36}$",  # GitHub App Refresh Token
            r"^github_pat_[A-Za-z0-9_]{22,}$",  # Fine-grained PAT
        ]

    async def verify(self, secret: str) -> VerificationResult:
        """Verify GitHub token by calling /user endpoint."""
        secret_hash = self.hash_secret(secret)
        start_time = time.time()

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    self.API_URL,
                    headers={
                        "Authorization": f"Bearer {secret}",
                        "Accept": "application/vnd.github+json",
                        "X-GitHub-Api-Version": "2022-11-28",
                    },
                    timeout=self.timeout,
                )

            latency_ms = (time.time() - start_time) * 1000

            if response.status_code == 200:
                data = response.json()
                return VerificationResult(
                    status=VerificationStatus.VERIFIED,
                    provider=self.provider_name,
                    secret_type=self._detect_secret_type(secret),
                    secret_hash=secret_hash,
                    verified_at=time.time(),
                    latency_ms=latency_ms,
                    account_info={
                        "login": data.get("login"),
                        "id": data.get("id"),
                        "type": data.get("type"),
                    },
                )

            if response.status_code == 401:
                return VerificationResult(
                    status=VerificationStatus.INVALID,
                    provider=self.provider_name,
                    secret_type=self._detect_secret_type(secret),
                    secret_hash=secret_hash,
                    verified_at=time.time(),
                    latency_ms=latency_ms,
                    error="Invalid or expired token",
                )

            if response.status_code == 403:
                # Valid token but rate limited or insufficient permissions
                return VerificationResult(
                    status=VerificationStatus.VERIFIED,
                    provider=self.provider_name,
                    secret_type=self._detect_secret_type(secret),
                    secret_hash=secret_hash,
                    verified_at=time.time(),
                    latency_ms=latency_ms,
                    metadata={"rate_limited": True},
                )

            return VerificationResult(
                status=VerificationStatus.UNKNOWN,
                provider=self.provider_name,
                secret_type=self._detect_secret_type(secret),
                secret_hash=secret_hash,
                verified_at=time.time(),
                latency_ms=latency_ms,
                error=f"Unexpected status: {response.status_code}",
            )

        except httpx.RequestError as e:
            latency_ms = (time.time() - start_time) * 1000
            return VerificationResult(
                status=VerificationStatus.UNKNOWN,
                provider=self.provider_name,
                secret_type=self._detect_secret_type(secret),
                secret_hash=secret_hash,
                verified_at=time.time(),
                latency_ms=latency_ms,
                error=str(e),
            )

    def _detect_secret_type(self, secret: str) -> str:
        if secret.startswith("ghp_"):
            return "github_personal_access_token"
        if secret.startswith("gho_"):
            return "github_oauth_token"
        if secret.startswith("ghu_"):
            return "github_app_user_token"
        if secret.startswith("ghs_"):
            return "github_app_installation_token"
        if secret.startswith("ghr_"):
            return "github_app_refresh_token"
        if secret.startswith("github_pat_"):
            return "github_fine_grained_pat"
        return "github_token"


class SlackVerifier(ProviderVerifier):
    """
    Verify Slack tokens using auth.test endpoint.

    Supports:
    - Bot tokens (xoxb-)
    - User tokens (xoxp-)
    - App tokens (xapp-)
    """

    API_URL = "https://slack.com/api/auth.test"

    @property
    def provider_name(self) -> str:
        return "slack"

    @property
    def supported_patterns(self) -> list[str]:
        return [
            r"^xoxb-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24}$",  # Bot token
            r"^xoxp-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24}$",  # User token
            r"^xapp-[0-9]+-[A-Za-z0-9]+-[0-9]+-[a-f0-9]+$",  # App token
            r"^xoxb-[0-9]+-[A-Za-z0-9]+$",  # Simplified bot
            r"^xoxp-[0-9]+-[A-Za-z0-9]+$",  # Simplified user
        ]

    async def verify(self, secret: str) -> VerificationResult:
        """Verify Slack token using auth.test."""
        secret_hash = self.hash_secret(secret)
        start_time = time.time()

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self.API_URL,
                    headers={"Authorization": f"Bearer {secret}"},
                    timeout=self.timeout,
                )

            latency_ms = (time.time() - start_time) * 1000
            data = response.json()

            if data.get("ok"):
                return VerificationResult(
                    status=VerificationStatus.VERIFIED,
                    provider=self.provider_name,
                    secret_type=self._detect_secret_type(secret),
                    secret_hash=secret_hash,
                    verified_at=time.time(),
                    latency_ms=latency_ms,
                    account_info={
                        "team": data.get("team"),
                        "team_id": data.get("team_id"),
                        "user": data.get("user"),
                        "user_id": data.get("user_id"),
                        "bot_id": data.get("bot_id"),
                    },
                )

            error = data.get("error", "Unknown error")
            if error in ("invalid_auth", "account_inactive", "token_revoked"):
                return VerificationResult(
                    status=VerificationStatus.INVALID,
                    provider=self.provider_name,
                    secret_type=self._detect_secret_type(secret),
                    secret_hash=secret_hash,
                    verified_at=time.time(),
                    latency_ms=latency_ms,
                    error=error,
                )

            return VerificationResult(
                status=VerificationStatus.UNKNOWN,
                provider=self.provider_name,
                secret_type=self._detect_secret_type(secret),
                secret_hash=secret_hash,
                verified_at=time.time(),
                latency_ms=latency_ms,
                error=error,
            )

        except httpx.RequestError as e:
            latency_ms = (time.time() - start_time) * 1000
            return VerificationResult(
                status=VerificationStatus.UNKNOWN,
                provider=self.provider_name,
                secret_type=self._detect_secret_type(secret),
                secret_hash=secret_hash,
                verified_at=time.time(),
                latency_ms=latency_ms,
                error=str(e),
            )

    def _detect_secret_type(self, secret: str) -> str:
        if secret.startswith("xoxb-"):
            return "slack_bot_token"
        if secret.startswith("xoxp-"):
            return "slack_user_token"
        if secret.startswith("xapp-"):
            return "slack_app_token"
        return "slack_token"


class StripeVerifier(ProviderVerifier):
    """
    Verify Stripe API keys using /v1/balance endpoint.

    Supports:
    - Live secret keys (sk_live_)
    - Test secret keys (sk_test_)
    - Restricted keys (rk_live_, rk_test_)
    """

    API_URL = "https://api.stripe.com/v1/balance"

    @property
    def provider_name(self) -> str:
        return "stripe"

    @property
    def supported_patterns(self) -> list[str]:
        return [
            r"^sk_live_[A-Za-z0-9]{24,}$",  # Live secret key
            r"^sk_test_[A-Za-z0-9]{24,}$",  # Test secret key
            r"^rk_live_[A-Za-z0-9]{24,}$",  # Live restricted key
            r"^rk_test_[A-Za-z0-9]{24,}$",  # Test restricted key
        ]

    async def verify(self, secret: str) -> VerificationResult:
        """Verify Stripe key using /v1/balance."""
        secret_hash = self.hash_secret(secret)
        start_time = time.time()

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    self.API_URL,
                    auth=(secret, ""),
                    timeout=self.timeout,
                )

            latency_ms = (time.time() - start_time) * 1000

            if response.status_code == 200:
                data = response.json()
                return VerificationResult(
                    status=VerificationStatus.VERIFIED,
                    provider=self.provider_name,
                    secret_type=self._detect_secret_type(secret),
                    secret_hash=secret_hash,
                    verified_at=time.time(),
                    latency_ms=latency_ms,
                    metadata={
                        "livemode": data.get("livemode"),
                        "object": data.get("object"),
                    },
                )

            if response.status_code == 401:
                return VerificationResult(
                    status=VerificationStatus.INVALID,
                    provider=self.provider_name,
                    secret_type=self._detect_secret_type(secret),
                    secret_hash=secret_hash,
                    verified_at=time.time(),
                    latency_ms=latency_ms,
                    error="Invalid API key",
                )

            return VerificationResult(
                status=VerificationStatus.UNKNOWN,
                provider=self.provider_name,
                secret_type=self._detect_secret_type(secret),
                secret_hash=secret_hash,
                verified_at=time.time(),
                latency_ms=latency_ms,
                error=f"Unexpected status: {response.status_code}",
            )

        except httpx.RequestError as e:
            latency_ms = (time.time() - start_time) * 1000
            return VerificationResult(
                status=VerificationStatus.UNKNOWN,
                provider=self.provider_name,
                secret_type=self._detect_secret_type(secret),
                secret_hash=secret_hash,
                verified_at=time.time(),
                latency_ms=latency_ms,
                error=str(e),
            )

    def _detect_secret_type(self, secret: str) -> str:
        if secret.startswith("sk_live_"):
            return "stripe_live_secret_key"
        if secret.startswith("sk_test_"):
            return "stripe_test_secret_key"
        if secret.startswith("rk_live_"):
            return "stripe_live_restricted_key"
        if secret.startswith("rk_test_"):
            return "stripe_test_restricted_key"
        return "stripe_key"


class OpenAIVerifier(ProviderVerifier):
    """
    Verify OpenAI API keys using /v1/models endpoint.
    """

    API_URL = "https://api.openai.com/v1/models"

    @property
    def provider_name(self) -> str:
        return "openai"

    @property
    def supported_patterns(self) -> list[str]:
        return [
            r"^sk-[A-Za-z0-9]{48}$",  # Standard API key
            r"^sk-proj-[A-Za-z0-9]{48,}$",  # Project API key
        ]

    async def verify(self, secret: str) -> VerificationResult:
        """Verify OpenAI key using /v1/models."""
        secret_hash = self.hash_secret(secret)
        start_time = time.time()

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    self.API_URL,
                    headers={
                        "Authorization": f"Bearer {secret}",
                    },
                    timeout=self.timeout,
                )

            latency_ms = (time.time() - start_time) * 1000

            if response.status_code == 200:
                return VerificationResult(
                    status=VerificationStatus.VERIFIED,
                    provider=self.provider_name,
                    secret_type="openai_api_key",
                    secret_hash=secret_hash,
                    verified_at=time.time(),
                    latency_ms=latency_ms,
                )

            if response.status_code == 401:
                return VerificationResult(
                    status=VerificationStatus.INVALID,
                    provider=self.provider_name,
                    secret_type="openai_api_key",
                    secret_hash=secret_hash,
                    verified_at=time.time(),
                    latency_ms=latency_ms,
                    error="Invalid API key",
                )

            return VerificationResult(
                status=VerificationStatus.UNKNOWN,
                provider=self.provider_name,
                secret_type="openai_api_key",
                secret_hash=secret_hash,
                verified_at=time.time(),
                latency_ms=latency_ms,
                error=f"Unexpected status: {response.status_code}",
            )

        except httpx.RequestError as e:
            latency_ms = (time.time() - start_time) * 1000
            return VerificationResult(
                status=VerificationStatus.UNKNOWN,
                provider=self.provider_name,
                secret_type="openai_api_key",
                secret_hash=secret_hash,
                verified_at=time.time(),
                latency_ms=latency_ms,
                error=str(e),
            )

    def _detect_secret_type(self, secret: str) -> str:
        return "openai_api_key"


class GenericVerifier(ProviderVerifier):
    """
    Generic verifier for custom/internal secrets.

    Uses a configurable webhook endpoint for verification.
    """

    def __init__(
        self,
        endpoint: str,
        patterns: list[str],
        provider: str = "custom",
        **kwargs,
    ):
        super().__init__(**kwargs)
        self._endpoint = endpoint
        self._patterns = patterns
        self._provider = provider

    @property
    def provider_name(self) -> str:
        return self._provider

    @property
    def supported_patterns(self) -> list[str]:
        return self._patterns

    async def verify(self, secret: str) -> VerificationResult:
        """
        Verify using custom webhook endpoint.

        SECURITY NOTE: Only sends SHA-256 hash of secret to prevent exposure.
        The webhook must implement hash-based verification.
        """
        secret_hash = self.hash_secret(secret)
        start_time = time.time()

        try:
            # SECURITY: Only send hash, never plaintext secret
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self._endpoint,
                    json={"secret_hash": secret_hash},
                    timeout=self.timeout,
                )

            latency_ms = (time.time() - start_time) * 1000

            if response.status_code == 200:
                return VerificationResult(
                    status=VerificationStatus.VERIFIED,
                    provider=self.provider_name,
                    secret_type="custom",
                    secret_hash=secret_hash,
                    verified_at=time.time(),
                    latency_ms=latency_ms,
                )

            return VerificationResult(
                status=VerificationStatus.INVALID,
                provider=self.provider_name,
                secret_type="custom",
                secret_hash=secret_hash,
                verified_at=time.time(),
                latency_ms=latency_ms,
            )

        except httpx.RequestError as e:
            latency_ms = (time.time() - start_time) * 1000
            return VerificationResult(
                status=VerificationStatus.UNKNOWN,
                provider=self.provider_name,
                secret_type="custom",
                secret_hash=secret_hash,
                verified_at=time.time(),
                latency_ms=latency_ms,
                error=str(e),
            )

    def _detect_secret_type(self, secret: str) -> str:
        return "custom"
