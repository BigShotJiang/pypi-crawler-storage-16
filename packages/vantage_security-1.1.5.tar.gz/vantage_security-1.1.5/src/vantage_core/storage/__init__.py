"""Storage module for Vantage database persistence.

Provides database storage for ground truth datasets, metrics history,
and validation results with support for SQLite and PostgreSQL.

Reference: US-031 - Database Persistence for Validation Framework
"""

from vantage_core.storage.database import (
    MimicDatabase,
    get_database,
)

__all__ = [
    "MimicDatabase",
    "get_database",
]
