"""Topology analysis for agent graphs."""

from vantage_core.topology.graph import AgentGraph

__all__ = ["AgentGraph"]
