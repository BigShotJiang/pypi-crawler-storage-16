from pathlib import Path

from typer.testing import CliRunner
from vantage_cli.main import app


def test_html_report_generation():
    # Setup test file in tmp
    # Note: Examples were moved to archive
    fixture_path = Path(".archive/legacy_v0/examples/realistic_crewai")
    if not fixture_path.exists():
        # Fallback for dev environment or if archive missing
        fixture_path = Path("examples/realistic_crewai")
        if not fixture_path.exists():
            # Create dummy
            import os

            os.makedirs("dummy_project", exist_ok=True)
            with open("dummy_project/agent.py", "w") as f:
                f.write(
                    "from crewai import Agent\nagent = Agent(role='Test', goal='Test', tools=[])"
                )
            fixture_path = Path("dummy_project")

    runner = CliRunner()

    # Run scan with --html
    # Note: We need to point to a valid directory.

    result = runner.invoke(
        app, ["scan", "directory", str(fixture_path), "--html", "--no-healthcheck"]
    )

    if result.exit_code != 0:
        print(f"CLI Output:\n{result.stdout}")

    # Check execution
    assert result.exit_code == 0
    assert "Generated Executive Report" in result.stdout
    assert "vantage_report.html" in result.stdout

    # Check artifact existence
    assert Path("vantage_report.html").exists()

    # Clean up
    if Path("vantage_report.html").exists():
        Path("vantage_report.html").unlink()


if __name__ == "__main__":
    test_html_report_generation()
