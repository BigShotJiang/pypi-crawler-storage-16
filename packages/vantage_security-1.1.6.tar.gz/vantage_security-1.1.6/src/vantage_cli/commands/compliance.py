"""
Compliance Reporting Commands

Commands for generating compliance reports:
- OWASP LLM Top 10 mapping
- SOC 2 evidence generation
- PDF/HTML reports for auditors
"""

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()

compliance_app = typer.Typer(
    name="compliance",
    help="Compliance reporting and evidence generation",
)


@compliance_app.command("owasp")
def owasp_report(
    scan_file: Path = typer.Argument(..., help="Path to Vantage scan results (JSON)"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file (JSON)"),
    project_name: str = typer.Option("", "--project", "-p", help="Project name"),
):
    """
    Generate OWASP LLM Top 10 mapping report.

    Maps security findings to OWASP Top 10 for Large Language Model Applications.

    Examples:
        vantage compliance owasp scan_results.json
        vantage compliance owasp scan_results.json --output owasp_report.json
    """
    from vantage_core.compliance.owasp_mapping import (
        OWASP_CATEGORIES,
        OWASPCategory,
        get_owasp_coverage,
        map_findings_to_owasp,
    )

    # Load scan results
    if not scan_file.exists():
        console.print(f"[red]File not found: {scan_file}[/red]")
        raise typer.Exit(1)

    with open(scan_file) as f:
        scan_results = json.load(f)

    findings = scan_results.get("findings", [])
    if not findings:
        console.print("[yellow]No findings in scan results[/yellow]")

    # Generate OWASP mapping
    mapping = map_findings_to_owasp(
        findings=findings,
        project_name=project_name or scan_results.get("project_name", ""),
    )

    # Display results
    console.print(
        Panel.fit(
            "[bold blue]OWASP LLM Top 10 Mapping Report[/bold blue]",
            border_style="blue",
        )
    )

    console.print(f"\n[bold]Scan ID:[/bold] {mapping.scan_id}")
    console.print(f"[bold]Project:[/bold] {mapping.project_name}")
    console.print(f"[bold]Date:[/bold] {mapping.scan_date}")
    console.print(f"[bold]Total Findings:[/bold] {len(mapping.findings)}")

    # Coverage table
    table = Table(title="OWASP LLM Top 10 Coverage")
    table.add_column("ID", style="cyan")
    table.add_column("Category", style="white")
    table.add_column("Findings", justify="center")
    table.add_column("Status", justify="center")

    for cat in OWASPCategory:
        count = mapping.get_category_count(cat)
        status = "[green][OK][/green]" if count > 0 else "[dim]-[/dim]"
        table.add_row(
            cat.value,
            OWASP_CATEGORIES[cat].name,
            str(count) if count > 0 else "-",
            status,
        )

    console.print(table)

    # Coverage summary
    coverage = get_owasp_coverage(mapping)
    console.print(
        f"\n[bold]Coverage:[/bold] {coverage['categories_covered']}/{coverage['total_categories']} "
        f"categories ({coverage['coverage_percentage']:.1f}%)"
    )

    # Severity breakdown
    breakdown = mapping.get_severity_breakdown()
    console.print("\n[bold]Severity Breakdown:[/bold]")
    console.print(f"  [red]Critical:[/red] {breakdown['critical']}")
    console.print(f"  [red]High:[/red] {breakdown['high']}")
    console.print(f"  [yellow]Medium:[/yellow] {breakdown['medium']}")
    console.print(f"  [green]Low:[/green] {breakdown['low']}")

    # Export if requested
    if output:
        with open(output, "w") as f:
            json.dump(mapping.to_dict(), f, indent=2)
        console.print(f"\n[green][OK] Report saved to {output}[/green]")


@compliance_app.command("soc2")
def soc2_evidence(
    scan_file: Path = typer.Argument(..., help="Path to Vantage scan results (JSON)"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file (JSON)"),
    organization: str = typer.Option("", "--org", help="Organization name"),
    system: str = typer.Option("", "--system", help="System name"),
    period_start: str = typer.Option("", "--start", help="Audit period start (YYYY-MM-DD)"),
    period_end: str = typer.Option("", "--end", help="Audit period end (YYYY-MM-DD)"),
):
    """
    Generate SOC 2 evidence package from scan results.

    Creates audit-ready evidence for SOC 2 Type II compliance.

    Examples:
        vantage compliance soc2 scan_results.json
        vantage compliance soc2 scan_results.json --org "Acme Corp" --system "AI Platform"
        vantage compliance soc2 scan_results.json --output soc2_evidence.json
    """
    from vantage_core.compliance.soc2_evidence import (
        SOC2_AI_CONTROLS,
        SOC2EvidenceGenerator,
    )

    # Load scan results
    if not scan_file.exists():
        console.print(f"[red]File not found: {scan_file}[/red]")
        raise typer.Exit(1)

    with open(scan_file) as f:
        scan_results = json.load(f)

    # Generate evidence
    generator = SOC2EvidenceGenerator(
        organization_name=organization,
        system_name=system,
        audit_period_start=period_start,
        audit_period_end=period_end,
    )

    generator.generate_from_scan_results(scan_results)
    package = generator.generate_package()

    # Display results
    console.print(
        Panel.fit(
            "[bold blue]SOC 2 Evidence Package[/bold blue]",
            border_style="blue",
        )
    )

    console.print(f"\n[bold]Organization:[/bold] {package.organization_name}")
    console.print(f"[bold]System:[/bold] {package.system_name}")
    console.print(
        f"[bold]Audit Period:[/bold] {package.audit_period_start} to {package.audit_period_end}"
    )
    console.print(f"[bold]Generated:[/bold] {package.generated_date}")

    # Coverage table
    table = Table(title="SOC 2 Control Coverage")
    table.add_column("Control", style="cyan")
    table.add_column("Name", style="white")
    table.add_column("Category", style="blue")
    table.add_column("Evidence", justify="center")

    for control_id, control in SOC2_AI_CONTROLS.items():
        evidence_count = len(package.get_evidence_for_control(control_id))
        status = f"[green]{evidence_count}[/green]" if evidence_count > 0 else "[dim]-[/dim]"
        table.add_row(
            control_id,
            control.name[:40],
            control.category.value,
            status,
        )

    console.print(table)

    # Summary
    coverage = package.get_coverage_summary()
    console.print(
        f"\n[bold]Coverage:[/bold] {coverage['controls_covered']}/{coverage['total_controls']} "
        f"controls ({coverage['coverage_percentage']:.1f}%)"
    )
    console.print(f"[bold]Evidence Items:[/bold] {coverage['evidence_count']}")

    # Category breakdown
    console.print("\n[bold]By Category:[/bold]")
    for cat, stats in coverage["by_category"].items():
        console.print(f"  {cat}: {stats['covered']}/{stats['total']}")

    # Export if requested
    if output:
        with open(output, "w") as f:
            json.dump(package.to_dict(), f, indent=2)
        console.print(f"\n[green][OK] Evidence package saved to {output}[/green]")


@compliance_app.command("report")
def generate_report(
    scan_file: Path = typer.Argument(..., help="Path to Vantage scan results (JSON)"),
    output: Path = typer.Option("compliance_report.pdf", "--output", "-o", help="Output file"),
    format: str = typer.Option("pdf", "--format", "-f", help="Output format: pdf, html"),
    title: str = typer.Option(
        "AI Agent Security Assessment Report", "--title", "-t", help="Report title"
    ),
    organization: str = typer.Option("", "--org", help="Organization name"),
    system: str = typer.Option("", "--system", help="System name"),
    include_owasp: bool = typer.Option(True, "--owasp/--no-owasp", help="Include OWASP mapping"),
    include_soc2: bool = typer.Option(True, "--soc2/--no-soc2", help="Include SOC 2 evidence"),
):
    """
    Generate a comprehensive compliance report (PDF or HTML).

    Creates professional audit-ready reports with:
    - Executive summary with ATSS score
    - OWASP LLM Top 10 mapping
    - SOC 2 evidence summary
    - Detailed findings
    - Remediation recommendations

    Examples:
        vantage compliance report scan_results.json
        vantage compliance report scan.json --output report.pdf --org "Acme"
        vantage compliance report scan.json --format html
    """
    from vantage_core.compliance.owasp_mapping import map_findings_to_owasp
    from vantage_core.compliance.pdf_report import (
        ComplianceReportGenerator,
        ReportConfig,
        ReportData,
    )
    from vantage_core.compliance.soc2_evidence import SOC2EvidenceGenerator

    # Load scan results
    if not scan_file.exists():
        console.print(f"[red]File not found: {scan_file}[/red]")
        raise typer.Exit(1)

    with open(scan_file) as f:
        scan_results = json.load(f)

    console.print("[bold blue]Generating Compliance Report...[/bold blue]")

    # Generate OWASP mapping
    owasp_mapping = None
    if include_owasp:
        console.print("  Generating OWASP LLM Top 10 mapping...")
        owasp_mapping = map_findings_to_owasp(
            findings=scan_results.get("findings", []),
            project_name=system or organization,
        )

    # Generate SOC 2 evidence
    soc2_package = None
    if include_soc2:
        console.print("  Generating SOC 2 evidence...")
        generator = SOC2EvidenceGenerator(
            organization_name=organization,
            system_name=system,
        )
        generator.generate_from_scan_results(scan_results)
        soc2_package = generator.generate_package()

    # Configure report
    config = ReportConfig(
        title=title,
        organization=organization,
        system_name=system,
        include_owasp_mapping=include_owasp,
        include_soc2_evidence=include_soc2,
    )

    # Build report data
    data = ReportData(
        scan_results=scan_results,
        atss_score=scan_results.get("score", 0),
        atss_grade=scan_results.get("grade", "N/A"),
        total_findings=scan_results.get("findings_count", len(scan_results.get("findings", []))),
        critical_findings=scan_results.get("critical_count", 0),
        high_findings=scan_results.get("high_count", 0),
        medium_findings=scan_results.get("medium_count", 0),
        low_findings=scan_results.get("low_count", 0),
        agents_detected=scan_results.get("agents_detected", 0),
        frameworks=scan_results.get("frameworks", []),
        owasp_mapping=owasp_mapping,
        soc2_package=soc2_package,
        findings=scan_results.get("findings", []),
    )

    # Generate report
    report_generator = ComplianceReportGenerator(config)

    output_path = str(output)
    if format.lower() == "pdf":
        console.print("  Generating PDF report...")
        success = report_generator.generate_pdf(data, output_path)
        if not success:
            output_path = output_path.replace(".pdf", ".html")
            console.print(
                "[yellow]  PDF generation requires reportlab. Generated HTML instead.[/yellow]"
            )
    else:
        console.print("  Generating HTML report...")
        report_generator.generate_html(data, output_path)

    console.print(f"\n[green][OK] Report generated: {output_path}[/green]")

    # Summary
    console.print("\n[bold]Report Summary:[/bold]")
    console.print(f"  ATSS Score: {data.atss_score}/100 (Grade: {data.atss_grade})")
    console.print(f"  Total Findings: {data.total_findings}")
    if owasp_mapping:
        console.print(
            f"  OWASP Categories: {len(owasp_mapping.categories_with_findings)}/10 covered"
        )
    if soc2_package:
        coverage = soc2_package.get_coverage_summary()
        console.print(
            f"  SOC 2 Controls: {coverage['controls_covered']}/{coverage['total_controls']} covered"
        )


@compliance_app.command("controls")
def list_controls(
    framework: str = typer.Option("all", "--framework", "-f", help="Framework: owasp, soc2, all"),
):
    """
    List compliance controls and their AI/LLM relevance.

    Examples:
        vantage compliance controls
        vantage compliance controls --framework owasp
        vantage compliance controls --framework soc2
    """
    from vantage_core.compliance.owasp_mapping import OWASP_CATEGORIES, OWASPCategory
    from vantage_core.compliance.soc2_evidence import SOC2_AI_CONTROLS

    if framework in ["owasp", "all"]:
        console.print(
            Panel.fit(
                "[bold blue]OWASP LLM Top 10 (2025)[/bold blue]",
                border_style="blue",
            )
        )

        table = Table()
        table.add_column("ID", style="cyan", width=8)
        table.add_column("Name", style="white", width=30)
        table.add_column("Description", style="dim", width=50)

        for cat in OWASPCategory:
            info = OWASP_CATEGORIES[cat]
            table.add_row(
                info.id,
                info.name,
                (
                    info.description[:100] + "..."
                    if len(info.description) > 100
                    else info.description
                ),
            )

        console.print(table)

    if framework in ["soc2", "all"]:
        if framework == "all":
            console.print()

        console.print(
            Panel.fit(
                "[bold blue]SOC 2 AI/LLM Security Controls[/bold blue]",
                border_style="blue",
            )
        )

        table = Table()
        table.add_column("ID", style="cyan", width=8)
        table.add_column("Name", style="white", width=25)
        table.add_column("Category", style="blue", width=15)
        table.add_column("AI Relevance", style="dim", width=40)

        for control_id, control in SOC2_AI_CONTROLS.items():
            table.add_row(
                control_id,
                control.name[:25],
                control.category.value,
                (
                    control.ai_relevance[:80] + "..."
                    if len(control.ai_relevance) > 80
                    else control.ai_relevance
                ),
            )

        console.print(table)


@compliance_app.command("audit-checklist")
def audit_checklist(
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file (markdown)"),
):
    """
    Generate an audit preparation checklist.

    Creates a checklist for preparing for security audits of AI/LLM systems.

    Examples:
        vantage compliance audit-checklist
        vantage compliance audit-checklist --output checklist.md
    """
    from vantage_core.compliance.soc2_evidence import SOC2_AI_CONTROLS

    checklist = """# AI/LLM Security Audit Preparation Checklist

## Pre-Audit Preparation

### Documentation
- [ ] System architecture diagram for AI/LLM components
- [ ] Agent topology and trust boundary documentation
- [ ] Data flow diagrams showing sensitive data handling
- [ ] Access control matrix for AI systems
- [ ] Incident response procedures for AI-specific threats

### Security Controls
- [ ] Prompt injection testing results
- [ ] System prompt protection mechanisms documented
- [ ] Tool/plugin security configurations reviewed
- [ ] Agent permission models documented
- [ ] Human-in-the-loop controls identified

### Evidence Collection

"""

    for control_id, control in SOC2_AI_CONTROLS.items():
        checklist += f"#### {control_id}: {control.name}\n"
        checklist += f"*{control.ai_relevance}*\n\n"
        checklist += "Evidence needed:\n"
        for evidence_type in control.evidence_types:
            checklist += f"- [ ] {evidence_type}\n"
        checklist += "\n"

    checklist += """
## Vantage Scan Requirements

- [ ] Run full security scan: `vantage ./project/`
- [ ] Export JSON results: `vantage ./project/ --format json -o scan_results.json`
- [ ] Generate OWASP mapping: `vantage compliance owasp scan_results.json`
- [ ] Generate SOC 2 evidence: `vantage compliance soc2 scan_results.json`
- [ ] Generate compliance report: `vantage compliance report scan_results.json`

## Post-Scan Actions

- [ ] Review all critical and high findings
- [ ] Document remediation plans for findings
- [ ] Collect evidence for manual controls
- [ ] Schedule follow-up scans after remediation
"""

    if output:
        with open(output, "w") as f:
            f.write(checklist)
        console.print(f"[green][OK] Checklist saved to {output}[/green]")
    else:
        console.print(checklist)
