"""Benchmark runner for Vantage evaluation.

Implements US-028: Comprehensive benchmark suite with ground truth
evaluation and statistical significance testing.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np

from vantage_core.benchmark.baselines import RandomBaseline, RuleBasedBaseline
from vantage_core.benchmark.results import (
    BenchmarkResults,
    ComparisonReport,
    bootstrap_test,
    paired_t_test,
)
from vantage_core.data.ground_truth import GroundTruthCollection, load_all_ground_truth

logger = logging.getLogger(__name__)


class BenchmarkRunner:
    """Run benchmarks against ground truth dataset.

    Evaluates MAST detection, connection detection, and alignment
    scoring accuracy with statistical analysis.
    """

    def __init__(self, ground_truth_path: Path | None = None):
        """Initialize benchmark runner.

        Args:
            ground_truth_path: Path to ground truth directory.
                              If None, uses default package data.
        """
        if ground_truth_path:
            self.ground_truth = GroundTruthCollection.load_from_directory(ground_truth_path)
            self.ground_truth_path = str(ground_truth_path)
        else:
            self.ground_truth = load_all_ground_truth()
            self.ground_truth_path = "package_default"

        logger.info(f"Loaded {len(self.ground_truth.systems)} ground truth systems")

    def run_benchmark(
        self, analyzer: Any = None, analyzer_name: str = "Vantage"
    ) -> BenchmarkResults:
        """Run full benchmark suite.

        Args:
            analyzer: Optional custom analyzer object with methods:
                      - detect_failure_risks(system) -> list
                      - detect_connections(system) -> list
                      - score_system(system) -> AlignmentScore
                      If None, uses default Vantage analyzers.
            analyzer_name: Name for results identification

        Returns:
            BenchmarkResults with all metrics
        """
        start_time = time.time()

        results = BenchmarkResults(
            timestamp=datetime.utcnow().isoformat(),
            analyzer_name=analyzer_name,
            ground_truth_path=self.ground_truth_path,
            total_systems=len(self.ground_truth.systems),
        )

        # Initialize default analyzers if needed
        if analyzer is None:
            from vantage_core.analysis.alignment import AlignmentScorer
            from vantage_core.analysis.collision import CollisionDetector
            from vantage_core.analysis.failure_taxonomy import MASTFailureDetector

            mast_detector = MASTFailureDetector()
            alignment_scorer = AlignmentScorer()
            collision_detector = CollisionDetector()

        # Collect predictions and ground truth
        mast_tp, mast_fp, mast_fn = 0, 0, 0
        conn_tp, conn_fp, conn_fn = 0, 0, 0
        alignment_errors = []
        alignment_predictions = []
        alignment_actuals = []

        system_scores = []
        framework_scores: dict[str, list[dict]] = {}

        for gt_system in self.ground_truth.systems:
            try:
                # Convert to AgentSystem
                system = gt_system.to_agent_system()

                # Run MAST detection
                if analyzer is None:
                    risks = mast_detector.detect_failure_risks(system)
                    predicted_failures = self._risks_to_failures(risks)
                else:
                    predicted_failures = analyzer.predict_mast_failures(gt_system)

                # Compare MAST predictions
                mast_result = self._compare_mast_failures(
                    predicted_failures, gt_system.expected_mast_failures
                )
                mast_tp += mast_result["tp"]
                mast_fp += mast_result["fp"]
                mast_fn += mast_result["fn"]

                # Run connection detection
                if analyzer is None:
                    detected_conns = [
                        {"source": c.source, "target": c.target}
                        for c in system.topology.connections
                    ]
                else:
                    detected_conns = analyzer.predict_connections(gt_system)

                # Compare connections
                conn_result = self._compare_connections(
                    detected_conns, gt_system.expected_connections
                )
                conn_tp += conn_result["tp"]
                conn_fp += conn_result["fp"]
                conn_fn += conn_result["fn"]

                # Run alignment scoring
                if analyzer is None:
                    collisions = collision_detector.detect_collisions(system)
                    score = alignment_scorer.score_system(system, collisions)
                    predicted_alignment = score.overall_score
                else:
                    predicted_alignment = analyzer.predict_alignment_score(gt_system)

                alignment_error = abs(predicted_alignment - gt_system.expected_alignment_score)
                alignment_errors.append(alignment_error)
                alignment_predictions.append(predicted_alignment)
                alignment_actuals.append(gt_system.expected_alignment_score)

                # Record per-system scores
                system_result = {
                    "system_id": gt_system.system_id,
                    "framework": gt_system.framework,
                    "difficulty": gt_system.difficulty,
                    "mast_f1": self._calculate_f1(
                        mast_result["tp"], mast_result["fp"], mast_result["fn"]
                    ),
                    "connection_f1": self._calculate_f1(
                        conn_result["tp"], conn_result["fp"], conn_result["fn"]
                    ),
                    "alignment_error": alignment_error,
                    "predicted_alignment": predicted_alignment,
                    "expected_alignment": gt_system.expected_alignment_score,
                }
                system_scores.append(system_result)

                # Group by framework
                if gt_system.framework not in framework_scores:
                    framework_scores[gt_system.framework] = []
                framework_scores[gt_system.framework].append(system_result)

            except Exception as e:
                logger.error(f"Error processing {gt_system.system_id}: {e}")
                continue

        # Calculate overall metrics
        results.mast_precision = mast_tp / (mast_tp + mast_fp) if (mast_tp + mast_fp) > 0 else 0
        results.mast_recall = mast_tp / (mast_tp + mast_fn) if (mast_tp + mast_fn) > 0 else 0
        results.mast_f1 = self._calculate_f1(mast_tp, mast_fp, mast_fn)

        results.connection_precision = (
            conn_tp / (conn_tp + conn_fp) if (conn_tp + conn_fp) > 0 else 0
        )
        results.connection_recall = conn_tp / (conn_tp + conn_fn) if (conn_tp + conn_fn) > 0 else 0
        results.connection_f1 = self._calculate_f1(conn_tp, conn_fp, conn_fn)

        results.alignment_mae = float(np.mean(alignment_errors)) if alignment_errors else 0
        if len(alignment_predictions) > 1:
            results.alignment_correlation = float(
                np.corrcoef(alignment_predictions, alignment_actuals)[0, 1]
            )

        results.system_scores = system_scores

        # Calculate per-framework metrics
        for framework, scores in framework_scores.items():
            results.by_framework[framework] = {
                "avg_mast_f1": float(np.mean([s["mast_f1"] for s in scores])),
                "avg_connection_f1": float(np.mean([s["connection_f1"] for s in scores])),
                "avg_alignment_error": float(np.mean([s["alignment_error"] for s in scores])),
                "n_systems": len(scores),
            }

        results.runtime_seconds = time.time() - start_time
        logger.info(f"Benchmark completed in {results.runtime_seconds:.2f}s")

        return results

    def compare_to_baseline(
        self, results: BenchmarkResults, baseline_type: str = "rule"
    ) -> ComparisonReport:
        """Compare results against baseline.

        Args:
            results: Benchmark results to compare
            baseline_type: 'rule' for RuleBasedBaseline or 'random' for RandomBaseline

        Returns:
            ComparisonReport with statistical analysis
        """
        # Run baseline
        if baseline_type == "rule":
            baseline = RuleBasedBaseline()
            baseline_name = "RuleBasedBaseline"
        else:
            baseline = RandomBaseline()
            baseline_name = "RandomBaseline"

        baseline_results = self.run_benchmark(baseline, baseline_name)

        # Create comparison report
        report = ComparisonReport(
            results_name=results.analyzer_name,
            baseline_name=baseline_name,
            timestamp=datetime.utcnow().isoformat(),
        )

        # Calculate differences
        report.mast_f1_diff = results.mast_f1 - baseline_results.mast_f1
        report.connection_f1_diff = results.connection_f1 - baseline_results.connection_f1
        report.alignment_mae_diff = results.alignment_mae - baseline_results.alignment_mae

        # Extract per-system scores for statistical tests
        if results.system_scores and baseline_results.system_scores:
            results_mast = [s["mast_f1"] for s in results.system_scores]
            baseline_mast = [s["mast_f1"] for s in baseline_results.system_scores]

            results_conn = [s["connection_f1"] for s in results.system_scores]
            baseline_conn = [s["connection_f1"] for s in baseline_results.system_scores]

            results_align = [
                -s["alignment_error"] for s in results.system_scores
            ]  # Negative so higher is better
            baseline_align = [-s["alignment_error"] for s in baseline_results.system_scores]

            # Run statistical tests
            try:
                report.mast_significance = paired_t_test(results_mast, baseline_mast)
                report.connection_significance = paired_t_test(results_conn, baseline_conn)
                report.alignment_significance = paired_t_test(results_align, baseline_align)
            except Exception as e:
                logger.warning(f"Statistical tests failed: {e}")
                # Fall back to bootstrap
                report.mast_significance = bootstrap_test(results_mast, baseline_mast)

        # Determine if overall improvement
        improvements = 0
        if report.mast_f1_diff > 0:
            improvements += 1
        if report.connection_f1_diff > 0:
            improvements += 1
        if report.alignment_mae_diff < 0:  # Lower MAE is better
            improvements += 1

        report.is_improvement = improvements >= 2

        # Generate notes
        if report.mast_f1_diff > 0.1:
            report.summary_notes.append(
                f"Strong improvement in MAST detection (+{report.mast_f1_diff:.2f} F1)"
            )
        elif report.mast_f1_diff < -0.1:
            report.summary_notes.append(
                f"MAST detection worse than baseline ({report.mast_f1_diff:.2f} F1)"
            )

        if report.connection_f1_diff > 0.1:
            report.summary_notes.append(
                f"Strong improvement in connection detection (+{report.connection_f1_diff:.2f} F1)"
            )

        if report.alignment_mae_diff < -5:
            report.summary_notes.append(
                f"Significantly better alignment scoring ({report.alignment_mae_diff:.1f} MAE)"
            )

        if report.mast_significance and report.mast_significance.significant:
            report.summary_notes.append("MAST improvement is statistically significant")

        return report

    def _risks_to_failures(self, risks: list) -> dict[str, list[str]]:
        """Convert failure risks to MAST category format."""
        failures: dict[str, list[str]] = {
            "manipulation": [],
            "autonomy": [],
            "secrecy": [],
            "takeover": [],
        }

        for risk in risks:
            category = risk.failure_mode.category.value.lower()
            if category in failures:
                for agent_id in risk.agents_at_risk:
                    if agent_id not in failures[category]:
                        failures[category].append(agent_id)

        return failures

    def _compare_mast_failures(
        self, predicted: dict[str, list[str]], expected: dict[str, list[str]]
    ) -> dict[str, int]:
        """Compare predicted and expected MAST failures."""
        tp, fp, fn = 0, 0, 0

        all_categories = set(predicted.keys()) | set(expected.keys())

        for category in all_categories:
            pred_agents = set(predicted.get(category, []))
            exp_agents = set(expected.get(category, []))

            tp += len(pred_agents & exp_agents)
            fp += len(pred_agents - exp_agents)
            fn += len(exp_agents - pred_agents)

        return {"tp": tp, "fp": fp, "fn": fn}

    def _compare_connections(
        self, predicted: list[dict[str, str]], expected: list[dict[str, Any]]
    ) -> dict[str, int]:
        """Compare predicted and expected connections."""
        pred_set = {(c["source"], c["target"]) for c in predicted}
        exp_set = {(c["source"], c["target"]) for c in expected}

        tp = len(pred_set & exp_set)
        fp = len(pred_set - exp_set)
        fn = len(exp_set - pred_set)

        return {"tp": tp, "fp": fp, "fn": fn}

    def _calculate_f1(self, tp: int, fp: int, fn: int) -> float:
        """Calculate F1 score from counts."""
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        if (precision + recall) > 0:
            return 2 * precision * recall / (precision + recall)
        return 0.0


def run_quick_benchmark() -> BenchmarkResults:
    """Convenience function to run a quick benchmark with defaults.

    Returns:
        BenchmarkResults from default Vantage analyzers
    """
    runner = BenchmarkRunner()
    return runner.run_benchmark()
