from typing import Dict, Set, List, Tuple
from vantage_core.graph.vantage_graph import VantageGraph
from vantage_core.graph.store import NodeType, EdgeType

class AdvancedDataFlowSolver:
    """
    Advanced Data Flow Solver with Pointer Analysis & Field Sensitivity.
    """
    def __init__(self, graph: VantageGraph):
        self.graph = graph
        # Points-To Set: ptr_id -> {obj_id, ...}
        # "Variable A points to Object B"
        self.points_to: Dict[int, Set[int]] = {}
        
        # Field Map: (obj_id, field_name) -> {value_id, ...}
        self.heap: Dict[Tuple[int, str], Set[int]] = {}

    def solve(self):
        """Run Inter-procedural Data Flow Analysis."""
        # 1. Initialize Points-To Graph
        self._init_pointers()
        
        # 1.5 Link Variables by Name (Simplified Scope)
        # Map variable name -> list of node IDs
        var_map: Dict[str, List[int]] = {}
        for nid in range(self.graph._count):
            if self.graph.get_node_type(nid) == NodeType.VARIABLE:
                name = self.graph.get_attr(nid, "name")
                if name:
                    var_map.setdefault(name, []).append(nid)
        
        # 2. Fixed-Point Iteration (Anderson's Analysis)
        changed = True
        iteration = 0
        while changed:
            changed = False
            iteration += 1
            
            # Iterate all edges to find flows
            for src_id in range(self.graph._count):
                out_edges = self.graph.out_edges(src_id)
                
                src_pts = self.points_to.get(src_id, set())
                if not src_pts:
                    continue
                    
                for dst_id, edge_type in out_edges:
                    if edge_type == EdgeType.DATA_FLOW:
                        dst_pts = self.points_to.setdefault(dst_id, set())
                        
                        if not src_pts.issubset(dst_pts):
                            dst_pts.update(src_pts)
                            changed = True
                            
                            # Propagate to aliases (same variable name)
                            if self.graph.get_node_type(dst_id) == NodeType.VARIABLE:
                                name = self.graph.get_attr(dst_id, "name")
                                if name and name in var_map:
                                    for alias_id in var_map[name]:
                                        alias_pts = self.points_to.setdefault(alias_id, set())
                                        if not dst_pts.issubset(alias_pts):
                                            alias_pts.update(dst_pts)



    def _init_pointers(self):
        """Initialize points-to sets for literals and allocations."""
        for nid in range(self.graph._count):
            ntype = self.graph.get_node_type(nid)
            
            # Allocation sites (Class instantiation, Literals)
            if ntype in (NodeType.LITERAL, NodeType.CLASS):
                # abstract object identified by allocation site ID
                self.points_to[nid] = {nid}

    def _propagate_taint(self, sources: Set[int], sinks: Set[int], sanitizers: Set[str]) -> List[Dict]:
        """Trace taint from sources to sinks using Points-To info."""
        # This is a Reachability problem on the Points-To graph
        vulns = []
        
        # Tainted Objects: Set of abstract object IDs that are tainted
        tainted_objs = set()
        
        # Seed taint from sources
        for src_id in sources:
            # Get objects pointed to by source variable
            objs = self.points_to.get(src_id, set())
            tainted_objs.update(objs)
            
        # Propagate through Heap (Fields)
        # If Obj A is tainted, and A.f -> Obj B, then B is tainted? 
        # Usually: If 'x' is tainted, and 'y = x', then 'y' is tainted.
        # If 'x' tainted, 'x.f = z', 'z' is NOT tainted.
        # If 'z' tainted, 'x.f = z', 'x.f' IS tainted.
        
        return vulns
