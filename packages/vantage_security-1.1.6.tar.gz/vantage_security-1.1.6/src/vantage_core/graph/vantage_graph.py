import array
import struct
from typing import Dict, List, Tuple, Optional, Any

# Byte-packing constants for memory efficiency
# Node Layout: [TYPE(1B) | ATTR_PTR(4B) | NEXT_SIBLING(4B) | FIRST_CHILD(4B)]
NODE_STRUCT = struct.Struct("B I I I")
NODE_SIZE = NODE_STRUCT.size

class VantageGraph:
    """
    High-Performance Graph Store using Byte Arrays.
    Simulates a C-like memory layout for maximum Python performance.
    """
    __slots__ = ('_nodes', '_edges_out', '_edges_in', '_attrs', '_attr_pool', '_count')

    def __init__(self, capacity: int = 10000):
        # Contiguous memory block for nodes
        self._nodes = bytearray(capacity * NODE_SIZE)
        
        # Adjacency Lists (List of integers for speed)
        # _edges_out[node_id] -> [target_id, type, target_id, type...]
        self._edges_out: List[array.array] = [] 
        self._edges_in: List[array.array] = []
        
        # Attribute Pool (String Interning & Object Storage)
        self._attrs: Dict[int, Any] = {}
        self._attr_pool: Dict[str, int] = {}
        
        self._count = 0

    def add_node(self, type_id: int, attrs: Optional[Dict[str, Any]] = None) -> int:
        nid = self._count
        offset = nid * NODE_SIZE
        
        # Grow buffer if needed
        if offset + NODE_SIZE > len(self._nodes):
            self._nodes.extend(bytearray(len(self._nodes)))
            
        # Pack Node Data
        # [TYPE, ATTR_ID, 0, 0]
        attr_id = 0
        if attrs:
            attr_id = id(attrs) # Use object ID as temporary handle, or better, store in dict
            self._attrs[nid] = attrs

        NODE_STRUCT.pack_into(self._nodes, offset, type_id, 0, 0, 0)
        
        # Extend Edge Lists
        self._edges_out.append(array.array('I'))
        self._edges_in.append(array.array('I'))
        
        self._count += 1
        return nid

    def add_edge(self, src: int, dst: int, type_id: int):
        # Store as [dst, type] pair flattened in array
        self._edges_out[src].extend((dst, type_id))
        self._edges_in[dst].extend((src, type_id))

    def get_node_type(self, nid: int) -> int:
        return self._nodes[nid * NODE_SIZE]

    def get_attr(self, nid: int, key: str) -> Any:
        return self._attrs.get(nid, {}).get(key)
        
    def out_edges(self, nid: int) -> List[Tuple[int, int]]:
        # Unpack flattened array [dst, type, dst, type...]
        raw = self._edges_out[nid]
        return [(raw[i], raw[i+1]) for i in range(0, len(raw), 2)]

    def in_edges(self, nid: int) -> List[Tuple[int, int]]:
        raw = self._edges_in[nid]
        return [(raw[i], raw[i+1]) for i in range(0, len(raw), 2)]
