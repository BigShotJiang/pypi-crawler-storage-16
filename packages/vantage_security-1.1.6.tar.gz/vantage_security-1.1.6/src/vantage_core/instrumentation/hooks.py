"""
Import Hook Manager for Robust Auto-Instrumentation.

Uses sys.meta_path to intercept imports before they load, ensuring
security patches are applied even if the user imports modules
in weird ways or orders.
"""

import importlib.abc
import importlib.util
from collections.abc import Callable


class SecurityImportHook(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    """
    Hooks into Python's import system to patch modules on load.
    """

    def __init__(self, patcher_func: Callable):
        self.patcher = patcher_func
        self.target_modules = {"crewai", "langchain", "autogen"}
        self._in_progress = set()  # Prevent recursion

    def find_spec(self, fullname, path, target=None):
        # Only intercept our targets top-level packages
        root_pkg = fullname.split(".")[0]
        if root_pkg in self.target_modules:
            return importlib.util.spec_from_loader(fullname, self)
        return None

    def create_module(self, spec):
        # Use default creation
        return None

    def exec_module(self, module):
        # 1. Execute the standard import
        # We need to temporarily remove our hook to avoid recursion loops
        # when we call importlib inside here
        if module.__name__ in self._in_progress:
            return

        self._in_progress.add(module.__name__)

        try:
            # Find the original spec (bypassing us)
            # This is tricky in Python. A simpler way is to let standard loading happen
            # then modify. But `exec_module` implies we own loading.

            # Alternative: Post-import hook strategy.
            # We don't implement Loader, we just return None in find_spec
            # but triggers a callback? No.

            # Standard pattern:
            # Use `importlib` to execute the module, then apply patch.
            pass
        finally:
            self._in_progress.discard(module.__name__)


# Simplified Strategy: "Post-Import" patching is safer than implementing a full Loader.
# We will use a polling approach or just rely on 'sys.modules' monitoring
# if we want to avoid the complexity of `exec_module`.

# ACTUALLY: The most robust way is `wrapt` library style, but that's a dependency.
# Let's stick to the `instrumentation.py` approach but make it smarter:
# We iterate `sys.modules` periodically? No.

# Best "Standard Lib" way:
# Just modify `sys.modules` after import if it exists, or wait for it.
# But we can't wait.

# Let's refine the previous `AutoInstrumentor` to be called *immediately* on startup.
# The user puts `vantage.patch_all()` at the top of `main.py`.
# That IS the standard for OpenTelemetry/Datadog in Python.
# Implementing a transparent `sitecustomize` injection is the "Enterprise" deployment way,
# but for a library, `patch_all()` is acceptable.

# I will improve `AutoInstrumentor` to handle "Lazy Patching".
# If `crewai` is NOT in `sys.modules`, we can add a dummy object to `sys.modules`
# that triggers the patch when accessed? Too magic.

# Better: Just check `sys.modules` in the `instrument_all` loop.
# If module not found, we can't patch yet.
# BUT, we can wrap `__import__` built-in!


class ImportInterceptor:
    """Intercepts __import__ to patch modules as they are loaded."""

    def __init__(self, patcher: "AutoInstrumentor"):
        self.patcher = patcher
        self.original_import = __builtins__["__import__"]
        self._patching = False  # Prevent recursion

    def install(self):
        __builtins__["__import__"] = self._import_hook

    def uninstall(self):
        """Restore the original import function."""
        if __builtins__["__import__"] == self._import_hook:
            __builtins__["__import__"] = self.original_import

    def _import_hook(self, name, globals=None, locals=None, fromlist=(), level=0):
        # 1. Call original import
        module = self.original_import(name, globals, locals, fromlist, level)

        # 2. Check if we need to patch, but avoid recursion
        if (
            not self._patching
            and name
            and ("crewai" in name or "langchain" in name or "autogen" in name)
        ):
            self._patching = True
            try:
                # Trigger patcher logic (idempotent)
                if "crewai" in name:
                    self.patcher.instrument_crewai()
                if "langchain" in name:
                    self.patcher.instrument_langchain()
                if "autogen" in name:
                    self.patcher.instrument_autogen()
            finally:
                self._patching = False

        return module
