"""
REST API for Vantage Security Platform.

This module provides FastAPI-based REST endpoints for security scanning,
results retrieval, and report generation.
"""

from vantage_core.security.api.app import app, create_app
from vantage_core.security.api.auth import (
    APIKeyAuth,
    rate_limit,
    verify_api_key,
)
from vantage_core.security.api.models import (
    AsyncScanResponse,
    ReportFormat,
    ScanRequest,
    ScanResponse,
    ScanStatus,
    WebhookConfig,
)

__all__ = [
    "app",
    "create_app",
    "ScanRequest",
    "ScanResponse",
    "ScanStatus",
    "ReportFormat",
    "AsyncScanResponse",
    "WebhookConfig",
    "verify_api_key",
    "rate_limit",
    "APIKeyAuth",
]
