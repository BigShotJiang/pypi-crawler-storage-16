"""
CLI Integration for Vantage Security Platform.

This module provides command-line interface commands for
security scanning and report generation.
"""

from vantage_core.security.cli.security import main, security

__all__ = [
    "security",
    "main",
]
