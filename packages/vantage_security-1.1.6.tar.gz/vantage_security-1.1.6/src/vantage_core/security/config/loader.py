"""
Configuration loader with multi-source support.

US-009: Environment Variable Overrides
US-010: YAML/TOML Configuration File

Loads configuration from multiple sources with proper precedence:
1. Explicit overrides (highest priority)
2. Environment variables
3. .env file
4. TOML/YAML configuration file
5. Default values (lowest priority)
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import tomli
import yaml

from vantage_core.security.config.schema import MimicSettings


class ConfigurationError(Exception):
    """Configuration loading or validation error."""

    def __init__(self, message: str, error_code: str = "CONFIG_ERROR"):
        super().__init__(message)
        self.error_code = error_code


def find_config_file(
    explicit_path: Path | None = None, search_paths: list[Path] | None = None
) -> Path | None:
    """
    Find configuration file using search hierarchy.

    Args:
        explicit_path: Explicitly specified config file path
        search_paths: Paths to search for config files

    Returns:
        Path to configuration file or None if not found
    """
    if explicit_path:
        if not explicit_path.exists():
            raise ConfigurationError(
                f"Configuration file not found: {explicit_path}", "CONFIG_NOT_FOUND"
            )
        return explicit_path

    # Default search paths
    if search_paths is None:
        cwd = Path.cwd()
        home = Path.home()
        search_paths = [
            cwd / "vantage.toml",
            cwd / "vantage.yaml",
            cwd / "vantage.yml",
            cwd / ".vantage.toml",
            cwd / ".vantage.yaml",
            cwd / ".vantage.yml",
            home / ".vantage.toml",
            home / ".vantage.yaml",
            home / ".vantage.yml",
            home / ".config" / "vantage" / "config.toml",
            home / ".config" / "vantage" / "config.yaml",
        ]

    for path in search_paths:
        if path.exists():
            return path

    return None


def load_toml(path: Path) -> dict[str, Any]:
    """
    Load configuration from TOML file.

    Args:
        path: Path to TOML file

    Returns:
        Configuration dictionary
    """
    try:
        with open(path, "rb") as f:
            return tomli.load(f)
    except tomli.TOMLDecodeError as e:
        raise ConfigurationError(f"Invalid TOML syntax in {path}: {e}", "CONFIG_PARSE_ERROR") from e


def load_yaml(path: Path) -> dict[str, Any]:
    """
    Load configuration from YAML file.

    Args:
        path: Path to YAML file

    Returns:
        Configuration dictionary
    """
    try:
        with open(path, encoding="utf-8") as f:
            data = yaml.safe_load(f)
            return data if data else {}
    except yaml.YAMLError as e:
        raise ConfigurationError(f"Invalid YAML syntax in {path}: {e}", "CONFIG_PARSE_ERROR") from e


def load_config_file(path: Path) -> dict[str, Any]:
    """
    Load configuration from file based on extension.

    Args:
        path: Path to configuration file

    Returns:
        Configuration dictionary
    """
    suffix = path.suffix.lower()

    if suffix == ".toml":
        return load_toml(path)
    elif suffix in (".yaml", ".yml"):
        return load_yaml(path)
    else:
        # Try TOML first, then YAML
        try:
            return load_toml(path)
        except ConfigurationError:
            return load_yaml(path)


def merge_configs(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """
    Deep merge two configuration dictionaries.

    Args:
        base: Base configuration
        override: Override configuration (takes precedence)

    Returns:
        Merged configuration
    """
    result = base.copy()

    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_configs(result[key], value)
        else:
            result[key] = value

    return result


def load_config(
    config_file: Path | str | None = None,
    overrides: dict[str, Any] | None = None,
    search_for_config: bool = True,
) -> MimicSettings:
    """
    Load configuration with proper precedence.

    Priority (highest to lowest):
    1. Explicit overrides dict
    2. Environment variables (MIMIC_ prefix)
    3. .env file
    4. TOML/YAML config file
    5. Default values

    Args:
        config_file: Optional explicit config file path
        overrides: Optional dictionary of override values
        search_for_config: Whether to search for config files

    Returns:
        Loaded and validated MimicSettings

    Raises:
        ConfigurationError: If configuration is invalid

    Example:
        >>> # Load with defaults and environment variables
        >>> settings = load_config()
        >>>
        >>> # Load from specific file
        >>> settings = load_config("/path/to/config.toml")
        >>>
        >>> # Load with overrides
        >>> settings = load_config(overrides={"log_level": "DEBUG"})
    """
    config_dict: dict[str, Any] = {}

    # Convert string path to Path
    if isinstance(config_file, str):
        config_file = Path(config_file)

    # Find and load config file
    if search_for_config or config_file:
        found_path = find_config_file(config_file)
        if found_path:
            config_dict = load_config_file(found_path)

    # Apply overrides
    if overrides:
        config_dict = merge_configs(config_dict, overrides)

    # Create settings (this will load env vars and validate)
    try:
        if config_dict:
            settings = MimicSettings(**config_dict)
        else:
            settings = MimicSettings()

        return settings

    except ValueError as e:
        raise ConfigurationError(
            f"Configuration validation failed: {e}", "CONFIG_VALIDATION_ERROR"
        ) from e


def get_config(config_file: Path | str | None = None, **kwargs: Any) -> MimicSettings:
    """
    Get configuration with keyword argument overrides.

    Convenience function that allows passing individual settings
    as keyword arguments.

    Args:
        config_file: Optional config file path
        **kwargs: Individual setting overrides

    Returns:
        Loaded and validated MimicSettings

    Example:
        >>> settings = get_config(
        ...     log_level="DEBUG",
        ...     taint_enabled=False,
        ...     entropy_api_key=4.0
        ... )
    """
    return load_config(config_file=config_file, overrides=kwargs if kwargs else None)


def validate_config(settings: MimicSettings) -> list[str]:
    """
    Perform additional validation on configuration.

    Checks for common misconfigurations and returns warnings.

    Args:
        settings: Configuration to validate

    Returns:
        List of warning messages
    """
    warnings = []

    # Check for overly permissive settings
    if settings.performance.max_file_size_kb > 10000:
        warnings.append(
            f"Large max_file_size_kb ({settings.performance.max_file_size_kb}) "
            "may cause memory issues"
        )

    if settings.performance.timeout_seconds > 1800:
        warnings.append(
            f"Long timeout_seconds ({settings.performance.timeout_seconds}) "
            "may indicate misconfiguration"
        )

    if settings.taint.max_iterations > 50000:
        warnings.append(
            f"High taint.max_iterations ({settings.taint.max_iterations}) "
            "may cause performance issues"
        )

    # Check for disabled security features
    if not settings.taint.enabled:
        warnings.append(
            "Taint analysis is disabled. Some data flow vulnerabilities " "may not be detected."
        )

    if not settings.rules.enable_builtin:
        warnings.append("Built-in rules are disabled. Ensure custom rules are configured.")

    # Check for potentially unsafe configurations
    if settings.entropy.default < 2.0:
        warnings.append(
            f"Low entropy threshold ({settings.entropy.default}) may cause " "many false positives"
        )

    if settings.confidence.min_secret < 0.3:
        warnings.append(
            f"Low confidence threshold ({settings.confidence.min_secret}) "
            "may cause many false positives"
        )

    return warnings


def dump_config(settings: MimicSettings, output_path: Path, format: str = "toml") -> None:
    """
    Dump configuration to file.

    Args:
        settings: Configuration to dump
        output_path: Output file path
        format: Output format ("toml" or "yaml")
    """
    config_dict = settings.to_dict()

    if format == "toml":
        import tomli_w

        with open(output_path, "wb") as f:
            tomli_w.dump(config_dict, f)
    elif format in ("yaml", "yml"):
        with open(output_path, "w", encoding="utf-8") as f:
            yaml.dump(config_dict, f, default_flow_style=False, sort_keys=False)
    else:
        raise ConfigurationError(f"Unsupported format: {format}", "CONFIG_FORMAT_ERROR")


def list_env_vars() -> dict[str, str]:
    """
    List all Vantage environment variables and their values.

    Returns:
        Dictionary of environment variable names to current values
    """
    prefix = "MIMIC_"
    return {key: value for key, value in os.environ.items() if key.startswith(prefix)}


def get_default_config() -> MimicSettings:
    """
    Get configuration with default values only.

    Useful for testing or getting a reference configuration.

    Returns:
        MimicSettings with all defaults
    """
    # Temporarily clear env vars to get pure defaults
    env_backup = {}
    prefix = "MIMIC_"

    for key in list(os.environ.keys()):
        if key.startswith(prefix):
            env_backup[key] = os.environ.pop(key)

    try:
        settings = MimicSettings()
    finally:
        # Restore env vars
        os.environ.update(env_backup)

    return settings
