"""
Enhanced Secret Detection Pipeline for Vantage Security Scanner.

This module implements entropy-based filtering, context analysis, and allowlist
management to reduce false positives in secret detection while maintaining
high security standards.

Components:
- EntropyCalculator: Shannon entropy calculation for filtering low-entropy strings
- ContextAnalyzer: Code context analysis for severity adjustment
- AllowlistManager: Configurable allowlist/denylist pattern management
- SecretDetectionPipeline: Main pipeline orchestrating all components
"""

import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

import yaml

from vantage_core.security.models import SecurityFinding, Severity


@dataclass
class ContextAnalysisResult:
    """Result of context analysis for a finding."""

    is_test_file: bool
    is_placeholder: bool
    variable_name: str | None
    context_flags: list[str]
    severity_reduction: int  # Number of severity levels to reduce


@dataclass
class AllowlistPattern:
    """A pattern for allowlisting false positives."""

    pattern: str
    pattern_type: str  # "regex", "glob", "literal"
    scope: str  # "global", "org", "repo", "file"
    reason: str

    def matches(self, text: str, file_path: str | None = None) -> bool:
        """Check if text matches this pattern."""
        if self.pattern_type == "literal":
            return text == self.pattern
        elif self.pattern_type == "regex":
            try:
                return bool(re.match(self.pattern, text, re.IGNORECASE))
            except re.error:
                return False
        elif self.pattern_type == "glob":
            # Simple glob matching using fnmatch-style patterns
            import fnmatch

            return fnmatch.fnmatch(text, self.pattern)
        return False


@dataclass
class SecretAnalysisResult:
    """Result of analyzing a finding through the secret detection pipeline."""

    original_finding: SecurityFinding
    is_filtered: bool
    filter_reason: str | None
    adjusted_severity: Severity
    entropy_score: float
    context_flags: list[str]


class EntropyCalculator:
    """
    Calculate Shannon entropy for secret detection.

    High-entropy strings (random characters) are more likely to be secrets,
    while low-entropy strings (repeated patterns) are likely false positives.
    """

    DEFAULT_THRESHOLD = 5.0

    # Regex patterns for common non-secret high-entropy strings
    UUID_PATTERN = re.compile(
        r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
    )
    MD5_PATTERN = re.compile(r"^[0-9a-fA-F]{32}$")
    SHA1_PATTERN = re.compile(r"^[0-9a-fA-F]{40}$")
    SHA256_PATTERN = re.compile(r"^[0-9a-fA-F]{64}$")

    def __init__(self, threshold: float = DEFAULT_THRESHOLD):
        """
        Initialize entropy calculator.

        Args:
            threshold: Minimum entropy value to consider a string as potentially
                      being a secret. Default is 5.0.
        """
        self.threshold = threshold

    def calculate_entropy(self, text: str) -> float:
        """
        Calculate Shannon entropy of a string.

        Uses the formula: -sum(p * log2(p)) for each unique character.
        Higher values indicate more randomness.

        Args:
            text: String to calculate entropy for.

        Returns:
            Entropy value as float. Empty strings return 0.0.
        """
        if not text:
            return 0.0

        # Count character frequencies
        freq = Counter(text)
        length = len(text)

        # Calculate Shannon entropy
        entropy = 0.0
        for count in freq.values():
            if count > 0:
                p = count / length
                entropy -= p * math.log2(p)

        return entropy

    def is_high_entropy(self, text: str) -> bool:
        """
        Check if text exceeds the entropy threshold.

        Args:
            text: String to check.

        Returns:
            True if entropy exceeds threshold, False otherwise.
        """
        return self.calculate_entropy(text) >= self.threshold

    def is_likely_uuid(self, text: str) -> bool:
        """
        Check if text matches UUID pattern.

        UUIDs have high entropy but are not secrets.

        Args:
            text: String to check.

        Returns:
            True if text matches UUID format.
        """
        return bool(self.UUID_PATTERN.match(text))

    def is_likely_hash(self, text: str) -> bool:
        """
        Check if text matches common hash patterns (MD5, SHA1, SHA256).

        Hashes have high entropy but are typically not secrets themselves
        (they're derived values).

        Args:
            text: String to check.

        Returns:
            True if text matches a known hash format.
        """
        return bool(
            self.MD5_PATTERN.match(text)
            or self.SHA1_PATTERN.match(text)
            or self.SHA256_PATTERN.match(text)
        )

    def should_flag(self, text: str) -> tuple[bool, str | None]:
        """
        Determine if a string should be flagged as a potential secret.

        Checks entropy threshold and excludes known non-secret patterns.

        Args:
            text: String to analyze.

        Returns:
            Tuple of (should_flag, reason_if_not_flagged).
        """
        # Check for known non-secret patterns first
        if self.is_likely_uuid(text):
            return False, "UUID pattern detected"

        if self.is_likely_hash(text):
            return False, "Hash pattern detected"

        # Check entropy threshold
        entropy = self.calculate_entropy(text)
        if entropy < self.threshold:
            return False, f"Low entropy ({entropy:.2f} < {self.threshold})"

        return True, None


class ContextAnalyzer:
    """
    Analyze code context to reduce false positives in secret detection.

    Considers factors like:
    - Whether the file is a test file
    - Whether variable names suggest placeholder values
    - Surrounding code context
    """

    # Patterns indicating test files
    TEST_PATH_PATTERNS = [
        "test",
        "tests",
        "spec",
        "mock",
        "__test__",
        "fixture",
        "fixtures",
    ]

    # Variable names suggesting placeholder/example values
    PLACEHOLDER_NAMES = [
        "example",
        "sample",
        "test",
        "dummy",
        "fake",
        "mock",
        "placeholder",
        "demo",
        "your_",
        "my_",
        "xxx",
        "todo",
    ]

    def analyze(
        self, finding: SecurityFinding, file_content: str | None = None
    ) -> ContextAnalysisResult:
        """
        Analyze context for a finding and determine severity adjustment.

        Args:
            finding: The security finding to analyze.
            file_content: Optional full file content for deeper analysis.

        Returns:
            ContextAnalysisResult with analysis details.
        """
        context_flags = []
        severity_reduction = 0

        # Check if test file
        is_test = self.is_test_file(finding.file_path)
        if is_test:
            context_flags.append("test_file")
            severity_reduction += 1

        # Extract variable name from code snippet if available
        variable_name = self._extract_variable_name(finding.code_snippet)

        # Check for placeholder patterns
        is_placeholder = False
        if variable_name:
            is_placeholder = self.is_placeholder_variable(variable_name)
            if is_placeholder:
                context_flags.append("placeholder_variable")
                severity_reduction += 1

        # Check if in comment
        if finding.is_in_comment:
            context_flags.append("in_comment")
            severity_reduction += 1

        # Check for example/documentation patterns in code
        if self._is_documentation_example(finding.code_snippet):
            context_flags.append("documentation_example")
            severity_reduction += 1

        # Cap severity reduction at 2 levels
        severity_reduction = min(severity_reduction, 2)

        return ContextAnalysisResult(
            is_test_file=is_test,
            is_placeholder=is_placeholder,
            variable_name=variable_name,
            context_flags=context_flags,
            severity_reduction=severity_reduction,
        )

    def is_test_file(self, file_path: str) -> bool:
        """
        Check if file is in a test directory or is a test file.

        Args:
            file_path: Path to the file.

        Returns:
            True if file appears to be a test file.
        """
        path_lower = file_path.lower()

        # Check path components
        path_parts = Path(file_path).parts
        for part in path_parts:
            part_lower = part.lower()
            for pattern in self.TEST_PATH_PATTERNS:
                if pattern in part_lower:
                    return True

        # Check filename patterns
        filename = Path(file_path).name.lower()
        if filename.startswith("test_") or filename.endswith("_test.py"):
            return True
        if filename.endswith(".spec.py") or filename.endswith(".spec.js"):
            return True

        return False

    def is_placeholder_variable(self, variable_name: str) -> bool:
        """
        Check if variable name suggests a placeholder value.

        Args:
            variable_name: Name of the variable.

        Returns:
            True if variable name suggests placeholder/example.
        """
        name_lower = variable_name.lower()

        for pattern in self.PLACEHOLDER_NAMES:
            if pattern in name_lower:
                return True

        return False

    def get_severity_adjustment(self, context: ContextAnalysisResult) -> int:
        """
        Get the number of severity levels to reduce.

        Args:
            context: Context analysis result.

        Returns:
            Number of severity levels to reduce (0, 1, or 2).
        """
        return context.severity_reduction

    def _extract_variable_name(self, code_snippet: str) -> str | None:
        """Extract variable name from code snippet."""
        # Match common assignment patterns
        patterns = [
            r"(\w+)\s*=\s*['\"]",  # var = "value"
            r"(\w+)\s*:\s*str\s*=",  # var: str =
            r"['\"](\w+)['\"]\s*:",  # "key": value
            r"(\w+)\s*=\s*os\.getenv",  # var = os.getenv
        ]

        for pattern in patterns:
            match = re.search(pattern, code_snippet)
            if match:
                return match.group(1)

        return None

    def _is_documentation_example(self, code_snippet: str) -> bool:
        """Check if code appears to be a documentation example."""
        example_indicators = [
            "example",
            "e.g.",
            "for instance",
            "such as",
            ">>> ",  # Python doctest
            "# demo",
            "// demo",
        ]

        snippet_lower = code_snippet.lower()
        return any(indicator in snippet_lower for indicator in example_indicators)


class AllowlistManager:
    """
    Manage allowlist patterns for false positive suppression.

    Supports multiple pattern types and scopes for flexible configuration.
    """

    # Built-in patterns for common false positives
    BUILTIN_PATTERNS = [
        AllowlistPattern(
            pattern=r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
            pattern_type="regex",
            scope="global",
            reason="UUID format",
        ),
        AllowlistPattern(
            pattern=r"^[0-9a-f]{40}$",
            pattern_type="regex",
            scope="global",
            reason="SHA1 hash (likely git commit)",
        ),
        AllowlistPattern(
            pattern=r"^[0-9a-f]{64}$",
            pattern_type="regex",
            scope="global",
            reason="SHA256 hash",
        ),
        AllowlistPattern(
            pattern=r"^[0-9a-f]{32}$",
            pattern_type="regex",
            scope="global",
            reason="MD5 hash",
        ),
        AllowlistPattern(
            pattern="YOUR_API_KEY",
            pattern_type="literal",
            scope="global",
            reason="Placeholder value",
        ),
        AllowlistPattern(
            pattern="REPLACE_ME",
            pattern_type="literal",
            scope="global",
            reason="Placeholder value",
        ),
        AllowlistPattern(
            pattern="CHANGEME",
            pattern_type="literal",
            scope="global",
            reason="Placeholder value",
        ),
        AllowlistPattern(
            pattern="your-api-key-here",
            pattern_type="literal",
            scope="global",
            reason="Placeholder value",
        ),
        AllowlistPattern(
            pattern="insert-key-here",
            pattern_type="literal",
            scope="global",
            reason="Placeholder value",
        ),
        AllowlistPattern(
            pattern="xxx",
            pattern_type="literal",
            scope="global",
            reason="Placeholder value",
        ),
    ]

    def __init__(self, custom_patterns: list[AllowlistPattern] | None = None):
        """
        Initialize allowlist manager.

        Args:
            custom_patterns: Additional patterns to include.
        """
        self.patterns = list(self.BUILTIN_PATTERNS)
        if custom_patterns:
            self.patterns.extend(custom_patterns)

    def is_allowlisted(self, text: str, file_path: str | None = None) -> tuple[bool, str]:
        """
        Check if text matches any allowlist pattern.

        Args:
            text: Text to check against patterns.
            file_path: Optional file path for scope checking.

        Returns:
            Tuple of (is_allowed, reason).
        """
        for pattern in self.patterns:
            # Check scope applicability
            if not self._scope_applies(pattern.scope, file_path):
                continue

            if pattern.matches(text, file_path):
                return True, pattern.reason

        return False, ""

    def add_pattern(self, pattern: AllowlistPattern) -> None:
        """
        Add a custom pattern to the allowlist.

        Args:
            pattern: Pattern to add.
        """
        self.patterns.append(pattern)

    def load_from_config(self, config_path: str) -> None:
        """
        Load patterns from a YAML configuration file.

        Expected format:
        ```yaml
        allowlist:
          - pattern: "^secret_.*"
            pattern_type: regex
            scope: global
            reason: "Internal naming convention"
        ```

        Args:
            config_path: Path to YAML configuration file.
        """
        try:
            with open(config_path) as f:
                config = yaml.safe_load(f)

            if not config or "allowlist" not in config:
                return

            for item in config["allowlist"]:
                pattern = AllowlistPattern(
                    pattern=item["pattern"],
                    pattern_type=item.get("pattern_type", "literal"),
                    scope=item.get("scope", "global"),
                    reason=item.get("reason", "Custom allowlist pattern"),
                )
                self.add_pattern(pattern)
        except (OSError, yaml.YAMLError):
            # Log error but don't fail
            pass

    def _scope_applies(self, scope: str, file_path: str | None) -> bool:
        """Check if a pattern scope applies to the given context."""
        # Global scope always applies
        if scope == "global":
            return True

        # File-specific scope requires matching path
        if scope == "file" and file_path:
            return True  # Would need pattern to include file restriction

        # Org/repo scopes would need additional context
        # For now, treat as global
        return True


class SecretDetectionPipeline:
    """
    Main pipeline for enhanced secret detection.

    Orchestrates entropy calculation, context analysis, and allowlist
    checking to filter findings and reduce false positives.
    """

    # Severity ordering for adjustment
    SEVERITY_ORDER = [
        Severity.INFO,
        Severity.LOW,
        Severity.MEDIUM,
        Severity.HIGH,
        Severity.CRITICAL,
    ]

    def __init__(
        self,
        entropy_threshold: float = 5.0,
        allowlist_patterns: list[AllowlistPattern] | None = None,
        use_ml_filtering: bool = True,
        ml_model_path: str | None = None,
    ):
        """
        Initialize the secret detection pipeline.

        Args:
            entropy_threshold: Minimum entropy to consider as potential secret.
            allowlist_patterns: Custom allowlist patterns.
            use_ml_filtering: Enable ML-based false positive filtering.
            ml_model_path: Path to ML model. If None, uses default location.
        """
        self.entropy_calc = EntropyCalculator(entropy_threshold)
        self.context_analyzer = ContextAnalyzer()
        self.allowlist = AllowlistManager(allowlist_patterns)
        self.use_ml_filtering = use_ml_filtering

        # Initialize ML classifier if enabled
        self.ml_classifier = None
        if use_ml_filtering:
            try:
                from .ml_features import MLSecretClassifier

                self.ml_classifier = MLSecretClassifier(model_path=ml_model_path)
            except Exception as e:
                # Disable ML filtering if initialization fails
                print(f"Warning: ML filtering disabled due to initialization error: {e}")
                self.use_ml_filtering = False

    def analyze_finding(
        self, finding: SecurityFinding, file_content: str | None = None
    ) -> SecretAnalysisResult:
        """
        Analyze a single finding through the pipeline.

        Applies entropy filtering, context analysis, and allowlist checking.

        Args:
            finding: Security finding to analyze.
            file_content: Optional full file content for deeper analysis.

        Returns:
            SecretAnalysisResult with analysis details.
        """
        context_flags = []
        filter_reason = None
        is_filtered = False
        adjusted_severity = finding.severity

        # Extract the secret value from the finding
        secret_value = self._extract_secret_value(finding)

        # Step 1: Calculate entropy
        entropy_score = self.entropy_calc.calculate_entropy(secret_value)

        # Step 2: Check entropy threshold (AC1: Entropy below 5.0 MUST NOT be flagged)
        should_flag, reason = self.entropy_calc.should_flag(secret_value)
        if not should_flag:
            is_filtered = True
            filter_reason = reason
            context_flags.append(f"low_entropy:{entropy_score:.2f}")
            return SecretAnalysisResult(
                original_finding=finding,
                is_filtered=is_filtered,
                filter_reason=filter_reason,
                adjusted_severity=adjusted_severity,
                entropy_score=entropy_score,
                context_flags=context_flags,
            )

        # Step 3: Check allowlist (AC2: UUIDs, commit hashes MUST be filtered)
        is_allowed, allowlist_reason = self.allowlist.is_allowlisted(
            secret_value, finding.file_path
        )
        if is_allowed:
            is_filtered = True
            filter_reason = f"Allowlisted: {allowlist_reason}"
            context_flags.append("allowlisted")
            return SecretAnalysisResult(
                original_finding=finding,
                is_filtered=is_filtered,
                filter_reason=filter_reason,
                adjusted_severity=adjusted_severity,
                entropy_score=entropy_score,
                context_flags=context_flags,
            )

        # Step 4: Apply ML filtering (if enabled)
        if self.use_ml_filtering and self.ml_classifier:
            # Extract context for ML classifier
            ml_context = finding.code_snippet if file_content is None else file_content

            is_secret, ml_confidence, ml_metadata = self.ml_classifier.classify(
                text=secret_value, context=ml_context, file_path=finding.file_path
            )

            # If ML classifier says it's NOT a secret with high confidence, filter it
            if not is_secret and ml_confidence < 0.3:
                is_filtered = True
                filter_reason = (
                    f"ML classifier: likely false positive (confidence: {ml_confidence:.2f})"
                )
                context_flags.append(f"ml_filtered:conf={ml_confidence:.2f}")

                # Add ML metadata to context flags
                if "stage1_reasoning" in ml_metadata:
                    context_flags.extend(
                        [f"ml_s1:{r}" for r in ml_metadata["stage1_reasoning"][:2]]
                    )

                return SecretAnalysisResult(
                    original_finding=finding,
                    is_filtered=is_filtered,
                    filter_reason=filter_reason,
                    adjusted_severity=adjusted_severity,
                    entropy_score=entropy_score,
                    context_flags=context_flags,
                )

            # Add ML confidence to context flags
            context_flags.append(f"ml_confidence:{ml_confidence:.2f}")
            if ml_metadata.get("ml_enabled"):
                context_flags.append("ml_enabled")

        # Step 5: Analyze context (AC3: Test file findings MUST have reduced severity)
        context_result = self.context_analyzer.analyze(finding, file_content)
        context_flags.extend(context_result.context_flags)

        # Step 6: Adjust severity based on context
        if context_result.severity_reduction > 0:
            adjusted_severity = self._reduce_severity(
                finding.severity, context_result.severity_reduction
            )

        return SecretAnalysisResult(
            original_finding=finding,
            is_filtered=is_filtered,
            filter_reason=filter_reason,
            adjusted_severity=adjusted_severity,
            entropy_score=entropy_score,
            context_flags=context_flags,
        )

    def filter_findings(self, findings: list[SecurityFinding]) -> list[SecretAnalysisResult]:
        """
        Filter all findings through the pipeline.

        Args:
            findings: List of security findings to analyze.

        Returns:
            List of SecretAnalysisResult for each finding.
        """
        results = []
        for finding in findings:
            result = self.analyze_finding(finding)
            results.append(result)
        return results

    def get_filtered_findings(self, findings: list[SecurityFinding]) -> list[SecurityFinding]:
        """
        Return only findings that pass the pipeline (not filtered out).

        Also applies severity adjustments to findings.

        Args:
            findings: List of security findings to process.

        Returns:
            List of findings that passed the pipeline with adjusted severities.
        """
        results = self.filter_findings(findings)
        filtered_findings = []

        for result in results:
            if not result.is_filtered:
                # Create a copy with adjusted severity
                finding = result.original_finding
                # Update severity if adjusted
                if result.adjusted_severity != finding.severity:
                    # Create updated finding with new severity
                    # Note: In production, you might want to create a new finding
                    # or use a copy mechanism
                    finding.severity = result.adjusted_severity
                    finding.metadata["original_severity"] = result.original_finding.severity.value
                    finding.metadata["severity_adjusted"] = True
                    finding.metadata["adjustment_context"] = result.context_flags

                filtered_findings.append(finding)

        return filtered_findings

    def _extract_secret_value(self, finding: SecurityFinding) -> str:
        """
        Extract the potential secret value from a finding.

        Looks in common locations for the secret value.
        """
        # Check metadata for explicit value
        if "secret_value" in finding.metadata:
            return finding.metadata["secret_value"]

        if "value" in finding.metadata:
            return finding.metadata["value"]

        # Try to extract from code snippet
        code = finding.code_snippet

        # Match quoted strings
        patterns = [
            r"['\"]([^'\"]+)['\"]",  # Single or double quoted
            r"=\s*([^\s;,]+)",  # Assignment value
        ]

        for pattern in patterns:
            matches = re.findall(pattern, code)
            if matches:
                # Return the longest match (likely the secret)
                return max(matches, key=len)

        # Fallback to full code snippet
        return code

    def _reduce_severity(self, severity: Severity, levels: int) -> Severity:
        """
        Reduce severity by specified number of levels.

        Args:
            severity: Current severity level.
            levels: Number of levels to reduce.

        Returns:
            Reduced severity, minimum is INFO.
        """
        try:
            current_index = self.SEVERITY_ORDER.index(severity)
        except ValueError:
            return severity

        new_index = max(0, current_index - levels)
        return self.SEVERITY_ORDER[new_index]
