"""
Git Repository Connector for Vantage Security Platform.

This module implements GitHub repository integration including:
- Clone repository with authentication (PAT or OAuth token)
- Branch/tag selection
- Private repository support
- Webhook event handling for auto-scan on push
- Cleanup cloned repositories
"""

import asyncio
import hashlib
import hmac
import re
import secrets
import shutil
from datetime import datetime
from pathlib import Path
from uuid import uuid4

from pydantic import BaseModel, Field, field_validator

from vantage_core.security.api.db_models import RepositoryProvider


# Configuration
class GitHubConfig:
    """GitHub connector configuration."""

    CLONE_TIMEOUT_SECONDS: int = 60
    MAX_REPO_SIZE_MB: int = 500
    CLEANUP_AFTER_HOURS: int = 1

    # Rate limit handling
    RATE_LIMIT_RETRY_ATTEMPTS: int = 3
    RATE_LIMIT_BACKOFF_BASE: int = 60  # seconds

    # API endpoints
    GITHUB_API_URL: str = "https://api.github.com"
    GITHUB_CLONE_URL: str = "https://github.com"

    # Storage
    CLONE_BASE_PATH: str = "/tmp/vantage/repos"


config = GitHubConfig()


# Request/Response Models
class ConnectRepositoryRequest(BaseModel):
    """Request to connect a GitHub repository."""

    url: str = Field(..., description="GitHub repository URL")
    access_token: str | None = Field(None, description="PAT or OAuth token for private repos")
    default_branch: str = Field("main", description="Default branch to scan")

    @field_validator("url")
    @classmethod
    def validate_github_url(cls, v: str) -> str:
        """Validate and normalize GitHub URL."""
        v = v.strip()

        # Support both HTTPS and shorthand formats
        patterns = [
            r"^https://github\.com/([^/]+)/([^/]+?)(?:\.git)?$",
            r"^git@github\.com:([^/]+)/([^/]+?)(?:\.git)?$",
            r"^([^/]+)/([^/]+)$",  # owner/repo shorthand
        ]

        for pattern in patterns:
            match = re.match(pattern, v)
            if match:
                owner, repo = match.groups()
                # Normalize to HTTPS URL
                return f"https://github.com/{owner}/{repo}"

        raise ValueError(
            "Invalid GitHub URL. Expected: https://github.com/owner/repo " "or owner/repo"
        )


class ConnectRepositoryResponse(BaseModel):
    """Response from repository connection."""

    repository_id: str
    name: str
    owner: str
    url: str
    default_branch: str
    is_private: bool
    webhook_secret: str | None = None


class ScanRepositoryRequest(BaseModel):
    """Request to scan a repository."""

    branch: str | None = None
    tag: str | None = None
    commit: str | None = Field(None, pattern=r"^[a-f0-9]{40}$")

    @field_validator("commit")
    @classmethod
    def validate_commit(cls, v: str | None) -> str | None:
        """Validate commit SHA format."""
        if v and not re.match(r"^[a-f0-9]{40}$", v):
            raise ValueError("Invalid commit SHA. Expected 40 character hex string")
        return v


class ScanRepositoryResponse(BaseModel):
    """Response from repository scan trigger."""

    scan_id: str
    repository_id: str
    ref: str
    commit: str
    status: str = "queued"


class RepositoryInfo(BaseModel):
    """Repository information from GitHub API."""

    id: int
    name: str
    full_name: str
    owner: str
    private: bool
    default_branch: str
    size_kb: int
    clone_url: str
    updated_at: datetime


class WebhookEvent(BaseModel):
    """GitHub webhook event."""

    event_type: str
    delivery_id: str
    repository_id: str
    repository_name: str
    ref: str
    before: str
    after: str
    pusher: str
    commits: list[dict]


class GitHubService:
    """
    GitHub repository connector service.

    Handles repository cloning, webhook processing, and integration
    with the scan pipeline.
    """

    def __init__(self):
        """Initialize GitHub service."""
        # In-memory storage for development
        self._repositories: dict[str, dict] = {}
        self._webhook_secrets: dict[str, str] = {}
        self._cloned_paths: dict[str, Path] = {}

        # Ensure clone directory exists
        Path(config.CLONE_BASE_PATH).mkdir(parents=True, exist_ok=True)

    async def connect_repository(
        self, user_id: str, request: ConnectRepositoryRequest
    ) -> ConnectRepositoryResponse:
        """
        Connect a GitHub repository.

        Args:
            user_id: User identifier
            request: Connection request

        Returns:
            Repository connection response
        """
        # Parse URL to extract owner/repo
        match = re.match(r"https://github\.com/([^/]+)/([^/]+)", request.url)
        if not match:
            raise ValueError("Invalid GitHub URL")

        owner, name = match.groups()

        # Check if already connected for this user
        for repo_id, repo in self._repositories.items():
            if repo["user_id"] == user_id and repo["owner"] == owner and repo["name"] == name:
                raise ValueError("Repository already connected")

        # Get repository info from GitHub API
        repo_info = await self._get_repository_info(owner, name, request.access_token)

        # Check repository size
        if repo_info.size_kb > config.MAX_REPO_SIZE_MB * 1024:
            raise ValueError(
                f"Repository size ({repo_info.size_kb // 1024}MB) exceeds "
                f"maximum ({config.MAX_REPO_SIZE_MB}MB)"
            )

        # Generate webhook secret
        webhook_secret = secrets.token_urlsafe(32)

        # Create repository record
        repo_id = str(uuid4())
        self._repositories[repo_id] = {
            "id": repo_id,
            "user_id": user_id,
            "provider": RepositoryProvider.GITHUB.value,
            "provider_repo_id": str(repo_info.id),
            "url": request.url,
            "name": name,
            "owner": owner,
            "default_branch": request.default_branch or repo_info.default_branch,
            "is_private": repo_info.private,
            "access_token": request.access_token,  # Encrypt in production
            "webhook_secret": webhook_secret,
            "created_at": datetime.utcnow(),
        }

        self._webhook_secrets[repo_id] = webhook_secret

        return ConnectRepositoryResponse(
            repository_id=repo_id,
            name=name,
            owner=owner,
            url=request.url,
            default_branch=request.default_branch or repo_info.default_branch,
            is_private=repo_info.private,
            webhook_secret=webhook_secret,
        )

    async def _get_repository_info(
        self, owner: str, name: str, access_token: str | None = None
    ) -> RepositoryInfo:
        """
        Get repository information from GitHub API.

        Args:
            owner: Repository owner
            name: Repository name
            access_token: Optional access token

        Returns:
            Repository information
        """
        import aiohttp

        headers = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "Vantage-Security-Platform",
        }

        if access_token:
            headers["Authorization"] = f"token {access_token}"

        url = f"{config.GITHUB_API_URL}/repos/{owner}/{name}"

        async with aiohttp.ClientSession() as session:
            for attempt in range(config.RATE_LIMIT_RETRY_ATTEMPTS):
                try:
                    async with session.get(url, headers=headers) as response:
                        # Handle rate limiting
                        if response.status == 403:
                            remaining = int(response.headers.get("X-RateLimit-Remaining", 0))
                            if remaining == 0:
                                reset_time = int(response.headers.get("X-RateLimit-Reset", 0))
                                wait_time = min(
                                    reset_time - int(datetime.utcnow().timestamp()),
                                    config.RATE_LIMIT_BACKOFF_BASE * (2**attempt),
                                )
                                if wait_time > 0 and attempt < config.RATE_LIMIT_RETRY_ATTEMPTS - 1:
                                    await asyncio.sleep(wait_time)
                                    continue

                            raise ValueError("GitHub API rate limit exceeded")

                        if response.status == 404:
                            raise ValueError("Repository not found or not accessible")

                        if response.status == 401:
                            raise ValueError("Invalid or expired access token")

                        if response.status != 200:
                            raise ValueError(f"GitHub API error: {response.status}")

                        data = await response.json()

                        return RepositoryInfo(
                            id=data["id"],
                            name=data["name"],
                            full_name=data["full_name"],
                            owner=data["owner"]["login"],
                            private=data["private"],
                            default_branch=data["default_branch"],
                            size_kb=data["size"],
                            clone_url=data["clone_url"],
                            updated_at=datetime.fromisoformat(
                                data["updated_at"].replace("Z", "+00:00")
                            ),
                        )

                except aiohttp.ClientError as e:
                    if attempt == config.RATE_LIMIT_RETRY_ATTEMPTS - 1:
                        raise ValueError(f"Failed to connect to GitHub: {str(e)}")
                    await asyncio.sleep(config.RATE_LIMIT_BACKOFF_BASE * (2**attempt))

        raise ValueError("Failed to get repository information")

    async def trigger_scan(
        self, repository_id: str, user_id: str, request: ScanRepositoryRequest
    ) -> ScanRepositoryResponse:
        """
        Trigger a scan on a repository.

        Args:
            repository_id: Repository identifier
            user_id: User identifier
            request: Scan request

        Returns:
            Scan response
        """
        repo = self._repositories.get(repository_id)
        if not repo:
            raise ValueError("Repository not found")

        if repo["user_id"] != user_id:
            raise PermissionError("Not authorized to scan this repository")

        # Determine ref to scan
        if request.commit:
            ref = request.commit
        elif request.tag:
            ref = f"refs/tags/{request.tag}"
        elif request.branch:
            ref = f"refs/heads/{request.branch}"
        else:
            ref = f"refs/heads/{repo['default_branch']}"

        # Clone repository
        clone_path = await self.clone_repository(repository_id, ref, repo.get("access_token"))

        # Get commit SHA
        commit = await self._get_head_commit(clone_path)

        # Create scan record
        scan_id = str(uuid4())

        # TODO: Queue scan job with pipeline orchestrator

        return ScanRepositoryResponse(
            scan_id=scan_id,
            repository_id=repository_id,
            ref=ref,
            commit=commit,
            status="queued",
        )

    async def clone_repository(
        self, repository_id: str, ref: str = "HEAD", access_token: str | None = None
    ) -> Path:
        """
        Clone repository to local storage.

        Args:
            repository_id: Repository identifier
            ref: Git reference (branch, tag, or commit)
            access_token: Optional access token

        Returns:
            Path to cloned repository
        """
        repo = self._repositories.get(repository_id)
        if not repo:
            raise ValueError("Repository not found")

        # Build clone URL with authentication
        clone_url = repo["url"]
        if access_token:
            # Insert token into URL
            clone_url = clone_url.replace("https://", f"https://x-access-token:{access_token}@")

        # Create clone directory
        clone_id = f"{repository_id}_{uuid4().hex[:8]}"
        clone_path = Path(config.CLONE_BASE_PATH) / clone_id
        clone_path.mkdir(parents=True, exist_ok=True)

        try:
            # Clone with depth 1 for performance
            cmd = ["git", "clone", "--depth", "1", "--single-branch"]

            # Handle specific refs
            if ref.startswith("refs/heads/"):
                branch = ref.replace("refs/heads/", "")
                # Validate branch name format
                if not re.match(r"^[a-zA-Z0-9._/-]+$", branch):
                    raise ValueError(f"Invalid branch name format: {branch}")
                cmd.extend(["--branch", branch])
            elif ref.startswith("refs/tags/"):
                tag = ref.replace("refs/tags/", "")
                # Validate tag name format
                if not re.match(r"^[a-zA-Z0-9._/-]+$", tag):
                    raise ValueError(f"Invalid tag name format: {tag}")
                cmd.extend(["--branch", tag])
            elif len(ref) == 40:  # Commit SHA
                # For specific commits, clone then checkout
                pass

            cmd.extend([clone_url, str(clone_path)])

            # Run clone command
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(clone_path.parent),
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(), timeout=config.CLONE_TIMEOUT_SECONDS
                )
            except asyncio.TimeoutError:
                process.kill()
                await process.communicate()
                raise ValueError(f"Clone timeout exceeded ({config.CLONE_TIMEOUT_SECONDS}s)")

            if process.returncode != 0:
                error = stderr.decode().strip()

                # Clean up failed clone
                if clone_path.exists():
                    shutil.rmtree(clone_path)

                if "Authentication failed" in error:
                    raise ValueError("Authentication failed. Check your access token.")
                elif "not found" in error.lower():
                    raise ValueError("Repository not found")
                else:
                    raise ValueError(f"Clone failed: {error}")

            # If specific commit, checkout
            if len(ref) == 40:
                # Validate ref format to prevent command injection
                if not re.match(r"^[a-fA-F0-9]{40}$", ref):
                    raise ValueError(f"Invalid commit SHA format: {ref}")
                checkout_cmd = ["git", "checkout", ref]
                checkout_process = await asyncio.create_subprocess_exec(
                    *checkout_cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(clone_path),
                )
                await checkout_process.communicate()

                if checkout_process.returncode != 0:
                    raise ValueError(f"Failed to checkout commit {ref}")

            # Track cloned path for cleanup
            self._cloned_paths[clone_id] = clone_path

            return clone_path

        except Exception:
            # Clean up on error
            if clone_path.exists():
                shutil.rmtree(clone_path)
            raise

    async def _get_head_commit(self, repo_path: Path) -> str:
        """Get HEAD commit SHA."""
        process = await asyncio.create_subprocess_exec(
            "git",
            "rev-parse",
            "HEAD",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(repo_path),
        )
        stdout, _ = await process.communicate()
        return stdout.decode().strip()

    async def handle_webhook(
        self, event_type: str, delivery_id: str, signature: str, payload: bytes
    ) -> str | None:
        """
        Handle GitHub webhook event.

        Args:
            event_type: GitHub event type (push, etc.)
            delivery_id: Delivery identifier
            signature: HMAC-SHA256 signature
            payload: Raw payload bytes

        Returns:
            Scan ID if scan was triggered, None otherwise
        """
        import json

        # Parse payload
        try:
            data = json.loads(payload)
        except json.JSONDecodeError:
            raise ValueError("Invalid JSON payload")

        # Get repository info
        repo_data = data.get("repository", {})
        repo_full_name = repo_data.get("full_name", "")

        if not repo_full_name:
            raise ValueError("Missing repository information")

        # Find matching repository
        matching_repo = None
        for repo_id, repo in self._repositories.items():
            if f"{repo['owner']}/{repo['name']}" == repo_full_name:
                matching_repo = (repo_id, repo)
                break

        if not matching_repo:
            # Repository not connected
            return None

        repo_id, repo = matching_repo

        # Verify webhook signature
        webhook_secret = repo.get("webhook_secret")
        if webhook_secret:
            expected_sig = hmac.new(webhook_secret.encode(), payload, hashlib.sha256).hexdigest()

            # Signature format: sha256=xxx
            provided_sig = signature.replace("sha256=", "")

            if not hmac.compare_digest(expected_sig, provided_sig):
                raise ValueError("Invalid webhook signature")

        # Handle push event
        if event_type == "push":
            ref = data.get("ref", "")
            after = data.get("after", "")

            # Only trigger scan for default branch
            if ref == f"refs/heads/{repo['default_branch']}":
                # Check if not a delete (all zeros)
                if after != "0" * 40:
                    request = ScanRepositoryRequest(branch=repo["default_branch"])

                    response = await self.trigger_scan(repo_id, repo["user_id"], request)

                    return response.scan_id

        return None

    async def get_repository(self, repository_id: str, user_id: str) -> dict:
        """Get repository details."""
        repo = self._repositories.get(repository_id)
        if not repo:
            raise ValueError("Repository not found")

        if repo["user_id"] != user_id:
            raise PermissionError("Not authorized to access this repository")

        return repo

    async def list_repositories(self, user_id: str) -> list[dict]:
        """List user's connected repositories."""
        return [repo for repo in self._repositories.values() if repo["user_id"] == user_id]

    async def disconnect_repository(self, repository_id: str, user_id: str) -> bool:
        """
        Disconnect a repository.

        Args:
            repository_id: Repository identifier
            user_id: User identifier

        Returns:
            True if disconnected
        """
        repo = self._repositories.get(repository_id)
        if not repo:
            raise ValueError("Repository not found")

        if repo["user_id"] != user_id:
            raise PermissionError("Not authorized to disconnect this repository")

        # Clean up any cloned repositories
        to_remove = []
        for clone_id, path in self._cloned_paths.items():
            if clone_id.startswith(repository_id):
                if path.exists():
                    shutil.rmtree(path)
                to_remove.append(clone_id)

        for clone_id in to_remove:
            del self._cloned_paths[clone_id]

        # Remove webhook secret
        if repository_id in self._webhook_secrets:
            del self._webhook_secrets[repository_id]

        # Remove repository record
        del self._repositories[repository_id]

        return True

    async def cleanup_clone(self, clone_id: str):
        """
        Clean up a cloned repository.

        Args:
            clone_id: Clone identifier
        """
        path = self._cloned_paths.get(clone_id)
        if path and path.exists():
            shutil.rmtree(path)

        if clone_id in self._cloned_paths:
            del self._cloned_paths[clone_id]

    async def cleanup_all_clones(self):
        """Clean up all cloned repositories."""
        for clone_id in list(self._cloned_paths.keys()):
            await self.cleanup_clone(clone_id)


# Global GitHub service instance
github_service = GitHubService()
