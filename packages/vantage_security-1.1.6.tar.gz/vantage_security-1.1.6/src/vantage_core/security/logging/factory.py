"""
Logger factory for Vantage security scanner.

Provides centralized logger creation with consistent configuration
across all scanner components using structlog for high-performance
structured logging.
"""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from typing import Any

import structlog

from vantage_core.security.logging.categories import LogCategory


class LoggerFactory:
    """
    Factory for creating configured loggers.

    Provides centralized logger creation with consistent
    configuration across all scanner components.

    Example:
        # Configure once at startup
        LoggerFactory.configure(log_level="INFO", json_output=True)

        # Get logger for a component
        logger = LoggerFactory.get_logger(LogCategory.SCANNER_ANALYSIS)
        logger.info("starting_analysis", file_count=42)
    """

    _configured: bool = False
    _loggers: dict[str, structlog.BoundLogger] = {}
    _log_level: str = "WARNING"  # Changed from INFO for less verbose default
    _json_output: bool = False  # Changed from True for human-readable default
    _log_file: str | None = None
    _audit_file: str | None = None

    @classmethod
    def configure(
        cls,
        log_level: str | None = None,
        json_output: bool | None = None,
        log_file: str | None = None,
        audit_file: str | None = None,
        correlation_id: str | None = None,
    ) -> None:
        """
        Configure the logging system.

        Must be called once at application startup before
        creating any loggers.

        Args:
            log_level: Minimum log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            json_output: Use JSON format (True) or console format (False)
            log_file: Optional file path for log output
            audit_file: Optional file path for audit logs
            correlation_id: Optional correlation ID for request tracing
        """
        # Allow environment variable overrides
        # Default to WARNING for less verbose output in CLI mode
        cls._log_level = log_level or os.environ.get("MIMIC_LOG_LEVEL", "WARNING")
        cls._json_output = (
            json_output
            if json_output is not None
            else (os.environ.get("MIMIC_LOG_JSON", "false").lower() == "true")
        )
        cls._log_file = log_file or os.environ.get("MIMIC_LOG_FILE")
        cls._audit_file = audit_file or os.environ.get("MIMIC_AUDIT_FILE")

        # Build processor chain
        processors: list[Any] = [
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.TimeStamper(fmt="iso"),
            cls._add_service_context,
        ]

        if correlation_id:
            structlog.contextvars.bind_contextvars(correlation_id=correlation_id)

        # Configure output format
        if cls._json_output:
            processors.append(structlog.processors.JSONRenderer())
            # Always use stdlib logger factory for JSON to ensure string output
            logger_factory = structlog.stdlib.LoggerFactory()

            # Configure root logger for stdout if no file specified
            if not cls._log_file:
                root_logger = logging.getLogger()
                root_logger.setLevel(getattr(logging, cls._log_level.upper()))
                console_handler = logging.StreamHandler(sys.stdout)
                console_handler.setFormatter(logging.Formatter("%(message)s"))
                root_logger.addHandler(console_handler)
        else:
            # If logging to file, disable colors for cleanliness
            colors = not bool(cls._log_file)
            processors.append(structlog.dev.ConsoleRenderer(colors=colors))

            if cls._log_file:
                logger_factory = structlog.stdlib.LoggerFactory()
                # Add console handler since stdlib won't print to stdout by default
                console_handler = logging.StreamHandler(sys.stdout)
                console_handler.setFormatter(logging.Formatter("%(message)s"))
                logging.getLogger().addHandler(console_handler)
            else:
                logger_factory = structlog.PrintLoggerFactory()

        # Configure file handler if specified
        if cls._log_file:
            cls._setup_file_handler(cls._log_file, cls._log_level)

        # Configure structlog
        structlog.configure(
            cache_logger_on_first_use=True,
            wrapper_class=structlog.make_filtering_bound_logger(
                getattr(logging, cls._log_level.upper())
            ),
            processors=processors,
            logger_factory=logger_factory,
        )

        cls._configured = True
        cls._loggers.clear()  # Clear cached loggers on reconfigure

    @classmethod
    def get_logger(
        cls, category: LogCategory | str, **initial_context: Any
    ) -> structlog.BoundLogger:
        """
        Get a logger for the specified category.

        Args:
            category: Log category for filtering
            initial_context: Initial context values to bind

        Returns:
            Configured BoundLogger instance

        Example:
            logger = LoggerFactory.get_logger(
                LogCategory.SCANNER_ANALYSIS,
                framework="langchain"
            )
        """
        if not cls._configured:
            cls.configure()

        category_str = category.value if isinstance(category, LogCategory) else category

        if category_str not in cls._loggers:
            logger = structlog.get_logger(category_str)
            cls._loggers[category_str] = logger.bind(category=category_str)

        if initial_context:
            return cls._loggers[category_str].bind(**initial_context)

        return cls._loggers[category_str]

    @classmethod
    def bind_context(cls, **context: Any) -> None:
        """
        Bind context variables that will be included in all log entries.

        Args:
            **context: Key-value pairs to bind to all loggers

        Example:
            LoggerFactory.bind_context(scan_id="abc123", user="admin")
        """
        structlog.contextvars.bind_contextvars(**context)

    @classmethod
    def clear_context(cls) -> None:
        """Clear all bound context variables."""
        structlog.contextvars.clear_contextvars()

    @classmethod
    def reset(cls) -> None:
        """
        Reset the logger factory to unconfigured state.

        Useful for testing or reconfiguration.
        """
        cls._configured = False
        cls._loggers.clear()
        cls.clear_context()

    @classmethod
    def set_level(cls, level: str, category: str | None = None) -> None:
        """
        Change log level at runtime.

        Args:
            level: New log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            category: Optional specific category to change (not yet implemented)
        """
        cls._log_level = level.upper()
        # Reconfigure to apply new level
        cls.configure(
            log_level=cls._log_level,
            json_output=cls._json_output,
            log_file=cls._log_file,
            audit_file=cls._audit_file,
        )

    @staticmethod
    def _add_service_context(
        logger: logging.Logger, method_name: str, event_dict: dict[str, Any]
    ) -> dict[str, Any]:
        """Add service context to event dict."""
        event_dict["service"] = "vantage"
        event_dict["version"] = "1.0.0"  # Should be imported from package
        return event_dict

    @classmethod
    def _setup_file_handler(cls, file_path: str, log_level: str) -> None:
        """
        Setup file handler for standard library logging.

        This ensures that structlog output also goes to file.
        """
        # Ensure directory exists
        log_dir = Path(file_path).parent
        if log_dir and not log_dir.exists():
            log_dir.mkdir(parents=True, exist_ok=True)

        # Configure root logger for file output
        root_logger = logging.getLogger()
        root_logger.setLevel(getattr(logging, log_level.upper()))

        # Add file handler
        file_handler = logging.FileHandler(file_path, encoding="utf-8")
        file_handler.setLevel(getattr(logging, log_level.upper()))

        # Use simple format for file (structlog will handle structure)
        formatter = logging.Formatter("%(message)s")
        file_handler.setFormatter(formatter)

        root_logger.addHandler(file_handler)


def get_logger(category: LogCategory | str, **initial_context: Any) -> structlog.BoundLogger:
    """
    Convenience function to get a logger.

    Args:
        category: Log category for filtering
        initial_context: Initial context values to bind

    Returns:
        Configured BoundLogger instance
    """
    return LoggerFactory.get_logger(category, **initial_context)
