"""
Rule registry for efficient rule lookup and filtering.

This module provides a registry for loaded rules with efficient
indexing by language, severity, and metadata tags.
"""

from __future__ import annotations

import logging
from collections.abc import Callable

from vantage_core.security.rules.schema import Rule, Severity

logger = logging.getLogger(__name__)


class RuleRegistry:
    """
    Registry for loaded rules with filtering support.

    Provides efficient lookup by ID, language, severity,
    and metadata tags.

    Example:
        registry = RuleRegistry()

        # Register rules
        for rule in rules:
            registry.register(rule)

        # Query rules
        python_rules = registry.get_rules_for_language("python")
        critical_rules = registry.get_rules_by_severity(Severity.CRITICAL)
        injection_rules = registry.get_rules_by_category("injection")
    """

    def __init__(self):
        self._rules: dict[str, Rule] = {}
        self._by_language: dict[str, list[Rule]] = {}
        self._by_severity: dict[Severity, list[Rule]] = {}
        self._by_category: dict[str, list[Rule]] = {}
        self._by_cwe: dict[str, list[Rule]] = {}
        self._enabled: set[str] = set()  # Track enabled rule IDs

    def register(self, rule: Rule) -> None:
        """
        Register a rule in the registry.

        Args:
            rule: Rule to register
        """
        if rule.id in self._rules:
            logger.warning(f"Overwriting existing rule: {rule.id}")

        self._rules[rule.id] = rule
        self._enabled.add(rule.id)

        # Index by language
        for lang in rule.languages:
            if lang not in self._by_language:
                self._by_language[lang] = []
            self._by_language[lang].append(rule)

        # Index by severity
        if rule.severity not in self._by_severity:
            self._by_severity[rule.severity] = []
        self._by_severity[rule.severity].append(rule)

        # Index by category
        category = rule.get_category()
        if category:
            if category not in self._by_category:
                self._by_category[category] = []
            self._by_category[category].append(rule)

        # Index by CWE
        cwe = rule.get_cwe()
        if cwe:
            if cwe not in self._by_cwe:
                self._by_cwe[cwe] = []
            self._by_cwe[cwe].append(rule)

    def unregister(self, rule_id: str) -> bool:
        """
        Remove a rule from the registry.

        Args:
            rule_id: ID of rule to remove

        Returns:
            True if rule was found and removed
        """
        if rule_id not in self._rules:
            return False

        rule = self._rules[rule_id]
        del self._rules[rule_id]
        self._enabled.discard(rule_id)

        # Remove from indices
        for lang in rule.languages:
            if lang in self._by_language:
                self._by_language[lang] = [r for r in self._by_language[lang] if r.id != rule_id]

        if rule.severity in self._by_severity:
            self._by_severity[rule.severity] = [
                r for r in self._by_severity[rule.severity] if r.id != rule_id
            ]

        category = rule.get_category()
        if category and category in self._by_category:
            self._by_category[category] = [
                r for r in self._by_category[category] if r.id != rule_id
            ]

        cwe = rule.get_cwe()
        if cwe and cwe in self._by_cwe:
            self._by_cwe[cwe] = [r for r in self._by_cwe[cwe] if r.id != rule_id]

        return True

    def register_many(self, rules: list[Rule]) -> int:
        """
        Register multiple rules at once.

        Args:
            rules: List of rules to register

        Returns:
            Number of rules registered
        """
        for rule in rules:
            self.register(rule)
        return len(rules)

    def get_rule(self, rule_id: str) -> Rule | None:
        """
        Get rule by ID.

        Args:
            rule_id: Rule identifier

        Returns:
            Rule or None if not found
        """
        return self._rules.get(rule_id)

    def get_rules_for_language(self, language: str) -> list[Rule]:
        """
        Get all rules applicable to a language.

        Args:
            language: Programming language name

        Returns:
            List of applicable rules
        """
        return [r for r in self._by_language.get(language.lower(), []) if r.id in self._enabled]

    def get_rules_by_severity(self, severity: Severity) -> list[Rule]:
        """
        Get all rules with given severity.

        Args:
            severity: Severity level to filter by

        Returns:
            List of rules with matching severity
        """
        return [r for r in self._by_severity.get(severity, []) if r.id in self._enabled]

    def get_rules_by_category(self, category: str) -> list[Rule]:
        """
        Get all rules in a category.

        Args:
            category: Category name (e.g., "injection", "secrets")

        Returns:
            List of rules in the category
        """
        return [r for r in self._by_category.get(category, []) if r.id in self._enabled]

    def get_rules_by_cwe(self, cwe: str) -> list[Rule]:
        """
        Get all rules for a CWE identifier.

        Args:
            cwe: CWE identifier (e.g., "CWE-89")

        Returns:
            List of rules matching the CWE
        """
        return [r for r in self._by_cwe.get(cwe, []) if r.id in self._enabled]

    def get_taint_rules(self) -> list[Rule]:
        """Get all taint-mode rules."""
        return [r for r in self._rules.values() if r.is_taint_rule and r.id in self._enabled]

    def get_pattern_rules(self) -> list[Rule]:
        """Get all pattern-based rules (non-taint)."""
        return [r for r in self._rules.values() if not r.is_taint_rule and r.id in self._enabled]

    def filter_rules(self, predicate: Callable[[Rule], bool]) -> list[Rule]:
        """
        Get rules matching a custom predicate.

        Args:
            predicate: Function that returns True for matching rules

        Returns:
            List of matching rules
        """
        return [r for r in self._rules.values() if predicate(r) and r.id in self._enabled]

    def enable_rule(self, rule_id: str) -> bool:
        """
        Enable a rule.

        Args:
            rule_id: ID of rule to enable

        Returns:
            True if rule exists and was enabled
        """
        if rule_id in self._rules:
            self._enabled.add(rule_id)
            return True
        return False

    def disable_rule(self, rule_id: str) -> bool:
        """
        Disable a rule.

        Args:
            rule_id: ID of rule to disable

        Returns:
            True if rule exists and was disabled
        """
        if rule_id in self._rules:
            self._enabled.discard(rule_id)
            return True
        return False

    def enable_all(self) -> None:
        """Enable all registered rules."""
        self._enabled = set(self._rules.keys())

    def disable_all(self) -> None:
        """Disable all rules."""
        self._enabled.clear()

    def set_enabled_rules(self, rule_ids: list[str]) -> None:
        """
        Set exactly which rules are enabled.

        Args:
            rule_ids: List of rule IDs to enable (all others disabled)
        """
        self._enabled = {rid for rid in rule_ids if rid in self._rules}

    def set_disabled_rules(self, rule_ids: list[str]) -> None:
        """
        Disable specific rules (all others enabled).

        Args:
            rule_ids: List of rule IDs to disable
        """
        self._enabled = {rid for rid in self._rules.keys() if rid not in rule_ids}

    def is_enabled(self, rule_id: str) -> bool:
        """Check if a rule is enabled."""
        return rule_id in self._enabled

    @property
    def all_rules(self) -> list[Rule]:
        """Get all registered rules (regardless of enabled state)."""
        return list(self._rules.values())

    @property
    def enabled_rules(self) -> list[Rule]:
        """Get all enabled rules."""
        return [r for r in self._rules.values() if r.id in self._enabled]

    @property
    def rule_count(self) -> int:
        """Get total number of registered rules."""
        return len(self._rules)

    @property
    def enabled_count(self) -> int:
        """Get number of enabled rules."""
        return len(self._enabled)

    @property
    def languages(self) -> list[str]:
        """Get list of all languages with rules."""
        return list(self._by_language.keys())

    @property
    def categories(self) -> list[str]:
        """Get list of all categories with rules."""
        return list(self._by_category.keys())

    def get_statistics(self) -> dict:
        """
        Get registry statistics.

        Returns:
            Dictionary with registry statistics
        """
        return {
            "total_rules": len(self._rules),
            "enabled_rules": len(self._enabled),
            "languages": {lang: len(rules) for lang, rules in self._by_language.items()},
            "severities": {sev.value: len(rules) for sev, rules in self._by_severity.items()},
            "categories": {cat: len(rules) for cat, rules in self._by_category.items()},
            "taint_rules": len(self.get_taint_rules()),
            "pattern_rules": len(self.get_pattern_rules()),
        }

    def clear(self) -> None:
        """Clear all registered rules."""
        self._rules.clear()
        self._by_language.clear()
        self._by_severity.clear()
        self._by_category.clear()
        self._by_cwe.clear()
        self._enabled.clear()
