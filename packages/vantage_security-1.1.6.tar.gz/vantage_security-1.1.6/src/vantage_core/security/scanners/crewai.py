"""
CrewAI Security Scanner.

Detects agents, tasks, and crews in CrewAI-based projects
and identifies security-relevant patterns including delegation risks.
"""

import ast
import re
import time
from pathlib import Path

from vantage_core.security.models import (
    AgentCommunication,
    MAASCategory,
    OWASPCategory,
    SecurityAgent,
    SecurityFinding,
    SecurityScanResult,
    SecurityTool,
    Severity,
    ToolCategory,
    TrustLevel,
    VulnerabilityCategory,
)
from vantage_core.security.scanners.base import SecurityScanner


class CrewAISecurityScanner(SecurityScanner):
    """
    Security scanner for CrewAI framework.

    Detects:
    - Agent definitions with roles and goals
    - Crew configurations (sequential/hierarchical)
    - Task definitions and assignments
    - Delegation patterns and chains
    """

    framework_name = "crewai"

    AGENT_PATTERNS = ["Agent"]
    CREW_PATTERNS = ["Crew"]
    TASK_PATTERNS = ["Task"]

    def scan(self, path: Path) -> SecurityScanResult:
        """Scan CrewAI project for security issues."""
        start_time = time.time()
        findings: list[SecurityFinding] = []
        agents: list[SecurityAgent] = []
        communications: list[AgentCommunication] = []

        if path.is_file():
            files = [path]
            yaml_files = []
        else:
            files = list(path.rglob("*.py"))
            # Also scan YAML config files for CrewAI agent definitions
            yaml_files = list(path.rglob("*.yaml")) + list(path.rglob("*.yml"))

        # Scan YAML files for agent definitions (CrewAI config pattern)
        for yaml_path in yaml_files:
            try:
                yaml_agents = self._extract_agents_from_yaml(yaml_path)
                agents.extend(yaml_agents)
            except Exception as e:
                self.logger.warning(
                    "yaml_scan_failed",
                    file_path=str(yaml_path),
                    error=str(e),
                )
                continue

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()

                # Extract agents
                file_agents = self._extract_agents_from_file(file_path, code)
                agents.extend(file_agents)

                # Extract communications (Topology Discovery)
                file_comms = self._extract_communications(file_path, code, file_agents)
                communications.extend(file_comms)

                # Check for vulnerabilities
                findings.extend(self.check_hardcoded_secrets(code, str(file_path)))
                findings.extend(self.check_dangerous_code_patterns(code, str(file_path)))
                findings.extend(self._check_crewai_patterns(code, str(file_path)))

                # Check each agent
                for agent in file_agents:
                    agent_findings = self.get_vulnerabilities(agent)
                    findings.extend(agent_findings)

            except Exception as e:
                # Log but continue with other files
                self.logger.warning(
                    "file_scan_failed",
                    file_path=str(file_path),
                    error=str(e),
                    exc_info=True,
                )
                continue

        # Build communications from YAML agents if we have multiple
        if len(agents) > 1 and not communications:
            communications = self._infer_sequential_topology(agents)

        return self.create_scan_result(
            findings=findings,
            agents=agents,
            frameworks=["crewai"],
            start_time=start_time,
            communications=communications,
        )

    def _extract_communications(
        self, file_path: Path, code: str, agents: list[SecurityAgent]
    ) -> list[AgentCommunication]:
        """
        Extract communication channels between agents.

        Infers topology from:
        1. Crew definitions (agents working together)
        2. Task assignments (flow of work)
        3. Delegation settings
        """
        communications: list[AgentCommunication] = []
        tree = ast.parse(code)

        # Map variable names to agent IDs for resolution
        agent_var_map = {}

        # We need to re-parse agents to get their variable names
        # This is a simplified approach; a full symbol table would be better
        class AgentVarVisitor(ast.NodeVisitor):
            def visit_Assign(self, node):
                try:
                    if isinstance(node.value, ast.Call):
                        func_name = ""
                        if isinstance(node.value.func, ast.Name):
                            func_name = node.value.func.id
                        elif isinstance(node.value.func, ast.Attribute):
                            func_name = node.value.func.attr

                        if func_name == "Agent":
                            # Found an agent assignment
                            for target in node.targets:
                                if isinstance(target, ast.Name):
                                    # Find matching agent by line number
                                    for agent in agents:
                                        if (
                                            hasattr(node.value, "lineno")
                                            and agent.line_number == node.value.lineno
                                        ):
                                            agent_var_map[target.id] = agent.id
                except Exception:
                    # Skip complex assignments that might cause errors
                    pass

        AgentVarVisitor().visit(tree)

        class TopologyVisitor(ast.NodeVisitor):
            def visit_Call(self, node):
                # Check for Crew definition
                func_name = ""
                if isinstance(node.func, ast.Name):
                    func_name = node.func.id
                elif isinstance(node.func, ast.Attribute):
                    func_name = node.func.attr

                if func_name == "Crew":
                    self._process_crew(node)

                # Check for Task definition
                elif func_name == "Task":
                    self._process_task(node)

            def _process_crew(self, node: ast.Call):
                crew_agents = []
                process_type = "sequential"  # Default

                for keyword in node.keywords:
                    if keyword.arg == "agents":
                        if isinstance(keyword.value, ast.List):
                            for elt in keyword.value.elts:
                                if isinstance(elt, ast.Name) and elt.id in agent_var_map:
                                    crew_agents.append(agent_var_map[elt.id])
                    elif keyword.arg == "process":
                        # Try to determine process type
                        if "hierarchical" in ast.dump(keyword.value).lower():
                            process_type = "hierarchical"

                # Create communications based on process
                if len(crew_agents) > 1:
                    if process_type == "sequential":
                        # Sequential: Agent 1 -> Agent 2 -> Agent 3
                        for i in range(len(crew_agents) - 1):
                            communications.append(
                                AgentCommunication(
                                    source_id=crew_agents[i],
                                    target_id=crew_agents[i + 1],
                                    communication_type="sequential_handoff",
                                    bidirectional=False,
                                )
                            )
                    elif process_type == "hierarchical":
                        # Hierarchical: Everyone talks to everyone (simplified)
                        # In reality, they talk to manager, but for blast radius,
                        # we assume full connectivity in the group
                        for i in range(len(crew_agents)):
                            for j in range(len(crew_agents)):
                                if i != j:
                                    communications.append(
                                        AgentCommunication(
                                            source_id=crew_agents[i],
                                            target_id=crew_agents[j],
                                            communication_type="hierarchical_collaboration",
                                            bidirectional=True,
                                        )
                                    )

            def _process_task(self, node: ast.Call):
                # Tasks don't explicitly define flow in CrewAI (it's in the list order),
                # but if we could link tasks to agents, we could refine the graph.
                # For now, Crew-level topology is the strongest signal.
                pass

        TopologyVisitor().visit(tree)

        # Add delegation paths
        for agent in agents:
            if agent.allow_delegation:
                # If agent allows delegation, it can potentially talk to ANY other agent
                # This creates a dense graph. To avoid noise, we might limit this
                # to agents in the same file or crew if we knew it.
                # For now, let's create a "potential_delegation" to all other agents found in this file
                for other_agent in agents:
                    if agent.id != other_agent.id:
                        communications.append(
                            AgentCommunication(
                                source_id=agent.id,
                                target_id=other_agent.id,
                                communication_type="delegation",
                                bidirectional=True,  # Delegation often implies return of result
                                metadata={
                                    "risk": (
                                        "high"
                                        if agent.trust_level < other_agent.trust_level
                                        else "low"
                                    )
                                },
                            )
                        )

        return communications

    def _extract_agents_from_yaml(self, yaml_path: Path) -> list[SecurityAgent]:
        """Extract agent definitions from CrewAI YAML config files.

        CrewAI supports YAML-based agent definitions in agents.yaml files.
        """
        agents: list[SecurityAgent] = []

        try:
            import yaml
        except ImportError:
            return agents

        # Only process files that look like CrewAI agent configs
        if "agent" not in yaml_path.name.lower():
            return agents

        try:
            with open(yaml_path, encoding="utf-8") as f:
                config = yaml.safe_load(f)
        except Exception:
            return agents

        if not isinstance(config, dict):
            return agents

        for agent_id, agent_config in config.items():
            if not isinstance(agent_config, dict):
                continue

            # Check if this looks like a CrewAI agent definition
            if not any(key in agent_config for key in ["role", "goal", "backstory"]):
                continue

            role = agent_config.get("role", agent_id)
            goal = agent_config.get("goal", "")
            backstory = agent_config.get("backstory", "")
            tools = agent_config.get("tools", [])
            allow_delegation = agent_config.get("allow_delegation", False)

            # Build system prompt from config
            system_prompt = f"Role: {role}\nGoal: {goal}\nBackstory: {backstory}"

            # Map tools to SecurityTool objects
            security_tools = []
            for tool_name in tools:
                security_tools.append(
                    SecurityTool(
                        name=tool_name,
                        description=f"CrewAI tool: {tool_name}",
                        categories=[self._infer_tool_category(tool_name)],
                    )
                )

            agent = SecurityAgent(
                id=f"crewai-yaml-{agent_id}",
                name=role,
                framework="crewai",
                trust_level=TrustLevel.INTERNAL,
                tools=security_tools,
                system_prompt=system_prompt,
                role=role,
                goal=goal,
                allow_delegation=allow_delegation,
                file_path=str(yaml_path),
                line_number=1,
                metadata={"source": "yaml", "agent_id": agent_id},
            )
            agents.append(agent)

        return agents

    def _infer_tool_category(self, tool_name: str) -> ToolCategory:
        """Infer tool category from tool name."""
        tool_lower = tool_name.lower()

        if any(kw in tool_lower for kw in ["search", "web", "scrape", "http", "news", "academic"]):
            return ToolCategory.NETWORK
        elif any(kw in tool_lower for kw in ["api", "caller", "endpoint"]):
            return ToolCategory.EXTERNAL_API
        elif any(kw in tool_lower for kw in ["file", "read", "write", "csv", "document", "format"]):
            return ToolCategory.FILE_SYSTEM
        elif any(kw in tool_lower for kw in ["code", "exec", "python", "shell"]):
            return ToolCategory.CODE_EXECUTION
        elif any(kw in tool_lower for kw in ["db", "sql", "database", "query"]):
            return ToolCategory.DATABASE
        else:
            return ToolCategory.API

    def _infer_sequential_topology(self, agents: list[SecurityAgent]) -> list[AgentCommunication]:
        """Infer sequential topology when agents are found but no explicit connections.

        Assumes agents work in sequence based on discovery order.
        """
        communications: list[AgentCommunication] = []

        if len(agents) < 2:
            return communications

        # Create sequential chain
        for i in range(len(agents) - 1):
            communications.append(
                AgentCommunication(
                    source_id=agents[i].id,
                    target_id=agents[i + 1].id,
                    communication_type="sequential_handoff",
                    bidirectional=False,
                    metadata={"inferred": True},
                )
            )

        return communications

    def get_agents(self, path: Path) -> list[SecurityAgent]:
        """Extract CrewAI agents from path."""
        agents: list[SecurityAgent] = []

        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()
                agents.extend(self._extract_agents_from_file(file_path, code))
            except Exception as e:
                # Log but continue with other files
                self.logger.warning(
                    "agent_extraction_failed", file_path=str(file_path), error=str(e)
                )
                continue

        return agents

    def get_vulnerabilities(self, agent: SecurityAgent) -> list[SecurityFinding]:
        """Analyze CrewAI agent for vulnerabilities."""
        findings: list[SecurityFinding] = []
        file_path = agent.file_path or "unknown"
        line_number = agent.line_number or 1

        # Check prompt injection risk
        if agent.system_prompt:
            finding = self.check_prompt_injection_risk(
                agent.system_prompt, file_path, line_number, agent.id
            )
            if finding:
                findings.append(finding)

        # Check excessive agency
        finding = self.check_excessive_agency(agent, file_path, line_number)
        if finding:
            findings.append(finding)

        # Check unsafe delegation
        finding = self.check_unsafe_delegation(agent, file_path, line_number)
        if finding:
            findings.append(finding)

        # Check role-specific issues
        findings.extend(self._check_role_security(agent, file_path, line_number))

        return findings

    def _extract_agents_from_file(self, file_path: Path, code: str) -> list[SecurityAgent]:
        """Extract CrewAI agents from a single file."""
        agents: list[SecurityAgent] = []
        tree = ast.parse(code)

        class AgentVisitor(ast.NodeVisitor):
            def __init__(self, scanner: CrewAISecurityScanner):
                self.scanner = scanner
                self.agents: list[SecurityAgent] = []

            def visit_Call(self, node: ast.Call) -> None:
                func_name = self._get_func_name(node)

                if func_name == "Agent":
                    agent = self._extract_agent_from_call(node)
                    if agent:
                        self.agents.append(agent)

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return node.func.attr
                return ""

            def _extract_agent_from_call(self, node: ast.Call) -> SecurityAgent | None:
                role = ""
                goal = ""
                backstory = ""
                allow_delegation = False
                tools: list[SecurityTool] = []

                for keyword in node.keywords:
                    if keyword.arg == "role":
                        role = self._get_string_value(keyword.value) or ""
                    elif keyword.arg == "goal":
                        goal = self._get_string_value(keyword.value) or ""
                    elif keyword.arg == "backstory":
                        backstory = self._get_string_value(keyword.value) or ""
                    elif keyword.arg == "allow_delegation":
                        if isinstance(keyword.value, ast.Constant):
                            allow_delegation = bool(keyword.value.value)
                    elif keyword.arg == "tools":
                        tools = self._extract_tools(keyword.value)

                agent_id = f"crewai-{role or 'agent'}-{node.lineno}"

                return SecurityAgent(
                    id=agent_id,
                    name=role or "CrewAI Agent",
                    framework="crewai",
                    role=role,
                    goal=goal,
                    system_prompt=backstory,
                    tools=tools,
                    allow_delegation=allow_delegation,
                    file_path=str(file_path),
                    line_number=node.lineno,
                    trust_level=self.scanner.infer_trust_level(
                        {"name": role, "role": role, "system_prompt": backstory}
                    ),
                )

            def _get_string_value(self, node: ast.AST) -> str | None:
                if isinstance(node, ast.Constant) and isinstance(node.value, str):
                    return node.value
                return None

            def _extract_tools(self, node: ast.AST) -> list[SecurityTool]:
                tools: list[SecurityTool] = []
                if isinstance(node, ast.List):
                    for elt in node.elts:
                        if isinstance(elt, ast.Name):
                            tools.append(
                                SecurityTool(
                                    name=elt.id,
                                    description=f"CrewAI tool: {elt.id}",
                                    categories=[],
                                    required_trust_level=TrustLevel.INTERNAL,
                                )
                            )
                return tools

        visitor = AgentVisitor(self)
        visitor.visit(tree)
        return visitor.agents

    def _check_crewai_patterns(self, code: str, file_path: str) -> list[SecurityFinding]:
        """Check for CrewAI-specific security patterns."""
        findings: list[SecurityFinding] = []
        lines = code.split("\n")

        for i, line in enumerate(lines, 1):
            # Check for hierarchical process without manager
            if re.search(r"process\s*=\s*Process\.hierarchical", line):
                # Look for manager_llm or manager_agent
                if not any(
                    "manager" in l.lower() for l in lines[max(0, i - 5) : min(len(lines), i + 5)]
                ):
                    findings.append(
                        SecurityFinding(
                            id=SecurityFinding.generate_id(),
                            title="Hierarchical Process Without Explicit Manager",
                            description="Hierarchical crew process may use default manager which could have excessive permissions.",
                            severity=Severity.MEDIUM,
                            confidence=0.7,
                            owasp_category=OWASPCategory.LLM08,
                            category=VulnerabilityCategory.EXCESSIVE_AGENCY,
                            file_path=file_path,
                            line_number=i,
                            code_snippet=line.strip(),
                            recommendation="Explicitly configure a manager agent with appropriate permissions.",
                            cwe_id="CWE-250",
                        )
                    )

            # Check for verbose mode
            if re.search(r"verbose\s*=\s*(True|2)", line):
                # Skip if it's a test file or example
                if self._is_test_file(file_path):
                    continue

                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Verbose Mode Enabled",
                        description="Verbose mode can expose agent reasoning and internal state.",
                        severity=Severity.LOW,
                        confidence=0.9,
                        owasp_category=OWASPCategory.LLM06,
                        category=VulnerabilityCategory.DATA_LEAKAGE,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Disable verbose mode in production.",
                        cwe_id="CWE-532",
                    )
                )

            # Check for memory=True without isolation
            if re.search(r"memory\s*=\s*True", line):
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Crew Memory Enabled",
                        description="Crew memory persists across interactions and may leak information.",
                        severity=Severity.MEDIUM,
                        confidence=0.6,
                        owasp_category=OWASPCategory.LLM06,
                        maas_category=MAASCategory.MAAS04,
                        category=VulnerabilityCategory.DATA_LEAKAGE,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Implement memory isolation per user/session.",
                        cwe_id="CWE-200",
                    )
                )

        return findings

    def _check_role_security(
        self, agent: SecurityAgent, file_path: str, line_number: int
    ) -> list[SecurityFinding]:
        """Check for role-specific security issues."""
        findings: list[SecurityFinding] = []

        role = (agent.role or "").lower()
        goal = (agent.goal or "").lower()

        # Check for overly broad roles
        broad_role_keywords = [
            "access everything",
            "full access",
            "admin access",
            "do anything",
            "superuser",
        ]
        if any(kw in role or kw in goal for kw in broad_role_keywords):
            findings.append(
                SecurityFinding(
                    id=SecurityFinding.generate_id(),
                    title="Overly Broad Agent Role",
                    description=f"Agent role '{agent.role}' appears to have overly broad permissions.",
                    severity=Severity.MEDIUM,
                    confidence=0.7,
                    owasp_category=OWASPCategory.LLM08,
                    category=VulnerabilityCategory.EXCESSIVE_AGENCY,
                    file_path=file_path,
                    line_number=line_number,
                    code_snippet=f"Role: {agent.role}, Goal: {agent.goal}",
                    recommendation="Define specific, limited roles following the principle of least privilege.",
                    agent_id=agent.id,
                    cwe_id="CWE-250",
                )
            )

        # Check for delegation without constraints
        if agent.allow_delegation:
            # Skip test files but flag for all trust levels except SYSTEM
            # Delegation is a security concern regardless of trust level
            is_test = self._is_test_file(file_path)
            if not is_test and agent.trust_level != TrustLevel.SYSTEM:
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Agent Allows Unrestricted Delegation",
                        description=f"Agent '{agent.name}' can delegate tasks without restrictions, enabling potential trust boundary violations.",
                        severity=Severity.MEDIUM,
                        confidence=0.8,
                        owasp_category=OWASPCategory.LLM08,
                        maas_category=MAASCategory.MAAS03,
                        category=VulnerabilityCategory.UNSAFE_DELEGATION,
                        file_path=file_path,
                        line_number=line_number,
                        code_snippet=f"Agent: {agent.name}, allow_delegation=True",
                        recommendation="Restrict delegation to specific trusted agents or implement delegation approval.",
                        agent_id=agent.id,
                        cwe_id="CWE-284",
                    )
                )

        return findings

    @classmethod
    def can_handle(cls, path: Path) -> bool:
        """Check if this scanner can handle CrewAI projects."""
        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    content = f.read()
                    if "from crewai" in content or "import crewai" in content:
                        return True
            except Exception:
                # Log file read errors but continue checking other files
                # This is expected for binary files, etc.
                continue

        return False
