"""
Integration with Vantage SecurityScanner.

US-016: Taint Path Reporting
Converts taint findings to SecurityFinding format for integration
with the existing scanner infrastructure.
"""

from vantage_core.security.models import (
    FindingExplanation,
    OWASPCategory,
    SecurityFinding,
    Severity,
    SourceLocation,
    VulnerabilityCategory,
)
from vantage_core.security.taint.analyzer import (
    IntraProceduralTaintAnalyzer,
    TaintAnalysisConfig,
    TaintFinding,
)

# Mapping from sink types to vulnerability categories
SINK_TO_CATEGORY = {
    "code_execution": VulnerabilityCategory.CODE_EXECUTION,
    "command_injection": VulnerabilityCategory.CODE_EXECUTION,
    "sql_injection": VulnerabilityCategory.DATA_LEAKAGE,
    "file_write": VulnerabilityCategory.INSECURE_TOOL_USE,
    "network_output": VulnerabilityCategory.DATA_LEAKAGE,
    "deserialization": VulnerabilityCategory.INSECURE_TOOL_USE,
}

# Mapping from sink types to OWASP categories
SINK_TO_OWASP = {
    "code_execution": OWASPCategory.LLM02,  # Insecure Output Handling
    "command_injection": OWASPCategory.LLM02,
    "sql_injection": OWASPCategory.LLM02,
    "file_write": OWASPCategory.LLM02,
    "network_output": OWASPCategory.LLM06,  # Sensitive Information Disclosure
    "deserialization": OWASPCategory.LLM07,  # Insecure Plugin Design
}

# Mapping from severity strings to Severity enum
SEVERITY_MAP = {
    "HIGH": Severity.HIGH,
    "MEDIUM": Severity.MEDIUM,
    "LOW": Severity.LOW,
}


def taint_finding_to_security_finding(
    taint_finding: TaintFinding,
    source_code: str = "",
) -> SecurityFinding:
    """
    Convert a TaintFinding to a SecurityFinding.

    Args:
        taint_finding: The taint finding to convert
        source_code: Optional source code for context extraction

    Returns:
        SecurityFinding compatible with existing scanner infrastructure
    """
    # Determine vulnerability category
    category = SINK_TO_CATEGORY.get(taint_finding.sink_type, VulnerabilityCategory.DATA_LEAKAGE)

    # Determine OWASP category
    owasp = SINK_TO_OWASP.get(taint_finding.sink_type, OWASPCategory.LLM02)

    # Map severity
    severity = SEVERITY_MAP.get(taint_finding.severity, Severity.MEDIUM)

    # Build title
    title = f"Taint Flow: {taint_finding.source.source_type} to {taint_finding.sink_type}"

    # Build description
    description = (
        f"Potentially tainted data from {taint_finding.source.source_type} "
        f"flows to {taint_finding.sink_function}() ({taint_finding.sink_type}). "
        f"Source at line {taint_finding.source_line}, sink at line {taint_finding.sink_line}."
    )

    # Build recommendation
    recommendation = _get_recommendation(taint_finding.sink_type, taint_finding.source.source_type)

    # Build path description
    path_description = _format_taint_path(taint_finding)

    # Create source location
    location = SourceLocation(
        file_path=taint_finding.file_path,
        start_line=taint_finding.sink_line,
        end_line=taint_finding.sink_line,
        start_column=1,
        highlighted_code=taint_finding.code_context,
    )

    # Create explanation
    explanation = FindingExplanation(
        what_was_found=f"Data flow from {taint_finding.source.source_type} to {taint_finding.sink_type}",
        why_its_risky=_get_risk_explanation(taint_finding.sink_type),
        how_to_fix=recommendation,
        matched_pattern=f"{taint_finding.source.variable} -> {taint_finding.sink_function}",
        risk_factors=[
            f"Source type: {taint_finding.source.source_type}",
            f"Sink type: {taint_finding.sink_type}",
        ],
        severity_justification=f"Taint state: {taint_finding.severity}",
        attack_scenario=_get_attack_scenario(taint_finding.sink_type),
    )

    return SecurityFinding(
        id=SecurityFinding.generate_id(),
        title=title,
        description=description,
        severity=severity,
        confidence=0.85 if taint_finding.severity == "HIGH" else 0.7,
        owasp_category=owasp,
        category=category,
        file_path=taint_finding.file_path,
        line_number=taint_finding.sink_line,
        code_snippet=taint_finding.code_context,
        recommendation=recommendation,
        evidence=[
            f"Source: {taint_finding.source.location}",
            f"Sink: {taint_finding.sink_location}",
            path_description,
        ],
        location=location,
        explanation=explanation,
        detection_method="taint",
        cwe_id=_get_cwe_id(taint_finding.sink_type),
    )


def analyze_code_for_taint(
    code: str,
    file_path: str,
    config: TaintAnalysisConfig | None = None,
) -> list[SecurityFinding]:
    """
    Analyze code for taint flows and return SecurityFindings.

    Args:
        code: Source code to analyze
        file_path: Path to the source file
        config: Optional analysis configuration

    Returns:
        List of SecurityFinding objects
    """
    analyzer = IntraProceduralTaintAnalyzer(config)
    taint_findings = analyzer.analyze(code, file_path)

    security_findings = []
    for tf in taint_findings:
        sf = taint_finding_to_security_finding(tf, code)
        security_findings.append(sf)

    return security_findings


def _get_recommendation(sink_type: str, source_type: str) -> str:
    """Get remediation recommendation based on sink type."""
    recommendations = {
        "code_execution": (
            "Never pass untrusted data directly to eval() or exec(). "
            "Use safer alternatives like ast.literal_eval() for parsing data, "
            "or implement a whitelist of allowed operations."
        ),
        "command_injection": (
            "Avoid constructing shell commands with user input. "
            "Use subprocess.run() with a list of arguments instead of shell=True. "
            "If shell commands are necessary, use shlex.quote() to escape arguments."
        ),
        "sql_injection": (
            "Use parameterized queries instead of string formatting. "
            "For example: cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,)). "
            "Never concatenate user input directly into SQL strings."
        ),
        "file_write": (
            "Validate and sanitize file paths to prevent path traversal attacks. "
            "Use os.path.basename() to extract filenames and verify they don't contain '../'. "
            "Consider using a whitelist of allowed directories."
        ),
        "network_output": (
            "Sanitize data before sending to external systems. "
            "Use appropriate encoding and validation based on the destination format."
        ),
        "deserialization": (
            "Avoid deserializing untrusted data with pickle. "
            "Use safer formats like JSON for data interchange. "
            "If pickle is required, validate data integrity and source."
        ),
    }
    return recommendations.get(sink_type, "Validate and sanitize all untrusted input before use.")


def _get_risk_explanation(sink_type: str) -> str:
    """Get risk explanation for sink type."""
    explanations = {
        "code_execution": (
            "Code execution vulnerabilities allow attackers to run arbitrary code "
            "on the server, potentially leading to complete system compromise."
        ),
        "command_injection": (
            "Command injection allows attackers to execute arbitrary system commands, "
            "which can be used to read files, modify data, or pivot to other systems."
        ),
        "sql_injection": (
            "SQL injection allows attackers to read, modify, or delete database content, "
            "bypass authentication, and potentially execute commands on the database server."
        ),
        "file_write": (
            "Unvalidated file writes can lead to arbitrary file creation or modification, "
            "potentially enabling code execution through webshells or configuration changes."
        ),
        "network_output": (
            "Sending unsanitized data to external systems can leak sensitive information "
            "or enable further attacks on connected systems."
        ),
        "deserialization": (
            "Deserializing untrusted data can lead to arbitrary code execution, "
            "as malicious payloads can be crafted to run code during deserialization."
        ),
    }
    return explanations.get(
        sink_type, "Untrusted data reaching sensitive operations poses security risks."
    )


def _get_attack_scenario(sink_type: str) -> str:
    """Get example attack scenario for sink type."""
    scenarios = {
        "code_execution": (
            'Attacker provides input like \'__import__("os").system("rm -rf /")\' '
            "which gets evaluated and executes a destructive command."
        ),
        "command_injection": (
            "Attacker provides filename like '; rm -rf /' which, when concatenated "
            "into a shell command, executes the malicious command."
        ),
        "sql_injection": (
            "Attacker provides input like \"' OR '1'='1\" to bypass authentication "
            'or "\'; DROP TABLE users;--" to delete data.'
        ),
        "file_write": (
            "Attacker provides path like '../../../etc/cron.d/malicious' "
            "to write a cron job that executes attacker-controlled code."
        ),
        "network_output": (
            "Attacker provides input containing sensitive data patterns "
            "that gets logged or transmitted to external services."
        ),
        "deserialization": (
            "Attacker provides crafted pickle data that executes arbitrary code "
            "when unpickled, such as spawning a reverse shell."
        ),
    }
    return scenarios.get(
        sink_type,
        "Attacker provides malicious input that flows to a sensitive operation.",
    )


def _get_cwe_id(sink_type: str) -> str:
    """Get CWE ID for sink type."""
    cwe_ids = {
        "code_execution": "CWE-94",  # Code Injection
        "command_injection": "CWE-78",  # OS Command Injection
        "sql_injection": "CWE-89",  # SQL Injection
        "file_write": "CWE-22",  # Path Traversal
        "network_output": "CWE-319",  # Cleartext Transmission
        "deserialization": "CWE-502",  # Deserialization of Untrusted Data
    }
    return cwe_ids.get(sink_type, "CWE-20")  # Improper Input Validation


def _format_taint_path(finding: TaintFinding) -> str:
    """Format the taint path for display."""
    if not finding.path:
        return f"Direct flow: {finding.source.variable} -> {finding.sink_function}()"

    path_parts = [finding.source.variable]
    for node in finding.path:
        path_parts.append(f"{node.variable}")
    path_parts.append(f"{finding.sink_function}()")

    return "Flow path: " + " -> ".join(path_parts)
