"""
Visualization module for Vantage Security Platform.

Provides data generators for frontend visualization of security
analysis results including infection simulations and trust boundaries.
"""

from vantage_core.security.visualization.infection import (
    AgentVisualState,
    AnimationData,
    FrameData,
    InfectionEvent,
    InfectionVisualizer,
    Position,
    generate_infection_animation,
)
from vantage_core.security.visualization.infection import (
    ExportFormat as InfectionExportFormat,
)
from vantage_core.security.visualization.trust_boundaries import (
    AgentPosition,
    TrustBoundaryVisualizer,
    ViolationIndicator,
    Zone,
    ZoneConnection,
    ZoneDiagram,
    generate_trust_boundary_diagram,
)
from vantage_core.security.visualization.trust_boundaries import (
    ExportFormat as TrustExportFormat,
)

__all__ = [
    # Infection visualization
    "InfectionVisualizer",
    "AnimationData",
    "FrameData",
    "InfectionEvent",
    "AgentVisualState",
    "Position",
    "InfectionExportFormat",
    "generate_infection_animation",
    # Trust boundary visualization
    "TrustBoundaryVisualizer",
    "ZoneDiagram",
    "Zone",
    "AgentPosition",
    "ViolationIndicator",
    "ZoneConnection",
    "TrustExportFormat",
    "generate_trust_boundary_diagram",
]
