"""Database persistence for Vantage validation framework.

Provides SQLite/PostgreSQL storage for ground truth datasets and metrics history.
Supports schema migrations, transaction support, and JSON to database migration.

Reference: US-031 - Database Persistence for Validation Framework
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import asdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Try to import SQLAlchemy
try:
    from sqlalchemy import (
        Column,
        DateTime,
        Float,
        ForeignKey,
        Index,
        Integer,
        MetaData,
        String,
        Table,
        Text,
        create_engine,
        text,
    )
    from sqlalchemy.pool import QueuePool, StaticPool

    SQLALCHEMY_AVAILABLE = True
except ImportError:
    SQLALCHEMY_AVAILABLE = False
    logger.warning("SQLAlchemy not installed. Database features disabled.")


# Schema version for migrations
SCHEMA_VERSION = 1


class MimicDatabase:
    """Database interface for Vantage validation data.

    Provides CRUD operations for ground truth datasets and metrics history
    with support for both SQLite and PostgreSQL backends.

    Example:
        db = MimicDatabase()  # Uses SQLite by default
        dataset_id = db.save_ground_truth(dataset)
        loaded = db.load_ground_truth(dataset_id)
    """

    def __init__(self, connection_string: str | None = None):
        """Initialize database connection.

        Args:
            connection_string: Database URL. If None, uses DATABASE_URL env var
                             or defaults to SQLite at ~/.vantage/vantage.db
        """
        if not SQLALCHEMY_AVAILABLE:
            raise ImportError(
                "SQLAlchemy is required for database features. "
                "Install with: pip install sqlalchemy"
            )

        # Determine connection string
        if connection_string is None:
            connection_string = os.environ.get("DATABASE_URL")

        if connection_string is None:
            # Default to SQLite
            db_dir = Path.home() / ".vantage"
            db_dir.mkdir(parents=True, exist_ok=True)
            db_path = db_dir / "vantage.db"
            connection_string = f"sqlite:///{db_path}"

        self._connection_string = connection_string
        self._is_sqlite = connection_string.startswith("sqlite")

        # Create engine with appropriate pooling
        if self._is_sqlite:
            # SQLite needs special handling for thread safety and foreign keys
            self._engine = create_engine(
                connection_string,
                connect_args={"check_same_thread": False},
                poolclass=StaticPool,
            )
            # Enable foreign key constraints for SQLite
            from sqlalchemy import event

            @event.listens_for(self._engine, "connect")
            def set_sqlite_pragma(dbapi_connection, connection_record):
                cursor = dbapi_connection.cursor()
                cursor.execute("PRAGMA foreign_keys=ON")
                cursor.close()

        else:
            # PostgreSQL with connection pooling
            self._engine = create_engine(
                connection_string,
                poolclass=QueuePool,
                pool_size=5,
                max_overflow=10,
            )

        # Create metadata and tables
        self._metadata = MetaData()
        self._define_schema()

        # Create tables
        self._metadata.create_all(self._engine)
        logger.info(f"Database initialized: {connection_string.split('@')[-1]}")

    def _define_schema(self) -> None:
        """Define database schema based on architecture section 3.2."""

        # Ground truth datasets table
        self._datasets_table = Table(
            "ground_truth_datasets",
            self._metadata,
            Column("id", String(36), primary_key=True),
            Column("name", String(255), nullable=False),
            Column("created_at", DateTime, default=datetime.utcnow),
            Column(
                "updated_at",
                DateTime,
                default=datetime.utcnow,
                onupdate=datetime.utcnow,
            ),
            Column("metadata", Text),  # JSON
            Column("version", Integer, default=1),
        )

        # Failure annotations table
        self._failures_table = Table(
            "failure_annotations",
            self._metadata,
            Column("id", Integer, primary_key=True, autoincrement=True),
            Column(
                "dataset_id",
                String(36),
                ForeignKey("ground_truth_datasets.id", ondelete="CASCADE"),
                nullable=False,
            ),
            Column("agent_id", String(255), nullable=False),
            Column("failure_code", String(50), nullable=False),
            Column("is_present", Integer, nullable=False),  # Boolean as int for SQLite
            Column("severity", String(50)),
            Column("annotator", String(255)),
            Column("confidence", Float, default=1.0),
            Index("idx_failures_dataset_agent", "dataset_id", "agent_id"),
        )

        # Connection annotations table
        self._connections_table = Table(
            "connection_annotations",
            self._metadata,
            Column("id", Integer, primary_key=True, autoincrement=True),
            Column(
                "dataset_id",
                String(36),
                ForeignKey("ground_truth_datasets.id", ondelete="CASCADE"),
                nullable=False,
            ),
            Column("source", String(255), nullable=False),
            Column("target", String(255), nullable=False),
            Column("exists", Integer, nullable=False),  # Boolean as int
            Column("data_passed", Text),  # JSON array
            Column("annotator", String(255)),
            Index("idx_connections_dataset", "dataset_id"),
        )

        # Alignment annotations table
        self._alignments_table = Table(
            "alignment_annotations",
            self._metadata,
            Column("id", Integer, primary_key=True, autoincrement=True),
            Column(
                "dataset_id",
                String(36),
                ForeignKey("ground_truth_datasets.id", ondelete="CASCADE"),
                nullable=False,
            ),
            Column("system_id", String(255), nullable=False),
            Column("overall_score", Float, nullable=False),
            Column("grade", String(10), nullable=False),
            Column("component_scores", Text),  # JSON
            Column("annotator", String(255)),
            Index("idx_alignments_dataset_system", "dataset_id", "system_id"),
        )

        # Metrics snapshots table
        self._metrics_table = Table(
            "metrics_snapshots",
            self._metadata,
            Column("id", Integer, primary_key=True, autoincrement=True),
            Column("timestamp", DateTime, default=datetime.utcnow, nullable=False),
            Column("component", String(100), nullable=False),
            Column("metrics", Text, nullable=False),  # JSON
            Column("git_commit", String(40)),
            Column("version", String(50)),
            Index("idx_metrics_component_timestamp", "component", "timestamp"),
        )

        # Schema version table
        self._schema_version_table = Table(
            "schema_version",
            self._metadata,
            Column("version", Integer, primary_key=True),
            Column("applied_at", DateTime, default=datetime.utcnow),
        )

    @contextmanager
    def transaction(self) -> Generator[Any, None, None]:
        """Context manager for database transactions.

        Yields:
            Database connection

        Example:
            with db.transaction() as conn:
                conn.execute(...)
        """
        with self._engine.connect() as conn:
            trans = conn.begin()
            try:
                yield conn
                trans.commit()
            except Exception:
                trans.rollback()
                raise

    def save_ground_truth(self, dataset: Any) -> str:
        """Save ground truth dataset to database.

        Args:
            dataset: GroundTruthDataset instance

        Returns:
            Dataset ID (UUID)
        """
        from vantage_core.validation.ground_truth import GroundTruthDataset

        if not isinstance(dataset, GroundTruthDataset):
            raise TypeError(f"Expected GroundTruthDataset, got {type(dataset)}")

        dataset_id = str(uuid.uuid4())

        with self.transaction() as conn:
            # Insert dataset
            conn.execute(
                self._datasets_table.insert().values(
                    id=dataset_id,
                    name=dataset.metadata.get("name", "Unnamed Dataset"),
                    metadata=json.dumps(dataset.metadata),
                )
            )

            # Insert failure annotations
            for failure in dataset.failures:
                conn.execute(
                    self._failures_table.insert().values(
                        dataset_id=dataset_id,
                        agent_id=failure.agent_id,
                        failure_code=failure.failure_code,
                        is_present=1 if failure.is_present else 0,
                        severity=failure.severity,
                        annotator=failure.annotator,
                        confidence=failure.confidence,
                    )
                )

            # Insert connection annotations
            for connection in dataset.connections:
                conn.execute(
                    self._connections_table.insert().values(
                        dataset_id=dataset_id,
                        source=connection.source,
                        target=connection.target,
                        exists=1 if connection.exists else 0,
                        data_passed=json.dumps(connection.data_passed),
                        annotator=connection.annotator,
                    )
                )

            # Insert alignment annotations
            for alignment in dataset.alignments:
                conn.execute(
                    self._alignments_table.insert().values(
                        dataset_id=dataset_id,
                        system_id=alignment.system_id,
                        overall_score=alignment.overall_score,
                        grade=alignment.grade,
                        component_scores=json.dumps(alignment.component_scores),
                        annotator=alignment.annotator,
                    )
                )

        logger.info(f"Saved ground truth dataset: {dataset_id}")
        return dataset_id

    def load_ground_truth(self, dataset_id: str) -> Any:
        """Load ground truth dataset from database.

        Args:
            dataset_id: Dataset UUID

        Returns:
            GroundTruthDataset instance

        Raises:
            ValueError: If dataset not found
        """
        from vantage_core.validation.ground_truth import (
            GroundTruthAlignment,
            GroundTruthConnection,
            GroundTruthDataset,
            GroundTruthFailure,
        )

        with self._engine.connect() as conn:
            # Load dataset metadata
            result = conn.execute(
                self._datasets_table.select().where(self._datasets_table.c.id == dataset_id)
            ).fetchone()

            if result is None:
                raise ValueError(f"Dataset not found: {dataset_id}")

            metadata = json.loads(result.metadata) if result.metadata else {}

            # Load failures
            failures = []
            failure_rows = conn.execute(
                self._failures_table.select().where(self._failures_table.c.dataset_id == dataset_id)
            ).fetchall()

            for row in failure_rows:
                failures.append(
                    GroundTruthFailure(
                        agent_id=row.agent_id,
                        failure_code=row.failure_code,
                        is_present=bool(row.is_present),
                        severity=row.severity,
                        annotator=row.annotator or "",
                        confidence=row.confidence or 1.0,
                    )
                )

            # Load connections
            connections = []
            conn_rows = conn.execute(
                self._connections_table.select().where(
                    self._connections_table.c.dataset_id == dataset_id
                )
            ).fetchall()

            for row in conn_rows:
                connections.append(
                    GroundTruthConnection(
                        source=row.source,
                        target=row.target,
                        exists=bool(row.exists),
                        data_passed=(json.loads(row.data_passed) if row.data_passed else []),
                        annotator=row.annotator or "",
                    )
                )

            # Load alignments
            alignments = []
            align_rows = conn.execute(
                self._alignments_table.select().where(
                    self._alignments_table.c.dataset_id == dataset_id
                )
            ).fetchall()

            for row in align_rows:
                alignments.append(
                    GroundTruthAlignment(
                        system_id=row.system_id,
                        overall_score=row.overall_score,
                        grade=row.grade,
                        component_scores=(
                            json.loads(row.component_scores) if row.component_scores else {}
                        ),
                        annotator=row.annotator or "",
                    )
                )

        return GroundTruthDataset(
            failures=failures,
            connections=connections,
            alignments=alignments,
            metadata=metadata,
        )

    def list_datasets(self) -> list[dict[str, Any]]:
        """List all ground truth datasets.

        Returns:
            List of dataset metadata dictionaries
        """
        with self._engine.connect() as conn:
            results = conn.execute(
                self._datasets_table.select().order_by(self._datasets_table.c.created_at.desc())
            ).fetchall()

        datasets = []
        for row in results:
            datasets.append(
                {
                    "id": row.id,
                    "name": row.name,
                    "created_at": (row.created_at.isoformat() if row.created_at else None),
                    "updated_at": (row.updated_at.isoformat() if row.updated_at else None),
                    "metadata": json.loads(row.metadata) if row.metadata else {},
                }
            )

        return datasets

    def delete_dataset(self, dataset_id: str) -> bool:
        """Delete a ground truth dataset.

        Args:
            dataset_id: Dataset UUID

        Returns:
            True if deleted, False if not found
        """
        with self.transaction() as conn:
            result = conn.execute(
                self._datasets_table.delete().where(self._datasets_table.c.id == dataset_id)
            )
            deleted = result.rowcount > 0

        if deleted:
            logger.info(f"Deleted dataset: {dataset_id}")
        return deleted

    def record_metrics(self, snapshot: Any) -> None:
        """Record metrics snapshot for history.

        Args:
            snapshot: MetricsSnapshot or dict with metrics data
        """
        # Handle different input types
        if hasattr(snapshot, "to_dict"):
            metrics_data = snapshot.to_dict()
        elif isinstance(snapshot, dict):
            metrics_data = snapshot
        else:
            metrics_data = asdict(snapshot) if hasattr(snapshot, "__dataclass_fields__") else {}

        component = metrics_data.get("component", "unknown")
        git_commit = metrics_data.get("git_commit")
        version = metrics_data.get("version")

        with self.transaction() as conn:
            conn.execute(
                self._metrics_table.insert().values(
                    component=component,
                    metrics=json.dumps(metrics_data),
                    git_commit=git_commit,
                    version=version,
                )
            )

        logger.debug(f"Recorded metrics for component: {component}")

    def get_metrics_history(self, component: str, days: int = 30) -> list[dict[str, Any]]:
        """Get metrics trend over time.

        Args:
            component: Component name to filter by
            days: Number of days to look back

        Returns:
            List of metrics snapshots
        """
        cutoff = datetime.utcnow() - timedelta(days=days)

        with self._engine.connect() as conn:
            results = conn.execute(
                self._metrics_table.select()
                .where(
                    (self._metrics_table.c.component == component)
                    & (self._metrics_table.c.timestamp >= cutoff)
                )
                .order_by(self._metrics_table.c.timestamp.asc())
            ).fetchall()

        history = []
        for row in results:
            history.append(
                {
                    "timestamp": row.timestamp.isoformat() if row.timestamp else None,
                    "component": row.component,
                    "metrics": json.loads(row.metrics) if row.metrics else {},
                    "git_commit": row.git_commit,
                    "version": row.version,
                }
            )

        return history

    def get_latest_metrics(self, component: str) -> dict[str, Any] | None:
        """Get the most recent metrics for a component.

        Args:
            component: Component name

        Returns:
            Latest metrics snapshot or None
        """
        with self._engine.connect() as conn:
            result = conn.execute(
                self._metrics_table.select()
                .where(self._metrics_table.c.component == component)
                .order_by(self._metrics_table.c.timestamp.desc())
                .limit(1)
            ).fetchone()

        if result is None:
            return None

        return {
            "timestamp": result.timestamp.isoformat() if result.timestamp else None,
            "component": result.component,
            "metrics": json.loads(result.metrics) if result.metrics else {},
            "git_commit": result.git_commit,
            "version": result.version,
        }

    def migrate_from_json(self, json_path: Path) -> str:
        """Migrate ground truth data from JSON file to database.

        Args:
            json_path: Path to JSON file

        Returns:
            Dataset ID of imported data

        Raises:
            FileNotFoundError: If file doesn't exist
        """
        from vantage_core.validation.ground_truth import GroundTruthDataset

        if not json_path.exists():
            raise FileNotFoundError(f"JSON file not found: {json_path}")

        # Load from JSON
        dataset = GroundTruthDataset.load(json_path)

        # Add source file info to metadata
        if "source_file" not in dataset.metadata:
            dataset.metadata["source_file"] = str(json_path)
        if "name" not in dataset.metadata:
            dataset.metadata["name"] = json_path.stem

        # Save to database
        dataset_id = self.save_ground_truth(dataset)
        logger.info(f"Migrated {json_path} to database as {dataset_id}")

        return dataset_id

    def export_to_json(self, dataset_id: str, output_path: Path) -> None:
        """Export dataset from database to JSON file.

        Args:
            dataset_id: Dataset UUID
            output_path: Path to save JSON file
        """
        dataset = self.load_ground_truth(dataset_id)
        dataset.save(output_path)
        logger.info(f"Exported {dataset_id} to {output_path}")

    def get_stats(self) -> dict[str, Any]:
        """Get database statistics.

        Returns:
            Dictionary with table counts and database info
        """
        with self._engine.connect() as conn:
            stats = {
                "datasets": conn.execute(
                    text("SELECT COUNT(*) FROM ground_truth_datasets")
                ).scalar(),
                "failures": conn.execute(text("SELECT COUNT(*) FROM failure_annotations")).scalar(),
                "connections": conn.execute(
                    text("SELECT COUNT(*) FROM connection_annotations")
                ).scalar(),
                "alignments": conn.execute(
                    text("SELECT COUNT(*) FROM alignment_annotations")
                ).scalar(),
                "metrics_snapshots": conn.execute(
                    text("SELECT COUNT(*) FROM metrics_snapshots")
                ).scalar(),
                "database_type": "sqlite" if self._is_sqlite else "postgresql",
            }

        return stats

    def close(self) -> None:
        """Close database connection."""
        self._engine.dispose()
        logger.debug("Database connection closed")


# Singleton instance
_database_instance: MimicDatabase | None = None


def get_database(connection_string: str | None = None) -> MimicDatabase:
    """Get database singleton instance.

    Args:
        connection_string: Optional connection string (only used on first call)

    Returns:
        MimicDatabase instance
    """
    global _database_instance
    if _database_instance is None:
        _database_instance = MimicDatabase(connection_string)
    return _database_instance


def reset_database() -> None:
    """Reset database singleton (for testing)."""
    global _database_instance
    if _database_instance is not None:
        _database_instance.close()
        _database_instance = None
