"""Testing utilities for Vantage.

This module provides utilities for generating test data and running
security tests against multi-agent AI systems.

Classes:
    TestDataGenerator: Generates test agents, connections, and payloads.
    TestRunner: Executes tests and collects results.
    TestResult: Represents the outcome of a single test.
    TestStatus: Enum of possible test statuses.
    TestSuite: A collection of tests to run together.
    RunnerConfig: Configuration for the test runner.
    GeneratedAgent: Represents a generated test agent.
    GeneratedConnection: Represents a generated connection.

Example:
    >>> from vantage_core.testing import TestDataGenerator, TestRunner
    >>> generator = TestDataGenerator()
    >>> agents = generator.generate_agents(count=5)
    >>> runner = TestRunner()
    >>> result = runner.run_test(my_test_function)
"""

from vantage_core.testing.generator import (
    GeneratedAgent,
    GeneratedConnection,
    TestDataGenerator,
)
from vantage_core.testing.runner import (
    RunnerConfig,
    TestResult,
    TestRunner,
    TestStatus,
    TestSuite,
)

__all__ = [
    # Generator classes
    "TestDataGenerator",
    "GeneratedAgent",
    "GeneratedConnection",
    # Runner classes
    "TestRunner",
    "TestResult",
    "TestStatus",
    "TestSuite",
    "RunnerConfig",
]
