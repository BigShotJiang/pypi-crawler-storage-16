"""
Agent Graph - Topology representation for multi-agent systems.

Uses NetworkX for graph operations.
"""

from dataclasses import dataclass, field

import networkx as nx

from vantage_core.models import DetectedAgent, DetectedConnection


@dataclass
class AgentNode:
    """A node in the agent graph."""

    agent: DetectedAgent
    in_degree: int = 0
    out_degree: int = 0
    is_entry_point: bool = False
    is_exit_point: bool = False
    trust_score: float = 0.5


@dataclass
class BlastRadius:
    """Result of blast radius calculation."""

    source_agent_id: str
    affected_agents: list[str] = field(default_factory=list)
    hop_count: int = 0
    infection_probability: float = 0.0


class AgentGraph:
    """
    Graph representation of multi-agent system topology.

    Enables analysis of:
    - Agent relationships and trust boundaries
    - Infection propagation paths
    - Blast radius calculation
    """

    def __init__(self) -> None:
        """Initialize empty graph."""
        self._graph: nx.DiGraph = nx.DiGraph()
        self._agents: dict[str, DetectedAgent] = {}

    def add_agent(self, agent: DetectedAgent) -> None:
        """Add an agent to the graph."""
        self._agents[agent.id] = agent
        self._graph.add_node(
            agent.id,
            name=agent.name,
            framework=agent.framework.value,
            trust_level=agent.trust_level,
        )

    def add_connection(self, connection: DetectedConnection) -> None:
        """Add a connection between agents."""
        if connection.source_id not in self._graph:
            raise ValueError(f"Source agent {connection.source_id} not in graph")
        if connection.target_id not in self._graph:
            raise ValueError(f"Target agent {connection.target_id} not in graph")

        self._graph.add_edge(
            connection.source_id,
            connection.target_id,
            connection_type=connection.connection_type.value,
            confidence=connection.confidence,
        )

    def get_agent(self, agent_id: str) -> DetectedAgent | None:
        """Get agent by ID."""
        return self._agents.get(agent_id)

    def get_agents(self) -> list[DetectedAgent]:
        """Get all agents."""
        return list(self._agents.values())

    def get_connections(self) -> list[tuple[str, str, dict]]:
        """Get all connections."""
        return list(self._graph.edges(data=True))

    @property
    def agent_count(self) -> int:
        """Number of agents."""
        return len(self._agents)

    @property
    def connection_count(self) -> int:
        """Number of connections."""
        return self._graph.number_of_edges()

    def get_entry_points(self) -> list[str]:
        """Get agents with no incoming connections (entry points)."""
        return [node for node in self._graph.nodes() if self._graph.in_degree(node) == 0]

    def get_exit_points(self) -> list[str]:
        """Get agents with no outgoing connections (exit points)."""
        return [node for node in self._graph.nodes() if self._graph.out_degree(node) == 0]

    def get_downstream_agents(self, agent_id: str) -> list[str]:
        """Get all agents reachable from the given agent."""
        if agent_id not in self._graph:
            return []
        return list(nx.descendants(self._graph, agent_id))

    def get_upstream_agents(self, agent_id: str) -> list[str]:
        """Get all agents that can reach the given agent."""
        if agent_id not in self._graph:
            return []
        return list(nx.ancestors(self._graph, agent_id))

    def calculate_blast_radius(
        self,
        source_agent_id: str,
        infection_probability: float = 0.8,
        max_hops: int = 10,
    ) -> BlastRadius:
        """
        Calculate the blast radius if an agent is compromised.

        Args:
            source_agent_id: The initially compromised agent
            infection_probability: Probability of infection per hop
            max_hops: Maximum propagation distance

        Returns:
            BlastRadius with affected agents
        """
        if source_agent_id not in self._graph:
            return BlastRadius(source_agent_id=source_agent_id)

        affected: set[str] = set()
        current_hop: set[str] = {source_agent_id}
        hop_count = 0
        cumulative_prob = 1.0

        while current_hop and hop_count < max_hops:
            next_hop: set[str] = set()
            cumulative_prob *= infection_probability

            for agent in current_hop:
                for successor in self._graph.successors(agent):
                    if successor not in affected and successor != source_agent_id:
                        affected.add(successor)
                        next_hop.add(successor)

            current_hop = next_hop
            if current_hop:
                hop_count += 1

        return BlastRadius(
            source_agent_id=source_agent_id,
            affected_agents=list(affected),
            hop_count=hop_count,
            infection_probability=cumulative_prob,
        )

    def get_trust_boundaries(self) -> list[tuple[str, str]]:
        """
        Identify trust boundary crossings.

        Returns edges where agents have different trust levels.
        """
        boundaries = []
        for source, target in self._graph.edges():
            source_trust = self._agents[source].trust_level
            target_trust = self._agents[target].trust_level
            if source_trust != target_trust:
                boundaries.append((source, target))
        return boundaries

    def get_critical_paths(self) -> list[list[str]]:
        """
        Find critical paths from entry points to exit points.

        These are potential attack paths through the system.
        """
        entry_points = self.get_entry_points()
        exit_points = self.get_exit_points()
        paths = []

        for entry in entry_points:
            for exit_point in exit_points:
                try:
                    for path in nx.all_simple_paths(self._graph, entry, exit_point, cutoff=10):
                        paths.append(path)
                except nx.NetworkXNoPath:
                    continue

        return paths

    def to_dict(self) -> dict:
        """Convert graph to dictionary representation."""
        return {
            "agents": [a.to_dict() for a in self._agents.values()],
            "connections": [
                {
                    "source": s,
                    "target": t,
                    **data,
                }
                for s, t, data in self._graph.edges(data=True)
            ],
            "metrics": {
                "agent_count": self.agent_count,
                "connection_count": self.connection_count,
                "entry_points": self.get_entry_points(),
                "exit_points": self.get_exit_points(),
                "trust_boundaries": len(self.get_trust_boundaries()),
            },
        }
