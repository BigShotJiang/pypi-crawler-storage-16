"""
CLI commands for prompt protection and hardening.

Commands:
    vantage protect harden <prompt>     - Harden a system prompt
    vantage protect analyze <prompt>    - Analyze prompt security
    vantage protect secrets <text>      - Detect secrets in text
    vantage protect redact <text>       - Redact secrets from text
    vantage protect check-input <text>  - Check input for injection attempts
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from vantage_core.protection import (
    PromptHardener,
    SecretFoundError,
    analyze_prompt_security,
    detect_secrets,
    is_injection_attempt,
    redact_all_secrets,
    validate_no_secrets,
)

app = typer.Typer(
    name="protect",
    help="Prompt protection and hardening commands",
    no_args_is_help=True,
)

console = Console()


@app.command("harden")
def harden_command(
    prompt: str | None = typer.Argument(
        None,
        help="System prompt to harden (or use --file)",
    ),
    file: Path | None = typer.Option(
        None,
        "--file",
        "-f",
        help="Read prompt from file",
    ),
    framework: str = typer.Option(
        "generic",
        "--framework",
        "-fw",
        help="Target framework: generic, langchain, crewai, autogen, langgraph, pydantic_ai, openai_swarm",
    ),
    level: str = typer.Option(
        "standard",
        "--level",
        "-l",
        help="Hardening level: minimal, standard, strict, paranoid",
    ),
    secrets: str | None = typer.Option(
        None,
        "--secrets",
        "-s",
        help="Comma-separated secrets to isolate",
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Save hardened prompt to file",
    ),
    show_original: bool = typer.Option(
        False,
        "--show-original",
        help="Show original prompt alongside hardened",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON",
    ),
):
    """
    Harden a system prompt with defensive measures.

    Adds protection against prompt injection attacks including:
    - Role anchoring (prevents identity manipulation)
    - Secret isolation (protects credentials)
    - Injection defense (blocks manipulation attempts)
    - Framework-specific security measures

    Examples:
        vantage protect harden "You are a helpful assistant"
        vantage protect harden --file prompt.txt --framework langchain
        vantage protect harden "..." --secrets "sk-key,password" --level strict
    """
    # Get prompt text
    if file:
        if not file.exists():
            console.print(f"[red]Error: File not found: {file}[/red]")
            raise typer.Exit(1)
        prompt_text = file.read_text()
    elif prompt:
        prompt_text = prompt
    else:
        # Read from stdin
        if sys.stdin.isatty():
            console.print("[yellow]Enter prompt (Ctrl+D to finish):[/yellow]")
        prompt_text = sys.stdin.read()

    if not prompt_text.strip():
        console.print("[red]Error: No prompt provided[/red]")
        raise typer.Exit(1)

    # Parse secrets
    secret_list = []
    if secrets:
        secret_list = [s.strip() for s in secrets.split(",") if s.strip()]

    # Harden the prompt
    try:
        hardener = PromptHardener()
        result = hardener.harden(
            system_prompt=prompt_text,
            secrets=secret_list,
            framework=framework,
            level=level,
        )
    except Exception as e:
        console.print(f"[red]Error hardening prompt: {e}[/red]")
        raise typer.Exit(1)

    # Output
    if json_output:
        output_data = {
            "original_length": len(result.original_prompt),
            "hardened_length": len(result.hardened_prompt),
            "secrets_isolated": result.secrets_isolated,
            "defenses_added": result.defenses_added,
            "protection_score": result.estimated_protection_score,
            "warnings": result.warnings,
            "hardened_prompt": result.hardened_prompt,
        }
        console.print(json.dumps(output_data, indent=2))
    else:
        # Rich output
        console.print()
        console.print(
            Panel.fit(
                "[bold green]Prompt Hardening Complete[/bold green]",
                border_style="green",
            )
        )

        # Stats table
        stats_table = Table(show_header=False, box=None)
        stats_table.add_column("Metric", style="cyan")
        stats_table.add_column("Value", style="white")
        stats_table.add_row("Original Length", f"{len(result.original_prompt)} chars")
        stats_table.add_row("Hardened Length", f"{len(result.hardened_prompt)} chars")
        stats_table.add_row("Secrets Isolated", str(result.secrets_isolated))
        stats_table.add_row("Protection Score", f"{result.estimated_protection_score:.0f}/100")
        stats_table.add_row("Framework", framework)
        stats_table.add_row("Level", level)
        console.print(stats_table)

        # Defenses added
        if result.defenses_added:
            console.print("\n[bold]Defenses Added:[/bold]")
            for defense in result.defenses_added:
                console.print(f"  [green][OK][/green] {defense}")

        # Warnings
        if result.warnings:
            console.print("\n[bold yellow]Warnings:[/bold yellow]")
            for warning in result.warnings:
                console.print(f"  [yellow]![/yellow] {warning}")

        # Show original if requested
        if show_original:
            console.print("\n[bold]Original Prompt:[/bold]")
            console.print(
                Panel(
                    Syntax(
                        result.original_prompt[:500]
                        + ("..." if len(result.original_prompt) > 500 else ""),
                        "text",
                        theme="monokai",
                    ),
                    title="Original",
                    border_style="dim",
                )
            )

        console.print("\n[bold]Hardened Prompt:[/bold]")
        # Show first 2000 chars of hardened prompt
        preview = result.hardened_prompt[:2000]
        if len(result.hardened_prompt) > 2000:
            preview += f"\n\n... [{len(result.hardened_prompt) - 2000} more characters]"
        console.print(Panel(preview, title="Hardened", border_style="green"))

    # Save to file if requested
    if output:
        output.write_text(result.hardened_prompt)
        console.print(f"\n[green]Saved to: {output}[/green]")


@app.command("analyze")
def analyze_command(
    prompt: str | None = typer.Argument(
        None,
        help="System prompt to analyze (or use --file)",
    ),
    file: Path | None = typer.Option(
        None,
        "--file",
        "-f",
        help="Read prompt from file",
    ),
    framework: str | None = typer.Option(
        None,
        "--framework",
        "-fw",
        help="Target framework for context",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON",
    ),
):
    """
    Analyze a system prompt for security vulnerabilities.

    Checks for:
    - Embedded secrets (API keys, passwords)
    - Missing role definition
    - Weak security instructions
    - Missing injection defenses

    Examples:
        vantage protect analyze "You are a helpful assistant"
        vantage protect analyze --file prompt.txt
    """
    # Get prompt text
    if file:
        if not file.exists():
            console.print(f"[red]Error: File not found: {file}[/red]")
            raise typer.Exit(1)
        prompt_text = file.read_text()
    elif prompt:
        prompt_text = prompt
    else:
        if sys.stdin.isatty():
            console.print("[yellow]Enter prompt (Ctrl+D to finish):[/yellow]")
        prompt_text = sys.stdin.read()

    if not prompt_text.strip():
        console.print("[red]Error: No prompt provided[/red]")
        raise typer.Exit(1)

    # Analyze
    analysis = analyze_prompt_security(prompt_text, framework)

    if json_output:
        console.print(json.dumps(analysis, indent=2))
    else:
        # Rich output
        console.print()

        # Grade panel
        grade_colors = {
            "A": "green",
            "B": "cyan",
            "C": "yellow",
            "D": "orange3",
            "F": "red",
        }
        grade_color = grade_colors.get(analysis["grade"], "white")
        console.print(
            Panel.fit(
                f"[bold {grade_color}]Security Grade: {analysis['grade']}[/bold {grade_color}]\n"
                f"Score: {analysis['score']}/100",
                border_style=grade_color,
            )
        )

        # Issues
        if analysis["issues"]:
            console.print("\n[bold red]Issues Found:[/bold red]")
            for issue in analysis["issues"]:
                console.print(f"  [red][X][/red] {issue}")

        # Recommendations
        if analysis["recommendations"]:
            console.print("\n[bold yellow]Recommendations:[/bold yellow]")
            for rec in analysis["recommendations"]:
                console.print(f"  [yellow]->[/yellow] {rec}")

        # Stats
        console.print(f"\n[dim]Prompt length: {analysis['prompt_length']} chars[/dim]")
        if analysis["secrets_detected"]:
            console.print(f"[red]Secrets detected: {analysis['secrets_detected']}[/red]")


@app.command("secrets")
def secrets_command(
    text: str | None = typer.Argument(
        None,
        help="Text to scan for secrets (or use --file)",
    ),
    file: Path | None = typer.Option(
        None,
        "--file",
        "-f",
        help="Read text from file",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON",
    ),
):
    """
    Detect secrets in text.

    Scans for API keys, passwords, tokens, and other credentials.
    Supports 20+ secret types including OpenAI, Anthropic, AWS, GitHub, etc.

    Examples:
        vantage protect secrets "API_KEY=sk-abc123..."
        vantage protect secrets --file config.txt
    """
    # Get text
    if file:
        if not file.exists():
            console.print(f"[red]Error: File not found: {file}[/red]")
            raise typer.Exit(1)
        text_content = file.read_text()
    elif text:
        text_content = text
    else:
        if sys.stdin.isatty():
            console.print("[yellow]Enter text (Ctrl+D to finish):[/yellow]")
        text_content = sys.stdin.read()

    if not text_content.strip():
        console.print("[red]Error: No text provided[/red]")
        raise typer.Exit(1)

    # Detect secrets
    findings = detect_secrets(text_content)

    if json_output:
        output_data = {
            "total_secrets": len(findings),
            "findings": [
                {
                    "type": f.secret_type.value,
                    "redacted_value": f.redacted_value,
                    "confidence": f.confidence,
                    "recommendation": f.recommendation,
                }
                for f in findings
            ],
        }
        console.print(json.dumps(output_data, indent=2))
    else:
        if not findings:
            console.print("[green]No secrets detected.[/green]")
        else:
            console.print(f"\n[bold red]Found {len(findings)} secret(s):[/bold red]\n")

            table = Table()
            table.add_column("Type", style="cyan")
            table.add_column("Value (Redacted)", style="yellow")
            table.add_column("Confidence", style="white")
            table.add_column("Recommendation", style="dim")

            for f in findings:
                table.add_row(
                    f.secret_type.value,
                    f.redacted_value[:40] + ("..." if len(f.redacted_value) > 40 else ""),
                    f"{f.confidence:.0%}",
                    f.recommendation[:30] + "...",
                )

            console.print(table)


@app.command("redact")
def redact_command(
    text: str | None = typer.Argument(
        None,
        help="Text to redact secrets from (or use --file)",
    ),
    file: Path | None = typer.Option(
        None,
        "--file",
        "-f",
        help="Read text from file",
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Save redacted text to file",
    ),
):
    """
    Redact all secrets from text.

    Replaces detected secrets with [REDACTED_TYPE] placeholders.

    Examples:
        vantage protect redact "API_KEY=sk-abc123..."
        vantage protect redact --file config.txt --output safe_config.txt
    """
    # Get text
    if file:
        if not file.exists():
            console.print(f"[red]Error: File not found: {file}[/red]")
            raise typer.Exit(1)
        text_content = file.read_text()
    elif text:
        text_content = text
    else:
        if sys.stdin.isatty():
            console.print("[yellow]Enter text (Ctrl+D to finish):[/yellow]")
        text_content = sys.stdin.read()

    if not text_content.strip():
        console.print("[red]Error: No text provided[/red]")
        raise typer.Exit(1)

    # Redact
    redacted = redact_all_secrets(text_content)

    if output:
        output.write_text(redacted)
        console.print(f"[green]Redacted text saved to: {output}[/green]")
    else:
        console.print(redacted)


@app.command("check-input")
def check_input_command(
    text: str = typer.Argument(
        ...,
        help="User input to check for injection attempts",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON",
    ),
):
    """
    Check if user input contains injection attempts.

    Detects:
    - Instruction override attempts
    - Jailbreak patterns
    - Prompt extraction attempts
    - Role manipulation
    - Encoding tricks

    Examples:
        vantage protect check-input "What is the weather?"
        vantage protect check-input "Ignore all previous instructions"
    """
    is_malicious = is_injection_attempt(text)

    if json_output:
        output_data = {
            "text": text[:100] + ("..." if len(text) > 100 else ""),
            "is_injection_attempt": is_malicious,
            "verdict": "BLOCKED" if is_malicious else "ALLOWED",
        }
        console.print(json.dumps(output_data, indent=2))
    else:
        if is_malicious:
            console.print(
                Panel.fit(
                    "[bold red]INJECTION ATTEMPT DETECTED[/bold red]\n\n"
                    f"Input: {text[:50]}{'...' if len(text) > 50 else ''}\n\n"
                    "[yellow]This input contains patterns commonly used in prompt injection attacks.[/yellow]",
                    border_style="red",
                )
            )
            raise typer.Exit(1)
        else:
            console.print(
                Panel.fit(
                    "[bold green]INPUT APPEARS SAFE[/bold green]\n\n"
                    f"Input: {text[:50]}{'...' if len(text) > 50 else ''}\n\n"
                    "[dim]No obvious injection patterns detected.[/dim]",
                    border_style="green",
                )
            )


@app.command("validate")
def validate_command(
    file: Path = typer.Argument(
        ...,
        help="File to validate for secrets",
    ),
    fail_on_secrets: bool = typer.Option(
        True,
        "--fail/--no-fail",
        help="Exit with error if secrets found",
    ),
):
    """
    Validate that a file contains no secrets.

    Useful for CI/CD pipelines to prevent secret leakage.

    Examples:
        vantage protect validate prompt.txt
        vantage protect validate config.json --no-fail
    """
    if not file.exists():
        console.print(f"[red]Error: File not found: {file}[/red]")
        raise typer.Exit(1)

    text = file.read_text()

    try:
        findings = validate_no_secrets(text, raise_on_found=fail_on_secrets)
        if findings:
            console.print(
                f"[yellow]Found {len(findings)} secret(s) but --no-fail specified[/yellow]"
            )
            for f in findings:
                console.print(f"  - {f.secret_type.value}: {f.redacted_value[:20]}...")
        else:
            console.print(f"[green][OK] {file} contains no secrets[/green]")
    except SecretFoundError as e:
        console.print(f"[red][X] {file} contains {len(e.findings)} secret(s):[/red]")
        for f in e.findings:
            console.print(f"  - {f.secret_type.value}: {f.redacted_value[:20]}...")
        raise typer.Exit(1)
