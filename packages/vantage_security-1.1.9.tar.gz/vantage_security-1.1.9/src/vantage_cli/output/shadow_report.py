"""
Rich CLI Output Formatter.

Provides interactive tables and visual risk indicators for the CLI.
"""

from pathlib import Path

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from vantage_core.models import ScanResult


def print_shadow_ai_report(result: ScanResult, console: Console = None):
    """Print a rich table of detected agents and their risks."""
    if not console:
        console = Console()

    # 1. Summary Panel
    high_risk_count = sum(1 for a in result.agents if a.metadata.get("high_risk"))

    summary_text = Text()
    summary_text.append(f"Total Agents: {len(result.agents)}\n", style="bold")
    summary_text.append(f"Frameworks: {result.framework}\n", style="cyan")

    if high_risk_count > 0:
        summary_text.append(f"⚠️  High Risk Agents: {high_risk_count}", style="bold red")
    else:
        summary_text.append("✅ No High Risk Agents Detected", style="bold green")

    console.print(
        Panel(
            summary_text,
            title="Shadow AI Discovery",
            border_style="blue",
            box=box.ROUNDED,
        )
    )
    console.print()

    # 2. Detailed Table
    table = Table(title="Detected Agents Inventory", box=box.SIMPLE_HEAD)

    table.add_column("Agent Name", style="bold")
    table.add_column("Framework", style="cyan")
    table.add_column("Risk Level", justify="center")
    table.add_column("Capabilities (Tools)", style="dim")
    table.add_column("Location", style="dim")

    for agent in result.agents:
        # Determine Risk Style
        is_high_risk = agent.metadata.get("high_risk", False)
        if is_high_risk:
            risk_badge = Text("CRITICAL", style="bold white on red")
        else:
            risk_badge = Text("LOW", style="green")

        # Format Tools
        tools_list = agent.tools
        if not tools_list:
            tools_text = "-"
        else:
            # Highlight dangerous tools
            tools_colored = []
            for t in tools_list:
                if is_high_risk and any(k in t.lower() for k in ["shell", "exec", "os", "cmd"]):
                    tools_colored.append(f"[red]{t}[/red]")
                else:
                    tools_colored.append(t)
            tools_text = ", ".join(tools_colored)

        # Location
        file_name = Path(agent.file_path).name
        location = f"{file_name}:{agent.line_number}"

        table.add_row(agent.name, agent.framework.value, risk_badge, tools_text, location)

    console.print(table)

    # 3. Recommendations
    if high_risk_count > 0:
        console.print()
        console.print("[bold red]Action Required:[/bold red] High risk agents detected.")
        console.print("Run [on blue] vantage protect --auto [/] to enable active defenses.")
