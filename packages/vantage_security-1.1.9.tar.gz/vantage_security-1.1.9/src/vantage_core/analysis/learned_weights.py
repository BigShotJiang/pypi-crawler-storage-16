"""Learned weights from user feedback using Bayesian updates.

Implements US-026: Alignment scoring weights that improve from user feedback.
Collects implicit and explicit feedback to update weight priors using Bayesian inference.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class WeightFeedback:
    """Feedback on alignment score weights.

    Attributes:
        system_id: ID of the analyzed system
        timestamp: When feedback was provided
        feedback_type: 'implicit' or 'explicit'
        action: For implicit - 'dismiss', 'investigate', 'accept'; for explicit - 'rate'
        rating: For explicit feedback, 1-5 scale of score accuracy
        predicted_score: The alignment score that was shown
        actual_outcome: Optional actual outcome (e.g., 'good', 'bad', 'neutral')
        component_scores: The component scores at time of feedback
        weights_used: The weights used for calculation
        notes: Optional additional context
    """

    system_id: str
    timestamp: str
    feedback_type: str  # 'implicit' or 'explicit'
    action: str
    rating: float | None = None
    predicted_score: float = 0.0
    actual_outcome: str | None = None
    component_scores: dict[str, float] = field(default_factory=dict)
    weights_used: dict[str, float] = field(default_factory=dict)
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WeightFeedback:
        """Create from dictionary."""
        return cls(**data)


@dataclass
class WeightHistory:
    """Record of weight changes over time."""

    timestamp: str
    weights: dict[str, float]
    reason: str
    feedback_count: int
    average_rating: float | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WeightHistory:
        """Create from dictionary."""
        return cls(**data)


class FeedbackCollector:
    """Collects and stores user feedback on alignment scores.

    Supports both implicit feedback (user actions) and explicit feedback (ratings).
    Stores feedback in JSON format for persistence.
    """

    def __init__(self, storage_path: Path | None = None):
        """Initialize the feedback collector.

        Args:
            storage_path: Path to JSON file for storing feedback.
                          Defaults to ~/.vantage/feedback.json
        """
        if storage_path is None:
            storage_path = Path.home() / ".vantage" / "feedback.json"

        self.storage_path = storage_path
        self._feedback: list[WeightFeedback] = []
        self._load()

    def _load(self) -> None:
        """Load feedback from storage."""
        if self.storage_path.exists():
            try:
                with open(self.storage_path, encoding="utf-8") as f:
                    data = json.load(f)
                self._feedback = [WeightFeedback.from_dict(fb) for fb in data]
                logger.debug(f"Loaded {len(self._feedback)} feedback entries")
            except Exception as e:
                logger.error(f"Failed to load feedback: {e}")
                self._feedback = []
        else:
            self._feedback = []

    def _save(self) -> None:
        """Save feedback to storage."""
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(self.storage_path, "w", encoding="utf-8") as f:
                json.dump([fb.to_dict() for fb in self._feedback], f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save feedback: {e}")

    def record_implicit_feedback(
        self,
        system_id: str,
        action: str,
        predicted_score: float,
        component_scores: dict[str, float],
        weights_used: dict[str, float],
        notes: str = "",
    ) -> None:
        """Record implicit feedback from user action.

        Args:
            system_id: ID of the analyzed system
            action: User action - 'dismiss' (ignored warning), 'investigate' (acted on it),
                    'accept' (agreed with score)
            predicted_score: The alignment score shown to user
            component_scores: The component scores at time of action
            weights_used: The weights used for calculation
            notes: Optional additional context
        """
        feedback = WeightFeedback(
            system_id=system_id,
            timestamp=datetime.utcnow().isoformat(),
            feedback_type="implicit",
            action=action,
            predicted_score=predicted_score,
            component_scores=component_scores,
            weights_used=weights_used,
            notes=notes,
        )
        self._feedback.append(feedback)
        self._save()
        logger.info(f"Recorded implicit feedback: {action} for {system_id}")

    def record_explicit_feedback(
        self,
        system_id: str,
        rating: float,
        predicted_score: float,
        component_scores: dict[str, float],
        weights_used: dict[str, float],
        actual_outcome: str | None = None,
        notes: str = "",
    ) -> None:
        """Record explicit feedback (user rating).

        Args:
            system_id: ID of the analyzed system
            rating: User rating 1-5 of score accuracy
            predicted_score: The alignment score shown to user
            component_scores: The component scores at time of rating
            weights_used: The weights used for calculation
            actual_outcome: Optional actual outcome observed
            notes: Optional additional context
        """
        feedback = WeightFeedback(
            system_id=system_id,
            timestamp=datetime.utcnow().isoformat(),
            feedback_type="explicit",
            action="rate",
            rating=rating,
            predicted_score=predicted_score,
            actual_outcome=actual_outcome,
            component_scores=component_scores,
            weights_used=weights_used,
            notes=notes,
        )
        self._feedback.append(feedback)
        self._save()
        logger.info(f"Recorded explicit feedback: {rating}/5 for {system_id}")

    def get_all_feedback(self) -> list[WeightFeedback]:
        """Get all collected feedback."""
        return self._feedback.copy()

    def get_feedback_summary(self) -> dict[str, Any]:
        """Get summary statistics of collected feedback."""
        if not self._feedback:
            return {
                "total_count": 0,
                "implicit_count": 0,
                "explicit_count": 0,
            }

        implicit = [fb for fb in self._feedback if fb.feedback_type == "implicit"]
        explicit = [fb for fb in self._feedback if fb.feedback_type == "explicit"]

        action_counts = {}
        for fb in implicit:
            action_counts[fb.action] = action_counts.get(fb.action, 0) + 1

        explicit_ratings = [fb.rating for fb in explicit if fb.rating is not None]

        return {
            "total_count": len(self._feedback),
            "implicit_count": len(implicit),
            "explicit_count": len(explicit),
            "action_breakdown": action_counts,
            "average_rating": np.mean(explicit_ratings) if explicit_ratings else None,
            "oldest_feedback": min(fb.timestamp for fb in self._feedback),
            "newest_feedback": max(fb.timestamp for fb in self._feedback),
        }

    def clear_feedback(self) -> None:
        """Clear all stored feedback."""
        self._feedback = []
        self._save()
        logger.info("Cleared all feedback")


class BayesianWeightUpdater:
    """Updates alignment weights using Bayesian inference from feedback.

    Uses feedback to update prior weight distributions, producing
    posterior weights that better predict user-rated alignment.
    """

    def __init__(
        self,
        prior_weights: dict[str, float] | None = None,
        storage_path: Path | None = None,
    ):
        """Initialize with prior weights.

        Args:
            prior_weights: AHP-derived baseline weights. Defaults to equal weights.
            storage_path: Path to JSON file for storing weight history.
        """
        if prior_weights is None:
            prior_weights = {
                "responsibility": 0.25,
                "handoff": 0.20,
                "coverage": 0.20,
                "redundancy": 0.15,
                "prompt_quality": 0.20,
            }

        self.baseline_weights = prior_weights.copy()
        self.current_weights = prior_weights.copy()

        # Prior parameters for Dirichlet distribution
        # Start with concentration proportional to prior weights
        self._alpha_prior = {k: v * 10 for k, v in prior_weights.items()}  # Concentration = 10
        self._alpha_posterior = self._alpha_prior.copy()

        if storage_path is None:
            storage_path = Path.home() / ".vantage" / "weight_history.json"
        self.storage_path = storage_path
        self._history: list[WeightHistory] = []
        self._load_history()

    def _load_history(self) -> None:
        """Load weight history from storage."""
        if self.storage_path.exists():
            try:
                with open(self.storage_path, encoding="utf-8") as f:
                    data = json.load(f)
                self._history = [WeightHistory.from_dict(h) for h in data.get("history", [])]

                # Load current alpha if available
                if "alpha_posterior" in data:
                    self._alpha_posterior = data["alpha_posterior"]

                # Load current weights if available
                if "current_weights" in data:
                    self.current_weights = data["current_weights"]

                logger.debug(f"Loaded {len(self._history)} weight history entries")
            except Exception as e:
                logger.error(f"Failed to load weight history: {e}")

    def _save_history(self) -> None:
        """Save weight history to storage."""
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            data = {
                "history": [h.to_dict() for h in self._history],
                "alpha_posterior": self._alpha_posterior,
                "current_weights": self.current_weights,
                "baseline_weights": self.baseline_weights,
            }
            with open(self.storage_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save weight history: {e}")

    def update(self, feedback: list[WeightFeedback]) -> dict[str, float]:
        """Update weights using Bayesian inference from feedback.

        Uses a Dirichlet distribution over weights. Feedback updates the
        concentration parameters based on:
        - Explicit ratings: Higher ratings increase confidence in current weights
        - Implicit actions: 'dismiss' suggests overweighted, 'investigate' suggests underweighted

        Args:
            feedback: List of feedback entries to process

        Returns:
            Updated weight dictionary
        """
        if not feedback:
            return self.current_weights

        # Process each feedback entry
        for fb in feedback:
            if fb.feedback_type == "explicit" and fb.rating is not None:
                # Explicit feedback: adjust based on rating
                # Rating 5 = perfect, increase confidence
                # Rating 1 = very wrong, decrease confidence and adjust
                confidence_factor = (fb.rating - 3) / 2  # -1 to 1

                if confidence_factor > 0:
                    # Good rating: increase concentration around current weights
                    for key in self._alpha_posterior:
                        self._alpha_posterior[key] += confidence_factor * 0.5
                else:
                    # Poor rating: adjust weights based on component scores
                    # Move toward components that might have been underweighted
                    self._adjust_from_poor_rating(fb, abs(confidence_factor))

            elif fb.feedback_type == "implicit":
                # Implicit feedback
                if fb.action == "dismiss":
                    # User dismissed warning - score may have been too low
                    # Slightly reduce confidence in current weights
                    for key in self._alpha_posterior:
                        self._alpha_posterior[key] *= 0.98
                elif fb.action == "investigate":
                    # User investigated - score was useful
                    # Increase confidence slightly
                    for key in self._alpha_posterior:
                        self._alpha_posterior[key] += 0.1
                elif fb.action == "accept":
                    # User accepted - weights are good
                    for key in self._alpha_posterior:
                        self._alpha_posterior[key] += 0.2

        # Compute new weights from posterior
        # Use mean of Dirichlet distribution
        total_alpha = sum(self._alpha_posterior.values())
        self.current_weights = {k: v / total_alpha for k, v in self._alpha_posterior.items()}

        # Record history
        explicit_ratings = [
            fb.rating for fb in feedback if fb.feedback_type == "explicit" and fb.rating is not None
        ]

        history_entry = WeightHistory(
            timestamp=datetime.utcnow().isoformat(),
            weights=self.current_weights.copy(),
            reason=f"Bayesian update from {len(feedback)} feedback entries",
            feedback_count=len(feedback),
            average_rating=(float(np.mean(explicit_ratings)) if explicit_ratings else None),
        )
        self._history.append(history_entry)
        self._save_history()

        logger.info(f"Updated weights from {len(feedback)} feedback entries")
        return self.current_weights

    def _adjust_from_poor_rating(self, feedback: WeightFeedback, adjustment_factor: float) -> None:
        """Adjust weights based on poor rating feedback.

        Analyzes component scores to identify potential misweighting.

        Args:
            feedback: The feedback entry with poor rating
            adjustment_factor: How much to adjust (0-1)
        """
        if not feedback.component_scores:
            return

        # Calculate variance of component scores
        scores = list(feedback.component_scores.values())
        if len(scores) < 2:
            return

        mean_score = np.mean(scores)
        # Components far from mean might need weight adjustment
        for key, score in feedback.component_scores.items():
            if key in self._alpha_posterior:
                deviation = (score - mean_score) / 100  # Normalized

                # If score was high but overall was bad, maybe overweighted
                # If score was low but overall was bad, maybe underweighted
                # This is a simplification - real implementation would need more context
                self._alpha_posterior[key] -= deviation * adjustment_factor * 0.5

        # Ensure all alphas stay positive
        min_alpha = 0.1
        for key in self._alpha_posterior:
            if self._alpha_posterior[key] < min_alpha:
                self._alpha_posterior[key] = min_alpha

    def reset_to_baseline(self) -> dict[str, float]:
        """Reset weights to expert-derived baseline.

        Clears all learned adjustments and restores original AHP weights.

        Returns:
            Baseline weight dictionary
        """
        self.current_weights = self.baseline_weights.copy()
        self._alpha_posterior = {k: v * 10 for k, v in self.baseline_weights.items()}

        history_entry = WeightHistory(
            timestamp=datetime.utcnow().isoformat(),
            weights=self.current_weights.copy(),
            reason="Reset to baseline weights",
            feedback_count=0,
        )
        self._history.append(history_entry)
        self._save_history()

        logger.info("Reset weights to baseline")
        return self.current_weights

    def get_weights(self) -> dict[str, float]:
        """Get current learned weights."""
        return self.current_weights.copy()

    def get_weight_history(self) -> list[WeightHistory]:
        """Get history of weight changes."""
        return self._history.copy()

    def get_weight_confidence(self) -> dict[str, float]:
        """Get confidence in each weight based on posterior concentration.

        Higher values indicate more confidence (more data supporting the weight).

        Returns:
            Dictionary of weight names to confidence scores
        """
        total_alpha = sum(self._alpha_posterior.values())
        baseline_total = sum(self.baseline_weights.values()) * 10

        return {k: self._alpha_posterior[k] / baseline_total for k in self._alpha_posterior}


def get_learned_weights(
    feedback_path: Path | None = None, weight_history_path: Path | None = None
) -> dict[str, float]:
    """Convenience function to get learned weights from stored feedback.

    Args:
        feedback_path: Path to feedback storage
        weight_history_path: Path to weight history storage

    Returns:
        Current learned weights
    """
    collector = FeedbackCollector(storage_path=feedback_path)
    updater = BayesianWeightUpdater(storage_path=weight_history_path)

    # Process any new feedback
    feedback = collector.get_all_feedback()
    if feedback:
        updater.update(feedback)

    return updater.get_weights()
