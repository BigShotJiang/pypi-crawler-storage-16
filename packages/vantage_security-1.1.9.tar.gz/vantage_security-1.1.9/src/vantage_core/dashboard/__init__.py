"""Team Dashboard for Vantage.

Provides historical tracking, trend analysis, and remediation management.
"""

from vantage_core.dashboard.agent_scores import (
    AgentScoreHistory,
    AgentScoreRecord,
    AgentScoreTracker,
    get_agent_score_history,
    get_agent_score_trends,
)
from vantage_core.dashboard.history import (
    HistoryDatabase,
    ScanRecord,
    VulnerabilityTrend,
    get_scan_history,
    get_vulnerability_trends,
    record_scan,
)
from vantage_core.dashboard.remediation import (
    RemediationItem,
    RemediationStatus,
    RemediationTracker,
    create_remediation_item,
    get_remediation_summary,
    update_remediation_status,
)
from vantage_core.dashboard.visualization import (
    DashboardRenderer,
    render_remediation_board,
    render_score_history,
    render_trends_chart,
)

__all__ = [
    # History
    "ScanRecord",
    "VulnerabilityTrend",
    "HistoryDatabase",
    "record_scan",
    "get_scan_history",
    "get_vulnerability_trends",
    # Agent scores
    "AgentScoreRecord",
    "AgentScoreHistory",
    "AgentScoreTracker",
    "get_agent_score_history",
    "get_agent_score_trends",
    # Remediation
    "RemediationStatus",
    "RemediationItem",
    "RemediationTracker",
    "create_remediation_item",
    "update_remediation_status",
    "get_remediation_summary",
    # Visualization
    "DashboardRenderer",
    "render_trends_chart",
    "render_score_history",
    "render_remediation_board",
]
