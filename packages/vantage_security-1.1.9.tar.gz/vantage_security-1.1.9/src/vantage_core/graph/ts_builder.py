from tree_sitter import Language, Parser
import tree_sitter_python
from vantage_core.graph.vantage_graph import VantageGraph
from vantage_core.graph.store import NodeType, EdgeType

class TSBuilder:
    """Tree-Sitter based CPG Builder."""
    
    def __init__(self):
        self.PY_LANGUAGE = Language(tree_sitter_python.language())
        self.parser = Parser(self.PY_LANGUAGE)
        self.graph = VantageGraph()
        
    def build(self, source_code: bytes) -> VantageGraph:
        tree = self.parser.parse(source_code)
        
        # Root module node
        root_id = self.graph.add_node(NodeType.MODULE)
        
        cursor = tree.walk()
        self._visit(cursor, root_id, source_code)
        
        return self.graph

    def _visit(self, cursor, parent_id: int, source: bytes) -> int:
        """Recursive visitor using Tree-Sitter cursor."""
        node_type = cursor.node.type
        current_id = None
        
        # --- Node Creation Logic ---
        if node_type == 'class_definition':
            name = self._get_node_name(cursor.node, source)
            current_id = self.graph.add_node(NodeType.CLASS, {"name": name})
            
        elif node_type == 'function_definition':
            name = self._get_node_name(cursor.node, source)
            current_id = self.graph.add_node(NodeType.FUNCTION, {"name": name})
            
        elif node_type == 'call':
            func_name = self._get_call_name(cursor.node, source)
            current_id = self.graph.add_node(NodeType.CALL, {"name": func_name})
            
            # Process Arguments (Data Flow: Arg -> Call)
            args_node = cursor.node.child_by_field_name('arguments')
            if args_node:
                # Iterate children of argument_list
                # Tree-sitter argument_list children include parens and commas, filter them
                
                # We need a new cursor for the args traversal or manual check
                # Manual Check using child count
                for i in range(args_node.child_count):
                    child = args_node.child(i)
                    if child.type == 'identifier':
                        # Usage of variable
                        arg_name = source[child.start_byte:child.end_byte].decode('utf-8')
                        arg_id = self.graph.add_node(NodeType.VARIABLE, {"name": arg_name})
                        self.graph.add_edge(arg_id, current_id, EdgeType.DATA_FLOW)
                    # Handle other arg types (literals, nested calls) if needed

            
        elif node_type == 'assignment':
            # Handle Assignment Special Case
            # We must process children manually to link flow
            left_node = cursor.node.child_by_field_name('left')
            right_node = cursor.node.child_by_field_name('right')
            
            if left_node and right_node:
                lhs_name = source[left_node.start_byte:left_node.end_byte].decode('utf-8')
                rhs_name = source[right_node.start_byte:right_node.end_byte].decode('utf-8')
                
                # 1. Create RHS Usage Node
                # Note: In full implementation we would recurse. 
                # Here we handle identifier/call RHS for the MVP.
                rhs_type = NodeType.VARIABLE
                if right_node.type == 'call':
                     rhs_type = NodeType.CALL
                     rhs_name = self._get_call_name(right_node, source)
                
                rhs_id = self.graph.add_node(rhs_type, {"name": rhs_name})
                
                # 2. Create LHS Definition Node
                lhs_id = self.graph.add_node(NodeType.VARIABLE, {"name": lhs_name})
                
                # 3. Create Edge
                self.graph.add_edge(rhs_id, lhs_id, EdgeType.DATA_FLOW)
                
                current_id = lhs_id
            else:
                current_id = self.graph.add_node(NodeType.BLOCK, {"type": "assign_error"})
                
        elif node_type == 'identifier':
            name = source[cursor.node.start_byte:cursor.node.end_byte].decode('utf-8')
            current_id = self.graph.add_node(NodeType.VARIABLE, {"name": name})
            
        elif node_type == 'string':
             # Literal
             val = source[cursor.node.start_byte:cursor.node.end_byte].decode('utf-8')
             current_id = self.graph.add_node(NodeType.LITERAL, {"value": val})

        # --- AST Linking ---
        if current_id is not None:
            self.graph.add_edge(parent_id, current_id, EdgeType.AST_CHILD)
            visit_parent = current_id
        else:
            visit_parent = parent_id

        # --- Child Traversal ---
        # Skip automatic child traversal for assignments as we handled them manually
        if node_type != 'assignment':
            if cursor.goto_first_child():
                while True:
                    self._visit(cursor, visit_parent, source)
                    if not cursor.goto_next_sibling():
                        break
                cursor.goto_parent()
                
        return current_id if current_id is not None else parent_id

    def _get_node_name(self, node, source: bytes) -> str:
        child = node.child_by_field_name('name')
        if child:
            return source[child.start_byte:child.end_byte].decode('utf-8')
        return "unknown"

    def _get_call_name(self, node, source: bytes) -> str:
        func_node = node.child_by_field_name('function')
        if func_node:
            return source[func_node.start_byte:func_node.end_byte].decode('utf-8')
        return "unknown"