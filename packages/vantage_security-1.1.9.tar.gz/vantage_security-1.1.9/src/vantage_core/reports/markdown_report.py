"""
Markdown Report Generator for Vantage Security Platform.

This module generates human-readable Markdown reports from scan results.
"""

from vantage_core.security.models import Severity
from vantage_core.security.pipeline.orchestrator import PipelineResult


class MarkdownReportGenerator:
    """
    Generates Markdown reports from scan results.

    Produces a comprehensive Markdown document suitable for
    documentation and sharing.
    """

    def __init__(self):
        """Initialize the Markdown report generator."""
        pass

    def generate(self, result: PipelineResult) -> str:
        """
        Generate a Markdown report from pipeline results.

        Args:
            result: Pipeline execution result

        Returns:
            Markdown string of the report
        """
        sections = []

        # Header
        sections.append(self._build_header(result))

        # Executive Summary
        sections.append(self._build_executive_summary(result))

        # Findings
        sections.append(self._build_findings_section(result))

        # Agent Inventory
        sections.append(self._build_agents_section(result))

        # Simulation Results
        sections.append(self._build_simulation_section(result))

        # Remediation Plan
        sections.append(self._build_remediation_section(result))

        return "\n\n".join(sections)

    def _build_header(self, result: PipelineResult) -> str:
        """Build report header."""
        return f"""# Vantage Security Scan Report

**Scan ID:** `{result.scan_id}`
**Date:** {result.completed_at.strftime('%Y-%m-%d %H:%M:%S')}
**Duration:** {result.duration_ms}ms
**Status:** {result.status.upper()}
"""

    def _build_executive_summary(self, result: PipelineResult) -> str:
        """Build executive summary section."""
        if not result.atss_result:
            return "## Executive Summary\n\nNo scoring data available."

        atss = result.atss_result
        score = atss.overall_score
        grade = atss.grade

        # Determine color/emoji based on grade
        grade_emoji = "🟢" if grade in ["A", "B"] else "🟡" if grade == "C" else "🔴"

        summary = [
            "## Executive Summary",
            "",
            f"### Security Score: {score:.1f}/100 {grade_emoji} (Grade: {grade})",
            "",
            "#### Score Breakdown",
            f"- **Vulnerability Score:** {atss.vulnerability_score:.1f}",
            f"- **Trust Boundary Score:** {atss.trust_boundary_score:.1f}",
            f"- **Communication Score:** {atss.communication_score:.1f}",
            f"- **Agent Risk Score:** {atss.agent_risk_score:.1f}",
        ]

        if atss.recommendations:
            summary.append("")
            summary.append("#### Key Recommendations")
            for rec in atss.recommendations:
                summary.append(f"- {rec}")

        return "\n".join(summary)

    def _build_findings_section(self, result: PipelineResult) -> str:
        """Build findings section."""
        if not result.scan_result:
            return "## Security Findings\n\nNo findings data available."

        findings = result.scan_result.findings
        if not findings:
            return "## Security Findings\n\n✅ No security findings detected."

        counts = {
            "Critical": result.scan_result.critical_count,
            "High": result.scan_result.high_count,
            "Medium": result.scan_result.medium_count,
            "Low": result.scan_result.low_count,
            "Info": result.scan_result.info_count,
        }

        section = [
            "## Security Findings",
            "",
            "### Summary",
            "",
            "| Severity | Count |",
            "|----------|-------|",
            f"| 🔴 Critical | {counts['Critical']} |",
            f"| 🟠 High | {counts['High']} |",
            f"| 🟡 Medium | {counts['Medium']} |",
            f"| 🔵 Low | {counts['Low']} |",
            f"| ⚪ Info | {counts['Info']} |",
            "",
            "### Detailed Findings",
        ]

        # Sort findings by severity (Critical -> Info)
        severity_order = {
            Severity.CRITICAL: 0,
            Severity.HIGH: 1,
            Severity.MEDIUM: 2,
            Severity.LOW: 3,
            Severity.INFO: 4,
        }

        sorted_findings = sorted(findings, key=lambda f: severity_order.get(f.severity, 5))

        for finding in sorted_findings:
            severity_icon = {
                Severity.CRITICAL: "🔴",
                Severity.HIGH: "🟠",
                Severity.MEDIUM: "🟡",
                Severity.LOW: "🔵",
                Severity.INFO: "⚪",
            }.get(finding.severity, "⚪")

            section.append(
                f"#### {severity_icon} [{finding.severity.value.upper()}] {finding.title}"
            )
            section.append(f"**ID:** `{finding.id}` | **Category:** {finding.category.value}")
            section.append("")
            section.append(f"**Description:** {finding.description}")
            section.append("")
            section.append(f"**Location:** `{finding.file_path}:{finding.line_number}`")
            section.append("```python")
            section.append(finding.code_snippet)
            section.append("```")
            section.append(f"**Recommendation:** {finding.recommendation}")
            section.append("")

        return "\n".join(section)

    def _build_agents_section(self, result: PipelineResult) -> str:
        """Build agents section."""
        if not result.scan_result or not result.scan_result.agents:
            return "## Agent Inventory\n\nNo agents detected."

        agents = result.scan_result.agents
        section = [
            "## Agent Inventory",
            "",
            f"**Total Agents:** {len(agents)}",
            f"**Frameworks:** {', '.join(result.scan_result.frameworks_detected)}",
            "",
            "| Agent Name | Framework | Trust Level | Tools |",
            "|------------|-----------|-------------|-------|",
        ]

        for agent in agents:
            tools_count = len(agent.tools)
            section.append(
                f"| {agent.name} | {agent.framework} | {agent.trust_level.value} | {tools_count} |"
            )

        return "\n".join(section)

    def _build_simulation_section(self, result: PipelineResult) -> str:
        """Build simulation results section."""
        if not result.simulation_results:
            return ""

        section = [
            "## Attack Simulation Results",
            "",
            "Simulated propagation of compromised agents.",
            "",
        ]

        for sim in result.simulation_results:
            section.append(f"### Scenario: Compromised `{sim.entry_point}`")
            section.append(f"- **Blast Radius:** {sim.blast_radius * 100:.1f}%")
            section.append(f"- **Infected Agents:** {len(sim.infected_agents)}")
            section.append(f"- **Time to Full Infection:** {sim.time_to_full_infection} steps")
            section.append("")

        return "\n".join(section)

    def _build_remediation_section(self, result: PipelineResult) -> str:
        """Build remediation section."""
        if not result.remediations:
            return ""

        section = [
            "## Remediation Plan",
            "",
            "Suggested fixes for identified vulnerabilities.",
            "",
        ]

        for rem in result.remediations:
            section.append(f"### Fix for {rem.title}")
            section.append(f"**Effort:** {rem.effort} ({rem.effort_hours}h)")
            section.append("")
            section.append(rem.explanation)
            section.append("")
            if rem.diff:
                section.append("```diff")
                section.append(rem.diff)
                section.append("```")
            section.append("")

        return "\n".join(section)
