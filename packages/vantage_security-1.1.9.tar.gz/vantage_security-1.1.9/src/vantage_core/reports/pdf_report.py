"""
PDF Report Generator for Vantage Security Platform.

This module generates PDF executive summary reports with
charts and visualizations.
"""

from datetime import datetime

from vantage_core.security.pipeline.orchestrator import PipelineResult


class PDFReportGenerator:
    """
    Generates PDF executive summary reports from scan results.

    Produces professional PDF output with charts and graphs
    suitable for executive presentations and compliance.
    """

    def __init__(self):
        """Initialize the PDF report generator."""
        pass

    def generate(self, result: PipelineResult) -> bytes:
        """
        Generate a PDF report from pipeline results.

        This implementation generates a simple text-based PDF.
        For production use, consider using ReportLab or WeasyPrint
        for more sophisticated layouts.

        Args:
            result: Pipeline execution result

        Returns:
            PDF bytes
        """
        # Build PDF content using a simple approach
        # In production, use a library like ReportLab or WeasyPrint
        content = self._build_pdf_content(result)
        return content

    def _build_pdf_content(self, result: PipelineResult) -> bytes:
        """
        Build PDF content as bytes.

        This creates a minimal valid PDF for demonstration.
        Production implementation should use proper PDF libraries.
        """
        # Build text content
        text_content = self._build_text_report(result)

        # Create a minimal PDF
        pdf_lines = [
            "%PDF-1.4",
            "1 0 obj",
            "<< /Type /Catalog /Pages 2 0 R >>",
            "endobj",
            "2 0 obj",
            "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            "endobj",
            "3 0 obj",
            "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
            "endobj",
            "4 0 obj",
            f"<< /Length {len(self._encode_pdf_text(text_content))} >>",
            "stream",
            self._encode_pdf_text(text_content),
            "endstream",
            "endobj",
            "5 0 obj",
            "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
            "endobj",
            "xref",
            "0 6",
            "0000000000 65535 f ",
            "0000000009 00000 n ",
            "0000000058 00000 n ",
            "0000000115 00000 n ",
            "0000000266 00000 n ",
            f"0000000{350 + len(self._encode_pdf_text(text_content)):03d} 00000 n ",
            "trailer",
            "<< /Size 6 /Root 1 0 R >>",
            "startxref",
            f"{400 + len(self._encode_pdf_text(text_content))}",
            "%%EOF",
        ]

        return "\n".join(pdf_lines).encode("latin-1")

    def _encode_pdf_text(self, text: str) -> str:
        """Encode text for PDF stream."""
        lines = text.split("\n")
        pdf_commands = ["BT", "/F1 10 Tf", "1 0 0 1 50 750 Tm"]

        y_pos = 750
        for line in lines:
            if y_pos < 50:
                break
            # Escape special PDF characters
            escaped = line.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
            pdf_commands.append(f"({escaped}) Tj")
            y_pos -= 12
            pdf_commands.append(f"1 0 0 1 50 {y_pos} Tm")

        pdf_commands.append("ET")
        return "\n".join(pdf_commands)

    def _build_text_report(self, result: PipelineResult) -> str:
        """Build text content for the PDF."""
        lines = []

        # Header
        lines.append("VANTAGE SECURITY REPORT")
        lines.append("=" * 40)
        lines.append("")
        lines.append(f"Scan ID: {result.scan_id}")
        lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"Status: {result.status}")
        lines.append("")

        # Executive Summary
        lines.append("EXECUTIVE SUMMARY")
        lines.append("-" * 40)

        if result.atss_result:
            lines.append(f"Security Score: {result.atss_result.overall_score:.1f}/100")
            lines.append(f"Grade: {result.atss_result.grade}")
        else:
            lines.append("Security Score: Not available")

        if result.scan_result:
            lines.append(f"Total Findings: {len(result.scan_result.findings)}")
            lines.append(f"  Critical: {result.scan_result.critical_count}")
            lines.append(f"  High: {result.scan_result.high_count}")
            lines.append(f"  Medium: {result.scan_result.medium_count}")
            lines.append(f"  Low: {result.scan_result.low_count}")
            lines.append(f"Agents Analyzed: {result.scan_result.agents_scanned}")
            lines.append(f"Frameworks: {', '.join(result.scan_result.frameworks_detected)}")
        lines.append("")

        # Score Breakdown
        if result.atss_result:
            lines.append("SCORE BREAKDOWN")
            lines.append("-" * 40)
            lines.append(f"Vulnerability Score: {result.atss_result.vulnerability_score:.1f}")
            lines.append(f"Trust Boundary Score: {result.atss_result.trust_boundary_score:.1f}")
            lines.append(f"Communication Score: {result.atss_result.communication_score:.1f}")
            lines.append(f"Agent Risk Score: {result.atss_result.agent_risk_score:.1f}")
            lines.append(f"Confidence: {result.atss_result.confidence:.2f}")
            lines.append("")

        # Top Findings
        if result.scan_result and result.scan_result.findings:
            lines.append("TOP FINDINGS")
            lines.append("-" * 40)

            for i, finding in enumerate(result.scan_result.findings[:5], 1):
                lines.append(f"{i}. [{finding.severity.value.upper()}] {finding.title}")
                lines.append(f"   Location: {finding.file_path}:{finding.line_number}")
                lines.append("")

        # Recommendations
        if result.remediations:
            lines.append("RECOMMENDATIONS")
            lines.append("-" * 40)

            for i, rem in enumerate(result.remediations[:5], 1):
                lines.append(f"{i}. {rem.title}")
                if rem.description:
                    desc = (
                        rem.description[:80] + "..."
                        if len(rem.description) > 80
                        else rem.description
                    )
                    lines.append(f"   {desc}")
                lines.append("")

        # Footer
        lines.append("")
        lines.append("-" * 40)
        lines.append("Generated by Vantage Security Platform")
        lines.append("https://vantage.io")

        return "\n".join(lines)
