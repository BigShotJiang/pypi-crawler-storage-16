"""Scanner for OpenAI Assistants, Swarm, and Agents SDK projects.

Detects agents from OpenAI Assistants API, Swarm framework, and the new Agents SDK.
"""

from __future__ import annotations

import ast
import json
import re
from pathlib import Path
from typing import Any

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult


class OpenAIScanner(BaseScanner):
    """Scanner for OpenAI Assistants, Swarm, and Agents SDK projects."""

    framework_name = "OpenAI"

    # Patterns for OpenAI agent detection
    ASSISTANT_PATTERNS = [
        "client.beta.assistants.create",
        "openai.beta.assistants.create",
        "Assistant(",
    ]

    SWARM_PATTERNS = [
        "from swarm import",
        "Agent(",  # Swarm Agent class
        "Swarm(",
    ]

    # Patterns for new OpenAI Agents SDK
    AGENTS_SDK_PATTERNS = [
        "from agents import",
        "from openai_agents import",
        "from openai.agents import",
    ]

    def scan_directory(self, directory: Path) -> ScanResult:
        """Scan a directory for OpenAI agents."""
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        files_scanned = 0

        # Find Python files
        python_files = list(directory.rglob("*.py"))

        # Also check for assistant config files
        json_files = list(directory.rglob("*.json"))

        for py_file in python_files:
            if self._should_skip_file(py_file):
                continue
            try:
                content = py_file.read_text(encoding="utf-8")
                files_scanned += 1

                # Check if this file uses OpenAI
                if not self._is_openai_file(content):
                    continue

                # Parse AST
                try:
                    tree = ast.parse(content)
                except SyntaxError:
                    continue

                # Extract agents
                file_agents = self._extract_agents(tree, content, py_file)
                agents.extend(file_agents)

                # Extract Swarm handoffs
                file_connections = self._extract_swarm_handoffs(tree, content)
                connections.extend(file_connections)

            except Exception as e:
                self._log_warning(f"Error scanning {py_file}: {e}")

        # Scan JSON config files for assistants
        for json_file in json_files:
            if self._should_skip_file(json_file):
                continue
            try:
                config_agents = self._scan_assistant_config(json_file)
                agents.extend(config_agents)
                files_scanned += 1
            except Exception:
                pass  # Skip invalid JSON files

        # Deduplicate agents
        seen_ids: set[str] = set()
        unique_agents: list[DetectedAgent] = []
        for agent in agents:
            if agent.id not in seen_ids:
                seen_ids.add(agent.id)
                unique_agents.append(agent)

        return ScanResult(
            agents=unique_agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=files_scanned,
            errors=[],
        )

    def _is_openai_file(self, content: str) -> bool:
        """Check if file uses OpenAI Assistants, Swarm, or Agents SDK."""
        patterns = [
            "from openai",
            "import openai",
            "from swarm",
            "import swarm",
            "beta.assistants",
            "from agents import",
            "from openai_agents import",
            "from openai.agents import",
        ]
        return any(p in content for p in patterns)

    def _extract_agents(self, tree: ast.AST, content: str, file_path: Path) -> list[DetectedAgent]:
        """Extract agent definitions from AST."""
        agents: list[DetectedAgent] = []

        # Detect framework type
        is_swarm = "from swarm" in content or "import swarm" in content
        is_agents_sdk = any(p in content for p in self.AGENTS_SDK_PATTERNS)

        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                agent = self._extract_agent_from_call(
                    node, content, file_path, is_swarm, is_agents_sdk
                )
                if agent:
                    agents.append(agent)

            # Handle assignments
            elif isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        agent = self._extract_agent_from_assignment(
                            target,
                            node.value,
                            content,
                            file_path,
                            is_swarm,
                            is_agents_sdk,
                        )
                        if agent:
                            agents.append(agent)

        return agents

    def _extract_agent_from_call(
        self,
        node: ast.Call,
        content: str,
        file_path: Path,
        is_swarm: bool,
        is_agents_sdk: bool = False,
    ) -> DetectedAgent | None:
        """Extract agent from a function call."""
        call_str = self._get_full_call_name(node)
        call_name = self._get_call_name(node)

        # Check for Assistant creation
        is_assistant = any(p in call_str for p in ["assistants.create", "Assistant"])

        # Check for Swarm Agent
        is_swarm_agent = is_swarm and call_name == "Agent"

        # Check for Agents SDK patterns
        is_sdk_agent = is_agents_sdk and call_name == "Agent"

        if not (is_assistant or is_swarm_agent or is_sdk_agent):
            return None

        # Extract agent info
        name = self._extract_name(node) or "Agent"
        agent_id = self._sanitize_id(name)
        instructions = self._extract_instructions(node)
        tools = self._extract_tools(node)

        # Build prompt from instructions and tools
        prompt = instructions or ""
        if tools:
            prompt += f"\n\nTools: {', '.join(tools)}"

        # Determine agent type
        if is_sdk_agent:
            agent_type = "agents_sdk"
            # Extract handoffs for Agents SDK
            handoffs = self._extract_handoffs(node)
            if handoffs:
                prompt += f"\n\nHandoffs: {', '.join(handoffs)}"
        elif is_swarm_agent:
            agent_type = "swarm"
        else:
            agent_type = "assistant"

        return DetectedAgent(
            id=agent_id,
            name=name,
            framework=Framework.OPENAI_SWARM,
            file_path=str(file_path),
            line_number=node.lineno,
            system_prompt=prompt.strip() or f"OpenAI {agent_type}",
            tools=tools,
            metadata={
                "agent_type": agent_type,
            },
        )

    def _extract_agent_from_assignment(
        self,
        target: ast.Name,
        call: ast.Call,
        content: str,
        file_path: Path,
        is_swarm: bool,
        is_agents_sdk: bool = False,
    ) -> DetectedAgent | None:
        """Extract agent from assignment."""
        call_str = self._get_full_call_name(call)
        call_name = self._get_call_name(call)

        # Check for Assistant creation
        is_assistant = any(p in call_str for p in ["assistants.create", "Assistant"])

        # Check for Swarm Agent
        is_swarm_agent = is_swarm and call_name == "Agent"

        # Check for Agents SDK patterns
        is_sdk_agent = is_agents_sdk and call_name == "Agent"

        if not (is_assistant or is_swarm_agent or is_sdk_agent):
            return None

        var_name = target.id
        name = self._extract_name(call) or self._format_name(var_name)
        agent_id = self._sanitize_id(var_name)
        instructions = self._extract_instructions(call)
        tools = self._extract_tools(call)

        prompt = instructions or ""
        if tools:
            prompt += f"\n\nTools: {', '.join(tools)}"

        # Determine agent type
        if is_sdk_agent:
            agent_type = "agents_sdk"
            # Extract handoffs for Agents SDK
            handoffs = self._extract_handoffs(call)
            if handoffs:
                prompt += f"\n\nHandoffs: {', '.join(handoffs)}"
        elif is_swarm_agent:
            agent_type = "swarm"
        else:
            agent_type = "assistant"

        return DetectedAgent(
            id=agent_id,
            name=name,
            framework=Framework.OPENAI_SWARM,
            file_path=str(file_path),
            line_number=call.lineno,
            system_prompt=prompt.strip() or f"OpenAI {agent_type}",
            tools=tools,
            metadata={
                "agent_type": agent_type,
                "variable_name": var_name,
            },
        )

    def _extract_swarm_handoffs(self, tree: ast.AST, content: str) -> list[DetectedConnection]:
        """Extract handoff connections from Swarm agents."""
        connections: list[DetectedConnection] = []

        # Map variable names to agent IDs
        agent_vars: dict[str, str] = {}

        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        if self._get_call_name(node.value) == "Agent":
                            agent_vars[target.id] = self._sanitize_id(target.id)

        # Look for handoff functions in Agent definitions
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and self._get_call_name(node) == "Agent":
                source_id = None

                # Find which variable this is assigned to
                parent = self._find_parent_assign(tree, node)
                if parent and isinstance(parent.targets[0], ast.Name):
                    source_id = agent_vars.get(parent.targets[0].id)

                if not source_id:
                    continue

                # Look for functions keyword that might contain handoffs
                for keyword in node.keywords:
                    if keyword.arg == "functions":
                        target_ids = self._extract_handoff_targets(keyword.value, agent_vars)
                        for target_id in target_ids:
                            if target_id and target_id != source_id:
                                connections.append(
                                    DetectedConnection(
                                        source_id=source_id,
                                        target_id=target_id,
                                        connection_type=ConnectionType.DELEGATION,
                                        confidence=0.95,
                                        confidence_level=ConnectionConfidence.FRAMEWORK,
                                        evidence=[
                                            f"OpenAI Swarm handoff: {source_id} -> {target_id}"
                                        ],
                                    )
                                )

        return connections

    def _extract_handoff_targets(self, node: ast.AST, agent_vars: dict[str, str]) -> list[str]:
        """Extract target agent IDs from handoff functions."""
        targets: list[str] = []

        if isinstance(node, ast.List):
            for elt in node.elts:
                if isinstance(elt, ast.Name):
                    func_name = elt.id
                    # Common Swarm pattern: transfer_to_X functions
                    if func_name.startswith("transfer_to_"):
                        target_name = func_name.replace("transfer_to_", "")
                        if target_name in agent_vars:
                            targets.append(agent_vars[target_name])
                        else:
                            for var_name, agent_id in agent_vars.items():
                                if (
                                    target_name in var_name.lower()
                                    or var_name.lower() in target_name
                                ):
                                    targets.append(agent_id)
                                    break
                            else:
                                targets.append(self._sanitize_id(target_name))

        return targets

    def _find_parent_assign(self, tree: ast.AST, target: ast.Call) -> ast.Assign | None:
        """Find the Assign node that contains this Call."""
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and node.value is target:
                return node
        return None

    def _scan_assistant_config(self, json_file: Path) -> list[DetectedAgent]:
        """Scan a JSON file for assistant configurations."""
        agents: list[DetectedAgent] = []

        try:
            content = json.loads(json_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return agents

        if isinstance(content, dict):
            if "instructions" in content or "name" in content:
                agent = self._parse_assistant_config(content, json_file)
                if agent:
                    agents.append(agent)

        elif isinstance(content, list):
            for item in content:
                if isinstance(item, dict) and ("instructions" in item or "name" in item):
                    agent = self._parse_assistant_config(item, json_file)
                    if agent:
                        agents.append(agent)

        return agents

    def _parse_assistant_config(
        self, config: dict[str, Any], file_path: Path
    ) -> DetectedAgent | None:
        """Parse an assistant configuration dict."""
        name = config.get("name", "Assistant")
        agent_id = self._sanitize_id(name)
        instructions = config.get("instructions", "")

        tools: list[str] = []
        if "tools" in config:
            for tool in config["tools"]:
                if isinstance(tool, dict):
                    tool_type = tool.get("type", "")
                    if tool_type == "function":
                        func_name = tool.get("function", {}).get("name", "")
                        if func_name:
                            tools.append(func_name)
                    elif tool_type:
                        tools.append(tool_type)

        prompt = instructions
        if tools:
            prompt += f"\n\nTools: {', '.join(tools)}"

        return DetectedAgent(
            id=agent_id,
            name=name,
            framework=Framework.OPENAI_SWARM,
            file_path=str(file_path),
            line_number=1,
            system_prompt=prompt.strip() or "OpenAI Assistant",
            tools=tools,
            metadata={"agent_type": "assistant"},
        )

    def _get_call_name(self, node: ast.Call) -> str | None:
        """Get the simple name of a function call."""
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            return node.func.attr
        return None

    def _get_full_call_name(self, node: ast.Call) -> str:
        """Get the full dotted name of a call."""
        parts: list[str] = []

        current = node.func
        while current:
            if isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            elif isinstance(current, ast.Name):
                parts.append(current.id)
                break
            else:
                break

        return ".".join(reversed(parts))

    def _extract_name(self, node: ast.Call) -> str | None:
        """Extract name from call arguments."""
        for keyword in node.keywords:
            if keyword.arg == "name" and isinstance(keyword.value, ast.Constant):
                return str(keyword.value.value)
        return None

    def _extract_instructions(self, node: ast.Call) -> str | None:
        """Extract instructions from call arguments."""
        for keyword in node.keywords:
            if keyword.arg == "instructions" and isinstance(keyword.value, ast.Constant):
                return str(keyword.value.value)
        return None

    def _extract_tools(self, node: ast.Call) -> list[str]:
        """Extract tool names from call arguments."""
        tools: list[str] = []
        for keyword in node.keywords:
            if keyword.arg in ("tools", "functions"):
                if isinstance(keyword.value, ast.List):
                    for elt in keyword.value.elts:
                        if isinstance(elt, ast.Name):
                            tools.append(elt.id)
                        elif isinstance(elt, ast.Dict):
                            for key, val in zip(elt.keys, elt.values):
                                if isinstance(key, ast.Constant) and key.value == "type":
                                    if isinstance(val, ast.Constant):
                                        tools.append(str(val.value))
        return tools

    def _extract_handoffs(self, node: ast.Call) -> list[str]:
        """Extract handoff agent names from Agents SDK call arguments."""
        handoffs: list[str] = []
        for keyword in node.keywords:
            if keyword.arg == "handoffs":
                if isinstance(keyword.value, ast.List):
                    for elt in keyword.value.elts:
                        if isinstance(elt, ast.Name):
                            handoffs.append(elt.id)
                        elif isinstance(elt, ast.Call):
                            call_name = self._get_call_name(elt)
                            if call_name == "Handoff":
                                for kw in elt.keywords:
                                    if kw.arg == "target" and isinstance(kw.value, ast.Name):
                                        handoffs.append(kw.value.id)
                                if elt.args and isinstance(elt.args[0], ast.Name):
                                    handoffs.append(elt.args[0].id)
        return handoffs

    def _sanitize_id(self, name: str) -> str:
        """Convert name to valid ID."""
        name = re.sub(r"[^a-zA-Z0-9]", "_", name)
        name = re.sub(r"([A-Z])", r"_\1", name).lower().strip("_")
        name = re.sub(r"_+", "_", name)
        return name or "agent"

    def _format_name(self, name: str) -> str:
        """Format name for display."""
        name = re.sub(r"_", " ", name)
        name = re.sub(r"([a-z])([A-Z])", r"\1 \2", name)
        return name.title()

    def _log_warning(self, message: str) -> None:
        """Log a warning message."""
        import logging

        logging.getLogger(__name__).warning(message)

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a single file for OpenAI agents."""
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []

        if path.suffix == ".py":
            try:
                content = path.read_text(encoding="utf-8")
                if self._is_openai_file(content):
                    tree = ast.parse(content)
                    agents = self._extract_agents(tree, content, path)
                    connections = self._extract_swarm_handoffs(tree, content)
            except Exception as e:
                self._log_warning(f"Error scanning {path}: {e}")

        elif path.suffix == ".json":
            try:
                config_agents = self._scan_assistant_config(path)
                agents.extend(config_agents)
            except Exception:
                pass

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=[],
        )
