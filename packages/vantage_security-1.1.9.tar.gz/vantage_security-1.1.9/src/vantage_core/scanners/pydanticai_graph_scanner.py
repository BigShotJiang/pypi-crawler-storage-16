from pathlib import Path
from vantage_core.models import DetectedAgent, DetectedConnection, Framework, ScanResult, ConnectionType, ConnectionConfidence
from vantage_core.scanners.base import BaseScanner
from vantage_core.graph.builder import CPGBuilder
from vantage_core.graph.query import CPGQuery

class PydanticAIGraphScanner(BaseScanner):
    """Graph-based Scanner for PydanticAI."""
    
    framework_name = "PydanticAI"

    def scan_file(self, path: Path) -> ScanResult:
        with open(path, "r", encoding="utf-8") as f:
            source = f.read()

        builder = CPGBuilder()
        graph = builder.build(source, str(path))
        query = CPGQuery(graph)
        
        agents = []
        
        # 1. Detect Agents via `Agent(...)` constructor
        calls = query.find_calls_by_name("Agent")
        for call_id, call_node in calls:
            model = query.resolve_argument(call_id, "model")
            system_prompt = query.resolve_argument(call_id, "system_prompt")
            
            # PydanticAI uses dynamic system prompts often, but we catch static ones
            
            name = f"pydantic_agent_{call_node.ast_node.lineno}"
            
            # Detect Tools: Look for methods decorated with @agent.tool or @tool
            # We assume 'agent' variable name matches the instance variable.
            # But the Agent call happens here. The variable is the target of assignment.
            
            # We need to know the variable name assigned to this Agent.
            # Reverse lookup: Who Calls this? No, we need "Who is assigned this?"
            # This requires checking the 'DEFINES' edge from the call result.
            
            # Simplified: Scan ALL functions in file for @*.tool decorators.
            tools = []
            
            # Strategy: Find all functions. Check decorators.
            all_funcs = query.find_nodes_by_type(query.graph.nodes[0]['data'].type.FUNCTION) 
            # Note: query.find_nodes_by_type returns (id, node). 
            # But we need to access NodeType enum properly.
            # Using query helper:
            
            # Iterate all functions in graph
            # This is expensive but accurate for this file scope.
            # Ideally `query.find_methods_with_decorator` supports regex.
            
            # Let's iterate all methods
            # We need to import NodeType to check type
            from vantage_core.graph.models import NodeType
            
            for n_id, node in query.graph.nodes(data=True):
                data = node.get('data')
                if data and data.type == NodeType.FUNCTION:
                    decos = data.data.get('decorators', [])
                    for d in decos:
                        if "tool" in d or "system_prompt" in d:
                            tools.append(data.data.get('name'))
            
            agents.append(DetectedAgent(
                id=self._make_id(name),
                name=name,
                framework=Framework.UNKNOWN, 
                file_path=str(path),
                line_number=call_node.ast_node.lineno,
                system_prompt=str(system_prompt) if system_prompt else "PydanticAI Agent",
                tools=tools,
                metadata={"model": model}
            ))

        return ScanResult(
            agents=agents,
            connections=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=[]
        )
