"""
Context-aware secret detection with entropy analysis.

This module provides advanced secret detection that goes beyond regex patterns
to analyze:
- Shannon entropy of potential secrets
- AST context (how the value is used)
- Variable usage patterns (API calls, auth headers, etc.)
"""

import ast
import math
import re
from collections import Counter
from dataclasses import dataclass, field
from enum import Enum


class UsageType(Enum):
    """Types of usage contexts for potential secrets."""

    AUTH_HEADER = "auth_header"
    API_CALL = "api_call"
    DATABASE_CONNECTION = "database_connection"
    ENCRYPTION_KEY = "encryption_key"
    ENVIRONMENT_REFERENCE = "environment_reference"
    CONFIG_LOOKUP = "config_lookup"
    LOGGING = "logging"
    STRING_FORMATTING = "string_formatting"
    COMPARISON = "comparison"
    UNKNOWN = "unknown"


@dataclass
class EntropyAnalysis:
    """Results of entropy analysis on a potential secret."""

    value: str
    shannon_entropy: float
    char_class_count: int  # Number of character classes (upper, lower, digit, special)
    has_patterns: bool  # Contains repetitive patterns
    is_base64_like: bool
    is_hex_like: bool
    is_uuid_like: bool

    @property
    def entropy_score(self) -> float:
        """
        Normalized entropy score (0-1).

        Higher scores indicate more likely to be a real secret.
        """
        # Base entropy contribution (0-1)
        # Max theoretical entropy is ~4.7 for uniformly random alphanumeric
        base_score = min(self.shannon_entropy / 4.7, 1.0)

        # Boost for multiple character classes
        class_boost = min(self.char_class_count / 4, 1.0) * 0.2

        # Penalty for patterns
        pattern_penalty = 0.3 if self.has_patterns else 0

        # Boost for known secret formats
        format_boost = 0
        if self.is_base64_like or self.is_hex_like:
            format_boost = 0.1
        if self.is_uuid_like:
            format_boost = 0.05  # UUIDs are less likely to be API keys

        return max(0, min(1, base_score + class_boost - pattern_penalty + format_boost))


@dataclass
class UsageContext:
    """Context about how a potential secret is used."""

    usage_type: UsageType
    line_number: int
    code_snippet: str
    confidence: float  # How confident we are about this usage type


@dataclass
class SecretContext:
    """Complete context for a potential secret finding."""

    value: str
    variable_name: str | None
    file_path: str
    line_number: int
    entropy_analysis: EntropyAnalysis
    usages: list[UsageContext] = field(default_factory=list)
    is_env_reference: bool = False
    is_placeholder: bool = False
    is_in_test_file: bool = False
    is_in_comment: bool = False
    matches_variable_name: bool = False  # e.g., API_KEY = "API_KEY"

    @property
    def final_confidence(self) -> float:
        """
        Calculate final confidence that this is a real secret.

        Returns value between 0 and 1.
        """
        # Start with entropy score
        confidence = self.entropy_analysis.entropy_score

        # Strong negative signals (likely false positive)
        if self.is_env_reference:
            confidence *= 0.1
        if self.is_placeholder:
            confidence *= 0.1
        if self.is_in_test_file:
            confidence *= 0.2
        if self.is_in_comment:
            confidence *= 0.3
        if self.matches_variable_name:
            confidence *= 0.05

        # Usage context boosts
        high_risk_usages = [
            UsageType.AUTH_HEADER,
            UsageType.API_CALL,
            UsageType.DATABASE_CONNECTION,
            UsageType.ENCRYPTION_KEY,
        ]

        for usage in self.usages:
            if usage.usage_type in high_risk_usages:
                confidence = min(1.0, confidence * 1.5)
            elif usage.usage_type == UsageType.LOGGING:
                # Secrets in logs are bad, but also common false positives
                confidence *= 0.8

        return confidence

    @property
    def is_likely_false_positive(self) -> bool:
        """Check if this is likely a false positive."""
        return self.final_confidence < 0.3


class SecretContextAnalyzer:
    """
    Analyzes potential secrets with full context awareness.

    This analyzer combines multiple signals to determine if a
    detected string is actually a secret:
    - Entropy analysis
    - AST context
    - Variable usage patterns
    - File location
    """

    # Default entropy thresholds by secret type (can be overridden via config)
    DEFAULT_ENTROPY_THRESHOLDS = {
        "api_key": 3.5,
        "password": 3.0,
        "token": 4.0,
        "secret": 3.5,
        "default": 3.0,
    }

    # Patterns that indicate environment variable references
    ENV_PATTERNS = [
        r"os\.environ",
        r"os\.getenv",
        r"environ\.get",
        r"config\.",
        r"settings\.",
        r"ENV\[",
        r"\$\{?\w+\}?",
    ]

    # Patterns that indicate placeholder values
    PLACEHOLDER_PATTERNS = [
        r"your[-_]",
        r"my[-_]",
        r"<[^>]+>",
        r"\{[^}]+\}",
        r"xxx+",
        r"placeholder",
        r"example",
        r"change[-_]?me",
        r"insert[-_]?here",
        r"todo",
        r"fixme",
    ]

    # Common non-secret strings that match patterns
    KNOWN_FALSE_POSITIVES = {
        "password",
        "secret",
        "token",
        "key",
        "api_key",
        "access_token",
        "refresh_token",
        "authorization_code",
        "client_credentials",
        "password_grant",
        "utf-8",
        "ascii",
        "json",
        "xml",
        "html",
        "test",
        "demo",
        "sample",
        "mock",
        "fake",
        "dummy",
    }

    def __init__(self, entropy_thresholds: dict[str, float] | None = None):
        """
        Initialize the analyzer.

        Args:
            entropy_thresholds: Optional dictionary of entropy thresholds by secret type.
                               If not provided, uses DEFAULT_ENTROPY_THRESHOLDS.
                               Can be configured via MimicSettings.get_entropy_thresholds()
        """
        self._env_pattern = re.compile("|".join(self.ENV_PATTERNS), re.IGNORECASE)
        self._placeholder_pattern = re.compile("|".join(self.PLACEHOLDER_PATTERNS), re.IGNORECASE)

        # Allow configuration override of entropy thresholds
        if entropy_thresholds is not None:
            self._entropy_thresholds = entropy_thresholds
        else:
            self._entropy_thresholds = self.DEFAULT_ENTROPY_THRESHOLDS.copy()

    @property
    def entropy_thresholds(self) -> dict[str, float]:
        """Get current entropy thresholds."""
        return self._entropy_thresholds

    def set_entropy_thresholds(self, thresholds: dict[str, float]) -> None:
        """
        Update entropy thresholds at runtime.

        Args:
            thresholds: Dictionary mapping secret types to entropy thresholds
        """
        self._entropy_thresholds.update(thresholds)

    def analyze(
        self,
        value: str,
        file_path: str,
        line_number: int,
        source_code: str,
        variable_name: str | None = None,
    ) -> SecretContext:
        """
        Analyze a potential secret with full context.

        Args:
            value: The potential secret value
            file_path: Path to the source file
            line_number: Line number where found
            source_code: Full source code of the file
            variable_name: Variable name if known

        Returns:
            SecretContext with full analysis
        """
        # Calculate entropy
        entropy_analysis = self._analyze_entropy(value)

        # Get the line for context analysis
        lines = source_code.split("\n")
        line = lines[line_number - 1] if line_number <= len(lines) else ""

        # Check for environment references
        is_env_reference = bool(self._env_pattern.search(line))

        # Check for placeholders
        is_placeholder = (
            bool(self._placeholder_pattern.search(value))
            or value.lower() in self.KNOWN_FALSE_POSITIVES
        )

        # Check if in test file
        is_in_test_file = self._is_test_file(file_path)

        # Check if in comment
        is_in_comment = self._is_in_comment(line, value)

        # Check if value matches variable name
        matches_variable_name = False
        if variable_name:
            # Handle cases like: API_KEY = "API_KEY"
            normalized_var = variable_name.lower().replace("_", "")
            normalized_val = value.lower().replace("_", "").replace("-", "")
            matches_variable_name = normalized_var == normalized_val

        # Analyze usage contexts
        usages = self._find_usages(source_code, variable_name, line_number)

        return SecretContext(
            value=value,
            variable_name=variable_name,
            file_path=file_path,
            line_number=line_number,
            entropy_analysis=entropy_analysis,
            usages=usages,
            is_env_reference=is_env_reference,
            is_placeholder=is_placeholder,
            is_in_test_file=is_in_test_file,
            is_in_comment=is_in_comment,
            matches_variable_name=matches_variable_name,
        )

    def _analyze_entropy(self, value: str) -> EntropyAnalysis:
        """Calculate entropy metrics for a value."""
        if not value:
            return EntropyAnalysis(
                value=value,
                shannon_entropy=0,
                char_class_count=0,
                has_patterns=True,
                is_base64_like=False,
                is_hex_like=False,
                is_uuid_like=False,
            )

        # Shannon entropy
        shannon_entropy = self._calculate_shannon_entropy(value)

        # Character class count
        char_classes = 0
        if any(c.isupper() for c in value):
            char_classes += 1
        if any(c.islower() for c in value):
            char_classes += 1
        if any(c.isdigit() for c in value):
            char_classes += 1
        if any(not c.isalnum() for c in value):
            char_classes += 1

        # Check for repetitive patterns
        has_patterns = self._has_repetitive_patterns(value)

        # Check for known formats
        is_base64_like = bool(re.match(r"^[A-Za-z0-9+/=]+$", value)) and len(value) >= 16
        is_hex_like = bool(re.match(r"^[0-9a-fA-F]+$", value)) and len(value) >= 16
        is_uuid_like = bool(
            re.match(
                r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$",
                value,
            )
        )

        return EntropyAnalysis(
            value=value,
            shannon_entropy=shannon_entropy,
            char_class_count=char_classes,
            has_patterns=has_patterns,
            is_base64_like=is_base64_like,
            is_hex_like=is_hex_like,
            is_uuid_like=is_uuid_like,
        )

    def _calculate_shannon_entropy(self, value: str) -> float:
        """Calculate Shannon entropy of a string."""
        if not value:
            return 0.0

        # Count character frequencies
        freq = Counter(value)
        length = len(value)

        # Calculate entropy
        entropy = 0.0
        for count in freq.values():
            if count > 0:
                p = count / length
                entropy -= p * math.log2(p)

        return entropy

    def _has_repetitive_patterns(self, value: str) -> bool:
        """Check if value has repetitive patterns."""
        if len(value) < 4:
            return True

        # Check for repeated characters
        if len(set(value)) < len(value) / 4:
            return True

        # Check for repeated substrings
        for pattern_len in range(2, min(len(value) // 2 + 1, 10)):
            pattern = value[:pattern_len]
            if value == pattern * (len(value) // pattern_len) + pattern[: len(value) % pattern_len]:
                return True

        # Check for keyboard patterns
        keyboard_patterns = ["qwerty", "asdf", "1234", "abcd", "0000"]
        value_lower = value.lower()
        if any(p in value_lower for p in keyboard_patterns):
            return True

        return False

    def _is_test_file(self, file_path: str) -> bool:
        """Check if file is a test file."""
        path_lower = file_path.lower()
        return any(
            [
                "/test_" in path_lower,
                "_test.py" in path_lower,
                "/tests/" in path_lower,
                "/test/" in path_lower,
                "/testing/" in path_lower,
                "conftest.py" in path_lower,
                "/fixtures/" in path_lower,
                "/mock" in path_lower,
            ]
        )

    def _is_in_comment(self, line: str, value: str) -> bool:
        """Check if the value appears to be in a comment."""
        # Find where the value is in the line
        value_pos = line.find(value)
        if value_pos == -1:
            return False

        # Check if there's a # before it (outside of strings)
        before_value = line[:value_pos]

        # Simple check: is there a # not inside a string?
        in_string = False
        string_char = None
        for i, char in enumerate(before_value):
            if char in "\"'" and (i == 0 or before_value[i - 1] != "\\"):
                if not in_string:
                    in_string = True
                    string_char = char
                elif char == string_char:
                    in_string = False
            elif char == "#" and not in_string:
                return True

        return False

    def _find_usages(
        self, source_code: str, variable_name: str | None, definition_line: int
    ) -> list[UsageContext]:
        """Find usages of the variable to determine context."""
        usages = []

        if not variable_name:
            return usages

        try:
            tree = ast.parse(source_code)
        except SyntaxError:
            return usages

        # Find all usages of this variable
        for node in ast.walk(tree):
            usage = self._check_usage_context(node, variable_name)
            if usage:
                usages.append(usage)

        return usages

    def _check_usage_context(self, node: ast.AST, variable_name: str) -> UsageContext | None:
        """Check if this AST node represents a usage of the variable."""

        # Check for API call patterns
        if isinstance(node, ast.Call):
            # Check if variable is passed as argument
            for arg in node.args:
                if isinstance(arg, ast.Name) and arg.id == variable_name:
                    return self._classify_call_usage(node, arg)

            # Check keyword arguments
            for keyword in node.keywords:
                if isinstance(keyword.value, ast.Name) and keyword.value.id == variable_name:
                    usage_type = self._classify_keyword_usage(keyword.arg)
                    if usage_type:
                        return UsageContext(
                            usage_type=usage_type,
                            line_number=node.lineno,
                            code_snippet=(ast.unparse(node) if hasattr(ast, "unparse") else ""),
                            confidence=0.8,
                        )

        # Check for dictionary/header assignments
        if isinstance(node, ast.Subscript):
            if isinstance(node.value, ast.Name):
                if "header" in node.value.id.lower():
                    return UsageContext(
                        usage_type=UsageType.AUTH_HEADER,
                        line_number=node.lineno,
                        code_snippet="",
                        confidence=0.9,
                    )

        return None

    def _classify_call_usage(self, call_node: ast.Call, arg_node: ast.AST) -> UsageContext | None:
        """Classify what type of call this variable is used in."""
        func_name = ""

        if isinstance(call_node.func, ast.Name):
            func_name = call_node.func.id.lower()
        elif isinstance(call_node.func, ast.Attribute):
            func_name = call_node.func.attr.lower()

        # Classify based on function name
        usage_type = UsageType.UNKNOWN
        confidence = 0.5

        if any(x in func_name for x in ["request", "fetch", "get", "post", "put", "delete"]):
            usage_type = UsageType.API_CALL
            confidence = 0.8
        elif any(x in func_name for x in ["connect", "create_engine", "cursor"]):
            usage_type = UsageType.DATABASE_CONNECTION
            confidence = 0.9
        elif any(x in func_name for x in ["encrypt", "decrypt", "sign", "verify"]):
            usage_type = UsageType.ENCRYPTION_KEY
            confidence = 0.9
        elif any(x in func_name for x in ["log", "print", "debug", "info", "warning", "error"]):
            usage_type = UsageType.LOGGING
            confidence = 0.7
        elif any(x in func_name for x in ["format", "join", "replace"]):
            usage_type = UsageType.STRING_FORMATTING
            confidence = 0.6

        if usage_type != UsageType.UNKNOWN:
            return UsageContext(
                usage_type=usage_type,
                line_number=call_node.lineno,
                code_snippet="",
                confidence=confidence,
            )

        return None

    def _classify_keyword_usage(self, keyword_name: str | None) -> UsageType | None:
        """Classify usage based on keyword argument name."""
        if not keyword_name:
            return None

        kw_lower = keyword_name.lower()

        if any(x in kw_lower for x in ["auth", "token", "bearer", "api_key", "apikey"]):
            return UsageType.AUTH_HEADER
        elif any(x in kw_lower for x in ["password", "passwd", "pwd"]):
            return UsageType.DATABASE_CONNECTION
        elif any(x in kw_lower for x in ["key", "secret"]) and "encrypt" in kw_lower:
            return UsageType.ENCRYPTION_KEY

        return None

    def should_report(self, context: SecretContext, min_confidence: float = 0.5) -> bool:
        """
        Determine if this secret should be reported based on context.

        Args:
            context: The analyzed secret context
            min_confidence: Minimum confidence threshold (0-1)

        Returns:
            True if the secret should be reported
        """
        # Check confidence threshold
        if context.final_confidence < min_confidence:
            return False

        # Check entropy threshold using instance thresholds
        entropy_threshold = self._entropy_thresholds.get(
            "default"
            if not context.variable_name
            else next(
                (k for k in self._entropy_thresholds if k in context.variable_name.lower()),
                "default",
            )
        )

        if context.entropy_analysis.shannon_entropy < entropy_threshold:
            # Low entropy, but might still be a secret if other signals are strong
            if context.final_confidence < 0.7:
                return False

        return True
