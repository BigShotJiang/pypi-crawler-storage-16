"""
Route registration for Web Dashboard Backend APIs.

This module registers all the dashboard-related API routes including
projects, dashboard widgets, visualizations, and webhooks.
"""

from fastapi import FastAPI

from vantage_core.security.api.dashboard import router as dashboard_router
from vantage_core.security.api.projects import router as projects_router
from vantage_core.security.api.visualizations import router as visualizations_router
from vantage_core.security.api.websocket import router as websocket_router


def register_dashboard_routes(app: FastAPI) -> None:
    """
    Register all dashboard-related API routes.

    Args:
        app: FastAPI application instance
    """
    # Project management endpoints
    app.include_router(
        projects_router,
        prefix="/api/v1",
        tags=["projects"],
    )

    # Dashboard score widgets and summaries
    app.include_router(
        dashboard_router,
        prefix="/api/v1",
        tags=["dashboard"],
    )

    # Visualization data endpoints
    app.include_router(
        visualizations_router,
        prefix="/api/v1",
        tags=["visualizations"],
    )

    # WebSocket endpoints
    app.include_router(
        websocket_router,
        prefix="/api/v1",
        tags=["websocket"],
    )


def get_all_dashboard_routers():
    """
    Get all dashboard-related routers for inclusion.

    Returns:
        List of router tuples (router, prefix, tags)
    """
    return [
        (projects_router, "/api/v1", ["projects"]),
        (dashboard_router, "/api/v1", ["dashboard"]),
        (visualizations_router, "/api/v1", ["visualizations"]),
        (websocket_router, "/api/v1", ["websocket"]),
    ]


__all__ = [
    "register_dashboard_routes",
    "get_all_dashboard_routers",
    "projects_router",
    "dashboard_router",
    "visualizations_router",
    "websocket_router",
]
