"""
File Upload Handler for Vantage Security Platform.

This module implements secure file upload handling including:
- Pre-signed URL generation for S3/local storage
- File validation (size limit 100MB, allowed types)
- Archive extraction with bomb protection
- ClamAV integration for malware scanning
- Cleanup after processing
"""

import asyncio
import hashlib
import os
import re
import shutil
import struct
import tarfile
import zipfile
from collections.abc import Callable
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field, field_validator

from vantage_core.security.api.db_models import UploadStatus


def _get_archive_opener(file_path: Path, filename: str) -> Callable[[], Any]:
    """Helper to get the correct archive opener."""

    if filename.endswith((".tar.gz", ".tgz")):

        def open_gz_tar():

            return tarfile.open(fileobj=gzip.open(file_path, "rb"))

        return open_gz_tar

    else:

        def open_tar():

            return tarfile.open(file_path)

        return open_tar


# Configuration
class UploadConfig:
    """Upload configuration."""

    MAX_FILE_SIZE: int = 100 * 1024 * 1024  # 100MB
    PRESIGN_EXPIRY_MINUTES: int = 15
    CLEANUP_AFTER_HOURS: int = 1

    ALLOWED_EXTENSIONS: list[str] = [".zip", ".tar.gz", ".tgz", ".tar", ".py"]

    ALLOWED_CONTENT_TYPES: dict[str, list[str]] = {
        ".zip": ["application/zip", "application/x-zip-compressed"],
        ".tar.gz": ["application/gzip", "application/x-gzip"],
        ".tgz": ["application/gzip", "application/x-gzip"],
        ".tar": ["application/x-tar"],
        ".py": ["text/x-python", "text/plain", "application/x-python-code"],
    }

    # Magic bytes for file type validation
    MAGIC_BYTES: dict[str, list[bytes]] = {
        ".zip": [b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08"],
        ".gz": [b"\x1f\x8b"],
        ".tar": [b"ustar"],
    }

    # Archive bomb protection
    MAX_ARCHIVE_FILES: int = 10000
    MAX_ARCHIVE_SIZE: int = 500 * 1024 * 1024  # 500MB expanded
    MAX_ARCHIVE_DEPTH: int = 5
    MAX_COMPRESSION_RATIO: int = 10

    # ClamAV settings
    CLAMAV_SOCKET: str = "/var/run/clamav/clamd.sock"
    CLAMAV_TIMEOUT: int = 30

    # Storage settings
    STORAGE_BACKEND: str = "local"  # "local" or "s3"
    LOCAL_STORAGE_PATH: str = "/tmp/vantage/uploads"
    S3_BUCKET: str = ""
    S3_PREFIX: str = "uploads/"


config = UploadConfig()


# Request/Response Models
class PresignRequest(BaseModel):
    """Request for pre-signed upload URL."""

    filename: str = Field(min_length=1, max_length=255)
    content_type: str
    file_size: int = Field(gt=0, le=config.MAX_FILE_SIZE)

    @field_validator("filename")
    @classmethod
    def validate_filename(cls, v: str) -> str:
        """Validate filename format and extension."""
        # Sanitize filename
        v = v.strip()

        # Block path traversal
        if ".." in v or v.startswith("/") or re.search(r"[<>:\"|?*]", v):
            raise ValueError("Invalid filename")

        # Check extension
        ext = "".join(Path(v).suffixes).lower()
        if not any(v.lower().endswith(allowed) for allowed in config.ALLOWED_EXTENSIONS):
            allowed = ", ".join(config.ALLOWED_EXTENSIONS)
            raise ValueError(f"File type not allowed. Allowed: {allowed}")

        return v

    @field_validator("content_type")
    @classmethod
    def validate_content_type(cls, v: str) -> str:
        """Validate content type."""
        all_types = []
        for types in config.ALLOWED_CONTENT_TYPES.values():
            all_types.extend(types)

        if v not in all_types:
            raise ValueError(f"Content type {v} not allowed")

        return v


class PresignResponse(BaseModel):
    """Response with pre-signed upload URL."""

    upload_id: str
    upload_url: str
    expires_at: datetime
    fields: dict[str, str] = Field(default_factory=dict)  # For S3 POST
    method: str = "PUT"


class UploadCompleteRequest(BaseModel):
    """Request to mark upload as complete."""

    file_hash: str | None = None  # Optional SHA-256 for verification


class UploadStatusResponse(BaseModel):
    """Upload status response."""

    upload_id: str
    status: str
    filename: str
    file_size: int
    created_at: datetime
    completed_at: datetime | None = None
    scan_id: str | None = None
    error_message: str | None = None
    malware_detected: bool = False
    malware_details: str | None = None


class ValidationResult(BaseModel):
    """File validation result."""

    valid: bool
    errors: list[str] = Field(default_factory=list)


class MalwareScanResult(BaseModel):
    """Malware scan result."""

    clean: bool
    malware_name: str | None = None
    error: str | None = None


class ArchiveAnalysisResult(BaseModel):
    """Archive bomb analysis result."""

    safe: bool
    reason: str | None = None
    file_count: int = 0
    total_size: int = 0
    max_depth: int = 0
    compression_ratio: float = 0.0


class UploadService:
    """
    File upload service with security controls.

    Handles secure file uploads with validation, malware scanning,
    and archive bomb protection.
    """

    def __init__(self):
        """Initialize upload service."""
        # In-memory storage for development
        self._uploads: dict[str, dict] = {}

        # Ensure local storage directory exists
        if config.STORAGE_BACKEND == "local":
            Path(config.LOCAL_STORAGE_PATH).mkdir(parents=True, exist_ok=True)

    async def generate_presign_url(self, user_id: str, request: PresignRequest) -> PresignResponse:
        """
        Generate pre-signed URL for direct upload.

        Args:
            user_id: User identifier
            request: Pre-sign request data

        Returns:
            Pre-signed URL response
        """
        upload_id = str(uuid4())
        expires_at = datetime.utcnow() + timedelta(minutes=config.PRESIGN_EXPIRY_MINUTES)

        # Generate storage key
        safe_filename = self._sanitize_filename(request.filename)
        storage_key = f"{config.S3_PREFIX}{upload_id}/{safe_filename}"

        # Create upload record
        self._uploads[upload_id] = {
            "id": upload_id,
            "user_id": user_id,
            "filename": safe_filename,
            "original_filename": request.filename,
            "content_type": request.content_type,
            "file_size": request.file_size,
            "storage_key": storage_key,
            "status": UploadStatus.PENDING.value,
            "presign_expires_at": expires_at,
            "created_at": datetime.utcnow(),
            "cleanup_at": datetime.utcnow() + timedelta(hours=config.CLEANUP_AFTER_HOURS),
        }

        if config.STORAGE_BACKEND == "s3":
            # Generate S3 pre-signed URL
            upload_url, fields = await self._generate_s3_presign(
                storage_key, request.content_type, request.file_size, expires_at
            )
            return PresignResponse(
                upload_id=upload_id,
                upload_url=upload_url,
                expires_at=expires_at,
                fields=fields,
                method="POST",
            )
        else:
            # Local storage - return direct upload URL
            upload_url = f"/api/v1/uploads/{upload_id}/file"
            return PresignResponse(
                upload_id=upload_id,
                upload_url=upload_url,
                expires_at=expires_at,
                method="PUT",
            )

    async def _generate_s3_presign(
        self, key: str, content_type: str, file_size: int, expires_at: datetime
    ) -> tuple[str, dict]:
        """
        Generate S3 pre-signed POST URL.

        In production, use boto3 to generate actual pre-signed URLs.
        """
        # Mock implementation - replace with actual S3 client
        return (
            f"https://s3.amazonaws.com/{config.S3_BUCKET}/{key}",
            {
                "key": key,
                "Content-Type": content_type,
                "x-amz-meta-upload-id": key.split("/")[1],
            },
        )

    async def save_file(self, upload_id: str, content: bytes) -> bool:
        """
        Save uploaded file content (for local storage).

        Args:
            upload_id: Upload identifier
            content: File content bytes

        Returns:
            True if saved successfully
        """
        upload = self._uploads.get(upload_id)
        if not upload:
            return False

        # Save to local storage
        file_path = Path(config.LOCAL_STORAGE_PATH) / upload_id / upload["filename"]
        file_path.parent.mkdir(parents=True, exist_ok=True)

        with open(file_path, "wb") as f:
            f.write(content)

        # Calculate hash
        file_hash = hashlib.sha256(content).hexdigest()
        upload["file_hash"] = file_hash
        upload["status"] = UploadStatus.UPLOADING.value

        return True

    async def complete_upload(
        self, upload_id: str, user_id: str, request: UploadCompleteRequest = None
    ) -> UploadStatusResponse:
        """
        Mark upload as complete and trigger processing.

        Args:
            upload_id: Upload identifier
            user_id: User identifier
            request: Completion request

        Returns:
            Upload status response
        """
        upload = self._uploads.get(upload_id)
        if not upload:
            raise ValueError("Upload not found")

        if upload["user_id"] != user_id:
            raise PermissionError("Not authorized to access this upload")

        # Verify hash if provided
        if request and request.file_hash:
            if upload.get("file_hash") and upload["file_hash"] != request.file_hash:
                upload["status"] = UploadStatus.FAILED.value
                upload["error_message"] = "File hash mismatch"
                return self._to_status_response(upload)

        # Update status
        upload["status"] = UploadStatus.SCANNING.value

        # Trigger async processing
        asyncio.create_task(self._process_upload(upload_id))

        return self._to_status_response(upload)

    async def _process_upload(self, upload_id: str):
        """
        Process uploaded file: validate, scan, extract.

        Args:
            upload_id: Upload identifier
        """
        upload = self._uploads.get(upload_id)
        if not upload:
            return

        try:
            # Get file path
            if config.STORAGE_BACKEND == "local":
                file_path = Path(config.LOCAL_STORAGE_PATH) / upload_id / upload["filename"]
            else:
                # Download from S3
                file_path = await self._download_from_s3(upload["storage_key"])

            if not file_path.exists():
                upload["status"] = UploadStatus.FAILED.value
                upload["error_message"] = "File not found"
                return

            # Read file content
            with open(file_path, "rb") as f:
                content = f.read()

            # Validate file
            validation = await self.validate_file(content, upload["filename"])
            if not validation.valid:
                upload["status"] = UploadStatus.FAILED.value
                upload["error_message"] = "; ".join(validation.errors)
                return

            # Scan for malware
            upload["status"] = UploadStatus.SCANNING.value
            scan_result = await self.scan_for_malware(content)

            if not scan_result.clean:
                upload["status"] = UploadStatus.MALWARE_DETECTED.value
                upload["malware_scan_result"] = {
                    "clean": False,
                    "malware_name": scan_result.malware_name,
                }
                upload["error_message"] = f"Malware detected: {scan_result.malware_name}"
                return

            # If archive, analyze for bombs
            if upload["filename"].endswith((".zip", ".tar.gz", ".tgz", ".tar")):
                analysis = await self.analyze_archive(file_path)
                if not analysis.safe:
                    upload["status"] = UploadStatus.FAILED.value
                    upload["error_message"] = f"Archive rejected: {analysis.reason}"
                    return

            # Processing complete
            upload["status"] = UploadStatus.PROCESSING.value
            upload["malware_scan_result"] = {"clean": True}

            # Extract archive if needed
            if upload["filename"].endswith((".zip", ".tar.gz", ".tgz", ".tar")):
                extract_path = await self.extract_archive(file_path, upload_id)
                upload["extracted_path"] = str(extract_path)

            upload["status"] = UploadStatus.COMPLETED.value
            upload["completed_at"] = datetime.utcnow()

        except Exception as e:
            upload["status"] = UploadStatus.FAILED.value
            upload["error_message"] = str(e)

    async def validate_file(self, content: bytes, filename: str) -> ValidationResult:
        """
        Validate file content and type.

        Args:
            content: File content bytes
            filename: Original filename

        Returns:
            Validation result
        """
        errors = []

        # Size validation
        if len(content) > config.MAX_FILE_SIZE:
            errors.append(f"File size exceeds maximum of {config.MAX_FILE_SIZE // 1024 // 1024}MB")

        # Extension validation
        ext = "".join(Path(filename).suffixes).lower()

        # Special handling for .tar.gz
        if filename.lower().endswith(".tar.gz"):
            ext = ".tar.gz"
        elif filename.lower().endswith(".tgz"):
            ext = ".tgz"
        else:
            ext = Path(filename).suffix.lower()

        if ext not in [".zip", ".tar.gz", ".tgz", ".tar", ".py"]:
            errors.append(f"File extension {ext} not allowed")
            return ValidationResult(valid=False, errors=errors)

        # Magic byte validation
        if ext in [".zip"]:
            if not any(content.startswith(magic) for magic in config.MAGIC_BYTES[".zip"]):
                errors.append("File content does not match ZIP format")
        elif ext in [".tar.gz", ".tgz"]:
            if not content.startswith(config.MAGIC_BYTES[".gz"][0]):
                errors.append("File content does not match GZIP format")
        elif ext == ".tar":
            # TAR magic bytes are at offset 257
            if len(content) >= 262 and b"ustar" not in content[257:262]:
                errors.append("File content does not match TAR format")
        elif ext == ".py":
            # Basic Python file validation
            try:
                content.decode("utf-8")
            except UnicodeDecodeError:
                errors.append("Python file contains invalid UTF-8")

        return ValidationResult(valid=len(errors) == 0, errors=errors)

    async def scan_for_malware(self, content: bytes) -> MalwareScanResult:
        """
        Scan content for malware using ClamAV.

        Args:
            content: File content bytes

        Returns:
            Malware scan result
        """
        try:
            # Try to connect to ClamAV daemon
            if not os.path.exists(config.CLAMAV_SOCKET):
                # ClamAV not available - mock clean result for development
                return MalwareScanResult(clean=True)

            reader, writer = await asyncio.wait_for(
                asyncio.open_unix_connection(config.CLAMAV_SOCKET),
                timeout=config.CLAMAV_TIMEOUT,
            )

            try:
                # Send INSTREAM command
                writer.write(b"zINSTREAM\x00")

                # Send content in chunks
                chunk_size = 2048
                for i in range(0, len(content), chunk_size):
                    chunk = content[i : i + chunk_size]
                    size = struct.pack("!L", len(chunk))
                    writer.write(size + chunk)

                # Send terminator
                writer.write(struct.pack("!L", 0))
                await writer.drain()

                # Read result
                result = await asyncio.wait_for(reader.read(1024), timeout=config.CLAMAV_TIMEOUT)

                result_str = result.decode().strip()

                if "FOUND" in result_str:
                    # Extract malware name
                    parts = result_str.split(":")
                    if len(parts) >= 2:
                        malware_name = parts[1].strip().replace(" FOUND", "")
                    else:
                        malware_name = "Unknown"

                    return MalwareScanResult(clean=False, malware_name=malware_name)

                return MalwareScanResult(clean=True)

            finally:
                writer.close()
                await writer.wait_closed()

        except FileNotFoundError:
            # ClamAV socket not found - return clean for dev
            return MalwareScanResult(clean=True)
        except asyncio.TimeoutError:
            return MalwareScanResult(clean=False, error="Malware scan timeout")
        except Exception as e:
            # Fail closed - reject on scan error
            return MalwareScanResult(clean=False, error=f"Scan error: {str(e)}")

    async def analyze_archive(self, file_path: Path) -> ArchiveAnalysisResult:
        """
        Analyze archive for potential bombs.

        Args:
            file_path: Path to archive file

        Returns:
            Archive analysis result
        """
        total_size = 0
        file_count = 0
        max_depth = 0
        compressed_size = file_path.stat().st_size

        filename = file_path.name.lower()

        try:
            if filename.endswith(".zip"):
                with zipfile.ZipFile(file_path) as zf:
                    for info in zf.infolist():
                        # Count files
                        file_count += 1
                        if file_count > config.MAX_ARCHIVE_FILES:
                            return ArchiveAnalysisResult(
                                safe=False,
                                reason=f"Too many files (>{config.MAX_ARCHIVE_FILES})",
                                file_count=file_count,
                            )

                        # Track size
                        total_size += info.file_size
                        if total_size > config.MAX_ARCHIVE_SIZE:
                            return ArchiveAnalysisResult(
                                safe=False,
                                reason=f"Expanded size exceeds {config.MAX_ARCHIVE_SIZE // 1024 // 1024}MB",
                                total_size=total_size,
                            )

                        # Check compression ratio
                        if info.compress_size > 0:
                            ratio = info.file_size / info.compress_size
                            if ratio > config.MAX_COMPRESSION_RATIO:
                                return ArchiveAnalysisResult(
                                    safe=False,
                                    reason=f"Compression ratio {ratio:.1f} exceeds limit",
                                    compression_ratio=ratio,
                                )

                        # Check nesting depth
                        depth = info.filename.count("/")
                        max_depth = max(max_depth, depth)
                        if depth > config.MAX_ARCHIVE_DEPTH:
                            return ArchiveAnalysisResult(
                                safe=False,
                                reason=f"Nesting depth {depth} exceeds limit",
                                max_depth=depth,
                            )

                        # Check for nested archives
                        if info.filename.lower().endswith((".zip", ".tar", ".gz", ".tgz")):
                            return ArchiveAnalysisResult(
                                safe=False, reason="Nested archives not allowed"
                            )

                        # Check for path traversal
                        if ".." in info.filename or info.filename.startswith("/"):
                            return ArchiveAnalysisResult(
                                safe=False, reason="Path traversal detected"
                            )

            elif filename.endswith((".tar.gz", ".tgz", ".tar")):
                opener = _get_archive_opener(file_path, filename)

                with opener() as tf:
                    for member in tf.getmembers():
                        file_count += 1
                        if file_count > config.MAX_ARCHIVE_FILES:
                            return ArchiveAnalysisResult(
                                safe=False,
                                reason=f"Too many files (>{config.MAX_ARCHIVE_FILES})",
                            )

                        total_size += member.size
                        if total_size > config.MAX_ARCHIVE_SIZE:
                            return ArchiveAnalysisResult(
                                safe=False, reason="Expanded size exceeds limit"
                            )

                        depth = member.name.count("/")
                        max_depth = max(max_depth, depth)
                        if depth > config.MAX_ARCHIVE_DEPTH:
                            return ArchiveAnalysisResult(
                                safe=False, reason="Nesting depth exceeds limit"
                            )

                        # Check for path traversal
                        if ".." in member.name or member.name.startswith("/"):
                            return ArchiveAnalysisResult(
                                safe=False, reason="Path traversal detected"
                            )

                        # Check for symlinks
                        if member.issym() or member.islnk():
                            return ArchiveAnalysisResult(
                                safe=False, reason="Symbolic links not allowed"
                            )

            # Calculate overall compression ratio
            compression_ratio = total_size / compressed_size if compressed_size > 0 else 0

            return ArchiveAnalysisResult(
                safe=True,
                file_count=file_count,
                total_size=total_size,
                max_depth=max_depth,
                compression_ratio=compression_ratio,
            )

        except Exception as e:
            return ArchiveAnalysisResult(safe=False, reason=f"Failed to analyze archive: {str(e)}")

    async def extract_archive(self, file_path: Path, upload_id: str) -> Path:
        """
        Extract archive to temporary directory.

        Args:
            file_path: Path to archive file
            upload_id: Upload identifier

        Returns:
            Path to extracted directory
        """
        extract_dir = Path(config.LOCAL_STORAGE_PATH) / upload_id / "extracted"
        extract_dir.mkdir(parents=True, exist_ok=True)

        filename = file_path.name.lower()

        if filename.endswith(".zip"):
            with zipfile.ZipFile(file_path) as zf:
                # Extract with sanitized paths
                for member in zf.namelist():
                    # Skip directories and dangerous paths
                    if member.endswith("/") or ".." in member:
                        continue

                    # Create safe extraction path
                    safe_path = extract_dir / member.lstrip("/")
                    safe_path.parent.mkdir(parents=True, exist_ok=True)

                    with zf.open(member) as source:
                        with open(safe_path, "wb") as target:
                            target.write(source.read())

        elif filename.endswith((".tar.gz", ".tgz", ".tar")):
            opener = _get_archive_opener(file_path, filename)

            with opener() as tf:
                # Extract with filtering
                for member in tf.getmembers():
                    if member.isfile() and ".." not in member.name:
                        safe_path = extract_dir / member.name.lstrip("/")
                        safe_path.parent.mkdir(parents=True, exist_ok=True)

                        with tf.extractfile(member) as source:
                            with open(safe_path, "wb") as target:
                                target.write(source.read())

        return extract_dir

    async def get_upload_status(self, upload_id: str, user_id: str) -> UploadStatusResponse:
        """
        Get upload processing status.

        Args:
            upload_id: Upload identifier
            user_id: User identifier

        Returns:
            Upload status response
        """
        upload = self._uploads.get(upload_id)
        if not upload:
            raise ValueError("Upload not found")

        if upload["user_id"] != user_id:
            raise PermissionError("Not authorized to access this upload")

        return self._to_status_response(upload)

    async def cleanup_upload(self, upload_id: str):
        """
        Clean up upload files.

        Args:
            upload_id: Upload identifier
        """
        upload = self._uploads.get(upload_id)
        if not upload:
            return

        # Remove local files
        upload_dir = Path(config.LOCAL_STORAGE_PATH) / upload_id
        if upload_dir.exists():
            shutil.rmtree(upload_dir)

        # Remove from memory
        del self._uploads[upload_id]

    async def cleanup_expired(self):
        """Clean up all expired uploads."""
        now = datetime.utcnow()
        expired = [
            uid
            for uid, upload in self._uploads.items()
            if upload.get("cleanup_at") and upload["cleanup_at"] < now
        ]

        for upload_id in expired:
            await self.cleanup_upload(upload_id)

    def _sanitize_filename(self, filename: str) -> str:
        """Sanitize filename for storage."""
        # Remove path components
        filename = Path(filename).name

        # Replace unsafe characters
        safe = re.sub(r"[^a-zA-Z0-9._-]", "_", filename)

        # Limit length
        if len(safe) > 100:
            ext = Path(safe).suffix
            safe = safe[:96] + ext

        return safe

    def _to_status_response(self, upload: dict) -> UploadStatusResponse:
        """Convert upload dict to status response."""
        malware_result = upload.get("malware_scan_result", {})

        return UploadStatusResponse(
            upload_id=upload["id"],
            status=upload["status"],
            filename=upload["original_filename"],
            file_size=upload["file_size"],
            created_at=upload["created_at"],
            completed_at=upload.get("completed_at"),
            scan_id=upload.get("scan_id"),
            error_message=upload.get("error_message"),
            malware_detected=(not malware_result.get("clean", True) if malware_result else False),
            malware_details=malware_result.get("malware_name"),
        )


# Global upload service instance
upload_service = UploadService()
