"""
Attack path aggregation and report consolidation for finding deduplication.

This module provides:
- AttackPathAggregator: Group findings by attack vectors they enable
- ReportConsolidator: Consolidate findings into deduplicated report

These components work together to reduce finding noise and highlight
the most critical attack paths in the codebase.
"""

from dataclasses import dataclass, field
from enum import Enum

from vantage_core.security.deduplication.fingerprinting import (
    FindingGroup,
    FingerprintGenerator,
    SimilarityMatcher,
)
from vantage_core.security.models import (
    SecurityFinding,
    Severity,
    VulnerabilityCategory,
)


class AttackVector(str, Enum):
    """Types of attack vectors that findings can enable."""

    CREDENTIAL_EXPOSURE = "credential_exposure"
    INJECTION = "injection"
    AUTH_BYPASS = "auth_bypass"
    DATA_EXFILTRATION = "data_exfiltration"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    SUPPLY_CHAIN = "supply_chain"
    DENIAL_OF_SERVICE = "denial_of_service"


@dataclass
class AttackPath:
    """
    A path of findings that enable a specific attack vector.

    Attack paths group related findings to show how multiple
    vulnerabilities can be chained together.
    """

    vector: AttackVector
    findings: list[SecurityFinding] = field(default_factory=list)
    severity: Severity = Severity.INFO  # Worst severity in path
    description: str = ""


class AttackPathAggregator:
    """
    Group findings by the attack vectors they enable.

    Maps vulnerability categories to attack vectors and groups
    findings accordingly, calculating risk based on the worst
    severity in each path.
    """

    # Mapping from vulnerability categories to attack vectors
    CATEGORY_TO_VECTOR: dict[VulnerabilityCategory, AttackVector] = {
        VulnerabilityCategory.PROMPT_INJECTION: AttackVector.INJECTION,
        VulnerabilityCategory.CODE_EXECUTION: AttackVector.INJECTION,
        VulnerabilityCategory.DATA_LEAKAGE: AttackVector.DATA_EXFILTRATION,
        VulnerabilityCategory.HARDCODED_SECRET: AttackVector.CREDENTIAL_EXPOSURE,
        VulnerabilityCategory.PRIVILEGE_ESCALATION: AttackVector.PRIVILEGE_ESCALATION,
        VulnerabilityCategory.EXCESSIVE_AGENCY: AttackVector.PRIVILEGE_ESCALATION,
        VulnerabilityCategory.TRUST_BOUNDARY_VIOLATION: AttackVector.AUTH_BYPASS,
        VulnerabilityCategory.UNSAFE_DELEGATION: AttackVector.AUTH_BYPASS,
        VulnerabilityCategory.INSECURE_TOOL_USE: AttackVector.INJECTION,
        VulnerabilityCategory.CONFIGURATION_WEAKNESS: AttackVector.AUTH_BYPASS,
        VulnerabilityCategory.SUPPLY_CHAIN: AttackVector.SUPPLY_CHAIN,
        VulnerabilityCategory.LICENSE_VIOLATION: AttackVector.SUPPLY_CHAIN,
    }

    # Descriptions for each attack vector
    VECTOR_DESCRIPTIONS: dict[AttackVector, str] = {
        AttackVector.CREDENTIAL_EXPOSURE: "Exposed credentials enable unauthorized access to systems and data",
        AttackVector.INJECTION: "Injection vulnerabilities allow attackers to execute malicious code or commands",
        AttackVector.AUTH_BYPASS: "Authentication/authorization flaws enable unauthorized access",
        AttackVector.DATA_EXFILTRATION: "Data leakage vulnerabilities expose sensitive information",
        AttackVector.PRIVILEGE_ESCALATION: "Privilege escalation enables attackers to gain elevated access",
        AttackVector.SUPPLY_CHAIN: "Supply chain vulnerabilities introduce risk from dependencies",
        AttackVector.DENIAL_OF_SERVICE: "DoS vulnerabilities can disrupt service availability",
    }

    def __init__(self):
        """Initialize the attack path aggregator."""
        pass

    def aggregate(self, findings: list[SecurityFinding]) -> list[AttackPath]:
        """
        Group findings by attack vector.

        Args:
            findings: List of security findings

        Returns:
            List of attack paths sorted by severity (worst first)
        """
        if not findings:
            return []

        # Group findings by attack vector
        vector_findings: dict[AttackVector, list[SecurityFinding]] = {}

        for finding in findings:
            vector = self._get_vector_for_category(finding.category)
            if vector not in vector_findings:
                vector_findings[vector] = []
            vector_findings[vector].append(finding)

        # Create attack paths
        paths: list[AttackPath] = []

        for vector, vec_findings in vector_findings.items():
            # Determine worst severity
            worst_severity = self._get_worst_severity(vec_findings)

            path = AttackPath(
                vector=vector,
                findings=vec_findings,
                severity=worst_severity,
                description=self.VECTOR_DESCRIPTIONS.get(vector, ""),
            )
            paths.append(path)

        # Sort by severity (worst first)
        paths.sort(key=lambda p: -self._severity_rank(p.severity))

        return paths

    def _get_vector_for_category(self, category: VulnerabilityCategory) -> AttackVector:
        """
        Get the attack vector for a vulnerability category.

        Args:
            category: Vulnerability category

        Returns:
            Corresponding attack vector (defaults to INJECTION if unknown)
        """
        return self.CATEGORY_TO_VECTOR.get(category, AttackVector.INJECTION)

    def _get_worst_severity(self, findings: list[SecurityFinding]) -> Severity:
        """
        Get the worst severity from a list of findings.

        Args:
            findings: List of findings

        Returns:
            Worst severity level
        """
        if not findings:
            return Severity.INFO

        return max(findings, key=lambda f: self._severity_rank(f.severity)).severity

    def _severity_rank(self, severity: Severity) -> int:
        """
        Get numeric rank for severity.

        Args:
            severity: Severity level

        Returns:
            Numeric rank (0-4, higher = more severe)
        """
        ranks = {
            Severity.CRITICAL: 4,
            Severity.HIGH: 3,
            Severity.MEDIUM: 2,
            Severity.LOW: 1,
            Severity.INFO: 0,
        }
        return ranks.get(severity, 0)


@dataclass
class ConsolidatedFinding:
    """
    A finding consolidated from multiple occurrences.

    Tracks all locations where the same vulnerability appears
    and maintains references to child findings.
    """

    id: str
    title: str
    severity: Severity
    occurrences: int
    locations: list[str]  # file:line for each occurrence
    children: list[SecurityFinding] = field(default_factory=list)
    attack_vectors: list[AttackVector] = field(default_factory=list)


@dataclass
class DeduplicationReport:
    """
    Complete deduplication report with metrics.

    Contains consolidated findings, attack paths, and statistics
    about the deduplication process.
    """

    original_count: int
    consolidated_count: int
    reduction_percentage: float
    consolidated_findings: list[ConsolidatedFinding] = field(default_factory=list)
    attack_paths: list[AttackPath] = field(default_factory=list)
    deduplication_stats: dict[str, int] = field(default_factory=dict)


class ReportConsolidator:
    """
    Consolidate findings into a deduplicated report.

    Uses fingerprinting and similarity matching to group findings,
    then creates a consolidated view with occurrence counts and
    attack path analysis.
    """

    def __init__(self, location_threshold: int = 5):
        """
        Initialize the report consolidator.

        Args:
            location_threshold: Line distance for proximity matching
        """
        self.fingerprint_gen = FingerprintGenerator()
        self.similarity_matcher = SimilarityMatcher(location_threshold)
        self.attack_aggregator = AttackPathAggregator()

    def consolidate(self, findings: list[SecurityFinding]) -> DeduplicationReport:
        """
        Create consolidated report from findings.

        Process:
        1. Match similar findings into groups
        2. Create consolidated findings from groups
        3. Generate attack paths
        4. Calculate statistics

        Args:
            findings: List of security findings

        Returns:
            DeduplicationReport with consolidated findings and metrics
        """
        if not findings:
            return DeduplicationReport(
                original_count=0,
                consolidated_count=0,
                reduction_percentage=0.0,
                consolidated_findings=[],
                attack_paths=[],
                deduplication_stats={},
            )

        # Group similar findings
        groups = self.similarity_matcher.match_findings(findings)

        # Create consolidated findings
        consolidated = self.get_consolidated_findings(findings, groups)

        # Generate attack paths
        attack_paths = self.attack_aggregator.aggregate(findings)

        # Calculate statistics
        original_count = len(findings)
        consolidated_count = len(consolidated)

        if original_count > 0:
            reduction_pct = round((original_count - consolidated_count) / original_count * 100, 2)
        else:
            reduction_pct = 0.0

        # Deduplication statistics
        stats = {
            "exact_matches": sum(1 for g in groups if "exact_fingerprint_match" in g.match_reasons),
            "proximity_matches": sum(1 for g in groups if "location_proximity" in g.match_reasons),
            "category_matches": sum(1 for g in groups if "related_categories" in g.match_reasons),
            "unique_findings": sum(1 for g in groups if "unique" in g.match_reasons),
            "total_groups": len(groups),
        }

        return DeduplicationReport(
            original_count=original_count,
            consolidated_count=consolidated_count,
            reduction_percentage=reduction_pct,
            consolidated_findings=consolidated,
            attack_paths=attack_paths,
            deduplication_stats=stats,
        )

    def get_consolidated_findings(
        self,
        findings: list[SecurityFinding],
        groups: list[FindingGroup] | None = None,
    ) -> list[ConsolidatedFinding]:
        """
        Return deduplicated findings with occurrence counts.

        Args:
            findings: Original findings list
            groups: Pre-computed groups (optional, will compute if None)

        Returns:
            List of consolidated findings
        """
        if groups is None:
            groups = self.similarity_matcher.match_findings(findings)

        consolidated: list[ConsolidatedFinding] = []

        for group in groups:
            primary = group.primary_finding
            all_findings = [primary] + group.related_findings

            # Collect all locations
            locations = [f"{f.file_path}:{f.line_number}" for f in all_findings]

            # Determine attack vectors for this finding
            vectors = list(
                set(
                    self.attack_aggregator._get_vector_for_category(f.category)
                    for f in all_findings
                )
            )

            # Get worst severity
            worst_severity = max(
                all_findings,
                key=lambda f: self.attack_aggregator._severity_rank(f.severity),
            ).severity

            cf = ConsolidatedFinding(
                id=primary.id,
                title=primary.title,
                severity=worst_severity,
                occurrences=len(all_findings),
                locations=locations,
                children=group.related_findings,
                attack_vectors=vectors,
            )
            consolidated.append(cf)

        # Sort by severity (worst first), then by occurrence count
        consolidated.sort(
            key=lambda c: (
                -self.attack_aggregator._severity_rank(c.severity),
                -c.occurrences,
            )
        )

        return consolidated
