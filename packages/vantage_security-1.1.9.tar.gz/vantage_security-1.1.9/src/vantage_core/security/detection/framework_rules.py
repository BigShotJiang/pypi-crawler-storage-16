"""
Framework-Specific Security Detection Rules

This module provides additional security detection rules for each supported
AI agent framework. These rules complement the generic vulnerability patterns
with framework-specific checks.
"""

import re
from collections.abc import Callable
from dataclasses import dataclass

from vantage_core.security.models import (
    OWASPCategory,
    Severity,
    VulnerabilityCategory,
)


@dataclass
class FrameworkRule:
    """A framework-specific security rule."""

    id: str
    name: str
    framework: str
    pattern: str  # Regex pattern to match
    severity: Severity
    owasp_category: OWASPCategory
    vulnerability_category: VulnerabilityCategory
    description: str
    recommendation: str
    context_check: Callable[[str, int], bool] | None = None  # Additional context validation


# LangChain-specific rules
LANGCHAIN_RULES = [
    FrameworkRule(
        id="LC-001",
        name="Unrestricted Agent Tools",
        framework="langchain",
        pattern=r"AgentExecutor\([^)]*tools\s*=\s*\[\s*\*",
        severity=Severity.HIGH,
        owasp_category=OWASPCategory.LLM08,
        vulnerability_category=VulnerabilityCategory.EXCESSIVE_AGENCY,
        description="Agent is configured with unrestricted tool access using wildcard.",
        recommendation="Explicitly list allowed tools instead of using wildcards.",
    ),
    FrameworkRule(
        id="LC-002",
        name="Shell Tool Without Restriction",
        framework="langchain",
        pattern=r"ShellTool\(\s*\)",
        severity=Severity.CRITICAL,
        owasp_category=OWASPCategory.LLM07,
        vulnerability_category=VulnerabilityCategory.CODE_EXECUTION,
        description="ShellTool allows arbitrary command execution without restrictions.",
        recommendation="Use structured command execution with allowlists or remove ShellTool.",
    ),
    FrameworkRule(
        id="LC-003",
        name="PythonREPL Without Sandboxing",
        framework="langchain",
        pattern=r"PythonREPLTool\(\s*\)|PythonREPL\(\s*\)",
        severity=Severity.CRITICAL,
        owasp_category=OWASPCategory.LLM07,
        vulnerability_category=VulnerabilityCategory.CODE_EXECUTION,
        description="PythonREPL executes arbitrary Python code without sandboxing.",
        recommendation="Use Docker-based execution or restrict to specific operations.",
    ),
    FrameworkRule(
        id="LC-004",
        name="Insecure Memory Configuration",
        framework="langchain",
        pattern=r"ConversationBufferMemory\([^)]*\)",
        severity=Severity.MEDIUM,
        owasp_category=OWASPCategory.LLM06,
        vulnerability_category=VulnerabilityCategory.DATA_LEAKAGE,
        description="Conversation memory may retain sensitive information indefinitely.",
        recommendation="Use ConversationSummaryMemory or add automatic memory cleanup.",
    ),
    FrameworkRule(
        id="LC-005",
        name="Direct SQL Query Execution",
        framework="langchain",
        pattern=r"SQLDatabaseToolkit|create_sql_agent",
        severity=Severity.HIGH,
        owasp_category=OWASPCategory.LLM07,
        vulnerability_category=VulnerabilityCategory.INSECURE_TOOL_USE,
        description="SQL agent can execute arbitrary queries against database.",
        recommendation="Use read-only database connections and query allowlists.",
    ),
    FrameworkRule(
        id="LC-006",
        name="Unfiltered Web Search Results",
        framework="langchain",
        pattern=r"SerpAPIWrapper|GoogleSearchAPIWrapper|DuckDuckGoSearchRun",
        severity=Severity.MEDIUM,
        owasp_category=OWASPCategory.LLM05,
        vulnerability_category=VulnerabilityCategory.DATA_LEAKAGE,
        description="Web search results are passed directly to LLM without filtering.",
        recommendation="Sanitize search results before passing to LLM to prevent indirect injection.",
    ),
    FrameworkRule(
        id="LC-007",
        name="File System Access Without Restriction",
        framework="langchain",
        pattern=r"FileManagementToolkit|ReadFileTool|WriteFileTool",
        severity=Severity.HIGH,
        owasp_category=OWASPCategory.LLM07,
        vulnerability_category=VulnerabilityCategory.INSECURE_TOOL_USE,
        description="File system tools allow unrestricted read/write access.",
        recommendation="Configure root_dir and implement path validation.",
    ),
]

# CrewAI-specific rules
CREWAI_RULES = [
    FrameworkRule(
        id="CA-001",
        name="Agent With Unrestricted Delegation",
        framework="crewai",
        pattern=r"Agent\([^)]*allow_delegation\s*=\s*True",
        severity=Severity.MEDIUM,
        owasp_category=OWASPCategory.LLM08,
        vulnerability_category=VulnerabilityCategory.UNSAFE_DELEGATION,
        description="Agent can delegate tasks to any other agent without restrictions.",
        recommendation="Use explicit delegation rules or disable delegation for sensitive agents.",
    ),
    FrameworkRule(
        id="CA-002",
        name="Code Execution Tool Enabled",
        framework="crewai",
        pattern=r"allow_code_execution\s*=\s*True",
        severity=Severity.CRITICAL,
        owasp_category=OWASPCategory.LLM07,
        vulnerability_category=VulnerabilityCategory.CODE_EXECUTION,
        description="Agent can execute arbitrary code.",
        recommendation="Disable code execution or use Docker-based sandboxing.",
    ),
    FrameworkRule(
        id="CA-003",
        name="Verbose Mode in Production",
        framework="crewai",
        pattern=r"Agent\([^)]*verbose\s*=\s*True",
        severity=Severity.LOW,
        owasp_category=OWASPCategory.LLM06,
        vulnerability_category=VulnerabilityCategory.DATA_LEAKAGE,
        description="Verbose mode may expose sensitive information in logs.",
        recommendation="Disable verbose mode in production environments.",
    ),
    FrameworkRule(
        id="CA-004",
        name="Undefined Task Context",
        framework="crewai",
        pattern=r"Task\([^)]*context\s*=\s*\[\]",
        severity=Severity.LOW,
        owasp_category=OWASPCategory.LLM07,
        vulnerability_category=VulnerabilityCategory.CONFIGURATION_WEAKNESS,
        description="Task has empty context which may lead to unpredictable behavior.",
        recommendation="Define explicit context for tasks or use task dependencies.",
    ),
    FrameworkRule(
        id="CA-005",
        name="Sequential Process Without Error Handling",
        framework="crewai",
        pattern=r"Crew\([^)]*process\s*=\s*Process\.sequential[^)]*\)",
        severity=Severity.MEDIUM,
        owasp_category=OWASPCategory.LLM09,
        vulnerability_category=VulnerabilityCategory.CONFIGURATION_WEAKNESS,
        description="Sequential crew process may fail silently without proper error handling.",
        recommendation="Implement task error callbacks and crew exception handlers.",
    ),
]

# AutoGen-specific rules
AUTOGEN_RULES = [
    FrameworkRule(
        id="AG-001",
        name="Code Execution Without Docker",
        framework="autogen",
        pattern=r"code_execution_config\s*=\s*\{[^}]*\"use_docker\"\s*:\s*False",
        severity=Severity.CRITICAL,
        owasp_category=OWASPCategory.LLM07,
        vulnerability_category=VulnerabilityCategory.CODE_EXECUTION,
        description="Code execution is enabled without Docker isolation.",
        recommendation="Always use use_docker=True for code execution in production.",
    ),
    FrameworkRule(
        id="AG-002",
        name="Unlimited Auto Reply Chain",
        framework="autogen",
        pattern=r"max_consecutive_auto_reply\s*=\s*(\d{3,}|None)",
        severity=Severity.MEDIUM,
        owasp_category=OWASPCategory.LLM08,
        vulnerability_category=VulnerabilityCategory.EXCESSIVE_AGENCY,
        description="Agent can auto-reply indefinitely, potentially causing loops.",
        recommendation="Set max_consecutive_auto_reply to a reasonable limit (e.g., 5-10).",
    ),
    FrameworkRule(
        id="AG-003",
        name="Human Input Mode Never",
        framework="autogen",
        pattern=r"human_input_mode\s*=\s*[\"']NEVER[\"']",
        severity=Severity.MEDIUM,
        owasp_category=OWASPCategory.LLM08,
        vulnerability_category=VulnerabilityCategory.EXCESSIVE_AGENCY,
        description="Agent operates without any human oversight.",
        recommendation="Use TERMINATE mode with proper termination conditions.",
    ),
    FrameworkRule(
        id="AG-004",
        name="Group Chat Without Speaker Control",
        framework="autogen",
        pattern=r"GroupChat\([^)]*speaker_selection_method\s*=\s*[\"']auto[\"']",
        severity=Severity.MEDIUM,
        owasp_category=OWASPCategory.LLM08,
        vulnerability_category=VulnerabilityCategory.UNSAFE_DELEGATION,
        description="Automatic speaker selection may allow unintended agent interactions.",
        recommendation="Use round_robin or custom speaker selection for controlled flows.",
    ),
    FrameworkRule(
        id="AG-005",
        name="Function Map Without Validation",
        framework="autogen",
        pattern=r"function_map\s*=\s*\{",
        severity=Severity.MEDIUM,
        owasp_category=OWASPCategory.LLM07,
        vulnerability_category=VulnerabilityCategory.INSECURE_TOOL_USE,
        description="Registered functions may not have input validation.",
        recommendation="Validate all function inputs before execution.",
    ),
]

# LlamaIndex-specific rules
LLAMAINDEX_RULES = [
    FrameworkRule(
        id="LI-001",
        name="Unfiltered Document Loading",
        framework="llamaindex",
        pattern=r"SimpleDirectoryReader\([^)]*\)",
        severity=Severity.MEDIUM,
        owasp_category=OWASPCategory.LLM05,
        vulnerability_category=VulnerabilityCategory.DATA_LEAKAGE,
        description="Directory reader loads all documents without filtering.",
        recommendation="Use file_extractor with content filtering and validation.",
    ),
    FrameworkRule(
        id="LI-002",
        name="Default Query Engine Trust",
        framework="llamaindex",
        pattern=r"\.as_query_engine\(\s*\)",
        severity=Severity.LOW,
        owasp_category=OWASPCategory.LLM07,
        vulnerability_category=VulnerabilityCategory.CONFIGURATION_WEAKNESS,
        description="Query engine uses default settings without security configuration.",
        recommendation="Configure response_mode and add node postprocessors for filtering.",
    ),
    FrameworkRule(
        id="LI-003",
        name="SQL Query Tool",
        framework="llamaindex",
        pattern=r"NLSQLTableQueryEngine|SQLTableRetrieverQueryEngine",
        severity=Severity.HIGH,
        owasp_category=OWASPCategory.LLM07,
        vulnerability_category=VulnerabilityCategory.INSECURE_TOOL_USE,
        description="SQL query engine allows natural language to SQL translation.",
        recommendation="Use read-only connections and implement query validation.",
    ),
    FrameworkRule(
        id="LI-004",
        name="Code Interpreter Tool",
        framework="llamaindex",
        pattern=r"CodeInterpreterToolSpec",
        severity=Severity.CRITICAL,
        owasp_category=OWASPCategory.LLM07,
        vulnerability_category=VulnerabilityCategory.CODE_EXECUTION,
        description="Code interpreter allows arbitrary code execution.",
        recommendation="Use sandboxed execution environment or restrict to safe operations.",
    ),
]

# Semantic Kernel-specific rules
SEMANTIC_KERNEL_RULES = [
    FrameworkRule(
        id="SK-001",
        name="Plugin Without Permission Control",
        framework="semantic_kernel",
        pattern=r"kernel\.add_plugin\([^)]*\)",
        severity=Severity.MEDIUM,
        owasp_category=OWASPCategory.LLM08,
        vulnerability_category=VulnerabilityCategory.EXCESSIVE_AGENCY,
        description="Plugin is added without explicit permission configuration.",
        recommendation="Use function invocation filters to control plugin access.",
    ),
    FrameworkRule(
        id="SK-002",
        name="Native Function Without Validation",
        framework="semantic_kernel",
        pattern=r"@kernel_function\s*\([^)]*\)",
        severity=Severity.LOW,
        owasp_category=OWASPCategory.LLM07,
        vulnerability_category=VulnerabilityCategory.INSECURE_TOOL_USE,
        description="Native function may not have input validation.",
        recommendation="Add input validation decorators or Pydantic models.",
    ),
    FrameworkRule(
        id="SK-003",
        name="OpenAI Function Calling Without Restrictions",
        framework="semantic_kernel",
        pattern=r"ToolCallBehavior\.AutoInvoke",
        severity=Severity.MEDIUM,
        owasp_category=OWASPCategory.LLM08,
        vulnerability_category=VulnerabilityCategory.EXCESSIVE_AGENCY,
        description="Auto-invoke allows LLM to call any available function.",
        recommendation="Use EnableFunctions with explicit function allowlist.",
    ),
]

# Combine all rules
ALL_FRAMEWORK_RULES = (
    LANGCHAIN_RULES + CREWAI_RULES + AUTOGEN_RULES + LLAMAINDEX_RULES + SEMANTIC_KERNEL_RULES
)

RULES_BY_FRAMEWORK = {
    "langchain": LANGCHAIN_RULES,
    "crewai": CREWAI_RULES,
    "autogen": AUTOGEN_RULES,
    "llamaindex": LLAMAINDEX_RULES,
    "semantic_kernel": SEMANTIC_KERNEL_RULES,
}


def get_rules_for_framework(framework: str) -> list[FrameworkRule]:
    """Get security rules for a specific framework."""
    return RULES_BY_FRAMEWORK.get(framework.lower(), [])


def get_all_rules() -> list[FrameworkRule]:
    """Get all framework-specific security rules."""
    return ALL_FRAMEWORK_RULES


def check_code_against_rules(
    code: str, framework: str | None = None
) -> list[tuple[FrameworkRule, int, str]]:
    """
    Check code against framework rules.

    Args:
        code: Source code to check
        framework: Optional framework to filter rules (checks all if None)

    Returns:
        List of (rule, line_number, matched_text) tuples
    """
    matches = []
    rules = get_rules_for_framework(framework) if framework else get_all_rules()

    lines = code.split("\n")
    for i, line in enumerate(lines, 1):
        for rule in rules:
            match = re.search(rule.pattern, line)
            if match:
                # Run additional context check if provided
                if rule.context_check and not rule.context_check(code, i):
                    continue
                matches.append((rule, i, match.group(0)))

    return matches
