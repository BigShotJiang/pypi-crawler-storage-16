"""
Exception Hierarchy for Vantage Security Scanner.

US-005: Specific Exception Types

Provides typed exceptions for different error conditions,
enabling programmatic error handling and clear diagnostics.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class ErrorCode(str, Enum):
    """
    Standardized error codes for categorization.

    Error codes follow pattern: VANTAGE-XXX
    - 1XX: Parse errors
    - 2XX: Analysis errors
    - 3XX: Configuration errors
    - 4XX: Rule errors
    - 5XX: IO errors
    """

    # Parse errors (1xx)
    PARSE_SYNTAX_ERROR = "VANTAGE-101"
    PARSE_ENCODING_ERROR = "VANTAGE-102"
    PARSE_TIMEOUT = "VANTAGE-103"
    PARSE_FILE_TOO_LARGE = "VANTAGE-104"

    # Analysis errors (2xx)
    ANALYSIS_RULE_FAILED = "VANTAGE-201"
    ANALYSIS_TIMEOUT = "VANTAGE-202"
    ANALYSIS_MEMORY_EXCEEDED = "VANTAGE-203"
    ANALYSIS_TAINT_DIVERGENCE = "VANTAGE-204"
    ANALYSIS_INTERNAL_ERROR = "VANTAGE-205"

    # Configuration errors (3xx)
    CONFIG_INVALID_SCHEMA = "VANTAGE-301"
    CONFIG_MISSING_REQUIRED = "VANTAGE-302"
    CONFIG_INVALID_PATH = "VANTAGE-303"
    CONFIG_TYPE_ERROR = "VANTAGE-304"
    CONFIG_VALIDATION_FAILED = "VANTAGE-305"

    # Rule errors (4xx)
    RULE_INVALID_SYNTAX = "VANTAGE-401"
    RULE_INVALID_PATTERN = "VANTAGE-402"
    RULE_DUPLICATE_ID = "VANTAGE-403"
    RULE_CIRCULAR_DEPENDENCY = "VANTAGE-404"
    RULE_LOAD_FAILED = "VANTAGE-405"

    # IO errors (5xx)
    IO_FILE_NOT_FOUND = "VANTAGE-501"
    IO_PERMISSION_DENIED = "VANTAGE-502"
    IO_DISK_FULL = "VANTAGE-503"
    IO_READ_ERROR = "VANTAGE-504"


@dataclass
class ErrorContext:
    """
    Rich context for error diagnosis.

    Provides detailed information about where and why an error occurred.
    """

    file_path: str | None = None
    line_number: int | None = None
    column_number: int | None = None
    source_snippet: str | None = None
    rule_id: str | None = None
    additional: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert context to dictionary for serialization."""
        result = {
            "file_path": self.file_path,
            "line_number": self.line_number,
            "column_number": self.column_number,
            "source_snippet": self.source_snippet,
            "rule_id": self.rule_id,
        }
        result.update(self.additional)
        return {k: v for k, v in result.items() if v is not None}


class MimicError(Exception):
    """
    Base exception for all Vantage errors.

    Provides structured error information for logging,
    SARIF reporting, and programmatic handling.

    All scanner exceptions should inherit from this class.
    """

    def __init__(
        self,
        message: str,
        error_code: ErrorCode,
        context: ErrorContext | None = None,
        cause: Exception | None = None,
        recoverable: bool = True,
    ):
        """
        Initialize Vantage error.

        Args:
            message: Human-readable error message
            error_code: Standardized error code for categorization
            context: Rich error context with file/line information
            cause: Original exception that caused this error
            recoverable: Whether the scan can continue after this error
        """
        super().__init__(message)
        self.error_code = error_code
        self.context = context or ErrorContext()
        self.cause = cause
        self.recoverable = recoverable
        self.timestamp = datetime.utcnow().isoformat()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        result = {
            "error_code": self.error_code.value,
            "message": str(self),
            "recoverable": self.recoverable,
            "timestamp": self.timestamp,
            "context": self.context.to_dict(),
        }

        if self.cause:
            result["cause"] = {
                "type": type(self.cause).__name__,
                "message": str(self.cause),
            }

        return result

    def to_sarif_notification(self) -> dict[str, Any]:
        """
        Convert to SARIF toolExecutionNotification format.

        Used for reporting errors in SARIF output as per
        SARIF 2.1.0 specification.
        """
        notification = {
            "message": {"text": str(self)},
            "level": "error" if not self.recoverable else "warning",
            "descriptor": {"id": self.error_code.value},
        }

        if self.context.file_path:
            location = {
                "physicalLocation": {
                    "artifactLocation": {"uri": self.context.file_path},
                    "region": {
                        "startLine": self.context.line_number or 1,
                        "startColumn": self.context.column_number or 1,
                    },
                }
            }
            notification["locations"] = [location]

        if self.cause:
            notification["exception"] = {
                "kind": type(self.cause).__name__,
                "message": str(self.cause),
            }

        return notification

    def __str__(self) -> str:
        """Return formatted error message."""
        base_msg = super().__str__()
        if self.context.file_path:
            location = self.context.file_path
            if self.context.line_number:
                location += f":{self.context.line_number}"
                if self.context.column_number:
                    location += f":{self.context.column_number}"
            return f"{base_msg} at {location}"
        return base_msg


# Parse Errors
class ParseError(MimicError):
    """Base class for parsing-related errors."""

    pass


class SyntaxParseError(ParseError):
    """
    Syntax error in source file.

    Raised when the AST parser encounters invalid Python syntax.
    """

    def __init__(
        self,
        file_path: str,
        line: int,
        column: int,
        message: str,
        cause: Exception | None = None,
    ):
        """
        Initialize syntax parse error.

        Args:
            file_path: Path to the file with syntax error
            line: Line number where error occurred
            column: Column number where error occurred
            message: Description of the syntax error
            cause: Original SyntaxError exception
        """
        context = ErrorContext(
            file_path=file_path,
            line_number=line,
            column_number=column,
        )
        super().__init__(
            f"Syntax error: {message}",
            ErrorCode.PARSE_SYNTAX_ERROR,
            context,
            cause=cause,
            recoverable=True,
        )


class EncodingError(ParseError):
    """
    File encoding issue.

    Raised when a file cannot be decoded with the expected encoding.
    """

    def __init__(
        self,
        file_path: str,
        encoding: str = "utf-8",
        cause: Exception | None = None,
    ):
        """
        Initialize encoding error.

        Args:
            file_path: Path to the file with encoding issue
            encoding: The encoding that was attempted
            cause: Original UnicodeDecodeError
        """
        context = ErrorContext(
            file_path=file_path,
            additional={"encoding": encoding},
        )
        super().__init__(
            f"Cannot decode file with {encoding} encoding",
            ErrorCode.PARSE_ENCODING_ERROR,
            context,
            cause=cause,
            recoverable=True,
        )


class ParseTimeoutError(ParseError):
    """
    Parsing exceeded time limit.

    Raised when parsing a file takes too long.
    """

    def __init__(self, file_path: str, timeout_seconds: int):
        """
        Initialize parse timeout error.

        Args:
            file_path: Path to the file that timed out
            timeout_seconds: The timeout limit that was exceeded
        """
        context = ErrorContext(
            file_path=file_path,
            additional={"timeout_seconds": timeout_seconds},
        )
        super().__init__(
            f"Parsing timed out after {timeout_seconds}s",
            ErrorCode.PARSE_TIMEOUT,
            context,
            recoverable=True,
        )


class FileTooLargeError(ParseError):
    """
    File exceeds size limit.

    Raised when a file is too large to parse safely.
    """

    def __init__(self, file_path: str, size_kb: int, max_size_kb: int):
        """
        Initialize file too large error.

        Args:
            file_path: Path to the oversized file
            size_kb: Actual file size in KB
            max_size_kb: Maximum allowed size in KB
        """
        context = ErrorContext(
            file_path=file_path,
            additional={"size_kb": size_kb, "max_size_kb": max_size_kb},
        )
        super().__init__(
            f"File size {size_kb}KB exceeds limit of {max_size_kb}KB",
            ErrorCode.PARSE_FILE_TOO_LARGE,
            context,
            recoverable=True,
        )


# Analysis Errors
class AnalysisError(MimicError):
    """Base class for analysis-related errors."""

    pass


class RuleExecutionError(AnalysisError):
    """
    Rule failed during execution.

    Raised when a security rule encounters an error while analyzing code.
    """

    def __init__(self, rule_id: str, file_path: str, cause: Exception):
        """
        Initialize rule execution error.

        Args:
            rule_id: ID of the rule that failed
            file_path: Path to the file being analyzed
            cause: Original exception from rule execution
        """
        context = ErrorContext(
            file_path=file_path,
            rule_id=rule_id,
        )
        super().__init__(
            f"Rule '{rule_id}' failed: {cause}",
            ErrorCode.ANALYSIS_RULE_FAILED,
            context,
            cause=cause,
            recoverable=True,
        )


class AnalysisTimeoutError(AnalysisError):
    """
    Analysis exceeded time limit.

    Raised when analysis of a file takes too long.
    """

    def __init__(self, file_path: str, timeout_seconds: int):
        """
        Initialize analysis timeout error.

        Args:
            file_path: Path to the file that timed out
            timeout_seconds: The timeout limit that was exceeded
        """
        context = ErrorContext(
            file_path=file_path,
            additional={"timeout_seconds": timeout_seconds},
        )
        super().__init__(
            f"Analysis timed out after {timeout_seconds}s",
            ErrorCode.ANALYSIS_TIMEOUT,
            context,
            recoverable=True,
        )


class MemoryExceededError(AnalysisError):
    """
    Analysis exceeded memory limit.

    Raised when analysis uses too much memory.
    """

    def __init__(self, file_path: str, memory_mb: int, max_memory_mb: int):
        """
        Initialize memory exceeded error.

        Args:
            file_path: Path to the file being analyzed
            memory_mb: Memory used in MB
            max_memory_mb: Maximum allowed memory in MB
        """
        context = ErrorContext(
            file_path=file_path,
            additional={"memory_mb": memory_mb, "max_memory_mb": max_memory_mb},
        )
        super().__init__(
            f"Memory usage {memory_mb}MB exceeds limit of {max_memory_mb}MB",
            ErrorCode.ANALYSIS_MEMORY_EXCEEDED,
            context,
            recoverable=True,
        )


class InternalAnalysisError(AnalysisError):
    """
    Unexpected internal error during analysis.

    Raised for unexpected errors that should be reported for debugging.
    """

    def __init__(self, message: str, file_path: str | None = None, cause: Exception | None = None):
        """
        Initialize internal analysis error.

        Args:
            message: Description of the internal error
            file_path: Optional path to the file being analyzed
            cause: Original exception
        """
        context = ErrorContext(file_path=file_path)
        super().__init__(
            f"Internal error: {message}",
            ErrorCode.ANALYSIS_INTERNAL_ERROR,
            context,
            cause=cause,
            recoverable=True,
        )


# Configuration Errors
class ConfigurationError(MimicError):
    """
    Invalid configuration.

    Raised when scanner configuration is invalid or missing required values.
    """

    def __init__(
        self,
        message: str,
        error_code: ErrorCode = ErrorCode.CONFIG_INVALID_SCHEMA,
        context: ErrorContext | None = None,
    ):
        """
        Initialize configuration error.

        Args:
            message: Description of the configuration error
            error_code: Specific configuration error code
            context: Optional error context
        """
        super().__init__(
            message,
            error_code,
            context,
            recoverable=False,
        )


class MissingConfigError(ConfigurationError):
    """
    Required configuration value is missing.

    Raised when a required configuration field is not provided.
    """

    def __init__(self, field_name: str, config_file: str | None = None):
        """
        Initialize missing config error.

        Args:
            field_name: Name of the missing configuration field
            config_file: Optional path to the configuration file
        """
        context = ErrorContext(
            file_path=config_file,
            additional={"field_name": field_name},
        )
        super().__init__(
            f"Missing required configuration: {field_name}",
            ErrorCode.CONFIG_MISSING_REQUIRED,
            context,
        )


class InvalidPathError(ConfigurationError):
    """
    Configuration path does not exist.

    Raised when a configured path is invalid or doesn't exist.
    """

    def __init__(self, path: str, path_type: str = "path"):
        """
        Initialize invalid path error.

        Args:
            path: The invalid path
            path_type: Type of path (e.g., "rules directory", "output file")
        """
        context = ErrorContext(
            file_path=path,
            additional={"path_type": path_type},
        )
        super().__init__(
            f"Invalid {path_type}: {path}",
            ErrorCode.CONFIG_INVALID_PATH,
            context,
        )


# Rule Errors
class RuleValidationError(MimicError):
    """
    Rule file is invalid.

    Raised when a custom rule file fails validation.
    """

    def __init__(self, rule_file: str, errors: list[str]):
        """
        Initialize rule validation error.

        Args:
            rule_file: Path to the invalid rule file
            errors: List of validation error messages
        """
        context = ErrorContext(
            file_path=rule_file,
            additional={"validation_errors": errors},
        )
        super().__init__(
            f"Invalid rule file: {'; '.join(errors)}",
            ErrorCode.RULE_INVALID_SYNTAX,
            context,
            recoverable=False,
        )
        self.validation_errors = errors


class DuplicateRuleIdError(MimicError):
    """
    Duplicate rule ID detected.

    Raised when multiple rules have the same ID.
    """

    def __init__(self, rule_id: str, files: list[str]):
        """
        Initialize duplicate rule ID error.

        Args:
            rule_id: The duplicate rule ID
            files: List of files containing the duplicate
        """
        context = ErrorContext(
            rule_id=rule_id,
            additional={"files": files},
        )
        super().__init__(
            f"Duplicate rule ID '{rule_id}' found in: {', '.join(files)}",
            ErrorCode.RULE_DUPLICATE_ID,
            context,
            recoverable=False,
        )


class RuleLoadError(MimicError):
    """
    Failed to load rule file.

    Raised when a rule file cannot be read or parsed.
    """

    def __init__(self, rule_file: str, cause: Exception):
        """
        Initialize rule load error.

        Args:
            rule_file: Path to the rule file
            cause: Original exception from loading
        """
        context = ErrorContext(file_path=rule_file)
        super().__init__(
            f"Failed to load rule file: {cause}",
            ErrorCode.RULE_LOAD_FAILED,
            context,
            cause=cause,
            recoverable=True,
        )


# IO Errors
class FileNotFoundError(MimicError):
    """
    File not found.

    Raised when a file does not exist.
    """

    def __init__(self, file_path: str):
        """
        Initialize file not found error.

        Args:
            file_path: Path to the missing file
        """
        context = ErrorContext(file_path=file_path)
        super().__init__(
            f"File not found: {file_path}",
            ErrorCode.IO_FILE_NOT_FOUND,
            context,
            recoverable=True,
        )


class PermissionDeniedError(MimicError):
    """
    Permission denied for file access.

    Raised when the scanner lacks permissions to access a file.
    """

    def __init__(self, file_path: str, operation: str = "read"):
        """
        Initialize permission denied error.

        Args:
            file_path: Path to the inaccessible file
            operation: The operation that was denied (read, write)
        """
        context = ErrorContext(
            file_path=file_path,
            additional={"operation": operation},
        )
        super().__init__(
            f"Permission denied for {operation} on {file_path}",
            ErrorCode.IO_PERMISSION_DENIED,
            context,
            recoverable=True,
        )


class FileReadError(MimicError):
    """
    Error reading file.

    Raised for general file read errors.
    """

    def __init__(self, file_path: str, cause: Exception):
        """
        Initialize file read error.

        Args:
            file_path: Path to the file
            cause: Original exception
        """
        context = ErrorContext(file_path=file_path)
        super().__init__(
            f"Error reading file: {cause}",
            ErrorCode.IO_READ_ERROR,
            context,
            cause=cause,
            recoverable=True,
        )
