"""
Configuration Extractor for Vantage Security Platform.

US-110: Configuration Extractor Implementation
Extracts and normalizes configuration from various sources including
YAML, JSON, TOML, .env, and Python configuration files.

Features:
- Multi-format parsing (YAML, JSON, TOML, .env, Python config)
- Environment variable detection (names only, not values)
- Secret detection with entropy analysis
- Framework-specific security settings extraction
- Normalized output schema
"""

import ast
import json
import logging
import math
import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class ConfigFormat(str, Enum):
    """Supported configuration file formats."""

    YAML = "yaml"
    JSON = "json"
    TOML = "toml"
    ENV = "env"
    PYTHON = "python"
    UNKNOWN = "unknown"


class SecretType(str, Enum):
    """Types of detected secrets."""

    API_KEY = "api_key"
    PASSWORD = "password"
    TOKEN = "token"
    SECRET_KEY = "secret_key"
    CONNECTION_STRING = "connection_string"
    PRIVATE_KEY = "private_key"
    AWS_KEY = "aws_key"
    GENERIC_SECRET = "generic_secret"


@dataclass
class SecretFinding:
    """Represents a detected potential secret in configuration."""

    key_path: str  # Full path to the key (e.g., "database.password")
    secret_type: SecretType
    confidence: float  # 0-1 confidence score
    detection_method: str  # "pattern", "entropy", "both"
    entropy: float | None = None
    file_path: str | None = None
    line_number: int | None = None
    recommendation: str = ""

    @property
    def severity(self) -> str:
        """Get severity based on confidence."""
        if self.confidence >= 0.9:
            return "critical"
        elif self.confidence >= 0.7:
            return "high"
        elif self.confidence >= 0.5:
            return "medium"
        return "low"


@dataclass
class EnvironmentVariable:
    """Represents an environment variable reference in configuration."""

    name: str  # Variable name (e.g., "DATABASE_URL")
    key_path: str  # Configuration key path where it's referenced
    file_path: str | None = None
    line_number: int | None = None
    default_value: str | None = None  # Default value if specified
    is_required: bool = True


@dataclass
class SecuritySettings:
    """Security-relevant settings extracted from framework configurations."""

    framework: str
    settings: dict[str, Any]
    warnings: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)


@dataclass
class ConfigFile:
    """Represents a parsed configuration file."""

    path: str
    format: ConfigFormat
    content: dict[str, Any]
    raw_content: str
    env_vars: list[EnvironmentVariable] = field(default_factory=list)
    secrets: list[SecretFinding] = field(default_factory=list)


@dataclass
class ConfigAnalysis:
    """Complete configuration analysis result."""

    config_files: list[ConfigFile]
    all_secrets: list[SecretFinding]
    all_env_vars: list[EnvironmentVariable]
    security_settings: list[SecuritySettings]
    summary: dict[str, Any] = field(default_factory=dict)


class ConfigExtractor:
    """
    Extract and analyze configuration from various file formats.

    Supports YAML, JSON, TOML, .env, and Python configuration files.
    Detects potential secrets and environment variable references.
    """

    # Patterns for detecting secret keys
    SECRET_KEY_PATTERNS = [
        (r"(?i)(api[_-]?key|apikey)", SecretType.API_KEY),
        (r"(?i)(password|passwd|pwd)", SecretType.PASSWORD),
        (r"(?i)(token|auth[_-]?token|access[_-]?token|bearer)", SecretType.TOKEN),
        (r"(?i)(secret[_-]?key|secret)", SecretType.SECRET_KEY),
        (
            r"(?i)(connection[_-]?string|conn[_-]?str|database[_-]?url|db[_-]?url)",
            SecretType.CONNECTION_STRING,
        ),
        (r"(?i)(private[_-]?key|priv[_-]?key|rsa[_-]?key)", SecretType.PRIVATE_KEY),
        (r"(?i)(aws[_-]?(access[_-]?key|secret|key))", SecretType.AWS_KEY),
    ]

    # Patterns for detecting environment variable references
    ENV_VAR_PATTERNS = [
        r"\$\{([A-Z_][A-Z0-9_]*)\}",  # ${VAR_NAME}
        r"\$([A-Z_][A-Z0-9_]*)",  # $VAR_NAME
        r"os\.environ\.get\(['\"]([A-Z_][A-Z0-9_]*)['\"]",  # os.environ.get("VAR")
        r"os\.getenv\(['\"]([A-Z_][A-Z0-9_]*)['\"]",  # os.getenv("VAR")
        r"env\(['\"]([A-Z_][A-Z0-9_]*)['\"]",  # env("VAR")
    ]

    # High entropy threshold for secret detection
    ENTROPY_THRESHOLD = 4.5
    MIN_SECRET_LENGTH = 8

    # Framework-specific security settings to extract
    FRAMEWORK_SETTINGS = {
        "langchain": [
            "verbose",
            "callbacks",
            "memory",
            "agent_executor_kwargs",
            "handle_parsing_errors",
            "max_iterations",
            "return_intermediate_steps",
        ],
        "crewai": [
            "verbose",
            "memory",
            "max_rpm",
            "function_calling_llm",
            "allow_delegation",
            "step_callback",
        ],
        "autogen": [
            "human_input_mode",
            "max_consecutive_auto_reply",
            "code_execution_config",
            "function_map",
            "llm_config",
        ],
        "openai": [
            "api_key",
            "organization",
            "timeout",
            "max_retries",
            "temperature",
            "max_tokens",
        ],
        "anthropic": ["api_key", "timeout", "max_retries", "default_headers"],
    }

    def __init__(self):
        """Initialize the configuration extractor."""
        self._yaml_available = False
        self._toml_available = False
        self._check_dependencies()

    def _check_dependencies(self):
        """Check for optional dependencies."""
        try:
            import yaml

            self._yaml_available = True
            self._yaml = yaml
        except ImportError:
            logger.warning("PyYAML not available, YAML parsing disabled")
            self._yaml = None

        try:
            import tomllib

            self._toml_available = True
            self._tomllib = tomllib
        except ImportError:
            try:
                import tomli as tomllib

                self._toml_available = True
                self._tomllib = tomllib
            except ImportError:
                logger.warning("tomllib/tomli not available, TOML parsing disabled")
                self._tomllib = None

    def extract(self, project_path: Path) -> ConfigAnalysis:
        """
        Extract and analyze all configuration files in a project.

        Args:
            project_path: Path to the project directory

        Returns:
            ConfigAnalysis with all extracted configuration data
        """
        project_path = Path(project_path)
        config_files: list[ConfigFile] = []

        # Find and parse all config files
        config_patterns = [
            "*.yaml",
            "*.yml",
            "*.json",
            "*.toml",
            "*.env",
            "config.py",
            "settings.py",
            "conf.py",
            "configuration.py",
            "**/config/*.py",
            "**/settings/*.py",
            "pyproject.toml",
            "setup.cfg",
        ]

        found_files: set[Path] = set()
        for pattern in config_patterns:
            for file_path in project_path.glob(pattern):
                if file_path.is_file() and file_path not in found_files:
                    found_files.add(file_path)
                    config_file = self._parse_config_file(file_path)
                    if config_file:
                        config_files.append(config_file)

        # Also check for .env files at root
        for env_file in [".env", ".env.local", ".env.development", ".env.production"]:
            env_path = project_path / env_file
            if env_path.exists() and env_path not in found_files:
                config_file = self._parse_config_file(env_path)
                if config_file:
                    config_files.append(config_file)

        # Aggregate results
        all_secrets: list[SecretFinding] = []
        all_env_vars: list[EnvironmentVariable] = []

        for cf in config_files:
            all_secrets.extend(cf.secrets)
            all_env_vars.extend(cf.env_vars)

        # Extract security settings
        security_settings = self._extract_all_security_settings(config_files)

        # Generate summary
        summary = {
            "total_files": len(config_files),
            "total_secrets": len(all_secrets),
            "total_env_vars": len(all_env_vars),
            "files_by_format": {},
            "secrets_by_severity": {"critical": 0, "high": 0, "medium": 0, "low": 0},
        }

        for cf in config_files:
            fmt = cf.format.value
            summary["files_by_format"][fmt] = summary["files_by_format"].get(fmt, 0) + 1

        for secret in all_secrets:
            summary["secrets_by_severity"][secret.severity] += 1

        return ConfigAnalysis(
            config_files=config_files,
            all_secrets=all_secrets,
            all_env_vars=all_env_vars,
            security_settings=security_settings,
            summary=summary,
        )

    def _parse_config_file(self, file_path: Path) -> ConfigFile | None:
        """Parse a single configuration file."""
        try:
            raw_content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            logger.error(f"Failed to read {file_path}: {e}")
            return None

        file_format = self._detect_format(file_path)
        content: dict[str, Any] = {}

        try:
            if file_format == ConfigFormat.YAML:
                content = self._parse_yaml(raw_content)
            elif file_format == ConfigFormat.JSON:
                content = self._parse_json(raw_content)
            elif file_format == ConfigFormat.TOML:
                content = self._parse_toml(raw_content)
            elif file_format == ConfigFormat.ENV:
                content = self._parse_env(raw_content)
            elif file_format == ConfigFormat.PYTHON:
                content = self._parse_python(raw_content)
            else:
                return None
        except Exception as e:
            logger.error(f"Failed to parse {file_path}: {e}")
            return None

        # Detect secrets and env vars
        secrets = self.detect_secrets(raw_content, str(file_path))
        env_vars = self._detect_env_vars(raw_content, str(file_path))

        # Also scan the parsed content for secrets
        content_secrets = self._scan_dict_for_secrets(content, str(file_path))
        secrets.extend(content_secrets)

        # Deduplicate secrets by key_path
        seen_paths: set[str] = set()
        unique_secrets: list[SecretFinding] = []
        for secret in secrets:
            if secret.key_path not in seen_paths:
                seen_paths.add(secret.key_path)
                unique_secrets.append(secret)

        return ConfigFile(
            path=str(file_path),
            format=file_format,
            content=content,
            raw_content=raw_content,
            env_vars=env_vars,
            secrets=unique_secrets,
        )

    def _detect_format(self, file_path: Path) -> ConfigFormat:
        """Detect the configuration file format."""
        suffix = file_path.suffix.lower()
        name = file_path.name.lower()

        if suffix in [".yaml", ".yml"]:
            return ConfigFormat.YAML
        elif suffix == ".json":
            return ConfigFormat.JSON
        elif suffix == ".toml":
            return ConfigFormat.TOML
        elif suffix == ".py":
            return ConfigFormat.PYTHON
        elif name.startswith(".env") or suffix == ".env":
            return ConfigFormat.ENV

        return ConfigFormat.UNKNOWN

    def _parse_yaml(self, content: str) -> dict[str, Any]:
        """Parse YAML content."""
        if not self._yaml_available:
            raise RuntimeError("YAML parsing not available")
        return self._yaml.safe_load(content) or {}

    def _parse_json(self, content: str) -> dict[str, Any]:
        """Parse JSON content."""
        return json.loads(content)

    def _parse_toml(self, content: str) -> dict[str, Any]:
        """Parse TOML content."""
        if not self._toml_available:
            raise RuntimeError("TOML parsing not available")
        return self._tomllib.loads(content)

    def _parse_env(self, content: str) -> dict[str, Any]:
        """Parse .env file content."""
        result: dict[str, Any] = {}
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip().strip("\"'")
                result[key] = value
        return result

    def _parse_python(self, content: str) -> dict[str, Any]:
        """Parse Python configuration file using AST."""
        result: dict[str, Any] = {}

        try:
            tree = ast.parse(content)
        except SyntaxError as e:
            logger.error(f"Python syntax error: {e}")
            return result

        for node in ast.walk(tree):
            # Extract simple assignments
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        value = self._ast_to_value(node.value)
                        if value is not None:
                            result[target.id] = value

            # Extract annotated assignments
            elif isinstance(node, ast.AnnAssign):
                if isinstance(node.target, ast.Name) and node.value:
                    value = self._ast_to_value(node.value)
                    if value is not None:
                        result[node.target.id] = value

        return result

    def _ast_to_value(self, node: ast.expr) -> Any:
        """Convert AST node to Python value."""
        if isinstance(node, ast.Constant):
            return node.value
        elif isinstance(node, ast.Str):  # Python 3.7 compatibility
            return node.s
        elif isinstance(node, ast.Num):  # Python 3.7 compatibility
            return node.n
        elif isinstance(node, ast.List):
            return [self._ast_to_value(elt) for elt in node.elts]
        elif isinstance(node, ast.Tuple):
            return tuple(self._ast_to_value(elt) for elt in node.elts)
        elif isinstance(node, ast.Dict):
            keys = []
            values = []
            for k in node.keys:
                if k is not None:
                    keys.append(self._ast_to_value(k))
                else:
                    keys.append(None)
            for v in node.values:
                values.append(self._ast_to_value(v))
            return dict(zip(keys, values))
        elif isinstance(node, ast.NameConstant):  # Python 3.7 compatibility
            return node.value
        elif isinstance(node, ast.Name):
            # Return the name as a string placeholder
            return f"<{node.id}>"

        return None

    def detect_secrets(self, content: str, filename: str) -> list[SecretFinding]:
        """
        Detect potential secrets using patterns and entropy analysis.

        Args:
            content: File content to analyze
            filename: Name of the file for reporting

        Returns:
            List of SecretFinding objects
        """
        secrets: list[SecretFinding] = []
        lines = content.splitlines()

        for line_num, line in enumerate(lines, 1):
            # Skip comments
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith("//"):
                continue

            # Look for key=value patterns
            matches = re.findall(
                r'(["\']?)([a-zA-Z_][a-zA-Z0-9_]*)\1\s*[:=]\s*["\']?([^"\'#\n]+)', line
            )

            for _, key, value in matches:
                value = value.strip().rstrip(",")
                if not value or len(value) < self.MIN_SECRET_LENGTH:
                    continue

                # Check if key matches secret patterns
                secret_type = self._match_secret_pattern(key)
                pattern_match = secret_type is not None

                # Calculate entropy
                entropy = self.calculate_entropy(value)
                high_entropy = entropy >= self.ENTROPY_THRESHOLD

                if pattern_match or high_entropy:
                    confidence = 0.0
                    detection_method = ""

                    if pattern_match and high_entropy:
                        confidence = 0.95
                        detection_method = "both"
                    elif pattern_match:
                        confidence = 0.7
                        detection_method = "pattern"
                    elif high_entropy:
                        confidence = 0.5
                        detection_method = "entropy"
                        secret_type = SecretType.GENERIC_SECRET

                    if confidence > 0:
                        secret = SecretFinding(
                            key_path=key,
                            secret_type=secret_type or SecretType.GENERIC_SECRET,
                            confidence=confidence,
                            detection_method=detection_method,
                            entropy=entropy,
                            file_path=filename,
                            line_number=line_num,
                            recommendation=self._get_secret_recommendation(
                                secret_type or SecretType.GENERIC_SECRET
                            ),
                        )
                        secrets.append(secret)

        return secrets

    def _match_secret_pattern(self, key: str) -> SecretType | None:
        """Match a key against secret patterns."""
        for pattern, secret_type in self.SECRET_KEY_PATTERNS:
            if re.search(pattern, key):
                return secret_type
        return None

    def calculate_entropy(self, value: str) -> float:
        """
        Calculate Shannon entropy of a string.

        Higher entropy suggests more randomness (potential secret).

        Args:
            value: String to analyze

        Returns:
            Shannon entropy value
        """
        if not value:
            return 0.0

        # Count character frequencies
        freq: dict[str, int] = {}
        for char in value:
            freq[char] = freq.get(char, 0) + 1

        # Calculate entropy
        length = len(value)
        entropy = 0.0
        for count in freq.values():
            prob = count / length
            entropy -= prob * math.log2(prob)

        return entropy

    def _scan_dict_for_secrets(
        self, data: dict[str, Any], filename: str, prefix: str = ""
    ) -> list[SecretFinding]:
        """Recursively scan a dictionary for secrets."""
        secrets: list[SecretFinding] = []

        for key, value in data.items():
            key_path = f"{prefix}.{key}" if prefix else key

            if isinstance(value, dict):
                secrets.extend(self._scan_dict_for_secrets(value, filename, key_path))
            elif isinstance(value, str) and len(value) >= self.MIN_SECRET_LENGTH:
                secret_type = self._match_secret_pattern(key)
                entropy = self.calculate_entropy(value)

                pattern_match = secret_type is not None
                high_entropy = entropy >= self.ENTROPY_THRESHOLD

                if pattern_match or high_entropy:
                    confidence = 0.0
                    detection_method = ""

                    if pattern_match and high_entropy:
                        confidence = 0.95
                        detection_method = "both"
                    elif pattern_match:
                        confidence = 0.7
                        detection_method = "pattern"
                    elif high_entropy:
                        confidence = 0.5
                        detection_method = "entropy"
                        secret_type = SecretType.GENERIC_SECRET

                    if confidence > 0:
                        secret = SecretFinding(
                            key_path=key_path,
                            secret_type=secret_type or SecretType.GENERIC_SECRET,
                            confidence=confidence,
                            detection_method=detection_method,
                            entropy=entropy,
                            file_path=filename,
                            recommendation=self._get_secret_recommendation(
                                secret_type or SecretType.GENERIC_SECRET
                            ),
                        )
                        secrets.append(secret)

        return secrets

    def _detect_env_vars(self, content: str, filename: str) -> list[EnvironmentVariable]:
        """Detect environment variable references in content."""
        env_vars: list[EnvironmentVariable] = []
        lines = content.splitlines()

        for line_num, line in enumerate(lines, 1):
            for pattern in self.ENV_VAR_PATTERNS:
                for match in re.finditer(pattern, line):
                    var_name = match.group(1)

                    # Try to find key path from context
                    key_path = self._extract_key_path(line)

                    # Check for default value
                    default = self._extract_default_value(line, var_name)

                    env_var = EnvironmentVariable(
                        name=var_name,
                        key_path=key_path,
                        file_path=filename,
                        line_number=line_num,
                        default_value=default,
                        is_required=default is None,
                    )
                    env_vars.append(env_var)

        return env_vars

    def _extract_key_path(self, line: str) -> str:
        """Extract the configuration key path from a line."""
        # Look for key = value pattern
        match = re.match(r'["\']?([a-zA-Z_][a-zA-Z0-9_]*)["\']?\s*[:=]', line.strip())
        if match:
            return match.group(1)
        return "unknown"

    def _extract_default_value(self, line: str, var_name: str) -> str | None:
        """Extract default value for an environment variable."""
        # Pattern for os.getenv("VAR", "default")
        match = re.search(
            r'(?:getenv|environ\.get)\(["\']' + var_name + r'["\'],\s*["\']([^"\']*)["\']',
            line,
        )
        if match:
            return match.group(1)
        return None

    def _get_secret_recommendation(self, secret_type: SecretType) -> str:
        """Get recommendation for a secret type."""
        recommendations = {
            SecretType.API_KEY: "Move API key to environment variable or secrets manager",
            SecretType.PASSWORD: "Use environment variable or secrets manager for passwords",
            SecretType.TOKEN: "Store tokens in secure secrets manager with rotation policy",
            SecretType.SECRET_KEY: "Use environment variable and rotate secret keys regularly",
            SecretType.CONNECTION_STRING: "Use environment variable for connection strings",
            SecretType.PRIVATE_KEY: "Store private keys in secure vault, never in code",
            SecretType.AWS_KEY: "Use IAM roles or AWS Secrets Manager instead of hardcoded keys",
            SecretType.GENERIC_SECRET: "Review this value - appears to contain sensitive data",
        }
        return recommendations.get(secret_type, "Review this configuration value")

    def extract_security_settings(self, config: dict[str, Any], framework: str) -> SecuritySettings:
        """
        Extract security-relevant settings for a specific framework.

        Args:
            config: Parsed configuration dictionary
            framework: Framework name (langchain, crewai, autogen, etc.)

        Returns:
            SecuritySettings with extracted settings and warnings
        """
        framework_lower = framework.lower()
        settings_keys = self.FRAMEWORK_SETTINGS.get(framework_lower, [])

        extracted: dict[str, Any] = {}
        warnings: list[str] = []
        recommendations: list[str] = []

        def extract_recursive(data: dict, prefix: str = ""):
            for key, value in data.items():
                full_key = f"{prefix}.{key}" if prefix else key

                # Check if this key is security-relevant
                if key.lower() in [k.lower() for k in settings_keys]:
                    extracted[full_key] = value

                    # Check for security warnings
                    self._check_setting_security(key, value, warnings, recommendations)

                # Recurse into nested dicts
                if isinstance(value, dict):
                    extract_recursive(value, full_key)

        extract_recursive(config)

        # Framework-specific checks
        if framework_lower == "langchain":
            self._check_langchain_security(config, warnings, recommendations)
        elif framework_lower == "crewai":
            self._check_crewai_security(config, warnings, recommendations)
        elif framework_lower == "autogen":
            self._check_autogen_security(config, warnings, recommendations)

        return SecuritySettings(
            framework=framework,
            settings=extracted,
            warnings=warnings,
            recommendations=recommendations,
        )

    def _check_setting_security(
        self, key: str, value: Any, warnings: list[str], recommendations: list[str]
    ):
        """Check individual setting for security issues."""
        key_lower = key.lower()

        # Verbose mode warnings
        if key_lower == "verbose" and value is True:
            warnings.append("Verbose mode enabled - may leak sensitive information in logs")
            recommendations.append("Disable verbose mode in production")

        # Temperature settings
        if key_lower == "temperature" and isinstance(value, (int, float)):
            if value > 1.0:
                warnings.append(f"High temperature ({value}) may cause unpredictable outputs")
                recommendations.append("Use temperature <= 1.0 for consistent behavior")

        # Max tokens
        if key_lower == "max_tokens" and isinstance(value, int):
            if value > 4000:
                warnings.append(f"High max_tokens ({value}) may increase costs significantly")

        # Delegation
        if key_lower == "allow_delegation" and value is True:
            warnings.append("Agent delegation enabled - ensure proper trust boundaries")
            recommendations.append("Implement validation for delegated tasks")

    def _check_langchain_security(
        self, config: dict[str, Any], warnings: list[str], recommendations: list[str]
    ):
        """LangChain-specific security checks."""
        # Check for dangerous tool usage
        if "tools" in config:
            tools = config["tools"]
            dangerous_tools = ["shell", "python_repl", "terminal", "bash"]
            for tool in tools if isinstance(tools, list) else []:
                if any(dt in str(tool).lower() for dt in dangerous_tools):
                    warnings.append(f"Dangerous tool detected: {tool}")
                    recommendations.append("Restrict code execution tools or sandbox them")

    def _check_crewai_security(
        self, config: dict[str, Any], warnings: list[str], recommendations: list[str]
    ):
        """CrewAI-specific security checks."""
        # Check memory settings
        if config.get("memory") is True:
            warnings.append("Crew memory enabled - may retain sensitive information")
            recommendations.append("Implement memory sanitization for sensitive data")

    def _check_autogen_security(
        self, config: dict[str, Any], warnings: list[str], recommendations: list[str]
    ):
        """AutoGen-specific security checks."""
        # Check code execution config
        code_exec = config.get("code_execution_config", {})
        if code_exec:
            if code_exec.get("use_docker") is False:
                warnings.append("Code execution without Docker isolation")
                recommendations.append("Enable Docker for code execution sandboxing")

        # Check human input mode
        if config.get("human_input_mode") == "NEVER":
            warnings.append("No human oversight - agent runs autonomously")
            recommendations.append("Consider TERMINATE or ALWAYS mode for sensitive operations")

    def _extract_all_security_settings(
        self, config_files: list[ConfigFile]
    ) -> list[SecuritySettings]:
        """Extract security settings from all config files."""
        settings: list[SecuritySettings] = []

        # Detect frameworks from imports and config patterns
        framework_indicators = {
            "langchain": ["langchain", "LANGCHAIN", "chain", "agent_executor"],
            "crewai": ["crewai", "CREWAI", "Crew", "crew"],
            "autogen": ["autogen", "AUTOGEN", "AssistantAgent", "UserProxyAgent"],
            "openai": ["openai", "OPENAI", "gpt-", "davinci"],
            "anthropic": ["anthropic", "ANTHROPIC", "claude"],
        }

        for cf in config_files:
            detected_frameworks: set[str] = set()

            # Check content for framework indicators
            for framework, indicators in framework_indicators.items():
                if any(ind in cf.raw_content for ind in indicators):
                    detected_frameworks.add(framework)

            # Extract settings for each detected framework
            for framework in detected_frameworks:
                security_settings = self.extract_security_settings(cf.content, framework)
                if security_settings.settings or security_settings.warnings:
                    settings.append(security_settings)

        return settings
