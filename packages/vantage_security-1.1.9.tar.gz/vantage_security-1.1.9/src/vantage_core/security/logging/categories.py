"""
Log category definitions for Vantage security scanner.

Provides a taxonomy of log categories for filtering, routing,
and analysis of scanner operations.
"""

from enum import Enum


class LogCategory(str, Enum):
    """
    Log categories for filtering and routing.

    Categories are hierarchical using dot notation to enable
    filtering at different granularities.
    """

    # Scanner operations
    SCANNER_PARSER = "scanner.parser"
    SCANNER_ANALYSIS = "scanner.analysis"
    SCANNER_PROGRESS = "scanner.progress"
    SCANNER_RESULTS = "scanner.results"
    SCANNER_DEGRADATION = "scanner.degradation"
    SCANNER_FAILURE = "scanner.failure"
    SCANNER_SECURITY = "scanner.security"

    # Pipeline operations
    PIPELINE = "pipeline"
    PIPELINE_STAGE = "pipeline.stage"

    # Configuration
    CONFIG = "config"
    CONFIG_LOAD = "config.load"
    CONFIG_CHANGE = "config.change"
    CONFIG_VALIDATION = "config.validation"

    # Rules engine
    RULES = "rules"
    RULES_LOAD = "rules.load"
    RULES_EVALUATION = "rules.evaluation"
    RULES_MATCH = "rules.match"

    # Taint analysis
    TAINT = "taint"
    TAINT_PROPAGATION = "taint.propagation"
    TAINT_SOURCE = "taint.source"
    TAINT_SINK = "taint.sink"

    # Audit trail
    AUDIT = "audit"
    AUDIT_SCAN = "audit.scan"
    AUDIT_CONFIG = "audit.config"
    AUDIT_ACCESS = "audit.access"

    # Performance metrics
    METRICS = "metrics"
    METRICS_TIMING = "metrics.timing"
    METRICS_MEMORY = "metrics.memory"
    METRICS_FINDINGS = "metrics.findings"

    # Decisions (for US-002)
    DECISION = "decision"
    DECISION_FILTER = "decision.filter"
    DECISION_REPORT = "decision.report"
    DECISION_SUPPRESS = "decision.suppress"


class FilterReason(str, Enum):
    """
    Reasons why a finding may be filtered out.

    Used for scanner decision logging (US-002) to provide
    transparency into filtering decisions.
    """

    # Allowlist filters
    ALLOWLISTED_PATH = "allowlisted_path"
    ALLOWLISTED_PATTERN = "allowlisted_pattern"
    ALLOWLISTED_RULE = "allowlisted_rule"

    # Confidence filters
    LOW_CONFIDENCE = "low_confidence"
    BELOW_THRESHOLD = "below_threshold"

    # Duplicate detection
    DUPLICATE_FINDING = "duplicate_finding"
    SIMILAR_FINDING = "similar_finding"

    # Suppression
    USER_SUPPRESSED = "user_suppressed"
    INLINE_SUPPRESSED = "inline_suppressed"

    # False positive detection
    FALSE_POSITIVE_PATTERN = "false_positive_pattern"
    TEST_FILE = "test_file"
    PLACEHOLDER_VALUE = "placeholder_value"

    # Severity filters
    SEVERITY_BELOW_MINIMUM = "severity_below_minimum"


class AuditEventType(str, Enum):
    """
    Types of audit events for compliance logging (US-004).

    Maps to SOC 2 control requirements for security tooling.
    """

    # Scan operations
    SCAN_STARTED = "scan.started"
    SCAN_COMPLETED = "scan.completed"
    SCAN_FAILED = "scan.failed"

    # Configuration changes
    CONFIG_LOADED = "config.loaded"
    CONFIG_CHANGED = "config.changed"
    CONFIG_RESET = "config.reset"

    # Finding management
    FINDING_REPORTED = "finding.reported"
    FINDING_SUPPRESSED = "finding.suppressed"
    FINDING_RESOLVED = "finding.resolved"

    # Rule management
    RULE_LOADED = "rule.loaded"
    RULE_ENABLED = "rule.enabled"
    RULE_DISABLED = "rule.disabled"

    # Access events
    API_ACCESS = "api.access"
    EXPORT_RESULTS = "export.results"


class MetricUnit(str, Enum):
    """
    Units for performance metrics (US-003).

    Ensures consistent units across all metrics logging.
    """

    MILLISECONDS = "ms"
    SECONDS = "s"
    BYTES = "bytes"
    KILOBYTES = "kb"
    MEGABYTES = "mb"
    COUNT = "count"
    PERCENTAGE = "percent"
