"""
Pipeline Module for Vantage Security Platform.

End-to-end security scan orchestration with progress tracking.
"""

from vantage_core.security.pipeline.orchestrator import (
    PipelineConfig,
    PipelineError,
    PipelineResult,
    ScanStage,
    SecurityPipeline,
    StageResult,
    run_security_pipeline,
)
from vantage_core.security.pipeline.progress import (
    ConsoleProgressCallback,
    JSONProgressCallback,
    PipelineProgress,
    ProgressCallback,
    ProgressReporter,
    StageProgress,
    StageStatus,
    WebSocketProgressCallback,
)

__all__ = [
    # Orchestrator
    "SecurityPipeline",
    "PipelineConfig",
    "PipelineResult",
    "ScanStage",
    "StageResult",
    "PipelineError",
    "run_security_pipeline",
    # Progress
    "ProgressReporter",
    "ProgressCallback",
    "StageProgress",
    "PipelineProgress",
    "StageStatus",
    "ConsoleProgressCallback",
    "JSONProgressCallback",
    "WebSocketProgressCallback",
]
