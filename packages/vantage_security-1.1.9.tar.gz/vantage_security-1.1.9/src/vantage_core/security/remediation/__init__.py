"""
Remediation Module for Vantage Security Platform.

Generates framework-specific fixes for security vulnerabilities
with validation and test case generation.
"""

from vantage_core.security.remediation.dispatch_patterns import (
    AttributeDispatcher,
    DispatchError,
    FieldExtractor,
    InvalidMethodNameError,
    NameValidators,
    SafeDispatcher,
    UnknownMethodError,
    dispatch_decorator,
)
from vantage_core.security.remediation.generator import (
    CodeContext,
    DiffGenerator,
    EffortEstimator,
    Remediation,
    RemediationGenerator,
    TestCaseGenerator,
    generate_remediation,
)
from vantage_core.security.remediation.patterns import (
    REMEDIATION_PATTERNS,
    Framework,
    RemediationPattern,
    RemediationPatternDB,
    RemediationType,
)
from vantage_core.security.remediation.validator import (
    RemediationValidator,
    ValidationResult,
    validate_remediation,
)

__all__ = [
    # Patterns
    "RemediationPatternDB",
    "RemediationPattern",
    "Framework",
    "RemediationType",
    "REMEDIATION_PATTERNS",
    # Generator
    "RemediationGenerator",
    "Remediation",
    "CodeContext",
    "EffortEstimator",
    "DiffGenerator",
    "TestCaseGenerator",
    "generate_remediation",
    # Validator
    "RemediationValidator",
    "ValidationResult",
    "validate_remediation",
    # Dispatch Patterns (safe exec/eval alternatives)
    "SafeDispatcher",
    "AttributeDispatcher",
    "FieldExtractor",
    "DispatchError",
    "UnknownMethodError",
    "InvalidMethodNameError",
    "dispatch_decorator",
    "NameValidators",
]
