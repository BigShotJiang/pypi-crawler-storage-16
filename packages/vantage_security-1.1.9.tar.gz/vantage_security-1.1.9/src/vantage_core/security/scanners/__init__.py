"""
Security Scanners for various AI agent frameworks.

Each scanner implements the SecurityScanner base class and provides
framework-specific vulnerability detection capabilities.
"""

from vantage_core.security.scanners.autogen import AutoGenSecurityScanner
from vantage_core.security.scanners.base import SecurityScanner
from vantage_core.security.scanners.crewai import CrewAISecurityScanner
from vantage_core.security.scanners.dependencies import (
    Dependency,
    DependencyScanner,
    DependencyScanResult,
    Vulnerability,
    scan_dependencies,
)
from vantage_core.security.scanners.langchain import LangChainSecurityScanner
from vantage_core.security.scanners.llamaindex import LlamaIndexSecurityScanner
from vantage_core.security.scanners.semantic_kernel import SemanticKernelSecurityScanner

__all__ = [
    "SecurityScanner",
    "LangChainSecurityScanner",
    "CrewAISecurityScanner",
    "AutoGenSecurityScanner",
    "LlamaIndexSecurityScanner",
    "SemanticKernelSecurityScanner",
    # Dependency Scanner
    "DependencyScanner",
    "Dependency",
    "Vulnerability",
    "DependencyScanResult",
    "scan_dependencies",
]
