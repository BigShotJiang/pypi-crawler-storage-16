"""
Multi-Agent Prompt Infection Simulator

Simulates how a prompt injection attack propagates through an agent network.
Based on research: arXiv:2410.07283 - "Prompt Infection: LLM-to-LLM Prompt Injection"

This is a KILLER FEATURE - no other security tool can simulate multi-agent attacks.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

import networkx as nx

from vantage_core.security.models import (
    TrustLevel,
)
from vantage_core.security.topology.graph import (
    AgentGraph,
    CommunicationType,
    GraphEdge,
    GraphNode,
)

# =============================================================================
# Enums and Data Classes for NetworkX-based Simulator
# =============================================================================


class InfectionStatus(Enum):
    """Agent infection status."""

    HEALTHY = "healthy"
    EXPOSED = "exposed"  # Received infected message
    INFECTED = "infected"  # Propagating infection
    CONTAINED = "contained"  # Infection stopped by defenses


@dataclass
class InfectionEvent:
    """Record of an infection propagation event."""

    step: int
    source_agent: str
    target_agent: str
    payload: str
    success: bool
    reason: str
    confidence: float


@dataclass
class AgentDefenses:
    """Agent's defensive capabilities."""

    input_validation: bool = False
    output_sanitization: bool = False
    prompt_hardening: float = 0.0  # 0-1 scale
    trust_verification: bool = False
    rate_limiting: bool = False

    @property
    def defense_score(self) -> float:
        """Calculate overall defense score (0-1)."""
        score = 0.0
        if self.input_validation:
            score += 0.25
        if self.output_sanitization:
            score += 0.20
        score += self.prompt_hardening * 0.30
        if self.trust_verification:
            score += 0.15
        if self.rate_limiting:
            score += 0.10
        return min(1.0, score)


@dataclass
class SimulationResult:
    """Result of attack simulation."""

    initial_compromise: str
    payload_used: str
    total_agents: int
    compromised_agents: list[str]
    contained_agents: list[str]
    healthy_agents: list[str]
    propagation_path: list[InfectionEvent]
    max_steps_reached: int
    blast_radius: float  # % of network compromised
    time_to_full_infection: int | None  # Steps, None if contained
    critical_path: list[str]  # Shortest path to most critical agent
    containment_recommendations: list[str]


class PromptInfectionSimulator:
    """
    Simulates prompt injection attacks propagating through multi-agent systems.

    Uses epidemic modeling (SIR-like) combined with agent-specific defenses
    to predict how attacks spread through agent networks.
    """

    def __init__(self, topology: nx.DiGraph):
        """
        Initialize simulator with agent topology.

        Args:
            topology: Directed graph of agent communication
                     Nodes are agent IDs, edges are communication channels
                     Node attributes: 'trust_level', 'tools', 'defenses'
                     Edge attributes: 'message_type', 'frequency'
        """
        self.topology = topology
        self.agent_status: dict[str, InfectionStatus] = {}
        self.agent_defenses: dict[str, AgentDefenses] = {}
        self._initialize_agents()

    def _initialize_agents(self) -> None:
        """Initialize agent status and defenses from topology."""
        for agent_id in self.topology.nodes():
            self.agent_status[agent_id] = InfectionStatus.HEALTHY

            # Extract defenses from node attributes or use defaults
            node_data = self.topology.nodes[agent_id]
            self.agent_defenses[agent_id] = AgentDefenses(
                input_validation=node_data.get("input_validation", False),
                output_sanitization=node_data.get("output_sanitization", False),
                prompt_hardening=node_data.get("prompt_hardening", 0.0),
                trust_verification=node_data.get("trust_verification", False),
                rate_limiting=node_data.get("rate_limiting", False),
            )

    def simulate_infection(
        self,
        initial_agent: str,
        payload: str,
        max_steps: int = 20,
        infection_probability: float = 0.7,
    ) -> SimulationResult:
        """
        Simulate infection spreading from initial agent.

        Args:
            initial_agent: ID of first compromised agent
            payload: Injection payload being propagated
            max_steps: Maximum simulation steps
            infection_probability: Base probability of successful infection

        Returns:
            SimulationResult with full propagation analysis
        """
        # Reset state
        self._reset_simulation()

        # Validate initial agent exists
        if initial_agent not in self.topology.nodes():
            raise ValueError(f"Initial agent '{initial_agent}' not found in topology")

        # Infect initial agent
        self.agent_status[initial_agent] = InfectionStatus.INFECTED
        infected: set[str] = {initial_agent}
        contained: set[str] = set()
        propagation_log: list[InfectionEvent] = []

        step = 0
        for step in range(max_steps):
            newly_infected: set[str] = set()

            for source_id in list(infected):
                # Get agents this infected agent can reach
                downstream = list(self.topology.successors(source_id))

                for target_id in downstream:
                    if self.agent_status[target_id] != InfectionStatus.HEALTHY:
                        continue  # Already infected or contained

                    # Calculate infection probability
                    success, confidence, reason = self._attempt_infection(
                        source_id, target_id, payload, infection_probability
                    )

                    # Record event
                    event = InfectionEvent(
                        step=step,
                        source_agent=source_id,
                        target_agent=target_id,
                        payload=payload[:50] + "..." if len(payload) > 50 else payload,
                        success=success,
                        reason=reason,
                        confidence=confidence,
                    )
                    propagation_log.append(event)

                    if success:
                        newly_infected.add(target_id)
                        self.agent_status[target_id] = InfectionStatus.INFECTED
                    else:
                        contained.add(target_id)
                        self.agent_status[target_id] = InfectionStatus.CONTAINED

            infected.update(newly_infected)

            # Check if infection has stopped
            if not newly_infected:
                break

        # Calculate results
        healthy = {a for a, s in self.agent_status.items() if s == InfectionStatus.HEALTHY}

        total_nodes = len(self.topology.nodes())
        blast_radius = len(infected) / total_nodes if total_nodes > 0 else 0.0

        # Find critical path (to most important agent)
        critical_path = self._find_critical_path(initial_agent, infected)

        # Generate containment recommendations
        recommendations = self._generate_recommendations(infected, contained, propagation_log)

        return SimulationResult(
            initial_compromise=initial_agent,
            payload_used=payload,
            total_agents=total_nodes,
            compromised_agents=list(infected),
            contained_agents=list(contained),
            healthy_agents=list(healthy),
            propagation_path=propagation_log,
            max_steps_reached=step + 1,
            blast_radius=blast_radius,
            time_to_full_infection=step + 1 if blast_radius == 1.0 else None,
            critical_path=critical_path,
            containment_recommendations=recommendations,
        )

    def _attempt_infection(
        self, source: str, target: str, payload: str, base_probability: float
    ) -> tuple[bool, float, str]:
        """
        Attempt to infect target agent from source.

        Returns: (success, confidence, reason)
        """
        defenses = self.agent_defenses[target]

        # Calculate adjusted probability
        probability = base_probability
        reasons: list[str] = []

        # Input validation reduces infection chance
        if defenses.input_validation:
            probability *= 0.4
            reasons.append("input_validation_blocked")

        # Prompt hardening reduces infection
        probability *= 1.0 - defenses.prompt_hardening * 0.5
        if defenses.prompt_hardening > 0.5:
            reasons.append("prompt_hardened")

        # Trust verification can catch cross-agent injection
        if defenses.trust_verification:
            probability *= 0.6
            reasons.append("trust_verification")

        # Edge attributes affect propagation
        edge_data = self.topology.edges.get((source, target), {})
        if edge_data.get("encrypted", False):
            probability *= 0.8  # Encryption doesn't stop injection but adds complexity

        # Payload sophistication affects success
        payload_strength = self._assess_payload_strength(payload)
        probability *= payload_strength

        # Deterministic evaluation based on defense threshold
        # If probability >= 0.5, infection succeeds (defenses insufficient)
        # If probability < 0.5, infection blocked (defenses effective)
        DEFENSE_THRESHOLD = 0.5
        success = probability >= DEFENSE_THRESHOLD

        reason = "infection_propagated" if success else ", ".join(reasons) or "defenses_effective"

        return success, probability, reason

    def _assess_payload_strength(self, payload: str) -> float:
        """Assess how strong/sophisticated the payload is."""
        strength = 1.0

        # Sophisticated payloads have higher success
        if "ignore" in payload.lower() or "disregard" in payload.lower():
            strength *= 1.2
        if "[INST]" in payload or "<|system|>" in payload:
            strength *= 1.3  # Token-level injection
        if len(payload) > 500:
            strength *= 0.9  # Very long payloads may be filtered

        return min(1.5, strength)

    def _find_critical_path(self, start: str, infected: set[str]) -> list[str]:
        """Find path from start to most critical infected agent."""
        # Determine criticality (by tools, trust level, connectivity)
        criticality: dict[str, int] = {}
        for agent_id in infected:
            node_data = self.topology.nodes.get(agent_id, {})
            score = 0

            # More tools = more critical
            tools = node_data.get("tools", [])
            score += len(tools) * 10

            # Higher trust = more critical
            trust = node_data.get("trust_level", 0)
            score += trust * 20

            # More connections = more critical
            score += self.topology.degree(agent_id) * 5

            criticality[agent_id] = score

        if not criticality:
            return [start]

        most_critical = max(criticality, key=lambda k: criticality[k])

        try:
            path = nx.shortest_path(self.topology, start, most_critical)
            return list(path)
        except nx.NetworkXNoPath:
            return [start, most_critical]

    def _generate_recommendations(
        self, infected: set[str], contained: set[str], events: list[InfectionEvent]
    ) -> list[str]:
        """Generate containment and prevention recommendations."""
        recommendations: list[str] = []

        # Analyze what stopped infections
        containment_reasons: dict[str, int] = {}
        for event in events:
            if not event.success:
                containment_reasons[event.reason] = containment_reasons.get(event.reason, 0) + 1

        # Most effective defenses
        if containment_reasons:
            most_effective = max(containment_reasons, key=lambda k: containment_reasons[k])
            recommendations.append(
                f"Most effective defense: {most_effective} "
                f"(blocked {containment_reasons[most_effective]} infections)"
            )

        # Agents that need hardening
        for agent_id in infected:
            defenses = self.agent_defenses[agent_id]
            if defenses.defense_score < 0.5:
                recommendations.append(
                    f"CRITICAL: Harden agent '{agent_id}' "
                    f"(defense score: {defenses.defense_score:.1%})"
                )

        # Topology recommendations
        total_nodes = len(self.topology.nodes())
        if total_nodes > 0 and len(infected) > total_nodes * 0.5:
            recommendations.append(
                "CRITICAL: >50% agents compromised. Consider segmenting agent network."
            )

        # Specific defense recommendations
        if not any(d.input_validation for d in self.agent_defenses.values()):
            recommendations.append("Add input validation to at least entry-point agents")

        if not any(d.trust_verification for d in self.agent_defenses.values()):
            recommendations.append("Implement trust verification for cross-agent communication")

        return recommendations

    def _reset_simulation(self) -> None:
        """Reset simulation state."""
        for agent_id in self.topology.nodes():
            self.agent_status[agent_id] = InfectionStatus.HEALTHY

    def run_multiple_scenarios(
        self,
        payloads: list[str],
        entry_points: list[str] | None = None,
        iterations: int = 100,
    ) -> dict:
        """
        Run multiple simulation scenarios for statistical analysis.

        Args:
            payloads: List of payloads to test
            entry_points: Specific entry points, or None for all
            iterations: Number of iterations per scenario

        Returns:
            Statistical summary of all simulations
        """
        if entry_points is None:
            # Use agents with external exposure as entry points
            entry_points = [
                n
                for n in self.topology.nodes()
                if self.topology.nodes[n].get("external_exposure", False)
            ] or list(self.topology.nodes())[:3]

        results: dict = {
            "total_simulations": 0,
            "average_blast_radius": 0.0,
            "max_blast_radius": 0.0,
            "min_blast_radius": 1.0,
            "most_vulnerable_entry": None,
            "most_effective_payload": None,
            "containment_success_rate": 0.0,
            "critical_agents": [],
        }

        all_blast_radii: list[float] = []
        entry_vulnerability: dict[str, float] = {e: 0.0 for e in entry_points}
        payload_effectiveness: dict[str, float] = {p: 0.0 for p in payloads}

        for entry in entry_points:
            for payload in payloads:
                for _ in range(iterations):
                    result = self.simulate_infection(entry, payload)
                    all_blast_radii.append(result.blast_radius)
                    entry_vulnerability[entry] += result.blast_radius
                    payload_effectiveness[payload] += result.blast_radius
                    results["total_simulations"] += 1

        # Calculate statistics
        if all_blast_radii:
            results["average_blast_radius"] = sum(all_blast_radii) / len(all_blast_radii)
            results["max_blast_radius"] = max(all_blast_radii)
            results["min_blast_radius"] = min(all_blast_radii)

        # Normalize and find most vulnerable/effective
        if entry_vulnerability:
            total_iterations_per_entry = len(payloads) * iterations
            for e in entry_vulnerability:
                entry_vulnerability[e] /= total_iterations_per_entry
            results["most_vulnerable_entry"] = max(
                entry_vulnerability, key=lambda k: entry_vulnerability[k]
            )

        if payload_effectiveness:
            total_iterations_per_payload = len(entry_points) * iterations
            for p in payload_effectiveness:
                payload_effectiveness[p] /= total_iterations_per_payload
            results["most_effective_payload"] = max(
                payload_effectiveness, key=lambda k: payload_effectiveness[k]
            )

        # Containment success rate
        contained_count = sum(1 for r in all_blast_radii if r < 0.5)
        results["containment_success_rate"] = (
            contained_count / len(all_blast_radii) if all_blast_radii else 0
        )

        return results

    def get_infection_statistics(self) -> dict:
        """
        Get current infection statistics.

        Returns:
            Dictionary with infection status counts
        """
        stats = {
            "healthy": 0,
            "exposed": 0,
            "infected": 0,
            "contained": 0,
            "total": len(self.agent_status),
        }

        for status in self.agent_status.values():
            if status == InfectionStatus.HEALTHY:
                stats["healthy"] += 1
            elif status == InfectionStatus.EXPOSED:
                stats["exposed"] += 1
            elif status == InfectionStatus.INFECTED:
                stats["infected"] += 1
            elif status == InfectionStatus.CONTAINED:
                stats["contained"] += 1

        return stats

    def get_defense_summary(self) -> dict:
        """
        Get summary of defenses across all agents.

        Returns:
            Dictionary with defense statistics
        """
        total = len(self.agent_defenses)
        if total == 0:
            return {
                "average_defense_score": 0.0,
                "agents_with_input_validation": 0,
                "agents_with_output_sanitization": 0,
                "agents_with_trust_verification": 0,
                "agents_with_rate_limiting": 0,
                "average_prompt_hardening": 0.0,
            }

        defense_scores = [d.defense_score for d in self.agent_defenses.values()]
        prompt_hardening_values = [d.prompt_hardening for d in self.agent_defenses.values()]

        return {
            "average_defense_score": sum(defense_scores) / total,
            "agents_with_input_validation": sum(
                1 for d in self.agent_defenses.values() if d.input_validation
            ),
            "agents_with_output_sanitization": sum(
                1 for d in self.agent_defenses.values() if d.output_sanitization
            ),
            "agents_with_trust_verification": sum(
                1 for d in self.agent_defenses.values() if d.trust_verification
            ),
            "agents_with_rate_limiting": sum(
                1 for d in self.agent_defenses.values() if d.rate_limiting
            ),
            "average_prompt_hardening": sum(prompt_hardening_values) / total,
        }


# =============================================================================
# Legacy Classes (AgentGraph-based) - Preserved for backward compatibility
# =============================================================================


class InfectionVector(str, Enum):
    """Ways an infection can spread between agents."""

    NO_CONNECTION = "no_connection"
    OUTPUT_NOT_PROCESSED = "output_not_processed"
    DEFENDED = "defended"
    VALIDATED = "validated"
    DIRECT_MESSAGE = "direct_message"
    SHARED_MEMORY = "shared_memory"
    DELEGATED_TASK = "delegated_task"
    CALLBACK_RESULT = "callback_result"
    BROADCAST = "broadcast"
    TOOL_OUTPUT = "tool_output"


@dataclass
class LegacyInfectionEvent:
    """Records a single infection propagation event (legacy format)."""

    hop: int
    source_agent: str
    target_agent: str
    infection_vector: str
    timestamp: int
    confidence: float = 1.0
    payload_mutation: str | None = None


@dataclass
class CriticalAgentAnalysis:
    """Analysis of agents critical to infection spread."""

    agent_id: str
    agent_name: str
    direct_infections: int
    total_descendants: int
    criticality_score: float
    recommendation: str
    risk_factors: list[str] = field(default_factory=list)


@dataclass
class ContainmentRecommendation:
    """Recommendation for containing infection spread."""

    strategy: str
    priority: str
    description: str
    impact: str
    implementation: str
    estimated_effort: str = "medium"
    effectiveness_score: float = 0.7


@dataclass
class InfectionSimulationResult:
    """Complete results from infection simulation (legacy format)."""

    entry_point: str
    blast_radius: int
    total_agents: int
    infection_percentage: float
    propagation_log: list[LegacyInfectionEvent]
    infection_graph: nx.DiGraph
    critical_agents: list[CriticalAgentAnalysis]
    containment_recommendations: list[ContainmentRecommendation]
    simulation_timestamp: datetime = field(default_factory=datetime.now)
    max_hop_reached: int = 0
    infection_stopped: bool = False
    stopping_reason: str | None = None


class AgentTopology:
    """
    Represents the network topology of agents.

    This is a wrapper around AgentGraph that provides additional
    functionality for infection simulation.
    """

    def __init__(self, graph: AgentGraph | None = None):
        """Initialize topology with optional existing graph."""
        self._graph = graph if graph else AgentGraph()
        self.agents: dict[str, GraphNode] = {}

    def add_agent(
        self,
        agent_id: str,
        trust_level: str = "INTERNAL",
        name: str | None = None,
        **kwargs,
    ) -> None:
        """Add an agent to the topology."""
        trust_enum = TrustLevel[trust_level.upper()]
        node = self._graph.add_node(
            id=agent_id, name=name or agent_id, trust_level=trust_enum, **kwargs
        )
        self.agents[agent_id] = node

    def add_connection(
        self, source: str, target: str, communication_type: str = "DIRECT", **kwargs
    ) -> None:
        """Add a connection between agents."""
        comm_type = CommunicationType[communication_type.upper()]
        self._graph.add_edge(source, target, communication_type=comm_type, **kwargs)

    def get_downstream_agents(self, agent_id: str) -> list[str]:
        """Get all agents that can be reached from this agent."""
        return self._graph.get_neighbors(agent_id)

    def get_agent(self, agent_id: str) -> GraphNode | None:
        """Get agent node by ID."""
        return self._graph.get_node(agent_id)

    def get_connection(self, source: str, target: str) -> GraphEdge | None:
        """Get connection between two agents."""
        return self._graph.get_edge(source, target)


class LegacyPromptInfectionSimulator:
    """
    Legacy simulator using AgentTopology wrapper.

    Preserved for backward compatibility with existing code.
    For new code, use PromptInfectionSimulator with nx.DiGraph directly.
    """

    def __init__(self):
        """Initialize the simulator."""
        self._defense_patterns = {
            "input_validation": ["validate", "sanitize", "filter", "clean"],
            "prompt_defense": ["system_prompt", "instruction_defense", "boundary"],
            "output_monitoring": ["monitor", "detect", "anomaly", "behavioral"],
        }

    def simulate_infection(
        self,
        topology: AgentTopology,
        entry_point: str,
        injection_payload: str,
        max_hops: int = 10,
    ) -> InfectionSimulationResult:
        """
        Simulate prompt infection spreading through agent network.

        Args:
            topology: Agent network topology
            entry_point: Initial compromised agent ID
            injection_payload: The prompt injection to simulate
            max_hops: Maximum propagation hops

        Returns:
            Complete infection simulation with:
            - Blast radius (how many agents compromised)
            - Propagation path (how infection spreads)
            - Critical agents at risk
            - Containment recommendations
        """
        # Initialize simulation state
        compromised_agents = {entry_point}
        propagation_log = []
        infection_graph = nx.DiGraph()
        infection_graph.add_node(entry_point, hop=0)

        # Track why simulation stops
        stopping_reason = None
        max_hop_reached = 0
        newly_compromised: set[str] = set()

        # Simulate infection spreading hop by hop
        for hop in range(max_hops):
            newly_compromised = set()

            for agent_id in list(compromised_agents):
                # What agents can this one reach?
                downstream = topology.get_downstream_agents(agent_id)

                for target_id in downstream:
                    if target_id in compromised_agents:
                        continue  # Already compromised

                    # Can infection propagate to this agent?
                    can_infect, infection_vector = self._can_propagate(
                        source=topology.get_agent(agent_id),
                        target=topology.get_agent(target_id),
                        payload=injection_payload,
                        topology=topology,
                    )

                    if can_infect:
                        newly_compromised.add(target_id)
                        infection_graph.add_edge(
                            agent_id, target_id, vector=infection_vector, hop=hop + 1
                        )

                        propagation_log.append(
                            LegacyInfectionEvent(
                                hop=hop + 1,
                                source_agent=agent_id,
                                target_agent=target_id,
                                infection_vector=infection_vector,
                                timestamp=hop,
                                confidence=self._calculate_infection_confidence(
                                    topology.get_agent(target_id)
                                ),
                            )
                        )

            compromised_agents.update(newly_compromised)
            max_hop_reached = hop + 1

            if not newly_compromised:
                stopping_reason = "No new infections - containment successful"
                break  # Infection contained
        else:
            stopping_reason = f"Maximum hops ({max_hops}) reached"

        # Analyze results
        return InfectionSimulationResult(
            entry_point=entry_point,
            blast_radius=len(compromised_agents),
            total_agents=len(topology.agents),
            infection_percentage=len(compromised_agents) / max(len(topology.agents), 1),
            propagation_log=propagation_log,
            infection_graph=infection_graph,
            critical_agents=self._identify_critical_agents(infection_graph, topology),
            containment_recommendations=self._generate_containment_strategy(
                infection_graph, topology
            ),
            max_hop_reached=max_hop_reached,
            infection_stopped=len(newly_compromised) == 0,
            stopping_reason=stopping_reason,
        )

    def _can_propagate(
        self,
        source: GraphNode | None,
        target: GraphNode | None,
        payload: str,
        topology: AgentTopology,
    ) -> tuple[bool, str]:
        """
        Determine if infection can propagate from source to target.

        Returns: (can_infect, infection_vector)
        """
        if not source or not target:
            return False, InfectionVector.NO_CONNECTION

        # Check 1: Does source communicate with target?
        connection = topology.get_connection(source.id, target.id)
        if not connection:
            return False, InfectionVector.NO_CONNECTION

        # Check 2: Does target process source's output?
        if not self._processes_output(target, source, connection):
            return False, InfectionVector.OUTPUT_NOT_PROCESSED

        # Check 3: Is target vulnerable to prompt injection?
        if self._has_prompt_injection_defense(target):
            return False, InfectionVector.DEFENDED

        # Check 4: Does target have validation?
        if self._has_input_validation(target, connection):
            return False, InfectionVector.VALIDATED

        # Infection succeeds - identify vector
        infection_vector = self._identify_infection_vector(source, target, connection)
        return True, infection_vector

    def _processes_output(
        self, target: GraphNode, source: GraphNode, connection: GraphEdge | None
    ) -> bool:
        """Check if target processes output from source."""
        if not connection:
            return False

        # Different communication types have different processing likelihood
        if connection.communication_type == CommunicationType.DIRECT:
            return True
        elif connection.communication_type == CommunicationType.BROADCAST:
            return True
        elif connection.communication_type == CommunicationType.CALLBACK:
            return True
        elif connection.communication_type == CommunicationType.SHARED_MEMORY:
            return True
        elif connection.communication_type == CommunicationType.DELEGATION:
            # Delegation requires trust
            return target.trust_level.value <= source.trust_level.value

        return False

    def _has_prompt_injection_defense(self, target: GraphNode) -> bool:
        """Check if target has prompt injection defenses."""
        # Check metadata for defense indicators
        metadata = target.metadata or {}

        # Look for defense keywords
        for key, value in metadata.items():
            if any(
                defense in str(key).lower() for defense in ["defense", "protection", "sanitize"]
            ):
                return True
            if any(
                defense in str(value).lower()
                for defense in self._defense_patterns["prompt_defense"]
            ):
                return True

        # High trust agents assumed to have better defenses
        if target.trust_level.value >= TrustLevel.SYSTEM.value:
            return True

        return False

    def _has_input_validation(self, target: GraphNode, connection: GraphEdge) -> bool:
        """Check if target validates inputs from this connection."""
        # Check connection metadata for validation
        if connection.metadata.get("validated", False):
            return True

        # Check target metadata for validation
        target_meta = target.metadata or {}
        if target_meta.get("input_validation", False):
            return True

        # Look for validation patterns
        for key, value in target_meta.items():
            if any(val in str(key).lower() for val in self._defense_patterns["input_validation"]):
                return True

        return False

    def _identify_infection_vector(
        self, source: GraphNode, target: GraphNode, connection: GraphEdge
    ) -> str:
        """Identify the specific infection vector used."""
        if connection.communication_type == CommunicationType.DIRECT:
            return InfectionVector.DIRECT_MESSAGE
        elif connection.communication_type == CommunicationType.BROADCAST:
            return InfectionVector.BROADCAST
        elif connection.communication_type == CommunicationType.CALLBACK:
            return InfectionVector.CALLBACK_RESULT
        elif connection.communication_type == CommunicationType.SHARED_MEMORY:
            return InfectionVector.SHARED_MEMORY
        elif connection.communication_type == CommunicationType.DELEGATION:
            return InfectionVector.DELEGATED_TASK
        else:
            # Check if infection through tool output
            if source.tool_count > 0:
                return InfectionVector.TOOL_OUTPUT
            return InfectionVector.DIRECT_MESSAGE

    def _calculate_infection_confidence(self, agent: GraphNode | None) -> float:
        """Calculate confidence that agent will be successfully infected."""
        if agent is None:
            return 0.5

        confidence = 1.0

        # Reduce confidence based on trust level
        trust_reduction = {
            TrustLevel.EXTERNAL: 0.0,
            TrustLevel.USER: 0.1,
            TrustLevel.INTERNAL: 0.2,
            TrustLevel.PRIVILEGED: 0.3,
            TrustLevel.SYSTEM: 0.5,
        }
        confidence -= trust_reduction.get(agent.trust_level, 0.2)

        # Reduce confidence if agent has defenses
        if agent.metadata.get("has_defenses", False):
            confidence -= 0.3

        return max(confidence, 0.1)

    def _identify_critical_agents(
        self, infection_graph: nx.DiGraph, topology: AgentTopology
    ) -> list[CriticalAgentAnalysis]:
        """Identify agents that are critical infection hubs."""
        critical = []

        for agent_id in infection_graph.nodes():
            # How many agents does this one infect?
            try:
                descendants = nx.descendants(infection_graph, agent_id)
            except Exception:
                descendants = set()

            if len(descendants) > 0:
                agent = topology.get_agent(agent_id)
                if agent:
                    risk_factors = []

                    # Identify risk factors
                    if agent.has_code_execution:
                        risk_factors.append("Has code execution capability")
                    if agent.has_external_access:
                        risk_factors.append("Has external network access")
                    if agent.allow_delegation:
                        risk_factors.append("Can delegate to other agents")
                    if agent.trust_level.value >= TrustLevel.PRIVILEGED.value:
                        risk_factors.append(f"High trust level: {agent.trust_level.name}")

                    critical.append(
                        CriticalAgentAnalysis(
                            agent_id=agent_id,
                            agent_name=agent.name,
                            direct_infections=len(list(infection_graph.successors(agent_id))),
                            total_descendants=len(descendants),
                            criticality_score=len(descendants) / max(len(topology.agents), 1),
                            recommendation=f"Harden {agent.name} - it can infect {len(descendants)} other agents",
                            risk_factors=risk_factors,
                        )
                    )

        # Sort by criticality
        critical.sort(key=lambda x: x.criticality_score, reverse=True)
        return critical

    def _generate_containment_strategy(
        self, infection_graph: nx.DiGraph, topology: AgentTopology
    ) -> list[ContainmentRecommendation]:
        """Generate recommendations to contain infection."""
        recommendations = []

        # Strategy 1: Cut critical edges
        # Find edges that if removed, reduce infection the most
        edge_criticality = []
        for edge in infection_graph.edges():
            source, target = edge
            try:
                descendants = len(nx.descendants(infection_graph, target))
            except Exception:
                descendants = 0

            if descendants > 0:
                edge_criticality.append((source, target, descendants))

        # Sort by criticality and take top edges
        edge_criticality.sort(key=lambda x: x[2], reverse=True)

        for source, target, descendants in edge_criticality[:3]:
            source_agent = topology.get_agent(source)
            target_agent = topology.get_agent(target)

            if source_agent and target_agent:
                recommendations.append(
                    ContainmentRecommendation(
                        strategy="isolate_connection",
                        priority=(
                            "critical"
                            if descendants > 5
                            else "high" if descendants > 2 else "medium"
                        ),
                        description=f"Isolate {source_agent.name} -> {target_agent.name} connection",
                        impact=f"Prevents {descendants} downstream infections",
                        implementation=f"Add input validation to {target_agent.name} for inputs from {source_agent.name}",
                        estimated_effort="low",
                        effectiveness_score=min(descendants / 10.0, 1.0),
                    )
                )

        # Strategy 2: Harden critical agents
        critical_agents = self._identify_critical_agents(infection_graph, topology)
        for critical in critical_agents[:3]:  # Top 3
            recommendations.append(
                ContainmentRecommendation(
                    strategy="harden_agent",
                    priority="critical" if critical.criticality_score > 0.5 else "high",
                    description=f"Harden {critical.agent_name}",
                    impact=f"Prevents {critical.total_descendants} cascade infections",
                    implementation="Add prompt injection defense, input validation, output sanitization",
                    estimated_effort="medium",
                    effectiveness_score=critical.criticality_score,
                )
            )

        # Strategy 3: Add monitoring at entry points
        entry_points = [n for n in topology.agents.values() if n.is_entry_point]
        if entry_points:
            recommendations.append(
                ContainmentRecommendation(
                    strategy="entry_point_monitoring",
                    priority="high",
                    description="Monitor entry point agents",
                    impact=f"Early detection at {len(entry_points)} entry points",
                    implementation="Deploy behavioral monitoring and anomaly detection on user-facing agents",
                    estimated_effort="medium",
                    effectiveness_score=0.8,
                )
            )

        # Strategy 4: Trust boundary enforcement
        trust_violations = []
        for edge in infection_graph.edges():
            source_agent = topology.get_agent(edge[0])
            target_agent = topology.get_agent(edge[1])
            if source_agent and target_agent:
                if source_agent.trust_level.value < target_agent.trust_level.value:
                    trust_violations.append((source_agent, target_agent))

        if trust_violations:
            recommendations.append(
                ContainmentRecommendation(
                    strategy="trust_boundary_enforcement",
                    priority="critical",
                    description=f"Enforce trust boundaries at {len(trust_violations)} violation points",
                    impact="Prevents privilege escalation attacks",
                    implementation="Add authentication and authorization checks at trust boundaries",
                    estimated_effort="high",
                    effectiveness_score=0.9,
                )
            )

        # Sort by effectiveness and priority
        priority_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        recommendations.sort(
            key=lambda x: (priority_order.get(x.priority, 3), -x.effectiveness_score)
        )

        return recommendations
