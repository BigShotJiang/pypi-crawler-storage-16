"""
Trust Boundary Analysis Module.

Provides trust level classification, zone detection, boundary crossing
detection, and privilege escalation analysis for multi-agent systems.
"""

from vantage_core.security.trust.boundaries import (
    BoundaryAnalyzer,
    BoundaryCrossing,
    EscalationPath,
)
from vantage_core.security.trust.classifier import (
    ClassificationEvidence,
    TrustClassification,
    TrustClassifier,
)
from vantage_core.security.trust.laundering import (
    LaunderingDetector,
    LaunderingPath,
)
from vantage_core.security.trust.zones import (
    TrustZone,
    ZoneConnection,
    ZoneDetector,
)

__all__ = [
    # Classifier
    "TrustClassifier",
    "TrustClassification",
    "ClassificationEvidence",
    # Zones
    "TrustZone",
    "ZoneDetector",
    "ZoneConnection",
    # Boundaries
    "BoundaryCrossing",
    "EscalationPath",
    "BoundaryAnalyzer",
    # Laundering
    "LaunderingPath",
    "LaunderingDetector",
]
