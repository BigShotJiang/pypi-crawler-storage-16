"""
Trust Boundary Visualization Data Generator (US-208).

Generates zone diagram data for frontend rendering including
agent positioning, violation indicators, and export formats.
"""

import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from vantage_core.security.models import Severity, TrustLevel
from vantage_core.security.topology.graph import AgentGraph, GraphNode
from vantage_core.security.trust.boundaries import (
    BoundaryAnalyzer,
    BoundaryCrossing,
)


class ExportFormat(str, Enum):
    """Supported export formats."""

    JSON = "json"
    SVG = "svg"
    PDF = "pdf"


@dataclass
class Position:
    """2D position for visualization."""

    x: float
    y: float

    def to_dict(self) -> dict[str, float]:
        return {"x": self.x, "y": self.y}


@dataclass
class Zone:
    """
    Represents a trust zone in the visualization.

    Contains zone boundaries, styling, and contained agents.
    """

    id: str
    name: str
    trust_level: TrustLevel
    color: str
    background_color: str
    border_style: str
    agents: list[str]
    position: Position
    width: float
    height: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "trust_level": self.trust_level.value,
            "color": self.color,
            "background_color": self.background_color,
            "border_style": self.border_style,
            "agents": self.agents,
            "position": self.position.to_dict(),
            "width": self.width,
            "height": self.height,
        }


@dataclass
class AgentPosition:
    """
    Position of an agent within the visualization.

    Includes position, styling, and metadata.
    """

    agent_id: str
    name: str
    zone_id: str
    trust_level: TrustLevel
    position: Position
    size: float = 40
    color: str = "#1976D2"
    border_color: str = "#0D47A1"
    has_findings: bool = False
    findings_severity: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "zone_id": self.zone_id,
            "trust_level": self.trust_level.value,
            "position": self.position.to_dict(),
            "size": self.size,
            "color": self.color,
            "border_color": self.border_color,
            "has_findings": self.has_findings,
            "findings_severity": self.findings_severity,
        }


@dataclass
class ViolationIndicator:
    """
    Visual indicator for a trust boundary violation.

    Contains styling and severity information.
    """

    id: str
    violation_type: str
    severity: Severity
    source_agent: str
    target_agent: str
    source_zone: str
    target_zone: str
    description: str
    recommendation: str
    color: str = "#D32F2F"
    line_style: str = "dashed"
    animated: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "violation_type": self.violation_type,
            "severity": self.severity.value,
            "source_agent": self.source_agent,
            "target_agent": self.target_agent,
            "source_zone": self.source_zone,
            "target_zone": self.target_zone,
            "description": self.description,
            "recommendation": self.recommendation,
            "color": self.color,
            "line_style": self.line_style,
            "animated": self.animated,
        }


@dataclass
class ZoneConnection:
    """
    Connection between agents across zones.

    Represents data flow between trust levels.
    """

    id: str
    source_agent: str
    target_agent: str
    source_zone: str
    target_zone: str
    data_sensitivity: str
    direction: str  # up, down, lateral
    is_violation: bool
    color: str = "#757575"
    thickness: float = 2

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "source_agent": self.source_agent,
            "target_agent": self.target_agent,
            "source_zone": self.source_zone,
            "target_zone": self.target_zone,
            "data_sensitivity": self.data_sensitivity,
            "direction": self.direction,
            "is_violation": self.is_violation,
            "color": self.color,
            "thickness": self.thickness,
        }


@dataclass
class ZoneDiagram:
    """
    Complete zone diagram for visualization.

    Contains all elements needed for frontend rendering.
    """

    zones: list[Zone]
    agents: list[AgentPosition]
    violations: list[ViolationIndicator]
    connections: list[ZoneConnection]
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "zones": [z.to_dict() for z in self.zones],
            "agents": [a.to_dict() for a in self.agents],
            "violations": [v.to_dict() for v in self.violations],
            "connections": [c.to_dict() for c in self.connections],
            "metadata": self.metadata,
        }


class TrustBoundaryVisualizer:
    """
    Generates trust boundary visualization data.

    Creates zone diagrams with agent positioning and violation
    indicators for frontend rendering with D3.js.
    """

    # Zone colors per UX design
    ZONE_COLORS = {
        TrustLevel.EXTERNAL: {
            "background": "#F5F5F5",
            "border": "#E0E0E0",
            "border_style": "dashed",
        },
        TrustLevel.USER: {
            "background": "#E3F2FD",
            "border": "#BBDEFB",
            "border_style": "solid",
        },
        TrustLevel.INTERNAL: {
            "background": "#E8F5E9",
            "border": "#C8E6C9",
            "border_style": "solid",
        },
        TrustLevel.PRIVILEGED: {
            "background": "#FFF3E0",
            "border": "#FFE0B2",
            "border_style": "double",
        },
        TrustLevel.SYSTEM: {
            "background": "#FFEBEE",
            "border": "#FFCDD2",
            "border_style": "double",
        },
    }

    # Severity colors
    SEVERITY_COLORS = {
        Severity.CRITICAL: "#D32F2F",
        Severity.HIGH: "#F57C00",
        Severity.MEDIUM: "#FBC02D",
        Severity.LOW: "#388E3C",
        Severity.INFO: "#757575",
    }

    # Sensitivity colors for data flow
    SENSITIVITY_COLORS = {
        "public": "#4CAF50",
        "internal": "#2196F3",
        "confidential": "#FF9800",
        "secret": "#F44336",
    }

    def __init__(
        self,
        width: float = 800,
        height: float = 600,
        padding: float = 40,
    ):
        """
        Initialize the visualizer.

        Args:
            width: Total diagram width
            height: Total diagram height
            padding: Padding around diagram
        """
        self.width = width
        self.height = height
        self.padding = padding

    def generate_zone_diagram(
        self,
        graph: AgentGraph,
        include_data_flows: bool = True,
    ) -> ZoneDiagram:
        """
        Generate complete zone diagram from agent graph.

        Args:
            graph: Agent topology graph
            include_data_flows: Whether to include data flow connections

        Returns:
            ZoneDiagram ready for rendering
        """
        # Analyze trust boundaries
        analyzer = BoundaryAnalyzer(graph)
        crossings = analyzer.find_crossings()

        # Group agents by trust level
        agents_by_level = self._group_agents_by_trust(graph)

        # Create zones
        zones = self._create_zones(agents_by_level)

        # Position agents within zones
        agents = self._position_agents(graph, agents_by_level, zones)

        # Create violation indicators
        violations = self._create_violation_indicators(crossings)

        # Create connections
        connections = []
        if include_data_flows:
            connections = self._create_connections(graph, crossings)

        # Build metadata
        stats = analyzer.get_boundary_statistics()
        metadata = {
            "total_zones": len(zones),
            "total_agents": len(agents),
            "total_violations": len(violations),
            "total_connections": len(connections),
            "boundary_statistics": stats,
        }

        return ZoneDiagram(
            zones=zones,
            agents=agents,
            violations=violations,
            connections=connections,
            metadata=metadata,
        )

    def get_violations(
        self,
        graph: AgentGraph,
        min_severity: Severity = Severity.LOW,
    ) -> list[ViolationIndicator]:
        """
        Get violation indicators from graph analysis.

        Args:
            graph: Agent topology graph
            min_severity: Minimum severity to include

        Returns:
            List of ViolationIndicator objects
        """
        analyzer = BoundaryAnalyzer(graph)
        crossings = analyzer.find_crossings()

        # Filter by severity
        filtered = [
            c
            for c in crossings
            if c.severity.value <= min_severity.value  # Lower value = higher severity
        ]

        return self._create_violation_indicators(filtered)

    def export(
        self,
        diagram: ZoneDiagram,
        format: ExportFormat | str,
    ) -> bytes:
        """
        Export zone diagram in specified format.

        Args:
            diagram: ZoneDiagram to export
            format: Export format

        Returns:
            Exported data as bytes
        """
        if isinstance(format, str):
            format = ExportFormat(format.lower())

        if format == ExportFormat.JSON:
            return json.dumps(diagram.to_dict(), indent=2).encode("utf-8")
        elif format == ExportFormat.SVG:
            return self._export_svg(diagram)
        elif format == ExportFormat.PDF:
            return self._export_pdf(diagram)
        else:
            raise ValueError(f"Unsupported format: {format}")

    def get_agent_details(
        self,
        graph: AgentGraph,
        agent_id: str,
    ) -> dict[str, Any] | None:
        """
        Get detailed information for an agent.

        Args:
            graph: Agent topology graph
            agent_id: Agent identifier

        Returns:
            Agent details dictionary or None
        """
        node = graph.get_node(agent_id)
        if not node:
            return None

        # Analyze exposure
        analyzer = BoundaryAnalyzer(graph)
        exposure = analyzer.analyze_agent_exposure(agent_id)

        return {
            "agent_id": agent_id,
            "name": node.name,
            "trust_level": node.trust_level.name,
            "trust_level_value": node.trust_level.value,
            "has_code_execution": node.has_code_execution,
            "tool_count": len(node.tools) if hasattr(node, "tools") else 0,
            "exposure": exposure,
        }

    def _group_agents_by_trust(
        self,
        graph: AgentGraph,
    ) -> dict[TrustLevel, list[GraphNode]]:
        """Group agents by their trust level."""
        groups: dict[TrustLevel, list[GraphNode]] = {}

        for node in graph.nodes:
            level = node.trust_level
            if level not in groups:
                groups[level] = []
            groups[level].append(node)

        return groups

    def _create_zones(
        self,
        agents_by_level: dict[TrustLevel, list[GraphNode]],
    ) -> list[Zone]:
        """Create zone elements for each trust level."""
        zones = []

        # Calculate zone dimensions
        available_height = self.height - (2 * self.padding)
        num_levels = len(agents_by_level)
        zone_height = available_height / max(num_levels, 1) if num_levels > 0 else available_height

        # Sort levels for top-to-bottom layout (external at top)
        sorted_levels = sorted(agents_by_level.keys(), key=lambda l: l.value)

        for i, level in enumerate(sorted_levels):
            agents = agents_by_level[level]
            colors = self.ZONE_COLORS.get(level, self.ZONE_COLORS[TrustLevel.INTERNAL])

            zone = Zone(
                id=f"zone-{level.name.lower()}",
                name=level.name,
                trust_level=level,
                color=colors["border"],
                background_color=colors["background"],
                border_style=colors["border_style"],
                agents=[a.id for a in agents],
                position=Position(
                    x=self.padding,
                    y=self.padding + (i * zone_height),
                ),
                width=self.width - (2 * self.padding),
                height=zone_height - 10,  # Small gap between zones
            )
            zones.append(zone)

        return zones

    def _position_agents(
        self,
        graph: AgentGraph,
        agents_by_level: dict[TrustLevel, list[GraphNode]],
        zones: list[Zone],
    ) -> list[AgentPosition]:
        """Position agents within their zones."""
        positioned = []

        # Create zone lookup
        zone_lookup = {z.trust_level: z for z in zones}

        for level, agents in agents_by_level.items():
            zone = zone_lookup.get(level)
            if not zone:
                continue

            # Calculate positions within zone
            num_agents = len(agents)
            if num_agents == 0:
                continue

            # Distribute agents horizontally within zone
            available_width = zone.width - 40
            spacing = available_width / max(num_agents, 1)

            for i, node in enumerate(agents):
                x = zone.position.x + 20 + (i * spacing) + (spacing / 2)
                y = zone.position.y + (zone.height / 2)

                # Determine agent color based on findings
                color = "#1976D2"
                border_color = "#0D47A1"
                has_findings = False
                findings_severity = None

                # Check for findings (mock - would come from scan results)
                if hasattr(node, "risk_score") and node.risk_score > 50:
                    has_findings = True
                    if node.risk_score > 80:
                        findings_severity = "critical"
                        border_color = self.SEVERITY_COLORS[Severity.CRITICAL]
                    elif node.risk_score > 60:
                        findings_severity = "high"
                        border_color = self.SEVERITY_COLORS[Severity.HIGH]
                    else:
                        findings_severity = "medium"
                        border_color = self.SEVERITY_COLORS[Severity.MEDIUM]

                positioned.append(
                    AgentPosition(
                        agent_id=node.id,
                        name=node.name,
                        zone_id=zone.id,
                        trust_level=level,
                        position=Position(x=x, y=y),
                        color=color,
                        border_color=border_color,
                        has_findings=has_findings,
                        findings_severity=findings_severity,
                    )
                )

        return positioned

    def _create_violation_indicators(
        self,
        crossings: list[BoundaryCrossing],
    ) -> list[ViolationIndicator]:
        """Create violation indicators from boundary crossings."""
        indicators = []

        for i, crossing in enumerate(crossings):
            # Determine violation type
            if crossing.is_elevation:
                violation_type = "privilege_escalation"
                description = f"Trust elevation from {crossing.source_trust.name} to {crossing.target_trust.name}"
            else:
                violation_type = "data_exposure"
                description = f"Potential data exposure from {crossing.source_trust.name} to {crossing.target_trust.name}"

            # Get severity color
            color = self.SEVERITY_COLORS.get(crossing.severity, "#757575")

            indicators.append(
                ViolationIndicator(
                    id=f"violation-{i}",
                    violation_type=violation_type,
                    severity=crossing.severity,
                    source_agent=crossing.source_agent,
                    target_agent=crossing.target_agent,
                    source_zone=f"zone-{crossing.source_trust.name.lower()}",
                    target_zone=f"zone-{crossing.target_trust.name.lower()}",
                    description=description,
                    recommendation=crossing.recommendation,
                    color=color,
                    line_style=(
                        "dashed"
                        if crossing.severity in [Severity.CRITICAL, Severity.HIGH]
                        else "solid"
                    ),
                    animated=crossing.severity == Severity.CRITICAL,
                )
            )

        return indicators

    def _create_connections(
        self,
        graph: AgentGraph,
        crossings: list[BoundaryCrossing],
    ) -> list[ZoneConnection]:
        """Create zone connection elements."""
        connections = []

        # Create set of violation edges for quick lookup
        violation_edges = {(c.source_agent, c.target_agent) for c in crossings}

        for i, edge in enumerate(graph.edges):
            source_node = graph.get_node(edge.source_id)
            target_node = graph.get_node(edge.target_id)

            if not source_node or not target_node:
                continue

            # Determine direction
            diff = target_node.trust_level.value - source_node.trust_level.value
            if diff > 0:
                direction = "down"  # Going to higher trust
            elif diff < 0:
                direction = "up"  # Going to lower trust
            else:
                direction = "lateral"

            # Check if this is a violation
            is_violation = (edge.source_id, edge.target_id) in violation_edges

            # Get color based on sensitivity
            color = self.SENSITIVITY_COLORS.get(edge.data_sensitivity, "#757575")

            # Thicker lines for more frequent connections
            thickness = 2.0

            connections.append(
                ZoneConnection(
                    id=f"connection-{i}",
                    source_agent=edge.source_id,
                    target_agent=edge.target_id,
                    source_zone=f"zone-{source_node.trust_level.name.lower()}",
                    target_zone=f"zone-{target_node.trust_level.name.lower()}",
                    data_sensitivity=edge.data_sensitivity,
                    direction=direction,
                    is_violation=is_violation,
                    color=color if not is_violation else "#D32F2F",
                    thickness=thickness,
                )
            )

        return connections

    def _export_svg(self, diagram: ZoneDiagram) -> bytes:
        """Export diagram as SVG."""
        svg_elements = []

        # SVG header
        svg_elements.append(
            f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'width="{self.width}" height="{self.height}" '
            f'viewBox="0 0 {self.width} {self.height}">'
        )

        # Add styles
        svg_elements.append(
            """
        <defs>
            <style>
                .zone { stroke-width: 2; }
                .agent { stroke-width: 2; }
                .violation { stroke-dasharray: 5,5; animation: pulse 1s infinite; }
                .connection { fill: none; }
                @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
            </style>
        </defs>
        """
        )

        # Draw zones
        for zone in diagram.zones:
            style = f"fill: {zone.background_color}; stroke: {zone.color};"
            if zone.border_style == "dashed":
                style += " stroke-dasharray: 5,5;"
            elif zone.border_style == "double":
                style += " stroke-width: 4;"

            svg_elements.append(
                f'<rect class="zone" x="{zone.position.x}" y="{zone.position.y}" '
                f'width="{zone.width}" height="{zone.height}" rx="8" '
                f'style="{style}" />'
            )
            # Zone label
            svg_elements.append(
                f'<text x="{zone.position.x + 10}" y="{zone.position.y + 20}" '
                f'font-size="12" font-weight="bold">{zone.name}</text>'
            )

        # Draw connections
        for conn in diagram.connections:
            # Find agent positions
            source_pos = next(
                (a.position for a in diagram.agents if a.agent_id == conn.source_agent),
                None,
            )
            target_pos = next(
                (a.position for a in diagram.agents if a.agent_id == conn.target_agent),
                None,
            )

            if source_pos and target_pos:
                classes = "connection"
                if conn.is_violation:
                    classes += " violation"

                svg_elements.append(
                    f'<line class="{classes}" '
                    f'x1="{source_pos.x}" y1="{source_pos.y}" '
                    f'x2="{target_pos.x}" y2="{target_pos.y}" '
                    f'stroke="{conn.color}" stroke-width="{conn.thickness}" />'
                )

        # Draw agents
        for agent in diagram.agents:
            svg_elements.append(
                f'<circle class="agent" cx="{agent.position.x}" cy="{agent.position.y}" '
                f'r="{agent.size / 2}" '
                f'fill="{agent.color}" stroke="{agent.border_color}" />'
            )
            # Agent label
            svg_elements.append(
                f'<text x="{agent.position.x}" y="{agent.position.y + agent.size}" '
                f'text-anchor="middle" font-size="10">{agent.name}</text>'
            )

        svg_elements.append("</svg>")
        return "\n".join(svg_elements).encode("utf-8")

    def _export_pdf(self, diagram: ZoneDiagram) -> bytes:
        """Export diagram as PDF (requires WeasyPrint)."""
        # Generate SVG first
        svg_content = self._export_svg(diagram)

        # Wrap in HTML
        html = f"""<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ margin: 0; padding: 20px; }}
        svg {{ max-width: 100%; height: auto; }}
    </style>
</head>
<body>
    {svg_content.decode('utf-8')}
</body>
</html>"""

        try:
            from weasyprint import HTML

            return HTML(string=html).write_pdf()
        except ImportError:
            return (
                b"PDF generation requires WeasyPrint. Install with: pip install weasyprint\n\n"
                + svg_content
            )


def generate_trust_boundary_diagram(
    graph: AgentGraph,
    format: str = "json",
) -> bytes:
    """
    Convenience function to generate trust boundary diagram.

    Args:
        graph: Agent topology graph
        format: Export format (json, svg, pdf)

    Returns:
        Diagram data as bytes
    """
    visualizer = TrustBoundaryVisualizer()
    diagram = visualizer.generate_zone_diagram(graph)
    return visualizer.export(diagram, format)
