"""
License Management Commands

Commands for managing Vantage licensing and tiers.
"""

from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()

license_app = typer.Typer(
    name="license",
    help="License management and tier information",
)


@license_app.command("status")
def show_status():
    """
    Show current license status and tier.

    Displays your current tier, available features, and usage limits.

    Examples:
        vantage license status
    """
    from vantage_core.licensing import (
        TierFeature,
        get_license_manager,
    )

    manager = get_license_manager()
    info = manager.get_license_info()

    # Header
    tier_colors = {
        "community": "blue",
        "professional": "green",
        "enterprise": "yellow",
    }
    tier_color = tier_colors.get(info.tier.value, "white")

    console.print(
        Panel.fit(
            f"[bold {tier_color}]{info.tier.value.upper()} TIER[/bold {tier_color}]",
            border_style=tier_color,
        )
    )

    # License info
    console.print(f"\n[bold]Organization:[/bold] {info.organization}")
    if info.email:
        console.print(f"[bold]Email:[/bold] {info.email}")

    if info.is_trial:
        console.print(
            f"[bold]Trial:[/bold] [yellow]{info.trial_days_remaining} days remaining[/yellow]"
        )

    if info.valid_until:
        console.print(f"[bold]Valid Until:[/bold] {info.valid_until[:10]}")

    # Usage
    usage = manager.get_daily_usage()
    limits = info.limits

    console.print("\n[bold cyan]Today's Usage[/bold cyan]")
    console.print(
        f"  Scans: {usage['scan_count']}/{limits.scans_per_day if limits.scans_per_day > 0 else 'Unlimited'}"
    )
    console.print(
        f"  Payloads: {usage['payloads_used']}/{limits.payload_count if limits.payload_count > 0 else 'Unlimited'}"
    )

    # Features
    console.print(f"\n[bold cyan]Available Features ({len(info.features)})[/bold cyan]")

    feature_groups = {
        "Payloads": [
            TierFeature.BASIC_PAYLOADS,
            TierFeature.FULL_PAYLOADS,
            TierFeature.CUSTOM_PAYLOADS,
        ],
        "Testing": [
            TierFeature.MOCK_TESTING,
            TierFeature.LIVE_LLM_TESTING,
            TierFeature.MULTI_MODEL_TESTING,
        ],
        "Analysis": [
            TierFeature.BASIC_SCANNING,
            TierFeature.ADVANCED_SCANNING,
            TierFeature.ML_DETECTION,
            TierFeature.EFFECTIVENESS_SCORES,
            TierFeature.FRAMEWORK_STATS,
        ],
        "Reports": [
            TierFeature.CLI_REPORTS,
            TierFeature.JSON_EXPORT,
            TierFeature.SARIF_EXPORT,
            TierFeature.COMPLIANCE_REPORTS,
            TierFeature.PDF_REPORTS,
        ],
        "Dashboard": [
            TierFeature.BASIC_DASHBOARD,
            TierFeature.TEAM_DASHBOARD,
            TierFeature.REMEDIATION_TRACKING,
            TierFeature.HISTORICAL_TRENDS,
        ],
    }

    for group_name, features in feature_groups.items():
        available = [f for f in features if f in info.features]
        if available:
            feature_str = ", ".join(f.value.replace("_", " ").title() for f in available)
            console.print(f"  [dim]{group_name}:[/dim] {feature_str}")


@license_app.command("activate")
def activate_license(
    license_key: str = typer.Argument(..., help="License key to activate"),
):
    """
    Activate a license key.

    License keys are provided when you purchase a Professional or Enterprise subscription.

    Examples:
        vantage license activate PRO-MYORG-abc12345
        vantage license activate ENT-COMPANY-xyz98765
    """
    from vantage_core.licensing import get_license_manager

    manager = get_license_manager()
    result = manager.activate_license(license_key)

    if result.is_valid:
        console.print("[green][OK] License activated successfully![/green]")
        console.print(f"  Tier: [bold]{result.tier.value.upper()}[/bold]")
        if result.license_info:
            console.print(f"  Organization: {result.license_info.organization}")
            console.print(f"  Valid until: {result.license_info.valid_until[:10]}")
    else:
        console.print("[red][X] License activation failed[/red]")
        console.print(f"  Error: {result.message}")
        raise typer.Exit(1)


@license_app.command("trial")
def start_trial(
    tier: str = typer.Option(
        "professional", "--tier", "-t", help="Tier to trial: professional, enterprise"
    ),
    days: int = typer.Option(14, "--days", "-d", help="Trial duration in days"),
):
    """
    Start a free trial.

    Try Professional or Enterprise features for free.

    Examples:
        vantage license trial
        vantage license trial --tier enterprise --days 30
    """
    from vantage_core.licensing import Tier, get_license_manager

    # Parse tier
    try:
        trial_tier = Tier(tier.lower())
    except ValueError:
        console.print(f"[red]Invalid tier: {tier}[/red]")
        console.print("Valid tiers: professional, enterprise")
        raise typer.Exit(1)

    if trial_tier == Tier.COMMUNITY:
        console.print("[yellow]Community tier is free, no trial needed![/yellow]")
        return

    manager = get_license_manager()
    trial_info = manager.start_trial(trial_tier, days)

    console.print("[green][OK] Trial started![/green]")
    console.print(f"  Tier: [bold]{trial_info.tier.value.upper()}[/bold]")
    console.print(f"  Duration: {days} days")
    console.print(f"  Expires: {trial_info.valid_until[:10]}")
    console.print("")
    console.print("[dim]To purchase a full license, visit https://vantage.dev/pricing[/dim]")


@license_app.command("compare")
def compare_tiers():
    """
    Compare tier features and pricing.

    Shows a side-by-side comparison of all tiers.

    Examples:
        vantage license compare
    """
    from vantage_core.licensing import (
        TIER_FEATURES,
        TIER_LIMITS,
        Tier,
        TierFeature,
    )

    console.print(
        Panel.fit(
            "[bold]Vantage Tier Comparison[/bold]",
            border_style="blue",
        )
    )

    # Feature comparison table
    table = Table(title="Features")
    table.add_column("Feature", style="cyan")
    table.add_column("Community", justify="center")
    table.add_column("Professional", justify="center")
    table.add_column("Enterprise", justify="center")

    # Group features for display
    feature_display = [
        (
            "Payloads",
            [
                (TierFeature.BASIC_PAYLOADS, "Basic Payloads (33)"),
                (TierFeature.FULL_PAYLOADS, "Full Database (206+)"),
                (TierFeature.CUSTOM_PAYLOADS, "Custom Payloads"),
            ],
        ),
        (
            "Testing",
            [
                (TierFeature.MOCK_TESTING, "Mock Testing"),
                (TierFeature.LIVE_LLM_TESTING, "Live LLM Testing"),
                (TierFeature.MULTI_MODEL_TESTING, "Multi-Model Testing"),
            ],
        ),
        (
            "Analysis",
            [
                (TierFeature.BASIC_SCANNING, "Basic Scanning"),
                (TierFeature.ADVANCED_SCANNING, "Advanced Scanning"),
                (TierFeature.ML_DETECTION, "ML Detection"),
                (TierFeature.EFFECTIVENESS_SCORES, "Effectiveness Scores"),
            ],
        ),
        (
            "Reports",
            [
                (TierFeature.CLI_REPORTS, "CLI Reports"),
                (TierFeature.JSON_EXPORT, "JSON Export"),
                (TierFeature.COMPLIANCE_REPORTS, "Compliance Reports"),
                (TierFeature.PDF_REPORTS, "PDF Reports"),
            ],
        ),
        (
            "Dashboard",
            [
                (TierFeature.BASIC_DASHBOARD, "Basic Dashboard"),
                (TierFeature.TEAM_DASHBOARD, "Team Dashboard"),
                (TierFeature.REMEDIATION_TRACKING, "Remediation Tracking"),
            ],
        ),
    ]

    for group_name, features in feature_display:
        table.add_row(f"[bold]{group_name}[/bold]", "", "", "", style="dim")
        for feature, display_name in features:
            com = (
                "[green][OK][/green]"
                if feature in TIER_FEATURES[Tier.COMMUNITY]
                else "[dim]-[/dim]"
            )
            pro = (
                "[green][OK][/green]"
                if feature in TIER_FEATURES[Tier.PROFESSIONAL]
                else "[dim]-[/dim]"
            )
            ent = (
                "[green][OK][/green]"
                if feature in TIER_FEATURES[Tier.ENTERPRISE]
                else "[dim]-[/dim]"
            )
            table.add_row(f"  {display_name}", com, pro, ent)

    console.print(table)

    # Limits table
    limits_table = Table(title="Limits")
    limits_table.add_column("Limit", style="cyan")
    limits_table.add_column("Community", justify="center")
    limits_table.add_column("Professional", justify="center")
    limits_table.add_column("Enterprise", justify="center")

    limits_display = [
        ("payload_count", "Payloads"),
        ("scans_per_day", "Scans/Day"),
        ("agents_per_scan", "Agents/Scan"),
        ("history_retention_days", "History (Days)"),
        ("team_members", "Team Members"),
        ("projects", "Projects"),
    ]

    for limit_key, display_name in limits_display:
        com = TIER_LIMITS[Tier.COMMUNITY]
        pro = TIER_LIMITS[Tier.PROFESSIONAL]
        ent = TIER_LIMITS[Tier.ENTERPRISE]

        com_val = getattr(com, limit_key)
        pro_val = getattr(pro, limit_key)
        ent_val = getattr(ent, limit_key)

        com_str = str(com_val) if com_val > 0 else "N/A"
        pro_str = str(pro_val) if pro_val > 0 else "Unlimited"
        ent_str = "Unlimited" if ent_val < 0 else str(ent_val)

        limits_table.add_row(display_name, com_str, pro_str, ent_str)

    console.print(limits_table)

    # Pricing
    console.print("\n[bold]Pricing[/bold]")
    console.print("  [blue]Community[/blue]: Free forever")
    console.print("  [green]Professional[/green]: $49/month or $490/year")
    console.print("  [yellow]Enterprise[/yellow]: Contact sales")
    console.print("")
    console.print("[dim]Visit https://vantage.dev/pricing for more information[/dim]")


@license_app.command("payloads")
def show_payloads(
    category: str = typer.Option("", "--category", "-c", help="Filter by category"),
    show_all: bool = typer.Option(False, "--all", "-a", help="Show all payloads (respects tier)"),
):
    """
    Show available payloads for your tier.

    Displays payloads you can access based on your license tier.

    Examples:
        vantage license payloads
        vantage license payloads --category jailbreak
        vantage license payloads --all
    """
    from vantage_core.licensing import (
        Tier,
        TieredPayloadDatabase,
        get_current_tier,
    )

    db = TieredPayloadDatabase()
    tier = get_current_tier()

    if category:
        payloads = db.get_by_category(category)
    else:
        payloads = db.get_payloads()

    stats = db.get_statistics()

    console.print(
        Panel.fit(
            f"[bold blue]Available Payloads ({tier.value.upper()} Tier)[/bold blue]",
            border_style="blue",
        )
    )

    console.print(f"\n[bold]Total Payloads:[/bold] {stats['total']}")
    console.print(f"[bold]Categories:[/bold] {stats['categories']}")

    if tier == Tier.COMMUNITY:
        console.print(
            f"\n[yellow]Upgrade to Professional for {206 - 33} additional payloads[/yellow]"
        )

    # Category breakdown
    console.print("\n[bold]By Category:[/bold]")
    for cat, count in sorted(stats["by_category"].items()):
        console.print(f"  {cat}: {count}")

    if show_all:
        console.print("\n[bold]Payloads:[/bold]")
        table = Table()
        table.add_column("ID", style="dim", width=12)
        table.add_column("Name", width=30)
        table.add_column("Category", width=20)
        table.add_column("Severity", width=10)

        for p in payloads[:50]:  # Limit display
            severity_style = {
                "critical": "red bold",
                "high": "red",
                "medium": "yellow",
                "low": "green",
            }.get(p.severity, "white")

            table.add_row(
                p.id[:12],
                p.name[:30],
                p.category,
                f"[{severity_style}]{p.severity}[/{severity_style}]",
            )

        console.print(table)

        if len(payloads) > 50:
            console.print(f"\n[dim]Showing 50 of {len(payloads)} payloads[/dim]")


@license_app.command("deactivate")
def deactivate_license():
    """
    Deactivate current license.

    Reverts to Community tier.

    Examples:
        vantage license deactivate
    """
    from vantage_core.licensing import get_license_manager

    confirm = typer.confirm("Are you sure you want to deactivate your license?")
    if not confirm:
        console.print("[yellow]Cancelled[/yellow]")
        return

    manager = get_license_manager()

    # Remove license file
    if manager.license_file.exists():
        manager.license_file.unlink()

    manager.clear_cache()

    console.print("[green][OK] License deactivated[/green]")
    console.print("You are now using the Community tier.")


@license_app.command("export")
def export_license(
    output: Path = typer.Option("license.json", "--output", "-o", help="Output file"),
):
    """
    Export license information.

    Exports license details for backup or transfer.

    Examples:
        vantage license export
        vantage license export --output my-license.json
    """
    import json

    from vantage_core.licensing import get_license_manager

    manager = get_license_manager()
    info = manager.get_license_info()

    data = info.to_dict()

    with open(output, "w") as f:
        json.dump(data, f, indent=2)

    console.print(f"[green][OK] License exported to {output}[/green]")


@license_app.command("features")
def check_features(
    feature: str = typer.Argument("", help="Feature to check (leave empty to list all)"),
):
    """
    Check feature availability.

    Lists available features or checks a specific feature.

    Examples:
        vantage license features
        vantage license features live_llm_testing
    """
    from vantage_core.licensing import (
        TierFeature,
        get_license_manager,
        get_minimum_tier_for_feature,
    )

    manager = get_license_manager()
    info = manager.get_license_info()

    if feature:
        # Check specific feature
        try:
            feat = TierFeature(feature)
        except ValueError:
            console.print(f"[red]Unknown feature: {feature}[/red]")
            console.print(f"Valid features: {', '.join(f.value for f in TierFeature)}")
            raise typer.Exit(1)

        is_available = feat in info.features
        min_tier = get_minimum_tier_for_feature(feat)

        if is_available:
            console.print(
                f"[green][OK] {feature} is available in your {info.tier.value} tier[/green]"
            )
        else:
            console.print(f"[red][X] {feature} requires {min_tier.value} tier[/red]")
            console.print("  Upgrade at https://vantage.dev/pricing")
    else:
        # List all features
        console.print(
            Panel.fit(
                f"[bold]Features for {info.tier.value.upper()} Tier[/bold]",
                border_style="blue",
            )
        )

        table = Table()
        table.add_column("Feature", style="cyan")
        table.add_column("Available", justify="center")
        table.add_column("Min Tier", justify="center")

        for feat in TierFeature:
            is_available = feat in info.features
            min_tier = get_minimum_tier_for_feature(feat)

            available_str = "[green][OK][/green]" if is_available else "[dim]-[/dim]"
            min_tier_str = min_tier.value

            table.add_row(feat.value, available_str, min_tier_str)

        console.print(table)
