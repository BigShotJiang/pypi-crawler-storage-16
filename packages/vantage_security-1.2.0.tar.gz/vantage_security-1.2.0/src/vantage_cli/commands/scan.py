"""Codebase scanning commands for Vantage CLI.

This module provides automatic agent detection from source code including:
- Multi-framework detection (17+ frameworks)
- Connection inference
- System extraction
- Health check integration
"""

from __future__ import annotations

import json
from pathlib import Path

import typer

from vantage_cli.output import get_console

scan_app = typer.Typer(
    name="scan",
    help="Scan codebases for agent definitions.",
    no_args_is_help=True,
)


@scan_app.command("directory")
def scan_directory(
    directory: Path = typer.Argument(
        ...,
        help="Path to directory containing agent code",
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output JSON file path for extracted system",
    ),
    html: bool = typer.Option(
        False,
        "--html",
        help="Generate HTML executive report",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed output",
    ),
    run_healthcheck: bool = typer.Option(
        True,
        "--healthcheck/--no-healthcheck",
        help="Run health check after scanning",
    ),
    format: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
):
    """Scan a codebase to auto-detect agent systems.

    [DEPRECATED] This command is deprecated and will be removed in v2.0.
    Please use 'vantage security scan' instead.

    This command now internally redirects to 'vantage security scan'.
    """
    from vantage_cli.commands.security import scan as security_scan
    
    # Map legacy arguments to new command arguments
    # 'html' flag implies format='html'
    target_format = "html" if html else format
    
    # If html flag is set but no output specified, default to vantage_report.html
    target_output = output
    if html and not output:
        target_output = Path("vantage_report.html")

    # Call the new security scanner
    # Note: We pass defaults for new flags like no_simulation etc.
    security_scan(
        path=directory,
        format=target_format,
        output=target_output,
        quiet=not verbose,
        # Legacy scan didn't do simulation/ML by default, but new one does.
        # To match legacy behavior roughly, we might want to disable advanced features?
        # No, "One CLI" means we should give them the full power now.
        no_simulation=False,
        no_remediation=False,
        no_ml=False,
        fail_on_findings=False
    )


def _system_to_dict(system) -> dict:
    """Convert AgentSystem to dictionary for JSON serialization."""
    return {
        "name": system.name,
        "description": system.description,
        "version": system.version,
        "agents": [
            {
                "id": agent.id,
                "name": agent.name,
                "description": agent.description,
                "model": agent.model,
                "temperature": agent.temperature,
                "max_tokens": agent.max_tokens,
                "prompt": {"content": agent.prompt.content},
            }
            for agent in system.agents.values()
        ],
        "topology": {
            "entry_points": system.topology.entry_points,
            "exit_points": system.topology.exit_points,
            "connections": [
                {
                    "source": conn.source,
                    "target": conn.target,
                    "condition": conn.condition,
                    "data_passed": conn.data_passed,
                }
                for conn in system.topology.connections
            ],
        },
        "metadata": system.metadata,
    }


def _run_quick_healthcheck(console, system) -> None:
    """Run quick health check on detected system."""
    from vantage_core.analysis.cost_estimator import CostEstimator
    from vantage_core.analysis.failure_taxonomy import MASTFailureDetector

    console.print()
    console.print("=" * 60)
    console.print("[bold]Running Health Check on Detected System[/bold]")
    console.print("=" * 60)

    # MAST Failure Detection
    detector = MASTFailureDetector(risk_threshold=0.3)
    failure_risks = detector.detect_failure_risks(system)

    if failure_risks:
        critical = [r for r in failure_risks if r.risk_level == "critical"]
        high = [r for r in failure_risks if r.risk_level == "high"]

        if critical:
            console.error(f"{len(critical)} CRITICAL failure risks")
        if high:
            console.warning(f"{len(high)} high-risk failure modes")

        console.print_subheader("Top Issues")
        for risk in failure_risks[:3]:
            theme = console.theme
            color = theme.get_risk_color(risk.risk_level)
            console.print(
                f"  [{color}]{risk.failure_mode.code}: {risk.failure_mode.name}[/{color}]"
            )
            console.print(f"    [{theme.success}]-> {risk.recommendation}[/{theme.success}]")
    else:
        console.success("No significant failure risks detected!")

    # Cascade Risk
    cascade = detector.calculate_cascade_risk(system)
    if cascade.cascade_score >= 50:
        console.warning(f"Cascade Risk: {cascade.cascade_score:.0f}/100")

    # Cost
    estimator = CostEstimator()
    cost = estimator.estimate_system_cost(system)
    console.print(
        f"\n[bold]Cost Estimate:[/bold] ${cost.monthly_cost_1000_runs:.2f}/month (1K runs)"
    )

    # Overall Score
    failure_penalty = min(len(failure_risks) * 5, 40)
    cascade_penalty = cascade.cascade_score * 0.3
    health_score = max(100 - failure_penalty - cascade_penalty, 0)

    theme = console.theme
    if health_score >= 80:
        color = theme.success
    elif health_score >= 60:
        color = theme.warning
    else:
        color = theme.error

    console.print(f"\n[bold]Health Score: [{color}]{health_score:.0f}/100[/{color}][/bold]")


@scan_app.command("frameworks")
def list_frameworks():
    """List all supported frameworks for agent detection.

    Shows detection capabilities for each framework.
    """
    console = get_console()

    console.print_header("Supported Frameworks for Auto-Detection")

    framework_info = [
        ("CrewAI", "full", "Agents, Tasks, Crews, Flows"),
        ("LangChain", "full", "Chains, Agents, Tools"),
        ("LangGraph", "full", "StateGraphs, Nodes, Edges"),
        ("AutoGen", "full", "Agents, GroupChat, Workflows"),
        ("LlamaIndex", "full", "Agents, Tools, Workflows"),
        ("Semantic Kernel", "full", "Plugins, Functions, Agents"),
        ("DSPy", "full", "Modules, Signatures"),
        ("SmolaGents", "full", "HfAgents, Tools"),
        ("PydanticAI", "full", "Agents, Tools"),
        ("MetaGPT", "partial", "Roles, Actions"),
        ("Agno", "full", "Agents, Tools"),
        ("Google ADK", "full", "Agents, Tools"),
        ("OpenAI Swarm", "full", "Agents, Handoffs"),
        ("BrowserUse", "partial", "Browser Agents"),
        ("OpenHands", "partial", "CodeAct Agents"),
        ("Skyvern", "partial", "Browser Workflows"),
        ("Dify", "partial", "YAML Workflows"),
    ]

    table = console.create_table(
        columns=["Framework", "Support", "Detects"],
    )

    for name, support, detects in framework_info:
        support_style = "[green]Full[/green]" if support == "full" else "[yellow]Partial[/yellow]"
        table.add_row(name, support_style, detects)

    console.print(table)

    console.print()
    console.info("To scan a project:")
    console.print("  vantage scan directory ./my-project")
