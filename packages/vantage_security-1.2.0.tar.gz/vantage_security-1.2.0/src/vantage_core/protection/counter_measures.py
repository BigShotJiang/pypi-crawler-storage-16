"""
Counter-Intelligence Module.

Implements aggressive defense strategies:
1. Constant-Time Responses (Anti-Timing Analysis)
2. Canary Watermarking (Leak Attribution)
"""

import logging
import random
import time
import uuid

logger = logging.getLogger(__name__)


class CounterMeasure:
    """Active counter-intelligence defenses."""

    def __init__(self, target_latency_ms: int = 1500):
        self.target_latency_ms = target_latency_ms

    def apply_constant_time(self, start_time: float):
        """
        Sleeps to normalize request duration, preventing timing side-channel attacks.

        If a request is blocked instantly (10ms), an attacker knows it hit a filter.
        If we sleep to match the average LLM latency (e.g. 1.5s), they can't tell.
        """
        elapsed_ms = (time.time() - start_time) * 1000
        remaining_ms = self.target_latency_ms - elapsed_ms

        # Add jitter to vantage real LLM variance (+/- 200ms)
        jitter = random.randint(-200, 200)
        target_sleep = max(0, remaining_ms + jitter) / 1000.0

        if target_sleep > 0:
            logger.debug(f"CounterMeasure: Sleeping {target_sleep:.2f}s to mask timing")
            time.sleep(target_sleep)

    def watermark_text(self, text: str, agent_id: str) -> str:
        """
        Injects an invisible Canary Token into the text.

        Uses Zero-Width Space (U+200B) encoding to hide a UUID.
        If this text leaks, we can decode the UUID to find the source.
        """
        token = str(uuid.uuid4())
        # Convert UUID to binary string
        binary = "".join(format(ord(c), "08b") for c in token)

        # Map 0 -> Zero Width Space (U+200B)
        # Map 1 -> Zero Width Non-Joiner (U+200C)
        invisible_chars = binary.replace("0", "\u200b").replace("1", "\u200c")

        # Append to text (invisible to humans)
        return text + invisible_chars

    @staticmethod
    def decode_watermark(text: str) -> str | None:
        """Extract watermark from text."""
        binary = ""
        for char in text:
            if char == "\u200b":
                binary += "0"
            elif char == "\u200c":
                binary += "1"

        if not binary or len(binary) % 8 != 0:
            return None

        try:
            # Convert binary back to string
            chars = []
            for i in range(0, len(binary), 8):
                byte = binary[i : i + 8]
                chars.append(chr(int(byte, 2)))
            return "".join(chars)
        except Exception:
            return None
