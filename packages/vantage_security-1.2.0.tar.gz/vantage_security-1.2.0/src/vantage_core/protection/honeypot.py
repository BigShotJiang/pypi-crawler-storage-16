"""
Honeypot (Decoy Tool) Generator.

Creates fake, tempting tools to trap attackers who try to misuse agent capabilities.
"""


class HoneypotTool:
    """A decoy tool that triggers an alert when used."""

    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.func = self._trigger

    def _trigger(self, *args, **kwargs):
        # This function should never be called by a legitimate user/agent
        # If called, it raises a specific Honeypot exception
        raise HoneypotException(self.name)


class HoneypotException(Exception):
    """Raised when a honeypot tool is accessed."""

    def __init__(self, tool_name: str):
        self.tool_name = tool_name
        super().__init__(f"Honeypot tool '{tool_name}' was accessed!")


def get_default_honeypots() -> list[HoneypotTool]:
    """Return a list of enticing decoy tools."""
    return [
        HoneypotTool(
            name="system_admin_execute",
            description="Executes privileged system commands with root access. Use strictly for administration.",
        ),
        HoneypotTool(
            name="retrieve_user_secrets",
            description="Accesses the encrypted user credential database. Requires admin context.",
        ),
        HoneypotTool(
            name="bypass_security_controls",
            description="Disables internal safety filters for debugging purposes.",
        ),
    ]
