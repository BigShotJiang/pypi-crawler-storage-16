from pathlib import Path
from vantage_core.models import DetectedAgent, Framework, ScanResult
from vantage_core.scanners.base import BaseScanner
from vantage_core.graph.builder import CPGBuilder
from vantage_core.graph.query import CPGQuery

class CrewAIGraphScanner(BaseScanner):
    """Next-generation Graph-based Scanner for CrewAI."""
    
    framework_name = "CrewAI"

    def scan_file(self, path: Path) -> ScanResult:
        with open(path, "r", encoding="utf-8") as f:
            source = f.read()

        # Phase 1 & 2: Ingestion & Graph Construction
        builder = CPGBuilder()
        graph = builder.build(source, str(path))
        
        # Phase 3: Query
        query = CPGQuery(graph)
        agents = []
        
        # Strategy 1: Find @agent decorators
        agent_methods = query.find_methods_with_decorator("agent")
        
        for method_id, method_node in agent_methods:
            # Inside this method, find "Agent(...)" call
            # We traverse the graph structure starting from method_id
            # This requires graph traversal which Query engine should facilitate, 
            # but for now we search globally and check containment (implied by file/scope).
            
            # Simple heuristic: Look for any "Agent" call where path/scope matches? 
            # Or assume the graph built represents this file only (it does).
            
            calls = query.find_calls_by_name("Agent")
            # Filter calls contained in this method
            calls = [(cid, cnode) for cid, cnode in calls if query.is_ancestor(method_id, cid)]
            
            for call_id, call_node in calls:
                # Resolve args
                name = query.resolve_argument(call_id, "name") or method_node.data.get('name')
                role = query.resolve_argument(call_id, "role")
                goal = query.resolve_argument(call_id, "goal")
                llm_info = query.resolve_argument(call_id, "llm")
                
                # Check for config-based initialization
                config = query.resolve_argument(call_id, "config")
                
                metadata = {}
                if llm_info and isinstance(llm_info, dict):
                     metadata.update({
                         "llm_provider": llm_info.get("name"),
                         "llm_model": llm_info.get("args", {}).get("model")
                     })

                if not role and not name and not config:
                    continue
                    
                agent = DetectedAgent(
                    id=self._make_id(name or role or "agent"),
                    name=name or role or "agent",
                    framework=Framework.CREWAI,
                    file_path=str(path),
                    line_number=call_node.ast_node.lineno,
                    system_prompt=f"Role: {role}\nGoal: {goal}",
                    metadata=metadata
                )
                agents.append(agent)
                
        return ScanResult(
            agents=agents,
            connections=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=[]
        )
