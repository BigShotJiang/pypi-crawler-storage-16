"""Scanner for Dify visual builder exports.

Detects agents from Dify YAML/JSON export format including chatflows and workflows.
"""

from __future__ import annotations

import ast
from pathlib import Path
from typing import Any

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult
from vantage_core.scanners.mixins import ASTExtractionMixin, ConfigFileMixin


class DifyScanner(BaseScanner, ASTExtractionMixin, ConfigFileMixin):
    """Scanner for Dify visual builder exports.

    Detects:
    - Chatflow configurations
    - Workflow configurations
    - Agent nodes and their connections
    - LLM configurations and tools

    Example:
        >>> scanner = DifyScanner()
        >>> result = scanner.scan_directory(Path("./dify_export"))
        >>> for agent in result.agents:
        ...     print(f"{agent.name}: {agent.system_prompt}")
    """

    framework_name = "Dify"

    # Node types that represent agents
    AGENT_NODE_TYPES = {
        "llm",
        "agent",
        "tool",
        "code",
        "template-transform",
        "question-classifier",
        "if-else",
        "iteration",
        "parameter-extractor",
    }

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a file for Dify agent definitions.

        Args:
            path: Path to Python, YAML, or JSON file

        Returns:
            ScanResult with detected agents and connections
        """
        # For Python files, look for Dify API usage
        if path.suffix == ".py":
            return self._scan_python_file(path)

        # For config files, parse Dify export format
        if path.suffix in [".yaml", ".yml", ".json"]:
            return self._scan_config_file(path)

        return ScanResult(
            agents=[],
            connections=[],
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=[],
        )

    def _scan_python_file(self, path: Path) -> ScanResult:
        """Scan a Python file for Dify API usage.

        Args:
            path: Path to Python file

        Returns:
            ScanResult with detected agents
        """
        agents: list[DetectedAgent] = []
        errors: list[str] = []

        try:
            tree = self._parse_python_file(path)
        except SyntaxError as e:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[f"Syntax error in {path}: {e}"],
            )

        # Look for Dify client usage
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        call_name = self._get_call_name(node.value)
                        if call_name in ["DifyClient", "ChatClient", "WorkflowClient"]:
                            agent = self._parse_dify_client(node.value, path, target.id)
                            if agent:
                                agents.append(agent)

        return ScanResult(
            agents=agents,
            connections=[],
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=errors,
        )

    def _scan_config_file(self, path: Path) -> ScanResult:
        """Scan a Dify export config file.

        Args:
            path: Path to YAML or JSON file

        Returns:
            ScanResult with detected agents and connections
        """
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        errors: list[str] = []

        # Parse config file
        config = self._parse_config(path)
        if not config:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[f"Failed to parse config file: {path}"],
            )

        # Check if this is a Dify export
        if not self._is_dify_config(config):
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[],
            )

        # Extract app info
        app_name = config.get("app", {}).get("name", "Dify App")
        app_mode = config.get("app", {}).get("mode", "workflow")

        # Parse based on mode
        if app_mode == "chat":
            agents, connections = self._parse_chatflow(config, path)
        else:
            agents, connections = self._parse_workflow(config, path)

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=errors,
        )

    def _is_dify_config(self, config: dict[str, Any]) -> bool:
        """Check if config is a Dify export.

        Args:
            config: Parsed config dictionary

        Returns:
            True if this appears to be a Dify config
        """
        # Check for common Dify export keys
        dify_keys = {"app", "workflow", "model_config", "graph"}
        return bool(dify_keys & set(config.keys()))

    def _parse_chatflow(
        self, config: dict[str, Any], path: Path
    ) -> tuple[list[DetectedAgent], list[DetectedConnection]]:
        """Parse a Dify chatflow configuration.

        Args:
            config: Parsed config dictionary
            path: Source file path

        Returns:
            Tuple of (agents, connections)
        """
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []

        # Get model config for chat
        model_config = config.get("model_config", {})

        # Create main chat agent
        app_name = config.get("app", {}).get("name", "Chat Agent")
        pre_prompt = model_config.get("pre_prompt", "")
        model = model_config.get("model", {}).get("name", "gpt-4")

        # Extract tools
        agent_mode = model_config.get("agent_mode", {})
        tools: list[str] = []
        if agent_mode.get("enabled"):
            for tool in agent_mode.get("tools", []):
                tool_name = tool.get("tool_name") or tool.get("provider_id", "")
                if tool_name:
                    tools.append(tool_name)

        system_prompt = pre_prompt
        if tools:
            system_prompt += f"\n\nTools: {', '.join(tools)}"

        agent = DetectedAgent(
            id=self._make_id(app_name),
            name=app_name,
            framework=Framework.DIFY,
            file_path=str(path),
            line_number=1,
            system_prompt=system_prompt.strip() or f"Dify Chat: {app_name}",
            tools=tools,
            metadata={
                "app_mode": "chat",
                "model": model,
            },
        )
        agents.append(agent)

        return agents, connections

    def _parse_workflow(
        self, config: dict[str, Any], path: Path
    ) -> tuple[list[DetectedAgent], list[DetectedConnection]]:
        """Parse a Dify workflow configuration.

        Args:
            config: Parsed config dictionary
            path: Source file path

        Returns:
            Tuple of (agents, connections)
        """
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        node_id_map: dict[str, str] = {}

        # Get workflow graph
        workflow = config.get("workflow", {})
        graph = workflow.get("graph", {})
        nodes = graph.get("nodes", [])
        edges = graph.get("edges", [])

        # Parse nodes
        for node in nodes:
            agent = self._parse_workflow_node(node, path)
            if agent:
                agents.append(agent)
                node_id_map[node.get("id", "")] = agent.id

        # Parse edges to create connections
        for edge in edges:
            source_node_id = edge.get("source")
            target_node_id = edge.get("target")

            if source_node_id in node_id_map and target_node_id in node_id_map:
                connections.append(
                    DetectedConnection(
                        source_id=node_id_map[source_node_id],
                        target_id=node_id_map[target_node_id],
                        connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                        confidence=0.95,
                        confidence_level=ConnectionConfidence.FRAMEWORK,
                        evidence=[f"Dify workflow edge: {source_node_id} -> {target_node_id}"],
                    )
                )

        return agents, connections

    def _parse_workflow_node(self, node: dict[str, Any], path: Path) -> DetectedAgent | None:
        """Parse a workflow node as an agent.

        Args:
            node: Node configuration dictionary
            path: Source file path

        Returns:
            DetectedAgent or None
        """
        node_type = node.get("data", {}).get("type", "")

        # Skip non-agent nodes
        if node_type not in self.AGENT_NODE_TYPES:
            return None

        # Extract node info
        node_id = node.get("id", "")
        title = node.get("data", {}).get("title", node_type)
        data = node.get("data", {})

        # Build system prompt based on node type
        system_prompt = self._build_node_prompt(node_type, data)

        # Extract model
        model = "gpt-4"
        if node_type == "llm":
            model_config = data.get("model", {})
            model = model_config.get("name", "gpt-4")

        # Extract tools for agent nodes
        tools: list[str] = []
        if node_type == "agent":
            for tool in data.get("tools", []):
                tool_name = tool.get("tool_name", "")
                if tool_name:
                    tools.append(tool_name)

        if tools:
            system_prompt += f"\n\nTools: {', '.join(tools)}"

        return DetectedAgent(
            id=self._make_id(f"{title}_{node_id[:8]}"),
            name=title,
            framework=Framework.DIFY,
            file_path=str(path),
            line_number=1,
            system_prompt=system_prompt.strip() or f"Dify {node_type} node",
            tools=tools,
            metadata={
                "node_type": node_type,
                "node_id": node_id,
                "model": model,
            },
        )

    def _build_node_prompt(self, node_type: str, data: dict[str, Any]) -> str:
        """Build system prompt for a workflow node.

        Args:
            node_type: Type of the node
            data: Node data dictionary

        Returns:
            System prompt string
        """
        if node_type == "llm":
            # LLM node - use prompt template
            prompt_template = data.get("prompt_template", [])
            if prompt_template:
                prompts = []
                for item in prompt_template:
                    if isinstance(item, dict):
                        text = item.get("text", "")
                        if text:
                            prompts.append(text)
                return "\n".join(prompts)
            return "LLM processing node"

        elif node_type == "agent":
            # Agent node - use system prompt
            return data.get("system_prompt", "") or "Agent node"

        elif node_type == "code":
            # Code node
            code = data.get("code", "")
            language = data.get("code_language", "python")
            return (
                f"Code execution ({language}): {code[:100]}..."
                if len(code) > 100
                else f"Code execution ({language})"
            )

        elif node_type == "tool":
            # Tool node
            tool_name = data.get("tool_name", "Tool")
            return f"Tool: {tool_name}"

        elif node_type == "template-transform":
            template = data.get("template", "")
            return (
                f"Template transformation: {template[:100]}..."
                if len(template) > 100
                else "Template transformation"
            )

        elif node_type == "question-classifier":
            classes = data.get("classes", [])
            if classes:
                class_names = [c.get("name", "") for c in classes if isinstance(c, dict)]
                return f"Question classifier: {', '.join(class_names)}"
            return "Question classifier"

        elif node_type == "if-else":
            return "Conditional branching"

        elif node_type == "iteration":
            return "Iteration/Loop processing"

        elif node_type == "parameter-extractor":
            return "Parameter extraction"

        return f"Dify {node_type} node"

    def _parse_dify_client(self, node: ast.Call, path: Path, var_name: str) -> DetectedAgent | None:
        """Parse Dify client instantiation.

        Args:
            node: AST Call node
            path: Source file path
            var_name: Variable name

        Returns:
            DetectedAgent or None
        """
        call_name = self._get_call_name(node)

        # Extract API key reference (for identification)
        api_key = self._extract_keyword_arg(node, "api_key")

        # Create agent representing the Dify client
        agent_id = self._make_id(var_name)
        name = self._format_display_name(var_name)

        client_type = "Chat" if "Chat" in call_name else "Workflow"
        system_prompt = f"Dify {client_type} Client"

        return DetectedAgent(
            id=agent_id,
            name=name,
            framework=Framework.DIFY,
            file_path=str(path),
            line_number=node.lineno,
            system_prompt=system_prompt,
            metadata={
                "client_type": call_name,
            },
        )

    def scan_directory(self, path: Path) -> ScanResult:
        """Override to also scan for Dify export files.

        Args:
            path: Directory path to scan

        Returns:
            ScanResult with all detected agents
        """
        # First do standard scan
        result = super().scan_directory(path)

        # Also look for Dify-specific config files
        dify_files = list(path.rglob("*dify*.yaml")) + list(path.rglob("*dify*.yml"))
        dify_files += list(path.rglob("*dify*.json"))

        for dify_file in dify_files:
            if self._should_skip_file(dify_file):
                continue

            try:
                file_result = self._scan_config_file(dify_file)
                result.agents.extend(file_result.agents)
                result.connections.extend(file_result.connections)
            except Exception as e:
                result.errors.append(f"Error scanning {dify_file}: {e}")

        return result

    def _scan_yaml_file(self, path: Path) -> ScanResult:
        """Override to handle Dify YAML exports.

        Args:
            path: Path to YAML file

        Returns:
            ScanResult with detected agents
        """
        return self._scan_config_file(path)
