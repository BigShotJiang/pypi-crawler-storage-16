"""
Baseline management for suppressing known findings.

This module provides functionality to:
- Create and manage baseline files
- Suppress known false positives or accepted risks
- Track suppression reasons and expiration
- Generate fingerprints for stable matching
"""

from vantage_core.security.baseline.manager import (
    Baseline,
    BaselineEntry,
    BaselineManager,
    SuppressionReason,
)

__all__ = [
    "BaselineManager",
    "BaselineEntry",
    "SuppressionReason",
    "Baseline",
]
