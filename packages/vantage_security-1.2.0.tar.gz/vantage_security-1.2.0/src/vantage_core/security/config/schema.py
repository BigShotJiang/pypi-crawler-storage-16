"""
Configuration schema with Pydantic models.

US-009: Environment Variable Overrides
US-010: YAML/TOML Configuration File
US-012: Configuration Validation

Defines all configuration settings for Vantage security scanner
with type validation, range constraints, and dependency checking.
"""

from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class LogLevel(str, Enum):
    """Log level options."""

    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class OutputFormat(str, Enum):
    """Output format options."""

    JSON = "json"
    SARIF = "sarif"
    TEXT = "text"
    HTML = "html"


class TaintAnalysisMode(str, Enum):
    """Taint analysis mode options."""

    DISABLED = "disabled"
    INTRA_PROCEDURAL = "intra_procedural"
    INTER_PROCEDURAL = "inter_procedural"  # Future enhancement


class LoggingConfig(BaseModel):
    """Logging configuration section."""

    level: LogLevel = Field(default=LogLevel.INFO, description="Minimum log level for output")
    json_output: bool = Field(
        default=True, description="Output logs in JSON format for log aggregation"
    )
    file: Path | None = Field(default=None, description="Optional file path for log output")
    audit_file: Path = Field(
        default=Path("audit.jsonl"), description="File path for audit trail logs"
    )
    include_timestamps: bool = Field(
        default=True, description="Include ISO 8601 timestamps in logs"
    )
    include_correlation_ids: bool = Field(
        default=True, description="Include correlation IDs for request tracing"
    )


class EntropyConfig(BaseModel):
    """
    Entropy threshold configuration for secret detection.

    These values are used by SecretContextAnalyzer to determine
    minimum entropy levels for different secret types.
    """

    api_key: float = Field(
        default=3.5,
        ge=0.0,
        le=8.0,
        description="Minimum entropy threshold for API keys",
    )
    password: float = Field(
        default=3.0,
        ge=0.0,
        le=8.0,
        description="Minimum entropy threshold for passwords",
    )
    token: float = Field(
        default=4.0, ge=0.0, le=8.0, description="Minimum entropy threshold for tokens"
    )
    secret: float = Field(
        default=3.5,
        ge=0.0,
        le=8.0,
        description="Minimum entropy threshold for generic secrets",
    )
    default: float = Field(
        default=3.0,
        ge=0.0,
        le=8.0,
        description="Default entropy threshold for unknown types",
    )


class ConfidenceConfig(BaseModel):
    """
    Confidence threshold configuration for findings.

    These values determine severity classification based on
    confidence scores.
    """

    min_secret: float = Field(
        default=0.5,
        ge=0.0,
        le=1.0,
        description="Minimum confidence to report a secret finding",
    )
    critical: float = Field(
        default=0.8,
        ge=0.0,
        le=1.0,
        description="Confidence threshold for CRITICAL severity",
    )
    high: float = Field(
        default=0.6,
        ge=0.0,
        le=1.0,
        description="Confidence threshold for HIGH severity",
    )

    @model_validator(mode="after")
    def validate_confidence_ordering(self) -> ConfidenceConfig:
        """Ensure confidence thresholds are properly ordered."""
        if self.high >= self.critical:
            raise ValueError(
                f"high confidence ({self.high}) must be less than "
                f"critical confidence ({self.critical})"
            )
        if self.min_secret > self.high:
            raise ValueError(
                f"min_secret confidence ({self.min_secret}) should not be "
                f"greater than high confidence ({self.high})"
            )
        return self


class TaintConfig(BaseModel):
    """Taint analysis configuration section."""

    enabled: bool = Field(default=True, description="Enable taint analysis for data flow tracking")
    mode: TaintAnalysisMode = Field(
        default=TaintAnalysisMode.INTRA_PROCEDURAL, description="Taint analysis mode"
    )
    max_depth: int = Field(
        default=100,
        ge=1,
        le=1000,
        description="Maximum depth for taint propagation tracking",
    )
    max_iterations: int = Field(
        default=1000,
        ge=10,
        le=100000,
        description="Maximum iterations for worklist algorithm",
    )
    timeout_per_function_ms: int = Field(
        default=5000,
        ge=100,
        le=60000,
        description="Timeout per function in milliseconds",
    )
    max_path_length: int = Field(
        default=50,
        ge=5,
        le=200,
        description="Maximum path length for taint flow reporting",
    )
    track_sanitizers: bool = Field(
        default=True, description="Track sanitizer functions that clean tainted data"
    )


class PerformanceConfig(BaseModel):
    """Performance tuning configuration section."""

    max_file_size_kb: int = Field(
        default=1000, ge=1, le=100000, description="Maximum file size to scan in KB"
    )
    timeout_seconds: int = Field(
        default=300, ge=1, le=3600, description="Overall scan timeout in seconds"
    )
    timeout_per_file_seconds: int = Field(
        default=30, ge=1, le=300, description="Timeout per file in seconds"
    )
    max_findings_per_file: int = Field(
        default=100, ge=1, le=10000, description="Maximum findings to report per file"
    )
    parallel_files: int = Field(
        default=4, ge=1, le=32, description="Number of files to process in parallel"
    )
    fail_fast: bool = Field(default=False, description="Stop scanning on first error")


class SeverityThresholds(BaseModel):
    """Severity score thresholds for risk scoring."""

    critical_score: float = Field(
        default=9.0, ge=0.0, le=10.0, description="Minimum score for CRITICAL severity"
    )
    high_score: float = Field(
        default=7.0, ge=0.0, le=10.0, description="Minimum score for HIGH severity"
    )
    medium_score: float = Field(
        default=4.0, ge=0.0, le=10.0, description="Minimum score for MEDIUM severity"
    )
    low_score: float = Field(
        default=1.0, ge=0.0, le=10.0, description="Minimum score for LOW severity"
    )

    @model_validator(mode="after")
    def validate_threshold_ordering(self) -> SeverityThresholds:
        """Ensure severity thresholds are properly ordered."""
        if self.high_score >= self.critical_score:
            raise ValueError(
                f"high_score ({self.high_score}) must be less than "
                f"critical_score ({self.critical_score})"
            )
        if self.medium_score >= self.high_score:
            raise ValueError(
                f"medium_score ({self.medium_score}) must be less than "
                f"high_score ({self.high_score})"
            )
        if self.low_score >= self.medium_score:
            raise ValueError(
                f"low_score ({self.low_score}) must be less than "
                f"medium_score ({self.medium_score})"
            )
        return self


class RulesConfig(BaseModel):
    """Custom rules configuration section."""

    paths: list[Path] = Field(
        default_factory=lambda: [Path("rules/")],
        description="Paths to custom rule directories",
    )
    enable_builtin: bool = Field(default=True, description="Enable built-in security rules")
    enable_experimental: bool = Field(default=False, description="Enable experimental rules")
    exclude_ids: list[str] = Field(
        default_factory=list, description="Rule IDs to exclude from scanning"
    )
    include_ids: list[str] = Field(
        default_factory=list, description="If set, only these rules will run"
    )


class MimicSettings(BaseSettings):
    """
    Main configuration for Vantage security scanner.

    Supports loading from:
    1. Constructor arguments (highest priority)
    2. Environment variables (MIMIC_ prefix)
    3. .env file
    4. TOML configuration file (vantage.toml)
    5. YAML configuration file (vantage.yaml)
    6. Default values (lowest priority)

    Environment variable examples:
    - MIMIC_LOG_LEVEL=DEBUG
    - MIMIC_LOGGING__JSON_OUTPUT=false
    - MIMIC_TAINT__ENABLED=false
    - MIMIC_ENTROPY__API_KEY=4.0
    """

    model_config = SettingsConfigDict(
        env_prefix="MIMIC_",
        env_nested_delimiter="__",
        env_file=".env",
        extra="ignore",
        case_sensitive=False,
    )

    # Core settings
    output_format: OutputFormat = Field(
        default=OutputFormat.SARIF, description="Output format for scan results"
    )
    output_file: Path | None = Field(default=None, description="Output file path for scan results")

    # Nested configurations
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    entropy: EntropyConfig = Field(default_factory=EntropyConfig)
    confidence: ConfidenceConfig = Field(default_factory=ConfidenceConfig)
    taint: TaintConfig = Field(default_factory=TaintConfig)
    performance: PerformanceConfig = Field(default_factory=PerformanceConfig)
    thresholds: SeverityThresholds = Field(default_factory=SeverityThresholds)
    rules: RulesConfig = Field(default_factory=RulesConfig)

    # Shortcut properties for common settings (backward compatibility)
    log_level: LogLevel | None = Field(default=None, description="Shortcut for logging.level")
    log_json: bool | None = Field(default=None, description="Shortcut for logging.json_output")
    log_file: Path | None = Field(default=None, description="Shortcut for logging.file")
    audit_file: Path | None = Field(default=None, description="Shortcut for logging.audit_file")

    # Entropy shortcuts
    entropy_api_key: float | None = Field(default=None)
    entropy_password: float | None = Field(default=None)
    entropy_token: float | None = Field(default=None)
    entropy_default: float | None = Field(default=None)

    # Confidence shortcuts
    min_secret_confidence: float | None = Field(default=None)
    critical_confidence: float | None = Field(default=None)
    high_confidence: float | None = Field(default=None)

    # Taint shortcuts
    taint_enabled: bool | None = Field(default=None)
    taint_max_depth: int | None = Field(default=None)
    taint_max_iterations: int | None = Field(default=None)

    # Performance shortcuts
    max_file_size_kb: int | None = Field(default=None)
    timeout_seconds: int | None = Field(default=None)
    parallel_files: int | None = Field(default=None)

    # Exclusions
    exclude_patterns: list[str] = Field(
        default=[
            "**/node_modules/**",
            "**/venv/**",
            "**/.venv/**",
            "**/.git/**",
            "**/test/**",
            "**/tests/**",
            "**/__pycache__/**",
            "**/.pytest_cache/**",
            "**/dist/**",
            "**/build/**",
        ],
        description="Glob patterns for files/directories to exclude",
    )

    @model_validator(mode="after")
    def apply_shortcuts(self) -> MimicSettings:
        """Apply shortcut settings to nested configurations."""
        # Logging shortcuts
        if self.log_level is not None:
            self.logging.level = self.log_level
        if self.log_json is not None:
            self.logging.json_output = self.log_json
        if self.log_file is not None:
            self.logging.file = self.log_file
        if self.audit_file is not None:
            self.logging.audit_file = self.audit_file

        # Entropy shortcuts
        if self.entropy_api_key is not None:
            self.entropy.api_key = self.entropy_api_key
        if self.entropy_password is not None:
            self.entropy.password = self.entropy_password
        if self.entropy_token is not None:
            self.entropy.token = self.entropy_token
        if self.entropy_default is not None:
            self.entropy.default = self.entropy_default

        # Confidence shortcuts
        if self.min_secret_confidence is not None:
            self.confidence.min_secret = self.min_secret_confidence
        if self.critical_confidence is not None:
            self.confidence.critical = self.critical_confidence
        if self.high_confidence is not None:
            self.confidence.high = self.high_confidence

        # Taint shortcuts
        if self.taint_enabled is not None:
            self.taint.enabled = self.taint_enabled
        if self.taint_max_depth is not None:
            self.taint.max_depth = self.taint_max_depth
        if self.taint_max_iterations is not None:
            self.taint.max_iterations = self.taint_max_iterations

        # Performance shortcuts
        if self.max_file_size_kb is not None:
            self.performance.max_file_size_kb = self.max_file_size_kb
        if self.timeout_seconds is not None:
            self.performance.timeout_seconds = self.timeout_seconds
        if self.parallel_files is not None:
            self.performance.parallel_files = self.parallel_files

        return self

    @model_validator(mode="after")
    def validate_dependencies(self) -> MimicSettings:
        """Validate configuration dependencies."""
        errors = []

        # Taint analysis requires sufficient timeout
        if self.taint.enabled:
            if self.performance.timeout_per_file_seconds < 10:
                errors.append("Taint analysis requires performance.timeout_per_file_seconds >= 10")

        # Inter-procedural analysis not yet supported
        if self.taint.mode == TaintAnalysisMode.INTER_PROCEDURAL:
            errors.append(
                "Inter-procedural taint analysis is not yet implemented. "
                "Use 'intra_procedural' mode."
            )

        if errors:
            raise ValueError("; ".join(errors))

        return self

    def get_entropy_thresholds(self) -> dict[str, float]:
        """
        Get entropy thresholds as dictionary for SecretContextAnalyzer.

        Returns:
            Dictionary mapping secret types to entropy thresholds
        """
        return {
            "api_key": self.entropy.api_key,
            "password": self.entropy.password,
            "token": self.entropy.token,
            "secret": self.entropy.secret,
            "default": self.entropy.default,
        }

    def to_dict(self) -> dict[str, Any]:
        """
        Convert settings to dictionary.

        Returns:
            Dictionary representation of all settings
        """
        return self.model_dump(exclude_none=True, mode="json")
