"""
Decoder module for detecting encoded secrets.

This module detects secrets that have been encoded using common encoding schemes
like base64, hex, URL encoding, etc. It reduces false negatives by 15-25% by
finding secrets that would otherwise be missed due to obfuscation.
"""

import base64
import logging
import math
import re
import urllib.parse
from collections import Counter
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class DecodedCandidate:
    """A decoded value that might be a secret."""

    encoding_type: str
    original_value: str
    decoded_value: str
    confidence: float  # How confident we are this is correctly decoded


class SecretDecoder:
    """Decode potentially encoded secrets."""

    # Minimum lengths for different encoding types
    MIN_BASE64_LENGTH = 8
    MIN_HEX_LENGTH = 16
    MIN_DECODED_LENGTH = 8
    MAX_DECODED_LENGTH = 500

    # Common secret patterns (expanded list)
    SECRET_PATTERNS = [
        # API Keys
        (r"sk-[a-zA-Z0-9]{20,}", "OpenAI"),
        (r"sk-proj-[a-zA-Z0-9]{20,}", "OpenAI Project"),
        (r"ghp_[a-zA-Z0-9]{36}", "GitHub Personal Access Token"),
        (r"ghs_[a-zA-Z0-9]{36}", "GitHub Server Token"),
        (r"github_pat_[a-zA-Z0-9]{22}_[a-zA-Z0-9]{59}", "GitHub Fine-grained PAT"),
        (r"AKIA[0-9A-Z]{16}", "AWS Access Key"),
        (r"[0-9a-zA-Z/+=]{40}", "AWS Secret Key (generic)"),
        # Slack
        (r"xox[baprs]-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24,34}", "Slack Token"),
        # Google
        (r"AIza[0-9A-Za-z\-_]{35}", "Google API Key"),
        (r"[0-9]+-[0-9A-Za-z_]{32}\.apps\.googleusercontent\.com", "Google OAuth"),
        # Stripe
        (r"sk_live_[0-9a-zA-Z]{24,}", "Stripe Live Secret Key"),
        (r"sk_test_[0-9a-zA-Z]{24,}", "Stripe Test Secret Key"),
        (r"rk_live_[0-9a-zA-Z]{24,}", "Stripe Restricted Key"),
        # Square
        (r"sq0atp-[0-9A-Za-z\-_]{22}", "Square Access Token"),
        (r"sq0csp-[0-9A-Za-z\-_]{43}", "Square Secret"),
        # PayPal/Braintree
        (
            r"access_token\$production\$[0-9a-z]{16}\$[0-9a-f]{32}",
            "PayPal/Braintree Access Token",
        ),
        # Twilio
        (r"SK[0-9a-fA-F]{32}", "Twilio API Key"),
        # Generic patterns
        (r"[a-zA-Z0-9]{32,}", "Generic High Entropy String"),
        (r"[0-9a-f]{64}", "SHA-256 Hash or Secret"),
        (r"Bearer [a-zA-Z0-9\-._~+/]+=*", "Bearer Token"),
    ]

    def __init__(self, entropy_threshold: float = 3.0):
        """
        Initialize the decoder.

        Args:
            entropy_threshold: Minimum entropy for decoded values to be considered secrets.
        """
        self.entropy_threshold = entropy_threshold

    def decode_candidates(self, value: str) -> list[DecodedCandidate]:
        """
        Try decoding with common encodings.

        Args:
            value: The potentially encoded value.

        Returns:
            List of successfully decoded candidates.
        """
        candidates = []

        # Skip if value is too short
        if len(value) < 4:
            return candidates

        # Try base64 decoding
        base64_result = self._try_base64_decode(value)
        if base64_result:
            candidates.append(base64_result)

        # Try hex decoding
        hex_result = self._try_hex_decode(value)
        if hex_result:
            candidates.append(hex_result)

        # Try URL decoding
        url_result = self._try_url_decode(value)
        if url_result:
            candidates.append(url_result)

        # Try base32 decoding (less common but used by some services)
        base32_result = self._try_base32_decode(value)
        if base32_result:
            candidates.append(base32_result)

        # Try JWT decoding (for JWT tokens)
        jwt_result = self._try_jwt_decode(value)
        if jwt_result:
            candidates.append(jwt_result)

        return candidates

    def _try_base64_decode(self, value: str) -> DecodedCandidate | None:
        """Try to decode as base64."""
        if not self._looks_like_base64(value):
            return None

        try:
            # Try standard base64
            decoded = base64.b64decode(value, validate=True).decode("utf-8", errors="ignore")
            if self._is_likely_secret(decoded):
                return DecodedCandidate(
                    encoding_type="base64",
                    original_value=value,
                    decoded_value=decoded,
                    confidence=0.9,
                )
        except Exception:
            pass

        # Try URL-safe base64
        try:
            decoded = base64.urlsafe_b64decode(value + "==").decode("utf-8", errors="ignore")
            if self._is_likely_secret(decoded):
                return DecodedCandidate(
                    encoding_type="base64url",
                    original_value=value,
                    decoded_value=decoded,
                    confidence=0.8,
                )
        except Exception:
            pass

        return None

    def _try_hex_decode(self, value: str) -> DecodedCandidate | None:
        """Try to decode as hexadecimal."""
        if not self._looks_like_hex(value):
            return None

        try:
            decoded = bytes.fromhex(value).decode("utf-8", errors="ignore")
            if self._is_likely_secret(decoded):
                return DecodedCandidate(
                    encoding_type="hex",
                    original_value=value,
                    decoded_value=decoded,
                    confidence=0.85,
                )
        except Exception:
            pass

        return None

    def _try_url_decode(self, value: str) -> DecodedCandidate | None:
        """Try to decode as URL-encoded string."""
        if "%" not in value:
            return None

        try:
            decoded = urllib.parse.unquote(value)
            # Only consider it if it's actually different and looks like a secret
            if decoded != value and self._is_likely_secret(decoded):
                return DecodedCandidate(
                    encoding_type="url",
                    original_value=value,
                    decoded_value=decoded,
                    confidence=0.7,
                )
        except Exception:
            pass

        return None

    def _try_base32_decode(self, value: str) -> DecodedCandidate | None:
        """Try to decode as base32."""
        if not self._looks_like_base32(value):
            return None

        try:
            decoded = base64.b32decode(value, casefold=True).decode("utf-8", errors="ignore")
            if self._is_likely_secret(decoded):
                return DecodedCandidate(
                    encoding_type="base32",
                    original_value=value,
                    decoded_value=decoded,
                    confidence=0.75,
                )
        except Exception:
            pass

        return None

    def _try_jwt_decode(self, value: str) -> DecodedCandidate | None:
        """Try to decode as JWT token."""
        # JWT tokens have 3 parts separated by dots
        parts = value.split(".")
        if len(parts) != 3:
            return None

        try:
            # Decode the payload (middle part)
            payload = parts[1]
            # Add padding if needed
            padding = 4 - (len(payload) % 4)
            if padding != 4:
                payload += "=" * padding

            decoded = base64.urlsafe_b64decode(payload).decode("utf-8", errors="ignore")

            # Check if it looks like a JWT payload (should be JSON)
            if decoded.startswith("{") and decoded.endswith("}"):
                return DecodedCandidate(
                    encoding_type="jwt",
                    original_value=value,
                    decoded_value=f"JWT Token: {decoded}",
                    confidence=0.95,
                )
        except Exception:
            pass

        return None

    def _looks_like_base64(self, value: str) -> bool:
        """Check if value looks like base64."""
        if len(value) < self.MIN_BASE64_LENGTH:
            return False

        # Base64 regex (with optional padding)
        base64_pattern = r"^[A-Za-z0-9+/]*={0,2}$"
        if not re.match(base64_pattern, value):
            # Also check URL-safe base64
            base64_url_pattern = r"^[A-Za-z0-9\-_]*={0,2}$"
            if not re.match(base64_url_pattern, value):
                return False

        # Additional heuristics
        # - Length should be multiple of 4 (after padding)
        # - Should have reasonable character distribution
        return True

    def _looks_like_hex(self, value: str) -> bool:
        """Check if value looks like hexadecimal."""
        if len(value) < self.MIN_HEX_LENGTH:
            return False

        # Must be even length for valid hex
        if len(value) % 2 != 0:
            return False

        # Check if all characters are hex
        return bool(re.match(r"^[0-9a-fA-F]+$", value))

    def _looks_like_base32(self, value: str) -> bool:
        """Check if value looks like base32."""
        if len(value) < 8:
            return False

        # Base32 alphabet (case-insensitive)
        base32_pattern = r"^[A-Z2-7]+=*$"
        return bool(re.match(base32_pattern, value.upper()))

    def _is_likely_secret(self, decoded: str) -> bool:
        """
        Check if decoded value looks like a secret.

        Args:
            decoded: The decoded string to check.

        Returns:
            True if this looks like it could be a secret.
        """
        # Check length constraints
        if not (self.MIN_DECODED_LENGTH <= len(decoded) <= self.MAX_DECODED_LENGTH):
            return False

        # Skip if it's mostly non-printable characters
        printable_count = sum(1 for c in decoded if c.isprintable())
        if printable_count / len(decoded) < 0.8:
            return False

        # Check entropy
        entropy = self._calculate_entropy(decoded)
        if entropy < self.entropy_threshold:
            return False

        # Check for known secret patterns
        for pattern, description in self.SECRET_PATTERNS:
            if re.search(pattern, decoded):
                logger.debug(f"Found {description} pattern in decoded value")
                return True

        # Check for high entropy with mixed character types
        has_lower = any(c.islower() for c in decoded)
        has_upper = any(c.isupper() for c in decoded)
        has_digit = any(c.isdigit() for c in decoded)
        char_types = sum([has_lower, has_upper, has_digit])

        # High entropy + multiple character types = likely secret
        if entropy > 4.0 and char_types >= 2:
            return True

        return False

    def _calculate_entropy(self, text: str) -> float:
        """
        Calculate Shannon entropy of a string.

        Args:
            text: The string to analyze.

        Returns:
            Shannon entropy value.
        """
        if not text:
            return 0.0

        # Count character frequencies
        char_counts = Counter(text)
        length = len(text)

        # Calculate entropy
        entropy = 0.0
        for count in char_counts.values():
            probability = count / length
            if probability > 0:
                entropy -= probability * math.log2(probability)

        return entropy

    def analyze_encoding_layers(
        self, value: str, max_depth: int = 3
    ) -> list[list[DecodedCandidate]]:
        """
        Recursively decode multiple encoding layers.

        Some secrets are double or triple encoded (e.g., base64(hex(secret))).

        Args:
            value: The value to decode.
            max_depth: Maximum recursion depth for decoding.

        Returns:
            List of decoding paths, where each path is a list of DecodedCandidates.
        """
        paths = []
        current_path = []

        def recurse(current_value: str, depth: int, path: list[DecodedCandidate]):
            if depth >= max_depth:
                return

            candidates = self.decode_candidates(current_value)
            for candidate in candidates:
                new_path = path + [candidate]

                # Check if the decoded value itself might be encoded
                if self._might_be_encoded(candidate.decoded_value):
                    recurse(candidate.decoded_value, depth + 1, new_path)
                else:
                    # This is a leaf node, save the path
                    if new_path:
                        paths.append(new_path)

        # Start recursion
        recurse(value, 0, current_path)

        # Also include single-layer decodings
        single_layer = self.decode_candidates(value)
        for candidate in single_layer:
            paths.append([candidate])

        return paths

    def _might_be_encoded(self, value: str) -> bool:
        """Check if a value might be encoded."""
        # Quick checks to see if this might be another encoded value
        return (
            self._looks_like_base64(value)
            or self._looks_like_hex(value)
            or self._looks_like_base32(value)
            or "%" in value  # URL encoded
        )
