"""
Prompt Injection Classifier for Multi-Agent Systems.

This module provides ML-based and rule-based classification of prompt injection
attacks in multi-agent systems. It detects:
- Direct prompt injection
- Indirect prompt injection
- Jailbreak attempts
- Context manipulation
- Role confusion attacks
"""

import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class InjectionType(str, Enum):
    """Types of prompt injection attacks."""

    DIRECT = "direct"  # Direct instruction override
    INDIRECT = "indirect"  # Via external data sources
    JAILBREAK = "jailbreak"  # Safety bypass
    CONTEXT_MANIPULATION = "context"  # Context window manipulation
    ROLE_CONFUSION = "role_confusion"  # Role/persona hijacking
    ENCODING_ATTACK = "encoding"  # Encoded payloads
    MULTI_TURN = "multi_turn"  # Multi-turn manipulation


@dataclass
class InjectionClassification:
    """Result of injection classification."""

    is_injection: bool
    injection_type: InjectionType | None
    confidence: float
    matched_patterns: list[str]
    explanation: str
    recommendation: str
    severity: str  # critical, high, medium, low
    metadata: dict[str, Any] = field(default_factory=dict)


class PromptInjectionClassifier:
    """
    Rule-based prompt injection classifier.

    Uses research-backed patterns to detect prompt injection attempts.
    """

    # Pattern categories with severity
    INJECTION_PATTERNS = {
        InjectionType.DIRECT: {
            "severity": "critical",
            "patterns": [
                # Instruction override
                (
                    r"(?i)ignore\s+(?:all\s+)?(?:previous\s+)?(?:instructions?|rules?|prompts?)",
                    "instruction_override",
                ),
                (r"(?i)forget\s+(?:everything|all|your\s+training)", "memory_wipe"),
                (
                    r"(?i)new\s+(?:instructions?|rules?|prompt)(?:\s*:|\s+are)",
                    "new_instruction",
                ),
                (
                    r"(?i)(?:your|the)\s+(?:real|actual|true)\s+(?:instructions?|purpose)",
                    "instruction_claim",
                ),
                (r"(?i)disregard\s+(?:all\s+)?(?:previous|prior|above)", "disregard"),
                (r"(?i)from\s+now\s+on(?:\s*,)?\s+(?:you|your)", "directive_start"),
                # System prompt extraction
                (
                    r"(?i)(?:reveal|show|print|output|display)\s+(?:your|the)\s+(?:system\s+)?(?:prompt|instructions?)",
                    "prompt_extraction",
                ),
                (
                    r"(?i)what\s+(?:is|are)\s+your\s+(?:system\s+)?(?:prompt|instructions?)",
                    "prompt_query",
                ),
                (
                    r"(?i)repeat\s+(?:your|the)\s+(?:initial|original|system)\s+(?:prompt|instructions?)",
                    "prompt_repeat",
                ),
            ],
        },
        InjectionType.JAILBREAK: {
            "severity": "critical",
            "patterns": [
                # DAN and variants
                (
                    r"(?i)(?:you\s+are|i\s+am)\s+(?:now\s+)?(?:DAN|STAN|DUDE)",
                    "dan_jailbreak",
                ),
                (r"(?i)do\s+anything\s+now", "dan_explicit"),
                (
                    r"(?i)(?:enabled?|activated?)\s+(?:developer|admin|god)\s+mode",
                    "special_mode",
                ),
                (r"(?i)jailbreak(?:en|ed)?\s+mode", "jailbreak_mode"),
                (
                    r"(?i)without\s+(?:any\s+)?(?:restrictions?|limitations?|filters?)",
                    "restriction_bypass",
                ),
                # Persona manipulation
                (
                    r"(?i)pretend\s+(?:to\s+)?(?:be|you're?|that)\s+(?:a|an)?\s*(?:evil|malicious|unfiltered|unrestricted)",
                    "evil_persona",
                ),
                (
                    r"(?i)act\s+as\s+(?:if\s+)?(?:you\s+(?:have|had)|there\s+(?:are|were))\s+no\s+(?:rules?|restrictions?)",
                    "no_rules",
                ),
                (
                    r"(?i)roleplay\s+as\s+(?:a|an)\s+(?:AI|assistant)\s+(?:without|with\s+no)",
                    "roleplay_bypass",
                ),
            ],
        },
        InjectionType.INDIRECT: {
            "severity": "high",
            "patterns": [
                # Hidden instructions in data
                (
                    r"(?i)(?:IMPORTANT|ATTENTION|CRITICAL|URGENT)(?:\s*[:\-!])?\s*(?:ignore|forget|disregard)",
                    "hidden_instruction",
                ),
                (r"(?i)<<<\s*(?:SYSTEM|ADMIN|HIDDEN)\s*>>>", "hidden_tag"),
                (r"(?i)\[INST\]|\[/INST\]|\[SYSTEM\]", "instruction_tag"),
                (
                    r"(?i)<!--\s*(?:ignore|forget|new\s+instructions?)",
                    "html_comment_injection",
                ),
                # Data exfiltration
                (
                    r"(?i)send\s+(?:this|the|all|it)\s+(?:data|info(?:rmation)?|text)?\s*to\s+",
                    "data_exfil",
                ),
                (
                    r"(?i)(?:email|post|upload|transmit)\s+(?:this|the|it)\s+to",
                    "data_send",
                ),
            ],
        },
        InjectionType.CONTEXT_MANIPULATION: {
            "severity": "high",
            "patterns": [
                # Context window attacks
                (
                    r"(?i)(?:above|previous)\s+(?:text|content|context)\s+(?:is|was)\s+(?:just\s+)?(?:a\s+)?(?:test|example)",
                    "context_dismissal",
                ),
                (
                    r"(?i)the\s+(?:real|actual|true)\s+(?:question|task|request)\s+is",
                    "context_redirect",
                ),
                (
                    r"(?i)everything\s+(?:before|above)\s+(?:this|was)\s+(?:fake|test)",
                    "context_invalidation",
                ),
                (
                    r"(?:\n\s*){10,}",
                    "newline_flood",
                ),  # Excessive newlines to push context
                # Attention manipulation
                (
                    r"(?i)pay\s+(?:close\s+)?attention\s+(?:only\s+)?to\s+(?:this|what\s+follows)",
                    "attention_hijack",
                ),
                (
                    r"(?i)focus\s+(?:only\s+)?on\s+(?:the\s+following|this\s+(?:part|section))",
                    "focus_redirect",
                ),
            ],
        },
        InjectionType.ROLE_CONFUSION: {
            "severity": "high",
            "patterns": [
                # Role impersonation
                (
                    r"(?i)(?:speaking|talking|writing)\s+as\s+(?:the\s+)?(?:system|admin|assistant)",
                    "role_claim",
                ),
                (
                    r"(?i)i\s+am\s+(?:the\s+)?(?:system|administrator|developer)",
                    "identity_claim",
                ),
                (r"(?i)\[(?:SYSTEM|ADMIN|ASSISTANT)\](?:\s*:)?", "role_tag"),
                (
                    r"(?i)(?:system|admin)\s*(?:says?|message|response)(?:\s*:)?",
                    "role_prefix",
                ),
                # Trust manipulation
                (
                    r"(?i)(?:you|the\s+AI)\s+(?:can|should)\s+trust\s+(?:me|this)",
                    "trust_claim",
                ),
                (
                    r"(?i)(?:authorized|verified|trusted)\s+(?:user|admin|request)",
                    "auth_claim",
                ),
            ],
        },
        InjectionType.ENCODING_ATTACK: {
            "severity": "medium",
            "patterns": [
                # Encoded payloads
                (
                    r"(?i)(?:base64|hex|rot13|unicode)\s*(?:decode|encoded?)(?:\s*:)?",
                    "encoding_instruction",
                ),
                (r"(?i)decode\s+(?:this|the\s+following)(?:\s*:)?", "decode_request"),
                (r"(?:\\x[0-9a-fA-F]{2}){4,}", "hex_escape_sequence"),
                (r"(?:\\u[0-9a-fA-F]{4}){4,}", "unicode_escape_sequence"),
                (r"(?:&#x?[0-9a-fA-F]+;){4,}", "html_entity_sequence"),
            ],
        },
        InjectionType.MULTI_TURN: {
            "severity": "medium",
            "patterns": [
                # Multi-turn setup
                (
                    r"(?i)(?:in\s+(?:our|the)\s+)?(?:previous|last|earlier)\s+conversation",
                    "conversation_reference",
                ),
                (
                    r"(?i)(?:you|we)\s+(?:agreed|discussed|said)\s+(?:earlier|before)",
                    "agreement_claim",
                ),
                (
                    r"(?i)(?:remember|recall)\s+(?:when\s+)?(?:you|we)\s+(?:said|agreed)",
                    "memory_manipulation",
                ),
                (
                    r"(?i)continue\s+(?:from|where)\s+(?:we\s+)?left\s+off",
                    "continuation_attempt",
                ),
            ],
        },
    }

    def __init__(self, strict_mode: bool = False):
        """
        Initialize the classifier.

        Args:
            strict_mode: If True, use lower confidence thresholds.
        """
        self.strict_mode = strict_mode
        self._compile_patterns()

    def _compile_patterns(self) -> None:
        """Pre-compile regex patterns."""
        self._compiled_patterns: dict[InjectionType, list[tuple[re.Pattern, str]]] = {}

        for injection_type, config in self.INJECTION_PATTERNS.items():
            self._compiled_patterns[injection_type] = [
                (re.compile(pattern), name) for pattern, name in config["patterns"]
            ]

    def classify(
        self, text: str, context: str = "", source: str = "unknown"
    ) -> InjectionClassification:
        """
        Classify text for prompt injection.

        Args:
            text: Text to analyze
            context: Additional context
            source: Source of the text (e.g., "user_input", "file", "api")

        Returns:
            InjectionClassification result
        """
        full_text = f"{context}\n{text}" if context else text
        matched_patterns = []
        detected_types = []
        max_severity = "low"

        severity_order = {"low": 0, "medium": 1, "high": 2, "critical": 3}

        # Check all pattern categories
        for injection_type, compiled_patterns in self._compiled_patterns.items():
            config = self.INJECTION_PATTERNS[injection_type]
            type_matched = False

            for pattern, name in compiled_patterns:
                if pattern.search(full_text):
                    matched_patterns.append(f"{injection_type.value}:{name}")
                    type_matched = True

            if type_matched:
                detected_types.append(injection_type)
                if severity_order[config["severity"]] > severity_order[max_severity]:
                    max_severity = config["severity"]

        # Calculate confidence
        if not matched_patterns:
            return InjectionClassification(
                is_injection=False,
                injection_type=None,
                confidence=0.0,
                matched_patterns=[],
                explanation="No injection patterns detected",
                recommendation="Text appears safe",
                severity="low",
            )

        # Base confidence
        confidence = min(0.5 + (len(matched_patterns) * 0.1), 1.0)

        # Boost for critical patterns
        if max_severity == "critical":
            confidence = min(confidence + 0.2, 1.0)

        # Determine primary injection type
        primary_type = detected_types[0] if detected_types else None

        # Generate explanation
        explanation = self._generate_explanation(detected_types, matched_patterns)

        # Generate recommendation
        recommendation = self._generate_recommendation(primary_type, max_severity)

        return InjectionClassification(
            is_injection=True,
            injection_type=primary_type,
            confidence=confidence,
            matched_patterns=matched_patterns,
            explanation=explanation,
            recommendation=recommendation,
            severity=max_severity,
            metadata={
                "all_types": [t.value for t in detected_types],
                "pattern_count": len(matched_patterns),
                "source": source,
            },
        )

    def _generate_explanation(
        self, detected_types: list[InjectionType], matched_patterns: list[str]
    ) -> str:
        """Generate human-readable explanation."""
        type_descriptions = {
            InjectionType.DIRECT: "direct instruction manipulation",
            InjectionType.INDIRECT: "hidden instructions in data",
            InjectionType.JAILBREAK: "safety guardrail bypass attempt",
            InjectionType.CONTEXT_MANIPULATION: "context window manipulation",
            InjectionType.ROLE_CONFUSION: "role or identity confusion",
            InjectionType.ENCODING_ATTACK: "encoded payload injection",
            InjectionType.MULTI_TURN: "multi-turn conversation manipulation",
        }

        types_str = ", ".join(type_descriptions.get(t, t.value) for t in detected_types[:3])

        return f"Detected {len(matched_patterns)} pattern(s) indicating {types_str}."

    def _generate_recommendation(self, injection_type: InjectionType | None, severity: str) -> str:
        """Generate remediation recommendation."""
        if not injection_type:
            return "Review input for potential security issues."

        recommendations = {
            InjectionType.DIRECT: (
                "Implement input sanitization and instruction isolation. "
                "Use delimiters to separate user input from system instructions."
            ),
            InjectionType.INDIRECT: (
                "Sanitize all external data before including in prompts. "
                "Implement content filtering for fetched documents."
            ),
            InjectionType.JAILBREAK: (
                "Strengthen system prompt guardrails. Consider using "
                "constitutional AI techniques and output filtering."
            ),
            InjectionType.CONTEXT_MANIPULATION: (
                "Limit context window exposure and implement "
                "attention anchoring in system prompts."
            ),
            InjectionType.ROLE_CONFUSION: (
                "Implement clear role boundaries and message signing. "
                "Add explicit role validation in prompts."
            ),
            InjectionType.ENCODING_ATTACK: (
                "Decode and inspect all encoded content before processing. "
                "Implement multi-layer content inspection."
            ),
            InjectionType.MULTI_TURN: (
                "Validate conversation history and implement session "
                "isolation. Do not trust claimed prior agreements."
            ),
        }

        base_rec = recommendations.get(injection_type, "Review and sanitize input.")

        if severity == "critical":
            return f"CRITICAL: {base_rec} Block this input immediately."
        elif severity == "high":
            return f"HIGH PRIORITY: {base_rec}"

        return base_rec


class MultiLayerInjectionDetector:
    """
    Multi-layer injection detection combining multiple techniques.

    Layers:
    1. Pattern matching (fast, rule-based)
    2. Semantic analysis (if available)
    3. ML classification (if model available)
    """

    def __init__(self, use_semantic: bool = True, use_ml: bool = True, strict_mode: bool = False):
        """
        Initialize the multi-layer detector.

        Args:
            use_semantic: Enable semantic analysis layer
            use_ml: Enable ML classification layer
            strict_mode: Use strict detection thresholds
        """
        self.pattern_classifier = PromptInjectionClassifier(strict_mode=strict_mode)
        self.strict_mode = strict_mode

        # Optional layers
        self.semantic_enabled = use_semantic
        self.ml_enabled = use_ml

    def detect(
        self, text: str, context: str = "", file_path: str = "", source: str = "unknown"
    ) -> InjectionClassification:
        """
        Perform multi-layer injection detection.

        Args:
            text: Text to analyze
            context: Additional context
            file_path: Path to source file (for additional context)
            source: Source of the text

        Returns:
            Combined InjectionClassification result
        """
        # Layer 1: Pattern matching
        pattern_result = self.pattern_classifier.classify(text, context, source)

        # If patterns found with high confidence, return early
        if pattern_result.is_injection and pattern_result.confidence >= 0.8:
            pattern_result.metadata["detection_layers"] = ["pattern"]
            return pattern_result

        # Layer 2: Heuristic analysis (always available)
        heuristic_score = self._heuristic_analysis(text)

        # Combine results
        combined_confidence = pattern_result.confidence
        if heuristic_score > 0.3:
            combined_confidence = max(
                combined_confidence, (pattern_result.confidence + heuristic_score) / 2
            )

        # Determine final classification
        is_injection = combined_confidence >= (0.4 if self.strict_mode else 0.5)

        return InjectionClassification(
            is_injection=is_injection,
            injection_type=pattern_result.injection_type,
            confidence=combined_confidence,
            matched_patterns=pattern_result.matched_patterns,
            explanation=pattern_result.explanation,
            recommendation=pattern_result.recommendation,
            severity=pattern_result.severity,
            metadata={
                **pattern_result.metadata,
                "detection_layers": ["pattern", "heuristic"],
                "heuristic_score": heuristic_score,
            },
        )

    def _heuristic_analysis(self, text: str) -> float:
        """
        Perform heuristic analysis for injection indicators.

        Returns a score between 0 and 1.
        """
        score = 0.0
        text_lower = text.lower()

        # Check for suspicious structures
        if text.count("\n") > 20:
            score += 0.1  # Many newlines might be padding

        if len(text) > 5000:
            score += 0.05  # Very long inputs are suspicious

        # Check for instruction-like language
        instruction_words = [
            "must",
            "shall",
            "should",
            "ignore",
            "forget",
            "override",
            "bypass",
            "disable",
            "enable",
        ]
        instruction_count = sum(1 for word in instruction_words if word in text_lower)
        score += min(instruction_count * 0.05, 0.2)

        # Check for special characters that might indicate formatting attacks
        special_sequences = [">>>", "<<<", "---", "===", "***", "```"]
        for seq in special_sequences:
            if seq in text:
                score += 0.05

        # Check for encoding indicators
        if re.search(r"base64|hex|rot13|encoded?|decode", text_lower):
            score += 0.1

        return min(score, 1.0)
