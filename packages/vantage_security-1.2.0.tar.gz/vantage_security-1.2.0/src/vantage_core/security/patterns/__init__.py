"""
Security Pattern Detection Module.

Provides AST-based pattern matching for vulnerability detection
and taint analysis for tracking sensitive data flows.
"""

from vantage_core.security.patterns.context import (
    ContextBuilder,
    DetectionContext,
    SemanticAnalyzer,
    build_finding_explanation,
    build_source_location,
)
from vantage_core.security.patterns.database import (
    PatternDatabase,
    PatternMatch,
    PatternMatcher,
    VulnerabilityPattern,
)
from vantage_core.security.patterns.sensitivity import (
    CredentialFinding,
    CredentialType,
    DataClassification,
    DataSensitivity,
    DataSensitivityClassifier,
    DataSource,
    EnhancedTaintTracker,
    ExfiltrationRisk,
    PIIFinding,
    PIIType,
    classify_data_sensitivity,
    find_exfiltration_risks,
    track_sensitive_data,
)
from vantage_core.security.patterns.taint import (
    TaintPath,
    TaintSink,
    TaintSource,
    TaintTracker,
)

__all__ = [
    # Pattern Database
    "VulnerabilityPattern",
    "PatternMatch",
    "PatternDatabase",
    "PatternMatcher",
    # Taint Analysis
    "TaintSource",
    "TaintSink",
    "TaintPath",
    "TaintTracker",
    # Data Sensitivity
    "DataSensitivityClassifier",
    "EnhancedTaintTracker",
    "DataSensitivity",
    "PIIType",
    "CredentialType",
    "PIIFinding",
    "CredentialFinding",
    "DataClassification",
    "DataSource",
    "ExfiltrationRisk",
    "classify_data_sensitivity",
    "track_sensitive_data",
    "find_exfiltration_risks",
    # Context Analysis
    "DetectionContext",
    "ContextBuilder",
    "SemanticAnalyzer",
    "build_source_location",
    "build_finding_explanation",
]
