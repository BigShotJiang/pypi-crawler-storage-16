"""
Pydantic models for YAML rule schema definition.

This module defines the schema for custom security rules using a
Semgrep-inspired YAML format with support for pattern matching,
metavariables, and taint analysis modes.

Schema Structure:
    rules:
      - id: rule-id
        message: "Description of the issue"
        severity: ERROR
        languages: [python]
        patterns:
          - pattern: <code pattern>
          - pattern-inside: <context pattern>
        metadata:
          cwe: CWE-XX
          owasp: LLMXX
        fix: "Remediation suggestion"
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator


class Severity(str, Enum):
    """Rule severity levels for findings."""

    CRITICAL = "CRITICAL"
    ERROR = "ERROR"
    HIGH = "HIGH"
    WARNING = "WARNING"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"

    def to_normalized(self) -> str:
        """Convert to normalized lowercase severity."""
        mapping = {
            "CRITICAL": "critical",
            "ERROR": "high",
            "HIGH": "high",
            "WARNING": "medium",
            "MEDIUM": "medium",
            "LOW": "low",
            "INFO": "info",
        }
        return mapping.get(self.value, "medium")


class PatternOperator(BaseModel):
    """Base class for all pattern operators."""

    class Config:
        extra = "forbid"


class Pattern(PatternOperator):
    """
    Simple pattern match.

    Matches code that exactly fits the pattern structure.
    Supports metavariables ($X) and ellipsis (...).

    Example:
        pattern: eval($X)
        pattern: cursor.execute($QUERY.format(...))
    """

    pattern: str


class PatternRegex(PatternOperator):
    """
    Regex pattern match for string literals.

    Matches string literals against a regular expression.

    Example:
        pattern-regex: "sk-[a-zA-Z0-9]{48}"
    """

    pattern_regex: str = Field(alias="pattern-regex")


class PatternInside(PatternOperator):
    """
    Contextual pattern - match must be inside this pattern.

    The main pattern only matches if it appears within code
    that matches this container pattern.

    Example:
        pattern-inside: |
          def $FUNC(...):
            ...
    """

    pattern_inside: str = Field(alias="pattern-inside")


class PatternNot(PatternOperator):
    """
    Negative pattern - must not match.

    Excludes matches where this pattern is present.

    Example:
        pattern-not: $X = sanitize($INPUT)
    """

    pattern_not: str = Field(alias="pattern-not")


class PatternNotInside(PatternOperator):
    """
    Negative contextual pattern - must not be inside this.

    Excludes matches that appear within this container pattern.

    Example:
        pattern-not-inside: |
          if validate($INPUT):
            ...
    """

    pattern_not_inside: str = Field(alias="pattern-not-inside")


class Patterns(PatternOperator):
    """
    AND composition of patterns.

    All patterns must match for the rule to trigger.

    Example:
        patterns:
          - pattern: execute($QUERY)
          - pattern-not-inside: |
              $QUERY = "..."
    """

    patterns: list[
        Pattern
        | PatternRegex
        | PatternInside
        | PatternNot
        | PatternNotInside
        | Patterns
        | PatternEither
    ]


class PatternEither(PatternOperator):
    """
    OR composition of patterns.

    At least one pattern must match for the rule to trigger.

    Example:
        pattern-either:
          - pattern: eval($X)
          - pattern: exec($X)
          - pattern: compile($X)
    """

    pattern_either: list[
        Pattern
        | PatternRegex
        | PatternInside
        | PatternNot
        | PatternNotInside
        | Patterns
        | PatternEither
    ] = Field(alias="pattern-either")


# Enable forward references for recursive types
Patterns.model_rebuild()
PatternEither.model_rebuild()


class MetavariableFilter(BaseModel):
    """
    Filter on captured metavariables.

    Applies additional constraints on metavariable values.

    Example:
        metavariable-regex:
          metavariable: $KEY
          regex: "^sk-"
        metavariable-comparison:
          metavariable: $NUM
          comparison: "> 100"
    """

    metavariable: str
    regex: str | None = None
    comparison: str | None = None


class TaintSourceDef(BaseModel):
    """
    Taint source definition for taint-mode rules.

    Defines where tainted data originates.

    Example:
        sources:
          - pattern: request.args.get(...)
            label: user_input
    """

    pattern: str
    label: str | None = None


class TaintSinkDef(BaseModel):
    """
    Taint sink definition for taint-mode rules.

    Defines where tainted data is dangerous.

    Example:
        sinks:
          - pattern: cursor.execute($QUERY)
            requires_label: user_input
    """

    pattern: str
    label: str | None = None
    requires_label: str | None = Field(default=None, alias="requires-label")


class TaintSanitizerDef(BaseModel):
    """
    Taint sanitizer definition for taint-mode rules.

    Defines functions that clean tainted data.

    Example:
        sanitizers:
          - pattern: escape_html($X)
    """

    pattern: str


class TaintMode(BaseModel):
    """
    Taint analysis rule configuration.

    Defines sources, sinks, and sanitizers for taint tracking.

    Example:
        mode: taint
        taint:
          sources:
            - pattern: request.form.get(...)
          sinks:
            - pattern: cursor.execute($QUERY)
          sanitizers:
            - pattern: parameterize($X)
    """

    sources: list[TaintSourceDef]
    sinks: list[TaintSinkDef]
    sanitizers: list[TaintSanitizerDef] = Field(default_factory=list)


class Rule(BaseModel):
    """
    Complete rule definition.

    Supports both pattern-matching and taint-analysis modes.

    Example YAML:
        rules:
          - id: python-sql-injection
            message: "Possible SQL injection via string formatting"
            severity: ERROR
            languages: [python]
            patterns:
              - pattern: cursor.execute($QUERY.format(...))
              - pattern-not-inside: |
                  $QUERY = "..."
            metadata:
              cwe: CWE-89
              owasp: LLM01
            fix: "Use parameterized queries instead"
    """

    id: str
    message: str
    severity: Severity
    languages: list[str]

    # Pattern matching (one required unless taint mode)
    pattern: str | None = None
    patterns: (
        list[
            Pattern
            | PatternRegex
            | PatternInside
            | PatternNot
            | PatternNotInside
            | Patterns
            | PatternEither
        ]
        | None
    ) = None
    pattern_either: (
        list[
            Pattern
            | PatternRegex
            | PatternInside
            | PatternNot
            | PatternNotInside
            | Patterns
            | PatternEither
        ]
        | None
    ) = Field(default=None, alias="pattern-either")

    # Taint mode (alternative to patterns)
    mode: str | None = None
    taint: TaintMode | None = None

    # Filters
    metavariable_regex: list[MetavariableFilter] | None = Field(
        default=None, alias="metavariable-regex"
    )
    metavariable_comparison: list[MetavariableFilter] | None = Field(
        default=None, alias="metavariable-comparison"
    )

    # Metadata
    metadata: dict[str, Any] = Field(default_factory=dict)
    fix: str | None = None

    class Config:
        populate_by_name = True
        extra = "ignore"

    @field_validator("id")
    @classmethod
    def validate_id(cls, v: str) -> str:
        """Validate rule ID format."""
        if not v:
            raise ValueError("Rule ID cannot be empty")
        # Allow alphanumeric, hyphens, underscores
        clean_id = v.replace("-", "").replace("_", "")
        if not clean_id.replace(".", "").isalnum():
            raise ValueError(f"Rule ID must be alphanumeric with hyphens/underscores: {v}")
        return v

    @field_validator("languages")
    @classmethod
    def validate_languages(cls, v: list[str]) -> list[str]:
        """Validate that at least one language is specified."""
        if not v:
            raise ValueError("At least one language must be specified")
        return [lang.lower() for lang in v]

    @property
    def is_taint_rule(self) -> bool:
        """Check if this is a taint-mode rule."""
        return self.mode == "taint" and self.taint is not None

    @property
    def has_pattern(self) -> bool:
        """Check if rule has any pattern defined."""
        return any(
            [
                self.pattern,
                self.patterns,
                self.pattern_either,
            ]
        )

    def get_cwe(self) -> str | None:
        """Get CWE identifier from metadata."""
        return self.metadata.get("cwe")

    def get_owasp(self) -> str | None:
        """Get OWASP category from metadata."""
        return self.metadata.get("owasp")

    def get_category(self) -> str | None:
        """Get vulnerability category from metadata."""
        return self.metadata.get("category")


class RuleFile(BaseModel):
    """
    Collection of rules in a YAML file.

    The root structure of a rule YAML file.

    Example:
        rules:
          - id: rule-1
            ...
          - id: rule-2
            ...
    """

    rules: list[Rule]

    @field_validator("rules")
    @classmethod
    def validate_unique_ids(cls, v: list[Rule]) -> list[Rule]:
        """Validate that all rule IDs are unique within the file."""
        ids = [rule.id for rule in v]
        duplicates = [id_ for id_ in ids if ids.count(id_) > 1]
        if duplicates:
            raise ValueError(f"Duplicate rule IDs in file: {set(duplicates)}")
        return v
