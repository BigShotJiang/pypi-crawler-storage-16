"""
Anthropic Security Scanner.

Detects Claude agents, tool definitions, and message patterns in Anthropic-based projects.
"""

import ast
import time
from pathlib import Path

from vantage_core.security.models import (
    AgentCommunication,
    CommunicationType,
    ContentType,
    SecurityAgent,
    SecurityFinding,
    SecurityScanResult,
    SecurityTool,
    ToolCategory,
    TrustLevel,
)
from vantage_core.security.scanners.base import SecurityScanner


class AnthropicSecurityScanner(SecurityScanner):
    """
    Security scanner for Anthropic Claude API.

    Detects:
    - Agent definitions (implicit via messages.create)
    - Tool definitions
    - System prompts
    """

    framework_name = "anthropic"

    def scan(self, path: Path) -> SecurityScanResult:
        """Scan Anthropic project for security issues."""
        start_time = time.time()
        findings: list[SecurityFinding] = []
        agents: list[SecurityAgent] = []
        communications: list[AgentCommunication] = []

        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()

                file_agents = self._extract_agents_from_file(file_path, code)
                agents.extend(file_agents)

                file_communications = self._extract_communications(file_path, code)
                communications.extend(file_communications)

                findings.extend(self.check_hardcoded_secrets(code, str(file_path)))
                findings.extend(self.check_dangerous_code_patterns(code, str(file_path)))

                for agent in file_agents:
                    agent_findings = self.get_vulnerabilities(agent)
                    findings.extend(agent_findings)

            except Exception:
                continue

        return self.create_scan_result(
            findings=findings,
            agents=agents,
            communications=communications,
            frameworks=["anthropic"],
            start_time=start_time,
        )

    def get_agents(self, path: Path) -> list[SecurityAgent]:
        """Extract Anthropic agents from path."""
        agents: list[SecurityAgent] = []
        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()
                agents.extend(self._extract_agents_from_file(file_path, code))
            except Exception:
                continue
        return agents

    def get_vulnerabilities(self, agent: SecurityAgent) -> list[SecurityFinding]:
        """Analyze Anthropic agent for vulnerabilities."""
        findings: list[SecurityFinding] = []
        file_path = agent.file_path or "unknown"
        line_number = agent.line_number or 1

        if agent.system_prompt:
            finding = self.check_prompt_injection_risk(
                agent.system_prompt, file_path, line_number, agent.id
            )
            if finding:
                findings.append(finding)

        return findings

    def _extract_agents_from_file(self, file_path: Path, code: str) -> list[SecurityAgent]:
        """Extract Anthropic agents from a single file."""
        agents: list[SecurityAgent] = []
        tree = ast.parse(code)

        class AgentVisitor(ast.NodeVisitor):
            def __init__(self, scanner: AnthropicSecurityScanner):
                self.scanner = scanner
                self.agents: list[SecurityAgent] = []

            def visit_Call(self, node: ast.Call) -> None:
                func_name = self._get_func_name(node)

                # client.messages.create
                if "messages.create" in func_name:
                    agent = self._extract_agent_from_call(node)
                    if agent:
                        self.agents.append(agent)

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return self._get_attr_name(node.func)
                return ""

            def _get_attr_name(self, node: ast.Attribute) -> str:
                if isinstance(node.value, ast.Name):
                    return f"{node.value.id}.{node.attr}"
                elif isinstance(node.value, ast.Attribute):
                    return f"{self._get_attr_name(node.value)}.{node.attr}"
                return node.attr

            def _extract_agent_from_call(self, node: ast.Call) -> SecurityAgent | None:
                name = "Claude Agent"
                system_prompt = None
                tools: list[SecurityTool] = []

                for keyword in node.keywords:
                    if keyword.arg == "system":
                        if isinstance(keyword.value, ast.Constant):
                            system_prompt = str(keyword.value.value)
                    elif keyword.arg == "tools":
                        tools = self._extract_tools(keyword.value)
                    elif keyword.arg == "model":
                        if isinstance(keyword.value, ast.Constant):
                            name = f"Claude ({keyword.value.value})"

                agent_id = f"anthropic-{name}-{node.lineno}"

                return SecurityAgent(
                    id=agent_id,
                    name=name,
                    framework="anthropic",
                    system_prompt=system_prompt,
                    tools=tools,
                    file_path=str(file_path),
                    line_number=node.lineno,
                    trust_level=self.scanner.infer_trust_level(
                        {"name": name, "system_prompt": system_prompt or ""}
                    ),
                    metadata={"type": "claude_agent"},
                )

            def _extract_tools(self, node: ast.AST) -> list[SecurityTool]:
                tools: list[SecurityTool] = []
                if isinstance(node, ast.List):
                    for elt in node.elts:
                        if isinstance(elt, ast.Dict):
                            tool_name = "unknown"
                            description = ""
                            for k, v in zip(elt.keys, elt.values):
                                if isinstance(k, ast.Constant):
                                    if k.value == "name" and isinstance(v, ast.Constant):
                                        tool_name = v.value
                                    elif k.value == "description" and isinstance(v, ast.Constant):
                                        description = v.value

                            tools.append(
                                SecurityTool(
                                    name=tool_name,
                                    description=description,
                                    categories=[ToolCategory.API],
                                    required_trust_level=TrustLevel.INTERNAL,
                                )
                            )
                return tools

        visitor = AgentVisitor(self)
        visitor.visit(tree)
        return visitor.agents

    def _extract_communications(self, file_path: Path, code: str) -> list[AgentCommunication]:
        """Extract communications from Anthropic code."""
        communications: list[AgentCommunication] = []
        tree = ast.parse(code)

        class CommunicationVisitor(ast.NodeVisitor):
            def __init__(self):
                self.comms: list[AgentCommunication] = []

            def visit_Call(self, node: ast.Call) -> None:
                func_name = self._get_func_name(node)

                # messages.create
                if "messages.create" in func_name:
                    agent_name = "Claude Agent"
                    tools = []

                    for keyword in node.keywords:
                        if keyword.arg == "model" and isinstance(keyword.value, ast.Constant):
                            agent_name = f"Claude ({keyword.value.value})"
                        elif keyword.arg == "tools":
                            tools = self._extract_tool_names(keyword.value)

                    agent_id = f"anthropic-{agent_name}-{node.lineno}"

                    for tool in tools:
                        # Agent -> Tool
                        self.comms.append(
                            AgentCommunication(
                                source_id=agent_name,
                                target_id=tool,
                                communication_type=CommunicationType.DELEGATION.value,
                                metadata={
                                    "protocol": "tool_call",
                                    "content_type": ContentType.TEXT.value,
                                    "file_path": str(file_path),
                                    "line_number": node.lineno,
                                },
                            )
                        )

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return self._get_attr_name(node.func)
                return ""

            def _get_attr_name(self, node: ast.Attribute) -> str:
                if isinstance(node.value, ast.Name):
                    return f"{node.value.id}.{node.attr}"
                elif isinstance(node.value, ast.Attribute):
                    return f"{self._get_attr_name(node.value)}.{node.attr}"
                return node.attr

            def _extract_tool_names(self, node: ast.AST) -> list[str]:
                names = []
                if isinstance(node, ast.List):
                    for elt in node.elts:
                        if isinstance(elt, ast.Dict):
                            for k, v in zip(elt.keys, elt.values):
                                if isinstance(k, ast.Constant) and k.value == "name":
                                    if isinstance(v, ast.Constant):
                                        names.append(v.value)
                return names

        visitor = CommunicationVisitor()
        visitor.visit(tree)
        return visitor.comms

    @classmethod
    def can_handle(cls, path: Path) -> bool:
        """Check if this scanner can handle Anthropic projects."""
        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    content = f.read()
                    if any(x in content for x in ["from anthropic", "import anthropic"]):
                        return True
            except Exception:
                continue

        return False
