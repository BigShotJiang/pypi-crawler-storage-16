"""
Trust Boundary Score (US-122).

Scores the security posture based on trust boundary crossings
and privilege escalation paths in the agent topology.
"""

from dataclasses import dataclass, field

from vantage_core.security.models import Severity, TrustLevel
from vantage_core.security.topology.graph import AgentGraph
from vantage_core.security.trust.boundaries import (
    BoundaryAnalyzer,
    BoundaryCrossing,
    EscalationPath,
)


@dataclass
class TrustBoundaryScore:
    """
    Score based on trust boundary analysis.

    Higher score means better security posture (fewer violations).
    """

    score: float  # 0-100, higher is more secure
    total_crossings: int
    high_risk_crossings: int
    escalation_paths: int
    shortest_escalation: int  # Hop count
    penalties: dict[str, float] = field(default_factory=dict)
    recommendations: list[str] = field(default_factory=list)

    @property
    def has_critical_paths(self) -> bool:
        """Check if there are critical escalation paths."""
        return self.shortest_escalation == 1 or self.high_risk_crossings > 3


class TrustBoundaryScorer:
    """
    Scores topology based on trust boundary violations.

    Analyzes boundary crossings and escalation paths to produce
    a normalized security score.
    """

    # Penalty weights for different violation types
    PENALTIES = {
        "crossing_per_agent": 2.0,  # Per crossing penalty
        "high_risk_crossing": 8.0,  # High-risk crossing penalty
        "escalation_path": 5.0,  # Per escalation path
        "direct_escalation": 15.0,  # Direct (1-hop) escalation
        "critical_to_external": 20.0,  # SYSTEM/PRIVILEGED to EXTERNAL
        "code_execution_boundary": 10.0,  # Code exec across boundary
        "sensitive_data_crossing": 6.0,  # Confidential/secret data
    }

    def __init__(
        self,
        penalties: dict[str, float] | None = None,
    ):
        """
        Initialize the scorer.

        Args:
            penalties: Custom penalty weights
        """
        self.penalties = penalties or self.PENALTIES

    def score(self, graph: AgentGraph) -> TrustBoundaryScore:
        """
        Calculate trust boundary score for a graph.

        Args:
            graph: Agent topology graph

        Returns:
            TrustBoundaryScore with details
        """
        if graph.node_count == 0:
            return TrustBoundaryScore(
                score=100.0,
                total_crossings=0,
                high_risk_crossings=0,
                escalation_paths=0,
                shortest_escalation=0,
            )

        analyzer = BoundaryAnalyzer(graph)
        crossings = analyzer.find_crossings()
        escalation_paths = analyzer.find_escalation_paths()

        # Calculate penalties
        penalties: dict[str, float] = {}
        total_penalty = 0.0

        # Penalty for total crossings normalized by agent count
        crossing_penalty = (len(crossings) / max(graph.node_count, 1)) * self.penalties[
            "crossing_per_agent"
        ]
        penalties["boundary_crossings"] = round(crossing_penalty, 2)
        total_penalty += crossing_penalty

        # Penalty for high-risk crossings
        high_risk_count = 0
        sensitive_data_count = 0
        code_exec_boundary = 0
        critical_external = 0

        for crossing in crossings:
            # Check severity
            if crossing.severity in [Severity.CRITICAL, Severity.HIGH]:
                high_risk_count += 1

            # Check for sensitive data
            if crossing.data_sensitivity in ["confidential", "secret"]:
                sensitive_data_count += 1

            # Check for code execution crossing boundary
            target_node = graph.get_node(crossing.target_agent)
            if target_node and target_node.has_code_execution and crossing.is_elevation:
                code_exec_boundary += 1

            # Check for critical to external
            if (
                crossing.source_trust.value >= TrustLevel.PRIVILEGED.value
                and crossing.target_trust.value <= TrustLevel.EXTERNAL.value
            ):
                critical_external += 1

        # Apply penalties
        if high_risk_count > 0:
            penalty = high_risk_count * self.penalties["high_risk_crossing"]
            penalties["high_risk_crossings"] = round(penalty, 2)
            total_penalty += penalty

        if sensitive_data_count > 0:
            penalty = sensitive_data_count * self.penalties["sensitive_data_crossing"]
            penalties["sensitive_data"] = round(penalty, 2)
            total_penalty += penalty

        if code_exec_boundary > 0:
            penalty = code_exec_boundary * self.penalties["code_execution_boundary"]
            penalties["code_execution_boundary"] = round(penalty, 2)
            total_penalty += penalty

        if critical_external > 0:
            penalty = critical_external * self.penalties["critical_to_external"]
            penalties["critical_to_external"] = round(penalty, 2)
            total_penalty += penalty

        # Penalty for escalation paths
        shortest_escalation = 0
        direct_escalations = 0

        if escalation_paths:
            # Count direct escalations
            direct_escalations = sum(1 for p in escalation_paths if p.is_direct)

            # Find shortest
            shortest_path = min(escalation_paths, key=lambda p: p.hop_count)
            shortest_escalation = shortest_path.hop_count

            # Path penalties
            path_penalty = len(escalation_paths) * self.penalties["escalation_path"]
            penalties["escalation_paths"] = round(path_penalty, 2)
            total_penalty += path_penalty

            # Direct escalation penalty
            if direct_escalations > 0:
                direct_penalty = direct_escalations * self.penalties["direct_escalation"]
                penalties["direct_escalations"] = round(direct_penalty, 2)
                total_penalty += direct_penalty

        # Calculate final score (0-100)
        max_penalty = 100.0  # Cap at 100 for normalization
        score = max(0.0, 100.0 - min(total_penalty, max_penalty))

        # Generate recommendations
        recommendations = self._generate_recommendations(
            crossings,
            escalation_paths,
            graph,
        )

        return TrustBoundaryScore(
            score=round(score, 2),
            total_crossings=len(crossings),
            high_risk_crossings=high_risk_count,
            escalation_paths=len(escalation_paths),
            shortest_escalation=shortest_escalation,
            penalties=penalties,
            recommendations=recommendations,
        )

    def _generate_recommendations(
        self,
        crossings: list[BoundaryCrossing],
        escalation_paths: list[EscalationPath],
        graph: AgentGraph,
    ) -> list[str]:
        """Generate actionable recommendations."""
        recommendations = []

        # Prioritize by impact
        if any(p.is_direct for p in escalation_paths):
            recommendations.append(
                "CRITICAL: Direct privilege escalation paths exist. "
                "Add intermediate validation layers."
            )

        # Check for sensitive data issues
        sensitive_crossings = [
            c for c in crossings if c.data_sensitivity in ["confidential", "secret"]
        ]
        if sensitive_crossings:
            recommendations.append(
                f"High-priority: {len(sensitive_crossings)} crossings involve sensitive data. "
                "Implement encryption and access controls."
            )

        # Check for code execution risks
        code_exec_risks = [
            c
            for c in crossings
            if c.is_elevation
            and graph.get_node(c.target_agent)
            and graph.get_node(c.target_agent).has_code_execution
        ]
        if code_exec_risks:
            recommendations.append(
                f"Warning: {len(code_exec_risks)} trust elevations to code-executing agents. "
                "Add input sanitization and sandboxing."
            )

        # General recommendations based on counts
        if len(crossings) > graph.node_count * 2:
            recommendations.append(
                "Consider consolidating agents into fewer trust zones to reduce boundary crossings."
            )

        if len(escalation_paths) > 5:
            recommendations.append(
                "Multiple escalation paths detected. Identify and harden chokepoints."
            )

        return recommendations


def calculate_trust_boundary_score(graph: AgentGraph) -> TrustBoundaryScore:
    """
    Convenience function to calculate trust boundary score.

    Args:
        graph: Agent topology graph

    Returns:
        TrustBoundaryScore
    """
    scorer = TrustBoundaryScorer()
    return scorer.score(graph)
