"""
Trust Laundering Detection.

US-117: Trust Laundering Detection - Detect routing through intermediates
to bypass boundaries, multi-hop trust escalation.

Trust laundering occurs when data is routed through intermediate agents
to make untrusted data appear trusted, bypassing security checks.
"""

from dataclasses import dataclass, field
from typing import Any

from vantage_core.security.models import Severity, TrustLevel
from vantage_core.security.topology.graph import AgentGraph


@dataclass
class LaunderingPath:
    """
    Represents a detected trust laundering path.

    Trust laundering uses intermediary agents to elevate trust
    without proper validation at each step.
    """

    path: list[str]  # Agent IDs from source to destination
    start_trust: TrustLevel
    end_trust: TrustLevel
    intermediaries: list[str]  # Agents acting as launderers
    trust_gain: int  # Total trust level increase
    laundering_score: float  # 0-1 severity score
    severity: Severity = Severity.HIGH
    pattern_type: str = "simple"  # simple, chained, circular
    evidence: list[str] = field(default_factory=list)
    recommendation: str = ""

    @property
    def hop_count(self) -> int:
        """Get the number of hops in the path."""
        return len(self.path) - 1

    @property
    def is_severe(self) -> bool:
        """Check if this is a severe laundering pattern."""
        return self.laundering_score >= 0.7


@dataclass
class LaunderingIndicator:
    """Intermediate analysis result for potential laundering."""

    agent_id: str
    incoming_trust: TrustLevel
    outgoing_trust: TrustLevel
    trust_elevation: int
    input_sources: list[str]
    output_targets: list[str]


class LaunderingDetector:
    """
    Detect trust laundering patterns in agent topologies.

    Identifies agents that receive low-trust input and produce
    high-trust output without proper validation.
    """

    def __init__(self, graph: AgentGraph):
        """
        Initialize the laundering detector.

        Args:
            graph: AgentGraph to analyze
        """
        self.graph = graph

    def detect_laundering(self) -> list[LaunderingPath]:
        """
        Detect all trust laundering paths in the graph.

        Returns:
            List of LaunderingPath objects sorted by severity
        """
        laundering_paths = []

        # Find potential launderer agents
        launderers = self._find_potential_launderers()

        for launderer in launderers:
            # Trace paths through this launderer
            paths = self._trace_laundering_paths(launderer)
            laundering_paths.extend(paths)

        # Check for chained laundering
        chained = self._detect_chained_laundering()
        laundering_paths.extend(chained)

        # Check for circular laundering
        circular = self._detect_circular_laundering()
        laundering_paths.extend(circular)

        # Sort by severity
        laundering_paths.sort(key=lambda p: (p.severity.value, -p.laundering_score), reverse=False)

        return laundering_paths

    def find_launderer_agents(self) -> list[str]:
        """
        Find agents that may be acting as trust launderers.

        Returns:
            List of agent IDs that are potential launderers
        """
        launderers = []

        for node in self.graph.nodes:
            # Check if agent receives from lower trust and sends to higher trust
            incoming_trusts = []
            outgoing_trusts = []

            for pred_id in self.graph.get_predecessors(node.id):
                pred = self.graph.get_node(pred_id)
                if pred:
                    incoming_trusts.append(pred.trust_level.value)

            for succ_id in self.graph.get_neighbors(node.id):
                succ = self.graph.get_node(succ_id)
                if succ:
                    outgoing_trusts.append(succ.trust_level.value)

            if incoming_trusts and outgoing_trusts:
                min_incoming = min(incoming_trusts)
                max_outgoing = max(outgoing_trusts)

                # Launderer if receiving low trust and sending high trust
                if min_incoming < node.trust_level.value <= max_outgoing:
                    launderers.append(node.id)

        return launderers

    def analyze_agent_laundering_risk(self, agent_id: str) -> dict[str, Any]:
        """
        Analyze laundering risk for a specific agent.

        Args:
            agent_id: Agent to analyze

        Returns:
            Dictionary of laundering risk metrics
        """
        node = self.graph.get_node(agent_id)
        if not node:
            return {}

        # Collect trust levels of connected agents
        incoming_trusts = []
        outgoing_trusts = []

        for pred_id in self.graph.get_predecessors(agent_id):
            pred = self.graph.get_node(pred_id)
            if pred:
                incoming_trusts.append(pred.trust_level.value)

        for succ_id in self.graph.get_neighbors(agent_id):
            succ = self.graph.get_node(succ_id)
            if succ:
                outgoing_trusts.append(succ.trust_level.value)

        # Calculate metrics
        min_incoming = min(incoming_trusts) if incoming_trusts else node.trust_level.value
        max_outgoing = max(outgoing_trusts) if outgoing_trusts else node.trust_level.value

        trust_amplification = max_outgoing - min_incoming
        is_launderer = min_incoming < node.trust_level.value <= max_outgoing

        # Calculate risk score
        risk_score = 0.0
        if is_launderer:
            risk_score = min(trust_amplification * 0.3, 1.0)
            if len(self.graph.get_predecessors(agent_id)) > 2:
                risk_score += 0.2  # Multiple low-trust inputs

        return {
            "agent_id": agent_id,
            "trust_level": node.trust_level.name,
            "min_incoming_trust": min_incoming,
            "max_outgoing_trust": max_outgoing,
            "trust_amplification": trust_amplification,
            "is_potential_launderer": is_launderer,
            "laundering_risk_score": risk_score,
        }

    def get_laundering_statistics(self) -> dict[str, Any]:
        """
        Get overall laundering statistics for the graph.

        Returns:
            Dictionary of laundering statistics
        """
        all_paths = self.detect_laundering()

        # Count by pattern type
        pattern_counts = {}
        for path in all_paths:
            pattern_counts[path.pattern_type] = pattern_counts.get(path.pattern_type, 0) + 1

        # Count by severity
        severity_counts = {sev: 0 for sev in Severity}
        for path in all_paths:
            severity_counts[path.severity] += 1

        # Find most common intermediaries
        intermediary_counts: dict[str, int] = {}
        for path in all_paths:
            for intermediary in path.intermediaries:
                intermediary_counts[intermediary] = intermediary_counts.get(intermediary, 0) + 1

        return {
            "total_paths": len(all_paths),
            "by_pattern_type": pattern_counts,
            "by_severity": {sev.name: count for sev, count in severity_counts.items()},
            "top_intermediaries": sorted(
                intermediary_counts.items(), key=lambda x: x[1], reverse=True
            )[:5],
            "average_laundering_score": (
                sum(p.laundering_score for p in all_paths) / len(all_paths) if all_paths else 0.0
            ),
        }

    def _find_potential_launderers(self) -> list[LaunderingIndicator]:
        """Find agents that act as potential launderers."""
        indicators = []

        for node in self.graph.nodes:
            incoming_trusts = []
            outgoing_trusts = []
            input_sources = []
            output_targets = []

            for pred_id in self.graph.get_predecessors(node.id):
                pred = self.graph.get_node(pred_id)
                if pred:
                    incoming_trusts.append(pred.trust_level.value)
                    input_sources.append(pred_id)

            for succ_id in self.graph.get_neighbors(node.id):
                succ = self.graph.get_node(succ_id)
                if succ:
                    outgoing_trusts.append(succ.trust_level.value)
                    output_targets.append(succ_id)

            if not incoming_trusts or not outgoing_trusts:
                continue

            min_incoming = min(incoming_trusts)
            max_outgoing = max(outgoing_trusts)

            # Check for trust amplification
            if min_incoming < node.trust_level.value and node.trust_level.value <= max_outgoing:
                indicator = LaunderingIndicator(
                    agent_id=node.id,
                    incoming_trust=TrustLevel(min_incoming),
                    outgoing_trust=TrustLevel(max_outgoing),
                    trust_elevation=max_outgoing - min_incoming,
                    input_sources=input_sources,
                    output_targets=output_targets,
                )
                indicators.append(indicator)

        return indicators

    def _trace_laundering_paths(self, launderer: LaunderingIndicator) -> list[LaunderingPath]:
        """Trace complete laundering paths through a launderer."""
        paths = []

        # For each low-trust input
        for source_id in launderer.input_sources:
            source = self.graph.get_node(source_id)
            if not source or source.trust_level.value >= launderer.incoming_trust.value + 1:
                continue

            # For each high-trust output
            for target_id in launderer.output_targets:
                target = self.graph.get_node(target_id)
                if not target or target.trust_level.value <= launderer.outgoing_trust.value - 1:
                    continue

                # Calculate laundering score
                trust_gain = target.trust_level.value - source.trust_level.value
                laundering_score = self._calculate_laundering_score(
                    trust_gain,
                    1,
                    source.trust_level,
                    target.trust_level,  # Single launderer
                )

                # Determine severity
                severity = self._determine_severity(laundering_score, trust_gain)

                path = LaunderingPath(
                    path=[source_id, launderer.agent_id, target_id],
                    start_trust=source.trust_level,
                    end_trust=target.trust_level,
                    intermediaries=[launderer.agent_id],
                    trust_gain=trust_gain,
                    laundering_score=laundering_score,
                    severity=severity,
                    pattern_type="simple",
                    evidence=[
                        f"Trust gain of {trust_gain} levels through single intermediary",
                        f"Path: {source_id} ({source.trust_level.name}) -> "
                        f"{launderer.agent_id} -> "
                        f"{target_id} ({target.trust_level.name})",
                    ],
                    recommendation=self._generate_recommendation(
                        "simple", [launderer.agent_id], trust_gain
                    ),
                )
                paths.append(path)

        return paths

    def _detect_chained_laundering(self) -> list[LaunderingPath]:
        """Detect chained laundering through multiple intermediaries."""
        chained_paths = []

        # Find all paths with trust elevation through multiple hops
        entry_points = [n for n in self.graph.nodes if n.trust_level.value <= TrustLevel.USER.value]

        targets = [
            n for n in self.graph.nodes if n.trust_level.value >= TrustLevel.PRIVILEGED.value
        ]

        for entry in entry_points:
            for target in targets:
                paths = self.graph.find_paths(entry.id, target.id, max_depth=5)

                for path in paths:
                    if len(path) < 3:  # Need at least one intermediary
                        continue

                    # Analyze trust elevation pattern
                    trust_levels = []
                    for agent_id in path:
                        node = self.graph.get_node(agent_id)
                        if node:
                            trust_levels.append(node.trust_level.value)

                    # Check for gradual elevation (laundering pattern)
                    if self._is_gradual_elevation(trust_levels):
                        intermediaries = path[1:-1]
                        trust_gain = trust_levels[-1] - trust_levels[0]

                        laundering_score = self._calculate_laundering_score(
                            trust_gain,
                            len(intermediaries),
                            entry.trust_level,
                            target.trust_level,
                        )

                        severity = self._determine_severity(laundering_score, trust_gain)

                        chained_path = LaunderingPath(
                            path=path,
                            start_trust=entry.trust_level,
                            end_trust=target.trust_level,
                            intermediaries=intermediaries,
                            trust_gain=trust_gain,
                            laundering_score=laundering_score,
                            severity=severity,
                            pattern_type="chained",
                            evidence=[
                                f"Gradual trust elevation through {len(intermediaries)} intermediaries",
                                f"Trust levels: {' -> '.join(str(t) for t in trust_levels)}",
                            ],
                            recommendation=self._generate_recommendation(
                                "chained", intermediaries, trust_gain
                            ),
                        )
                        chained_paths.append(chained_path)

        return chained_paths

    def _detect_circular_laundering(self) -> list[LaunderingPath]:
        """Detect circular trust laundering patterns."""
        circular_paths = []

        # Find cycles in the graph
        visited = set()
        rec_stack = set()

        def find_cycles(node_id: str, path: list[str]) -> list[list[str]]:
            cycles = []
            visited.add(node_id)
            rec_stack.add(node_id)
            path.append(node_id)

            for neighbor in self.graph.get_neighbors(node_id):
                if neighbor not in visited:
                    cycles.extend(find_cycles(neighbor, path.copy()))
                elif neighbor in rec_stack:
                    # Found a cycle
                    cycle_start = path.index(neighbor)
                    cycle = path[cycle_start:] + [neighbor]
                    cycles.append(cycle)

            rec_stack.discard(node_id)
            return cycles

        # Find all cycles
        all_cycles = []
        for node in self.graph.nodes:
            if node.id not in visited:
                all_cycles.extend(find_cycles(node.id, []))

        # Analyze cycles for laundering
        for cycle in all_cycles:
            if len(cycle) < 3:
                continue

            # Get trust levels in cycle
            trust_levels = []
            for agent_id in cycle[:-1]:  # Exclude duplicate end node
                node = self.graph.get_node(agent_id)
                if node:
                    trust_levels.append(node.trust_level.value)

            if not trust_levels:
                continue

            # Check if cycle includes trust variation
            if max(trust_levels) - min(trust_levels) >= 1:
                trust_gain = max(trust_levels) - min(trust_levels)
                intermediaries = cycle[1:-1]

                laundering_score = (
                    self._calculate_laundering_score(
                        trust_gain,
                        len(intermediaries),
                        TrustLevel(min(trust_levels)),
                        TrustLevel(max(trust_levels)),
                    )
                    + 0.2
                )  # Penalty for circular pattern

                severity = Severity.CRITICAL if laundering_score > 0.8 else Severity.HIGH

                circular_path = LaunderingPath(
                    path=cycle,
                    start_trust=TrustLevel(min(trust_levels)),
                    end_trust=TrustLevel(max(trust_levels)),
                    intermediaries=intermediaries,
                    trust_gain=trust_gain,
                    laundering_score=min(laundering_score, 1.0),
                    severity=severity,
                    pattern_type="circular",
                    evidence=[
                        f"Circular trust laundering with {len(cycle) - 1} agents",
                        "Data can cycle indefinitely through trust levels",
                    ],
                    recommendation=self._generate_recommendation(
                        "circular", intermediaries, trust_gain
                    ),
                )
                circular_paths.append(circular_path)

        return circular_paths

    def _is_gradual_elevation(self, trust_levels: list[int]) -> bool:
        """Check if trust levels show gradual elevation pattern."""
        if len(trust_levels) < 3:
            return False

        # Check for monotonic or near-monotonic increase
        increases = 0
        for i in range(1, len(trust_levels)):
            if trust_levels[i] > trust_levels[i - 1]:
                increases += 1

        # At least half the steps should increase
        return increases >= len(trust_levels) // 2

    def _calculate_laundering_score(
        self,
        trust_gain: int,
        intermediary_count: int,
        start_trust: TrustLevel,
        end_trust: TrustLevel,
    ) -> float:
        """Calculate a laundering severity score."""
        # Base score on trust gain
        score = min(trust_gain * 0.25, 0.75)

        # More intermediaries = more laundering
        score += min(intermediary_count * 0.1, 0.2)

        # Higher penalty for reaching system level
        if end_trust == TrustLevel.SYSTEM:
            score += 0.15
        elif end_trust == TrustLevel.PRIVILEGED:
            score += 0.1

        # Higher penalty for starting from external
        if start_trust == TrustLevel.EXTERNAL:
            score += 0.1

        return min(score, 1.0)

    def _determine_severity(self, laundering_score: float, trust_gain: int) -> Severity:
        """Determine severity level from score and trust gain."""
        if laundering_score >= 0.8 or trust_gain >= 4:
            return Severity.CRITICAL
        elif laundering_score >= 0.6 or trust_gain >= 3:
            return Severity.HIGH
        elif laundering_score >= 0.4 or trust_gain >= 2:
            return Severity.MEDIUM
        else:
            return Severity.LOW

    def _generate_recommendation(
        self, pattern_type: str, intermediaries: list[str], trust_gain: int
    ) -> str:
        """Generate recommendation for addressing laundering."""
        recommendations = []

        if pattern_type == "simple":
            if intermediaries:
                recommendations.append(
                    f"Add trust verification at {intermediaries[0]} before forwarding data"
                )
            recommendations.append(
                "Implement data provenance tracking to maintain original trust level"
            )

        elif pattern_type == "chained":
            recommendations.append(
                "Break the laundering chain by requiring re-validation at each trust boundary"
            )
            if len(intermediaries) > 2:
                recommendations.append(
                    f"Review why {len(intermediaries)} intermediaries are needed"
                )

        elif pattern_type == "circular":
            recommendations.append(
                "Eliminate circular data flow to prevent infinite trust laundering"
            )
            recommendations.append("Add cycle detection and maximum iteration limits")

        if trust_gain >= 3:
            recommendations.append("Consider architectural changes to reduce trust differential")

        return "; ".join(recommendations)


def detect_trust_laundering(graph: AgentGraph) -> list[LaunderingPath]:
    """
    Convenience function to detect trust laundering.

    Args:
        graph: AgentGraph to analyze

    Returns:
        List of LaunderingPath objects
    """
    detector = LaunderingDetector(graph)
    return detector.detect_laundering()
