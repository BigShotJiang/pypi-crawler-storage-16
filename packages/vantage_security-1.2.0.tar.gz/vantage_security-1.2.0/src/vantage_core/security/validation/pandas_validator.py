"""
Pandas Query Validation and Sanitization.

Provides security validation for Pandas DataFrame.query() expressions
to prevent code injection attacks.

IMPORTANT: CVE-2024-9880 demonstrates that DataFrame.query() is
fundamentally unsafe for untrusted input because it uses eval()
internally. This module provides best-effort validation but the
only truly safe approach is to avoid query() with untrusted input.

Key features:
- AST-based validation of query expressions
- Allowlist of safe operations
- Detection of dangerous patterns
- Alternative safe filtering approaches

References:
- CVE-2024-9880: Pandas DataFrame.query() code injection
- https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.query.html
"""

import ast
import re
from dataclasses import dataclass, field
from typing import Any


class PandasValidationError(Exception):
    """Error during Pandas query validation."""

    pass


class DangerousExpressionError(PandasValidationError):
    """Query contains dangerous expressions."""

    pass


class UnsupportedOperationError(PandasValidationError):
    """Query contains unsupported operations."""

    pass


@dataclass
class PandasValidationConfig:
    """Configuration for Pandas query validation."""

    # Allowed column names (empty = allow all alphanumeric)
    allowed_columns: set[str] = field(default_factory=set)

    # Allowed comparison operators
    allowed_comparisons: set[str] = field(
        default_factory=lambda: {
            "Eq",
            "NotEq",
            "Lt",
            "LtE",
            "Gt",
            "GtE",
            "In",
            "NotIn",
            "Is",
            "IsNot",
        }
    )

    # Allowed boolean operators
    allowed_bool_ops: set[str] = field(default_factory=lambda: {"And", "Or", "Not"})

    # Blocked patterns in query strings
    blocked_patterns: list[str] = field(
        default_factory=lambda: [
            r"__\w+__",  # Dunder attributes
            r"\beval\b",  # eval calls
            r"\bexec\b",  # exec calls
            r"\bimport\b",  # import statements
            r"\bopen\b",  # file operations
            r"\bos\.",  # os module
            r"\bsys\.",  # sys module
            r"\bsubprocess\b",  # subprocess
            r"\@",  # @ operator (matrix mult, could be abused)
            r"\blambda\b",  # lambda functions
            r"\bdef\b",  # function definitions
            r"\bclass\b",  # class definitions
            r"\bglobals\b",  # globals access
            r"\blocals\b",  # locals access
            r"\bgetattr\b",  # attribute access
            r"\bsetattr\b",  # attribute setting
            r"\bdelattr\b",  # attribute deletion
            r"\b__builtins__\b",  # builtins access
        ]
    )

    # Maximum query length
    max_query_length: int = 1000

    # Strict mode - only allow simple comparisons
    strict_mode: bool = True


@dataclass
class PandasValidationResult:
    """Result of Pandas query validation."""

    is_valid: bool
    query: str
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    columns_referenced: set[str] = field(default_factory=set)


class PandasQueryValidator:
    """
    Validate Pandas query() expressions for security issues.

    WARNING: This provides best-effort validation but DataFrame.query()
    is fundamentally unsafe for untrusted input. Consider using
    safe_filter() methods instead.

    Example:
        validator = PandasQueryValidator()
        result = validator.validate("age > 18 and status == 'active'")
        if not result.is_valid:
            raise ValueError(f"Invalid query: {result.errors}")
    """

    # Safe identifier pattern
    IDENTIFIER_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")

    # String literal pattern
    STRING_PATTERN = re.compile(r'^["\'][^"\']*["\']$')

    def __init__(self, config: PandasValidationConfig | None = None):
        """
        Initialize validator.

        Args:
            config: Validation configuration
        """
        self.config = config or PandasValidationConfig()
        self._compile_patterns()

    def _compile_patterns(self):
        """Compile blocked patterns."""
        self._blocked_patterns = [
            re.compile(p, re.IGNORECASE) for p in self.config.blocked_patterns
        ]

    def validate(self, query: str) -> PandasValidationResult:
        """
        Validate a Pandas query expression.

        Args:
            query: Query string for DataFrame.query()

        Returns:
            PandasValidationResult with validation status
        """
        result = PandasValidationResult(
            is_valid=True,
            query=query,
        )

        # Check query length
        if len(query) > self.config.max_query_length:
            result.errors.append(
                f"Query exceeds max length ({len(query)} > {self.config.max_query_length})"
            )
            result.is_valid = False

        # Check for blocked patterns
        for pattern in self._blocked_patterns:
            if pattern.search(query):
                result.errors.append(f"Blocked pattern: {pattern.pattern}")
                result.is_valid = False

        # Parse and validate AST
        try:
            tree = ast.parse(query, mode="eval")
            ast_errors, columns = self._validate_ast(tree.body)
            result.errors.extend(ast_errors)
            result.columns_referenced = columns
            if ast_errors:
                result.is_valid = False
        except SyntaxError as e:
            result.errors.append(f"Syntax error: {e}")
            result.is_valid = False

        # Check column allowlist
        if self.config.allowed_columns and result.columns_referenced:
            disallowed = result.columns_referenced - self.config.allowed_columns
            if disallowed:
                result.errors.append(f"Disallowed columns: {disallowed}")
                result.is_valid = False

        # Add warning about query() safety
        result.warnings.append(
            "DataFrame.query() uses eval() internally and is not safe "
            "for untrusted input. Consider using boolean indexing instead."
        )

        return result

    def validate_or_raise(self, query: str) -> str:
        """
        Validate and return query, or raise exception.

        Args:
            query: Query string to validate

        Returns:
            The validated query

        Raises:
            PandasValidationError: If validation fails
        """
        result = self.validate(query)
        if not result.is_valid:
            raise PandasValidationError("; ".join(result.errors))
        return query

    def _validate_ast(self, node: ast.AST) -> tuple:
        """
        Recursively validate AST nodes.

        Returns:
            Tuple of (errors list, columns set)
        """
        errors = []
        columns = set()

        if isinstance(node, ast.BoolOp):
            # And, Or
            op_name = type(node.op).__name__
            if op_name not in self.config.allowed_bool_ops:
                errors.append(f"Disallowed boolean operator: {op_name}")
            for value in node.values:
                sub_errors, sub_cols = self._validate_ast(value)
                errors.extend(sub_errors)
                columns.update(sub_cols)

        elif isinstance(node, ast.UnaryOp):
            # Not, etc.
            op_name = type(node.op).__name__
            if op_name not in self.config.allowed_bool_ops:
                errors.append(f"Disallowed unary operator: {op_name}")
            sub_errors, sub_cols = self._validate_ast(node.operand)
            errors.extend(sub_errors)
            columns.update(sub_cols)

        elif isinstance(node, ast.Compare):
            # Comparisons: a > b, a == b, etc.
            for op in node.ops:
                op_name = type(op).__name__
                if op_name not in self.config.allowed_comparisons:
                    errors.append(f"Disallowed comparison: {op_name}")

            sub_errors, sub_cols = self._validate_ast(node.left)
            errors.extend(sub_errors)
            columns.update(sub_cols)

            for comparator in node.comparators:
                sub_errors, sub_cols = self._validate_ast(comparator)
                errors.extend(sub_errors)
                columns.update(sub_cols)

        elif isinstance(node, ast.Name):
            # Variable/column reference
            name = node.id
            if not self.IDENTIFIER_PATTERN.match(name):
                errors.append(f"Invalid identifier: {name}")
            elif name.startswith("_"):
                errors.append(f"Private attribute access not allowed: {name}")
            else:
                columns.add(name)

        elif isinstance(node, ast.Constant):
            # Literal values (strings, numbers, etc.)
            pass  # Safe

        elif isinstance(node, ast.Num):
            # Legacy number node (Python < 3.8)
            pass  # Safe

        elif isinstance(node, ast.Str):
            # Legacy string node (Python < 3.8)
            pass  # Safe

        elif isinstance(node, ast.List):
            # List literals for 'in' comparisons
            for elt in node.elts:
                sub_errors, sub_cols = self._validate_ast(elt)
                errors.extend(sub_errors)
                columns.update(sub_cols)

        elif isinstance(node, ast.Tuple):
            # Tuple literals
            for elt in node.elts:
                sub_errors, sub_cols = self._validate_ast(elt)
                errors.extend(sub_errors)
                columns.update(sub_cols)

        elif isinstance(node, ast.BinOp):
            # Binary operations (+, -, *, /)
            if self.config.strict_mode:
                errors.append(
                    f"Binary operations not allowed in strict mode: {type(node.op).__name__}"
                )
            sub_errors, sub_cols = self._validate_ast(node.left)
            errors.extend(sub_errors)
            columns.update(sub_cols)
            sub_errors, sub_cols = self._validate_ast(node.right)
            errors.extend(sub_errors)
            columns.update(sub_cols)

        elif isinstance(node, ast.Call):
            # Function calls - dangerous!
            errors.append("Function calls not allowed in queries (potential code injection)")

        elif isinstance(node, ast.Attribute):
            # Attribute access - dangerous!
            errors.append("Attribute access not allowed: potential injection vector")

        elif isinstance(node, ast.Subscript):
            # Subscript access - could be dangerous
            errors.append("Subscript access not allowed in queries")

        else:
            errors.append(f"Unsupported AST node type: {type(node).__name__}")

        return errors, columns


def validate_pandas_query(
    query: str,
    allowed_columns: set[str] | None = None,
) -> PandasValidationResult:
    """
    Convenience function to validate Pandas query.

    Args:
        query: Query string to validate
        allowed_columns: Optional set of allowed column names

    Returns:
        PandasValidationResult
    """
    config = PandasValidationConfig()
    if allowed_columns:
        config.allowed_columns = allowed_columns

    validator = PandasQueryValidator(config)
    return validator.validate(query)


class SafeDataFrameFilter:
    """
    Safe alternative to DataFrame.query() for untrusted input.

    Instead of using query(), this class provides safe filtering
    methods that don't use eval().

    Example:
        df = pd.DataFrame({'age': [25, 30, 35], 'name': ['A', 'B', 'C']})
        safe_filter = SafeDataFrameFilter(df, allowed_columns={'age', 'name'})

        # Safe filtering
        result = safe_filter.filter_equals('name', 'A')
        result = safe_filter.filter_greater_than('age', 25)
        result = safe_filter.filter_in('name', ['A', 'B'])
    """

    def __init__(
        self,
        df: Any,  # pd.DataFrame
        allowed_columns: set[str] | None = None,
    ):
        """
        Initialize safe filter.

        Args:
            df: Pandas DataFrame to filter
            allowed_columns: Optional set of allowed column names
        """
        self.df = df
        self.allowed_columns = allowed_columns or set(df.columns)

    def _validate_column(self, column: str) -> None:
        """Validate that column is allowed."""
        if column not in self.allowed_columns:
            raise ValueError(f"Column '{column}' not in allowed columns")
        if column not in self.df.columns:
            raise ValueError(f"Column '{column}' not found in DataFrame")

    def filter_equals(self, column: str, value: Any) -> Any:
        """Filter where column equals value."""
        self._validate_column(column)
        return self.df[self.df[column] == value]

    def filter_not_equals(self, column: str, value: Any) -> Any:
        """Filter where column does not equal value."""
        self._validate_column(column)
        return self.df[self.df[column] != value]

    def filter_greater_than(self, column: str, value: Any) -> Any:
        """Filter where column is greater than value."""
        self._validate_column(column)
        return self.df[self.df[column] > value]

    def filter_greater_or_equal(self, column: str, value: Any) -> Any:
        """Filter where column is greater than or equal to value."""
        self._validate_column(column)
        return self.df[self.df[column] >= value]

    def filter_less_than(self, column: str, value: Any) -> Any:
        """Filter where column is less than value."""
        self._validate_column(column)
        return self.df[self.df[column] < value]

    def filter_less_or_equal(self, column: str, value: Any) -> Any:
        """Filter where column is less than or equal to value."""
        self._validate_column(column)
        return self.df[self.df[column] <= value]

    def filter_in(self, column: str, values: list[Any]) -> Any:
        """Filter where column value is in list."""
        self._validate_column(column)
        return self.df[self.df[column].isin(values)]

    def filter_not_in(self, column: str, values: list[Any]) -> Any:
        """Filter where column value is not in list."""
        self._validate_column(column)
        return self.df[~self.df[column].isin(values)]

    def filter_contains(self, column: str, substring: str) -> Any:
        """Filter where string column contains substring."""
        self._validate_column(column)
        return self.df[self.df[column].str.contains(substring, regex=False)]

    def filter_startswith(self, column: str, prefix: str) -> Any:
        """Filter where string column starts with prefix."""
        self._validate_column(column)
        return self.df[self.df[column].str.startswith(prefix)]

    def filter_endswith(self, column: str, suffix: str) -> Any:
        """Filter where string column ends with suffix."""
        self._validate_column(column)
        return self.df[self.df[column].str.endswith(suffix)]

    def filter_isnull(self, column: str) -> Any:
        """Filter where column is null."""
        self._validate_column(column)
        return self.df[self.df[column].isnull()]

    def filter_notnull(self, column: str) -> Any:
        """Filter where column is not null."""
        self._validate_column(column)
        return self.df[self.df[column].notnull()]

    def filter_between(self, column: str, low: Any, high: Any) -> Any:
        """Filter where column value is between low and high (inclusive)."""
        self._validate_column(column)
        return self.df[(self.df[column] >= low) & (self.df[column] <= high)]
