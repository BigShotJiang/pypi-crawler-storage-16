"""Vantage CLI package.

Command-line interface for Vantage security scanner.
"""

from vantage_cli.main import app, main

__all__ = ["app", "main"]
__version__ = "1.2.4"
