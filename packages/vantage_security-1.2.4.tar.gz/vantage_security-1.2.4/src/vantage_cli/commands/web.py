"""
Web dashboard commands for Vantage CLI.

Provides commands to start the web dashboard server.
"""

from __future__ import annotations

import typer

web_app = typer.Typer(
    name="web",
    help="Web dashboard server commands",
    no_args_is_help=True,
)


@web_app.command("serve")
def serve(
    host: str = typer.Option(
        "0.0.0.0",
        "--host",
        "-h",
        help="Host to bind the server to",
    ),
    port: int = typer.Option(
        8080,
        "--port",
        "-p",
        help="Port to bind the server to",
    ),
    debug: bool = typer.Option(
        False,
        "--debug",
        "-d",
        help="Enable debug mode with auto-reload",
    ),
) -> None:
    """
    Start the Vantage web dashboard server.

    The dashboard provides:
    - Prompt injection testing interface
    - Infection simulation visualization
    - Effectiveness data dashboard
    - Competitor comparison page

    Example:
        vantage web serve --port 8080
        vantage web serve --host 127.0.0.1 --port 3000 --debug
    """
    from rich.console import Console

    console = Console()

    console.print()
    console.print("[bold cyan]Vantage Web Dashboard[/bold cyan]")
    console.print()
    console.print(f"Starting server on [bold]http://{host}:{port}[/bold]")
    console.print()
    console.print("Available pages:")
    console.print(f"  [blue]http://{host}:{port}/[/blue]           - Main dashboard")
    console.print(f"  [blue]http://{host}:{port}/demo[/blue]        - Prompt testing")
    console.print(f"  [blue]http://{host}:{port}/visualization[/blue] - Infection viz")
    console.print(f"  [blue]http://{host}:{port}/effectiveness[/blue] - Effectiveness data")
    console.print(f"  [blue]http://{host}:{port}/compare[/blue]      - Competitor comparison")
    console.print()
    console.print("Press [bold]Ctrl+C[/bold] to stop the server")
    console.print()

    try:
        from vantage_core.web.server import run_server

        run_server(host=host, port=port, debug=debug)
    except ImportError:
        console.print("[red]Error:[/red] Flask is required for the web dashboard")
        console.print("Install with: [bold]pip install flask[/bold]")
        raise typer.Exit(1)
    except KeyboardInterrupt:
        console.print()
        console.print("[yellow]Server stopped[/yellow]")


@web_app.command("demo")
def demo(
    port: int = typer.Option(
        8080,
        "--port",
        "-p",
        help="Port for the demo server",
    ),
) -> None:
    """
    Start a quick demo server on localhost.

    This is a convenience command for local testing.
    """
    from rich.console import Console

    console = Console()

    console.print()
    console.print("[bold green]Starting Vantage Demo...[/bold green]")
    console.print()

    serve(host="127.0.0.1", port=port, debug=True)
