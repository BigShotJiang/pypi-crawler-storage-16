"""
JSON Report Generator for Vantage Security Platform.

This module generates structured JSON reports from scan results.
"""

import json
from datetime import datetime
from typing import Any

from vantage_core.security.pipeline.orchestrator import PipelineResult


class JSONReportGenerator:
    """
    Generates structured JSON reports from scan results.

    Produces comprehensive JSON output including all findings,
    scores, simulations, and remediations.
    """

    def __init__(self):
        """Initialize the JSON report generator."""
        pass

    def generate(self, result: PipelineResult) -> str:
        """
        Generate a JSON report from pipeline results.

        Args:
            result: Pipeline execution result

        Returns:
            JSON string of the report
        """
        report = {
            "report_type": "mimic_security",
            "version": "1.0.0",
            "generated_at": datetime.now().isoformat(),
            "scan": self._build_scan_section(result),
            "score": self._build_score_section(result),
            "findings": self._build_findings_section(result),
            "agents": self._build_agents_section(result),
            "communications": self._build_communications_section(result),
            "simulation": self._build_simulation_section(result),
            "remediation": self._build_remediation_section(result),
            "metadata": result.metadata,
        }

        return json.dumps(report, indent=2, default=str)

    def _build_scan_section(self, result: PipelineResult) -> dict[str, Any]:
        """Build scan metadata section."""
        return {
            "scan_id": result.scan_id,
            "status": result.status,
            "started_at": result.started_at.isoformat(),
            "completed_at": result.completed_at.isoformat(),
            "duration_ms": result.duration_ms,
            "stages_completed": [s.value for s in result.stages_completed],
            "stages_failed": [s.value for s in result.stages_failed],
            "errors": result.errors,
        }

    def _build_score_section(self, result: PipelineResult) -> dict[str, Any] | None:
        """Build ATSS score section."""
        if not result.atss_result:
            return None

        atss = result.atss_result
        return {
            "overall_score": atss.overall_score,
            "grade": atss.grade,
            "confidence": atss.confidence,
            "breakdown": {
                "vulnerability_score": atss.vulnerability_score,
                "trust_boundary_score": atss.trust_boundary_score,
                "communication_score": atss.communication_score,
                "agent_risk_score": atss.agent_risk_score,
            },
            "high_risk_agents": atss.high_risk_agents,
            "recommendations": atss.recommendations,
        }

    def _build_findings_section(self, result: PipelineResult) -> dict[str, Any]:
        """Build findings section."""
        if not result.scan_result:
            return {
                "total": 0,
                "by_severity": {},
                "by_category": {},
                "items": [],
            }

        findings = result.scan_result.findings

        # Group by severity
        by_severity = {
            "critical": result.scan_result.critical_count,
            "high": result.scan_result.high_count,
            "medium": result.scan_result.medium_count,
            "low": result.scan_result.low_count,
            "info": result.scan_result.info_count,
        }

        # Group by category
        by_category: dict[str, int] = {}
        for finding in findings:
            cat = finding.category.value
            by_category[cat] = by_category.get(cat, 0) + 1

        # Build finding items
        items = []
        for finding in findings:
            items.append(
                {
                    "id": finding.id,
                    "title": finding.title,
                    "description": finding.description,
                    "severity": finding.severity.value,
                    "confidence": finding.confidence,
                    "category": finding.category.value,
                    "owasp_category": finding.owasp_category.value,
                    "maas_category": (
                        finding.maas_category.value if finding.maas_category else None
                    ),
                    "cwe_id": finding.cwe_id,
                    "location": {
                        "file_path": finding.file_path,
                        "line_number": finding.line_number,
                        "code_snippet": finding.code_snippet,
                    },
                    "agent_id": finding.agent_id,
                    "recommendation": finding.recommendation,
                    "evidence": finding.evidence,
                    "cvss_score": finding.cvss_score,
                    "sla_hours": finding.sla_hours,
                }
            )

        return {
            "total": len(findings),
            "by_severity": by_severity,
            "by_category": by_category,
            "items": items,
        }

    def _build_agents_section(self, result: PipelineResult) -> dict[str, Any]:
        """Build agents section."""
        if not result.scan_result:
            return {
                "total": 0,
                "frameworks": [],
                "items": [],
            }

        scan_result = result.scan_result
        items = []

        for agent in scan_result.agents:
            tools = []
            for tool in agent.tools:
                tools.append(
                    {
                        "name": tool.name,
                        "description": tool.description,
                        "categories": [c.value for c in tool.categories],
                        "required_trust_level": tool.required_trust_level.value,
                        "risk_score": tool.risk_score,
                    }
                )

            items.append(
                {
                    "id": agent.id,
                    "name": agent.name,
                    "framework": agent.framework,
                    "trust_level": agent.trust_level.value,
                    "role": agent.role,
                    "goal": agent.goal,
                    "has_code_execution": agent.has_code_execution,
                    "has_external_access": agent.has_external_access,
                    "allow_delegation": agent.allow_delegation,
                    "tools": tools,
                    "location": {
                        "file_path": agent.file_path,
                        "line_number": agent.line_number,
                    },
                }
            )

        return {
            "total": scan_result.agents_scanned,
            "frameworks": scan_result.frameworks_detected,
            "items": items,
        }

    def _build_communications_section(self, result: PipelineResult) -> dict[str, Any]:
        """Build communications section."""
        if not result.scan_result:
            return {
                "total": 0,
                "items": [],
            }

        scan_result = result.scan_result
        items = []

        for comm in scan_result.communications:
            items.append(
                {
                    "source_agent": comm.source_id,
                    "target_agent": comm.target_id,
                    "type": comm.communication_type,  # Also fix this field name
                    "protocol": comm.metadata.get(
                        "protocol", "unknown"
                    ),  # Protocol is in metadata? No, I used protocol in init. Wait.
                    "content_type": comm.metadata.get(
                        "content_type", "text"
                    ),  # Content type is likely not in init based on debug error
                    "location": {
                        "file_path": comm.metadata.get("file_path"),
                        "line_number": comm.metadata.get("line_number"),
                    },
                }
            )

        return {
            "total": len(items),
            "items": items,
        }

    def _build_simulation_section(self, result: PipelineResult) -> dict[str, Any]:
        """Build simulation results section."""
        if not result.simulation_results:
            return {
                "performed": False,
                "results": [],
            }

        results = []
        for sim_result in result.simulation_results:
            results.append(
                {
                    "entry_point": sim_result.entry_point,
                    "blast_radius": sim_result.blast_radius,
                    "infected_agents": sim_result.infected_agents,
                    "time_to_full_infection": sim_result.time_to_full_infection,
                    "containment_effectiveness": sim_result.containment_effectiveness,
                    "critical_paths": sim_result.critical_paths,
                }
            )

        return {
            "performed": True,
            "results": results,
        }

    def _build_remediation_section(self, result: PipelineResult) -> dict[str, Any]:
        """Build remediation section."""
        if not result.remediations:
            return {
                "generated": False,
                "items": [],
            }

        items = []
        for rem in result.remediations:
            items.append(
                {
                    "finding_id": rem.finding_id,
                    "pattern_id": rem.pattern_id,
                    "remedy_type": rem.remedy_type.value,
                    "title": rem.title,
                    "description": rem.description,
                    "explanation": rem.explanation,
                    "code_before": rem.code_before,
                    "code_after": rem.code_after,
                    "diff": rem.diff,
                    "imports_required": rem.imports_required,
                    "effort": rem.effort,
                    "effort_hours": rem.effort_hours,
                    "confidence": rem.confidence,
                    "references": rem.references,
                }
            )

        return {
            "generated": True,
            "count": len(items),
            "items": items,
        }
