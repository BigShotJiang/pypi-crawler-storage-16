"""
Database package for Vantage Security Platform.

This package provides database models, connection management,
and repository patterns for data access.
"""

from vantage_core.security.api.database.connection import (
    check_database_health,
    get_async_engine,
    get_async_session_maker,
    get_db,
)
from vantage_core.security.api.database.models import (
    APIKey,
    AuditLog,
    Base,
    GitHubInstallation,
    Project,
    ProjectMember,
    Scan,
    ScanResult,
    ScanSourceType,
    ScanStatus,
    User,
    UserRole,
    Webhook,
)

__all__ = [
    # Base
    "Base",
    # Models
    "User",
    "APIKey",
    "Project",
    "ProjectMember",
    "Scan",
    "ScanResult",
    "GitHubInstallation",
    "Webhook",
    "AuditLog",
    # Enums
    "UserRole",
    "ScanStatus",
    "ScanSourceType",
    # Connection
    "get_async_engine",
    "get_async_session_maker",
    "get_db",
    "check_database_health",
]
