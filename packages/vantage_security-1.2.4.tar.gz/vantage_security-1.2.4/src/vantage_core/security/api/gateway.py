"""
API Gateway Enhancements for Vantage Security Platform.

This module implements:
- Rate limiting with Redis (configurable per endpoint)
- Request/response logging
- OpenAPI 3.0 documentation generation
- Error handling standardization
- CORS configuration
"""

import logging
import time
import uuid
from collections.abc import Callable
from functools import wraps

from fastapi import FastAPI, HTTPException, Request, Response, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from starlette.middleware.base import BaseHTTPMiddleware

from vantage_core.security.api.models import ErrorResponse

# Configure logging
logger = logging.getLogger("vantage.api")


# Configuration
class GatewayConfig:
    """API Gateway configuration."""

    # Rate limiting
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_WINDOW_SECONDS: int = 60

    # Tier-based rate limits (requests per minute)
    RATE_LIMITS = {"free": 30, "pro": 100, "enterprise": 500, "anonymous": 10}

    # Per-endpoint rate limits (override tier limits)
    ENDPOINT_RATE_LIMITS = {
        "/api/v1/scan": 10,  # More restrictive for scans
        "/api/v1/uploads/presign": 20,
        "/api/v1/repositories/connect": 10,
    }

    # Logging
    LOG_REQUESTS: bool = True
    LOG_RESPONSE_BODY: bool = False  # Set to False for security

    # CORS
    CORS_ORIGINS: list[str] = ["*"]  # Configure for production
    CORS_ALLOW_CREDENTIALS: bool = True
    CORS_ALLOW_METHODS: list[str] = ["*"]
    CORS_ALLOW_HEADERS: list[str] = ["*"]

    # Redis (for production rate limiting)
    REDIS_URL: str = "redis://localhost:6379/0"

    # Request limits
    MAX_REQUEST_SIZE: int = 100 * 1024 * 1024  # 100MB


config = GatewayConfig()


# Rate limiting models
class RateLimitInfo(BaseModel):
    """Rate limit information."""

    limit: int
    remaining: int
    reset: int
    retry_after: int | None = None


class RateLimitResult(BaseModel):
    """Rate limit check result."""

    allowed: bool
    info: RateLimitInfo


# In-memory rate limiter (use Redis in production)
class SlidingWindowRateLimiter:
    """
    Sliding window rate limiter implementation.

    Uses in-memory storage for development. In production,
    use Redis for distributed rate limiting.
    """

    def __init__(self):
        """Initialize rate limiter."""
        self._requests: dict[str, list[float]] = {}

    def check(self, key: str, limit: int, window_seconds: int = 60) -> RateLimitResult:
        """
        Check if request is allowed under rate limit.

        Args:
            key: Rate limit key (e.g., user_id or API key)
            limit: Maximum requests per window
            window_seconds: Time window in seconds

        Returns:
            Rate limit result
        """
        now = time.time()
        window_start = now - window_seconds

        # Get existing requests
        requests = self._requests.get(key, [])

        # Filter to only requests within window
        requests = [ts for ts in requests if ts > window_start]

        current_count = len(requests)
        remaining = max(0, limit - current_count)
        reset_at = int(now + window_seconds)

        info = RateLimitInfo(limit=limit, remaining=remaining, reset=reset_at)

        if current_count >= limit:
            info.retry_after = reset_at - int(now)
            return RateLimitResult(allowed=False, info=info)

        # Record this request
        requests.append(now)
        self._requests[key] = requests

        info.remaining = remaining - 1

        return RateLimitResult(allowed=True, info=info)

    def reset(self, key: str):
        """Reset rate limit for a key."""
        if key in self._requests:
            del self._requests[key]


# Global rate limiter
rate_limiter = SlidingWindowRateLimiter()


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Middleware for rate limiting API requests.

    Applies tier-based and endpoint-specific rate limits
    using sliding window algorithm.
    """

    async def dispatch(self, request: Request, call_next):
        """Process request through rate limiter."""
        if not config.RATE_LIMIT_ENABLED:
            return await call_next(request)

        # Skip rate limiting for health checks
        if request.url.path in ["/health", "/", "/api/docs", "/api/redoc"]:
            return await call_next(request)

        # Get rate limit key and tier
        key, tier = self._get_rate_limit_key(request)

        # Determine rate limit
        limit = self._get_rate_limit(request.url.path, tier)

        # Check rate limit
        result = rate_limiter.check(key, limit, config.RATE_LIMIT_WINDOW_SECONDS)

        # Add rate limit info to request state
        request.state.rate_limit_info = result.info.model_dump()

        if not result.allowed:
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content=ErrorResponse(
                    error="rate_limit_exceeded",
                    message="Too many requests. Please slow down.",
                    details={
                        "limit": result.info.limit,
                        "retry_after": result.info.retry_after,
                    },
                ).model_dump(),
                headers={
                    "X-RateLimit-Limit": str(result.info.limit),
                    "X-RateLimit-Remaining": "0",
                    "X-RateLimit-Reset": str(result.info.reset),
                    "Retry-After": str(result.info.retry_after),
                },
            )

        response = await call_next(request)

        # Add rate limit headers
        response.headers["X-RateLimit-Limit"] = str(result.info.limit)
        response.headers["X-RateLimit-Remaining"] = str(result.info.remaining)
        response.headers["X-RateLimit-Reset"] = str(result.info.reset)

        return response

    def _get_rate_limit_key(self, request: Request) -> tuple[str, str]:
        """Get rate limit key and tier from request."""
        # Try to get from authenticated user
        if hasattr(request.state, "user"):
            user = request.state.user
            key = f"user:{user.get('id', 'unknown')}"
            tier = user.get("tier", "free")
            return key, tier

        # Try to get from API key
        if hasattr(request.state, "api_key_data"):
            key_data = request.state.api_key_data
            key = f"apikey:{key_data.get('key_id', 'unknown')}"
            tier = key_data.get("tier", "pro")
            return key, tier

        # Fall back to IP address
        client_ip = request.client.host if request.client else "unknown"
        return f"ip:{client_ip}", "anonymous"

    def _get_rate_limit(self, path: str, tier: str) -> int:
        """Get rate limit for path and tier."""
        # Check endpoint-specific limit
        for endpoint, limit in config.ENDPOINT_RATE_LIMITS.items():
            if path.startswith(endpoint):
                return limit

        # Use tier-based limit
        return config.RATE_LIMITS.get(tier, config.RATE_LIMITS["anonymous"])


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """
    Middleware for logging API requests and responses.

    Captures request details, timing, and response status
    for monitoring and debugging.
    """

    async def dispatch(self, request: Request, call_next):
        """Log request and response."""
        # Generate request ID
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
        request.state.request_id = request_id

        # Record start time
        start_time = time.time()

        # Log request
        if config.LOG_REQUESTS:
            await self._log_request(request, request_id)

        try:
            response = await call_next(request)

            # Calculate duration
            duration_ms = int((time.time() - start_time) * 1000)

            # Log response
            if config.LOG_REQUESTS:
                self._log_response(request, response, request_id, duration_ms)

            # Add headers
            response.headers["X-Request-ID"] = request_id
            response.headers["X-Response-Time"] = f"{duration_ms}ms"

            return response

        except Exception as e:
            # Log error
            duration_ms = int((time.time() - start_time) * 1000)
            logger.error(
                "Request failed",
                extra={
                    "request_id": request_id,
                    "path": request.url.path,
                    "method": request.method,
                    "duration_ms": duration_ms,
                    "error": str(e),
                },
            )
            raise

    async def _log_request(self, request: Request, request_id: str):
        """Log incoming request."""
        log_data = {
            "request_id": request_id,
            "method": request.method,
            "path": request.url.path,
            "query": str(request.query_params),
            "client_ip": request.client.host if request.client else "unknown",
            "user_agent": request.headers.get("User-Agent", "unknown"),
        }

        logger.info(f"Incoming request: {request.method} {request.url.path}", extra=log_data)

    def _log_response(
        self, request: Request, response: Response, request_id: str, duration_ms: int
    ):
        """Log outgoing response."""
        log_data = {
            "request_id": request_id,
            "method": request.method,
            "path": request.url.path,
            "status_code": response.status_code,
            "duration_ms": duration_ms,
        }

        if response.status_code >= 400:
            logger.warning("Request completed with error", extra=log_data)
        else:
            logger.info("Request completed", extra=log_data)


class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    """
    Middleware for standardized error handling.

    Catches exceptions and returns consistent error responses
    with proper status codes and error details.
    """

    async def dispatch(self, request: Request, call_next):
        """Handle errors with standardized responses."""
        try:
            return await call_next(request)
        except HTTPException:
            # Re-raise FastAPI exceptions
            raise
        except ValueError as e:
            return JSONResponse(
                status_code=status.HTTP_400_BAD_REQUEST,
                content=ErrorResponse(
                    error="validation_error",
                    message=str(e),
                    request_id=getattr(request.state, "request_id", None),
                ).model_dump(),
            )
        except PermissionError as e:
            return JSONResponse(
                status_code=status.HTTP_403_FORBIDDEN,
                content=ErrorResponse(
                    error="permission_denied",
                    message=str(e),
                    request_id=getattr(request.state, "request_id", None),
                ).model_dump(),
            )
        except Exception as e:
            logger.exception(
                "Unhandled exception",
                extra={
                    "request_id": getattr(request.state, "request_id", None),
                    "path": request.url.path,
                },
            )

            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content=ErrorResponse(
                    error="internal_error",
                    message="An unexpected error occurred",
                    details={"type": type(e).__name__},
                    request_id=getattr(request.state, "request_id", None),
                ).model_dump(),
            )


def configure_gateway(app: FastAPI):
    """
    Configure API gateway middleware and settings.

    Args:
        app: FastAPI application instance
    """
    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=config.CORS_ORIGINS,
        allow_credentials=config.CORS_ALLOW_CREDENTIALS,
        allow_methods=config.CORS_ALLOW_METHODS,
        allow_headers=config.CORS_ALLOW_HEADERS,
        expose_headers=[
            "X-Request-ID",
            "X-RateLimit-Limit",
            "X-RateLimit-Remaining",
            "X-RateLimit-Reset",
            "X-Response-Time",
        ],
    )

    # Add custom middleware (order matters - first added is outermost)
    app.add_middleware(ErrorHandlingMiddleware)
    app.add_middleware(RequestLoggingMiddleware)
    app.add_middleware(RateLimitMiddleware)

    # Configure OpenAPI
    configure_openapi(app)


def configure_openapi(app: FastAPI):
    """
    Configure OpenAPI documentation.

    Args:
        app: FastAPI application instance
    """
    app.title = "Vantage Security API"
    app.description = """
## Vantage AI Agent Security Testing Platform

This API provides security scanning and analysis capabilities for multi-agent AI systems.

### Features

- **Security Scanning**: Analyze agent code for vulnerabilities
- **Trust Boundary Analysis**: Map trust zones and detect violations
- **Infection Simulation**: Test agent system resilience
- **Remediation Recommendations**: Get actionable security fixes

### Authentication

All API endpoints require authentication via:
- **API Key**: Include `X-API-Key` header
- **JWT Token**: Include `Authorization: Bearer <token>` header

### Rate Limiting

API requests are rate limited based on your subscription tier:
- **Free**: 30 requests/minute
- **Pro**: 100 requests/minute
- **Enterprise**: 500 requests/minute

Rate limit headers are included in all responses:
- `X-RateLimit-Limit`: Your rate limit
- `X-RateLimit-Remaining`: Requests remaining
- `X-RateLimit-Reset`: Unix timestamp when limit resets

### Error Responses

All errors follow a standard format:
```json
{
  "error": "error_type",
  "message": "Human readable message",
  "details": {},
  "request_id": "uuid"
}
```
"""

    app.version = "1.0.0"
    app.contact = {"name": "Vantage Support", "email": "support@vantage.io"}
    app.license_info = {"name": "Proprietary", "url": "https://vantage.io/terms"}

    # Add security schemes
    app.openapi_tags = [
        {
            "name": "authentication",
            "description": "User authentication and session management",
        },
        {"name": "scans", "description": "Security scan operations"},
        {"name": "uploads", "description": "File upload management"},
        {"name": "repositories", "description": "Git repository integration"},
        {"name": "webhooks", "description": "Webhook management"},
        {"name": "reports", "description": "Report generation and retrieval"},
    ]


# Utility function for adding rate limit info to response
def add_rate_limit_headers(response: Response, info: dict):
    """Add rate limit headers to response."""
    response.headers["X-RateLimit-Limit"] = str(info.get("limit", 0))
    response.headers["X-RateLimit-Remaining"] = str(info.get("remaining", 0))
    response.headers["X-RateLimit-Reset"] = str(info.get("reset", 0))


# Rate limit bypass decorator for internal services
def bypass_rate_limit(func: Callable) -> Callable:
    """
    Decorator to bypass rate limiting for internal services.

    Use with caution - only for trusted internal endpoints.
    """

    @wraps(func)
    async def wrapper(request: Request, *args, **kwargs):
        # Check for bypass token
        bypass_token = request.headers.get("X-RateLimit-Bypass-Token")
        if bypass_token:
            # Validate token (implement proper validation)
            request.state.bypass_rate_limit = True

        return await func(request, *args, **kwargs)

    return wrapper
