"""
Runtime configuration manager.

US-011: Runtime Configuration API

Provides thread-safe runtime configuration management with
observer pattern for change notifications.
"""

from __future__ import annotations

import copy
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from threading import RLock
from typing import Any

from vantage_core.security.config.loader import ConfigurationError
from vantage_core.security.config.schema import MimicSettings


@dataclass
class ConfigChange:
    """Record of a configuration change."""

    key: str
    old_value: Any
    new_value: Any
    source: str  # "api", "env", "file", "reset"
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


class ConfigurationManager:
    """
    Runtime configuration manager with change notification.

    Provides thread-safe access to configuration with
    observer pattern for change notification.

    Features:
    - Thread-safe get/set operations
    - Observer pattern for change callbacks
    - Immutable key protection
    - Validation on value changes
    - Reset to defaults

    Example:
        >>> from vantage_core.security.config import load_config
        >>> settings = load_config()
        >>> manager = ConfigurationManager(settings)
        >>>
        >>> # Get configuration value
        >>> max_depth = manager.get("taint.max_depth")
        >>>
        >>> # Set configuration value
        >>> manager.set("taint.max_depth", 50)
        >>>
        >>> # Register change callback
        >>> def on_change(change: ConfigChange):
        ...     print(f"Config changed: {change.key}")
        >>> manager.add_change_callback(on_change)
    """

    # Keys that cannot be changed at runtime
    DEFAULT_IMMUTABLE_KEYS = frozenset(
        {
            "rules.paths",
            "output_file",
            "logging.audit_file",
        }
    )

    def __init__(self, settings: MimicSettings, immutable_keys: set[str] | None = None):
        """
        Initialize the configuration manager.

        Args:
            settings: Initial configuration settings
            immutable_keys: Additional keys that cannot be changed at runtime
        """
        self._settings = settings
        self._lock = RLock()
        self._callbacks: list[Callable[[ConfigChange], None]] = []
        self._change_history: list[ConfigChange] = []

        # Build immutable keys set
        self._immutable_keys = set(self.DEFAULT_IMMUTABLE_KEYS)
        if immutable_keys:
            self._immutable_keys.update(immutable_keys)

    @property
    def settings(self) -> MimicSettings:
        """Get the current settings (read-only reference)."""
        with self._lock:
            return self._settings

    def get(self, key: str, default: Any = None) -> Any:
        """
        Get configuration value by dotted key path.

        Args:
            key: Dotted key path (e.g., "taint.max_depth")
            default: Default value if key not found

        Returns:
            Configuration value

        Example:
            >>> value = manager.get("entropy.api_key")
            >>> value = manager.get("logging.level")
        """
        with self._lock:
            try:
                return self._get_nested(self._settings, key)
            except (KeyError, AttributeError):
                return default

    def set(self, key: str, value: Any, source: str = "api") -> None:
        """
        Set configuration value at runtime.

        Args:
            key: Dotted key path
            value: New value
            source: Source of change for audit

        Raises:
            ConfigurationError: If key is immutable or value invalid

        Example:
            >>> manager.set("taint.max_depth", 50)
            >>> manager.set("entropy.api_key", 4.0, source="user")
        """
        if key in self._immutable_keys:
            raise ConfigurationError(
                f"Configuration key '{key}' cannot be changed at runtime",
                "CONFIG_IMMUTABLE",
            )

        with self._lock:
            try:
                old_value = self._get_nested(self._settings, key)
            except (KeyError, AttributeError):
                old_value = None

            # Skip if value hasn't changed
            if old_value == value:
                return

            # Validate new value by creating a test copy
            self._validate_value(key, value)

            # Set new value
            self._set_nested(self._settings, key, value)

            # Record and notify
            change = ConfigChange(key, old_value, value, source)
            self._change_history.append(change)

            for callback in self._callbacks:
                try:
                    callback(change)
                except Exception:
                    # Don't let callback errors break configuration
                    pass

    def reset(self, key: str) -> None:
        """
        Reset configuration key to default value.

        Args:
            key: Dotted key path to reset

        Example:
            >>> manager.reset("taint.max_depth")
        """
        default_settings = MimicSettings()
        try:
            default_value = self._get_nested(default_settings, key)
            self.set(key, default_value, source="reset")
        except (KeyError, AttributeError) as e:
            raise ConfigurationError(f"Cannot reset unknown key: {key}", "CONFIG_KEY_ERROR") from e

    def reset_all(self) -> None:
        """Reset all mutable configuration to defaults."""
        default_settings = MimicSettings()

        with self._lock:
            # Create list of all keys to reset
            keys_to_reset = self._get_all_keys(self._settings)

            for key in keys_to_reset:
                if key not in self._immutable_keys:
                    try:
                        default_value = self._get_nested(default_settings, key)
                        current_value = self._get_nested(self._settings, key)

                        if current_value != default_value:
                            self.set(key, default_value, source="reset_all")
                    except (KeyError, AttributeError):
                        pass

    def add_change_callback(self, callback: Callable[[ConfigChange], None]) -> None:
        """
        Register callback for configuration changes.

        Args:
            callback: Function to call on configuration change

        Example:
            >>> def on_change(change):
            ...     logger.info(f"Config {change.key} changed to {change.new_value}")
            >>> manager.add_change_callback(on_change)
        """
        with self._lock:
            self._callbacks.append(callback)

    def remove_change_callback(self, callback: Callable[[ConfigChange], None]) -> None:
        """
        Remove a registered callback.

        Args:
            callback: Callback to remove
        """
        with self._lock:
            if callback in self._callbacks:
                self._callbacks.remove(callback)

    def get_change_history(self) -> list[ConfigChange]:
        """
        Get history of configuration changes.

        Returns:
            List of ConfigChange records
        """
        with self._lock:
            return list(self._change_history)

    def is_immutable(self, key: str) -> bool:
        """
        Check if a key is immutable.

        Args:
            key: Dotted key path

        Returns:
            True if key cannot be changed at runtime
        """
        return key in self._immutable_keys

    def get_all(self) -> dict[str, Any]:
        """
        Get all configuration as a dictionary.

        Returns:
            Dictionary of all configuration values
        """
        with self._lock:
            return self._settings.to_dict()

    def update(self, updates: dict[str, Any], source: str = "api") -> None:
        """
        Update multiple configuration values atomically.

        Args:
            updates: Dictionary of key-value pairs to update
            source: Source of changes

        Example:
            >>> manager.update({
            ...     "taint.max_depth": 50,
            ...     "entropy.api_key": 4.0
            ... })
        """
        with self._lock:
            for key, value in updates.items():
                self.set(key, value, source)

    def _get_nested(self, obj: Any, key: str) -> Any:
        """Get nested attribute by dotted path."""
        parts = key.split(".")
        for part in parts:
            if hasattr(obj, part):
                obj = getattr(obj, part)
            elif isinstance(obj, dict) and part in obj:
                obj = obj[part]
            else:
                raise KeyError(f"Configuration key not found: {key}")
        return obj

    def _set_nested(self, obj: Any, key: str, value: Any) -> None:
        """Set nested attribute by dotted path."""
        parts = key.split(".")

        # Navigate to parent
        for part in parts[:-1]:
            if hasattr(obj, part):
                obj = getattr(obj, part)
            elif isinstance(obj, dict):
                obj = obj[part]
            else:
                raise KeyError(f"Configuration key not found: {key}")

        # Set the final attribute
        final_key = parts[-1]
        if hasattr(obj, final_key):
            setattr(obj, final_key, value)
        elif isinstance(obj, dict):
            obj[final_key] = value
        else:
            raise KeyError(f"Cannot set configuration key: {key}")

    def _validate_value(self, key: str, value: Any) -> None:
        """Validate value against schema by creating test copy."""
        # Create deep copy and apply change
        test_settings = copy.deepcopy(self._settings)

        try:
            self._set_nested(test_settings, key, value)

            # Re-validate the entire settings
            # This will trigger Pydantic validators
            test_dict = test_settings.model_dump()
            MimicSettings.model_validate(test_dict)

        except Exception as e:
            raise ConfigurationError(
                f"Invalid value for '{key}': {e}", "CONFIG_VALIDATION_ERROR"
            ) from e

    def _get_all_keys(self, obj: Any, prefix: str = "") -> list[str]:
        """Recursively get all configuration keys."""
        keys = []

        if hasattr(obj, "model_dump"):
            data = obj.model_dump()
        elif isinstance(obj, dict):
            data = obj
        else:
            return keys

        for key, value in data.items():
            full_key = f"{prefix}.{key}" if prefix else key

            if isinstance(value, dict):
                keys.extend(self._get_all_keys(value, full_key))
            else:
                keys.append(full_key)

        return keys


# Singleton instance for global access
_global_manager: ConfigurationManager | None = None
_global_lock = RLock()


def get_global_manager() -> ConfigurationManager | None:
    """
    Get the global configuration manager instance.

    Returns:
        Global ConfigurationManager or None if not initialized
    """
    with _global_lock:
        return _global_manager


def set_global_manager(manager: ConfigurationManager) -> None:
    """
    Set the global configuration manager instance.

    Args:
        manager: ConfigurationManager to use globally
    """
    global _global_manager
    with _global_lock:
        _global_manager = manager


def initialize_global_config(
    settings: MimicSettings | None = None,
) -> ConfigurationManager:
    """
    Initialize global configuration manager.

    Args:
        settings: Optional settings to use (loads defaults if None)

    Returns:
        Initialized ConfigurationManager
    """
    from vantage_core.security.config.loader import load_config

    if settings is None:
        settings = load_config()

    manager = ConfigurationManager(settings)
    set_global_manager(manager)
    return manager


def get_config_value(key: str, default: Any = None) -> Any:
    """
    Get configuration value from global manager.

    Convenience function for quick access to global config.

    Args:
        key: Dotted key path
        default: Default value if not found

    Returns:
        Configuration value
    """
    manager = get_global_manager()
    if manager is None:
        manager = initialize_global_config()
    return manager.get(key, default)


def set_config_value(key: str, value: Any) -> None:
    """
    Set configuration value in global manager.

    Args:
        key: Dotted key path
        value: New value
    """
    manager = get_global_manager()
    if manager is None:
        manager = initialize_global_config()
    manager.set(key, value)
