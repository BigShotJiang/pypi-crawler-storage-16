"""
Finding Deduplication System for Vantage Security Scanner.

This module provides semantic fingerprinting and similarity matching
to consolidate duplicate security findings and reduce noise in reports.

Key components:
- FingerprintGenerator: Generate semantic fingerprints for findings
- SimilarityMatcher: Group similar findings together
- AttackPathAggregator: Group findings by attack vectors
- ReportConsolidator: Create deduplicated reports with metrics

Example usage:
    from vantage_core.security.deduplication import ReportConsolidator

    consolidator = ReportConsolidator()
    report = consolidator.consolidate(findings)

    print(f"Reduced {report.original_count} to {report.consolidated_count}")
    print(f"Reduction: {report.reduction_percentage}%")
"""

from vantage_core.security.deduplication.aggregation import (
    AttackPath,
    AttackPathAggregator,
    AttackVector,
    ConsolidatedFinding,
    DeduplicationReport,
    ReportConsolidator,
)
from vantage_core.security.deduplication.cross_framework import (
    FRAMEWORK_PRIORITY,
    CrossFrameworkDeduplicator,
    FrameworkFinding,
    deduplicate_findings,
)
from vantage_core.security.deduplication.fingerprinting import (
    FindingFingerprint,
    FindingGroup,
    FingerprintGenerator,
    SimilarityMatcher,
)

__all__ = [
    # Fingerprinting
    "FindingFingerprint",
    "FingerprintGenerator",
    "FindingGroup",
    "SimilarityMatcher",
    # Aggregation
    "AttackVector",
    "AttackPath",
    "AttackPathAggregator",
    "ConsolidatedFinding",
    "DeduplicationReport",
    "ReportConsolidator",
    # Cross-framework deduplication
    "CrossFrameworkDeduplicator",
    "FrameworkFinding",
    "deduplicate_findings",
    "FRAMEWORK_PRIORITY",
]
