"""
Unified Secret Filtering Module.

This module provides a single source of truth for secret filtering,
replacing inconsistent filtering across multiple files. It reduces
false positives and ensures consistent behavior across all pipelines.
"""

import logging
import re
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class FilterResult:
    """Result of filtering check."""

    is_false_positive: bool
    reason: str
    confidence: float  # How confident we are this is a false positive


class UnifiedSecretFilter:
    """
    Single source of truth for secret filtering.

    Replaces inconsistent filtering across:
    - base.py
    - secret_detection.py
    - ml_features.py
    """

    # Centralized UUID pattern
    UUID_PATTERN = re.compile(
        r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.IGNORECASE
    )

    # Hash patterns
    MD5_PATTERN = re.compile(r"^[0-9a-fA-F]{32}$")
    SHA1_PATTERN = re.compile(r"^[0-9a-fA-F]{40}$")
    SHA256_PATTERN = re.compile(r"^[0-9a-fA-F]{64}$")
    SHA512_PATTERN = re.compile(r"^[0-9a-fA-F]{128}$")

    # Common placeholder patterns (expanded list)
    PLACEHOLDER_PATTERNS = [
        # Generic placeholders
        r"(your|my|the)_?(api_)?key(_here)?",
        r"(your|my|the)_?(secret|token|password)(_here)?",
        r"xxx+",
        r"test_?(key|token|secret|password)",
        r"dummy_?(key|token|secret|password)",
        r"example_?(key|token|secret|password)",
        r"sample_?(key|token|secret|password)",
        r"demo_?(key|token|secret|password)",
        r"fake_?(key|token|secret|password)",
        r"mock_?(key|token|secret|password)",
        r"placeholder",
        r"changeme",
        r"todo",
        r"fixme",
        r"replace_?me",
        # Common default passwords
        r"^(password|admin|root|test|user|guest)\d*$",
        r"^12345+$",
        r"^qwerty+$",
        r"^abc123+$",
        # Development/test values
        r"^localhost$",
        r"^127\.0\.0\.1$",
        r"^0\.0\.0\.0$",
        r"^foo(bar)?$",
        r"^bar(baz)?$",
        r"^baz$",
        # Documentation examples
        r"<[A-Z_]+>",  # <YOUR_API_KEY>
        r"\$\{[A-Z_]+\}",  # ${API_KEY}
        r"\{\{[A-Z_]+\}\}",  # {{API_KEY}}
    ]

    # File patterns that are likely not production
    TEST_FILE_PATTERNS = [
        r"test[s]?/",
        r"test_",
        r"_test\.",
        r"\.test\.",
        r"\.spec\.",
        r"/fixtures?/",
        r"/mocks?/",
        r"/stubs?/",
    ]

    EXAMPLE_FILE_PATTERNS = [
        r"example[s]?/",
        r"demo[s]?/",
        r"sample[s]?/",
        r"tutorial[s]?/",
        r"\.example\.",
        r"_example\.",
    ]

    DOC_FILE_PATTERNS = [
        r"\.md$",
        r"\.rst$",
        r"\.txt$",
        r"README",
        r"CHANGELOG",
        r"docs?/",
    ]

    def __init__(self, strict_mode: bool = False):
        """
        Initialize the unified filter.

        Args:
            strict_mode: If True, be more conservative (fewer false positive detections).
        """
        self.strict_mode = strict_mode
        self.compiled_placeholders = [
            re.compile(pattern, re.IGNORECASE) for pattern in self.PLACEHOLDER_PATTERNS
        ]
        self.stats = {"total_checked": 0, "filtered": 0, "by_reason": {}}

    def is_false_positive(
        self, text: str, file_path: str = "", context: str = "", variable_name: str = ""
    ) -> tuple[bool, str]:
        """
        Check if this is a false positive.

        Args:
            text: The potential secret value.
            file_path: Path to the file being analyzed.
            context: Surrounding code context.
            variable_name: Name of the variable containing the value.

        Returns:
            Tuple of (is_false_positive, reason).
        """
        self.stats["total_checked"] += 1

        # Convert to string and clean
        text = str(text).strip()
        if not text:
            return self._record_result(True, "empty_value")

        text_lower = text.lower()

        # 1. Check file type
        file_type_result = self._check_file_type(file_path)
        if file_type_result[0]:
            return self._record_result(*file_type_result)

        # 2. Check for UUIDs
        if self.UUID_PATTERN.match(text):
            return self._record_result(True, "uuid")

        # 3. Check for hash patterns
        hash_result = self._check_hash_patterns(text)
        if hash_result[0]:
            return self._record_result(*hash_result)

        # 4. Check placeholder patterns
        placeholder_result = self._check_placeholders(text, text_lower)
        if placeholder_result[0]:
            return self._record_result(*placeholder_result)

        # 5. Check sequential/repetitive patterns
        sequential_result = self._check_sequential_patterns(text)
        if sequential_result[0]:
            return self._record_result(*sequential_result)

        # 6. Check variable name hints
        if variable_name:
            var_result = self._check_variable_name(variable_name)
            if var_result[0]:
                return self._record_result(*var_result)

        # 7. Context-based checks
        if context:
            context_result = self._check_context(context, text)
            if context_result[0]:
                return self._record_result(*context_result)

        # 8. Length-based filtering
        if len(text) < 6:
            return self._record_result(True, "too_short")
        if len(text) > 500:
            return self._record_result(True, "too_long")

        # 9. All same character or very low entropy
        if self._is_low_entropy(text):
            return self._record_result(True, "low_entropy")

        return self._record_result(False, "")

    def _record_result(self, is_fp: bool, reason: str) -> tuple[bool, str]:
        """Record and return filtering result."""
        if is_fp:
            self.stats["filtered"] += 1
            self.stats["by_reason"][reason] = self.stats["by_reason"].get(reason, 0) + 1
        return is_fp, reason

    def _check_file_type(self, file_path: str) -> tuple[bool, str]:
        """Check if file type suggests false positive."""
        if not file_path:
            return False, ""

        file_lower = file_path.lower()

        # In strict mode, don't filter based on file type alone
        if self.strict_mode:
            return False, ""

        # Test files
        for pattern in self.TEST_FILE_PATTERNS:
            if re.search(pattern, file_lower):
                return True, "test_file"

        # Example files
        for pattern in self.EXAMPLE_FILE_PATTERNS:
            if re.search(pattern, file_lower):
                return True, "example_file"

        # Documentation files
        for pattern in self.DOC_FILE_PATTERNS:
            if re.search(pattern, file_lower):
                return True, "documentation_file"

        return False, ""

    def _check_hash_patterns(self, text: str) -> tuple[bool, str]:
        """Check if text matches common hash patterns."""
        if self.MD5_PATTERN.match(text):
            return True, "md5_hash"
        if self.SHA1_PATTERN.match(text):
            return True, "sha1_hash"
        if self.SHA256_PATTERN.match(text):
            return True, "sha256_hash"
        if self.SHA512_PATTERN.match(text):
            return True, "sha512_hash"
        return False, ""

    def _check_placeholders(self, text: str, text_lower: str) -> tuple[bool, str]:
        """Check if text matches placeholder patterns."""
        for pattern in self.compiled_placeholders:
            if pattern.search(text_lower):
                return True, "placeholder_pattern"

        # Check for obvious non-random patterns
        if text_lower in [
            "password",
            "secret",
            "token",
            "apikey",
            "api_key",
            "access_key",
            "secret_key",
            "private_key",
        ]:
            return True, "literal_secret_name"

        return False, ""

    def _check_sequential_patterns(self, text: str) -> tuple[bool, str]:
        """Check for sequential or repetitive patterns."""
        # Extract alphanumeric characters
        alphanum = "".join(c for c in text if c.isalnum())
        if not alphanum:
            return False, ""

        # Check for sequential numbers
        if self._is_sequential(alphanum):
            return True, "sequential_pattern"

        # Check for repeated characters
        if len(set(alphanum)) <= 2:
            return True, "repeated_chars"

        # Check for patterns like "1111111", "aaaaaaa"
        for char in set(alphanum):
            count = alphanum.count(char)
            if count >= len(alphanum) * 0.8:  # 80% same character
                return True, "mostly_same_char"

        return False, ""

    def _is_sequential(self, text: str) -> bool:
        """Check if string contains sequential patterns."""
        # Check for numeric sequences
        if text.isdigit():
            # Check for sequences like "123456", "111111"
            if all(text[i] == text[0] for i in range(len(text))):
                return True
            # Check for incrementing sequences
            try:
                diffs = [int(text[i + 1]) - int(text[i]) for i in range(len(text) - 1)]
                if all(d == diffs[0] for d in diffs) and abs(diffs[0]) <= 1:
                    return True
            except:
                pass

        # Check for alphabetic sequences
        if text.isalpha():
            text_lower = text.lower()
            # Check for sequences like "abcdef"
            diffs = [
                ord(text_lower[i + 1]) - ord(text_lower[i]) for i in range(len(text_lower) - 1)
            ]
            if all(d == 1 for d in diffs):
                return True

        return False

    def _check_variable_name(self, variable_name: str) -> tuple[bool, str]:
        """Check if variable name suggests a placeholder."""
        var_lower = variable_name.lower()

        placeholder_var_patterns = [
            "test",
            "temp",
            "tmp",
            "dummy",
            "fake",
            "mock",
            "example",
            "sample",
            "demo",
            "placeholder",
        ]

        for pattern in placeholder_var_patterns:
            if pattern in var_lower:
                return True, f"variable_name_{pattern}"

        return False, ""

    def _check_context(self, context: str, text: str) -> tuple[bool, str]:
        """Check context for hints about false positives."""
        context_lower = context.lower()

        # Check for test assertions
        if "assert" in context_lower and text in context:
            return True, "test_assertion"

        # Check for example comments
        example_indicators = [
            "# example:",
            "// example:",
            "/* example",
            "# e.g.",
            "// e.g.",
            "/* e.g.",
            "# for example",
            "// for example",
            "# sample:",
            "// sample:",
        ]

        for indicator in example_indicators:
            if indicator in context_lower:
                return True, "example_context"

        return False, ""

    def _is_low_entropy(self, text: str) -> bool:
        """Check if text has very low entropy."""
        # Count unique characters
        unique_chars = len(set(text))

        # Very low character diversity
        if unique_chars <= 3:
            return True

        # Check character distribution
        char_counts = {}
        for char in text:
            char_counts[char] = char_counts.get(char, 0) + 1

        # If any character makes up > 50% of the string
        max_count = max(char_counts.values())
        if max_count > len(text) * 0.5:
            return True

        return False

    def get_filter_confidence(
        self, text: str, file_path: str = "", context: str = ""
    ) -> FilterResult:
        """
        Get detailed filtering result with confidence.

        Returns:
            FilterResult with confidence score.
        """
        is_fp, reason = self.is_false_positive(text, file_path, context)

        # Assign confidence based on reason
        confidence_map = {
            "uuid": 0.99,
            "md5_hash": 0.98,
            "sha1_hash": 0.98,
            "sha256_hash": 0.98,
            "sha512_hash": 0.98,
            "empty_value": 1.0,
            "placeholder_pattern": 0.95,
            "literal_secret_name": 0.99,
            "sequential_pattern": 0.9,
            "repeated_chars": 0.95,
            "mostly_same_char": 0.95,
            "too_short": 0.9,
            "too_long": 0.85,
            "low_entropy": 0.85,
            "test_file": 0.8,
            "example_file": 0.85,
            "documentation_file": 0.9,
            "test_assertion": 0.9,
            "example_context": 0.85,
        }

        confidence = confidence_map.get(reason, 0.7) if is_fp else 0.0

        return FilterResult(is_false_positive=is_fp, reason=reason, confidence=confidence)

    def get_stats(self) -> dict:
        """Get filtering statistics."""
        return {
            **self.stats,
            "filter_rate": (
                self.stats["filtered"] / self.stats["total_checked"]
                if self.stats["total_checked"] > 0
                else 0
            ),
        }

    def reset_stats(self):
        """Reset statistics."""
        self.stats = {"total_checked": 0, "filtered": 0, "by_reason": {}}
