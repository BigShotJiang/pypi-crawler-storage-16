"""
Inter-Procedural Taint Tracking for Data Flow Analysis

This module provides taint analysis to track how user input flows through
the codebase and reaches dangerous sinks (eval, exec, SQL queries, etc.).

Key capabilities:
1. Source identification - Find where untrusted data enters
2. Sink identification - Find dangerous operations
3. Taint propagation - Track data flow through variables and function calls
4. Path analysis - Report complete taint paths from source to sink
"""

import ast
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class TaintSource(str, Enum):
    """Sources of potentially tainted data."""

    USER_INPUT = "user_input"  # input(), request.*, argv
    FILE_READ = "file_read"  # file.read(), open()
    NETWORK = "network"  # requests.get(), socket.recv()
    DATABASE = "database"  # cursor.fetchall(), query results
    ENVIRONMENT = "environment"  # os.environ, getenv()
    AGENT_MESSAGE = "agent_message"  # LLM responses, agent outputs
    EXTERNAL_DATA = "external_data"  # API responses, webhooks


class TaintSink(str, Enum):
    """Dangerous operations that shouldn't receive tainted data."""

    CODE_EXEC = "code_execution"  # eval, exec, compile
    SHELL_EXEC = "shell_execution"  # os.system, subprocess, Popen
    SQL_QUERY = "sql_query"  # cursor.execute with string formatting
    FILE_WRITE = "file_write"  # open() with write mode
    DESERIALIZATION = "deserialization"  # pickle.loads, yaml.load
    LLM_PROMPT = "llm_prompt"  # Direct prompt injection risk
    PATH_ACCESS = "path_access"  # Path traversal risk


@dataclass
class TaintedVariable:
    """Represents a variable that contains tainted data."""

    name: str
    source: TaintSource
    source_line: int
    taint_path: list[str] = field(default_factory=list)
    confidence: float = 1.0


@dataclass
class TaintViolation:
    """A detected taint violation (tainted data reaching a sink)."""

    source: TaintSource
    sink: TaintSink
    source_line: int
    sink_line: int
    variable_name: str
    taint_path: list[str]
    file_path: str
    code_snippet: str
    confidence: float
    severity: str  # CRITICAL, HIGH, MEDIUM


@dataclass
class TaintAnalysisResult:
    """Complete result from taint analysis."""

    violations: list[TaintViolation]
    tainted_variables: dict[str, TaintedVariable]
    sources_found: int
    sinks_found: int
    paths_analyzed: int


class TaintTracker(ast.NodeVisitor):
    """
    AST-based inter-procedural taint tracker.

    Tracks data flow from sources (user input, file reads, etc.)
    to sinks (eval, exec, SQL queries, etc.) across function calls.
    """

    # Source patterns - where untrusted data enters
    SOURCE_PATTERNS = {
        TaintSource.USER_INPUT: [
            ("input", None),
            ("request", "form"),
            ("request", "args"),
            ("request", "json"),
            ("request", "data"),
            ("request", "files"),
            ("sys", "argv"),
            ("user_message", None),
            ("user_input", None),
            ("query", None),
        ],
        TaintSource.FILE_READ: [
            ("open", None),
            ("read", None),
            ("readlines", None),
            ("readline", None),
        ],
        TaintSource.NETWORK: [
            ("requests", "get"),
            ("requests", "post"),
            ("urllib", "urlopen"),
            ("socket", "recv"),
            ("fetch", None),
        ],
        TaintSource.DATABASE: [
            ("cursor", "fetchall"),
            ("cursor", "fetchone"),
            ("cursor", "fetchmany"),
            ("execute", None),  # When SELECT results
        ],
        TaintSource.AGENT_MESSAGE: [
            ("llm", "complete"),
            ("llm", "generate"),
            ("model", "invoke"),
            ("agent", "run"),
            ("chain", "invoke"),
            ("response", "content"),
            ("completion", None),
        ],
    }

    # Sink patterns - dangerous operations
    SINK_PATTERNS = {
        TaintSink.CODE_EXEC: [
            ("eval", None, "CRITICAL"),
            ("exec", None, "CRITICAL"),
            ("compile", None, "HIGH"),
            ("__import__", None, "HIGH"),
        ],
        TaintSink.SHELL_EXEC: [
            ("os", "system", "CRITICAL"),
            ("os", "popen", "CRITICAL"),
            ("subprocess", "run", "CRITICAL"),
            ("subprocess", "call", "CRITICAL"),
            ("subprocess", "Popen", "CRITICAL"),
            ("commands", "getoutput", "CRITICAL"),
        ],
        TaintSink.SQL_QUERY: [
            ("cursor", "execute", "CRITICAL"),
            ("db", "execute", "CRITICAL"),
            ("execute", None, "HIGH"),
            ("executemany", None, "HIGH"),
        ],
        TaintSink.FILE_WRITE: [
            ("open", None, "MEDIUM"),  # Only when mode='w'
            ("write", None, "MEDIUM"),
            ("writelines", None, "MEDIUM"),
        ],
        TaintSink.DESERIALIZATION: [
            ("pickle", "loads", "CRITICAL"),
            ("pickle", "load", "CRITICAL"),
            ("yaml", "load", "CRITICAL"),
            ("marshal", "loads", "HIGH"),
        ],
        TaintSink.LLM_PROMPT: [
            ("complete", None, "HIGH"),
            ("generate", None, "HIGH"),
            ("invoke", None, "HIGH"),
            ("format", None, "MEDIUM"),  # String formatting in prompts
        ],
    }

    # Functions that propagate taint
    PROPAGATING_FUNCTIONS = {
        "str",
        "repr",
        "format",
        "join",
        "split",
        "strip",
        "lower",
        "upper",
        "replace",
        "encode",
        "decode",
        "format_map",
        "f-string",
    }

    def __init__(self, file_path: str = ""):
        self.file_path = file_path
        self.tainted_vars: dict[str, TaintedVariable] = {}
        self.violations: list[TaintViolation] = []
        self.function_returns: dict[str, TaintedVariable | None] = {}
        self.current_function: str | None = None
        self.sources_found = 0
        self.sinks_found = 0
        self.source_lines: dict[int, str] = {}

    def analyze(self, code: str, file_path: str = "") -> TaintAnalysisResult:
        """Analyze code for taint violations."""
        self.file_path = file_path
        self.source_lines = {i + 1: line for i, line in enumerate(code.split("\n"))}

        try:
            tree = ast.parse(code)
            self.visit(tree)
        except SyntaxError:
            pass

        return TaintAnalysisResult(
            violations=self.violations,
            tainted_variables=self.tainted_vars,
            sources_found=self.sources_found,
            sinks_found=self.sinks_found,
            paths_analyzed=len(self.tainted_vars),
        )

    def visit_Assign(self, node: ast.Assign):
        """Track assignments that might propagate taint."""
        # Check if RHS is a taint source
        source_info = self._check_source(node.value)

        if source_info:
            source_type, confidence = source_info
            self.sources_found += 1

            for target in node.targets:
                if isinstance(target, ast.Name):
                    self.tainted_vars[target.id] = TaintedVariable(
                        name=target.id,
                        source=source_type,
                        source_line=node.lineno,
                        taint_path=[f"Line {node.lineno}: {target.id} = <{source_type.value}>"],
                        confidence=confidence,
                    )

        # Check if RHS uses a tainted variable
        elif self._uses_tainted_var(node.value):
            tainted = self._get_tainted_var_used(node.value)
            if tainted:
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        new_path = tainted.taint_path.copy()
                        new_path.append(
                            f"Line {node.lineno}: {target.id} = <propagated from {tainted.name}>"
                        )
                        self.tainted_vars[target.id] = TaintedVariable(
                            name=target.id,
                            source=tainted.source,
                            source_line=tainted.source_line,
                            taint_path=new_path,
                            confidence=tainted.confidence * 0.9,
                        )

        self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        """Check calls for sinks and track taint through function calls."""
        # Check if this is a dangerous sink
        sink_info = self._check_sink(node)

        if sink_info:
            sink_type, severity = sink_info
            self.sinks_found += 1

            # Check if any argument is tainted
            for arg in node.args:
                if self._uses_tainted_var(arg):
                    tainted = self._get_tainted_var_used(arg)
                    if tainted:
                        code_line = self.source_lines.get(node.lineno, "")
                        violation = TaintViolation(
                            source=tainted.source,
                            sink=sink_type,
                            source_line=tainted.source_line,
                            sink_line=node.lineno,
                            variable_name=tainted.name,
                            taint_path=tainted.taint_path
                            + [f"Line {node.lineno}: Sink <{sink_type.value}>"],
                            file_path=self.file_path,
                            code_snippet=code_line.strip(),
                            confidence=tainted.confidence,
                            severity=severity,
                        )
                        self.violations.append(violation)

        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef):
        """Track function definitions for inter-procedural analysis."""
        old_function = self.current_function
        self.current_function = node.name

        # Mark parameters as potentially tainted (conservative)
        for arg in node.args.args:
            param_name = arg.arg
            # Parameters are potential entry points for tainted data
            self.tainted_vars[param_name] = TaintedVariable(
                name=param_name,
                source=TaintSource.USER_INPUT,
                source_line=node.lineno,
                taint_path=[f"Line {node.lineno}: Parameter {param_name} (potential taint)"],
                confidence=0.5,  # Lower confidence for parameters
            )

        self.generic_visit(node)
        self.current_function = old_function

    def visit_JoinedStr(self, node: ast.JoinedStr):
        """Handle f-strings which can propagate taint."""
        for value in node.values:
            if isinstance(value, ast.FormattedValue):
                if self._uses_tainted_var(value.value):
                    # F-string with tainted value - potential issue
                    pass
        self.generic_visit(node)

    def _check_source(self, node: ast.expr) -> tuple[TaintSource, float] | None:
        """Check if a node represents a taint source."""
        if isinstance(node, ast.Call):
            func_name = self._get_func_name(node)

            for source_type, patterns in self.SOURCE_PATTERNS.items():
                for pattern in patterns:
                    if self._matches_pattern(func_name, pattern):
                        return (source_type, 1.0)

        elif isinstance(node, ast.Subscript):
            # Check for request.form['key'], os.environ['key'], etc.
            if isinstance(node.value, ast.Attribute):
                obj_name = self._get_attr_chain(node.value)
                if any(src in obj_name for src in ["request", "environ", "argv"]):
                    return (TaintSource.USER_INPUT, 1.0)

        return None

    def _check_sink(self, node: ast.Call) -> tuple[TaintSink, str] | None:
        """Check if a call is a dangerous sink."""
        func_name = self._get_func_name(node)

        for sink_type, patterns in self.SINK_PATTERNS.items():
            for pattern in patterns:
                if len(pattern) == 3:
                    obj, method, severity = pattern
                else:
                    obj, method = pattern
                    severity = "HIGH"

                if self._matches_pattern(func_name, (obj, method)):
                    # Extra check for SQL - only flag if string formatting is used
                    if sink_type == TaintSink.SQL_QUERY:
                        if not self._has_string_formatting(node):
                            continue
                    return (sink_type, severity)

        return None

    def _get_func_name(self, node: ast.Call) -> str:
        """Get the full function name from a Call node."""
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            return self._get_attr_chain(node.func)
        return ""

    def _get_attr_chain(self, node: ast.Attribute) -> str:
        """Get the full attribute chain (e.g., 'os.system')."""
        parts = []
        current = node
        while isinstance(current, ast.Attribute):
            parts.append(current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            parts.append(current.id)
        return ".".join(reversed(parts))

    def _matches_pattern(self, func_name: str, pattern: tuple) -> bool:
        """Check if function name matches a pattern."""
        obj, method = pattern
        if method is None:
            return func_name == obj or func_name.endswith(f".{obj}")
        return func_name == f"{obj}.{method}" or func_name.endswith(f".{method}")

    def _uses_tainted_var(self, node: ast.expr) -> bool:
        """Check if an expression uses a tainted variable."""
        if isinstance(node, ast.Name):
            return node.id in self.tainted_vars
        elif isinstance(node, ast.BinOp):
            return self._uses_tainted_var(node.left) or self._uses_tainted_var(node.right)
        elif isinstance(node, ast.Call):
            return any(self._uses_tainted_var(arg) for arg in node.args)
        elif isinstance(node, ast.JoinedStr):
            return any(
                (self._uses_tainted_var(v.value) if isinstance(v, ast.FormattedValue) else False)
                for v in node.values
            )
        elif isinstance(node, ast.Subscript):
            return self._uses_tainted_var(node.value)
        elif isinstance(node, ast.Attribute):
            return self._uses_tainted_var(node.value)
        return False

    def _get_tainted_var_used(self, node: ast.expr) -> TaintedVariable | None:
        """Get the tainted variable used in an expression."""
        if isinstance(node, ast.Name):
            return self.tainted_vars.get(node.id)
        elif isinstance(node, ast.BinOp):
            left = self._get_tainted_var_used(node.left)
            if left:
                return left
            return self._get_tainted_var_used(node.right)
        elif isinstance(node, ast.Call):
            for arg in node.args:
                tainted = self._get_tainted_var_used(arg)
                if tainted:
                    return tainted
        elif isinstance(node, ast.JoinedStr):
            for v in node.values:
                if isinstance(v, ast.FormattedValue):
                    tainted = self._get_tainted_var_used(v.value)
                    if tainted:
                        return tainted
        return None

    def _has_string_formatting(self, node: ast.Call) -> bool:
        """Check if a call uses string formatting (vulnerability indicator for SQL)."""
        for arg in node.args:
            if isinstance(arg, ast.JoinedStr):  # f-string
                return True
            if isinstance(arg, ast.BinOp) and isinstance(arg.op, ast.Mod):  # % formatting
                return True
            if isinstance(arg, ast.Call):
                func_name = self._get_func_name(arg)
                if func_name in ("format", "str.format"):
                    return True
        return False


def analyze_file(file_path: Path) -> TaintAnalysisResult:
    """Analyze a single file for taint violations."""
    try:
        code = file_path.read_text()
        tracker = TaintTracker(str(file_path))
        return tracker.analyze(code, str(file_path))
    except Exception:
        return TaintAnalysisResult(
            violations=[],
            tainted_variables={},
            sources_found=0,
            sinks_found=0,
            paths_analyzed=0,
        )


def analyze_directory(directory: Path) -> list[TaintViolation]:
    """Analyze all Python files in a directory."""
    violations = []

    for py_file in directory.rglob("*.py"):
        result = analyze_file(py_file)
        violations.extend(result.violations)

    return violations
