"""
Stage 2 XGBoost Training Pipeline.

Trains a gradient boosting classifier for secret detection using 20 engineered features.
Targets: 84%+ precision, 80%+ recall on validation set.
"""

import json
import sys
from pathlib import Path

import numpy as np

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent))

from src.vantage.security.detection.ml_features import FeatureExtractor, SecretFeatures
from src.vantage.security.detection.training.synthetic_data import (
    SyntheticDataGenerator,
    TrainingSample,
)


def extract_features_from_samples(
    samples: list[TrainingSample], feature_extractor: FeatureExtractor
) -> tuple[np.ndarray, np.ndarray]:
    """
    Extract feature vectors and labels from training samples.

    Args:
        samples: List of TrainingSample objects
        feature_extractor: FeatureExtractor instance

    Returns:
        Tuple of (features, labels) as numpy arrays
    """
    feature_vectors = []
    labels = []

    for sample in samples:
        try:
            # Extract features using existing FeatureExtractor
            features = feature_extractor.extract(
                text=sample.text, context=sample.context, file_path=sample.file_path
            )

            # Convert to vector
            feature_vector = features.to_vector()
            feature_vectors.append(feature_vector)
            labels.append(1 if sample.is_secret else 0)

        except Exception as e:
            print(f"Warning: Failed to extract features for sample: {e}")
            continue

    return np.array(feature_vectors), np.array(labels)


def train_xgboost_model(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_val: np.ndarray,
    y_val: np.ndarray,
    output_path: str = None,
) -> "xgboost.XGBClassifier":
    """
    Train XGBoost classifier for Stage 2.

    Args:
        X_train: Training features
        y_train: Training labels
        X_val: Validation features
        y_val: Validation labels
        output_path: Path to save trained model

    Returns:
        Trained XGBoost model
    """
    try:
        import xgboost as xgb
    except ImportError:
        print("ERROR: xgboost not installed. Install with: pip install xgboost")
        return None

    print("Training XGBoost model...")

    # Compute class weights for imbalanced data
    n_pos = np.sum(y_train == 1)
    n_neg = np.sum(y_train == 0)
    scale_pos_weight = n_neg / n_pos if n_pos > 0 else 1.0

    print(f"Class distribution: {n_pos} positives, {n_neg} negatives")
    print(f"Scale pos weight: {scale_pos_weight:.2f}")

    # XGBoost configuration
    model = xgb.XGBClassifier(
        objective="binary:logistic",
        max_depth=6,
        learning_rate=0.1,
        n_estimators=100,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=scale_pos_weight,
        random_state=42,
        tree_method="hist",
        eval_metric="logloss",
    )

    # Train with early stopping
    model.fit(X_train, y_train, eval_set=[(X_val, y_val)], verbose=10)

    # Evaluate on validation set
    print("\nEvaluating on validation set...")
    y_pred = model.predict(X_val)
    y_proba = model.predict_proba(X_val)[:, 1]

    # Calculate metrics
    from sklearn.metrics import (
        confusion_matrix,
        f1_score,
        precision_score,
        recall_score,
    )

    precision = precision_score(y_val, y_pred)
    recall = recall_score(y_val, y_pred)
    f1 = f1_score(y_val, y_pred)
    cm = confusion_matrix(y_val, y_pred)

    print("\nValidation Metrics:")
    print(f"  Precision: {precision:.3f} (target: >= 0.84)")
    print(f"  Recall: {recall:.3f} (target: >= 0.80)")
    print(f"  F1 Score: {f1:.3f}")
    print("\nConfusion Matrix:")
    print(f"  TN: {cm[0,0]:4d}  FP: {cm[0,1]:4d}")
    print(f"  FN: {cm[1,0]:4d}  TP: {cm[1,1]:4d}")

    # Check if targets are met
    targets_met = precision >= 0.84 and recall >= 0.80
    print(f"\nTargets met: {'YES' if targets_met else 'NO'}")

    # Save model
    if output_path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Save as JSON for ONNX conversion
        model.save_model(str(output_path))
        print(f"\nModel saved to: {output_path}")

        # Save metadata
        metadata = {
            "version": "1.0.0",
            "model_type": "xgboost",
            "num_features": X_train.shape[1],
            "feature_names": SecretFeatures.feature_names(),
            "metrics": {
                "precision": float(precision),
                "recall": float(recall),
                "f1": float(f1),
            },
            "training_params": {
                "max_depth": 6,
                "learning_rate": 0.1,
                "n_estimators": 100,
                "scale_pos_weight": float(scale_pos_weight),
            },
        }

        metadata_path = output_path.with_suffix(".metadata.json")
        with open(metadata_path, "w") as f:
            json.dump(metadata, f, indent=2)
        print(f"Metadata saved to: {metadata_path}")

    return model


def main():
    """Main training pipeline."""
    print("=" * 70)
    print("Stage 2 XGBoost Training Pipeline")
    print("=" * 70)

    # Step 1: Generate synthetic training data
    print("\n[1/4] Generating synthetic training data...")
    generator = SyntheticDataGenerator(seed=42)
    samples = generator.generate_dataset(num_samples=10000, positive_ratio=0.4)
    train_samples, val_samples, test_samples = generator.split_dataset(samples)

    print(f"  Train: {len(train_samples)} samples")
    print(f"  Val: {len(val_samples)} samples")
    print(f"  Test: {len(test_samples)} samples")

    # Step 2: Extract features
    print("\n[2/4] Extracting features from samples...")
    feature_extractor = FeatureExtractor()

    X_train, y_train = extract_features_from_samples(train_samples, feature_extractor)
    X_val, y_val = extract_features_from_samples(val_samples, feature_extractor)
    X_test, y_test = extract_features_from_samples(test_samples, feature_extractor)

    print(f"  Train features: {X_train.shape}")
    print(f"  Val features: {X_val.shape}")
    print(f"  Test features: {X_test.shape}")

    # Step 3: Train model
    print("\n[3/4] Training XGBoost model...")
    output_path = (
        Path(__file__).parent.parent.parent.parent.parent / "models" / "stage2_xgboost.json"
    )

    model = train_xgboost_model(X_train, y_train, X_val, y_val, output_path=str(output_path))

    if model is None:
        print("ERROR: Model training failed")
        return 1

    # Step 4: Final evaluation on test set
    print("\n[4/4] Final evaluation on test set...")
    y_pred = model.predict(X_test)

    from sklearn.metrics import (
        classification_report,
        f1_score,
        precision_score,
        recall_score,
    )

    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)

    print("\nTest Set Metrics:")
    print(f"  Precision: {precision:.3f}")
    print(f"  Recall: {recall:.3f}")
    print(f"  F1 Score: {f1:.3f}")

    print("\nDetailed Classification Report:")
    print(classification_report(y_test, y_pred, target_names=["Non-Secret", "Secret"]))

    print("\n" + "=" * 70)
    print("Training Complete!")
    print("=" * 70)
    print("\nNext steps:")
    print("  1. Convert model to ONNX: python deployment/convert_to_onnx.py")
    print("  2. Run benchmarks: python tests/benchmark_stage2.py")
    print("  3. Integrate with MLSecretClassifier")

    return 0


if __name__ == "__main__":
    exit(main())
