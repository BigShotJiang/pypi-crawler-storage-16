"""
Real-world vulnerability data collector for training world-class security models.

This module downloads and processes real vulnerability data from:
- GitHub Security Advisory Database (GHSA)
- CVEfixes dataset
- OWASP Benchmark
- NVD/CVE database

No synthetic data - only real, labeled vulnerabilities.
"""

import json
import logging
import os
import re
import subprocess
from collections.abc import Iterator
from dataclasses import dataclass, field
from pathlib import Path

import requests

logger = logging.getLogger(__name__)


@dataclass
class VulnerabilityExample:
    """A single vulnerability example for training."""

    id: str  # CVE or GHSA ID
    code: str  # The vulnerable code
    fixed_code: str | None  # The fixed version (if available)
    cwe_id: str | None  # CWE classification
    severity: str  # critical, high, medium, low
    vulnerability_type: str  # injection, code_execution, etc.
    language: str  # python, javascript, etc.
    source: str  # ghsa, cvefixes, owasp, nvd
    description: str
    file_path: str | None = None
    line_number: int | None = None
    is_vulnerable: bool = True  # True for vulnerable, False for safe
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "code": self.code,
            "fixed_code": self.fixed_code,
            "cwe_id": self.cwe_id,
            "severity": self.severity,
            "vulnerability_type": self.vulnerability_type,
            "language": self.language,
            "source": self.source,
            "description": self.description,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "is_vulnerable": self.is_vulnerable,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "VulnerabilityExample":
        return cls(**data)


class GHSACollector:
    """
    Collect vulnerabilities from GitHub Security Advisory Database.

    The GHSA database contains 22,000+ reviewed security advisories
    with excellent Python/PyPI coverage.
    """

    GHSA_REPO = "https://github.com/github/advisory-database.git"
    GHSA_API = "https://api.github.com/advisories"

    # CWE to vulnerability type mapping
    CWE_TO_TYPE = {
        "CWE-78": "command_injection",
        "CWE-79": "xss",
        "CWE-89": "sql_injection",
        "CWE-94": "code_execution",
        "CWE-95": "code_injection",
        "CWE-96": "code_injection",
        "CWE-98": "file_inclusion",
        "CWE-119": "buffer_overflow",
        "CWE-125": "buffer_overflow",
        "CWE-200": "information_disclosure",
        "CWE-250": "privilege_escalation",
        "CWE-269": "privilege_escalation",
        "CWE-287": "authentication_bypass",
        "CWE-295": "certificate_validation",
        "CWE-311": "missing_encryption",
        "CWE-312": "plaintext_storage",
        "CWE-319": "cleartext_transmission",
        "CWE-327": "weak_crypto",
        "CWE-352": "csrf",
        "CWE-400": "dos",
        "CWE-434": "file_upload",
        "CWE-502": "deserialization",
        "CWE-522": "weak_credentials",
        "CWE-601": "open_redirect",
        "CWE-611": "xxe",
        "CWE-798": "hardcoded_credentials",
        "CWE-918": "ssrf",
    }

    def __init__(self, cache_dir: Path | None = None, github_token: str | None = None):
        self.cache_dir = cache_dir or Path.home() / ".cache" / "vantage" / "ghsa"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.github_token = github_token or os.environ.get("GITHUB_TOKEN")

    def _get_headers(self) -> dict:
        headers = {"Accept": "application/vnd.github+json"}
        if self.github_token:
            headers["Authorization"] = f"Bearer {self.github_token}"
        return headers

    def collect_from_api(
        self, ecosystem: str = "pip", severity: str | None = None, limit: int = 1000
    ) -> Iterator[VulnerabilityExample]:
        """
        Collect advisories from GitHub API.

        Args:
            ecosystem: Package ecosystem (pip, npm, maven, etc.)
            severity: Filter by severity (critical, high, medium, low)
            limit: Maximum number of advisories to fetch
        """
        logger.info(f"Collecting GHSA advisories for {ecosystem} (limit={limit})")

        params = {
            "ecosystem": ecosystem,
            "per_page": 100,
        }
        if severity:
            params["severity"] = severity

        collected = 0
        page = 1

        while collected < limit:
            params["page"] = page

            try:
                response = requests.get(
                    self.GHSA_API,
                    headers=self._get_headers(),
                    params=params,
                    timeout=30,
                )
                response.raise_for_status()
                advisories = response.json()

                if not advisories:
                    break

                for advisory in advisories:
                    if collected >= limit:
                        break

                    example = self._parse_advisory(advisory)
                    if example:
                        collected += 1
                        yield example

                page += 1

            except requests.RequestException as e:
                logger.error(f"Error fetching GHSA advisories: {e}")
                break

        logger.info(f"Collected {collected} GHSA advisories")

    def _parse_advisory(self, advisory: dict) -> VulnerabilityExample | None:
        """Parse a GHSA advisory into a VulnerabilityExample."""
        try:
            ghsa_id = advisory.get("ghsa_id", "")
            cve_id = advisory.get("cve_id")

            # Get CWE
            cwes = advisory.get("cwes", [])
            cwe_id = cwes[0].get("cwe_id") if cwes else None

            # Map CWE to vulnerability type
            vuln_type = "unknown"
            if cwe_id:
                vuln_type = self.CWE_TO_TYPE.get(cwe_id, "unknown")

            # Get severity
            severity = advisory.get("severity", "medium").lower()

            # Get description (contains vulnerability details)
            description = advisory.get("description", "")
            summary = advisory.get("summary", "")

            # Try to extract code from description
            code = self._extract_code_from_description(description)

            # Get references for more context
            references = advisory.get("references", [])

            return VulnerabilityExample(
                id=ghsa_id or cve_id or "unknown",
                code=code or description[:500],
                fixed_code=None,
                cwe_id=cwe_id,
                severity=severity,
                vulnerability_type=vuln_type,
                language="python",
                source="ghsa",
                description=f"{summary}\n\n{description}",
                is_vulnerable=True,
                metadata={
                    "cve_id": cve_id,
                    "ghsa_id": ghsa_id,
                    "references": (references[:5] if isinstance(references, list) else []),
                    "published_at": advisory.get("published_at"),
                    "updated_at": advisory.get("updated_at"),
                },
            )
        except Exception as e:
            logger.warning(f"Error parsing advisory: {e}")
            return None

    def _extract_code_from_description(self, description: str) -> str | None:
        """Extract code blocks from markdown description."""
        # Look for code blocks
        code_pattern = r"```(?:python|py)?\n(.*?)```"
        matches = re.findall(code_pattern, description, re.DOTALL)
        if matches:
            return matches[0].strip()

        # Look for inline code that looks like function calls
        inline_pattern = r"`([^`]+\([^)]*\))`"
        matches = re.findall(inline_pattern, description)
        if matches:
            return matches[0]

        return None


class CVEFixesCollector:
    """
    Collect vulnerabilities from CVEfixes dataset.

    CVEfixes contains 11,873 CVEs with 138,974 changed functions,
    including before/after code pairs.
    """

    CVEFIXES_URL = "https://zenodo.org/record/4476563/files/CVEfixes_v1.0.7.zip"

    def __init__(self, cache_dir: Path | None = None):
        self.cache_dir = cache_dir or Path.home() / ".cache" / "vantage" / "cvefixes"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.cache_dir / "CVEfixes.db"

    def download(self) -> bool:
        """Download CVEfixes dataset if not cached."""
        if self.db_path.exists():
            logger.info("CVEfixes database already cached")
            return True

        logger.info("Downloading CVEfixes dataset...")

        try:
            zip_path = self.cache_dir / "cvefixes.zip"

            response = requests.get(self.CVEFIXES_URL, stream=True, timeout=300)
            response.raise_for_status()

            with open(zip_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

            # Extract
            import zipfile

            with zipfile.ZipFile(zip_path, "r") as z:
                z.extractall(self.cache_dir)

            zip_path.unlink()
            logger.info("CVEfixes downloaded successfully")
            return True

        except Exception as e:
            logger.error(f"Error downloading CVEfixes: {e}")
            return False

    def collect(
        self, language: str = "Python", limit: int = 5000
    ) -> Iterator[VulnerabilityExample]:
        """
        Collect vulnerabilities from CVEfixes database.

        Args:
            language: Programming language to filter
            limit: Maximum examples to collect
        """
        if not self.db_path.exists():
            if not self.download():
                logger.error("CVEfixes database not available")
                return

        import sqlite3

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Query for vulnerable functions with their fixes
        query = """
        SELECT
            c.cve_id,
            c.cwe_id,
            c.severity,
            c.description,
            f.name as func_name,
            f.before_change,
            f.after_change,
            fi.filename,
            fi.programming_language
        FROM cve c
        JOIN file_change fc ON c.cve_id = fc.cve_id
        JOIN file fi ON fc.file_change_id = fi.file_change_id
        JOIN method_change f ON fc.file_change_id = f.file_change_id
        WHERE fi.programming_language = ?
        AND f.before_change IS NOT NULL
        AND f.before_change != ''
        LIMIT ?
        """

        try:
            cursor.execute(query, (language, limit))
            rows = cursor.fetchall()

            logger.info(f"Found {len(rows)} {language} vulnerabilities in CVEfixes")

            for row in rows:
                (
                    cve_id,
                    cwe_id,
                    severity,
                    desc,
                    func_name,
                    before,
                    after,
                    filename,
                    lang,
                ) = row

                # Map CWE to type
                vuln_type = GHSACollector.CWE_TO_TYPE.get(cwe_id, "unknown")

                yield VulnerabilityExample(
                    id=cve_id,
                    code=before,
                    fixed_code=after,
                    cwe_id=cwe_id,
                    severity=severity or "medium",
                    vulnerability_type=vuln_type,
                    language=lang.lower(),
                    source="cvefixes",
                    description=desc or "",
                    file_path=filename,
                    is_vulnerable=True,
                    metadata={
                        "function_name": func_name,
                        "has_fix": after is not None,
                    },
                )

        finally:
            conn.close()


class OWASPBenchmarkCollector:
    """
    Collect from OWASP Benchmark - evaluation gold standard.

    Contains 3,000 test cases with 50% real vulnerabilities
    and 50% safe decoys, with 100% known exploitability.
    """

    BENCHMARK_REPO = "https://github.com/OWASP-Benchmark/BenchmarkPython.git"

    # OWASP test case categories
    CATEGORIES = {
        "cmdi": "command_injection",
        "sqli": "sql_injection",
        "xss": "xss",
        "pathtraver": "path_traversal",
        "securecookie": "insecure_cookie",
        "ldapi": "ldap_injection",
        "crypto": "weak_crypto",
        "hash": "weak_hash",
        "random": "weak_random",
        "trustbound": "trust_boundary",
        "xxe": "xxe",
    }

    def __init__(self, cache_dir: Path | None = None):
        self.cache_dir = cache_dir or Path.home() / ".cache" / "vantage" / "owasp"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.repo_path = self.cache_dir / "BenchmarkPython"

    def download(self) -> bool:
        """Clone OWASP Benchmark repository."""
        if self.repo_path.exists():
            logger.info("OWASP Benchmark already cached")
            return True

        logger.info("Cloning OWASP Benchmark...")

        try:
            result = subprocess.run(
                [
                    "git",
                    "clone",
                    "--depth",
                    "1",
                    self.BENCHMARK_REPO,
                    str(self.repo_path),
                ],
                capture_output=True,
                text=True,
                timeout=300,
            )

            if result.returncode != 0:
                logger.error(f"Git clone failed: {result.stderr}")
                return False

            logger.info("OWASP Benchmark cloned successfully")
            return True

        except Exception as e:
            logger.error(f"Error cloning OWASP Benchmark: {e}")
            return False

    def collect(self, limit: int = 3000) -> Iterator[VulnerabilityExample]:
        """
        Collect test cases from OWASP Benchmark.

        Each test case is labeled as vulnerable or safe.
        """
        if not self.repo_path.exists():
            if not self.download():
                return

        # Look for test case files
        test_dir = self.repo_path / "src" / "main" / "python"

        if not test_dir.exists():
            # Try alternate structure
            test_dir = self.repo_path

        # Find Python test files
        collected = 0
        for py_file in test_dir.rglob("*.py"):
            if collected >= limit:
                break

            # Parse test case metadata from filename/content
            example = self._parse_test_file(py_file)
            if example:
                collected += 1
                yield example

        logger.info(f"Collected {collected} OWASP Benchmark test cases")

    def _parse_test_file(self, file_path: Path) -> VulnerabilityExample | None:
        """Parse an OWASP test case file."""
        try:
            content = file_path.read_text()
            filename = file_path.name

            # Extract test case info from filename (e.g., BenchmarkTest00001_cmdi.py)
            match = re.match(r"Benchmark(?:Test)?(\d+)_?(\w+)?", filename)
            if not match:
                return None

            test_id = match.group(1)
            category = match.group(2) or "unknown"

            # Determine if vulnerable from comments or metadata
            is_vulnerable = (
                "# vulnerable" in content.lower() or "vulnerability: true" in content.lower()
            )

            # Get CWE from content
            cwe_match = re.search(r"CWE[- ]?(\d+)", content)
            cwe_id = f"CWE-{cwe_match.group(1)}" if cwe_match else None

            vuln_type = self.CATEGORIES.get(category.lower(), "unknown")

            return VulnerabilityExample(
                id=f"OWASP-{test_id}",
                code=content,
                fixed_code=None,
                cwe_id=cwe_id,
                severity="high" if is_vulnerable else "info",
                vulnerability_type=vuln_type,
                language="python",
                source="owasp",
                description=f"OWASP Benchmark test case {test_id} ({category})",
                file_path=str(file_path),
                is_vulnerable=is_vulnerable,
                metadata={
                    "category": category,
                    "test_id": test_id,
                },
            )

        except Exception as e:
            logger.warning(f"Error parsing {file_path}: {e}")
            return None


class SecListsCollector:
    """
    Collect security patterns from SecLists.

    SecLists contains fuzzing payloads, attack patterns, and
    security testing data.
    """

    SECLISTS_REPO = "https://github.com/danielmiessler/SecLists.git"

    def __init__(self, cache_dir: Path | None = None):
        self.cache_dir = cache_dir or Path.home() / ".cache" / "vantage" / "seclists"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.repo_path = self.cache_dir / "SecLists"

    def download(self) -> bool:
        """Clone SecLists repository (sparse checkout for relevant dirs)."""
        if self.repo_path.exists():
            logger.info("SecLists already cached")
            return True

        logger.info("Cloning SecLists (this may take a while)...")

        try:
            # Sparse clone to get only what we need
            result = subprocess.run(
                [
                    "git",
                    "clone",
                    "--depth",
                    "1",
                    "--filter=blob:none",
                    "--sparse",
                    self.SECLISTS_REPO,
                    str(self.repo_path),
                ],
                capture_output=True,
                text=True,
                timeout=600,
            )

            if result.returncode != 0:
                logger.warning(f"Sparse clone failed, trying full clone: {result.stderr}")
                result = subprocess.run(
                    [
                        "git",
                        "clone",
                        "--depth",
                        "1",
                        self.SECLISTS_REPO,
                        str(self.repo_path),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=600,
                )

            if result.returncode != 0:
                logger.error(f"Git clone failed: {result.stderr}")
                return False

            logger.info("SecLists cloned successfully")
            return True

        except Exception as e:
            logger.error(f"Error cloning SecLists: {e}")
            return False

    def collect_injection_patterns(self) -> Iterator[str]:
        """Collect injection attack patterns."""
        if not self.repo_path.exists():
            if not self.download():
                return

        patterns_dirs = [
            "Fuzzing/command-injection-commix.txt",
            "Fuzzing/SQLi",
            "Fuzzing/XSS",
            "Fuzzing/command-injection",
        ]

        for pattern_path in patterns_dirs:
            full_path = self.repo_path / pattern_path
            if full_path.is_file():
                yield from self._read_patterns_file(full_path)
            elif full_path.is_dir():
                for f in full_path.glob("*.txt"):
                    yield from self._read_patterns_file(f)

    def _read_patterns_file(self, path: Path) -> Iterator[str]:
        """Read patterns from a file."""
        try:
            content = path.read_text(errors="ignore")
            for line in content.splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    yield line
        except Exception as e:
            logger.warning(f"Error reading {path}: {e}")


class VulnerabilityDataset:
    """
    Combined vulnerability dataset from all sources.

    This class orchestrates data collection from multiple sources
    and provides a unified interface for training.
    """

    def __init__(self, cache_dir: Path | None = None):
        self.cache_dir = cache_dir or Path.home() / ".cache" / "vantage" / "vulnerability_data"
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        self.ghsa = GHSACollector(self.cache_dir / "ghsa")
        self.cvefixes = CVEFixesCollector(self.cache_dir / "cvefixes")
        self.owasp = OWASPBenchmarkCollector(self.cache_dir / "owasp")
        self.seclists = SecListsCollector(self.cache_dir / "seclists")

        self.dataset_path = self.cache_dir / "vulnerability_dataset.jsonl"

    def collect_all(
        self,
        ghsa_limit: int = 2000,
        cvefixes_limit: int = 5000,
        owasp_limit: int = 3000,
        save: bool = True,
    ) -> list[VulnerabilityExample]:
        """
        Collect vulnerabilities from all sources.

        Args:
            ghsa_limit: Max GHSA advisories
            cvefixes_limit: Max CVEfixes examples
            owasp_limit: Max OWASP test cases
            save: Whether to save to disk

        Returns:
            List of VulnerabilityExample objects
        """
        examples = []

        # Collect from GHSA
        logger.info("Collecting from GitHub Security Advisories...")
        for example in self.ghsa.collect_from_api(limit=ghsa_limit):
            examples.append(example)

        # Collect from CVEfixes
        logger.info("Collecting from CVEfixes...")
        for example in self.cvefixes.collect(limit=cvefixes_limit):
            examples.append(example)

        # Collect from OWASP
        logger.info("Collecting from OWASP Benchmark...")
        for example in self.owasp.collect(limit=owasp_limit):
            examples.append(example)

        logger.info(f"Total collected: {len(examples)} vulnerability examples")

        # Deduplicate by code hash
        examples = self._deduplicate(examples)
        logger.info(f"After deduplication: {len(examples)} examples")

        if save:
            self.save(examples)

        return examples

    def _deduplicate(self, examples: list[VulnerabilityExample]) -> list[VulnerabilityExample]:
        """Remove duplicate examples based on code hash."""
        seen = set()
        unique = []

        for ex in examples:
            # Hash the code content
            code_hash = hash(ex.code.strip())
            if code_hash not in seen:
                seen.add(code_hash)
                unique.append(ex)

        return unique

    def save(self, examples: list[VulnerabilityExample]) -> None:
        """Save dataset to JSONL file."""
        with open(self.dataset_path, "w") as f:
            for ex in examples:
                f.write(json.dumps(ex.to_dict()) + "\n")
        logger.info(f"Saved {len(examples)} examples to {self.dataset_path}")

    def load(self) -> list[VulnerabilityExample]:
        """Load dataset from JSONL file."""
        if not self.dataset_path.exists():
            logger.warning("Dataset file not found")
            return []

        examples = []
        with open(self.dataset_path) as f:
            for line in f:
                data = json.loads(line)
                examples.append(VulnerabilityExample.from_dict(data))

        logger.info(f"Loaded {len(examples)} examples from {self.dataset_path}")
        return examples

    def get_statistics(self) -> dict:
        """Get dataset statistics."""
        examples = self.load()

        stats = {
            "total": len(examples),
            "by_source": {},
            "by_severity": {},
            "by_type": {},
            "by_cwe": {},
            "vulnerable_count": 0,
            "safe_count": 0,
        }

        for ex in examples:
            # By source
            stats["by_source"][ex.source] = stats["by_source"].get(ex.source, 0) + 1

            # By severity
            stats["by_severity"][ex.severity] = stats["by_severity"].get(ex.severity, 0) + 1

            # By type
            stats["by_type"][ex.vulnerability_type] = (
                stats["by_type"].get(ex.vulnerability_type, 0) + 1
            )

            # By CWE
            if ex.cwe_id:
                stats["by_cwe"][ex.cwe_id] = stats["by_cwe"].get(ex.cwe_id, 0) + 1

            # Vulnerable vs safe
            if ex.is_vulnerable:
                stats["vulnerable_count"] += 1
            else:
                stats["safe_count"] += 1

        return stats


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    # Collect vulnerability data
    dataset = VulnerabilityDataset()
    examples = dataset.collect_all()

    # Print statistics
    stats = dataset.get_statistics()
    print("\nDataset Statistics:")
    print(f"  Total examples: {stats['total']}")
    print(f"  Vulnerable: {stats['vulnerable_count']}")
    print(f"  Safe: {stats['safe_count']}")
    print("\nBy Source:")
    for source, count in stats["by_source"].items():
        print(f"  {source}: {count}")
    print("\nBy Severity:")
    for sev, count in stats["by_severity"].items():
        print(f"  {sev}: {count}")
    print("\nTop Vulnerability Types:")
    for vtype, count in sorted(stats["by_type"].items(), key=lambda x: -x[1])[:10]:
        print(f"  {vtype}: {count}")
