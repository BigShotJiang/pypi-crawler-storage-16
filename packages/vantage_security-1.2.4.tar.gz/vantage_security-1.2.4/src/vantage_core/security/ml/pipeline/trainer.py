"""
Model trainer with incremental learning support.

Supports:
- Initial training from scratch
- Incremental updates with new vulnerabilities
- Model versioning and rollback
- Training metrics and evaluation
"""

import json
import logging
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Optional ML imports
try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, Dataset

    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    from transformers import AutoModel, AutoTokenizer, get_linear_schedule_with_warmup

    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False


@dataclass
class TrainingConfig:
    """Configuration for model training."""

    # Model settings
    model_name: str = "microsoft/codebert-base"  # Smaller than GraphCodeBERT
    max_length: int = 256  # Reduced for memory efficiency
    num_labels: int = 2  # vulnerable / safe

    # Training hyperparameters - optimized for CPU/low memory
    batch_size: int = 4  # Reduced for memory
    learning_rate: float = 2e-5
    epochs: int = 3
    warmup_ratio: float = 0.1
    weight_decay: float = 0.01
    gradient_accumulation_steps: int = 4  # Effective batch size = 16

    # Incremental training
    incremental_epochs: int = 1
    min_new_samples: int = 100  # Minimum new samples to trigger retraining
    max_train_samples: int = 500  # Limit samples for memory efficiency

    # Paths
    output_dir: Path = Path("models/vulnerability_detector")
    checkpoint_dir: Path = Path("models/checkpoints")

    # Evaluation
    eval_split: float = 0.1
    early_stopping_patience: int = 3

    # Memory optimization
    use_fp16: bool = False  # Enable if GPU available
    gradient_checkpointing: bool = True  # Save memory during training


@dataclass
class TrainingMetrics:
    """Metrics from a training run."""

    epoch: int
    train_loss: float
    val_loss: float | None
    accuracy: float | None
    precision: float | None
    recall: float | None
    f1_score: float | None
    timestamp: str


class VulnerabilityDataset(Dataset):
    """PyTorch dataset for vulnerability detection."""

    def __init__(self, examples: list[dict], tokenizer: Any, max_length: int = 512):
        self.examples = examples
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, idx: int) -> dict:
        example = self.examples[idx]
        code = example.get("code", "")

        # Tokenize
        encoding = self.tokenizer(
            code,
            truncation=True,
            max_length=self.max_length,
            padding="max_length",
            return_tensors="pt",
        )

        # Label: 1 = vulnerable, 0 = safe
        label = 1 if example.get("is_vulnerable", True) else 0

        return {
            "input_ids": encoding["input_ids"].squeeze(),
            "attention_mask": encoding["attention_mask"].squeeze(),
            "labels": torch.tensor(label),
        }


class ModelTrainer:
    """
    Trainer for vulnerability detection model.

    Supports both full training and incremental updates.
    """

    def __init__(self, config: TrainingConfig | None = None):
        self.config = config or TrainingConfig()
        self.config.output_dir = Path(self.config.output_dir)
        self.config.checkpoint_dir = Path(self.config.checkpoint_dir)

        self.config.output_dir.mkdir(parents=True, exist_ok=True)
        self.config.checkpoint_dir.mkdir(parents=True, exist_ok=True)

        self.model = None
        self.tokenizer = None
        self.device = "cuda" if TORCH_AVAILABLE and torch.cuda.is_available() else "cpu"

        self.training_history: list[TrainingMetrics] = []
        self._load_history()

    def _load_history(self):
        """Load training history from disk."""
        history_path = self.config.output_dir / "training_history.json"
        if history_path.exists():
            with open(history_path) as f:
                data = json.load(f)
                self.training_history = [TrainingMetrics(**m) for m in data]

    def _save_history(self):
        """Save training history to disk."""
        history_path = self.config.output_dir / "training_history.json"
        with open(history_path, "w") as f:
            json.dump([vars(m) for m in self.training_history], f, indent=2)

    def initialize_model(self, load_weights: bool = True):
        """Initialize model and tokenizer.

        Args:
            load_weights: If True, load existing weights. If False, start fresh.
        """
        if not TORCH_AVAILABLE or not TRANSFORMERS_AVAILABLE:
            raise RuntimeError("PyTorch and Transformers required for training")

        logger.info(f"Initializing model: {self.config.model_name}")
        logger.info(f"  Max length: {self.config.max_length}")
        logger.info(f"  Batch size: {self.config.batch_size}")
        logger.info(f"  Gradient accumulation: {self.config.gradient_accumulation_steps}")
        logger.info(f"  Max train samples: {self.config.max_train_samples}")

        self.tokenizer = AutoTokenizer.from_pretrained(self.config.model_name)

        # Build model
        from vantage_core.security.ml.vulnerability_model import (
            GraphCodeBERTVulnerabilityModel,
        )

        self.model = GraphCodeBERTVulnerabilityModel(
            model_name=self.config.model_name,
            num_labels=self.config.num_labels,
        )

        # Enable gradient checkpointing to save memory during training
        if self.config.gradient_checkpointing:
            if hasattr(self.model, "encoder") and hasattr(
                self.model.encoder, "gradient_checkpointing_enable"
            ):
                logger.info("Enabling gradient checkpointing for memory efficiency")
                self.model.encoder.gradient_checkpointing_enable()

        # Load existing weights if available and requested
        if load_weights:
            weights_path = self.config.output_dir / "model.pt"
            if weights_path.exists():
                logger.info(f"Loading existing weights from {weights_path}")
                state_dict = torch.load(weights_path, map_location=self.device)
                self.model.load_state_dict(state_dict)
        else:
            logger.info("Starting with fresh model weights (not loading existing)")

        self.model.to(self.device)
        logger.info(f"Model initialized on {self.device}")

    def train(
        self,
        train_data: list[dict],
        val_data: list[dict] | None = None,
        incremental: bool = False,
        fresh_start: bool = False,
    ) -> dict:
        """
        Train the model.

        Args:
            train_data: Training examples
            val_data: Validation examples (optional)
            incremental: If True, do incremental training with fewer epochs
            fresh_start: If True, start with fresh weights (don't load existing)

        Returns:
            Training metrics
        """
        if not self.model:
            self.initialize_model(load_weights=not fresh_start)

        # Check if we have enough data for incremental training
        if incremental and len(train_data) < self.config.min_new_samples:
            logger.info(f"Not enough new samples ({len(train_data)}) for incremental training")
            return {"status": "skipped", "reason": "insufficient_samples"}

        # Apply max_train_samples limit to prevent OOM
        if self.config.max_train_samples and len(train_data) > self.config.max_train_samples:
            logger.info(
                f"Limiting training data from {len(train_data)} to {self.config.max_train_samples} samples"
            )
            from random import sample

            train_data = sample(train_data, self.config.max_train_samples)

        # Similarly limit validation data
        max_val_samples = (
            self.config.max_train_samples // 5 if self.config.max_train_samples else None
        )
        if val_data and max_val_samples and len(val_data) > max_val_samples:
            from random import sample

            val_data = sample(val_data, max_val_samples)

        # Prepare datasets
        train_dataset = VulnerabilityDataset(train_data, self.tokenizer, self.config.max_length)

        val_dataset = None
        if val_data:
            val_dataset = VulnerabilityDataset(val_data, self.tokenizer, self.config.max_length)

        train_loader = DataLoader(
            train_dataset,
            batch_size=self.config.batch_size,
            shuffle=True,
        )

        val_loader = None
        if val_dataset:
            val_loader = DataLoader(
                val_dataset,
                batch_size=self.config.batch_size,
            )

        # Setup optimizer
        epochs = self.config.incremental_epochs if incremental else self.config.epochs
        total_steps = len(train_loader) * epochs

        optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=self.config.learning_rate,
            weight_decay=self.config.weight_decay,
        )

        scheduler = get_linear_schedule_with_warmup(
            optimizer,
            num_warmup_steps=int(total_steps * self.config.warmup_ratio),
            num_training_steps=total_steps,
        )

        # Training loop
        logger.info(f"Starting {'incremental' if incremental else 'full'} training...")
        logger.info(f"  Epochs: {epochs}")
        logger.info(f"  Training samples: {len(train_data)}")
        logger.info(f"  Batch size: {self.config.batch_size}")

        best_val_loss = float("inf")
        patience_counter = 0

        for epoch in range(epochs):
            # Train
            train_loss = self._train_epoch(train_loader, optimizer, scheduler)

            # Evaluate
            val_loss, accuracy, precision, recall, f1 = None, None, None, None, None
            if val_loader:
                val_loss, accuracy, precision, recall, f1 = self._evaluate(val_loader)

            # Log metrics
            metrics = TrainingMetrics(
                epoch=len(self.training_history) + 1,
                train_loss=train_loss,
                val_loss=val_loss,
                accuracy=accuracy,
                precision=precision,
                recall=recall,
                f1_score=f1,
                timestamp=datetime.utcnow().isoformat(),
            )
            self.training_history.append(metrics)

            logger.info(f"Epoch {epoch + 1}/{epochs}")
            logger.info(f"  Train Loss: {train_loss:.4f}")
            if val_loss is not None:
                logger.info(f"  Val Loss: {val_loss:.4f}")
                logger.info(f"  Accuracy: {accuracy:.4f}, F1: {f1:.4f}")

            # Early stopping
            if val_loss is not None:
                if val_loss < best_val_loss:
                    best_val_loss = val_loss
                    patience_counter = 0
                    # Save best model
                    self._save_checkpoint("best")
                else:
                    patience_counter += 1
                    if patience_counter >= self.config.early_stopping_patience:
                        logger.info("Early stopping triggered")
                        break

        # Save final model
        self._save_model()
        self._save_history()

        return {
            "status": "completed",
            "epochs_trained": epoch + 1,
            "final_train_loss": train_loss,
            "final_val_loss": val_loss,
            "best_val_loss": best_val_loss,
            "accuracy": accuracy,
            "f1_score": f1,
        }

    def _train_epoch(
        self,
        train_loader: DataLoader,
        optimizer: Any,
        scheduler: Any,
    ) -> float:
        """Train for one epoch with gradient accumulation."""
        self.model.train()
        total_loss = 0
        accumulation_steps = self.config.gradient_accumulation_steps

        optimizer.zero_grad()

        for step, batch in enumerate(train_loader):
            input_ids = batch["input_ids"].to(self.device)
            attention_mask = batch["attention_mask"].to(self.device)
            labels = batch["labels"].to(self.device)

            outputs = self.model(input_ids, attention_mask, labels=labels)
            loss = outputs["loss"]

            # Scale loss for gradient accumulation
            loss = loss / accumulation_steps
            loss.backward()

            total_loss += loss.item() * accumulation_steps

            # Update weights after accumulation_steps
            if (step + 1) % accumulation_steps == 0 or (step + 1) == len(train_loader):
                # Gradient clipping to prevent exploding gradients
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad()

            # Clear cache periodically to free memory
            if (step + 1) % 10 == 0 and self.device == "cuda":
                torch.cuda.empty_cache()

        return total_loss / len(train_loader)

    def _evaluate(self, val_loader: DataLoader) -> tuple:
        """Evaluate the model."""
        self.model.eval()
        total_loss = 0
        all_preds = []
        all_labels = []

        with torch.no_grad():
            for batch in val_loader:
                input_ids = batch["input_ids"].to(self.device)
                attention_mask = batch["attention_mask"].to(self.device)
                labels = batch["labels"].to(self.device)

                outputs = self.model(input_ids, attention_mask, labels=labels)
                loss = outputs["loss"]
                # Use vuln_logits (from our model) or logits (standard)
                logits = (
                    outputs.get("vuln_logits")
                    if "vuln_logits" in outputs
                    else outputs.get("logits")
                )

                total_loss += loss.item()

                preds = torch.argmax(logits, dim=1)
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())

        # Calculate metrics
        val_loss = total_loss / len(val_loader)

        tp = sum(1 for p, l in zip(all_preds, all_labels) if p == 1 and l == 1)
        tn = sum(1 for p, l in zip(all_preds, all_labels) if p == 0 and l == 0)
        fp = sum(1 for p, l in zip(all_preds, all_labels) if p == 1 and l == 0)
        fn = sum(1 for p, l in zip(all_preds, all_labels) if p == 0 and l == 1)

        accuracy = (tp + tn) / len(all_labels) if all_labels else 0
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

        return val_loss, accuracy, precision, recall, f1

    def _save_model(self):
        """Save the model."""
        model_path = self.config.output_dir / "model.pt"
        torch.save(self.model.state_dict(), model_path)

        # Save config
        config_path = self.config.output_dir / "config.json"
        with open(config_path, "w") as f:
            json.dump(
                {
                    "model_name": self.config.model_name,
                    "max_length": self.config.max_length,
                    "num_labels": self.config.num_labels,
                    "saved_at": datetime.utcnow().isoformat(),
                },
                f,
                indent=2,
            )

        logger.info(f"Model saved to {model_path}")

    def _save_checkpoint(self, name: str):
        """Save a checkpoint."""
        checkpoint_path = self.config.checkpoint_dir / f"{name}.pt"
        torch.save(self.model.state_dict(), checkpoint_path)
        logger.info(f"Checkpoint saved: {checkpoint_path}")

    def load_best_model(self):
        """Load the best checkpoint."""
        best_path = self.config.checkpoint_dir / "best.pt"
        if best_path.exists():
            if not self.model:
                self.initialize_model()
            state_dict = torch.load(best_path, map_location=self.device)
            self.model.load_state_dict(state_dict)
            logger.info("Loaded best checkpoint")

    def get_model_info(self) -> dict:
        """Get information about the current model."""
        info = {
            "model_name": self.config.model_name,
            "device": self.device,
            "output_dir": str(self.config.output_dir),
        }

        model_path = self.config.output_dir / "model.pt"
        if model_path.exists():
            info["model_exists"] = True
            info["model_size_mb"] = model_path.stat().st_size / (1024 * 1024)

            config_path = self.config.output_dir / "config.json"
            if config_path.exists():
                with open(config_path) as f:
                    info["config"] = json.load(f)
        else:
            info["model_exists"] = False

        if self.training_history:
            latest = self.training_history[-1]
            info["latest_training"] = {
                "epoch": latest.epoch,
                "train_loss": latest.train_loss,
                "val_loss": latest.val_loss,
                "f1_score": latest.f1_score,
                "timestamp": latest.timestamp,
            }

        return info


class IncrementalTrainer:
    """
    Wrapper for incremental model training.

    Monitors for new data and automatically triggers retraining.
    """

    def __init__(
        self,
        data_fetcher: Any,
        trainer: ModelTrainer | None = None,
    ):

        self.data_fetcher = data_fetcher
        self.trainer = trainer or ModelTrainer()

        self.last_training_time: datetime | None = None
        self._load_state()

    def _load_state(self):
        """Load trainer state."""
        state_path = self.trainer.config.output_dir / "incremental_state.json"
        if state_path.exists():
            with open(state_path) as f:
                state = json.load(f)
                if state.get("last_training_time"):
                    self.last_training_time = datetime.fromisoformat(state["last_training_time"])

    def _save_state(self):
        """Save trainer state."""
        state_path = self.trainer.config.output_dir / "incremental_state.json"
        with open(state_path, "w") as f:
            json.dump(
                {
                    "last_training_time": (
                        self.last_training_time.isoformat() if self.last_training_time else None
                    ),
                },
                f,
            )

    def check_and_train(self) -> dict:
        """
        Check for new data and train if needed.

        Returns:
            Training results or status
        """
        # Fetch new vulnerabilities
        logger.info("Checking for new vulnerabilities...")
        new_vulns = self.data_fetcher.fetch_all(since=self.last_training_time)

        if not new_vulns:
            logger.info("No new vulnerabilities found")
            return {"status": "no_new_data"}

        logger.info(f"Found {len(new_vulns)} new vulnerabilities")

        # Get training data
        train_data = self.data_fetcher.get_training_data(
            languages=["python", "javascript"],  # Focus on common languages
        )

        # Split into train/val
        from random import shuffle

        shuffle(train_data)
        split_idx = int(len(train_data) * (1 - self.trainer.config.eval_split))
        train_split = train_data[:split_idx]
        val_split = train_data[split_idx:]

        # Train
        results = self.trainer.train(
            train_data=train_split,
            val_data=val_split,
            incremental=self.last_training_time is not None,
        )

        if results.get("status") == "completed":
            self.last_training_time = datetime.utcnow()
            self._save_state()

        return results

    def full_retrain(self) -> dict:
        """Force a full retraining from all data."""
        logger.info("Starting full retraining...")

        # Get all training data
        train_data = self.data_fetcher.get_training_data()

        if not train_data:
            logger.warning("No training data available")
            return {"status": "no_data"}

        # Split
        from random import shuffle

        shuffle(train_data)
        split_idx = int(len(train_data) * (1 - self.trainer.config.eval_split))
        train_split = train_data[:split_idx]
        val_split = train_data[split_idx:]

        # Train (full, not incremental)
        results = self.trainer.train(
            train_data=train_split,
            val_data=val_split,
            incremental=False,
        )

        if results.get("status") == "completed":
            self.last_training_time = datetime.utcnow()
            self._save_state()

        return results
