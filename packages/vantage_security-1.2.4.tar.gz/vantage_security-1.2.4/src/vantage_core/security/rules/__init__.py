"""
Custom Rule Engine for Vantage Security Scanner.

This module provides a Semgrep-like rule engine for defining and executing
custom security rules using YAML-based pattern definitions.

Key Components:
- schema: Pydantic models for rule YAML schema
- loader: Rule loading and validation from YAML files
- matcher: Pattern matching DSL engine
- executor: Rule execution against source code

Example Usage:
    from vantage_core.security.rules import RuleLoader, RuleExecutor, RuleRegistry

    # Load rules from directory
    loader = RuleLoader()
    rules = loader.load_rules([Path("rules/")])

    # Register rules
    registry = RuleRegistry()
    for rule in rules:
        registry.register(rule)

    # Execute rules against code
    executor = RuleExecutor()
    for rule in registry.get_rules_for_language("python"):
        findings = executor.execute(rule, code_ast, file_path)
"""

from vantage_core.security.rules.executor import RuleExecutor, RuleMatch
from vantage_core.security.rules.loader import RuleLoader
from vantage_core.security.rules.matcher import PatternMatch, PatternMatcher
from vantage_core.security.rules.registry import RuleRegistry
from vantage_core.security.rules.schema import (
    MetavariableFilter,
    Pattern,
    PatternEither,
    PatternInside,
    PatternNot,
    PatternNotInside,
    PatternOperator,
    PatternRegex,
    Patterns,
    Rule,
    RuleFile,
    Severity,
    TaintMode,
    TaintSanitizerDef,
    TaintSinkDef,
    TaintSourceDef,
)

__all__ = [
    # Schema types
    "Rule",
    "RuleFile",
    "Severity",
    "PatternOperator",
    "Pattern",
    "PatternRegex",
    "PatternInside",
    "PatternNot",
    "PatternNotInside",
    "Patterns",
    "PatternEither",
    "MetavariableFilter",
    "TaintSourceDef",
    "TaintSinkDef",
    "TaintSanitizerDef",
    "TaintMode",
    # Loader and registry
    "RuleLoader",
    "RuleRegistry",
    # Matching and execution
    "PatternMatcher",
    "PatternMatch",
    "RuleExecutor",
    "RuleMatch",
]
