"""
Core secret verification interfaces and base classes.

This module provides the foundation for verifying secrets against provider APIs,
eliminating false positives by confirming whether credentials are actually valid.
"""

import asyncio
import hashlib
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class VerificationStatus(Enum):
    """Status of secret verification."""

    VERIFIED = "verified"  # Confirmed valid and active
    INVALID = "invalid"  # Confirmed invalid/expired
    UNKNOWN = "unknown"  # Could not determine (network error, rate limit)
    UNSUPPORTED = "unsupported"  # No verification method available
    SKIPPED = "skipped"  # Verification intentionally skipped


@dataclass
class VerificationResult:
    """Result of verifying a secret."""

    status: VerificationStatus
    provider: str
    secret_type: str
    secret_hash: str  # SHA-256 hash, never store actual secret
    verified_at: float  # Unix timestamp
    latency_ms: float  # Time taken for verification
    metadata: dict[str, Any] = field(default_factory=dict)
    error: str | None = None

    # Additional context for verified secrets
    account_info: dict[str, Any] | None = None  # e.g., AWS account ID
    permissions: list[str] | None = None  # Scopes/permissions
    expiration: float | None = None  # When secret expires

    @property
    def is_active(self) -> bool:
        """Check if secret is confirmed active."""
        return self.status == VerificationStatus.VERIFIED

    @property
    def confidence(self) -> float:
        """Return confidence score for the verification result."""
        confidence_map = {
            VerificationStatus.VERIFIED: 1.0,
            VerificationStatus.INVALID: 1.0,
            VerificationStatus.UNKNOWN: 0.3,
            VerificationStatus.UNSUPPORTED: 0.5,
            VerificationStatus.SKIPPED: 0.0,
        }
        return confidence_map.get(self.status, 0.0)

    def to_audit_log(self) -> dict:
        """Generate audit log entry (never includes actual secret)."""
        return {
            "event_type": "secret_verification",
            "status": self.status.value,
            "provider": self.provider,
            "secret_type": self.secret_type,
            "secret_hash": self.secret_hash,
            "timestamp": self.verified_at,
            "latency_ms": self.latency_ms,
            "error": self.error,
        }


class CircuitBreaker:
    """
    Circuit breaker pattern for handling provider API failures.

    States:
    - CLOSED: Normal operation, requests pass through
    - OPEN: Too many failures, requests are rejected
    - HALF_OPEN: Testing if service recovered
    """

    def __init__(
        self,
        failure_threshold: int = 5,
        reset_timeout: float = 60.0,
        half_open_max_calls: int = 3,
    ):
        self.failure_threshold = failure_threshold
        self.reset_timeout = reset_timeout
        self.half_open_max_calls = half_open_max_calls

        self._failures = 0
        self._last_failure_time = 0.0
        self._state = "closed"
        self._half_open_calls = 0
        self._lock = asyncio.Lock()

    async def can_execute(self) -> bool:
        """Check if request should be allowed through."""
        async with self._lock:
            if self._state == "closed":
                return True

            if self._state == "open":
                # Check if reset timeout has passed
                if time.time() - self._last_failure_time >= self.reset_timeout:
                    self._state = "half_open"
                    self._half_open_calls = 0
                    return True
                return False

            if self._state == "half_open":
                if self._half_open_calls < self.half_open_max_calls:
                    self._half_open_calls += 1
                    return True
                return False

            return False

    async def record_success(self):
        """Record a successful call."""
        async with self._lock:
            if self._state == "half_open":
                self._state = "closed"
            self._failures = 0

    async def record_failure(self):
        """Record a failed call."""
        async with self._lock:
            self._failures += 1
            self._last_failure_time = time.time()

            if self._failures >= self.failure_threshold:
                self._state = "open"
                logger.warning(f"Circuit breaker opened after {self._failures} failures")

    @property
    def state(self) -> str:
        """Get current circuit breaker state."""
        return self._state


class RateLimiter:
    """Token bucket rate limiter for provider APIs."""

    def __init__(self, rate: float, burst: int):
        """
        Initialize rate limiter.

        Args:
            rate: Requests per second
            burst: Maximum burst size
        """
        self.rate = rate
        self.burst = burst
        self._tokens = float(burst)
        self._last_update = time.time()
        self._lock = asyncio.Lock()

    async def acquire(self) -> bool:
        """Acquire a token, waiting if necessary."""
        async with self._lock:
            now = time.time()
            elapsed = now - self._last_update
            self._tokens = min(self.burst, self._tokens + elapsed * self.rate)
            self._last_update = now

            if self._tokens >= 1:
                self._tokens -= 1
                return True

            # Calculate wait time
            wait_time = (1 - self._tokens) / self.rate
            await asyncio.sleep(wait_time)
            self._tokens = 0
            return True


class ProviderVerifier(ABC):
    """
    Abstract base class for provider-specific secret verification.

    Each provider (AWS, GitHub, etc.) implements this interface with
    their specific verification logic.
    """

    def __init__(
        self,
        rate_limit: float = 10.0,
        rate_burst: int = 20,
        timeout: float = 30.0,
    ):
        """
        Initialize provider verifier.

        Args:
            rate_limit: Requests per second
            rate_burst: Maximum burst size
            timeout: Request timeout in seconds
        """
        self.rate_limiter = RateLimiter(rate_limit, rate_burst)
        self.circuit_breaker = CircuitBreaker()
        self.timeout = timeout

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Return the provider name (e.g., 'aws', 'github')."""
        pass

    @property
    @abstractmethod
    def supported_patterns(self) -> list[str]:
        """Return regex patterns for secrets this verifier handles."""
        pass

    @abstractmethod
    async def verify(self, secret: str) -> VerificationResult:
        """
        Verify a secret against the provider API.

        Args:
            secret: The secret value to verify

        Returns:
            VerificationResult with verification status
        """
        pass

    def hash_secret(self, secret: str) -> str:
        """Generate SHA-256 hash of secret for logging."""
        return hashlib.sha256(secret.encode()).hexdigest()

    async def safe_verify(self, secret: str) -> VerificationResult:
        """
        Verify with circuit breaker and rate limiting.

        This wraps the verify() method with resilience patterns.
        """
        secret_hash = self.hash_secret(secret)
        start_time = time.time()

        # Check circuit breaker
        if not await self.circuit_breaker.can_execute():
            return VerificationResult(
                status=VerificationStatus.UNKNOWN,
                provider=self.provider_name,
                secret_type=self._detect_secret_type(secret),
                secret_hash=secret_hash,
                verified_at=time.time(),
                latency_ms=0,
                error="Circuit breaker open",
            )

        # Apply rate limiting
        await self.rate_limiter.acquire()

        try:
            result = await asyncio.wait_for(self.verify(secret), timeout=self.timeout)
            await self.circuit_breaker.record_success()
            return result

        except asyncio.TimeoutError:
            await self.circuit_breaker.record_failure()
            latency_ms = (time.time() - start_time) * 1000
            return VerificationResult(
                status=VerificationStatus.UNKNOWN,
                provider=self.provider_name,
                secret_type=self._detect_secret_type(secret),
                secret_hash=secret_hash,
                verified_at=time.time(),
                latency_ms=latency_ms,
                error=f"Timeout after {self.timeout}s",
            )

        except Exception as e:
            await self.circuit_breaker.record_failure()
            latency_ms = (time.time() - start_time) * 1000
            logger.error(f"Verification error for {self.provider_name}: {e}")
            return VerificationResult(
                status=VerificationStatus.UNKNOWN,
                provider=self.provider_name,
                secret_type=self._detect_secret_type(secret),
                secret_hash=secret_hash,
                verified_at=time.time(),
                latency_ms=latency_ms,
                error=str(e),
            )

    def _detect_secret_type(self, secret: str) -> str:
        """Detect secret type based on format."""
        return "unknown"


class SecretVerifier:
    """
    Main entry point for secret verification.

    Routes secrets to appropriate provider verifiers based on patterns.
    """

    def __init__(self):
        self._verifiers: dict[str, ProviderVerifier] = {}
        self._pattern_cache: dict[str, str] = {}  # pattern -> provider

    def register_verifier(self, verifier: ProviderVerifier):
        """Register a provider verifier."""
        self._verifiers[verifier.provider_name] = verifier

        # Cache patterns for fast lookup
        for pattern in verifier.supported_patterns:
            self._pattern_cache[pattern] = verifier.provider_name

    def get_verifier(self, secret: str) -> ProviderVerifier | None:
        """Get appropriate verifier for a secret."""
        import re

        for pattern, provider_name in self._pattern_cache.items():
            if re.match(pattern, secret):
                return self._verifiers.get(provider_name)

        return None

    async def verify(self, secret: str) -> VerificationResult:
        """
        Verify a secret using the appropriate provider.

        Args:
            secret: The secret value to verify

        Returns:
            VerificationResult
        """
        verifier = self.get_verifier(secret)

        if verifier is None:
            return VerificationResult(
                status=VerificationStatus.UNSUPPORTED,
                provider="unknown",
                secret_type="unknown",
                secret_hash=hashlib.sha256(secret.encode()).hexdigest(),
                verified_at=time.time(),
                latency_ms=0,
                error="No verifier available for this secret type",
            )

        return await verifier.safe_verify(secret)

    async def verify_batch(
        self,
        secrets: list[str],
        max_concurrent: int = 10,
    ) -> list[VerificationResult]:
        """
        Verify multiple secrets concurrently.

        Args:
            secrets: List of secrets to verify
            max_concurrent: Maximum concurrent verifications

        Returns:
            List of VerificationResults in same order as input
        """
        semaphore = asyncio.Semaphore(max_concurrent)

        async def verify_with_semaphore(secret: str) -> VerificationResult:
            async with semaphore:
                return await self.verify(secret)

        tasks = [verify_with_semaphore(s) for s in secrets]
        return await asyncio.gather(*tasks)
