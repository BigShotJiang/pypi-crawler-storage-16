"""Validation metrics for Vantage analysis components.

Provides precision, recall, F1, calibration metrics (ECE),
and regression metrics for validating analysis accuracy.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import numpy as np

if TYPE_CHECKING:
    from vantage_core.analysis.failure_taxonomy import SemanticFailureRisk
    from vantage_core.scanners.base import DetectedConnection
    from vantage_core.validation.ground_truth import GroundTruthDataset

logger = logging.getLogger(__name__)

# Try to import scipy for correlation calculations
try:
    from scipy import stats

    SCIPY_AVAILABLE = True
except ImportError:
    SCIPY_AVAILABLE = False


@dataclass
class ClassificationMetrics:
    """Metrics for classification tasks."""

    precision: float
    recall: float
    f1: float
    accuracy: float
    support: int
    confusion_matrix: np.ndarray
    per_class_metrics: dict[str, dict] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "precision": self.precision,
            "recall": self.recall,
            "f1": self.f1,
            "accuracy": self.accuracy,
            "support": self.support,
            "confusion_matrix": self.confusion_matrix.tolist(),
            "per_class_metrics": self.per_class_metrics,
        }


@dataclass
class RegressionMetrics:
    """Metrics for regression tasks (scores)."""

    mae: float  # Mean absolute error
    rmse: float  # Root mean squared error
    correlation: float  # Pearson correlation
    spearman: float  # Spearman rank correlation

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "mae": self.mae,
            "rmse": self.rmse,
            "correlation": self.correlation,
            "spearman": self.spearman,
        }


@dataclass
class CalibrationMetrics:
    """Calibration metrics for confidence."""

    ece: float  # Expected calibration error
    mce: float  # Maximum calibration error
    reliability_diagram: dict  # Bins for plotting

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "ece": self.ece,
            "mce": self.mce,
            "reliability_diagram": self.reliability_diagram,
        }


class ValidationMetrics:
    """Compute validation metrics for all components."""

    def __init__(self, ground_truth: GroundTruthDataset):
        """Initialize with ground truth dataset.

        Args:
            ground_truth: Dataset with expert annotations
        """
        self.ground_truth = ground_truth

    def evaluate_failure_detection(
        self, predictions: list[SemanticFailureRisk], agent_id: str | None = None
    ) -> ClassificationMetrics:
        """Evaluate failure mode detection.

        Args:
            predictions: List of detected failure risks
            agent_id: Optional specific agent to evaluate

        Returns:
            ClassificationMetrics with precision, recall, F1
        """
        # Build prediction set
        pred_set: set[tuple[str, str]] = set()  # (agent_id, failure_code)
        for risk in predictions:
            for aid in risk.agents_at_risk:
                if agent_id is None or aid == agent_id:
                    pred_set.add((aid, risk.failure_mode.code))

        # Build ground truth set
        gt_set: set[tuple[str, str]] = set()
        for failure in self.ground_truth.failures:
            if failure.is_present:
                if agent_id is None or failure.agent_id == agent_id:
                    gt_set.add((failure.agent_id, failure.failure_code))

        # Calculate metrics
        true_positives = len(pred_set & gt_set)
        false_positives = len(pred_set - gt_set)
        false_negatives = len(gt_set - pred_set)

        precision = (
            true_positives / (true_positives + false_positives)
            if (true_positives + false_positives) > 0
            else 0
        )
        recall = (
            true_positives / (true_positives + false_negatives)
            if (true_positives + false_negatives) > 0
            else 0
        )
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

        total = true_positives + false_positives + false_negatives
        accuracy = true_positives / total if total > 0 else 0

        # Build confusion matrix [TN, FP], [FN, TP]
        # Note: We don't have true negatives without complete enumeration
        confusion = np.array([[0, false_positives], [false_negatives, true_positives]])

        # Per-class metrics (by failure code)
        per_class: dict[str, dict] = {}
        failure_codes = set(f.failure_code for f in self.ground_truth.failures)
        for code in failure_codes:
            code_pred = {(aid, fc) for aid, fc in pred_set if fc == code}
            code_gt = {(aid, fc) for aid, fc in gt_set if fc == code}

            tp = len(code_pred & code_gt)
            fp = len(code_pred - code_gt)
            fn = len(code_gt - code_pred)

            p = tp / (tp + fp) if (tp + fp) > 0 else 0
            r = tp / (tp + fn) if (tp + fn) > 0 else 0
            f = 2 * p * r / (p + r) if (p + r) > 0 else 0

            per_class[code] = {
                "precision": p,
                "recall": r,
                "f1": f,
                "support": len(code_gt),
            }

        return ClassificationMetrics(
            precision=precision,
            recall=recall,
            f1=f1,
            accuracy=accuracy,
            support=len(gt_set),
            confusion_matrix=confusion,
            per_class_metrics=per_class,
        )

    def evaluate_connection_detection(
        self, predictions: list[DetectedConnection]
    ) -> ClassificationMetrics:
        """Evaluate connection detection.

        Args:
            predictions: List of detected connections

        Returns:
            ClassificationMetrics with precision, recall, F1
        """
        # Build prediction set
        pred_set: set[tuple[str, str]] = set()
        for conn in predictions:
            pred_set.add((conn.source, conn.target))

        # Build ground truth set
        gt_set: set[tuple[str, str]] = set()
        for conn in self.ground_truth.connections:
            if conn.exists:
                gt_set.add((conn.source, conn.target))

        # Calculate metrics
        true_positives = len(pred_set & gt_set)
        false_positives = len(pred_set - gt_set)
        false_negatives = len(gt_set - pred_set)

        precision = (
            true_positives / (true_positives + false_positives)
            if (true_positives + false_positives) > 0
            else 0
        )
        recall = (
            true_positives / (true_positives + false_negatives)
            if (true_positives + false_negatives) > 0
            else 0
        )
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

        total = true_positives + false_positives + false_negatives
        accuracy = true_positives / total if total > 0 else 0

        confusion = np.array([[0, false_positives], [false_negatives, true_positives]])

        return ClassificationMetrics(
            precision=precision,
            recall=recall,
            f1=f1,
            accuracy=accuracy,
            support=len(gt_set),
            confusion_matrix=confusion,
            per_class_metrics={},
        )

    def evaluate_alignment_scoring(
        self,
        predictions: list[tuple[str, float]],  # (system_id, predicted_score)
    ) -> tuple[RegressionMetrics, CalibrationMetrics]:
        """Evaluate alignment scoring.

        Args:
            predictions: List of (system_id, predicted_score) tuples

        Returns:
            Tuple of (RegressionMetrics, CalibrationMetrics)
        """
        # Match predictions to ground truth
        pred_scores = []
        gt_scores = []

        pred_dict = {sys_id: score for sys_id, score in predictions}

        for alignment in self.ground_truth.alignments:
            if alignment.system_id in pred_dict:
                pred_scores.append(pred_dict[alignment.system_id])
                gt_scores.append(alignment.overall_score)

        if not pred_scores:
            return (
                RegressionMetrics(mae=0, rmse=0, correlation=0, spearman=0),
                CalibrationMetrics(ece=0, mce=0, reliability_diagram={}),
            )

        pred_arr = np.array(pred_scores)
        gt_arr = np.array(gt_scores)

        # Regression metrics
        mae = float(np.mean(np.abs(pred_arr - gt_arr)))
        rmse = float(np.sqrt(np.mean((pred_arr - gt_arr) ** 2)))

        # Correlation
        if len(pred_arr) > 1:
            correlation = float(np.corrcoef(pred_arr, gt_arr)[0, 1])
            if SCIPY_AVAILABLE:
                spearman = float(stats.spearmanr(pred_arr, gt_arr).correlation)
            else:
                spearman = correlation  # Fallback
        else:
            correlation = 0
            spearman = 0

        regression = RegressionMetrics(
            mae=mae,
            rmse=rmse,
            correlation=correlation,
            spearman=spearman,
        )

        # For calibration, we need confidence scores
        # Using score/100 as confidence proxy
        confidences = pred_arr / 100
        correct = np.abs(pred_arr - gt_arr) < 10  # Within 10 points

        calibration = self.compute_confidence_calibration(
            confidences.tolist(),
            correct.tolist(),
        )

        return regression, calibration

    def compute_confidence_calibration(
        self, confidences: list[float], correct: list[bool], n_bins: int = 10
    ) -> CalibrationMetrics:
        """Compute Expected Calibration Error (ECE).

        ECE = sum(|accuracy(bin) - confidence(bin)| * |bin|) / n

        Args:
            confidences: List of confidence scores (0-1)
            correct: List of whether prediction was correct
            n_bins: Number of bins for calibration

        Returns:
            CalibrationMetrics with ECE, MCE, and reliability diagram
        """
        if not confidences:
            return CalibrationMetrics(
                ece=0,
                mce=0,
                reliability_diagram={
                    "bins": [],
                    "accuracies": [],
                    "confidences": [],
                    "counts": [],
                },
            )

        conf_arr = np.array(confidences)
        correct_arr = np.array(correct, dtype=float)

        # Create bins
        bin_boundaries = np.linspace(0, 1, n_bins + 1)
        bin_indices = np.digitize(conf_arr, bin_boundaries[1:-1])

        # Calculate metrics per bin
        bin_accuracies = []
        bin_confidences = []
        bin_counts = []

        ece = 0.0
        mce = 0.0

        for i in range(n_bins):
            in_bin = bin_indices == i
            bin_count = np.sum(in_bin)

            if bin_count > 0:
                bin_accuracy = np.mean(correct_arr[in_bin])
                bin_confidence = np.mean(conf_arr[in_bin])
                calibration_error = abs(bin_accuracy - bin_confidence)

                ece += calibration_error * bin_count
                mce = max(mce, calibration_error)

                bin_accuracies.append(float(bin_accuracy))
                bin_confidences.append(float(bin_confidence))
                bin_counts.append(int(bin_count))
            else:
                bin_accuracies.append(0)
                bin_confidences.append((bin_boundaries[i] + bin_boundaries[i + 1]) / 2)
                bin_counts.append(0)

        ece = ece / len(confidences)

        reliability_diagram = {
            "bins": [(bin_boundaries[i], bin_boundaries[i + 1]) for i in range(n_bins)],
            "accuracies": bin_accuracies,
            "confidences": bin_confidences,
            "counts": bin_counts,
        }

        return CalibrationMetrics(
            ece=float(ece),
            mce=float(mce),
            reliability_diagram=reliability_diagram,
        )


def calculate_precision(true_positives: int, false_positives: int) -> float:
    """Calculate precision.

    Args:
        true_positives: Number of true positives
        false_positives: Number of false positives

    Returns:
        Precision score (0-1)
    """
    total = true_positives + false_positives
    return true_positives / total if total > 0 else 0


def calculate_recall(true_positives: int, false_negatives: int) -> float:
    """Calculate recall.

    Args:
        true_positives: Number of true positives
        false_negatives: Number of false negatives

    Returns:
        Recall score (0-1)
    """
    total = true_positives + false_negatives
    return true_positives / total if total > 0 else 0


def calculate_f1(precision: float, recall: float) -> float:
    """Calculate F1 score.

    Args:
        precision: Precision score
        recall: Recall score

    Returns:
        F1 score (0-1)
    """
    total = precision + recall
    return 2 * precision * recall / total if total > 0 else 0


def calculate_ece(confidences: list[float], accuracies: list[float], counts: list[int]) -> float:
    """Calculate Expected Calibration Error.

    Args:
        confidences: Per-bin average confidence
        accuracies: Per-bin accuracy
        counts: Number of samples per bin

    Returns:
        ECE score (0-1, lower is better)
    """
    total = sum(counts)
    if total == 0:
        return 0

    ece = 0.0
    for conf, acc, count in zip(confidences, accuracies, counts):
        ece += abs(acc - conf) * count

    return ece / total
