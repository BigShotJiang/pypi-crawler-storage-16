"""
Vantage Web Dashboard.

Provides a web-based interface for:
- Infection simulation visualization
- Prompt injection testing
- Effectiveness data dashboard
- Comparison with competitors
"""

from vantage_core.web.server import create_app, run_server

__all__ = ["create_app", "run_server"]
