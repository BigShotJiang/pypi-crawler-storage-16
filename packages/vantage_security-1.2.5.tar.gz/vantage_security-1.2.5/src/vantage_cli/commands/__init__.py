"""Vantage CLI commands package.

Contains all command group implementations and shared data loaders.
"""

from vantage_cli.commands._loaders import (
    # Data loaders
    load_agent_system,
    load_analyze_commands,
    load_compliance_commands,
    load_dashboard_commands,
    load_health_commands,
    load_license_commands,
    load_ml_commands,
    load_prompt_file,
    load_protect_commands,
    # Command group loaders
    load_scan_commands,
    load_security_commands,
    load_verify_commands,
    load_web_commands,
)

__all__ = [
    # Data loaders
    "load_agent_system",
    "load_prompt_file",
    # Command group loaders
    "load_scan_commands",
    "load_security_commands",
    "load_health_commands",
    "load_verify_commands",
    "load_compliance_commands",
    "load_dashboard_commands",
    "load_license_commands",
    "load_protect_commands",
    "load_ml_commands",
    "load_web_commands",
    "load_analyze_commands",
]
