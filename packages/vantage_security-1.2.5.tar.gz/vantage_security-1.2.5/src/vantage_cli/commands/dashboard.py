"""
Team Dashboard Commands

Commands for viewing security trends, agent scores, and remediation tracking.
"""

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress
from rich.table import Table

console = Console()

dashboard_app = typer.Typer(
    name="dashboard",
    help="Team dashboard for security trends and remediation tracking",
)


@dashboard_app.command("show")
def show_dashboard(
    project: str = typer.Option("", "--project", "-p", help="Filter by project"),
    days: int = typer.Option(30, "--days", "-d", help="Number of days to analyze"),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output HTML file"),
):
    """
    Display the team security dashboard.

    Shows vulnerability trends, agent scores, and remediation status.

    Examples:
        vantage dashboard show
        vantage dashboard show --project my-api --days 60
        vantage dashboard show --output dashboard.html
    """
    from vantage_core.dashboard.visualization import DashboardRenderer

    renderer = DashboardRenderer()

    if output:
        # Generate HTML dashboard
        console.print("[bold blue]Generating HTML dashboard...[/bold blue]")
        html = renderer.render_html_dashboard(project or None, days)
        output.write_text(html)
        console.print(f"[green][OK] Dashboard saved to {output}[/green]")
    else:
        # Display CLI dashboard
        cli_output = renderer.render_cli_dashboard(project or None, days)
        console.print(cli_output)


@dashboard_app.command("trends")
def show_trends(
    project: str = typer.Option("", "--project", "-p", help="Filter by project"),
    days: int = typer.Option(30, "--days", "-d", help="Number of days to analyze"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table, json"),
):
    """
    Show vulnerability trends over time.

    Displays historical data on security scores and findings.

    Examples:
        vantage dashboard trends
        vantage dashboard trends --project api-v2 --days 90
    """
    from vantage_core.dashboard.history import HistoryDatabase

    db = HistoryDatabase()
    trend = db.get_vulnerability_trends(project or None, days)

    if not trend:
        console.print("[yellow]No trend data available[/yellow]")
        return

    if format == "json":
        console.print(json.dumps(trend.to_dict(), indent=2))
        return

    console.print(
        Panel.fit(
            "[bold blue]Vulnerability Trends[/bold blue]",
            border_style="blue",
        )
    )

    console.print(f"\n[bold]Period:[/bold] {trend.period_start[:10]} to {trend.period_end[:10]}")
    console.print(f"[bold]Project:[/bold] {trend.project_name}")
    console.print(f"[bold]Scans:[/bold] {trend.scan_count}")
    console.print(f"[bold]Average Score:[/bold] {trend.avg_score:.1f}/100")
    console.print(f"[bold]Score Range:[/bold] {trend.min_score} - {trend.max_score}")

    improvement_color = "green" if trend.improvement_rate > 0 else "red"
    console.print(
        f"[bold]Improvement:[/bold] [{improvement_color}]{trend.improvement_rate:+.1f}%[/{improvement_color}]"
    )

    # Score trend table
    if trend.score_trend:
        table = Table(title="Score History (Recent)")
        table.add_column("Date", style="cyan")
        table.add_column("Score", justify="center")
        table.add_column("Critical", justify="center", style="red")
        table.add_column("High", justify="center", style="yellow")

        # Show last 10 entries
        for i in range(-min(10, len(trend.timestamps)), 0):
            table.add_row(
                trend.timestamps[i][:10],
                str(trend.score_trend[i]),
                str(trend.critical_trend[i]),
                str(trend.high_trend[i]),
            )

        console.print(table)


@dashboard_app.command("agents")
def show_agents(
    project: str = typer.Option("", "--project", "-p", help="Filter by project"),
    days: int = typer.Option(30, "--days", "-d", help="Number of days to analyze"),
    sort: str = typer.Option("score", "--sort", "-s", help="Sort by: score, improvement, risk"),
):
    """
    Show agent security scores and trends.

    Lists all tracked agents with their current scores and improvement rates.

    Examples:
        vantage dashboard agents
        vantage dashboard agents --project api --sort improvement
    """
    from vantage_core.dashboard.agent_scores import AgentScoreTracker

    tracker = AgentScoreTracker()

    if project:
        scores = tracker.get_project_agent_scores(project, days)
    else:
        # Get all projects and their agents
        all_agents = tracker.get_all_agents()
        scores = []
        for agent in all_agents:
            history = tracker.get_agent_score_history(
                agent["agent_id"], agent["project_name"], days
            )
            if history:
                scores.append(history)

    if not scores:
        console.print("[yellow]No agent data available[/yellow]")
        return

    console.print(
        Panel.fit(
            "[bold blue]Agent Security Scores[/bold blue]",
            border_style="blue",
        )
    )

    # Sort
    if sort == "score":
        scores.sort(key=lambda x: x.current_score)
    elif sort == "improvement":
        scores.sort(key=lambda x: x.improvement_rate, reverse=True)
    elif sort == "risk":
        risk_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        scores.sort(
            key=lambda x: risk_order.get(
                x.risk_level_history[-1] if x.risk_level_history else "low", 4
            )
        )

    table = Table()
    table.add_column("Agent", style="cyan")
    table.add_column("Project", style="blue")
    table.add_column("Framework")
    table.add_column("Score", justify="center")
    table.add_column("Trend", justify="center")
    table.add_column("Risk", justify="center")
    table.add_column("Records")

    for history in scores:
        risk = history.risk_level_history[-1] if history.risk_level_history else "unknown"
        risk_style = {
            "critical": "red bold",
            "high": "red",
            "medium": "yellow",
            "low": "green",
        }.get(risk, "white")

        trend_color = "green" if history.improvement_rate > 0 else "red"
        trend_symbol = (
            "^" if history.improvement_rate > 0 else "v" if history.improvement_rate < 0 else "-"
        )

        table.add_row(
            history.agent_name[:20],
            history.project_name[:15],
            history.framework[:10],
            str(history.current_score),
            f"[{trend_color}]{trend_symbol} {abs(history.improvement_rate):.1f}%[/{trend_color}]",
            f"[{risk_style}]{risk.upper()}[/{risk_style}]",
            str(history.record_count),
        )

    console.print(table)


@dashboard_app.command("remediation")
def show_remediation(
    project: str = typer.Option("", "--project", "-p", help="Filter by project"),
    status: str = typer.Option("", "--status", "-s", help="Filter by status"),
    assignee: str = typer.Option("", "--assignee", "-a", help="Filter by assignee"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table, board, json"),
):
    """
    Show remediation tracking status.

    Lists remediation items with status, assignee, and progress.

    Examples:
        vantage dashboard remediation
        vantage dashboard remediation --status open
        vantage dashboard remediation --format board
    """
    from vantage_core.dashboard.remediation import (
        RemediationStatus,
        RemediationTracker,
    )
    from vantage_core.dashboard.visualization import render_remediation_board

    if format == "board":
        board = render_remediation_board(project or None)
        console.print(board)
        return

    tracker = RemediationTracker()

    # Get items with filters
    status_filter = RemediationStatus(status) if status else None
    items = tracker.get_items(
        project_name=project or None,
        status=status_filter,
        assignee=assignee or None,
        limit=50,
    )

    if format == "json":
        console.print(json.dumps([i.to_dict() for i in items], indent=2))
        return

    # Get summary
    summary = tracker.get_summary(project or None)

    console.print(
        Panel.fit(
            "[bold blue]Remediation Tracking[/bold blue]",
            border_style="blue",
        )
    )

    # Summary stats
    console.print(f"\n[bold]Project:[/bold] {project or 'All'}")
    console.print(f"[bold]Total Items:[/bold] {summary.total_items}")
    console.print(
        f"[bold]Open:[/bold] [red]{summary.open_count}[/red]  |  "
        f"[bold]In Progress:[/bold] [yellow]{summary.in_progress_count}[/yellow]  |  "
        f"[bold]Blocked:[/bold] [red]{summary.blocked_count}[/red]  |  "
        f"[bold]Resolved:[/bold] [green]{summary.resolved_count}[/green]"
    )
    console.print(
        f"[bold]Overdue:[/bold] [red]{summary.overdue_count}[/red]  |  "
        f"[bold]Avg Resolution:[/bold] {summary.avg_resolution_days} days"
    )

    if not items:
        console.print("\n[yellow]No remediation items found[/yellow]")
        return

    # Items table
    table = Table(title="Remediation Items")
    table.add_column("ID", style="dim", width=8)
    table.add_column("Severity", width=8)
    table.add_column("Title", width=35)
    table.add_column("Status", width=12)
    table.add_column("Assignee", width=12)
    table.add_column("Age", justify="center", width=6)

    for item in items[:30]:
        severity_style = {
            "critical": "red bold",
            "high": "red",
            "medium": "yellow",
            "low": "green",
        }.get(item.severity, "white")

        status_style = {
            "open": "red",
            "in_progress": "yellow",
            "blocked": "red bold",
            "resolved": "green",
            "accepted_risk": "blue",
            "false_positive": "dim",
            "wont_fix": "dim",
        }.get(item.status.value, "white")

        overdue = " [!]" if item.is_overdue else ""

        table.add_row(
            item.item_id[:8],
            f"[{severity_style}]{item.severity.upper()}[/{severity_style}]",
            item.title[:35],
            f"[{status_style}]{item.status.value}[/{status_style}]{overdue}",
            item.assignee[:12] if item.assignee else "[dim]Unassigned[/dim]",
            f"{item.days_open}d",
        )

    console.print(table)


@dashboard_app.command("remediation-update")
def update_remediation(
    item_id: str = typer.Argument(..., help="Remediation item ID"),
    status: str = typer.Option("", "--status", "-s", help="New status"),
    assignee: str = typer.Option("", "--assignee", "-a", help="Assign to user"),
    due_date: str = typer.Option("", "--due", help="Due date (YYYY-MM-DD)"),
    comment: str = typer.Option("", "--comment", "-c", help="Add a comment"),
    user: str = typer.Option("", "--user", "-u", help="Your username"),
):
    """
    Update a remediation item.

    Change status, assignee, or add comments to track progress.

    Examples:
        vantage dashboard remediation-update abc123 --status in_progress
        vantage dashboard remediation-update abc123 --assignee john --due 2024-02-01
        vantage dashboard remediation-update abc123 --comment "Fixed in PR #123" --status resolved
    """
    from vantage_core.dashboard.remediation import (
        RemediationStatus,
        RemediationTracker,
    )

    tracker = RemediationTracker()

    # Find item (support partial ID)
    items = tracker.get_items(limit=1000)
    item = None
    for i in items:
        if i.item_id.startswith(item_id):
            item = i
            break

    if not item:
        console.print(f"[red]Item not found: {item_id}[/red]")
        raise typer.Exit(1)

    # Update status
    if status:
        try:
            new_status = RemediationStatus(status)
            tracker.update_status(item.item_id, new_status, user, comment)
            console.print(f"[green][OK] Status updated to {status}[/green]")
        except ValueError:
            valid = ", ".join(s.value for s in RemediationStatus)
            console.print(f"[red]Invalid status. Valid options: {valid}[/red]")
            raise typer.Exit(1)

    # Update assignee
    if assignee or due_date:
        tracker.assign_item(item.item_id, assignee or item.assignee, due_date or item.due_date)
        if assignee:
            console.print(f"[green][OK] Assigned to {assignee}[/green]")
        if due_date:
            console.print(f"[green][OK] Due date set to {due_date}[/green]")

    # Add comment
    if comment and not status:  # Comment already added with status update
        tracker.add_comment(item.item_id, comment, user)
        console.print("[green][OK] Comment added[/green]")


@dashboard_app.command("record")
def record_scan(
    scan_file: Path = typer.Argument(..., help="Path to scan results JSON"),
    project: str = typer.Option("", "--project", "-p", help="Project name"),
    branch: str = typer.Option("", "--branch", "-b", help="Git branch"),
    commit: str = typer.Option("", "--commit", "-c", help="Git commit hash"),
    create_remediations: bool = typer.Option(
        False, "--remediate", "-r", help="Create remediation items"
    ),
):
    """
    Record scan results to history database.

    Stores scan data for trend analysis and optionally creates remediation items.

    Examples:
        vantage dashboard record scan_results.json --project my-api
        vantage dashboard record scan.json --project api --branch main --remediate
    """
    from vantage_core.dashboard.agent_scores import AgentScoreTracker
    from vantage_core.dashboard.history import record_scan as record_scan_fn
    from vantage_core.dashboard.remediation import RemediationTracker

    if not scan_file.exists():
        console.print(f"[red]File not found: {scan_file}[/red]")
        raise typer.Exit(1)

    with open(scan_file) as f:
        scan_results = json.load(f)

    project_name = project or scan_results.get("project_name", scan_file.stem)

    with Progress() as progress:
        task = progress.add_task("Recording scan...", total=3)

        # Record scan history
        record = record_scan_fn(
            scan_results,
            project_name=project_name,
            branch=branch,
            commit_hash=commit,
        )
        progress.advance(task)

        # Record agent scores
        tracker = AgentScoreTracker()
        agent_records = tracker.record_agents_from_scan(scan_results, record.scan_id, project_name)
        progress.advance(task)

        # Create remediation items
        remediation_items = []
        if create_remediations:
            rem_tracker = RemediationTracker()
            remediation_items = rem_tracker.create_items_from_scan(
                scan_results, project_name, record.scan_id
            )
        progress.advance(task)

    console.print("\n[green][OK] Scan recorded[/green]")
    console.print(f"  Scan ID: {record.scan_id}")
    console.print(f"  Project: {project_name}")
    console.print(f"  Score: {record.atss_score}/100 (Grade: {record.atss_grade})")
    console.print(f"  Findings: {record.total_findings}")
    console.print(f"  Agents recorded: {len(agent_records)}")

    if create_remediations:
        console.print(f"  Remediation items created: {len(remediation_items)}")


@dashboard_app.command("history")
def show_history(
    project: str = typer.Option("", "--project", "-p", help="Filter by project"),
    days: int = typer.Option(30, "--days", "-d", help="Number of days"),
    limit: int = typer.Option(20, "--limit", "-l", help="Maximum records"),
):
    """
    Show scan history.

    Lists recent scans with scores and findings.

    Examples:
        vantage dashboard history
        vantage dashboard history --project api --days 60
    """
    from vantage_core.dashboard.history import HistoryDatabase

    db = HistoryDatabase()
    records = db.get_scan_history(project or None, days, limit)

    if not records:
        console.print("[yellow]No scan history found[/yellow]")
        return

    console.print(
        Panel.fit(
            "[bold blue]Scan History[/bold blue]",
            border_style="blue",
        )
    )

    table = Table()
    table.add_column("Date", style="cyan")
    table.add_column("Project")
    table.add_column("Grade", justify="center")
    table.add_column("Score", justify="center")
    table.add_column("Findings", justify="center")
    table.add_column("Critical", justify="center", style="red")
    table.add_column("High", justify="center", style="yellow")
    table.add_column("Agents", justify="center")

    for record in records:
        grade_style = {
            "A": "green bold",
            "B": "green",
            "C": "yellow",
            "D": "red",
            "F": "red bold",
        }.get(record.atss_grade, "white")

        table.add_row(
            record.timestamp[:16],
            record.project_name[:15],
            f"[{grade_style}]{record.atss_grade}[/{grade_style}]",
            str(record.atss_score),
            str(record.total_findings),
            str(record.critical_count),
            str(record.high_count),
            str(record.agents_detected),
        )

    console.print(table)


@dashboard_app.command("stats")
def show_stats(
    project: str = typer.Option("", "--project", "-p", help="Filter by project"),
):
    """
    Show overall statistics.

    Displays aggregate statistics across all scans.

    Examples:
        vantage dashboard stats
        vantage dashboard stats --project api
    """
    from vantage_core.dashboard.history import HistoryDatabase
    from vantage_core.dashboard.remediation import RemediationTracker

    db = HistoryDatabase()
    stats = db.get_statistics(project or None)

    rem_tracker = RemediationTracker()
    rem_summary = rem_tracker.get_summary(project or None)

    console.print(
        Panel.fit(
            "[bold blue]Security Statistics[/bold blue]",
            border_style="blue",
        )
    )

    console.print(f"\n[bold]Project:[/bold] {project or 'All'}")
    console.print("")

    # Scan stats
    console.print("[bold cyan]Scan Statistics[/bold cyan]")
    console.print(f"  Total Scans:        {stats['total_scans']}")
    console.print(f"  Average Score:      {stats['avg_score']}/100")
    console.print(f"  Score Range:        {stats['min_score']} - {stats['max_score']}")
    console.print(f"  Total Findings:     {stats['total_findings']}")
    console.print(f"  Total Critical:     {stats['total_critical']}")
    console.print(f"  Total High:         {stats['total_high']}")
    console.print(f"  Avg Agents/Scan:    {stats['avg_agents']}")
    if stats["first_scan"]:
        console.print(f"  First Scan:         {stats['first_scan'][:10]}")
        console.print(f"  Last Scan:          {stats['last_scan'][:10]}")
    console.print("")

    # Remediation stats
    console.print("[bold cyan]Remediation Statistics[/bold cyan]")
    console.print(f"  Total Items:        {rem_summary.total_items}")
    console.print(f"  Open:               {rem_summary.open_count}")
    console.print(f"  Resolved:           {rem_summary.resolved_count}")
    console.print(f"  Overdue:            {rem_summary.overdue_count}")
    console.print(f"  Avg Resolution:     {rem_summary.avg_resolution_days} days")
    console.print("")
    console.print("  Mean Time to Remediate:")
    console.print(f"    Critical:         {rem_summary.mttr_critical} days")
    console.print(f"    High:             {rem_summary.mttr_high} days")
    console.print(f"    Medium:           {rem_summary.mttr_medium} days")
    console.print(f"    Low:              {rem_summary.mttr_low} days")


@dashboard_app.command("projects")
def list_projects():
    """
    List all tracked projects.

    Shows projects with scan history in the database.

    Examples:
        vantage dashboard projects
    """
    from vantage_core.dashboard.history import HistoryDatabase

    db = HistoryDatabase()
    projects = db.get_projects()

    if not projects:
        console.print("[yellow]No projects found[/yellow]")
        return

    console.print(
        Panel.fit(
            "[bold blue]Tracked Projects[/bold blue]",
            border_style="blue",
        )
    )

    table = Table()
    table.add_column("Project", style="cyan")
    table.add_column("Scans", justify="center")
    table.add_column("Avg Score", justify="center")
    table.add_column("Last Scan")

    for project in projects:
        stats = db.get_statistics(project)
        table.add_row(
            project,
            str(stats["total_scans"]),
            str(stats["avg_score"]),
            stats["last_scan"][:10] if stats["last_scan"] else "-",
        )

    console.print(table)
