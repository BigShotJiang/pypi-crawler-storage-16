"""Analysis tools for multi-agent system prompt optimization."""

from vantage_core.analysis.alignment import AlignmentScorer

# Production analyzers with embeddings and LLM-as-Judge
from vantage_core.analysis.collision import CollisionDetector
from vantage_core.analysis.cost_estimator import (
    AgentCostEstimate,
    CostEstimator,
    SystemCostEstimate,
)
from vantage_core.analysis.dependency import DependencyMapper

# Killer features based on research
from vantage_core.analysis.failure_taxonomy import (
    CascadeRiskReport,
    FailureMode,
    FailureRisk,
    MASTFailureDetector,
)

__all__ = [
    "DependencyMapper",
    "CollisionDetector",
    "AlignmentScorer",
    # Killer features
    "MASTFailureDetector",
    "FailureMode",
    "FailureRisk",
    "CascadeRiskReport",
    "CostEstimator",
    "SystemCostEstimate",
    "AgentCostEstimate",
]
