class ProjectSymbolTable:
    """Dummy Symbol Table for OSS Release."""
    def __init__(self, root_path=None):
        pass
    
    def resolve_symbol(self, file_path, name):
        return None

