"""Benchmark results with statistical analysis.

Provides data structures for benchmark results, comparisons,
and statistical significance testing.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np


@dataclass
class MetricResult:
    """Result for a single metric."""

    name: str
    value: float
    std: float = 0.0
    ci_lower: float = 0.0
    ci_upper: float = 0.0
    n_samples: int = 0


@dataclass
class DifficultyBreakdown:
    """Results broken down by difficulty level."""

    easy: dict[str, MetricResult] = field(default_factory=dict)
    medium: dict[str, MetricResult] = field(default_factory=dict)
    hard: dict[str, MetricResult] = field(default_factory=dict)


@dataclass
class BenchmarkResults:
    """Complete benchmark results with statistics.

    Contains metrics for MAST detection, connection detection,
    and alignment scoring across the ground truth dataset.
    """

    # Metadata
    timestamp: str = ""
    analyzer_name: str = ""
    ground_truth_path: str = ""
    total_systems: int = 0

    # Overall metrics
    mast_precision: float = 0.0
    mast_recall: float = 0.0
    mast_f1: float = 0.0

    connection_precision: float = 0.0
    connection_recall: float = 0.0
    connection_f1: float = 0.0

    alignment_mae: float = 0.0
    alignment_correlation: float = 0.0

    # Per-system scores for statistical analysis
    system_scores: list[dict[str, Any]] = field(default_factory=list)

    # Breakdown by difficulty
    by_difficulty: DifficultyBreakdown = field(default_factory=DifficultyBreakdown)

    # Breakdown by framework
    by_framework: dict[str, dict[str, float]] = field(default_factory=dict)

    # Runtime info
    runtime_seconds: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "timestamp": self.timestamp,
            "analyzer_name": self.analyzer_name,
            "ground_truth_path": self.ground_truth_path,
            "total_systems": self.total_systems,
            "overall_metrics": {
                "mast": {
                    "precision": self.mast_precision,
                    "recall": self.mast_recall,
                    "f1": self.mast_f1,
                },
                "connection": {
                    "precision": self.connection_precision,
                    "recall": self.connection_recall,
                    "f1": self.connection_f1,
                },
                "alignment": {
                    "mae": self.alignment_mae,
                    "correlation": self.alignment_correlation,
                },
            },
            "system_scores": self.system_scores,
            "by_framework": self.by_framework,
            "runtime_seconds": self.runtime_seconds,
        }

    def save(self, path: Path) -> None:
        """Save results to JSON file."""
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load(cls, path: Path) -> BenchmarkResults:
        """Load results from JSON file."""
        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        results = cls(
            timestamp=data.get("timestamp", ""),
            analyzer_name=data.get("analyzer_name", ""),
            ground_truth_path=data.get("ground_truth_path", ""),
            total_systems=data.get("total_systems", 0),
            system_scores=data.get("system_scores", []),
            by_framework=data.get("by_framework", {}),
            runtime_seconds=data.get("runtime_seconds", 0.0),
        )

        # Load overall metrics
        overall = data.get("overall_metrics", {})
        mast = overall.get("mast", {})
        results.mast_precision = mast.get("precision", 0.0)
        results.mast_recall = mast.get("recall", 0.0)
        results.mast_f1 = mast.get("f1", 0.0)

        conn = overall.get("connection", {})
        results.connection_precision = conn.get("precision", 0.0)
        results.connection_recall = conn.get("recall", 0.0)
        results.connection_f1 = conn.get("f1", 0.0)

        align = overall.get("alignment", {})
        results.alignment_mae = align.get("mae", 0.0)
        results.alignment_correlation = align.get("correlation", 0.0)

        return results

    def summary(self) -> str:
        """Generate human-readable summary."""
        lines = [
            f"Benchmark Results - {self.timestamp}",
            f"Analyzer: {self.analyzer_name}",
            f"Systems: {self.total_systems}",
            "",
            "MAST Detection:",
            f"  Precision: {self.mast_precision:.3f}",
            f"  Recall:    {self.mast_recall:.3f}",
            f"  F1 Score:  {self.mast_f1:.3f}",
            "",
            "Connection Detection:",
            f"  Precision: {self.connection_precision:.3f}",
            f"  Recall:    {self.connection_recall:.3f}",
            f"  F1 Score:  {self.connection_f1:.3f}",
            "",
            "Alignment Scoring:",
            f"  MAE:         {self.alignment_mae:.2f}",
            f"  Correlation: {self.alignment_correlation:.3f}",
            "",
            f"Runtime: {self.runtime_seconds:.2f}s",
        ]
        return "\n".join(lines)


@dataclass
class StatisticalTest:
    """Result of a statistical significance test."""

    test_name: str
    statistic: float
    p_value: float
    significant: bool  # at alpha=0.05
    effect_size: float = 0.0
    confidence_interval: tuple[float, float] = (0.0, 0.0)


@dataclass
class ComparisonReport:
    """Comparison between benchmark results and baseline."""

    results_name: str
    baseline_name: str
    timestamp: str = ""

    # Metric differences (results - baseline)
    mast_f1_diff: float = 0.0
    connection_f1_diff: float = 0.0
    alignment_mae_diff: float = 0.0

    # Statistical tests
    mast_significance: StatisticalTest | None = None
    connection_significance: StatisticalTest | None = None
    alignment_significance: StatisticalTest | None = None

    # Overall assessment
    is_improvement: bool = False
    summary_notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "results_name": self.results_name,
            "baseline_name": self.baseline_name,
            "timestamp": self.timestamp,
            "differences": {
                "mast_f1": self.mast_f1_diff,
                "connection_f1": self.connection_f1_diff,
                "alignment_mae": self.alignment_mae_diff,
            },
            "is_improvement": self.is_improvement,
            "summary_notes": self.summary_notes,
        }

    def summary(self) -> str:
        """Generate human-readable summary."""
        lines = [
            f"Comparison: {self.results_name} vs {self.baseline_name}",
            "",
            "Metric Differences:",
            f"  MAST F1:       {self.mast_f1_diff:+.3f}",
            f"  Connection F1: {self.connection_f1_diff:+.3f}",
            f"  Alignment MAE: {self.alignment_mae_diff:+.2f} (lower is better)",
            "",
        ]

        if self.mast_significance:
            sig = "Yes" if self.mast_significance.significant else "No"
            lines.append(
                f"MAST improvement significant: {sig} (p={self.mast_significance.p_value:.4f})"
            )

        if self.connection_significance:
            sig = "Yes" if self.connection_significance.significant else "No"
            lines.append(
                f"Connection improvement significant: {sig} (p={self.connection_significance.p_value:.4f})"
            )

        if self.alignment_significance:
            sig = "Yes" if self.alignment_significance.significant else "No"
            lines.append(
                f"Alignment improvement significant: {sig} (p={self.alignment_significance.p_value:.4f})"
            )

        lines.append("")
        lines.append(f"Overall Improvement: {'Yes' if self.is_improvement else 'No'}")

        if self.summary_notes:
            lines.append("")
            lines.append("Notes:")
            for note in self.summary_notes:
                lines.append(f"  - {note}")

        return "\n".join(lines)


def paired_t_test(scores1: list[float], scores2: list[float]) -> StatisticalTest:
    """Perform paired t-test between two sets of scores.

    Args:
        scores1: First set of scores
        scores2: Second set of scores (paired)

    Returns:
        StatisticalTest with results
    """
    from scipy import stats

    if len(scores1) != len(scores2):
        raise ValueError("Score lists must be same length for paired test")

    if len(scores1) < 2:
        return StatisticalTest(
            test_name="paired_t_test",
            statistic=0.0,
            p_value=1.0,
            significant=False,
        )

    # Perform test
    statistic, p_value = stats.ttest_rel(scores1, scores2)

    # Calculate effect size (Cohen's d)
    diff = np.array(scores1) - np.array(scores2)
    effect_size = np.mean(diff) / np.std(diff) if np.std(diff) > 0 else 0

    # Bootstrap confidence interval for mean difference
    n_bootstrap = 1000
    bootstrap_means = []
    for _ in range(n_bootstrap):
        sample_idx = np.random.choice(len(diff), size=len(diff), replace=True)
        bootstrap_means.append(np.mean(diff[sample_idx]))

    ci_lower = np.percentile(bootstrap_means, 2.5)
    ci_upper = np.percentile(bootstrap_means, 97.5)

    return StatisticalTest(
        test_name="paired_t_test",
        statistic=float(statistic),
        p_value=float(p_value),
        significant=p_value < 0.05,
        effect_size=float(effect_size),
        confidence_interval=(float(ci_lower), float(ci_upper)),
    )


def bootstrap_test(
    scores1: list[float], scores2: list[float], n_bootstrap: int = 10000
) -> StatisticalTest:
    """Perform bootstrap significance test.

    Tests if the mean of scores1 is significantly different from scores2.

    Args:
        scores1: First set of scores
        scores2: Second set of scores
        n_bootstrap: Number of bootstrap iterations

    Returns:
        StatisticalTest with results
    """
    arr1 = np.array(scores1)
    arr2 = np.array(scores2)

    observed_diff = np.mean(arr1) - np.mean(arr2)

    # Pool scores for permutation test
    pooled = np.concatenate([arr1, arr2])
    n1 = len(arr1)

    # Bootstrap
    bootstrap_diffs = []
    for _ in range(n_bootstrap):
        np.random.shuffle(pooled)
        bootstrap_diffs.append(np.mean(pooled[:n1]) - np.mean(pooled[n1:]))

    # Calculate p-value (two-tailed)
    p_value = np.mean(np.abs(bootstrap_diffs) >= np.abs(observed_diff))

    # Effect size
    pooled_std = np.std(pooled)
    effect_size = observed_diff / pooled_std if pooled_std > 0 else 0

    # CI from bootstrap distribution
    ci_lower = np.percentile(bootstrap_diffs, 2.5)
    ci_upper = np.percentile(bootstrap_diffs, 97.5)

    return StatisticalTest(
        test_name="bootstrap_test",
        statistic=float(observed_diff),
        p_value=float(p_value),
        significant=p_value < 0.05,
        effect_size=float(effect_size),
        confidence_interval=(float(ci_lower), float(ci_upper)),
    )
