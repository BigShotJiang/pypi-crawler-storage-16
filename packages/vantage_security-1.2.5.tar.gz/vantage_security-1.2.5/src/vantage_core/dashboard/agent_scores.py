"""Agent security score tracking over time.

Tracks individual agent security scores and trends.
"""

import json
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any


@dataclass
class AgentScoreRecord:
    """Record of an agent's security score at a point in time."""

    agent_id: str
    agent_name: str
    project_name: str
    timestamp: str
    security_score: int
    risk_level: str  # low, medium, high, critical
    has_system_prompt: bool
    has_tools: bool
    tool_count: int
    finding_count: int
    critical_findings: int
    high_findings: int
    framework: str
    scan_id: str
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "agent_id": self.agent_id,
            "agent_name": self.agent_name,
            "project_name": self.project_name,
            "timestamp": self.timestamp,
            "security_score": self.security_score,
            "risk_level": self.risk_level,
            "has_system_prompt": self.has_system_prompt,
            "has_tools": self.has_tools,
            "tool_count": self.tool_count,
            "finding_count": self.finding_count,
            "critical_findings": self.critical_findings,
            "high_findings": self.high_findings,
            "framework": self.framework,
            "scan_id": self.scan_id,
            "metadata": self.metadata,
        }


@dataclass
class AgentScoreHistory:
    """Historical score data for an agent."""

    agent_id: str
    agent_name: str
    project_name: str
    framework: str
    record_count: int
    current_score: int
    avg_score: float
    min_score: int
    max_score: int
    score_trend: list[int]
    timestamps: list[str]
    improvement_rate: float
    risk_level_history: list[str]
    first_seen: str
    last_seen: str

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "agent_id": self.agent_id,
            "agent_name": self.agent_name,
            "project_name": self.project_name,
            "framework": self.framework,
            "record_count": self.record_count,
            "current_score": self.current_score,
            "avg_score": self.avg_score,
            "min_score": self.min_score,
            "max_score": self.max_score,
            "score_trend": self.score_trend,
            "timestamps": self.timestamps,
            "improvement_rate": self.improvement_rate,
            "risk_level_history": self.risk_level_history,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
        }


class AgentScoreTracker:
    """SQLite database for agent score tracking."""

    def __init__(self, db_path: str | None = None):
        """Initialize database.

        Args:
            db_path: Path to SQLite database. Defaults to ~/.vantage/agent_scores.db
        """
        if db_path is None:
            db_dir = Path.home() / ".vantage"
            db_dir.mkdir(parents=True, exist_ok=True)
            db_path = str(db_dir / "agent_scores.db")

        self.db_path = db_path
        self._init_db()

    def _init_db(self) -> None:
        """Initialize database schema."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS agent_scores (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_id TEXT NOT NULL,
                    agent_name TEXT NOT NULL,
                    project_name TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    security_score INTEGER NOT NULL,
                    risk_level TEXT NOT NULL,
                    has_system_prompt INTEGER NOT NULL,
                    has_tools INTEGER NOT NULL,
                    tool_count INTEGER NOT NULL,
                    finding_count INTEGER NOT NULL,
                    critical_findings INTEGER NOT NULL,
                    high_findings INTEGER NOT NULL,
                    framework TEXT NOT NULL,
                    scan_id TEXT NOT NULL,
                    metadata TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_agent_project
                ON agent_scores(agent_id, project_name)
            """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_project_timestamp
                ON agent_scores(project_name, timestamp)
            """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_scan_id
                ON agent_scores(scan_id)
            """
            )
            conn.commit()

    def record_agent_score(self, record: AgentScoreRecord) -> None:
        """Record an agent's security score."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                INSERT INTO agent_scores (
                    agent_id, agent_name, project_name, timestamp, security_score,
                    risk_level, has_system_prompt, has_tools, tool_count,
                    finding_count, critical_findings, high_findings,
                    framework, scan_id, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    record.agent_id,
                    record.agent_name,
                    record.project_name,
                    record.timestamp,
                    record.security_score,
                    record.risk_level,
                    1 if record.has_system_prompt else 0,
                    1 if record.has_tools else 0,
                    record.tool_count,
                    record.finding_count,
                    record.critical_findings,
                    record.high_findings,
                    record.framework,
                    record.scan_id,
                    json.dumps(record.metadata),
                ),
            )
            conn.commit()

    def record_agents_from_scan(
        self,
        scan_results: dict[str, Any],
        scan_id: str,
        project_name: str,
    ) -> list[AgentScoreRecord]:
        """Record all agents from a scan result.

        Args:
            scan_results: Full scan results
            scan_id: Scan ID for correlation
            project_name: Project name

        Returns:
            List of created AgentScoreRecord objects
        """
        timestamp = datetime.now().isoformat()
        records = []

        agents = scan_results.get("agents", [])
        findings = scan_results.get("findings", [])

        # Build agent findings map
        agent_findings: dict[str, list[dict]] = {}
        for finding in findings:
            agent_id = finding.get("agent_id", "")
            if agent_id:
                if agent_id not in agent_findings:
                    agent_findings[agent_id] = []
                agent_findings[agent_id].append(finding)

        for agent in agents:
            agent_id = agent.get("id", agent.get("name", "unknown"))
            agent_name = agent.get("name", agent_id)

            # Get findings for this agent
            agent_specific_findings = agent_findings.get(agent_id, [])
            critical = sum(1 for f in agent_specific_findings if f.get("severity") == "critical")
            high = sum(1 for f in agent_specific_findings if f.get("severity") == "high")

            # Calculate agent-specific score
            base_score = 100
            base_score -= critical * 20
            base_score -= high * 10
            base_score -= len(agent_specific_findings) * 2
            security_score = max(0, min(100, base_score))

            # Determine risk level
            if critical > 0:
                risk_level = "critical"
            elif high > 0:
                risk_level = "high"
            elif len(agent_specific_findings) > 3:
                risk_level = "medium"
            else:
                risk_level = "low"

            record = AgentScoreRecord(
                agent_id=agent_id,
                agent_name=agent_name,
                project_name=project_name,
                timestamp=timestamp,
                security_score=security_score,
                risk_level=risk_level,
                has_system_prompt=agent.get("has_system_prompt", False),
                has_tools=agent.get("has_tools", False),
                tool_count=len(agent.get("tools", [])),
                finding_count=len(agent_specific_findings),
                critical_findings=critical,
                high_findings=high,
                framework=agent.get("framework", "unknown"),
                scan_id=scan_id,
                metadata=agent.get("metadata", {}),
            )

            self.record_agent_score(record)
            records.append(record)

        return records

    def get_agent_history(
        self,
        agent_id: str,
        project_name: str,
        days: int = 30,
        limit: int = 100,
    ) -> list[AgentScoreRecord]:
        """Get score history for a specific agent.

        Args:
            agent_id: Agent identifier
            project_name: Project name
            days: Number of days to look back
            limit: Maximum records to return

        Returns:
            List of AgentScoreRecord objects
        """
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()

        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                """
                SELECT * FROM agent_scores
                WHERE agent_id = ? AND project_name = ? AND timestamp >= ?
                ORDER BY timestamp DESC
                LIMIT ?
            """,
                (agent_id, project_name, cutoff, limit),
            )

            records = []
            for row in cursor.fetchall():
                records.append(
                    AgentScoreRecord(
                        agent_id=row["agent_id"],
                        agent_name=row["agent_name"],
                        project_name=row["project_name"],
                        timestamp=row["timestamp"],
                        security_score=row["security_score"],
                        risk_level=row["risk_level"],
                        has_system_prompt=bool(row["has_system_prompt"]),
                        has_tools=bool(row["has_tools"]),
                        tool_count=row["tool_count"],
                        finding_count=row["finding_count"],
                        critical_findings=row["critical_findings"],
                        high_findings=row["high_findings"],
                        framework=row["framework"],
                        scan_id=row["scan_id"],
                        metadata=json.loads(row["metadata"] or "{}"),
                    )
                )

            return records

    def get_all_agents(self, project_name: str | None = None) -> list[dict[str, Any]]:
        """Get list of all tracked agents.

        Args:
            project_name: Filter by project

        Returns:
            List of agent info dictionaries
        """
        with sqlite3.connect(self.db_path) as conn:
            if project_name:
                cursor = conn.execute(
                    """
                    SELECT DISTINCT agent_id, agent_name, project_name, framework,
                           MIN(timestamp) as first_seen, MAX(timestamp) as last_seen,
                           COUNT(*) as record_count
                    FROM agent_scores
                    WHERE project_name = ?
                    GROUP BY agent_id, project_name
                    ORDER BY agent_name
                """,
                    (project_name,),
                )
            else:
                cursor = conn.execute(
                    """
                    SELECT DISTINCT agent_id, agent_name, project_name, framework,
                           MIN(timestamp) as first_seen, MAX(timestamp) as last_seen,
                           COUNT(*) as record_count
                    FROM agent_scores
                    GROUP BY agent_id, project_name
                    ORDER BY project_name, agent_name
                """
                )

            agents = []
            for row in cursor.fetchall():
                agents.append(
                    {
                        "agent_id": row[0],
                        "agent_name": row[1],
                        "project_name": row[2],
                        "framework": row[3],
                        "first_seen": row[4],
                        "last_seen": row[5],
                        "record_count": row[6],
                    }
                )

            return agents

    def get_agent_score_history(
        self,
        agent_id: str,
        project_name: str,
        days: int = 30,
    ) -> AgentScoreHistory | None:
        """Get comprehensive score history for an agent.

        Args:
            agent_id: Agent identifier
            project_name: Project name
            days: Number of days to analyze

        Returns:
            AgentScoreHistory or None
        """
        records = self.get_agent_history(agent_id, project_name, days, limit=1000)
        if not records:
            return None

        # Sort by timestamp (oldest first)
        records.sort(key=lambda r: r.timestamp)

        scores = [r.security_score for r in records]
        avg_score = sum(scores) / len(scores)

        # Calculate improvement rate
        if len(scores) >= 2:
            improvement_rate = ((scores[-1] - scores[0]) / max(scores[0], 1)) * 100
        else:
            improvement_rate = 0.0

        return AgentScoreHistory(
            agent_id=agent_id,
            agent_name=records[-1].agent_name,
            project_name=project_name,
            framework=records[-1].framework,
            record_count=len(records),
            current_score=scores[-1],
            avg_score=round(avg_score, 1),
            min_score=min(scores),
            max_score=max(scores),
            score_trend=scores,
            timestamps=[r.timestamp for r in records],
            improvement_rate=round(improvement_rate, 1),
            risk_level_history=[r.risk_level for r in records],
            first_seen=records[0].timestamp,
            last_seen=records[-1].timestamp,
        )

    def get_project_agent_scores(
        self,
        project_name: str,
        days: int = 30,
    ) -> list[AgentScoreHistory]:
        """Get score histories for all agents in a project.

        Args:
            project_name: Project name
            days: Number of days to analyze

        Returns:
            List of AgentScoreHistory objects
        """
        agents = self.get_all_agents(project_name)
        histories = []

        for agent in agents:
            history = self.get_agent_score_history(agent["agent_id"], project_name, days)
            if history:
                histories.append(history)

        return histories

    def get_worst_agents(
        self,
        project_name: str | None = None,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        """Get agents with lowest current scores.

        Args:
            project_name: Filter by project
            limit: Number of agents to return

        Returns:
            List of agent info with scores
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row

            # Get most recent score for each agent
            if project_name:
                cursor = conn.execute(
                    """
                    SELECT a.agent_id, a.agent_name, a.project_name, a.framework,
                           a.security_score, a.risk_level, a.finding_count,
                           a.critical_findings, a.high_findings, a.timestamp
                    FROM agent_scores a
                    INNER JOIN (
                        SELECT agent_id, project_name, MAX(timestamp) as max_ts
                        FROM agent_scores
                        WHERE project_name = ?
                        GROUP BY agent_id, project_name
                    ) b ON a.agent_id = b.agent_id
                       AND a.project_name = b.project_name
                       AND a.timestamp = b.max_ts
                    ORDER BY a.security_score ASC
                    LIMIT ?
                """,
                    (project_name, limit),
                )
            else:
                cursor = conn.execute(
                    """
                    SELECT a.agent_id, a.agent_name, a.project_name, a.framework,
                           a.security_score, a.risk_level, a.finding_count,
                           a.critical_findings, a.high_findings, a.timestamp
                    FROM agent_scores a
                    INNER JOIN (
                        SELECT agent_id, project_name, MAX(timestamp) as max_ts
                        FROM agent_scores
                        GROUP BY agent_id, project_name
                    ) b ON a.agent_id = b.agent_id
                       AND a.project_name = b.project_name
                       AND a.timestamp = b.max_ts
                    ORDER BY a.security_score ASC
                    LIMIT ?
                """,
                    (limit,),
                )

            return [dict(row) for row in cursor.fetchall()]

    def get_improved_agents(
        self,
        project_name: str | None = None,
        days: int = 30,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        """Get agents that have improved the most.

        Args:
            project_name: Filter by project
            days: Time period to analyze
            limit: Number of agents to return

        Returns:
            List of agents with improvement data
        """
        if project_name:
            agents = self.get_all_agents(project_name)
        else:
            agents = self.get_all_agents()

        improvements = []
        for agent in agents:
            history = self.get_agent_score_history(agent["agent_id"], agent["project_name"], days)
            if history and history.record_count >= 2:
                improvements.append(
                    {
                        "agent_id": history.agent_id,
                        "agent_name": history.agent_name,
                        "project_name": history.project_name,
                        "framework": history.framework,
                        "current_score": history.current_score,
                        "improvement_rate": history.improvement_rate,
                        "first_score": history.score_trend[0],
                        "record_count": history.record_count,
                    }
                )

        # Sort by improvement rate
        improvements.sort(key=lambda x: x["improvement_rate"], reverse=True)
        return improvements[:limit]


def get_agent_score_history(
    agent_id: str,
    project_name: str,
    days: int = 30,
    db_path: str | None = None,
) -> AgentScoreHistory | None:
    """Get score history for an agent.

    Args:
        agent_id: Agent identifier
        project_name: Project name
        days: Number of days to analyze
        db_path: Optional database path

    Returns:
        AgentScoreHistory or None
    """
    tracker = AgentScoreTracker(db_path)
    return tracker.get_agent_score_history(agent_id, project_name, days)


def get_agent_score_trends(
    project_name: str,
    days: int = 30,
    db_path: str | None = None,
) -> list[AgentScoreHistory]:
    """Get score trends for all agents in a project.

    Args:
        project_name: Project name
        days: Number of days to analyze
        db_path: Optional database path

    Returns:
        List of AgentScoreHistory objects
    """
    tracker = AgentScoreTracker(db_path)
    return tracker.get_project_agent_scores(project_name, days)
