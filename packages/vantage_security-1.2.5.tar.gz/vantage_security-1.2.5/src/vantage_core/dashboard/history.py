"""Historical vulnerability tracking for Team Dashboard.

Stores scan results over time and calculates vulnerability trends.
"""

import hashlib
import json
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any


@dataclass
class ScanRecord:
    """Record of a single scan."""

    scan_id: str
    timestamp: str
    project_name: str
    atss_score: int
    atss_grade: str
    total_findings: int
    critical_count: int
    high_count: int
    medium_count: int
    low_count: int
    agents_detected: int
    frameworks: list[str] = field(default_factory=list)
    findings_by_type: dict[str, int] = field(default_factory=dict)
    branch: str = ""
    commit_hash: str = ""
    scan_duration_seconds: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "scan_id": self.scan_id,
            "timestamp": self.timestamp,
            "project_name": self.project_name,
            "atss_score": self.atss_score,
            "atss_grade": self.atss_grade,
            "total_findings": self.total_findings,
            "critical_count": self.critical_count,
            "high_count": self.high_count,
            "medium_count": self.medium_count,
            "low_count": self.low_count,
            "agents_detected": self.agents_detected,
            "frameworks": self.frameworks,
            "findings_by_type": self.findings_by_type,
            "branch": self.branch,
            "commit_hash": self.commit_hash,
            "scan_duration_seconds": self.scan_duration_seconds,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ScanRecord":
        """Create from dictionary."""
        return cls(
            scan_id=data["scan_id"],
            timestamp=data["timestamp"],
            project_name=data["project_name"],
            atss_score=data["atss_score"],
            atss_grade=data["atss_grade"],
            total_findings=data["total_findings"],
            critical_count=data["critical_count"],
            high_count=data["high_count"],
            medium_count=data["medium_count"],
            low_count=data["low_count"],
            agents_detected=data["agents_detected"],
            frameworks=data.get("frameworks", []),
            findings_by_type=data.get("findings_by_type", {}),
            branch=data.get("branch", ""),
            commit_hash=data.get("commit_hash", ""),
            scan_duration_seconds=data.get("scan_duration_seconds", 0.0),
            metadata=data.get("metadata", {}),
        )


@dataclass
class VulnerabilityTrend:
    """Vulnerability trend data over a time period."""

    period_start: str
    period_end: str
    project_name: str
    scan_count: int
    avg_score: float
    min_score: int
    max_score: int
    total_findings: int
    critical_trend: list[int]  # Counts per scan
    high_trend: list[int]
    medium_trend: list[int]
    low_trend: list[int]
    score_trend: list[int]
    timestamps: list[str]
    improvement_rate: float  # Percentage change in score

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "period_start": self.period_start,
            "period_end": self.period_end,
            "project_name": self.project_name,
            "scan_count": self.scan_count,
            "avg_score": self.avg_score,
            "min_score": self.min_score,
            "max_score": self.max_score,
            "total_findings": self.total_findings,
            "critical_trend": self.critical_trend,
            "high_trend": self.high_trend,
            "medium_trend": self.medium_trend,
            "low_trend": self.low_trend,
            "score_trend": self.score_trend,
            "timestamps": self.timestamps,
            "improvement_rate": self.improvement_rate,
        }


class HistoryDatabase:
    """SQLite database for scan history."""

    def __init__(self, db_path: str | None = None):
        """Initialize database.

        Args:
            db_path: Path to SQLite database. Defaults to ~/.vantage/history.db
        """
        if db_path is None:
            db_dir = Path.home() / ".vantage"
            db_dir.mkdir(parents=True, exist_ok=True)
            db_path = str(db_dir / "history.db")

        self.db_path = db_path
        self._init_db()

    def _init_db(self) -> None:
        """Initialize database schema."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS scan_history (
                    scan_id TEXT PRIMARY KEY,
                    timestamp TEXT NOT NULL,
                    project_name TEXT NOT NULL,
                    atss_score INTEGER NOT NULL,
                    atss_grade TEXT NOT NULL,
                    total_findings INTEGER NOT NULL,
                    critical_count INTEGER NOT NULL,
                    high_count INTEGER NOT NULL,
                    medium_count INTEGER NOT NULL,
                    low_count INTEGER NOT NULL,
                    agents_detected INTEGER NOT NULL,
                    frameworks TEXT NOT NULL,
                    findings_by_type TEXT NOT NULL,
                    branch TEXT,
                    commit_hash TEXT,
                    scan_duration_seconds REAL,
                    metadata TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_project_timestamp
                ON scan_history(project_name, timestamp)
            """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_timestamp
                ON scan_history(timestamp)
            """
            )
            conn.commit()

    def record_scan(self, record: ScanRecord) -> None:
        """Record a scan result."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO scan_history (
                    scan_id, timestamp, project_name, atss_score, atss_grade,
                    total_findings, critical_count, high_count, medium_count, low_count,
                    agents_detected, frameworks, findings_by_type, branch, commit_hash,
                    scan_duration_seconds, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    record.scan_id,
                    record.timestamp,
                    record.project_name,
                    record.atss_score,
                    record.atss_grade,
                    record.total_findings,
                    record.critical_count,
                    record.high_count,
                    record.medium_count,
                    record.low_count,
                    record.agents_detected,
                    json.dumps(record.frameworks),
                    json.dumps(record.findings_by_type),
                    record.branch,
                    record.commit_hash,
                    record.scan_duration_seconds,
                    json.dumps(record.metadata),
                ),
            )
            conn.commit()

    def get_scan_history(
        self,
        project_name: str | None = None,
        days: int = 30,
        limit: int = 100,
    ) -> list[ScanRecord]:
        """Get scan history.

        Args:
            project_name: Filter by project name
            days: Number of days to look back
            limit: Maximum number of records

        Returns:
            List of ScanRecord objects
        """
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()

        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            if project_name:
                cursor = conn.execute(
                    """
                    SELECT * FROM scan_history
                    WHERE project_name = ? AND timestamp >= ?
                    ORDER BY timestamp DESC
                    LIMIT ?
                """,
                    (project_name, cutoff, limit),
                )
            else:
                cursor = conn.execute(
                    """
                    SELECT * FROM scan_history
                    WHERE timestamp >= ?
                    ORDER BY timestamp DESC
                    LIMIT ?
                """,
                    (cutoff, limit),
                )

            records = []
            for row in cursor.fetchall():
                records.append(
                    ScanRecord(
                        scan_id=row["scan_id"],
                        timestamp=row["timestamp"],
                        project_name=row["project_name"],
                        atss_score=row["atss_score"],
                        atss_grade=row["atss_grade"],
                        total_findings=row["total_findings"],
                        critical_count=row["critical_count"],
                        high_count=row["high_count"],
                        medium_count=row["medium_count"],
                        low_count=row["low_count"],
                        agents_detected=row["agents_detected"],
                        frameworks=json.loads(row["frameworks"]),
                        findings_by_type=json.loads(row["findings_by_type"]),
                        branch=row["branch"] or "",
                        commit_hash=row["commit_hash"] or "",
                        scan_duration_seconds=row["scan_duration_seconds"] or 0.0,
                        metadata=json.loads(row["metadata"] or "{}"),
                    )
                )

            return records

    def get_projects(self) -> list[str]:
        """Get list of all projects."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "SELECT DISTINCT project_name FROM scan_history ORDER BY project_name"
            )
            return [row[0] for row in cursor.fetchall()]

    def get_vulnerability_trends(
        self,
        project_name: str | None = None,
        days: int = 30,
    ) -> VulnerabilityTrend | None:
        """Calculate vulnerability trends over time.

        Args:
            project_name: Filter by project name
            days: Number of days to analyze

        Returns:
            VulnerabilityTrend or None if no data
        """
        records = self.get_scan_history(project_name, days, limit=1000)
        if not records:
            return None

        # Sort by timestamp (oldest first)
        records.sort(key=lambda r: r.timestamp)

        critical_trend = [r.critical_count for r in records]
        high_trend = [r.high_count for r in records]
        medium_trend = [r.medium_count for r in records]
        low_trend = [r.low_count for r in records]
        score_trend = [r.atss_score for r in records]
        timestamps = [r.timestamp for r in records]

        scores = [r.atss_score for r in records]
        avg_score = sum(scores) / len(scores)

        # Calculate improvement rate (first vs last score)
        if len(scores) >= 2:
            improvement_rate = ((scores[-1] - scores[0]) / max(scores[0], 1)) * 100
        else:
            improvement_rate = 0.0

        return VulnerabilityTrend(
            period_start=records[0].timestamp,
            period_end=records[-1].timestamp,
            project_name=project_name or "all",
            scan_count=len(records),
            avg_score=avg_score,
            min_score=min(scores),
            max_score=max(scores),
            total_findings=sum(r.total_findings for r in records),
            critical_trend=critical_trend,
            high_trend=high_trend,
            medium_trend=medium_trend,
            low_trend=low_trend,
            score_trend=score_trend,
            timestamps=timestamps,
            improvement_rate=improvement_rate,
        )

    def get_latest_scan(self, project_name: str) -> ScanRecord | None:
        """Get the most recent scan for a project."""
        records = self.get_scan_history(project_name, days=365, limit=1)
        return records[0] if records else None

    def get_scan_by_id(self, scan_id: str) -> ScanRecord | None:
        """Get a specific scan by ID."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute("SELECT * FROM scan_history WHERE scan_id = ?", (scan_id,))
            row = cursor.fetchone()
            if not row:
                return None

            return ScanRecord(
                scan_id=row["scan_id"],
                timestamp=row["timestamp"],
                project_name=row["project_name"],
                atss_score=row["atss_score"],
                atss_grade=row["atss_grade"],
                total_findings=row["total_findings"],
                critical_count=row["critical_count"],
                high_count=row["high_count"],
                medium_count=row["medium_count"],
                low_count=row["low_count"],
                agents_detected=row["agents_detected"],
                frameworks=json.loads(row["frameworks"]),
                findings_by_type=json.loads(row["findings_by_type"]),
                branch=row["branch"] or "",
                commit_hash=row["commit_hash"] or "",
                scan_duration_seconds=row["scan_duration_seconds"] or 0.0,
                metadata=json.loads(row["metadata"] or "{}"),
            )

    def delete_old_records(self, days: int = 90) -> int:
        """Delete records older than specified days.

        Args:
            days: Delete records older than this many days

        Returns:
            Number of deleted records
        """
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("DELETE FROM scan_history WHERE timestamp < ?", (cutoff,))
            conn.commit()
            return cursor.rowcount

    def get_statistics(self, project_name: str | None = None) -> dict[str, Any]:
        """Get overall statistics.

        Args:
            project_name: Filter by project name

        Returns:
            Dictionary of statistics
        """
        with sqlite3.connect(self.db_path) as conn:
            if project_name:
                cursor = conn.execute(
                    """
                    SELECT
                        COUNT(*) as total_scans,
                        AVG(atss_score) as avg_score,
                        MIN(atss_score) as min_score,
                        MAX(atss_score) as max_score,
                        SUM(total_findings) as total_findings,
                        SUM(critical_count) as total_critical,
                        SUM(high_count) as total_high,
                        AVG(agents_detected) as avg_agents,
                        MIN(timestamp) as first_scan,
                        MAX(timestamp) as last_scan
                    FROM scan_history
                    WHERE project_name = ?
                """,
                    (project_name,),
                )
            else:
                cursor = conn.execute(
                    """
                    SELECT
                        COUNT(*) as total_scans,
                        AVG(atss_score) as avg_score,
                        MIN(atss_score) as min_score,
                        MAX(atss_score) as max_score,
                        SUM(total_findings) as total_findings,
                        SUM(critical_count) as total_critical,
                        SUM(high_count) as total_high,
                        AVG(agents_detected) as avg_agents,
                        MIN(timestamp) as first_scan,
                        MAX(timestamp) as last_scan
                    FROM scan_history
                """
                )

            row = cursor.fetchone()
            return {
                "total_scans": row[0] or 0,
                "avg_score": round(row[1] or 0, 1),
                "min_score": row[2] or 0,
                "max_score": row[3] or 0,
                "total_findings": row[4] or 0,
                "total_critical": row[5] or 0,
                "total_high": row[6] or 0,
                "avg_agents": round(row[7] or 0, 1),
                "first_scan": row[8],
                "last_scan": row[9],
            }


def _generate_scan_id(project_name: str, timestamp: str) -> str:
    """Generate a unique scan ID."""
    data = f"{project_name}:{timestamp}:{datetime.now().timestamp()}"
    return hashlib.sha256(data.encode()).hexdigest()[:16]


def record_scan(
    scan_results: dict[str, Any],
    project_name: str = "",
    branch: str = "",
    commit_hash: str = "",
    db_path: str | None = None,
) -> ScanRecord:
    """Record scan results to history database.

    Args:
        scan_results: Scan results dictionary
        project_name: Project name
        branch: Git branch
        commit_hash: Git commit hash
        db_path: Optional database path

    Returns:
        Created ScanRecord
    """
    timestamp = datetime.now().isoformat()
    scan_id = _generate_scan_id(project_name, timestamp)

    # Extract findings by type
    findings_by_type: dict[str, int] = {}
    for finding in scan_results.get("findings", []):
        finding_type = finding.get("type", "unknown")
        findings_by_type[finding_type] = findings_by_type.get(finding_type, 0) + 1

    record = ScanRecord(
        scan_id=scan_id,
        timestamp=timestamp,
        project_name=project_name or scan_results.get("project_name", "unknown"),
        atss_score=scan_results.get("score", 0),
        atss_grade=scan_results.get("grade", "N/A"),
        total_findings=scan_results.get("findings_count", len(scan_results.get("findings", []))),
        critical_count=scan_results.get("critical_count", 0),
        high_count=scan_results.get("high_count", 0),
        medium_count=scan_results.get("medium_count", 0),
        low_count=scan_results.get("low_count", 0),
        agents_detected=scan_results.get("agents_detected", 0),
        frameworks=scan_results.get("frameworks", []),
        findings_by_type=findings_by_type,
        branch=branch,
        commit_hash=commit_hash,
        scan_duration_seconds=scan_results.get("duration_seconds", 0.0),
        metadata=scan_results.get("metadata", {}),
    )

    db = HistoryDatabase(db_path)
    db.record_scan(record)

    return record


def get_scan_history(
    project_name: str | None = None,
    days: int = 30,
    limit: int = 100,
    db_path: str | None = None,
) -> list[ScanRecord]:
    """Get scan history.

    Args:
        project_name: Filter by project name
        days: Number of days to look back
        limit: Maximum number of records
        db_path: Optional database path

    Returns:
        List of ScanRecord objects
    """
    db = HistoryDatabase(db_path)
    return db.get_scan_history(project_name, days, limit)


def get_vulnerability_trends(
    project_name: str | None = None,
    days: int = 30,
    db_path: str | None = None,
) -> VulnerabilityTrend | None:
    """Get vulnerability trends.

    Args:
        project_name: Filter by project name
        days: Number of days to analyze
        db_path: Optional database path

    Returns:
        VulnerabilityTrend or None
    """
    db = HistoryDatabase(db_path)
    return db.get_vulnerability_trends(project_name, days)
