"""Dashboard visualization for Team Dashboard.

Renders charts, tables, and visual reports for the CLI and HTML output.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from vantage_core.dashboard.agent_scores import AgentScoreHistory, AgentScoreTracker
from vantage_core.dashboard.history import (
    HistoryDatabase,
    ScanRecord,
    VulnerabilityTrend,
)
from vantage_core.dashboard.remediation import (
    RemediationItem,
    RemediationSummary,
    RemediationTracker,
)


@dataclass
class DashboardData:
    """Complete dashboard data."""

    project_name: str
    generated_at: str
    vulnerability_trend: VulnerabilityTrend | None
    agent_scores: list[AgentScoreHistory]
    remediation_summary: RemediationSummary
    recent_scans: list[ScanRecord]
    open_remediations: list[RemediationItem]
    worst_agents: list[dict[str, Any]]
    improved_agents: list[dict[str, Any]]
    statistics: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "project_name": self.project_name,
            "generated_at": self.generated_at,
            "vulnerability_trend": (
                self.vulnerability_trend.to_dict() if self.vulnerability_trend else None
            ),
            "agent_scores": [s.to_dict() for s in self.agent_scores],
            "remediation_summary": self.remediation_summary.to_dict(),
            "recent_scans": [s.to_dict() for s in self.recent_scans],
            "open_remediations": [r.to_dict() for r in self.open_remediations],
            "worst_agents": self.worst_agents,
            "improved_agents": self.improved_agents,
            "statistics": self.statistics,
        }


class DashboardRenderer:
    """Renders dashboard visualizations."""

    def __init__(
        self,
        history_db_path: str | None = None,
        agent_db_path: str | None = None,
        remediation_db_path: str | None = None,
    ):
        """Initialize renderer with database paths."""
        self.history_db = HistoryDatabase(history_db_path)
        self.agent_tracker = AgentScoreTracker(agent_db_path)
        self.remediation_tracker = RemediationTracker(remediation_db_path)

    def get_dashboard_data(
        self,
        project_name: str | None = None,
        days: int = 30,
    ) -> DashboardData:
        """Get complete dashboard data.

        Args:
            project_name: Filter by project
            days: Number of days to analyze

        Returns:
            DashboardData object
        """
        return DashboardData(
            project_name=project_name or "all",
            generated_at=datetime.now().isoformat(),
            vulnerability_trend=self.history_db.get_vulnerability_trends(project_name, days),
            agent_scores=(
                self.agent_tracker.get_project_agent_scores(project_name, days)
                if project_name
                else []
            ),
            remediation_summary=self.remediation_tracker.get_summary(project_name),
            recent_scans=self.history_db.get_scan_history(project_name, days, limit=10),
            open_remediations=self.remediation_tracker.get_open_items(project_name, limit=20),
            worst_agents=self.agent_tracker.get_worst_agents(project_name, limit=5),
            improved_agents=self.agent_tracker.get_improved_agents(project_name, days, limit=5),
            statistics=self.history_db.get_statistics(project_name),
        )

    def render_cli_dashboard(
        self,
        project_name: str | None = None,
        days: int = 30,
    ) -> str:
        """Render dashboard for CLI output.

        Args:
            project_name: Filter by project
            days: Number of days to analyze

        Returns:
            Formatted string for CLI display
        """
        data = self.get_dashboard_data(project_name, days)
        lines = []

        # Header
        lines.append("=" * 70)
        lines.append(f"  Team Security Dashboard - {data.project_name.upper()}")
        lines.append(f"  Generated: {data.generated_at[:19]}")
        lines.append("=" * 70)
        lines.append("")

        # Overview statistics
        stats = data.statistics
        lines.append("OVERVIEW")
        lines.append("-" * 40)
        lines.append(f"  Total Scans:     {stats.get('total_scans', 0)}")
        lines.append(f"  Average Score:   {stats.get('avg_score', 0)}/100")
        lines.append(
            f"  Score Range:     {stats.get('min_score', 0)} - {stats.get('max_score', 0)}"
        )
        lines.append(f"  Total Findings:  {stats.get('total_findings', 0)}")
        lines.append(f"  Critical:        {stats.get('total_critical', 0)}")
        lines.append(f"  High:            {stats.get('total_high', 0)}")
        lines.append("")

        # Vulnerability trend
        if data.vulnerability_trend:
            trend = data.vulnerability_trend
            lines.append("VULNERABILITY TRENDS")
            lines.append("-" * 40)
            lines.append(f"  Period: {trend.period_start[:10]} to {trend.period_end[:10]}")
            lines.append(f"  Scans: {trend.scan_count}")
            lines.append(f"  Improvement: {trend.improvement_rate:+.1f}%")
            lines.append("")

            # Mini ASCII chart of scores
            if trend.score_trend:
                lines.append("  Score Trend:")
                chart = self._render_ascii_chart(trend.score_trend, width=40, height=5)
                for line in chart:
                    lines.append(f"    {line}")
            lines.append("")

        # Remediation summary
        remediation = data.remediation_summary
        lines.append("REMEDIATION STATUS")
        lines.append("-" * 40)
        lines.append(f"  Total Items:     {remediation.total_items}")
        lines.append(f"  Open:            {remediation.open_count}")
        lines.append(f"  In Progress:     {remediation.in_progress_count}")
        lines.append(f"  Blocked:         {remediation.blocked_count}")
        lines.append(f"  Resolved:        {remediation.resolved_count}")
        lines.append(f"  Overdue:         {remediation.overdue_count}")
        lines.append(f"  Avg Resolution:  {remediation.avg_resolution_days} days")
        lines.append("")

        # MTTR by severity
        lines.append("  Mean Time to Remediate:")
        lines.append(f"    Critical: {remediation.mttr_critical} days")
        lines.append(f"    High:     {remediation.mttr_high} days")
        lines.append(f"    Medium:   {remediation.mttr_medium} days")
        lines.append(f"    Low:      {remediation.mttr_low} days")
        lines.append("")

        # Worst agents
        if data.worst_agents:
            lines.append("AGENTS NEEDING ATTENTION")
            lines.append("-" * 40)
            for agent in data.worst_agents[:5]:
                risk = agent.get("risk_level", "unknown")
                score = agent.get("security_score", 0)
                name = agent.get("agent_name", "unknown")[:25]
                lines.append(f"  [{risk.upper():8}] {name:25} Score: {score}")
            lines.append("")

        # Recent improvements
        if data.improved_agents:
            lines.append("TOP IMPROVEMENTS")
            lines.append("-" * 40)
            for agent in data.improved_agents[:5]:
                name = agent.get("agent_name", "unknown")[:25]
                improvement = agent.get("improvement_rate", 0)
                lines.append(f"  {name:25} {improvement:+.1f}%")
            lines.append("")

        # Open remediations
        if data.open_remediations:
            lines.append("OPEN REMEDIATIONS (Top 10)")
            lines.append("-" * 40)
            for item in data.open_remediations[:10]:
                severity = item.severity[:4].upper()
                title = item.title[:40]
                status = item.status.value[:10]
                overdue = " [OVERDUE]" if item.is_overdue else ""
                lines.append(f"  [{severity}] {title:40} {status}{overdue}")
            lines.append("")

        lines.append("=" * 70)
        return "\n".join(lines)

    def _render_ascii_chart(
        self,
        values: list[int],
        width: int = 40,
        height: int = 5,
    ) -> list[str]:
        """Render a simple ASCII chart.

        Args:
            values: List of values to plot
            width: Chart width
            height: Chart height

        Returns:
            List of strings representing chart lines
        """
        if not values:
            return ["No data"]

        min_val = min(values)
        max_val = max(values)
        val_range = max_val - min_val if max_val != min_val else 1

        # Normalize values to height
        normalized = [int((v - min_val) / val_range * (height - 1)) for v in values]

        # Sample if too many values
        if len(normalized) > width:
            step = len(normalized) / width
            normalized = [normalized[int(i * step)] for i in range(width)]

        # Build chart
        lines = []
        for row in range(height - 1, -1, -1):
            line = ""
            for col, val in enumerate(normalized):
                if val >= row:
                    line += "█"
                else:
                    line += " "
            # Add scale on the right
            if row == height - 1:
                line += f" {max_val}"
            elif row == 0:
                line += f" {min_val}"
            lines.append(line)

        return lines

    def render_html_dashboard(
        self,
        project_name: str | None = None,
        days: int = 30,
    ) -> str:
        """Render dashboard as HTML.

        Args:
            project_name: Filter by project
            days: Number of days to analyze

        Returns:
            HTML string
        """
        data = self.get_dashboard_data(project_name, days)

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vantage Team Dashboard - {data.project_name}</title>
    <style>
        :root {{
            --bg-primary: #1a1a2e;
            --bg-secondary: #16213e;
            --bg-card: #0f3460;
            --text-primary: #e8e8e8;
            --text-secondary: #a8a8a8;
            --accent: #00d9ff;
            --success: #00ff88;
            --warning: #ffa500;
            --danger: #ff4757;
            --critical: #ff0055;
        }}
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            margin: 0;
            padding: 20px;
        }}
        .dashboard {{
            max-width: 1400px;
            margin: 0 auto;
        }}
        .header {{
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            background: var(--bg-secondary);
            border-radius: 10px;
        }}
        .header h1 {{
            color: var(--accent);
            margin: 0;
        }}
        .header .subtitle {{
            color: var(--text-secondary);
            margin-top: 5px;
        }}
        .grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }}
        .card {{
            background: var(--bg-card);
            border-radius: 10px;
            padding: 20px;
        }}
        .card h3 {{
            color: var(--accent);
            margin-top: 0;
            border-bottom: 1px solid var(--accent);
            padding-bottom: 10px;
        }}
        .metric {{
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }}
        .metric:last-child {{
            border-bottom: none;
        }}
        .metric-label {{
            color: var(--text-secondary);
        }}
        .metric-value {{
            font-weight: bold;
        }}
        .score-badge {{
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-weight: bold;
        }}
        .score-a {{ background: var(--success); color: #000; }}
        .score-b {{ background: #88ff00; color: #000; }}
        .score-c {{ background: var(--warning); color: #000; }}
        .score-d {{ background: #ff8800; color: #000; }}
        .score-f {{ background: var(--danger); color: #fff; }}
        .severity-critical {{ color: var(--critical); }}
        .severity-high {{ color: var(--danger); }}
        .severity-medium {{ color: var(--warning); }}
        .severity-low {{ color: var(--success); }}
        .status-badge {{
            display: inline-block;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 0.8em;
        }}
        .status-open {{ background: var(--danger); }}
        .status-in_progress {{ background: var(--warning); color: #000; }}
        .status-resolved {{ background: var(--success); color: #000; }}
        .trend-up {{ color: var(--success); }}
        .trend-down {{ color: var(--danger); }}
        table {{
            width: 100%;
            border-collapse: collapse;
        }}
        th, td {{
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }}
        th {{
            color: var(--accent);
        }}
        .chart-container {{
            height: 200px;
            background: rgba(0,0,0,0.2);
            border-radius: 5px;
            padding: 10px;
            margin-top: 10px;
        }}
        .progress-bar {{
            height: 8px;
            background: rgba(255,255,255,0.1);
            border-radius: 4px;
            overflow: hidden;
        }}
        .progress-fill {{
            height: 100%;
            background: var(--accent);
            transition: width 0.3s;
        }}
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="header">
            <h1>Team Security Dashboard</h1>
            <div class="subtitle">Project: {data.project_name} | Generated: {data.generated_at[:19]}</div>
        </div>

        <!-- Overview Stats -->
        <div class="grid">
            <div class="card">
                <h3>Overview</h3>
                <div class="metric">
                    <span class="metric-label">Total Scans</span>
                    <span class="metric-value">{data.statistics.get('total_scans', 0)}</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Average Score</span>
                    <span class="metric-value">{data.statistics.get('avg_score', 0)}/100</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Score Range</span>
                    <span class="metric-value">{data.statistics.get('min_score', 0)} - {data.statistics.get('max_score', 0)}</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Total Findings</span>
                    <span class="metric-value">{data.statistics.get('total_findings', 0)}</span>
                </div>
            </div>

            <div class="card">
                <h3>Vulnerability Trend</h3>
                {self._render_trend_html(data.vulnerability_trend)}
            </div>

            <div class="card">
                <h3>Remediation Status</h3>
                {self._render_remediation_html(data.remediation_summary)}
            </div>
        </div>

        <!-- Agents -->
        <div class="grid">
            <div class="card">
                <h3>Agents Needing Attention</h3>
                {self._render_worst_agents_html(data.worst_agents)}
            </div>

            <div class="card">
                <h3>Top Improvements</h3>
                {self._render_improved_agents_html(data.improved_agents)}
            </div>
        </div>

        <!-- Open Remediations -->
        <div class="card">
            <h3>Open Remediations</h3>
            {self._render_remediations_table_html(data.open_remediations)}
        </div>

        <!-- Recent Scans -->
        <div class="card">
            <h3>Recent Scans</h3>
            {self._render_scans_table_html(data.recent_scans)}
        </div>
    </div>
</body>
</html>"""
        return html

    def _render_trend_html(self, trend: VulnerabilityTrend | None) -> str:
        """Render vulnerability trend section."""
        if not trend:
            return "<p>No trend data available</p>"

        trend_class = "trend-up" if trend.improvement_rate > 0 else "trend-down"
        trend_symbol = "↑" if trend.improvement_rate > 0 else "↓"

        return f"""
        <div class="metric">
            <span class="metric-label">Period</span>
            <span class="metric-value">{trend.period_start[:10]} to {trend.period_end[:10]}</span>
        </div>
        <div class="metric">
            <span class="metric-label">Scans</span>
            <span class="metric-value">{trend.scan_count}</span>
        </div>
        <div class="metric">
            <span class="metric-label">Improvement</span>
            <span class="metric-value {trend_class}">{trend_symbol} {abs(trend.improvement_rate):.1f}%</span>
        </div>
        <div class="metric">
            <span class="metric-label">Avg Score</span>
            <span class="metric-value">{trend.avg_score:.1f}</span>
        </div>
        """

    def _render_remediation_html(self, summary: RemediationSummary) -> str:
        """Render remediation summary section."""
        total = summary.total_items or 1
        resolved_pct = (summary.resolved_count / total) * 100

        return f"""
        <div class="metric">
            <span class="metric-label">Total Items</span>
            <span class="metric-value">{summary.total_items}</span>
        </div>
        <div class="metric">
            <span class="metric-label">Open</span>
            <span class="metric-value severity-high">{summary.open_count}</span>
        </div>
        <div class="metric">
            <span class="metric-label">In Progress</span>
            <span class="metric-value severity-medium">{summary.in_progress_count}</span>
        </div>
        <div class="metric">
            <span class="metric-label">Resolved</span>
            <span class="metric-value severity-low">{summary.resolved_count}</span>
        </div>
        <div class="metric">
            <span class="metric-label">Overdue</span>
            <span class="metric-value severity-critical">{summary.overdue_count}</span>
        </div>
        <div style="margin-top: 10px;">
            <span class="metric-label">Resolution Progress</span>
            <div class="progress-bar">
                <div class="progress-fill" style="width: {resolved_pct:.1f}%"></div>
            </div>
        </div>
        """

    def _render_worst_agents_html(self, agents: list[dict[str, Any]]) -> str:
        """Render worst agents section."""
        if not agents:
            return "<p>No agent data available</p>"

        rows = ""
        for agent in agents[:5]:
            risk = agent.get("risk_level", "unknown")
            risk_class = f"severity-{risk}"
            rows += f"""
            <tr>
                <td>{agent.get('agent_name', 'unknown')}</td>
                <td class="{risk_class}">{risk.upper()}</td>
                <td>{agent.get('security_score', 0)}</td>
            </tr>
            """

        return f"""
        <table>
            <thead>
                <tr><th>Agent</th><th>Risk</th><th>Score</th></tr>
            </thead>
            <tbody>{rows}</tbody>
        </table>
        """

    def _render_improved_agents_html(self, agents: list[dict[str, Any]]) -> str:
        """Render improved agents section."""
        if not agents:
            return "<p>No improvement data available</p>"

        rows = ""
        for agent in agents[:5]:
            improvement = agent.get("improvement_rate", 0)
            trend_class = "trend-up" if improvement > 0 else "trend-down"
            rows += f"""
            <tr>
                <td>{agent.get('agent_name', 'unknown')}</td>
                <td class="{trend_class}">{improvement:+.1f}%</td>
                <td>{agent.get('current_score', 0)}</td>
            </tr>
            """

        return f"""
        <table>
            <thead>
                <tr><th>Agent</th><th>Improvement</th><th>Score</th></tr>
            </thead>
            <tbody>{rows}</tbody>
        </table>
        """

    def _render_remediations_table_html(self, items: list[RemediationItem]) -> str:
        """Render remediations table."""
        if not items:
            return "<p>No open remediations</p>"

        rows = ""
        for item in items[:10]:
            severity_class = f"severity-{item.severity}"
            status_class = f"status-{item.status.value}"
            overdue = " [OVERDUE]" if item.is_overdue else ""
            rows += f"""
            <tr>
                <td class="{severity_class}">{item.severity.upper()}</td>
                <td>{item.title[:50]}</td>
                <td>{item.agent_name or '-'}</td>
                <td><span class="status-badge {status_class}">{item.status.value}</span>{overdue}</td>
                <td>{item.assignee or 'Unassigned'}</td>
                <td>{item.days_open}d</td>
            </tr>
            """

        return f"""
        <table>
            <thead>
                <tr><th>Severity</th><th>Title</th><th>Agent</th><th>Status</th><th>Assignee</th><th>Age</th></tr>
            </thead>
            <tbody>{rows}</tbody>
        </table>
        """

    def _render_scans_table_html(self, scans: list[ScanRecord]) -> str:
        """Render recent scans table."""
        if not scans:
            return "<p>No recent scans</p>"

        rows = ""
        for scan in scans[:10]:
            grade_class = f"score-{scan.atss_grade.lower()}"
            rows += f"""
            <tr>
                <td>{scan.timestamp[:16]}</td>
                <td><span class="score-badge {grade_class}">{scan.atss_grade}</span></td>
                <td>{scan.atss_score}</td>
                <td>{scan.total_findings}</td>
                <td class="severity-critical">{scan.critical_count}</td>
                <td class="severity-high">{scan.high_count}</td>
                <td>{scan.agents_detected}</td>
            </tr>
            """

        return f"""
        <table>
            <thead>
                <tr><th>Date</th><th>Grade</th><th>Score</th><th>Findings</th><th>Critical</th><th>High</th><th>Agents</th></tr>
            </thead>
            <tbody>{rows}</tbody>
        </table>
        """


def render_trends_chart(
    project_name: str | None = None,
    days: int = 30,
    db_path: str | None = None,
) -> str:
    """Render vulnerability trends chart.

    Args:
        project_name: Filter by project
        days: Number of days
        db_path: Optional database path

    Returns:
        ASCII chart string
    """
    renderer = DashboardRenderer(db_path)
    data = renderer.get_dashboard_data(project_name, days)

    if not data.vulnerability_trend:
        return "No trend data available"

    lines = ["Vulnerability Trend (Score over time):", ""]
    chart = renderer._render_ascii_chart(data.vulnerability_trend.score_trend, width=50, height=8)
    lines.extend(chart)

    return "\n".join(lines)


def render_score_history(
    agent_id: str,
    project_name: str,
    days: int = 30,
    db_path: str | None = None,
) -> str:
    """Render agent score history.

    Args:
        agent_id: Agent identifier
        project_name: Project name
        days: Number of days
        db_path: Optional database path

    Returns:
        ASCII chart string
    """
    tracker = AgentScoreTracker(db_path)
    history = tracker.get_agent_score_history(agent_id, project_name, days)

    if not history:
        return f"No history for agent {agent_id}"

    lines = [
        f"Score History: {history.agent_name}",
        f"Project: {project_name}",
        f"Current Score: {history.current_score}",
        f"Improvement: {history.improvement_rate:+.1f}%",
        "",
    ]

    renderer = DashboardRenderer()
    chart = renderer._render_ascii_chart(history.score_trend, width=40, height=5)
    lines.extend(chart)

    return "\n".join(lines)


def render_remediation_board(
    project_name: str | None = None,
    db_path: str | None = None,
) -> str:
    """Render remediation board.

    Args:
        project_name: Filter by project
        db_path: Optional database path

    Returns:
        Formatted string
    """
    tracker = RemediationTracker(db_path)
    summary = tracker.get_summary(project_name)
    items = tracker.get_open_items(project_name, limit=20)

    lines = [
        "=" * 60,
        f"  Remediation Board - {project_name or 'All Projects'}",
        "=" * 60,
        "",
        f"  Open: {summary.open_count}  |  In Progress: {summary.in_progress_count}  |  "
        f"Blocked: {summary.blocked_count}  |  Resolved: {summary.resolved_count}",
        f"  Overdue: {summary.overdue_count}  |  Avg Resolution: {summary.avg_resolution_days} days",
        "",
        "-" * 60,
    ]

    if items:
        for item in items:
            severity = item.severity[:4].upper()
            status = item.status.value[:10]
            title = item.title[:35]
            assignee = item.assignee[:10] if item.assignee else "Unassigned"
            overdue = " [!]" if item.is_overdue else ""
            lines.append(f"  [{severity}] {title:35} {status:10} {assignee}{overdue}")
    else:
        lines.append("  No open items")

    lines.append("-" * 60)
    return "\n".join(lines)
