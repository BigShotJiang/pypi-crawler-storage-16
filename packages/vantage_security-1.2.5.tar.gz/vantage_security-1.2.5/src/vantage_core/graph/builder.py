import ast
import networkx as nx
import uuid
from typing import Any, Optional

from vantage_core.graph.models import NodeType, EdgeType, GraphNode

class CPGBuilder:
    """Code Property Graph Builder.
    
    Transforms Python AST into a NetworkX graph combining AST, CFG, and DFG properties.
    """
    
    def __init__(self):
        self.graph = nx.DiGraph()
        self.current_scope: list[str] = [] # Stack of node IDs (Module, Class, Func)
    
    def build(self, source_code: str, file_path: str) -> nx.DiGraph:
        """Build CPG from source code."""
        tree = ast.parse(source_code, filename=file_path)
        self._visit(tree, file_path=file_path)
        return self.graph

    def _add_node(self, node_type: NodeType, ast_node: Any, **kwargs) -> str:
        """Add a node to the graph and return its ID."""
        node_id = str(uuid.uuid4())
        node = GraphNode(id=node_id, type=node_type, ast_node=ast_node, data=kwargs)
        self.graph.add_node(node_id, data=node)
        
        # Link to parent scope if exists
        if self.current_scope:
            parent_id = self.current_scope[-1]
            self.graph.add_edge(parent_id, node_id, type=EdgeType.CONTAINS)
            
        return node_id

    def _add_edge(self, source_id: str, target_id: str, edge_type: EdgeType):
        self.graph.add_edge(source_id, target_id, type=edge_type)

    def _visit(self, node: ast.AST, **kwargs):
        """Recursive visitor dispatch."""
        method_name = f"_visit_{node.__class__.__name__}"
        visitor = getattr(self, method_name, self._visit_generic)
        if method_name == "_visit_Module":
             return visitor(node, **kwargs)
        return visitor(node)

    def _visit_generic(self, node: ast.AST):
        """Default visitor for unhandled nodes."""
        for child in ast.iter_child_nodes(node):
            self._visit(child)

    def _visit_If(self, node: ast.If):
        if_id = self._add_node(NodeType.BLOCK, node, type="if")
        
        # Test condition
        test_id = self._visit(node.test)
        self.graph.add_edge(test_id, if_id, type=EdgeType.ARGUMENT, arg="condition")
        
        # True Branch
        last_true_id = if_id
        for stmt in node.body:
            stmt_id = self._visit(stmt)
            if stmt_id:
                self.graph.add_edge(last_true_id, stmt_id, type=EdgeType.CFG_NEXT, branch="true")
                last_true_id = stmt_id
                
        # False Branch
        last_false_id = if_id
        for stmt in node.orelse:
            stmt_id = self._visit(stmt)
            if stmt_id:
                self.graph.add_edge(last_false_id, stmt_id, type=EdgeType.CFG_NEXT, branch="false")
                last_false_id = stmt_id
                
        return if_id

    def _visit_Import(self, node: ast.Import):
        for alias in node.names:
            node_id = self._add_node(NodeType.IMPORT, node, 
                                     module=alias.name, 
                                     alias=alias.asname or alias.name)
            
    def _visit_ImportFrom(self, node: ast.ImportFrom):
        module = node.module or ""
        for alias in node.names:
             node_id = self._add_node(NodeType.IMPORT, node,
                                      module=module,
                                      name=alias.name,
                                      alias=alias.asname or alias.name)

    def _visit_Module(self, node: ast.Module, file_path: str = ""):
        module_id = self._add_node(NodeType.MODULE, node, name="module", file_path=file_path)
        self.current_scope.append(module_id)
        
        # Process body
        last_stmt_id = None
        for stmt in node.body:
            stmt_id = self._visit(stmt)
            if stmt_id:
                if last_stmt_id:
                    self._add_edge(last_stmt_id, stmt_id, EdgeType.NEXT)
                last_stmt_id = stmt_id
                
        self.current_scope.pop()
        return module_id

    def _visit_ClassDef(self, node: ast.ClassDef):
        class_id = self._add_node(NodeType.CLASS, node, name=node.name)
        self.current_scope.append(class_id)
        
        # Process body
        for stmt in node.body:
            self._visit(stmt)
            
        self.current_scope.pop()
        return class_id

    def _visit_FunctionDef(self, node: ast.FunctionDef):
        func_id = self._add_node(NodeType.FUNCTION, node, name=node.name)
        
        # Process decorators (important for @agent)
        for deco in node.decorator_list:
            if isinstance(deco, ast.Name):
                self.graph.nodes[func_id]['data'].data.setdefault('decorators', []).append(deco.id)
            elif isinstance(deco, ast.Call):
                name = self._get_call_name(deco)
                self.graph.nodes[func_id]['data'].data.setdefault('decorators', []).append(name)

        self.current_scope.append(func_id)
        
        for stmt in node.body:
            self._visit(stmt)
            
        self.current_scope.pop()
        return func_id

    def _visit_Assign(self, node: ast.Assign):
        """Handle assignments: x = Call(...)"""
        # 1. Process Value (RHS)
        value_id = self._visit(node.value)
        
        # 2. Process Targets (LHS)
        for target in node.targets:
            if isinstance(target, ast.Name):
                target_id = self._add_node(NodeType.VARIABLE, target, name=target.id)
                
                # DATA FLOW: Value -> Variable
                if value_id:
                    self._add_edge(value_id, target_id, EdgeType.FLOWS_TO)
                    self._add_edge(target_id, value_id, EdgeType.DEFINES)
                    
        return value_id # Treat assignment statement ID as the value ID for simplicity in flow

    def _visit_Call(self, node: ast.Call):
        call_name = self._get_call_name(node)
        call_id = self._add_node(NodeType.CALL, node, name=call_name)
        
        # Handle method calls: obj.method()
        if isinstance(node.func, ast.Attribute):
            receiver_id = self._visit(node.func.value)
            if receiver_id:
                self.graph.add_edge(receiver_id, call_id, type=EdgeType.RECEIVER)
        
        # Process arguments
        for keyword in node.keywords:
            arg_val_id = self._visit(keyword.value)
            if arg_val_id:
                # Edge: Argument Value -> Call
                # We tag the edge with the argument name
                self.graph.add_edge(arg_val_id, call_id, type=EdgeType.ARGUMENT, arg=keyword.arg)
        
        # Positional args (simplified)
        for arg in node.args:
            arg_val_id = self._visit(arg)
            if arg_val_id:
                self.graph.add_edge(arg_val_id, call_id, type=EdgeType.ARGUMENT, arg="_pos_")

        return call_id

    def _visit_Name(self, node: ast.Name):
        # Variable usage
        node_id = self._add_node(NodeType.VARIABLE, node, name=node.id)
        return node_id
    
    def _visit_Attribute(self, node: ast.Attribute):
        # Attribute access like self.llm
        # We try to resolve the full name "self.llm"
        full_name = self._get_attribute_name(node)
        node_id = self._add_node(NodeType.VARIABLE, node, name=full_name)
        return node_id

    def _visit_Subscript(self, node: ast.Subscript):
        # Capture subscript access (e.g. config['agent'])
        # Simplified: just represent as an expression
        node_id = self._add_node(NodeType.EXPRESSION, node, type="subscript")
        
        # Visit value (the object being sliced)
        val_id = self._visit(node.value)
        if val_id:
            self._add_edge(val_id, node_id, EdgeType.FLOWS_TO) # Flow from object to access
            
        # Visit slice (index)
        if hasattr(node, 'slice'):
             slice_id = self._visit(node.slice)
             if slice_id:
                 self._add_edge(slice_id, node_id, EdgeType.ARGUMENT)
             
        return node_id

    def _visit_BinOp(self, node: ast.BinOp):
        """Handle binary operations (e.g. | for chains)."""
        op_name = node.op.__class__.__name__
        node_id = self._add_node(NodeType.BINOP, node, op=op_name)
        
        left_id = self._visit(node.left)
        right_id = self._visit(node.right)
        
        if left_id:
            self.graph.add_edge(left_id, node_id, type=EdgeType.OPERAND, position="left")
        if right_id:
            self.graph.add_edge(right_id, node_id, type=EdgeType.OPERAND, position="right")
            
        # For LangChain: | implies data flow from left to right
        if isinstance(node.op, ast.BitOr) and left_id and right_id:
            self.graph.add_edge(left_id, right_id, type=EdgeType.FLOWS_TO)
            
        return node_id

    def _visit_Constant(self, node: ast.Constant):
        return self._add_node(NodeType.LITERAL, node, value=node.value)
    
    def _visit_Dict(self, node: ast.Dict):
        # Handle dicts for config resolution
        dict_id = self._add_node(NodeType.EXPRESSION, node, type="dict")
        # Simplified: just visit children
        return dict_id
        
    def _get_call_name(self, node: ast.Call) -> str:
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            return self._get_attribute_name(node.func)
        return "unknown"

    def _get_attribute_name(self, node: Any) -> str:
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            return f"{self._get_attribute_name(node.value)}.{node.attr}"
        return ""
