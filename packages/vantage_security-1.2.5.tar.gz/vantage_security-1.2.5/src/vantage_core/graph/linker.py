from dataclasses import dataclass, field
from typing import Optional

@dataclass
class SymbolDefinition:
    name: str
    file_path: str
    node_id: str
    type: str  # "class", "function", "variable"

@dataclass
class ImportReference:
    name: str
    file_path: str
    node_id: str
    module_name: str # "vantage_core.graph"
    imported_name: str # "CPGBuilder" (or "*" or alias)

class GlobalSymbolTable:
    def __init__(self):
        # Map module_path -> symbol_name -> Definition
        self.definitions: dict[str, dict[str, SymbolDefinition]] = {}
        self.imports: list[ImportReference] = []

    def add_definition(self, module: str, name: str, defn: SymbolDefinition):
        if module not in self.definitions:
            self.definitions[module] = {}
        self.definitions[module][name] = defn

    def add_import(self, ref: ImportReference):
        self.imports.append(ref)

    def resolve(self, module: str, name: str) -> Optional[SymbolDefinition]:
        if module in self.definitions:
            return self.definitions[module].get(name)
        return None

class GraphLinker:
    def __init__(self, graph):
        self.graph = graph
        self.symbol_table = GlobalSymbolTable()

    def index_graph(self):
        """Pass 1: Index all exports (classes, functions, variables) in the graph."""
        from vantage_core.graph.models import NodeType
        
        # 1. Map nodes to their files
        file_map = {}
        for n_id, data in self.graph.nodes(data=True):
            node = data.get('data')
            if node and node.type == NodeType.MODULE:
                file_map[n_id] = node.data.get('file_path')

        # 2. Iterate nodes to find exports and imports
        for n_id, data in self.graph.nodes(data=True):
            node = data.get('data')
            if not node: continue
            
            # Find definitions (Top-level classes/functions)
            if node.type in (NodeType.CLASS, NodeType.FUNCTION):
                # Check if parent is a module
                in_edges = self.graph.in_edges(n_id, data=True)
                for src, dst, e_data in in_edges:
                    if e_data.get('type').name == "CONTAINS":
                        parent = self.graph.nodes[src]['data']
                        if parent.type == NodeType.MODULE:
                            file_path = parent.data.get('file_path')
                            name = node.data.get('name')
                            if file_path and name:
                                self.symbol_table.add_definition(
                                    file_path, # Use file path as module key for simplicity
                                    name,
                                    SymbolDefinition(name, file_path, n_id, node.type.name)
                                )
                                # Mark node as EXPORT
                                node.type = NodeType.EXPORT 
                                # (Or add a tag/label, but modifying type is quick hack for now)

            # Find Imports
            if node.type == NodeType.IMPORT:
                # Find the module node containing this import
                # (Need to traverse up CONTAINS)
                # ... skipping robust traversal for brevity, assuming standard structure
                
                module_name = node.data.get('module')
                imported_name = node.data.get('name') # for "from X import Y"
                alias = node.data.get('alias')
                
                if module_name:
                    self.symbol_table.add_import(ImportReference(
                        name=alias or imported_name or module_name,
                        file_path="TODO", # Need to fetch from parent module
                        node_id=n_id,
                        module_name=module_name,
                        imported_name=imported_name
                    ))

    def link(self):
        """Pass 2: Connect IMPORTS to DEFINITIONS."""
        from vantage_core.graph.models import EdgeType
        
        for imp in self.symbol_table.imports:
            # Try to resolve import
            # 1. Resolve module path (Mapping import string "vantage.core" to file path)
            # This is HARD in static analysis without running python.
            # Heuristic: Suffix match
            
            target_def = None
            
            # Iterate all known modules (files)
            for file_path, defs in self.symbol_table.definitions.items():
                # Check if file_path matches module_name
                # e.g. module="vantage_core.graph", file="/.../vantage_core/graph.py"
                
                # Normalize paths for comparison
                normalized_mod = imp.module_name.replace(".", "/")
                if normalized_mod in file_path:
                    # Found the module file, now look for symbol
                    if imp.imported_name in defs:
                        target_def = defs[imp.imported_name]
                        break
            
            if target_def:
                # Add Cross-File Edge
                self.graph.add_edge(imp.node_id, target_def.node_id, type=EdgeType.LINKS_TO)
                # print(f"LINKED: {imp.module_name}.{imp.imported_name} -> {target_def.file_path}")
