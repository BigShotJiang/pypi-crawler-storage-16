from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Any, Optional

class NodeType(Enum):
    MODULE = auto()
    CLASS = auto()
    FUNCTION = auto()
    BLOCK = auto()
    STATEMENT = auto()
    EXPRESSION = auto()
    VARIABLE = auto()
    CALL = auto()
    LITERAL = auto()
    ARGUMENT = auto()
    BINOP = auto()
    IMPORT = auto()
    EXPORT = auto()

class EdgeType(Enum):
    CONTAINS = auto()        # AST hierarchy: Class -> Method
    NEXT = auto()            # Control Flow: Stmt A -> Stmt B
    DEFINES = auto()         # Variable Definition: x = 1 -> x
    USES = auto()            # Variable Usage: print(x) -> x
    CALLS = auto()           # Function Call: func() -> func
    ARGUMENT = auto()        # Argument: func(arg=val) -> val
    RETURNS = auto()         # Return: return x -> x
    FLOWS_TO = auto()        # Data Flow: Val -> Var
    RECEIVER = auto()        # Method call receiver: obj.method() -> obj
    OPERAND = auto()         # Binary Op operand: a | b -> a, b
    LINKS_TO = auto()        # Cross-file link: Import -> Export
    CFG_NEXT = auto()        # Control Flow: Stmt A -> Stmt B
    FLOWS_WITH_CONDITION = auto() # Data flow conditional on branch

@dataclass
class GraphNode:
    id: str
    type: NodeType
    ast_node: Any  # The original AST node
    data: dict[str, Any] = field(default_factory=dict)
    
    def __hash__(self):
        return hash(self.id)
