import networkx as nx
from typing import Optional, Any
from vantage_core.graph.models import NodeType, EdgeType, GraphNode

class CPGQuery:
    def __init__(self, graph: nx.DiGraph):
        self.graph = graph

    def find_nodes_by_type(self, node_type: NodeType) -> list[tuple[str, GraphNode]]:
        """Find all nodes of a specific type."""
        results = []
        for n_id, data in self.graph.nodes(data=True):
            node = data.get('data')
            if node and node.type == node_type:
                results.append((n_id, node))
        return results

    def find_calls_by_name(self, name: str) -> list[tuple[str, GraphNode]]:
        """Find all calls to a specific function name."""
        calls = self.find_nodes_by_type(NodeType.CALL)
        return [(n_id, node) for n_id, node in calls if node.data.get('name') == name]
    
    def find_methods_with_decorator(self, decorator_name: str) -> list[tuple[str, GraphNode]]:
        """Find functions decorated with a specific decorator."""
        funcs = self.find_nodes_by_type(NodeType.FUNCTION)
        results = []
        for n_id, node in funcs:
            decos = node.data.get('decorators', [])
            if decorator_name in decos:
                results.append((n_id, node))
        return results

    def is_ancestor(self, ancestor_id: str, node_id: str) -> bool:
        """Check if ancestor_id contains node_id (direct or indirect)."""
        # Traverse up from node_id looking for ancestor_id
        current = node_id
        visited = {current}
        while True:
            preds = list(self.graph.predecessors(current))
            found_parent = False
            for p_id in preds:
                edge_data = self.graph.get_edge_data(p_id, current)
                if edge_data.get('type') == EdgeType.CONTAINS:
                    if p_id == ancestor_id:
                        return True
                    if p_id not in visited:
                        visited.add(p_id)
                        current = p_id
                        found_parent = True
                    break
            if not found_parent:
                return False

    def resolve_argument(self, call_id: str, arg_name: str) -> Optional[Any]:
        """Resolve the value of an argument passed to a call.
        
        Traces back FLOWS_TO edges to find the origin.
        """
        # 1. Find the argument node connected to the call
        # Edge direction: ArgVal -> Call
        in_edges = self.graph.in_edges(call_id, data=True)
        
        arg_val_id = None
        for src, dst, data in in_edges:
            if data.get('type') == EdgeType.ARGUMENT and data.get('arg') == arg_name:
                arg_val_id = src
                break
        
        if not arg_val_id:
            return None
            
        # 2. Inspect the argument value node
        node_data = self.graph.nodes[arg_val_id]['data']
        node: GraphNode = node_data
        
        # If it's a Literal, return value
        if node.type == NodeType.LITERAL:
            return node.data.get('value')
            
        # If it's a Variable, trace back to definition
        if node.type == NodeType.VARIABLE:
            return self._trace_variable_definition(arg_val_id, node.data.get('name'))
            
        # If it's an Expression (e.g. Subscript)
        if node.type == NodeType.EXPRESSION:
            return {"type": "expression", "expr_type": node.data.get('type')}
            
        return None

    def _trace_variable_definition(self, var_node_id: str, var_name: str) -> Optional[Any]:
        """Trace a variable back to its definition (Simplified Data Flow)."""
        # 1. Check direct local flow (if explicitly linked)
        in_edges = self.graph.in_edges(var_node_id, data=True)
        for src, dst, data in in_edges:
            if data.get('type') == EdgeType.FLOWS_TO:
                src_node = self.graph.nodes[src]['data']
                if src_node.type == NodeType.CALL:
                    return {"type": "call", "name": src_node.data.get('name')}
                if src_node.type == NodeType.LITERAL:
                    return src_node.data.get('value')

        # 2. Search global graph for definition of this variable
        # (Heuristic: Find any variable node with same name that has a value flowing into it)
        # TODO: Implement proper scoping (only check variables in same or parent scope)
        candidates = []
        for n_id, data in self.graph.nodes(data=True):
            node = data.get('data')
            if node and node.type == NodeType.VARIABLE and node.data.get('name') == var_name:
                # Check if this node has an incoming value
                for src, dst, e_data in self.graph.in_edges(n_id, data=True):
                    if e_data.get('type') == EdgeType.FLOWS_TO:
                        candidates.append(src)
        
        # If multiple candidates, pick one (ideally based on proximity/scope)
        if candidates:
            # Pick first for now
            src_node = self.graph.nodes[candidates[0]]['data']
            if src_node.type == NodeType.CALL:
                return {"type": "call", "name": src_node.data.get('name')}
            if src_node.type == NodeType.LITERAL:
                return src_node.data.get('value')
                
        if var_name.startswith("self."):
            return self._find_class_member_definition(var_node_id, var_name)
            
        return None

    def resolve_receiver(self, call_id: str) -> Optional[Any]:
        """Resolve the receiver object of a method call."""
        in_edges = self.graph.in_edges(call_id, data=True)
        for src, dst, data in in_edges:
            if data.get('type') == EdgeType.RECEIVER:
                node = self.graph.nodes[src]['data']
                if node.type == NodeType.VARIABLE:
                    return self._trace_variable_definition(src, node.data.get('name'))
                if node.type == NodeType.CALL:
                    return {"type": "call", "name": node.data.get('name')}
        return None

    def find_chains(self) -> list[tuple[str, str]]:
        """Find LangChain-style chains (BitOr operations)."""
        chains = []
        binops = self.find_nodes_by_type(NodeType.BINOP)
        for n_id, node in binops:
            if node.data.get('op') == "BitOr":
                # Get left and right
                left_id = None
                right_id = None
                in_edges = self.graph.in_edges(n_id, data=True)
                for src, dst, data in in_edges:
                    if data.get('type') == EdgeType.OPERAND:
                        if data.get('position') == "left":
                            left_id = src
                        elif data.get('position') == "right":
                            right_id = src
                
                if left_id and right_id:
                    # Resolve names if possible
                    left_name = self._resolve_node_name(left_id)
                    right_name = self._resolve_node_name(right_id)
                    if left_name and right_name:
                        chains.append((left_name, right_name))
        return chains

    def _resolve_node_name(self, node_id: str) -> Optional[str]:
        """Helper to get a human-readable name for a node."""
        node = self.graph.nodes[node_id]['data']
        if node.type == NodeType.VARIABLE:
            return node.data.get('name')
        if node.type == NodeType.CALL:
            return node.data.get('name')
        if node.type == NodeType.LITERAL:
            return str(node.data.get('value'))
        return None

    def _find_class_member_definition(self, context_node_id: str, member_name: str) -> Optional[Any]:
        """Find definition of self.x in the enclosing class."""
        # 1. Find enclosing class
        # Traverse incoming CONTAINS edges up
        current_id = context_node_id
        class_id = None
        
        # Basic parent lookup (this is expensive in large graphs, but ok here)
        # Note: In NetworkX, CONTAINS is directed Parent -> Child. 
        # So we need to look for predecessors with CONTAINS edge.
        
        # We need to walk up until we find a CLASS node.
        # Since we didn't store parent pointers explicitly in Builder efficiently for lookup,
        # we scan logical structure. 
        # Actually, in _add_node we did: parent -> node (CONTAINS).
        # So we look at in_edges.
        
        while True:
            preds = list(self.graph.predecessors(current_id))
            parent_found = False
            for p_id in preds:
                edge_data = self.graph.get_edge_data(p_id, current_id)
                if edge_data.get('type') == EdgeType.CONTAINS:
                    node = self.graph.nodes[p_id]['data']
                    if node.type == NodeType.CLASS:
                        class_id = p_id
                        break # Found class
                    current_id = p_id
                    parent_found = True
                    break
            
            if class_id or not parent_found:
                break
                
        if not class_id:
            return None
            
        # Strip self. prefix
        if member_name.startswith("self."):
            member_name = member_name.split(".", 1)[1]

        # 2. Search class body for assignment to member_name
        # Find all Variable nodes contained in Class that match name
        # And are targets of assignment (DEFINES edge from them?)
        # Wait, in builder: Value -> Variable (DEFINES edge is Variable -> Value? No, target -> value)
        # Builder: self._add_edge(target_id, value_id, EdgeType.DEFINES)
        
        # We want to find a Variable node 'v' where:
        # v is inside Class (recursively? or just direct child? Assignments are usually in methods)
        # v.name == member_name
        # v has an outgoing DEFINES edge to some Value 'val'
        
        # This is a global graph search, simplified:
        
        for n_id, data in self.graph.nodes(data=True):
            node = data.get('data')
            if node and node.type == NodeType.VARIABLE and node.data.get('name') == member_name:
                # Check if this variable defines something
                # We need to check if this variable is "defined" here. 
                # In builder: Value -> Variable (FLOWS_TO).
                # So we look for incoming FLOWS_TO.
                
                # Check value
                in_edges = self.graph.in_edges(n_id, data=True)
                for src, dst, e_data in in_edges:
                    if e_data.get('type') == EdgeType.FLOWS_TO:
                        src_node = self.graph.nodes[src]['data']
                        
                        # Verify this variable is inside our class
                        # (Skipping robust containment check for prototype speed, assuming name uniqueness roughly or taking first match)
                        
                        if src_node.type == NodeType.CALL:
                            return {"type": "call", "name": src_node.data.get('name'), "args": self._get_call_args(src)}
                        
        return None

    def _get_call_args(self, call_id: str) -> dict:
        """Extract arguments for a call node."""
        args = {}
        in_edges = self.graph.in_edges(call_id, data=True)
        for src, dst, data in in_edges:
            if data.get('type') == EdgeType.ARGUMENT:
                arg_name = data.get('arg')
                val_node = self.graph.nodes[src]['data']
                if val_node.type == NodeType.LITERAL:
                    args[arg_name] = val_node.data.get('value')
        return args
