import array
from enum import IntEnum, auto
from typing import Any, Optional, Dict, List, Tuple

# Maps for string interning to save memory
_STRING_POOL: Dict[str, int] = {}
_ID_POOL: List[str] = []

def intern_string(s: str) -> int:
    if s not in _STRING_POOL:
        idx = len(_ID_POOL)
        _STRING_POOL[s] = idx
        _ID_POOL.append(s)
    return _STRING_POOL[s]

def get_string(idx: int) -> str:
    return _ID_POOL[idx]

class NodeType(IntEnum):
    UNKNOWN = 0
    MODULE = 1
    CLASS = 2
    FUNCTION = 3
    VARIABLE = 4
    CALL = 5
    LITERAL = 6
    BLOCK = 7
    IMPORT = 8
    EXPORT = 9
    ARGUMENT = 10

class EdgeType(IntEnum):
    AST_CHILD = 0
    CFG_NEXT = 1
    DATA_FLOW = 2
    CALLS = 3
    REFERS_TO = 4
    DEFINES = 5

class FastGraph:
    """A high-performance integer-based graph store."""
    
    def __init__(self):
        # Node storage
        self.node_count = 0
        self.node_types = array.array('B') # Byte array for types
        self.node_attrs: Dict[int, Dict[str, Any]] = {} # Sparse storage for attributes
        
        # Edge storage (Adjacency List)
        # outgoing_edges[src_id] = [(dst_id, type), ...]
        self.outgoing_edges: List[List[Tuple[int, int]]] = []
        self.incoming_edges: List[List[Tuple[int, int]]] = []

    def add_node(self, type_id: int, attrs: Optional[Dict[str, Any]] = None) -> int:
        nid = self.node_count
        self.node_count += 1
        self.node_types.append(type_id)
        self.outgoing_edges.append([])
        self.incoming_edges.append([])
        
        if attrs:
            self.node_attrs[nid] = attrs
            
        return nid

    def add_edge(self, src: int, dst: int, type_id: int):
        self.outgoing_edges[src].append((dst, type_id))
        self.incoming_edges[dst].append((src, type_id))

    def get_node_type(self, nid: int) -> int:
        return self.node_types[nid]

    def get_attr(self, nid: int, key: str) -> Any:
        return self.node_attrs.get(nid, {}).get(key)
        
    def out_edges(self, nid: int) -> List[Tuple[int, int]]:
        return self.outgoing_edges[nid]
        
    def in_edges(self, nid: int) -> List[Tuple[int, int]]:
        return self.incoming_edges[nid]
