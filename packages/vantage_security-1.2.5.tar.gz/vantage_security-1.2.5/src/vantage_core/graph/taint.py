from typing import Any, Optional
import networkx as nx
from vantage_core.graph.models import NodeType, EdgeType

class TaintTrackingEngine:
    def __init__(self, graph: nx.DiGraph):
        self.graph = graph
        self.sources = {
            "input", "request.args", "request.form", "sys.argv", 
            "argparse", "os.environ"
        }
        self.sinks = {
            "os.system", "subprocess.call", "subprocess.Popen", 
            "eval", "exec", "pickle.loads", "yaml.unsafe_load"
        }

    def find_vulnerabilities(self) -> list[dict]:
        """Find paths from Sources to Sinks."""
        vulns = []
        
        # 1. Locate Source Nodes
        source_nodes = []
        for n_id, data in self.graph.nodes(data=True):
            node = data.get('data')
            if node and node.type == NodeType.CALL:
                if node.data.get('name') in self.sources:
                    source_nodes.append(n_id)
            elif node and node.type == NodeType.VARIABLE:
                # Heuristic: variable names indicating user input
                if "user_input" in node.data.get('name', "").lower():
                    source_nodes.append(n_id)

        # 2. Locate Sink Nodes
        sink_nodes = []
        for n_id, data in self.graph.nodes(data=True):
            node = data.get('data')
            if node and node.type == NodeType.CALL:
                if node.data.get('name') in self.sinks:
                    sink_nodes.append(n_id)

        # 3. Path Finding (Data Flow)
        for source in source_nodes:
            for sink in sink_nodes:
                if nx.has_path(self.graph, source, sink):
                    # Check if path follows FLOWS_TO edges
                    try:
                        path = nx.shortest_path(self.graph, source, sink)
                        if self._validate_flow_path(path):
                             # Determine Source Name (Function Call Name preferably)
                             source_node = self.graph.nodes[source]['data']
                             source_name = source_node.data.get('name')
                             
                             # If source was detected via variable heuristic (e.g. user_input),
                             # try to find the defining call (e.g. input())
                             if source_node.type == NodeType.VARIABLE:
                                 # Heuristic: Find any node with same name that is defined by a known source call
                                 var_name = source_node.data.get('name')
                                 found_def = False
                                 
                                 # Search all nodes for this variable name
                                 for n_id, data in self.graph.nodes(data=True):
                                     node = data.get('data')
                                     if node and node.type == NodeType.VARIABLE and node.data.get('name') == var_name:
                                         # Check definition
                                         # In Assign: Call -> Variable (FLOWS_TO)
                                         in_edges = self.graph.in_edges(n_id, data=True)
                                         for src, dst, e_data in in_edges:
                                             if e_data.get('type') == EdgeType.FLOWS_TO:
                                                  def_node = self.graph.nodes[src]['data']
                                                  if def_node.type == NodeType.CALL:
                                                      call_name = def_node.data.get('name')
                                                      if call_name in self.sources:
                                                          source_name = call_name
                                                          found_def = True
                                                          break
                                     if found_def: break


                             vulns.append({
                                 "type": "TaintFlow",
                                 "source": source_name,
                                 "sink": self.graph.nodes[sink]['data'].data.get('name'),
                                 "path_length": len(path)
                             })
                    except nx.NetworkXNoPath:
                        continue
                        
        return vulns

    def _validate_flow_path(self, path: list[str]) -> bool:
        """Verify that a path follows valid Data Flow edges."""
        for i in range(len(path) - 1):
            u, v = path[i], path[i+1]
            edge_data = self.graph.get_edge_data(u, v)
            etype = edge_data.get('type')
            
            # Valid flow transitions
            if etype in (EdgeType.FLOWS_TO, EdgeType.DEFINES, EdgeType.ARGUMENT, EdgeType.LINKS_TO):
                continue
            
            # TODO: Handle CFG dependencies (Implicit Flow)
            
            return False
        return True
