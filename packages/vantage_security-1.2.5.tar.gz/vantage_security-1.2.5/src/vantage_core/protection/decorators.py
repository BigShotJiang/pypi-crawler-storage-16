"""
Framework-Native Security Decorators.

Provides simple, one-line decorators to add security to agent functions.
Works with LangChain, CrewAI, AutoGen, and generic Python functions.

Usage:
    from vantage_core.protection import secure, protect

    # Simple decorator
    @secure
    def my_agent(user_input: str) -> str:
        return agent.run(user_input)

    # With options
    @protect(
        isolate_secrets=True,
        harden_prompt=True,
        filter_input=True,
    )
    def my_langchain_agent(user_input: str) -> str:
        return chain.invoke(user_input)
"""

import functools
import logging
import re
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, TypeVar

from vantage_core.protection.hardening import (
    Framework,
    HardeningLevel,
)

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


@dataclass
class ProtectionConfig:
    """Configuration for the @protect decorator."""

    isolate_secrets: bool = True
    harden_prompt: bool = True
    filter_input: bool = True
    filter_output: bool = True
    block_injection: bool = True
    log_suspicious: bool = True
    framework: Framework = Framework.GENERIC
    hardening_level: HardeningLevel = HardeningLevel.STANDARD
    secrets: list[str] = field(default_factory=list)
    blocked_patterns: list[str] = field(default_factory=list)
    max_input_length: int = 10000
    rate_limit_per_minute: int = 0  # 0 = no limit


@dataclass
class ProtectionResult:
    """Result of protection processing."""

    allowed: bool
    filtered_input: str | None = None
    filtered_output: str | None = None
    blocked_reason: str | None = None
    warnings: list[str] = field(default_factory=list)
    processing_time_ms: float = 0


class InputFilter:
    """Filters potentially malicious input."""

    # Dangerous patterns that indicate injection attempts
    INJECTION_PATTERNS = [
        # Direct instruction override
        r"(?i)ignore\s+(all\s+)?(previous|prior|above)\s+(instructions?|rules?)",
        r"(?i)disregard\s+(all\s+)?(previous|prior|above)",
        r"(?i)forget\s+(everything|all)\s+(you\s+)?(know|learned)",
        r"(?i)new\s+instructions?:",
        r"(?i)override\s+(instructions?|rules?|settings?)",
        # Jailbreak attempts
        r"(?i)\bdan\b.*mode",
        r"(?i)developer\s+mode",
        r"(?i)jailbreak",
        r"(?i)unrestricted\s+mode",
        r"(?i)evil\s+mode",
        r"(?i)bypass\s+(security|filter|restriction)",
        # Prompt extraction
        r"(?i)what\s+(are|is)\s+your\s+(system\s+)?prompt",
        r"(?i)show\s+(me\s+)?your\s+(system\s+)?instructions?",
        r"(?i)reveal\s+(your\s+)?(hidden\s+)?instructions?",
        r"(?i)print\s+(your\s+)?system\s+(prompt|message)",
        # Role manipulation
        r"(?i)pretend\s+(to\s+be|you\s+are)",
        r"(?i)act\s+as\s+(if\s+)?(you\s+are|a)",
        r"(?i)roleplay\s+as",
        r"(?i)you\s+are\s+now\s+(a|an)",
        # Encoding tricks
        r"(?i)base64[:\s]+",
        r"(?i)decode\s+(this|the\s+following)",
        r"(?i)in\s+hex[:\s]",
        # Multi-turn manipulation
        r"(?i)in\s+our\s+previous\s+conversation",
        r"(?i)as\s+we\s+discussed\s+(earlier|before)",
        r"(?i)remember\s+when\s+you\s+(said|told)",
        # Tool abuse
        r"(?i)execute\s+(this\s+)?(code|command|script)",
        r"(?i)run\s+(this\s+)?(shell|bash|python)",
        r"(?i)call\s+(the\s+)?function",
    ]

    # Unicode control characters that could be used for attacks
    SUSPICIOUS_UNICODE = [
        "\u200b",  # Zero-width space
        "\u200c",  # Zero-width non-joiner
        "\u200d",  # Zero-width joiner
        "\u2060",  # Word joiner
        "\u2062",  # Invisible times
        "\u2063",  # Invisible separator
        "\u2064",  # Invisible plus
        "\ufeff",  # Zero-width no-break space (BOM)
        "\u00ad",  # Soft hyphen
    ]

    # Unicode tag range (used in some attacks)
    UNICODE_TAG_RANGE = range(0xE0000, 0xE007F + 1)

    def __init__(self, config: ProtectionConfig):
        """Initialize the filter."""
        self.config = config
        self._compiled_patterns = [re.compile(p) for p in self.INJECTION_PATTERNS]
        # Add custom blocked patterns
        for pattern in config.blocked_patterns:
            try:
                self._compiled_patterns.append(re.compile(pattern, re.IGNORECASE))
            except re.error as e:
                logger.warning(f"Invalid blocked pattern '{pattern}': {e}")

    def filter(self, text: str) -> ProtectionResult:
        """
        Filter input text for potential attacks.

        Args:
            text: Input text to filter

        Returns:
            ProtectionResult with filtered text or block reason
        """
        start_time = time.time()
        warnings: list[str] = []

        # Check length
        if len(text) > self.config.max_input_length:
            return ProtectionResult(
                allowed=False,
                blocked_reason=f"Input exceeds maximum length ({len(text)} > {self.config.max_input_length})",
                processing_time_ms=(time.time() - start_time) * 1000,
            )

        # Check for injection patterns
        if self.config.block_injection:
            for pattern in self._compiled_patterns:
                match = pattern.search(text)
                if match:
                    if self.config.log_suspicious:
                        logger.warning(f"Blocked injection attempt: '{match.group()[:50]}...'")
                    return ProtectionResult(
                        allowed=False,
                        blocked_reason="Potential injection attempt detected",
                        processing_time_ms=(time.time() - start_time) * 1000,
                    )

        # Check for suspicious Unicode
        filtered_text = text
        for char in self.SUSPICIOUS_UNICODE:
            if char in text:
                warnings.append(f"Removed suspicious Unicode character: U+{ord(char):04X}")
                filtered_text = filtered_text.replace(char, "")

        # Remove Unicode tag characters
        result_chars = []
        for char in filtered_text:
            if ord(char) not in self.UNICODE_TAG_RANGE:
                result_chars.append(char)
            else:
                warnings.append(f"Removed Unicode tag: U+{ord(char):04X}")
        filtered_text = "".join(result_chars)

        # Check for encoded content that might hide attacks
        encoded_patterns = [
            (r"[A-Za-z0-9+/]{50,}={0,2}", "Potential base64 encoded content"),
            (r"(?:\\x[0-9a-fA-F]{2}){10,}", "Hex-encoded content"),
        ]
        for pattern, description in encoded_patterns:
            if re.search(pattern, filtered_text):
                warnings.append(description)

        return ProtectionResult(
            allowed=True,
            filtered_input=filtered_text,
            warnings=warnings,
            processing_time_ms=(time.time() - start_time) * 1000,
        )


class OutputFilter:
    """Filters output to prevent secret leakage."""

    def __init__(self, config: ProtectionConfig):
        """Initialize the filter."""
        self.config = config
        self._secrets_patterns: list[tuple[re.Pattern, str]] = []

        # Add explicit secrets
        for secret in config.secrets:
            if len(secret) >= 4:  # Only match meaningful secrets
                escaped = re.escape(secret)
                self._secrets_patterns.append((re.compile(escaped, re.IGNORECASE), "[REDACTED]"))

        # Add common secret patterns
        self._secrets_patterns.extend(
            [
                (re.compile(r"sk-[a-zA-Z0-9]{32,}"), "[REDACTED_API_KEY]"),
                (
                    re.compile(r'(?i)api[_-]?key["\'\s:=]+[a-zA-Z0-9_\-]{20,}'),
                    "api_key=[REDACTED]",
                ),
                (
                    re.compile(r'(?i)password["\'\s:=]+[^\s"\']{8,}'),
                    "password=[REDACTED]",
                ),
                (re.compile(r'(?i)secret["\'\s:=]+[^\s"\']{8,}'), "secret=[REDACTED]"),
                (
                    re.compile(r'(?i)token["\'\s:=]+[a-zA-Z0-9_\-]{20,}'),
                    "token=[REDACTED]",
                ),
                (
                    re.compile(r'(?:postgres|mysql|mongodb)://[^\s"\']+'),
                    "[REDACTED_DB_URL]",
                ),
                (
                    re.compile(r"-----BEGIN [A-Z ]+ PRIVATE KEY-----"),
                    "[REDACTED_PRIVATE_KEY]",
                ),
            ]
        )

    def filter(self, text: str) -> ProtectionResult:
        """
        Filter output text to prevent secret leakage.

        Args:
            text: Output text to filter

        Returns:
            ProtectionResult with filtered text
        """
        start_time = time.time()
        warnings: list[str] = []
        filtered = text

        for pattern, replacement in self._secrets_patterns:
            matches = pattern.findall(filtered)
            if matches:
                warnings.append(f"Redacted {len(matches)} potential secret(s)")
                filtered = pattern.sub(replacement, filtered)

        return ProtectionResult(
            allowed=True,
            filtered_output=filtered,
            warnings=warnings,
            processing_time_ms=(time.time() - start_time) * 1000,
        )


class RateLimiter:
    """Simple rate limiter for protection."""

    def __init__(self, max_per_minute: int):
        """Initialize rate limiter."""
        self.max_per_minute = max_per_minute
        self._calls: list[float] = []

    def check(self) -> bool:
        """Check if request is allowed."""
        if self.max_per_minute <= 0:
            return True

        now = time.time()
        # Remove calls older than 1 minute
        self._calls = [t for t in self._calls if now - t < 60]

        if len(self._calls) >= self.max_per_minute:
            return False

        self._calls.append(now)
        return True


def protect(
    isolate_secrets: bool = True,
    harden_prompt: bool = True,
    filter_input: bool = True,
    filter_output: bool = True,
    block_injection: bool = True,
    log_suspicious: bool = True,
    framework: str | Framework = Framework.GENERIC,
    hardening_level: str | HardeningLevel = HardeningLevel.STANDARD,
    secrets: list[str] | None = None,
    blocked_patterns: list[str] | None = None,
    max_input_length: int = 10000,
    rate_limit_per_minute: int = 0,
) -> Callable[[F], F]:
    """
    Decorator to protect agent functions from prompt injection.

    Args:
        isolate_secrets: Whether to isolate secrets from prompts
        harden_prompt: Whether to add defensive instructions
        filter_input: Whether to filter user input for attacks
        filter_output: Whether to filter output for secret leakage
        block_injection: Whether to block detected injection attempts
        log_suspicious: Whether to log suspicious activity
        framework: Target framework for specialized protection
        hardening_level: Level of hardening to apply
        secrets: List of secrets to protect
        blocked_patterns: Additional regex patterns to block
        max_input_length: Maximum allowed input length
        rate_limit_per_minute: Rate limit (0 = no limit)

    Returns:
        Decorated function with protection

    Example:
        @protect(
            isolate_secrets=True,
            secrets=["sk-my-api-key"],
            framework="langchain",
        )
        def my_agent(user_input: str) -> str:
            return chain.invoke({"input": user_input})
    """
    config = ProtectionConfig(
        isolate_secrets=isolate_secrets,
        harden_prompt=harden_prompt,
        filter_input=filter_input,
        filter_output=filter_output,
        block_injection=block_injection,
        log_suspicious=log_suspicious,
        framework=Framework(framework) if isinstance(framework, str) else framework,
        hardening_level=(
            HardeningLevel(hardening_level) if isinstance(hardening_level, str) else hardening_level
        ),
        secrets=secrets or [],
        blocked_patterns=blocked_patterns or [],
        max_input_length=max_input_length,
        rate_limit_per_minute=rate_limit_per_minute,
    )

    input_filter = InputFilter(config)
    output_filter = OutputFilter(config)
    rate_limiter = RateLimiter(config.rate_limit_per_minute)

    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Rate limiting
            if not rate_limiter.check():
                raise RuntimeError("Rate limit exceeded")

            # Find the user input in args/kwargs
            # Usually it's the first string argument
            input_text = None
            input_idx = None
            input_key = None

            # Check kwargs first for common names
            for key in ["user_input", "input", "query", "message", "prompt", "text"]:
                if key in kwargs and isinstance(kwargs[key], str):
                    input_text = kwargs[key]
                    input_key = key
                    break

            # Check args if not found in kwargs
            if input_text is None:
                for i, arg in enumerate(args):
                    if isinstance(arg, str) and i > 0:  # Skip 'self' for methods
                        input_text = arg
                        input_idx = i
                        break

            # Filter input if found
            if input_text and config.filter_input:
                result = input_filter.filter(input_text)

                if not result.allowed:
                    if config.log_suspicious:
                        logger.warning(f"Blocked input: {result.blocked_reason}")
                    raise ValueError(f"Input blocked: {result.blocked_reason}")

                # Replace filtered input
                if result.filtered_input != input_text:
                    if input_key:
                        kwargs[input_key] = result.filtered_input
                    elif input_idx is not None:
                        args = list(args)
                        args[input_idx] = result.filtered_input
                        args = tuple(args)

                if result.warnings and config.log_suspicious:
                    for warning in result.warnings:
                        logger.warning(f"Input warning: {warning}")

            # Call the original function
            output = func(*args, **kwargs)

            # Filter output if it's a string
            if config.filter_output and isinstance(output, str):
                result = output_filter.filter(output)
                if result.warnings and config.log_suspicious:
                    for warning in result.warnings:
                        logger.warning(f"Output warning: {warning}")
                output = result.filtered_output

            return output

        return wrapper  # type: ignore

    return decorator


def secure(func: F) -> F:
    """
    Simple decorator with default protection settings.

    Usage:
        @secure
        def my_agent(user_input: str) -> str:
            return agent.run(user_input)
    """
    return protect()(func)


# Framework-specific decorator factories


def langchain_protect(
    secrets: list[str] | None = None,
    level: str | HardeningLevel = HardeningLevel.STANDARD,
) -> Callable[[F], F]:
    """
    Decorator optimized for LangChain agents.

    Example:
        @langchain_protect(secrets=["sk-my-key"])
        def my_chain(input: str) -> str:
            return chain.invoke({"input": input})
    """
    return protect(
        framework=Framework.LANGCHAIN,
        hardening_level=level,
        secrets=secrets or [],
        filter_input=True,
        filter_output=True,
    )


def crewai_protect(
    secrets: list[str] | None = None,
    level: str | HardeningLevel = HardeningLevel.STANDARD,
) -> Callable[[F], F]:
    """
    Decorator optimized for CrewAI agents.

    Example:
        @crewai_protect(secrets=["api_key"])
        def my_crew_task(task: str) -> str:
            return crew.kickoff({"task": task})
    """
    return protect(
        framework=Framework.CREWAI,
        hardening_level=level,
        secrets=secrets or [],
        filter_input=True,
        filter_output=True,
    )


def autogen_protect(
    secrets: list[str] | None = None,
    level: str | HardeningLevel = HardeningLevel.STRICT,  # Stricter by default for code execution
) -> Callable[[F], F]:
    """
    Decorator optimized for AutoGen agents.

    Uses STRICT level by default due to code execution capabilities.

    Example:
        @autogen_protect(secrets=["db_password"])
        def my_autogen_chat(message: str) -> str:
            return agent.generate_reply([{"content": message}])
    """
    return protect(
        framework=Framework.AUTOGEN,
        hardening_level=level,
        secrets=secrets or [],
        filter_input=True,
        filter_output=True,
        block_injection=True,
    )


# Context manager for protecting code blocks


class SecureContext:
    """
    Context manager for protecting code blocks.

    Usage:
        with SecureContext(secrets=["sk-key"]) as ctx:
            # Protected code
            result = agent.run(ctx.filter_input(user_input))
            return ctx.filter_output(result)
    """

    def __init__(
        self,
        secrets: list[str] | None = None,
        block_injection: bool = True,
        filter_secrets: bool = True,
    ):
        """Initialize secure context."""
        self.config = ProtectionConfig(
            secrets=secrets or [],
            block_injection=block_injection,
            filter_output=filter_secrets,
        )
        self.input_filter = InputFilter(self.config)
        self.output_filter = OutputFilter(self.config)

    def __enter__(self) -> "SecureContext":
        """Enter context."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context."""
        return False

    def filter_input(self, text: str) -> str:
        """Filter input text."""
        result = self.input_filter.filter(text)
        if not result.allowed:
            raise ValueError(f"Input blocked: {result.blocked_reason}")
        return result.filtered_input or text

    def filter_output(self, text: str) -> str:
        """Filter output text."""
        result = self.output_filter.filter(text)
        return result.filtered_output or text


# Helper functions


def is_injection_attempt(text: str) -> bool:
    """
    Quick check if text appears to be an injection attempt.

    Args:
        text: Text to check

    Returns:
        True if injection patterns detected
    """
    config = ProtectionConfig(block_injection=True)
    filter_ = InputFilter(config)
    result = filter_.filter(text)
    return not result.allowed


def redact_secrets(text: str, secrets: list[str] | None = None) -> str:
    """
    Redact secrets from text.

    Args:
        text: Text to redact
        secrets: List of specific secrets to redact

    Returns:
        Text with secrets redacted
    """
    config = ProtectionConfig(secrets=secrets or [])
    filter_ = OutputFilter(config)
    result = filter_.filter(text)
    return result.filtered_output or text
