"""
Secret Detection and Redaction Module.

Detects and redacts sensitive information like API keys, passwords, tokens,
and other credentials from text.

Usage:
    from vantage_core.protection import detect_secrets, redact_all_secrets, validate_no_secrets

    # Detect secrets
    findings = detect_secrets("My API key is sk-abc123...")
    for finding in findings:
        print(f"Found {finding.secret_type}: {finding.redacted_value}")

    # Redact secrets
    safe_text = redact_all_secrets("API_KEY=sk-abc123 PASSWORD=secret")

    # Validate (raises if secrets found)
    validate_no_secrets(system_prompt)  # Raises SecretFoundError if secrets present
"""

import re
from dataclasses import dataclass
from enum import Enum
from typing import Any


class SecretType(str, Enum):
    """Types of secrets that can be detected."""

    # API Keys
    OPENAI_API_KEY = "openai_api_key"
    ANTHROPIC_API_KEY = "anthropic_api_key"
    AWS_ACCESS_KEY = "aws_access_key"
    AWS_SECRET_KEY = "aws_secret_key"
    GOOGLE_API_KEY = "google_api_key"
    AZURE_KEY = "azure_key"
    GITHUB_TOKEN = "github_token"
    GITLAB_TOKEN = "gitlab_token"
    SLACK_TOKEN = "slack_token"
    STRIPE_KEY = "stripe_key"
    TWILIO_KEY = "twilio_key"
    SENDGRID_KEY = "sendgrid_key"
    MAILGUN_KEY = "mailgun_key"
    GENERIC_API_KEY = "generic_api_key"

    # Tokens
    JWT_TOKEN = "jwt_token"
    BEARER_TOKEN = "bearer_token"
    OAUTH_TOKEN = "oauth_token"
    REFRESH_TOKEN = "refresh_token"
    SESSION_TOKEN = "session_token"

    # Credentials
    PASSWORD = "password"
    SECRET = "secret"
    DATABASE_URL = "database_url"
    CONNECTION_STRING = "connection_string"

    # Keys
    PRIVATE_KEY = "private_key"
    SSH_KEY = "ssh_key"
    PGP_KEY = "pgp_key"
    ENCRYPTION_KEY = "encryption_key"

    # Other
    WEBHOOK_URL = "webhook_url"
    INTERNAL_URL = "internal_url"

    # PII Types
    SSN = "ssn"
    CREDIT_CARD = "credit_card"
    EMAIL = "email"
    PHONE_NUMBER = "phone_number"
    IP_ADDRESS = "ip_address"
    DATE_OF_BIRTH = "date_of_birth"
    DRIVERS_LICENSE = "drivers_license"
    PASSPORT_NUMBER = "passport_number"
    BANK_ACCOUNT = "bank_account"
    ROUTING_NUMBER = "routing_number"
    IBAN = "iban"
    ADDRESS = "address"
    MEDICAL_RECORD = "medical_record"


@dataclass
class SecretFinding:
    """Represents a detected secret."""

    secret_type: SecretType
    original_value: str
    redacted_value: str
    confidence: float  # 0-1
    start_position: int
    end_position: int
    context: str = ""
    recommendation: str = ""


@dataclass
class SecretPattern:
    """Pattern definition for secret detection."""

    secret_type: SecretType
    pattern: str
    confidence: float
    description: str
    redaction_format: str = "[REDACTED_{type}]"


class SecretDetector:
    """
    Detects secrets in text using pattern matching.

    Covers major API providers, common credential patterns,
    and generic secret formats.
    """

    # Pattern definitions
    PATTERNS: list[SecretPattern] = [
        # OpenAI
        SecretPattern(
            SecretType.OPENAI_API_KEY,
            r"sk-[a-zA-Z0-9]{20,}[a-zA-Z0-9_-]*",
            0.95,
            "OpenAI API key (sk-...)",
        ),
        SecretPattern(
            SecretType.OPENAI_API_KEY,
            r"sk-proj-[a-zA-Z0-9_-]{20,}",
            0.98,
            "OpenAI project API key",
        ),
        # Anthropic
        SecretPattern(
            SecretType.ANTHROPIC_API_KEY,
            r"sk-ant-[a-zA-Z0-9_-]{20,}",
            0.98,
            "Anthropic API key",
        ),
        # AWS
        SecretPattern(
            SecretType.AWS_ACCESS_KEY,
            r"(?:A3T[A-Z0-9]|AKIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}",
            0.95,
            "AWS Access Key ID",
        ),
        SecretPattern(
            SecretType.AWS_SECRET_KEY,
            r'(?i)(?:aws)?_?(?:secret)?_?(?:access)?_?key["\'\s:=]+([A-Za-z0-9/+=]{40})',
            0.90,
            "AWS Secret Access Key",
        ),
        # Google
        SecretPattern(
            SecretType.GOOGLE_API_KEY,
            r"AIza[0-9A-Za-z_-]{35}",
            0.95,
            "Google API key",
        ),
        # Azure
        SecretPattern(
            SecretType.AZURE_KEY,
            r'(?i)(?:azure|microsoft)[_-]?(?:api)?[_-]?key["\'\s:=]+[a-zA-Z0-9+/=]{32,}',
            0.85,
            "Azure API key",
        ),
        # GitHub
        SecretPattern(
            SecretType.GITHUB_TOKEN,
            r"gh[pousr]_[A-Za-z0-9_]{36,}",
            0.98,
            "GitHub token",
        ),
        SecretPattern(
            SecretType.GITHUB_TOKEN,
            r"github_pat_[A-Za-z0-9_]{22,}",
            0.98,
            "GitHub personal access token",
        ),
        # GitLab
        SecretPattern(
            SecretType.GITLAB_TOKEN,
            r"glpat-[A-Za-z0-9_-]{20,}",
            0.95,
            "GitLab personal access token",
        ),
        # Slack
        SecretPattern(
            SecretType.SLACK_TOKEN,
            r"xox[baprs]-[0-9]{10,13}-[a-zA-Z0-9-]+",
            0.95,
            "Slack token",
        ),
        # Stripe
        SecretPattern(
            SecretType.STRIPE_KEY,
            r"sk_(?:live|test)_[0-9a-zA-Z]{24,}",
            0.98,
            "Stripe secret key",
        ),
        SecretPattern(
            SecretType.STRIPE_KEY,
            r"pk_(?:live|test)_[0-9a-zA-Z]{24,}",
            0.98,
            "Stripe publishable key",
        ),
        # Twilio
        SecretPattern(
            SecretType.TWILIO_KEY,
            r"SK[0-9a-fA-F]{32}",
            0.90,
            "Twilio API key",
        ),
        # SendGrid
        SecretPattern(
            SecretType.SENDGRID_KEY,
            r"SG\.[a-zA-Z0-9_-]{22,}\.[a-zA-Z0-9_-]{22,}",
            0.98,
            "SendGrid API key",
        ),
        # Mailgun
        SecretPattern(
            SecretType.MAILGUN_KEY,
            r"key-[0-9a-zA-Z]{32}",
            0.90,
            "Mailgun API key",
        ),
        # JWT
        SecretPattern(
            SecretType.JWT_TOKEN,
            r"eyJ[A-Za-z0-9_-]*\.eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*",
            0.95,
            "JWT token",
        ),
        # Bearer token
        SecretPattern(
            SecretType.BEARER_TOKEN,
            r"(?i)bearer\s+[a-zA-Z0-9_\-.~+/]+=*",
            0.85,
            "Bearer token",
        ),
        # Generic patterns
        SecretPattern(
            SecretType.PASSWORD,
            r'(?i)(?:password|passwd|pwd)["\'\s:=]+([^\s"\']{8,})',
            0.80,
            "Password",
        ),
        SecretPattern(
            SecretType.SECRET,
            r'(?i)(?:secret|secret_key)["\'\s:=]+([^\s"\']{8,})',
            0.80,
            "Secret value",
        ),
        SecretPattern(
            SecretType.GENERIC_API_KEY,
            r'(?i)(?:api[_-]?key|apikey)["\'\s:=]+([a-zA-Z0-9_\-]{20,})',
            0.75,
            "Generic API key",
        ),
        # Database URLs
        SecretPattern(
            SecretType.DATABASE_URL,
            r'(?:postgres|postgresql|mysql|mongodb|redis)://[^\s"\']+',
            0.90,
            "Database connection URL",
        ),
        SecretPattern(
            SecretType.CONNECTION_STRING,
            r'(?i)(?:connection[_-]?string|conn[_-]?str)["\'\s:=]+[^\s"\']{20,}',
            0.85,
            "Connection string",
        ),
        # Private keys
        SecretPattern(
            SecretType.PRIVATE_KEY,
            r"-----BEGIN (?:RSA |DSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----",
            0.99,
            "Private key header",
        ),
        SecretPattern(
            SecretType.SSH_KEY,
            r"ssh-(?:rsa|dsa|ecdsa|ed25519)\s+[A-Za-z0-9+/=]+",
            0.95,
            "SSH public key",
        ),
        SecretPattern(
            SecretType.PGP_KEY,
            r"-----BEGIN PGP (?:PRIVATE|PUBLIC) KEY BLOCK-----",
            0.99,
            "PGP key header",
        ),
        SecretPattern(
            SecretType.ENCRYPTION_KEY,
            r'(?i)(?:encryption[_-]?key|aes[_-]?key|master[_-]?key)["\'\s:=]+[^\s"\']{16,}',
            0.85,
            "Encryption key",
        ),
        # URLs
        SecretPattern(
            SecretType.WEBHOOK_URL,
            r'https://(?:hooks\.slack\.com|discord\.com/api/webhooks|.*\.webhook\.office\.com)/[^\s"\']+',
            0.90,
            "Webhook URL",
        ),
        SecretPattern(
            SecretType.INTERNAL_URL,
            r'https?://(?:localhost|127\.0\.0\.1|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(?:1[6-9]|2\d|3[01])\.\d+\.\d+)[^\s"\']*',
            0.70,
            "Internal/local URL",
        ),
        SecretPattern(
            SecretType.INTERNAL_URL,
            r'https?://[^/\s"\']+\.(?:internal|local|private|corp|intra)[^\s"\']*',
            0.80,
            "Internal domain URL",
        ),
        # PII Patterns
        SecretPattern(
            SecretType.SSN,
            r"\b\d{3}-\d{2}-\d{4}\b",
            0.95,
            "Social Security Number (XXX-XX-XXXX format)",
        ),
        SecretPattern(
            SecretType.SSN,
            r"(?i)(?:ssn|social\s*security)[:\s]*\d{9}",
            0.90,
            "Social Security Number (9 digits)",
        ),
        SecretPattern(
            SecretType.CREDIT_CARD,
            r"\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12})\b",
            0.95,
            "Credit card number (Visa, MC, Amex, Discover)",
        ),
        SecretPattern(
            SecretType.CREDIT_CARD,
            r"\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b",
            0.85,
            "Credit card number (formatted)",
        ),
        SecretPattern(
            SecretType.EMAIL,
            r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",
            0.90,
            "Email address",
        ),
        SecretPattern(
            SecretType.PHONE_NUMBER,
            r"\b(?:\+1[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}\b",
            0.85,
            "US Phone number",
        ),
        SecretPattern(
            SecretType.PHONE_NUMBER,
            r"\b\+[1-9][0-9]{6,14}\b",
            0.80,
            "International phone number",
        ),
        SecretPattern(
            SecretType.IP_ADDRESS,
            r"\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b",
            0.75,
            "IPv4 address",
        ),
        SecretPattern(
            SecretType.DATE_OF_BIRTH,
            r"(?i)(?:dob|date\s*of\s*birth|birth\s*date)[:\s]*\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}",
            0.90,
            "Date of birth",
        ),
        SecretPattern(
            SecretType.DRIVERS_LICENSE,
            r"(?i)(?:driver\'?s?\s*license|dl)[:\s#]*[A-Z0-9]{5,15}",
            0.80,
            "Driver's license number",
        ),
        SecretPattern(
            SecretType.PASSPORT_NUMBER,
            r"(?i)passport[:\s#]*[A-Z0-9]{6,12}",
            0.85,
            "Passport number",
        ),
        SecretPattern(
            SecretType.BANK_ACCOUNT,
            r"(?i)(?:account|acct)[:\s#]*\d{8,17}",
            0.80,
            "Bank account number",
        ),
        SecretPattern(
            SecretType.ROUTING_NUMBER,
            r"(?i)(?:routing|aba|rtn)[:\s#]*\d{9}",
            0.85,
            "Bank routing number",
        ),
        SecretPattern(
            SecretType.IBAN,
            r"\b[A-Z]{2}\d{2}[A-Z0-9]{4,30}\b",
            0.80,
            "IBAN (International Bank Account Number)",
        ),
        SecretPattern(
            SecretType.ADDRESS,
            r"\b\d{1,5}\s+(?:[A-Z][a-z]+\s+){1,3}(?:Street|St|Avenue|Ave|Boulevard|Blvd|Road|Rd|Lane|Ln|Drive|Dr|Way|Court|Ct|Place|Pl|Circle|Cir)\b",
            0.75,
            "Street address",
        ),
        SecretPattern(
            SecretType.MEDICAL_RECORD,
            r"(?i)(?:mrn|medical\s*record|patient\s*id)[:\s#]*[A-Z0-9]{6,15}",
            0.85,
            "Medical record number",
        ),
    ]

    def __init__(self, custom_patterns: list[SecretPattern] | None = None):
        """
        Initialize detector.

        Args:
            custom_patterns: Additional patterns to detect
        """
        self.patterns = list(self.PATTERNS)
        if custom_patterns:
            self.patterns.extend(custom_patterns)

        # Pre-compile patterns
        self._compiled: list[tuple[SecretPattern, re.Pattern]] = []
        for pattern in self.patterns:
            try:
                compiled = re.compile(pattern.pattern)
                self._compiled.append((pattern, compiled))
            except re.error as e:
                import logging

                logging.warning(f"Invalid pattern for {pattern.secret_type}: {e}")

    def detect(self, text: str, include_context: bool = True) -> list[SecretFinding]:
        """
        Detect secrets in text.

        Args:
            text: Text to scan
            include_context: Whether to include surrounding context

        Returns:
            List of SecretFinding objects
        """
        findings: list[SecretFinding] = []
        seen_values: set[str] = set()  # Deduplicate

        for pattern_def, compiled in self._compiled:
            for match in compiled.finditer(text):
                # Get the matched value
                if match.groups():
                    value = match.group(1)
                    start = match.start(1)
                    end = match.end(1)
                else:
                    value = match.group()
                    start = match.start()
                    end = match.end()

                # Skip if we've seen this exact value
                if value in seen_values:
                    continue
                seen_values.add(value)

                # Get context if requested
                context = ""
                if include_context:
                    ctx_start = max(0, start - 20)
                    ctx_end = min(len(text), end + 20)
                    context = text[ctx_start:ctx_end]

                # Generate redacted value
                redacted = self._redact_value(value, pattern_def.secret_type)

                # Generate recommendation
                recommendation = self._get_recommendation(pattern_def.secret_type)

                finding = SecretFinding(
                    secret_type=pattern_def.secret_type,
                    original_value=value,
                    redacted_value=redacted,
                    confidence=pattern_def.confidence,
                    start_position=start,
                    end_position=end,
                    context=context,
                    recommendation=recommendation,
                )
                findings.append(finding)

        # Sort by position
        findings.sort(key=lambda f: f.start_position)

        return findings

    def _redact_value(self, value: str, secret_type: SecretType) -> str:
        """Generate redacted version of a secret."""
        if len(value) <= 8:
            return "*" * len(value)

        # Show prefix for identification, redact the rest
        prefix_len = 4
        suffix_len = 4

        if secret_type in [SecretType.PASSWORD, SecretType.SECRET]:
            # Fully redact passwords
            return "[REDACTED]"
        elif "key" in secret_type.value.lower():
            # Show key prefix
            return f"{value[:prefix_len]}...{value[-suffix_len:]}"
        elif "url" in secret_type.value.lower():
            # Redact credentials in URLs
            import urllib.parse

            try:
                parsed = urllib.parse.urlparse(value)
                if parsed.password:
                    redacted_url = value.replace(parsed.password, "[REDACTED]")
                    return redacted_url
            except Exception:
                pass
            return value[:prefix_len] + "..." + value[-suffix_len:]
        else:
            return f"{value[:prefix_len]}{'*' * (len(value) - prefix_len - suffix_len)}{value[-suffix_len:]}"

    def _get_recommendation(self, secret_type: SecretType) -> str:
        """Get remediation recommendation for a secret type."""
        recommendations = {
            SecretType.OPENAI_API_KEY: "Use environment variable OPENAI_API_KEY instead",
            SecretType.ANTHROPIC_API_KEY: "Use environment variable ANTHROPIC_API_KEY instead",
            SecretType.AWS_ACCESS_KEY: "Use IAM roles or AWS credentials file",
            SecretType.AWS_SECRET_KEY: "Use IAM roles or AWS credentials file",
            SecretType.GITHUB_TOKEN: "Use GitHub Actions secrets or environment variables",
            SecretType.PASSWORD: "Use a secrets manager or environment variables",
            SecretType.DATABASE_URL: "Use environment variable DATABASE_URL",
            SecretType.PRIVATE_KEY: "Store in secure key management system",
            SecretType.JWT_TOKEN: "Tokens should not be hardcoded",
            # PII recommendations
            SecretType.SSN: "Remove SSN - collect only when legally required, never in prompts",
            SecretType.CREDIT_CARD: "Remove credit card data - use tokenized payment processing",
            SecretType.EMAIL: "Consider if email is necessary; use user IDs instead",
            SecretType.PHONE_NUMBER: "Remove phone numbers from prompts unless essential",
            SecretType.DATE_OF_BIRTH: "Remove DOB - high identity theft risk",
            SecretType.DRIVERS_LICENSE: "Remove license numbers - regulated PII",
            SecretType.PASSPORT_NUMBER: "Remove passport data - highly sensitive",
            SecretType.BANK_ACCOUNT: "Remove bank details - use secure payment APIs",
            SecretType.ROUTING_NUMBER: "Remove routing numbers - banking fraud risk",
            SecretType.IBAN: "Remove IBAN - international banking data",
            SecretType.ADDRESS: "Consider if full address is needed",
            SecretType.MEDICAL_RECORD: "Remove medical IDs - HIPAA protected",
            SecretType.IP_ADDRESS: "Consider if IP logging is necessary for your use case",
        }
        return recommendations.get(secret_type, "Move to environment variable or secrets manager")

    def redact(self, text: str) -> tuple[str, list[SecretFinding]]:
        """
        Detect and redact all secrets in text.

        Args:
            text: Text to redact

        Returns:
            Tuple of (redacted text, list of findings)
        """
        findings = self.detect(text, include_context=False)

        # Sort by position descending to maintain correct positions during replacement
        findings_sorted = sorted(findings, key=lambda f: f.start_position, reverse=True)

        result = text
        for finding in findings_sorted:
            replacement = f"[REDACTED_{finding.secret_type.value.upper()}]"
            result = result[: finding.start_position] + replacement + result[finding.end_position :]

        return result, list(reversed(findings_sorted))


class SecretFoundError(Exception):
    """Raised when secrets are found in text that should be secret-free."""

    def __init__(self, findings: list[SecretFinding]):
        self.findings = findings
        types = [f.secret_type.value for f in findings]
        super().__init__(f"Found {len(findings)} secret(s): {', '.join(types)}")


def detect_secrets(
    text: str,
    include_context: bool = True,
    custom_patterns: list[SecretPattern] | None = None,
) -> list[SecretFinding]:
    """
    Convenience function to detect secrets in text.

    Args:
        text: Text to scan
        include_context: Whether to include surrounding context
        custom_patterns: Additional patterns to detect

    Returns:
        List of SecretFinding objects
    """
    detector = SecretDetector(custom_patterns)
    return detector.detect(text, include_context)


def redact_all_secrets(
    text: str,
    custom_patterns: list[SecretPattern] | None = None,
) -> str:
    """
    Convenience function to redact all secrets from text.

    Args:
        text: Text to redact
        custom_patterns: Additional patterns to detect

    Returns:
        Text with secrets redacted
    """
    detector = SecretDetector(custom_patterns)
    redacted, _ = detector.redact(text)
    return redacted


def validate_no_secrets(
    text: str,
    raise_on_found: bool = True,
    allowed_types: list[SecretType] | None = None,
) -> list[SecretFinding]:
    """
    Validate that text contains no secrets.

    Args:
        text: Text to validate
        raise_on_found: Whether to raise SecretFoundError if found
        allowed_types: Secret types to ignore (e.g., for internal URLs)

    Returns:
        List of findings (empty if valid)

    Raises:
        SecretFoundError: If secrets found and raise_on_found is True
    """
    detector = SecretDetector()
    findings = detector.detect(text, include_context=True)

    # Filter out allowed types
    if allowed_types:
        findings = [f for f in findings if f.secret_type not in allowed_types]

    if findings and raise_on_found:
        raise SecretFoundError(findings)

    return findings


def get_secret_summary(findings: list[SecretFinding]) -> dict[str, Any]:
    """
    Get summary of secret findings.

    Args:
        findings: List of secret findings

    Returns:
        Summary dictionary
    """
    by_type: dict[str, int] = {}
    high_confidence = 0
    total_risk = 0

    for finding in findings:
        type_name = finding.secret_type.value
        by_type[type_name] = by_type.get(type_name, 0) + 1

        if finding.confidence >= 0.9:
            high_confidence += 1

        # Calculate risk based on secret type
        risk_scores = {
            SecretType.PRIVATE_KEY: 10,
            SecretType.AWS_SECRET_KEY: 9,
            SecretType.DATABASE_URL: 9,
            SecretType.OPENAI_API_KEY: 8,
            SecretType.ANTHROPIC_API_KEY: 8,
            SecretType.PASSWORD: 8,
            SecretType.JWT_TOKEN: 7,
        }
        total_risk += risk_scores.get(finding.secret_type, 5)

    return {
        "total_findings": len(findings),
        "high_confidence": high_confidence,
        "by_type": by_type,
        "risk_score": total_risk,
        "unique_types": len(by_type),
    }
