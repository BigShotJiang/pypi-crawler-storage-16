"""Scanner for Agno (formerly Phidata) framework.

Detects agents from Agno including Agent class and team configurations.
"""

from __future__ import annotations

import ast
from pathlib import Path

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult
from vantage_core.scanners.mixins import ASTExtractionMixin


class AgnoScanner(BaseScanner, ASTExtractionMixin):
    """Scanner for Agno (formerly Phidata) framework.

    Detects:
    - Agent class instantiations
    - Team configurations
    - Tool and model configurations

    Example:
        >>> scanner = AgnoScanner()
        >>> result = scanner.scan_file(Path("agent.py"))
        >>> for agent in result.agents:
        ...     print(f"{agent.name}: {agent.system_prompt}")
    """

    framework_name = "Agno"

    # Agent classes to detect
    AGENT_CLASSES = {
        "Agent",
        "Assistant",  # Legacy phidata name
    }

    # Team classes to detect
    TEAM_CLASSES = {
        "Team",
        "AgentTeam",
    }

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a Python file for Agno agent definitions.

        Args:
            path: Path to Python file

        Returns:
            ScanResult with detected agents and connections
        """
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        errors: list[str] = []

        try:
            tree = self._parse_python_file(path)
        except SyntaxError as e:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[f"Syntax error in {path}: {e}"],
            )

        # Track agent variable names for team parsing
        agent_vars: dict[str, str] = {}

        # First pass: find agent instantiations
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        # Check for Agent
                        agent = self._parse_agent_call(node.value, path, target.id)
                        if agent:
                            agents.append(agent)
                            agent_vars[target.id] = agent.id

        # Second pass: find team configurations
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                call_name = self._get_call_name(node)
                if call_name in self.TEAM_CLASSES:
                    team_conns = self._parse_team_connections(node, agent_vars)
                    connections.extend(team_conns)

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=errors,
        )

    def _parse_agent_call(
        self, node: ast.Call, path: Path, var_name: str | None
    ) -> DetectedAgent | None:
        """Parse Agno Agent constructor call.

        Args:
            node: AST Call node
            path: Source file path
            var_name: Variable name if assigned

        Returns:
            DetectedAgent or None if not a recognized agent
        """
        call_name = self._get_call_name(node)
        if call_name not in self.AGENT_CLASSES:
            return None

        # Extract name
        name = self._extract_keyword_arg(node, "name")
        if not name:
            name = var_name or call_name
        agent_id = self._make_id(name)

        # Extract description (often used as high-level purpose)
        description = self._extract_keyword_arg(node, "description")

        # Extract instructions (system prompt)
        instructions = self._extract_keyword_arg(node, "instructions")
        if isinstance(instructions, list):
            instructions = "\n".join(str(i) for i in instructions)

        # Build system prompt
        system_prompt = ""
        if description:
            system_prompt = f"{description}\n\n"
        if instructions:
            system_prompt += str(instructions)
        if not system_prompt:
            system_prompt = f"Agno {call_name}"

        # Extract model
        model = self._extract_model_config(node)

        # Extract tools
        tools = self._extract_tools(node)
        if tools:
            tool_str = ", ".join(tools)
            system_prompt = f"{system_prompt}\n\nTools: {tool_str}"

        # Extract knowledge (RAG sources)
        knowledge = self._extract_keyword_arg(node, "knowledge")
        if knowledge:
            if isinstance(knowledge, list):
                knowledge_str = ", ".join(str(k) for k in knowledge)
            else:
                knowledge_str = str(knowledge)
            system_prompt = f"{system_prompt}\n\nKnowledge: {knowledge_str}"

        # Extract storage
        storage = self._extract_keyword_arg(node, "storage")
        if storage:
            system_prompt = f"{system_prompt}\n\nStorage: {storage}"

        return DetectedAgent(
            id=agent_id,
            name=self._format_display_name(str(name)),
            system_prompt=system_prompt.strip(),
            file_path=str(path),
            line_number=node.lineno,
            framework=Framework.AGNO,
            tools=tools,
            metadata={
                "agent_type": call_name,
                "model": model,
            },
        )

    def _extract_model_config(self, node: ast.Call) -> str:
        """Extract model configuration from agent call.

        Args:
            node: AST Call node

        Returns:
            Model string
        """
        # Check for model keyword
        model = self._extract_keyword_arg(node, "model")

        if model:
            if isinstance(model, str):
                return model
            # Model might be a class instantiation
            return str(model)

        # Check for llm
        llm = self._extract_keyword_arg(node, "llm")
        if llm:
            if isinstance(llm, str):
                return llm
            return str(llm)

        return "gpt-4"  # Default

    def _extract_tools(self, node: ast.Call) -> list[str]:
        """Extract tool names from agent call.

        Args:
            node: AST Call node

        Returns:
            List of tool names
        """
        tools: list[str] = []

        tools_arg = self._extract_keyword_arg(node, "tools")
        if isinstance(tools_arg, list):
            for tool in tools_arg:
                if isinstance(tool, str):
                    tools.append(tool)
                elif isinstance(tool, dict) and "name" in tool:
                    tools.append(tool["name"])

        return tools

    def _parse_team_connections(
        self, node: ast.Call, agent_vars: dict[str, str]
    ) -> list[DetectedConnection]:
        """Parse connections from Team configuration.

        Args:
            node: AST Call node for Team
            agent_vars: Mapping of variable names to agent IDs

        Returns:
            List of connections between agents
        """
        connections: list[DetectedConnection] = []

        # Get members (agents in the team)
        members = self._extract_keyword_arg(node, "members")
        if not members:
            members = self._extract_keyword_arg(node, "agents")

        if isinstance(members, list):
            # Extract agent IDs from members
            member_ids: list[str] = []
            for member in members:
                if isinstance(member, str) and member in agent_vars:
                    member_ids.append(agent_vars[member])

            # Check for mode/strategy
            mode = self._extract_keyword_arg(node, "mode")

            if mode == "sequential" or not mode:
                # Sequential connections
                for i in range(len(member_ids) - 1):
                    connections.append(
                        DetectedConnection(
                            source_id=member_ids[i],
                            target_id=member_ids[i + 1],
                            connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                            confidence=0.95,
                            confidence_level=ConnectionConfidence.FRAMEWORK,
                            evidence=["Agno Team sequential mode"],
                        )
                    )
            elif mode == "coordinate" or mode == "route":
                # Hub-and-spoke pattern - first agent coordinates others
                if len(member_ids) > 1:
                    coordinator = member_ids[0]
                    for member_id in member_ids[1:]:
                        connections.append(
                            DetectedConnection(
                                source_id=coordinator,
                                target_id=member_id,
                                connection_type=ConnectionType.HIERARCHICAL,
                                confidence=0.95,
                                confidence_level=ConnectionConfidence.FRAMEWORK,
                                evidence=[f"Agno Team {mode} mode - coordinator to member"],
                            )
                        )
                        connections.append(
                            DetectedConnection(
                                source_id=member_id,
                                target_id=coordinator,
                                connection_type=ConnectionType.HIERARCHICAL,
                                confidence=0.95,
                                confidence_level=ConnectionConfidence.FRAMEWORK,
                                evidence=[f"Agno Team {mode} mode - member to coordinator"],
                            )
                        )

        return connections
