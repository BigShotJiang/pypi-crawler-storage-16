"""Data Flow Analysis for Connection Detection.

Implements variable tracking and data flow graph construction to detect
connections between agents. Provides 80% confidence connections that
complement the 95% confidence framework-specific patterns.

Reference: US-025 - Data Flow Analysis for Connection Detection
"""

from __future__ import annotations

import ast
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
)

logger = logging.getLogger(__name__)


@dataclass
class VariableInfo:
    """Information about a variable assignment."""

    name: str
    source_agent: str | None  # Agent that produced this value
    line_number: int
    file_path: str
    is_agent_output: bool = False
    intermediate_processing: list[str] = field(default_factory=list)


@dataclass
class DataFlowEdge:
    """Edge in the data flow graph."""

    source_agent: str
    target_agent: str
    variable_name: str
    source_line: int
    target_line: int
    confidence: float
    evidence: list[str]


class DataFlowAnalyzer:
    """Analyzes data flow between agents for connection detection.

    Tracks variable assignments, return values, and parameters to build
    a data flow graph between agents.

    Example:
        analyzer = DataFlowAnalyzer()
        connections = analyzer.detect_connections(agents, source_files)
    """

    def __init__(
        self,
        confidence: float = 0.80,
        cross_function_confidence: float = 0.75,
    ):
        """Initialize the data flow analyzer.

        Args:
            confidence: Default confidence for intra-function connections
            cross_function_confidence: Confidence for cross-function connections
        """
        self.confidence = confidence
        self.cross_function_confidence = cross_function_confidence

        # Framework-specific output patterns
        self._output_patterns = {
            # Method patterns that indicate agent output
            "run",
            "execute",
            "invoke",
            "process",
            "chat",
            "complete",
            "generate",
            "respond",
            "call",
            "kickoff",
            "initiate_chat",
            "send_message",
        }

        # Framework-specific attribute patterns
        self._output_attributes = {
            "output",
            "result",
            "response",
            "content",
            "message",
            "chat_result",
            "last_message",
        }

    def track_variables(
        self,
        tree: ast.Module,
        file_path: str = "",
        agents: list[DetectedAgent] | None = None,
    ) -> dict[str, list[VariableInfo]]:
        """Track where variables are assigned and used.

        Args:
            tree: Parsed AST module
            file_path: Path to source file (for reporting)
            agents: List of detected agents to match against

        Returns:
            Dictionary mapping variable names to their assignments
        """
        agent_ids = {a.id.lower() for a in agents} if agents else set()
        agent_names = {a.name.lower(): a.id for a in agents} if agents else {}

        variables: dict[str, list[VariableInfo]] = {}
        visitor = _VariableTracker(
            agent_ids=agent_ids,
            agent_names=agent_names,
            output_patterns=self._output_patterns,
            output_attributes=self._output_attributes,
            file_path=file_path,
        )
        visitor.visit(tree)

        return visitor.variables

    def build_flow_graph(
        self, agents: list[DetectedAgent], source_files: list[Path]
    ) -> dict[str, list[DataFlowEdge]]:
        """Build graph of data flow between agents.

        Args:
            agents: List of detected agents
            source_files: List of source file paths to analyze

        Returns:
            Dictionary mapping source agents to their outgoing edges
        """
        flow_graph: dict[str, list[DataFlowEdge]] = {}
        agent_ids = {a.id for a in agents}

        for file_path in source_files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    source = f.read()
                tree = ast.parse(source, filename=str(file_path))

                # Track variables in this file
                variables = self.track_variables(tree, str(file_path), agents)

                # Analyze usages to find connections
                edges = self._find_data_flow_edges(tree, variables, agents, str(file_path))

                for edge in edges:
                    if edge.source_agent not in flow_graph:
                        flow_graph[edge.source_agent] = []
                    flow_graph[edge.source_agent].append(edge)

            except Exception as e:
                logger.debug(f"Error analyzing {file_path}: {e}")
                continue

        return flow_graph

    def detect_connections(
        self, agents: list[DetectedAgent], source_files: list[Path]
    ) -> list[DetectedConnection]:
        """Detect connections at 80% confidence from data flow.

        Args:
            agents: List of detected agents
            source_files: List of source file paths to analyze

        Returns:
            List of detected connections with data flow confidence
        """
        flow_graph = self.build_flow_graph(agents, source_files)

        connections: list[DetectedConnection] = []
        seen_pairs: set[tuple[str, str]] = set()

        for source_agent, edges in flow_graph.items():
            for edge in edges:
                pair = (edge.source_agent, edge.target_agent)
                if pair in seen_pairs:
                    continue

                seen_pairs.add(pair)

                connection = DetectedConnection(
                    source_id=edge.source_agent,
                    target_id=edge.target_agent,
                    connection_type=ConnectionType.DELEGATION,
                    confidence=edge.confidence,
                    confidence_level=ConnectionConfidence.HEURISTIC,
                    evidence=edge.evidence,
                    metadata={
                        "data_passed": [edge.variable_name],
                        "line_numbers": (edge.source_line, edge.target_line),
                    },
                )
                connections.append(connection)

        return connections

    def _find_data_flow_edges(
        self,
        tree: ast.Module,
        variables: dict[str, list[VariableInfo]],
        agents: list[DetectedAgent],
        file_path: str,
    ) -> list[DataFlowEdge]:
        """Find data flow edges from variable assignments to usages.

        Args:
            tree: Parsed AST module
            variables: Tracked variable information
            agents: List of detected agents
            file_path: Source file path

        Returns:
            List of data flow edges between agents
        """
        edges: list[DataFlowEdge] = []
        agent_ids = {a.id.lower() for a in agents}
        agent_names = {a.name.lower(): a.id for a in agents}

        # Find usages of variables in agent calls
        usage_visitor = _UsageAnalyzer(
            variables=variables,
            agent_ids=agent_ids,
            agent_names=agent_names,
            output_patterns=self._output_patterns,
        )
        usage_visitor.visit(tree)

        # Create edges from usages
        for usage in usage_visitor.usages:
            var_name = usage["variable"]
            target_agent = usage["target_agent"]
            usage_line = usage["line"]

            if var_name not in variables:
                continue

            for var_info in variables[var_name]:
                if var_info.source_agent and var_info.source_agent != target_agent:
                    # Determine confidence based on processing chain
                    confidence = self.confidence
                    if var_info.intermediate_processing:
                        confidence = self.cross_function_confidence

                    evidence = [
                        f"Variable '{var_name}' assigned from {var_info.source_agent} "
                        f"at line {var_info.line_number}",
                        f"Used as input to {target_agent} at line {usage_line}",
                    ]
                    if var_info.intermediate_processing:
                        evidence.append(
                            f"Through processing: {' -> '.join(var_info.intermediate_processing)}"
                        )

                    edge = DataFlowEdge(
                        source_agent=var_info.source_agent,
                        target_agent=target_agent,
                        variable_name=var_name,
                        source_line=var_info.line_number,
                        target_line=usage_line,
                        confidence=confidence,
                        evidence=evidence,
                    )
                    edges.append(edge)

        return edges


class _VariableTracker(ast.NodeVisitor):
    """AST visitor to track variable assignments."""

    def __init__(
        self,
        agent_ids: set[str],
        agent_names: dict[str, str],
        output_patterns: set[str],
        output_attributes: set[str],
        file_path: str,
    ):
        self.agent_ids = agent_ids
        self.agent_names = agent_names
        self.output_patterns = output_patterns
        self.output_attributes = output_attributes
        self.file_path = file_path
        self.variables: dict[str, list[VariableInfo]] = {}
        self._current_function: str | None = None

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        """Track function context."""
        old_function = self._current_function
        self._current_function = node.name
        self.generic_visit(node)
        self._current_function = old_function

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        """Track async function context."""
        self.visit_FunctionDef(node)  # type: ignore

    def visit_Assign(self, node: ast.Assign) -> None:
        """Track variable assignments."""
        # Check if this is an agent output assignment
        source_agent = self._get_agent_from_call(node.value)

        for target in node.targets:
            if isinstance(target, ast.Name):
                var_info = VariableInfo(
                    name=target.id,
                    source_agent=source_agent,
                    line_number=node.lineno,
                    file_path=self.file_path,
                    is_agent_output=source_agent is not None,
                )

                if target.id not in self.variables:
                    self.variables[target.id] = []
                self.variables[target.id].append(var_info)

            elif isinstance(target, ast.Tuple):
                # Handle tuple unpacking
                for elt in target.elts:
                    if isinstance(elt, ast.Name):
                        var_info = VariableInfo(
                            name=elt.id,
                            source_agent=source_agent,
                            line_number=node.lineno,
                            file_path=self.file_path,
                            is_agent_output=source_agent is not None,
                        )
                        if elt.id not in self.variables:
                            self.variables[elt.id] = []
                        self.variables[elt.id].append(var_info)

        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        """Track annotated assignments."""
        if node.value and isinstance(node.target, ast.Name):
            source_agent = self._get_agent_from_call(node.value)

            var_info = VariableInfo(
                name=node.target.id,
                source_agent=source_agent,
                line_number=node.lineno,
                file_path=self.file_path,
                is_agent_output=source_agent is not None,
            )

            if node.target.id not in self.variables:
                self.variables[node.target.id] = []
            self.variables[node.target.id].append(var_info)

        self.generic_visit(node)

    def visit_NamedExpr(self, node: ast.NamedExpr) -> None:
        """Track walrus operator assignments."""
        source_agent = self._get_agent_from_call(node.value)

        var_info = VariableInfo(
            name=node.target.id,
            source_agent=source_agent,
            line_number=node.lineno,
            file_path=self.file_path,
            is_agent_output=source_agent is not None,
        )

        if node.target.id not in self.variables:
            self.variables[node.target.id] = []
        self.variables[node.target.id].append(var_info)

        self.generic_visit(node)

    def _get_agent_from_call(self, node: ast.expr) -> str | None:
        """Extract agent ID from a call expression."""
        if isinstance(node, ast.Call):
            # Check for method call patterns like agent.run()
            if isinstance(node.func, ast.Attribute):
                method_name = node.func.attr.lower()
                if method_name in self.output_patterns:
                    # Get the object being called
                    if isinstance(node.func.value, ast.Name):
                        obj_name = node.func.value.id.lower()
                        if obj_name in self.agent_ids:
                            return obj_name
                        if obj_name in self.agent_names:
                            return self.agent_names[obj_name]

                    # Check for attribute access like crew.agent.run()
                    if isinstance(node.func.value, ast.Attribute):
                        attr_name = node.func.value.attr.lower()
                        if attr_name in self.agent_ids:
                            return attr_name
                        if attr_name in self.agent_names:
                            return self.agent_names[attr_name]

            # Check for direct function call with agent name
            if isinstance(node.func, ast.Name):
                func_name = node.func.id.lower()
                if func_name in self.agent_ids:
                    return func_name
                if func_name in self.agent_names:
                    return self.agent_names[func_name]

        # Check for attribute access like result.output
        elif isinstance(node, ast.Attribute):
            if node.attr.lower() in self.output_attributes:
                # Recursively check the value
                return self._get_agent_from_call(node.value)

        return None


class _UsageAnalyzer(ast.NodeVisitor):
    """AST visitor to find variable usages in agent calls."""

    def __init__(
        self,
        variables: dict[str, list[VariableInfo]],
        agent_ids: set[str],
        agent_names: dict[str, str],
        output_patterns: set[str],
    ):
        self.variables = variables
        self.agent_ids = agent_ids
        self.agent_names = agent_names
        self.output_patterns = output_patterns
        self.usages: list[dict[str, Any]] = []

    def visit_Call(self, node: ast.Call) -> None:
        """Check for variables used in agent calls."""
        target_agent = self._get_target_agent(node)

        if target_agent:
            # Check arguments for tracked variables
            for arg in node.args:
                var_names = self._extract_variables(arg)
                for var_name in var_names:
                    if var_name in self.variables:
                        self.usages.append(
                            {
                                "variable": var_name,
                                "target_agent": target_agent,
                                "line": node.lineno,
                            }
                        )

            # Check keyword arguments
            for keyword in node.keywords:
                var_names = self._extract_variables(keyword.value)
                for var_name in var_names:
                    if var_name in self.variables:
                        self.usages.append(
                            {
                                "variable": var_name,
                                "target_agent": target_agent,
                                "line": node.lineno,
                            }
                        )

        self.generic_visit(node)

    def _get_target_agent(self, node: ast.Call) -> str | None:
        """Get the target agent ID from a call."""
        if isinstance(node.func, ast.Attribute):
            method_name = node.func.attr.lower()
            if method_name in self.output_patterns:
                if isinstance(node.func.value, ast.Name):
                    obj_name = node.func.value.id.lower()
                    if obj_name in self.agent_ids:
                        return obj_name
                    if obj_name in self.agent_names:
                        return self.agent_names[obj_name]

                if isinstance(node.func.value, ast.Attribute):
                    attr_name = node.func.value.attr.lower()
                    if attr_name in self.agent_ids:
                        return attr_name
                    if attr_name in self.agent_names:
                        return self.agent_names[attr_name]

        elif isinstance(node.func, ast.Name):
            func_name = node.func.id.lower()
            if func_name in self.agent_ids:
                return func_name
            if func_name in self.agent_names:
                return self.agent_names[func_name]

        return None

    def _extract_variables(self, node: ast.expr) -> list[str]:
        """Extract variable names from an expression."""
        variables = []

        if isinstance(node, ast.Name):
            variables.append(node.id)
        elif isinstance(node, ast.Attribute):
            # Get the base variable
            base_vars = self._extract_variables(node.value)
            variables.extend(base_vars)
        elif isinstance(node, ast.Subscript):
            base_vars = self._extract_variables(node.value)
            variables.extend(base_vars)
        elif isinstance(node, ast.Call):
            # Check arguments of nested calls
            for arg in node.args:
                variables.extend(self._extract_variables(arg))
            for keyword in node.keywords:
                variables.extend(self._extract_variables(keyword.value))
        elif isinstance(node, (ast.List, ast.Tuple)):
            for elt in node.elts:
                variables.extend(self._extract_variables(elt))
        elif isinstance(node, ast.Dict):
            for value in node.values:
                if value:
                    variables.extend(self._extract_variables(value))

        return variables


def analyze_data_flow(
    agents: list[DetectedAgent], source_files: list[Path], confidence: float = 0.80
) -> list[DetectedConnection]:
    """Convenience function to analyze data flow.

    Args:
        agents: List of detected agents
        source_files: List of source file paths
        confidence: Confidence level for detected connections

    Returns:
        List of detected connections
    """
    analyzer = DataFlowAnalyzer(confidence=confidence)
    return analyzer.detect_connections(agents, source_files)


# ---------------------------------------------------------
# Level 3: Call Graph Analysis
# Reference: US-029 - Call Graph Analysis for Connection Detection
# ---------------------------------------------------------


@dataclass
class CallGraphNode:
    """Node in the call graph representing a function."""

    name: str
    file_path: str
    line_number: int
    calls: list[str] = field(default_factory=list)  # Functions this node calls
    called_by: list[str] = field(default_factory=list)  # Functions that call this node
    agent_invocations: list[str] = field(default_factory=list)  # Agents invoked by this function


@dataclass
class CallPath:
    """A path through the call graph from one agent to another."""

    source_agent: str
    target_agent: str
    path: list[str]  # List of function names in the path
    source_line: int
    target_line: int


class CallGraphAnalyzer:
    """Analyzes function call graphs to detect agent connections.

    Builds a directed graph of function calls and traces paths
    to find agent invocation sequences (Level 3: 75% confidence).

    Example:
        analyzer = CallGraphAnalyzer()
        connections = analyzer.detect_connections(agents, source_files)
    """

    def __init__(
        self,
        confidence: float = 0.75,
        max_depth: int = 5,
    ):
        """Initialize the call graph analyzer.

        Args:
            confidence: Confidence level for detected connections
            max_depth: Maximum depth for path traversal (prevent explosion)
        """
        self.confidence = confidence
        self.max_depth = max_depth

        # Framework-specific invocation patterns
        self._invocation_patterns = {
            "run",
            "execute",
            "invoke",
            "process",
            "chat",
            "complete",
            "generate",
            "respond",
            "call",
            "kickoff",
            "initiate_chat",
            "send_message",
            "arun",
            "ainvoke",
            "aexecute",
        }

    def build_call_graph(
        self, source_files: list[Path], agents: list[DetectedAgent]
    ) -> dict[str, CallGraphNode]:
        """Build directed graph of function calls.

        Args:
            source_files: List of source file paths to analyze
            agents: List of detected agents

        Returns:
            Dictionary mapping qualified function names to CallGraphNodes
        """
        call_graph: dict[str, CallGraphNode] = {}
        agent_ids = {a.id.lower() for a in agents}
        agent_names = {a.name.lower(): a.id for a in agents}

        for file_path in source_files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    source = f.read()
                tree = ast.parse(source, filename=str(file_path))

                # Extract functions and their calls
                visitor = _CallGraphVisitor(
                    file_path=str(file_path),
                    agent_ids=agent_ids,
                    agent_names=agent_names,
                    invocation_patterns=self._invocation_patterns,
                )
                visitor.visit(tree)

                # Merge into main graph
                for name, node in visitor.nodes.items():
                    qualified_name = f"{file_path.stem}:{name}"
                    call_graph[qualified_name] = node

            except Exception as e:
                logger.debug(f"Error building call graph for {file_path}: {e}")
                continue

        # Build reverse edges (called_by)
        for name, node in call_graph.items():
            for called in node.calls:
                if called in call_graph:
                    call_graph[called].called_by.append(name)

        return call_graph

    def find_agent_paths(
        self, call_graph: dict[str, CallGraphNode], agents: list[DetectedAgent]
    ) -> list[CallPath]:
        """Find paths between agent invocations in the call graph.

        Args:
            call_graph: Built call graph
            agents: List of detected agents

        Returns:
            List of paths between agent invocations
        """
        paths: list[CallPath] = []
        agent_ids = {a.id.lower() for a in agents}

        # Find all functions that invoke agents
        agent_functions: dict[str, list[str]] = {}  # agent_id -> [function_names]
        for func_name, node in call_graph.items():
            for agent_id in node.agent_invocations:
                if agent_id not in agent_functions:
                    agent_functions[agent_id] = []
                agent_functions[agent_id].append(func_name)

        # For each pair of agents, find paths
        for source_agent in agent_ids:
            if source_agent not in agent_functions:
                continue

            for target_agent in agent_ids:
                if target_agent == source_agent:
                    continue
                if target_agent not in agent_functions:
                    continue

                # Find paths from functions invoking source to functions invoking target
                for source_func in agent_functions[source_agent]:
                    for target_func in agent_functions[target_agent]:
                        path = self._find_path(call_graph, source_func, target_func)
                        if path:
                            call_path = CallPath(
                                source_agent=source_agent,
                                target_agent=target_agent,
                                path=path,
                                source_line=call_graph[source_func].line_number,
                                target_line=call_graph[target_func].line_number,
                            )
                            paths.append(call_path)

        return paths

    def _find_path(self, graph: dict[str, CallGraphNode], start: str, end: str) -> list[str] | None:
        """Find a path between two nodes using BFS.

        Args:
            graph: The call graph
            start: Starting function name
            end: Ending function name

        Returns:
            List of function names in path, or None if no path exists
        """
        if start == end:
            return [start]

        visited: set[str] = set()
        queue: list[tuple[str, list[str]]] = [(start, [start])]

        while queue:
            current, path = queue.pop(0)

            if len(path) > self.max_depth:
                continue

            if current == end:
                return path

            if current in visited:
                continue
            visited.add(current)

            if current not in graph:
                continue

            # Follow both directions (calls and called_by)
            neighbors = graph[current].calls + graph[current].called_by
            for neighbor in neighbors:
                if neighbor not in visited:
                    queue.append((neighbor, path + [neighbor]))

        return None

    def detect_connections(
        self, agents: list[DetectedAgent], source_files: list[Path]
    ) -> list[DetectedConnection]:
        """Detect connections at 75% confidence from call graph analysis.

        Args:
            agents: List of detected agents
            source_files: List of source file paths to analyze

        Returns:
            List of detected connections with call graph confidence
        """
        call_graph = self.build_call_graph(source_files, agents)
        paths = self.find_agent_paths(call_graph, agents)

        connections: list[DetectedConnection] = []
        seen_pairs: set[tuple[str, str]] = set()

        for call_path in paths:
            pair = (call_path.source_agent, call_path.target_agent)
            if pair in seen_pairs:
                continue

            seen_pairs.add(pair)

            evidence = [
                f"Call graph path: {' -> '.join(call_path.path)}",
                f"Source function at line {call_path.source_line}",
                f"Target function at line {call_path.target_line}",
            ]

            connection = DetectedConnection(
                source_id=call_path.source_agent,
                target_id=call_path.target_agent,
                connection_type=ConnectionType.DELEGATION,
                confidence=self.confidence,
                confidence_level=ConnectionConfidence.HEURISTIC,
                evidence=evidence,
                metadata={"line_numbers": (call_path.source_line, call_path.target_line)},
            )
            connections.append(connection)

        return connections


class _CallGraphVisitor(ast.NodeVisitor):
    """AST visitor to build function call graph."""

    def __init__(
        self,
        file_path: str,
        agent_ids: set[str],
        agent_names: dict[str, str],
        invocation_patterns: set[str],
    ):
        self.file_path = file_path
        self.agent_ids = agent_ids
        self.agent_names = agent_names
        self.invocation_patterns = invocation_patterns
        self.nodes: dict[str, CallGraphNode] = {}
        self._current_function: str | None = None

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        """Process function definition."""
        old_function = self._current_function
        self._current_function = node.name

        # Create node for this function
        self.nodes[node.name] = CallGraphNode(
            name=node.name,
            file_path=self.file_path,
            line_number=node.lineno,
        )

        self.generic_visit(node)
        self._current_function = old_function

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        """Process async function definition."""
        self.visit_FunctionDef(node)  # type: ignore

    def visit_Call(self, node: ast.Call) -> None:
        """Process function calls."""
        if self._current_function is None:
            self.generic_visit(node)
            return

        current_node = self.nodes.get(self._current_function)
        if current_node is None:
            self.generic_visit(node)
            return

        # Get called function name
        called_name = self._get_called_name(node)
        if called_name:
            current_node.calls.append(called_name)

        # Check for agent invocations
        agent_id = self._get_agent_invocation(node)
        if agent_id:
            current_node.agent_invocations.append(agent_id)

        self.generic_visit(node)

    def _get_called_name(self, node: ast.Call) -> str | None:
        """Extract the name of the called function."""
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            return node.func.attr
        return None

    def _get_agent_invocation(self, node: ast.Call) -> str | None:
        """Check if this call invokes an agent."""
        if isinstance(node.func, ast.Attribute):
            method_name = node.func.attr.lower()
            if method_name in self.invocation_patterns:
                # Get the object being called
                if isinstance(node.func.value, ast.Name):
                    obj_name = node.func.value.id.lower()
                    if obj_name in self.agent_ids:
                        return obj_name
                    if obj_name in self.agent_names:
                        return self.agent_names[obj_name]

                # Check for attribute access
                if isinstance(node.func.value, ast.Attribute):
                    attr_name = node.func.value.attr.lower()
                    if attr_name in self.agent_ids:
                        return attr_name
                    if attr_name in self.agent_names:
                        return self.agent_names[attr_name]

        return None


# ---------------------------------------------------------
# Level 4: Semantic Inference
# Reference: US-030 - Semantic Inference for Connection Detection
# ---------------------------------------------------------


@dataclass
class SemanticMatch:
    """A semantic match between agent reference and prompt text."""

    source_agent: str
    target_agent: str
    matched_phrase: str
    similarity_score: float
    source_line: int


class SemanticAnalyzer:
    """Analyzes prompts semantically to detect agent connections.

    Uses embeddings to find agent references by semantic similarity
    (Level 4: 50% confidence fallback).

    Example:
        analyzer = SemanticAnalyzer()
        connections = analyzer.detect_connections(agents)
    """

    def __init__(
        self,
        confidence: float = 0.50,
        similarity_threshold: float = 0.6,
        batch_size: int = 32,
        model_name: str = "all-mpnet-base-v2",
    ):
        """Initialize the semantic analyzer.

        Args:
            confidence: Confidence level for detected connections
            similarity_threshold: Minimum similarity for a match
            batch_size: Batch size for embedding computation
            model_name: Sentence transformer model to use
        """
        self.confidence = confidence
        self.similarity_threshold = similarity_threshold
        self.batch_size = batch_size
        self.model_name = model_name
        self._registry = None

        # Try to import ModelRegistry for embeddings
        try:
            from vantage_core.model_registry import get_model_registry

            self._registry = get_model_registry()
        except ImportError:
            logger.warning(
                "ModelRegistry not available, semantic analysis will use keyword fallback"
            )

    def extract_key_phrases(self, text: str) -> list[str]:
        """Extract key phrases from text for embedding.

        Args:
            text: Text to extract phrases from

        Returns:
            List of key phrases
        """
        # Split into sentences
        import re

        sentences = re.split(r"[.!?]\s+", text)

        phrases = []
        for sentence in sentences:
            # Skip very short sentences
            if len(sentence.split()) < 3:
                continue

            # Look for agent-related phrases
            agent_patterns = [
                r"(?:pass|send|forward|delegate|invoke|call|coordinate with|work with)\s+(?:to|with)?\s*(?:the\s+)?(\w+)",
                r"(?:receive|get|obtain|accept)\s+(?:from|input from)\s*(?:the\s+)?(\w+)",
                r"(?:the\s+)?(\w+)\s+(?:agent|worker|assistant)",
            ]

            for pattern in agent_patterns:
                matches = re.findall(pattern, sentence.lower())
                if matches:
                    phrases.append(sentence.strip())
                    break
            else:
                # Include sentences mentioning roles or responsibilities
                if any(
                    word in sentence.lower()
                    for word in ["agent", "task", "role", "delegate", "coordinate"]
                ):
                    phrases.append(sentence.strip())

        return phrases if phrases else [text[:500]]  # Fallback to first 500 chars

    def compute_agent_embeddings(self, agents: list[DetectedAgent]) -> dict[str, Any] | None:
        """Compute embeddings for agent names and descriptions.

        Args:
            agents: List of detected agents

        Returns:
            Dictionary mapping agent IDs to embeddings, or None if unavailable
        """
        if self._registry is None or not self._registry.is_embedding_available():
            return None

        # Build texts to embed for each agent
        agent_texts = []
        agent_ids = []

        for agent in agents:
            # Combine name and key info for embedding
            text = f"{agent.name} {agent.id}"
            agent_texts.append(text)
            agent_ids.append(agent.id)

        # Get embeddings
        embeddings = self._registry.get_embeddings(
            agent_texts, model_name=self.model_name, batch_size=self.batch_size
        )

        if embeddings is None:
            return None

        return {aid: emb for aid, emb in zip(agent_ids, embeddings)}

    def find_semantic_matches(
        self, agents: list[DetectedAgent], agent_embeddings: dict[str, Any]
    ) -> list[SemanticMatch]:
        """Find semantic matches between prompts and agents.

        Args:
            agents: List of detected agents
            agent_embeddings: Precomputed agent embeddings

        Returns:
            List of semantic matches
        """
        import numpy as np

        matches: list[SemanticMatch] = []

        for source_agent in agents:
            if not source_agent.system_prompt:
                continue

            # Extract key phrases from this agent's prompt
            phrases = self.extract_key_phrases(source_agent.system_prompt)

            if not phrases:
                continue

            # Get embeddings for phrases
            phrase_embeddings = self._registry.get_embeddings(
                phrases, model_name=self.model_name, batch_size=self.batch_size
            )

            if phrase_embeddings is None:
                continue

            # Compare with each other agent
            for target_id, target_emb in agent_embeddings.items():
                if target_id == source_agent.id:
                    continue

                # Compute similarities
                for i, phrase_emb in enumerate(phrase_embeddings):
                    # Cosine similarity
                    similarity = np.dot(phrase_emb, target_emb) / (
                        np.linalg.norm(phrase_emb) * np.linalg.norm(target_emb) + 1e-8
                    )

                    if similarity >= self.similarity_threshold:
                        match = SemanticMatch(
                            source_agent=source_agent.id,
                            target_agent=target_id,
                            matched_phrase=phrases[i][:100],  # Truncate for evidence
                            similarity_score=float(similarity),
                            source_line=source_agent.line_number,
                        )
                        matches.append(match)

        return matches

    def detect_connections(self, agents: list[DetectedAgent]) -> list[DetectedConnection]:
        """Detect connections at 50% confidence from semantic inference.

        Args:
            agents: List of detected agents

        Returns:
            List of detected connections with semantic confidence
        """
        # Check if embedding is available
        if self._registry is None or not self._registry.is_embedding_available():
            logger.warning("Embedding model not available, falling back to keyword matching")
            return self._keyword_fallback(agents)

        # Compute agent embeddings
        agent_embeddings = self.compute_agent_embeddings(agents)
        if agent_embeddings is None:
            return self._keyword_fallback(agents)

        # Find semantic matches
        matches = self.find_semantic_matches(agents, agent_embeddings)

        # Convert to connections
        connections: list[DetectedConnection] = []
        seen_pairs: set[tuple[str, str]] = set()

        for match in matches:
            pair = (match.source_agent, match.target_agent)
            if pair in seen_pairs:
                continue

            seen_pairs.add(pair)

            evidence = [
                f"Semantic match (similarity: {match.similarity_score:.2f})",
                f"Matched phrase: '{match.matched_phrase}'",
            ]

            connection = DetectedConnection(
                source_id=match.source_agent,
                target_id=match.target_agent,
                connection_type=ConnectionType.DELEGATION,
                confidence=self.confidence,
                confidence_level=ConnectionConfidence.INFERRED,
                evidence=evidence,
                metadata={"line_numbers": (match.source_line, 0)},
            )
            connections.append(connection)

        return connections

    def _keyword_fallback(self, agents: list[DetectedAgent]) -> list[DetectedConnection]:
        """Fallback to keyword matching when embeddings unavailable.

        Args:
            agents: List of detected agents

        Returns:
            List of detected connections based on keyword matching
        """
        connections: list[DetectedConnection] = []
        seen_pairs: set[tuple[str, str]] = set()

        agent_names = {a.name.lower(): a.id for a in agents}

        for source_agent in agents:
            if not source_agent.system_prompt:
                continue

            prompt_lower = source_agent.system_prompt.lower()

            for target_agent in agents:
                if target_agent.id == source_agent.id:
                    continue

                # Check for name mentions
                target_name_lower = target_agent.name.lower()
                target_id_lower = target_agent.id.lower()

                if target_name_lower in prompt_lower or target_id_lower in prompt_lower:
                    pair = (source_agent.id, target_agent.id)
                    if pair in seen_pairs:
                        continue

                    seen_pairs.add(pair)

                    evidence = [
                        f"Keyword match: '{target_agent.name}' found in prompt",
                        "Fallback method (embedding unavailable)",
                    ]

                    connection = DetectedConnection(
                        source_id=source_agent.id,
                        target_id=target_agent.id,
                        connection_type=ConnectionType.DELEGATION,
                        confidence=self.confidence * 0.8,  # Lower confidence for keyword
                        confidence_level=ConnectionConfidence.INFERRED,
                        evidence=evidence,
                        metadata={
                            "line_numbers": (
                                source_agent.line_number,
                                target_agent.line_number,
                            )
                        },
                    )
                    connections.append(connection)

        return connections


# ---------------------------------------------------------
# Multi-Level Connection Detector
# Combines all levels with deduplication
# ---------------------------------------------------------


class MultiLevelConnectionDetector:
    """Combines all connection detection levels with deduplication.

    Runs detection at all configured levels and merges results,
    keeping only the highest confidence connection for each pair.

    Example:
        detector = MultiLevelConnectionDetector()
        connections = detector.detect_all(agents, source_files)
    """

    def __init__(
        self,
        enable_data_flow: bool = True,
        enable_call_graph: bool = True,
        enable_semantic: bool = True,
        semantic_threshold: float = 0.6,
    ):
        """Initialize the multi-level detector.

        Args:
            enable_data_flow: Enable Level 2 data flow analysis
            enable_call_graph: Enable Level 3 call graph analysis
            enable_semantic: Enable Level 4 semantic inference
            semantic_threshold: Threshold for semantic matching
        """
        self.enable_data_flow = enable_data_flow
        self.enable_call_graph = enable_call_graph
        self.enable_semantic = enable_semantic

        # Initialize analyzers
        if enable_data_flow:
            self._data_flow_analyzer = DataFlowAnalyzer()
        if enable_call_graph:
            self._call_graph_analyzer = CallGraphAnalyzer()
        if enable_semantic:
            self._semantic_analyzer = SemanticAnalyzer(similarity_threshold=semantic_threshold)

    def detect_all(
        self, agents: list[DetectedAgent], source_files: list[Path]
    ) -> list[DetectedConnection]:
        """Run all detection levels and merge results.

        Args:
            agents: List of detected agents
            source_files: List of source file paths

        Returns:
            Deduplicated list of detected connections (highest confidence wins)
        """
        all_connections: list[DetectedConnection] = []

        # Level 2: Data Flow Analysis (80% confidence)
        if self.enable_data_flow:
            try:
                data_flow_connections = self._data_flow_analyzer.detect_connections(
                    agents, source_files
                )
                all_connections.extend(data_flow_connections)
                logger.debug(f"Level 2 found {len(data_flow_connections)} connections")
            except Exception as e:
                logger.warning(f"Data flow analysis failed: {e}")

        # Level 3: Call Graph Analysis (75% confidence)
        if self.enable_call_graph:
            try:
                call_graph_connections = self._call_graph_analyzer.detect_connections(
                    agents, source_files
                )
                all_connections.extend(call_graph_connections)
                logger.debug(f"Level 3 found {len(call_graph_connections)} connections")
            except Exception as e:
                logger.warning(f"Call graph analysis failed: {e}")

        # Level 4: Semantic Inference (50% confidence)
        if self.enable_semantic:
            try:
                semantic_connections = self._semantic_analyzer.detect_connections(agents)
                all_connections.extend(semantic_connections)
                logger.debug(f"Level 4 found {len(semantic_connections)} connections")
            except Exception as e:
                logger.warning(f"Semantic analysis failed: {e}")

        # Deduplicate: keep highest confidence for each pair
        return self._deduplicate_connections(all_connections)

    def _deduplicate_connections(
        self, connections: list[DetectedConnection]
    ) -> list[DetectedConnection]:
        """Deduplicate connections, keeping highest confidence.

        Args:
            connections: All detected connections

        Returns:
            Deduplicated list with highest confidence per pair
        """
        best_connections: dict[tuple[str, str], DetectedConnection] = {}

        for conn in connections:
            pair = (conn.source_id, conn.target_id)

            if pair not in best_connections:
                best_connections[pair] = conn
            elif conn.confidence > best_connections[pair].confidence:
                best_connections[pair] = conn

        return list(best_connections.values())


def analyze_call_graph(
    agents: list[DetectedAgent], source_files: list[Path], confidence: float = 0.75
) -> list[DetectedConnection]:
    """Convenience function to analyze call graph.

    Args:
        agents: List of detected agents
        source_files: List of source file paths
        confidence: Confidence level for detected connections

    Returns:
        List of detected connections
    """
    analyzer = CallGraphAnalyzer(confidence=confidence)
    return analyzer.detect_connections(agents, source_files)


def analyze_semantic(
    agents: list[DetectedAgent],
    confidence: float = 0.50,
    similarity_threshold: float = 0.6,
) -> list[DetectedConnection]:
    """Convenience function for semantic analysis.

    Args:
        agents: List of detected agents
        confidence: Confidence level for detected connections
        similarity_threshold: Minimum similarity for matches

    Returns:
        List of detected connections
    """
    analyzer = SemanticAnalyzer(confidence=confidence, similarity_threshold=similarity_threshold)
    return analyzer.detect_connections(agents)
