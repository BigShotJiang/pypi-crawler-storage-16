"""Scanner for LangGraph agent definitions.

Detects StateGraph, MessageGraph, and compiled workflows.
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult

logger = logging.getLogger(__name__)


class LangGraphScanner(BaseScanner):
    """Scanner for LangGraph agent definitions."""

    framework_name = "LangGraph"

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a Python file for LangGraph definitions."""
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []

        try:
            tree = self._parse_python_file(path)
        except SyntaxError:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=["Syntax Error"],
            )

        # Track graph variables: var_name -> graph_id
        graph_vars: dict[str, str] = {}

        # DEBUG: Print scanning
        print(f"DEBUG: LangGraph scanning {path}")

        for node in ast.walk(tree):
            # 1. Detect Graph Creation
            # graph = StateGraph(...) or MessageGraph(...)
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        func_name = self._get_call_name(node.value)

                        # DEBUG
                        # if func_name: print(f"DEBUG: Found call {func_name}")

                        if func_name in ("StateGraph", "MessageGraph"):
                            graph_id = self._make_id(target.id)
                            graph_vars[target.id] = graph_id

                            # Register the Graph itself as an "Agent" (Orchestrator)
                            agents.append(
                                DetectedAgent(
                                    id=graph_id,
                                    name=target.id,
                                    framework=Framework.LANGGRAPH,
                                    file_path=str(path),
                                    line_number=node.lineno,
                                    system_prompt=f"LangGraph Workflow ({func_name})",
                                    metadata={"type": "graph"},
                                )
                            )

            # 2. Detect Nodes (Agents)
            # graph.add_node("name", agent_callable)
            if isinstance(node, ast.Call):
                func_name = self._get_call_name(node)
                if func_name == "add_node" or (
                    isinstance(func_name, str) and func_name.endswith(".add_node")
                ):
                    # Extract args
                    args = [self._extract_value(a) for a in node.args]
                    if len(args) >= 2:
                        node_name = str(args[0])
                        node_callable = str(args[1])

                        # Register the Node as an Agent
                        agent_id = self._make_id(node_name)
                        agents.append(
                            DetectedAgent(
                                id=agent_id,
                                name=node_name,
                                framework=Framework.LANGGRAPH,
                                file_path=str(path),
                                line_number=node.lineno,
                                system_prompt=f"Graph Node executing: {node_callable}",
                                metadata={"type": "node", "callable": node_callable},
                            )
                        )

                        # Link Graph -> Node (Hierarchical)
                        # Try to find which graph this belongs to
                        if isinstance(node.func, ast.Attribute) and isinstance(
                            node.func.value, ast.Name
                        ):
                            graph_var = node.func.value.id
                            if graph_var in graph_vars:
                                connections.append(
                                    DetectedConnection(
                                        source_id=graph_vars[graph_var],
                                        target_id=agent_id,
                                        connection_type=ConnectionType.HIERARCHICAL,
                                        confidence=0.9,
                                        confidence_level=ConnectionConfidence.FRAMEWORK,
                                        evidence=["graph.add_node"],
                                    )
                                )

            # 3. Detect Edges (Connections)
            # graph.add_edge("start", "end")
            if isinstance(node, ast.Call):
                func_name = self._get_call_name(node)
                if func_name == "add_edge" or (
                    isinstance(func_name, str) and func_name.endswith(".add_edge")
                ):
                    args = [self._extract_value(a) for a in node.args]
                    if len(args) >= 2:
                        src = self._make_id(str(args[0]))
                        tgt = self._make_id(str(args[1]))

                        connections.append(
                            DetectedConnection(
                                source_id=src,
                                target_id=tgt,
                                connection_type=ConnectionType.DIRECT,
                                confidence=0.9,
                                confidence_level=ConnectionConfidence.FRAMEWORK,
                                evidence=["graph.add_edge"],
                            )
                        )

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=[],
        )
