"""Scanner for Microsoft Semantic Kernel agent definitions.

Semantic Kernel is an enterprise SDK for building AI agents with plugins,
planners, and memory capabilities.

Example detection targets:

    # Chat Completion Agent
    from semantic_kernel.agents import ChatCompletionAgent

    agent = ChatCompletionAgent(
        service_id="openai",
        kernel=kernel,
        name="assistant",
        instructions="You are a helpful AI assistant.",
    )

    # Multi-agent group chat
    from semantic_kernel.agents import AgentGroupChat

    chat = AgentGroupChat(
        agents=[writer_agent, reviewer_agent, editor_agent],
        termination_strategy=MaxTurnsTermination(max_turns=10),
    )

    # Plugin function
    from semantic_kernel.functions import kernel_function

    @kernel_function(description="Search the web for information")
    async def search_web(query: str) -> str:
        '''Search function implementation.'''
        pass
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult
from vantage_core.scanners.mixins import ASTExtractionMixin

logger = logging.getLogger(__name__)


class SemanticKernelScanner(BaseScanner, ASTExtractionMixin):
    """Scanner for Microsoft Semantic Kernel agent definitions.

    Detects:
    - ChatCompletionAgent, OpenAIAssistantAgent
    - AgentGroupChat for multi-agent scenarios
    - Kernel functions and plugins
    """

    framework_name = "SemanticKernel"

    # Agent classes to detect
    AGENT_CLASSES = {
        "ChatCompletionAgent",
        "OpenAIAssistantAgent",
        "AzureAssistantAgent",
        "Agent",
    }

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a Python file for Semantic Kernel agent definitions.

        Args:
            path: Path to Python file

        Returns:
            ScanResult with detected agents and connections
        """
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        errors: list[str] = []

        try:
            tree = self._parse_python_file(path)
        except SyntaxError as e:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[f"Syntax error in {path}: {e}"],
            )

        # Collect plugins and kernel functions for context
        plugins: list[str] = []

        # First pass: find agents and plugins
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                # Parse agent definitions
                agent = self._parse_agent_call(node, path)
                if agent:
                    agents.append(agent)

                # Track plugins from add_plugin calls
                if self._is_add_plugin_call(node):
                    plugin_name = self._extract_plugin_name(node)
                    if plugin_name and isinstance(plugin_name, str):
                        plugins.append(plugin_name)

            # Parse kernel_function decorators as capabilities
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if self._has_kernel_function_decorator(node):
                    plugins.append(node.name)

        # Second pass: parse AgentGroupChat for connections
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                conns = self._parse_group_chat(node, agents)
                connections.extend(conns)

        # Enrich agents with plugin info
        for agent in agents:
            if plugins and agent.system_prompt and "Plugins:" not in agent.system_prompt:
                agent.system_prompt += f"\n\nPlugins: {', '.join(plugins)}"

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=errors,
        )

    def _parse_agent_call(self, node: ast.Call, path: Path) -> DetectedAgent | None:
        """Parse Semantic Kernel agent constructor.

        Args:
            node: AST Call node
            path: Source file path

        Returns:
            DetectedAgent or None if not an agent call
        """
        func_name = self._get_call_name(node)
        if func_name not in self.AGENT_CLASSES:
            return None

        # Extract name
        name = (
            self._extract_keyword_arg(node, "name")
            or self._extract_keyword_arg(node, "id")
            or func_name
        )
        if not isinstance(name, str):
            name = func_name

        # Extract instructions (system prompt)
        system_prompt = (
            self._extract_keyword_arg(node, "instructions")
            or self._extract_keyword_arg(node, "system_message")
            or f"Semantic Kernel {func_name}"
        )
        if not isinstance(system_prompt, str):
            system_prompt = f"Semantic Kernel {func_name}"

        # Description adds context
        description = self._extract_keyword_arg(node, "description")
        if description and isinstance(description, str):
            system_prompt = f"{description}\n\n{system_prompt}"

        # Service ID indicates model backend
        service_id = self._extract_keyword_arg(node, "service_id")
        model = "gpt-4"  # Default
        if service_id and isinstance(service_id, str):
            if "azure" in service_id.lower():
                model = "azure-openai"
            elif "openai" in service_id.lower():
                model = "gpt-4"

        # Execution settings
        execution_settings = self._extract_keyword_arg(node, "execution_settings")
        if execution_settings and isinstance(execution_settings, dict):
            if "temperature" in execution_settings:
                system_prompt += f"\n\nTemperature: {execution_settings['temperature']}"

        return DetectedAgent(
            id=self._make_id(name),
            name=name,
            system_prompt=system_prompt,
            file_path=str(path),
            line_number=node.lineno,
            framework=Framework.SEMANTIC_KERNEL,
            metadata={"model": model},
        )

    def _parse_group_chat(
        self, node: ast.Call, agents: list[DetectedAgent]
    ) -> list[DetectedConnection]:
        """Parse AgentGroupChat for agent connections.

        Group chats are modeled as fully-connected meshes where all agents
        can communicate with all other agents.

        Args:
            node: AST Call node
            agents: List of detected agents

        Returns:
            List of detected connections
        """
        connections: list[DetectedConnection] = []
        func_name = self._get_call_name(node)

        if func_name != "AgentGroupChat":
            return connections

        # If we have multiple agents, create mesh connections
        if len(agents) > 1:
            agent_ids = [a.id for a in agents]

            # Group chat = fully connected mesh
            for i, source in enumerate(agent_ids):
                for target in agent_ids[i + 1 :]:
                    # Bidirectional connections
                    connections.append(
                        DetectedConnection(
                            source_id=source,
                            target_id=target,
                            connection_type=ConnectionType.BROADCAST,
                            confidence=0.95,
                            confidence_level=ConnectionConfidence.FRAMEWORK,
                            evidence=["Semantic Kernel AgentGroupChat mesh connection"],
                        )
                    )
                    connections.append(
                        DetectedConnection(
                            source_id=target,
                            target_id=source,
                            connection_type=ConnectionType.BROADCAST,
                            confidence=0.95,
                            confidence_level=ConnectionConfidence.FRAMEWORK,
                            evidence=["Semantic Kernel AgentGroupChat mesh connection"],
                        )
                    )

        return connections

    def _is_add_plugin_call(self, node: ast.Call) -> bool:
        """Check if this is a kernel.add_plugin() call.

        Args:
            node: AST Call node

        Returns:
            True if this is an add_plugin call
        """
        if isinstance(node.func, ast.Attribute):
            return node.func.attr == "add_plugin"
        return False

    def _extract_plugin_name(self, node: ast.Call) -> str | None:
        """Extract plugin name from add_plugin call.

        Args:
            node: AST Call node

        Returns:
            Plugin name or None
        """
        # Check first positional arg
        if node.args:
            value = self._extract_value(node.args[0])
            if isinstance(value, str):
                return value

        # Check plugin_name keyword
        plugin_name = self._extract_keyword_arg(node, "plugin_name")
        if isinstance(plugin_name, str):
            return plugin_name

        # Check plugin keyword
        plugin = self._extract_keyword_arg(node, "plugin")
        if isinstance(plugin, str):
            return plugin

        return None

    def _has_kernel_function_decorator(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
        """Check if a function has @kernel_function decorator.

        Args:
            node: Function definition node

        Returns:
            True if decorated with kernel_function
        """
        for decorator in node.decorator_list:
            if isinstance(decorator, ast.Name):
                if decorator.id == "kernel_function":
                    return True
            elif isinstance(decorator, ast.Call):
                if self._get_call_name(decorator) == "kernel_function":
                    return True
        return False
