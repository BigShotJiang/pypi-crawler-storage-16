"""Scanner for Skyvern workflow-based browser automation agents.

Skyvern is a browser automation platform that uses LLMs and computer vision
to interact with websites through workflow compositions.

Example detection targets:

    # Workflow with TaskBlocks
    from skyvern.forge.sdk.workflow.models.block import TaskBlock, NavigationBlock
    from skyvern.forge.sdk.workflow.models.workflow import Workflow

    task_block = TaskBlock(
        label="research_task",
        title="Research Agent",
        url="https://example.com",
        navigation_goal="Find and extract data",
        complete_criterion="Data successfully extracted",
    )

    # Skyvern client usage
    from skyvern import Skyvern

    skyvern = Skyvern(api_key="...")
    result = await skyvern.run_task(
        url="https://example.com",
        prompt="Extract product information"
    )

    # YAML workflow configuration
    # workflow.yaml
    title: "Data Extraction Workflow"
    blocks:
      - block_type: task
        label: extraction_agent
        navigation_goal: "Navigate and extract data"
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import Any

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult
from vantage_core.scanners.mixins import ASTExtractionMixin, ConfigFileMixin

logger = logging.getLogger(__name__)


class SkyvernScanner(BaseScanner, ASTExtractionMixin, ConfigFileMixin):
    """Scanner for Skyvern workflow-based browser automation.

    Detects:
    - TaskBlock, NavigationBlock, ExtractionBlock definitions
    - Workflow and WorkflowDefinition compositions
    - Skyvern client task executions
    - YAML workflow configurations
    - ForgeClient API patterns
    """

    framework_name = "Skyvern"

    # Block types that represent agent-like behavior
    BLOCK_TYPES = {
        "TaskBlock",
        "ActionBlock",
        "NavigationBlock",
        "ExtractionBlock",
        "ValidationBlock",
        "LoginBlock",
        "FileDownloadBlock",
        "ForLoopBlock",
        "CodeBlock",
        "TextPromptBlock",
        "HumanInteractionBlock",
        "NavigationV2Block",
        "TaskV2Block",
        "FileParserBlock",
        "SendEmailBlock",
        "DownloadToS3Block",
        "UploadToS3Block",
    }

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a file for Skyvern agent definitions.

        Args:
            path: Path to file (Python or YAML)

        Returns:
            ScanResult with detected agents
        """
        # Handle YAML files
        if path.suffix in [".yaml", ".yml"]:
            return self._scan_yaml_file(path)

        return self._scan_python_file(path)

    def _scan_python_file(self, path: Path) -> ScanResult:
        """Scan a Python file for Skyvern definitions.

        Args:
            path: Path to Python file

        Returns:
            ScanResult with detected agents
        """
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        errors: list[str] = []

        try:
            tree = self._parse_python_file(path)
        except SyntaxError as e:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[f"Syntax error in {path}: {e}"],
            )

        # Check for skyvern imports
        content = path.read_text(encoding="utf-8")
        if not self._has_skyvern_imports(content):
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[],
            )

        # Track block labels for connection detection
        block_order: list[str] = []

        # First pass: find block definitions
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        agent = self._parse_block_call(target, node.value, path)
                        if agent:
                            agents.append(agent)
                            # Track label for connections
                            label = agent.metadata.get("label", agent.id)
                            if label not in block_order:
                                block_order.append(label)

            # Also check for standalone block calls
            elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
                agent = self._parse_standalone_block(node.value, path)
                if agent:
                    agents.append(agent)
                    label = agent.metadata.get("label", agent.id)
                    if label not in block_order:
                        block_order.append(label)

        # Second pass: find Skyvern client usage
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        agent = self._parse_skyvern_client(target, node.value, path)
                        if agent:
                            agents.append(agent)

        # Third pass: find run_task or run_workflow calls
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                agent = self._parse_task_call(node, path)
                if agent:
                    agents.append(agent)

        # Fourth pass: detect workflow connections
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                conns = self._parse_workflow_definition(node, block_order)
                connections.extend(conns)

        # Infer sequential connections from block order if no explicit ones found
        if not connections and len(block_order) > 1:
            for i in range(len(block_order) - 1):
                connections.append(
                    DetectedConnection(
                        source_id=self._make_id(block_order[i]),
                        target_id=self._make_id(block_order[i + 1]),
                        connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                        confidence=0.85,
                        confidence_level=ConnectionConfidence.HEURISTIC,
                        evidence=[f"Skyvern block order: {block_order[i]} -> {block_order[i + 1]}"],
                    )
                )

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=errors,
        )

    def _has_skyvern_imports(self, content: str) -> bool:
        """Check if file has Skyvern imports.

        Args:
            content: File content as string

        Returns:
            True if skyvern imports are present
        """
        return any(
            p in content
            for p in [
                "from skyvern",
                "import skyvern",
                "from skyvern_llamaindex",
                "from skyvern_langchain",
            ]
        )

    def _parse_block_call(
        self, target: ast.Name, call: ast.Call, path: Path
    ) -> DetectedAgent | None:
        """Parse block instantiation assigned to a variable.

        Args:
            target: Variable name target
            call: AST Call node
            path: Source file path

        Returns:
            DetectedAgent or None if not a block call
        """
        call_name = self._get_call_name(call)
        if call_name not in self.BLOCK_TYPES:
            return None

        return self._build_agent_from_block(call, path, target.id, call_name)

    def _parse_standalone_block(self, call: ast.Call, path: Path) -> DetectedAgent | None:
        """Parse standalone block call without assignment.

        Args:
            call: AST Call node
            path: Source file path

        Returns:
            DetectedAgent or None if not a block call
        """
        call_name = self._get_call_name(call)
        if call_name not in self.BLOCK_TYPES:
            return None

        # Use label as identifier if available
        label = self._extract_keyword_arg(call, "label")
        var_name = label if isinstance(label, str) else call_name.lower()

        return self._build_agent_from_block(call, path, var_name, call_name)

    def _build_agent_from_block(
        self, call: ast.Call, path: Path, var_name: str, block_type: str
    ) -> DetectedAgent:
        """Build DetectedAgent from block call.

        Args:
            call: AST Call node
            path: Source file path
            var_name: Variable name
            block_type: Type of block

        Returns:
            DetectedAgent instance
        """
        # Extract block properties
        label = self._extract_keyword_arg(call, "label")
        title = self._extract_keyword_arg(call, "title")
        url = self._extract_keyword_arg(call, "url")
        nav_goal = self._extract_keyword_arg(call, "navigation_goal")
        complete = self._extract_keyword_arg(call, "complete_criterion")
        terminate = self._extract_keyword_arg(call, "terminate_criterion")
        extraction = self._extract_keyword_arg(call, "data_extraction_goal")

        # Build system prompt from block properties
        prompt_parts: list[str] = []
        if nav_goal and isinstance(nav_goal, str):
            prompt_parts.append(f"Navigation Goal: {nav_goal}")
        if complete and isinstance(complete, str):
            prompt_parts.append(f"Complete Criterion: {complete}")
        if terminate and isinstance(terminate, str):
            prompt_parts.append(f"Terminate Criterion: {terminate}")
        if extraction and isinstance(extraction, str):
            prompt_parts.append(f"Data Extraction Goal: {extraction}")

        system_prompt = "\n\n".join(prompt_parts) if prompt_parts else f"Skyvern {block_type}"

        # Determine agent name
        agent_name = title if isinstance(title, str) else var_name
        agent_id = label if isinstance(label, str) else var_name

        # Build raw config
        raw_config: dict[str, Any] = {
            "block_type": block_type,
            "label": label,
        }
        if url:
            raw_config["url"] = url

        return DetectedAgent(
            id=self._make_id(agent_id),
            name=self._format_display_name(agent_name),
            framework=Framework.SKYVERN,
            file_path=str(path),
            line_number=call.lineno,
            system_prompt=system_prompt,
            metadata=raw_config,
        )

    def _parse_skyvern_client(
        self, target: ast.Name, call: ast.Call, path: Path
    ) -> DetectedAgent | None:
        """Parse Skyvern client instantiation.

        Args:
            target: Variable name target
            call: AST Call node
            path: Source file path

        Returns:
            DetectedAgent or None if not a Skyvern client
        """
        call_name = self._get_call_name(call)
        if call_name not in ["Skyvern", "ForgeClient", "AsyncForgeClient"]:
            return None

        return DetectedAgent(
            id=self._make_id(target.id),
            name=self._format_display_name(target.id),
            framework=Framework.SKYVERN,
            file_path=str(path),
            line_number=call.lineno,
            system_prompt=f"Skyvern {call_name} client",
            metadata={"client_type": call_name},
        )

    def _parse_task_call(self, call: ast.Call, path: Path) -> DetectedAgent | None:
        """Parse run_task or run_workflow calls.

        Args:
            call: AST Call node
            path: Source file path

        Returns:
            DetectedAgent or None if not a task call
        """
        # Check for method calls like skyvern.run_task()
        if not isinstance(call.func, ast.Attribute):
            return None

        method_name = call.func.attr
        if method_name not in ["run_task", "run_workflow", "create_task"]:
            return None

        # Extract task parameters
        url = self._extract_keyword_arg(call, "url")
        prompt = self._extract_keyword_arg(call, "prompt")
        navigation_goal = self._extract_keyword_arg(call, "navigation_goal")

        # Build system prompt
        prompt_parts: list[str] = []
        if prompt and isinstance(prompt, str):
            prompt_parts.append(f"Task: {prompt}")
        if navigation_goal and isinstance(navigation_goal, str):
            prompt_parts.append(f"Navigation Goal: {navigation_goal}")

        system_prompt = "\n\n".join(prompt_parts) if prompt_parts else f"Skyvern {method_name}"

        # Generate name from prompt or method
        if prompt and isinstance(prompt, str):
            words = prompt.split()[:3]
            agent_name = "_".join(words).lower()
        else:
            agent_name = method_name

        return DetectedAgent(
            id=self._make_id(agent_name),
            name=self._format_display_name(agent_name),
            framework=Framework.SKYVERN,
            file_path=str(path),
            line_number=call.lineno,
            system_prompt=system_prompt,
            metadata={
                "method": method_name,
                "url": url,
            },
        )

    def _parse_workflow_definition(
        self, call: ast.Call, block_order: list[str]
    ) -> list[DetectedConnection]:
        """Parse Workflow or WorkflowDefinition for connections.

        Args:
            call: AST Call node
            block_order: List of block labels in order

        Returns:
            List of detected connections
        """
        connections: list[DetectedConnection] = []

        call_name = self._get_call_name(call)
        if call_name not in ["Workflow", "WorkflowDefinition"]:
            return connections

        # Look for blocks parameter
        blocks_node = self._get_keyword_node(call, "blocks")
        if blocks_node and isinstance(blocks_node, ast.List):
            block_labels: list[str] = []
            for elt in blocks_node.elts:
                if isinstance(elt, ast.Call):
                    label = self._extract_keyword_arg(elt, "label")
                    if label and isinstance(label, str):
                        block_labels.append(label)

            # Create sequential connections
            for i in range(len(block_labels) - 1):
                connections.append(
                    DetectedConnection(
                        source_id=self._make_id(block_labels[i]),
                        target_id=self._make_id(block_labels[i + 1]),
                        connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                        confidence=0.95,
                        confidence_level=ConnectionConfidence.FRAMEWORK,
                        evidence=[
                            f"Skyvern workflow blocks: {block_labels[i]} -> {block_labels[i + 1]}"
                        ],
                    )
                )

        return connections

    def _get_keyword_node(self, node: ast.Call, arg_name: str) -> ast.expr | None:
        """Get the AST node for a keyword argument.

        Args:
            node: AST Call node
            arg_name: Keyword argument name

        Returns:
            AST expression node or None
        """
        for keyword in node.keywords:
            if keyword.arg == arg_name:
                return keyword.value
        return None

    def _scan_yaml_file(self, path: Path) -> ScanResult:
        """Scan a YAML workflow file.

        Args:
            path: Path to YAML file

        Returns:
            ScanResult with detected agents
        """
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []

        config = self._parse_yaml_config(path)
        if not config:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[],
            )

        # Extract workflow title
        workflow_title = config.get("title", "Skyvern Workflow")

        # Process blocks
        blocks = config.get("blocks", [])
        block_labels: list[str] = []

        for block in blocks:
            if not isinstance(block, dict):
                continue

            block_type = block.get("block_type", "task")
            label = block.get("label", f"block_{len(agents)}")

            # Build system prompt
            prompt_parts: list[str] = []
            if block.get("navigation_goal"):
                prompt_parts.append(f"Navigation Goal: {block['navigation_goal']}")
            if block.get("complete_criterion"):
                prompt_parts.append(f"Complete Criterion: {block['complete_criterion']}")
            if block.get("data_extraction_goal"):
                prompt_parts.append(f"Data Extraction Goal: {block['data_extraction_goal']}")

            system_prompt = "\n\n".join(prompt_parts) if prompt_parts else f"Skyvern {block_type}"

            agent_name = block.get("title", label)

            agents.append(
                DetectedAgent(
                    id=self._make_id(label),
                    name=self._format_display_name(agent_name),
                    framework=Framework.SKYVERN,
                    file_path=str(path),
                    line_number=0,
                    system_prompt=system_prompt,
                    metadata={
                        "block_type": block_type,
                        "label": label,
                        "url": block.get("url"),
                        "workflow_title": workflow_title,
                    },
                )
            )

            block_labels.append(label)

        # Create sequential connections
        for i in range(len(block_labels) - 1):
            connections.append(
                DetectedConnection(
                    source_id=self._make_id(block_labels[i]),
                    target_id=self._make_id(block_labels[i + 1]),
                    connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                    confidence=0.95,
                    confidence_level=ConnectionConfidence.FRAMEWORK,
                    evidence=[f"Skyvern YAML workflow: {block_labels[i]} -> {block_labels[i + 1]}"],
                )
            )

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=[],
        )
