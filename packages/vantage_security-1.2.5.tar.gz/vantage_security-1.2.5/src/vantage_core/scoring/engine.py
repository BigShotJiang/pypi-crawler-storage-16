"""
ATSS Scoring Engine - Agent Topology Security Score.

Calculates a 0-100 security score based on:
- Vulnerability findings
- Trust boundary analysis
- Communication patterns
- Agent-level risk
"""

from dataclasses import dataclass, field
from typing import Any

from vantage_core.models import (
    DetectedAgent,
    DetectedConnection,
    SecurityFinding,
    Severity,
)
from vantage_core.topology.graph import AgentGraph


@dataclass
class ScoreBreakdown:
    """Breakdown of score components."""

    vulnerability_score: float = 100.0  # Penalized by findings
    trust_boundary_score: float = 100.0  # Trust boundary violations
    communication_score: float = 100.0  # Communication pattern risks
    agent_risk_score: float = 100.0  # Individual agent risks


@dataclass
class ScoreResult:
    """Result of security scoring."""

    score: int  # 0-100
    grade: str  # A-F
    breakdown: ScoreBreakdown = field(default_factory=ScoreBreakdown)
    recommendations: list[str] = field(default_factory=list)
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "score": self.score,
            "grade": self.grade,
            "breakdown": {
                "vulnerability_score": self.breakdown.vulnerability_score,
                "trust_boundary_score": self.breakdown.trust_boundary_score,
                "communication_score": self.breakdown.communication_score,
                "agent_risk_score": self.breakdown.agent_risk_score,
            },
            "recommendations": self.recommendations,
            "details": self.details,
        }


# Severity weights for scoring
SEVERITY_WEIGHTS = {
    Severity.CRITICAL: 25,
    Severity.HIGH: 15,
    Severity.MEDIUM: 8,
    Severity.LOW: 3,
    Severity.INFO: 0,
}


def calculate_grade(score: int) -> str:
    """Convert score to letter grade."""
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "F"


class ScoringEngine:
    """
    ATSS (Agent Topology Security Score) calculation engine.

    Provides a comprehensive security score for multi-agent systems.
    """

    def __init__(
        self,
        vulnerability_weight: float = 0.4,
        trust_weight: float = 0.25,
        communication_weight: float = 0.2,
        agent_weight: float = 0.15,
    ) -> None:
        """
        Initialize scoring engine.

        Args:
            vulnerability_weight: Weight for vulnerability score
            trust_weight: Weight for trust boundary score
            communication_weight: Weight for communication score
            agent_weight: Weight for agent risk score
        """
        self.vulnerability_weight = vulnerability_weight
        self.trust_weight = trust_weight
        self.communication_weight = communication_weight
        self.agent_weight = agent_weight

    def calculate_score(
        self,
        findings: list[SecurityFinding],
        graph: AgentGraph | None = None,
        agents: list[DetectedAgent] | None = None,
        connections: list[DetectedConnection] | None = None,
    ) -> ScoreResult:
        """
        Calculate the ATSS security score.

        Args:
            findings: Security findings from scan
            graph: Agent topology graph
            agents: Detected agents (if no graph)
            connections: Detected connections (if no graph)

        Returns:
            ScoreResult with score, grade, and breakdown
        """
        breakdown = ScoreBreakdown()
        recommendations: list[str] = []
        details: dict[str, Any] = {}

        # Calculate vulnerability score (deduct points for findings)
        vuln_score, vuln_details = self._calculate_vulnerability_score(findings)
        breakdown.vulnerability_score = vuln_score
        details["vulnerability"] = vuln_details

        # Calculate trust boundary score
        if graph:
            trust_score, trust_details = self._calculate_trust_score(graph)
            breakdown.trust_boundary_score = trust_score
            details["trust_boundary"] = trust_details

            # Calculate communication score
            comm_score, comm_details = self._calculate_communication_score(graph)
            breakdown.communication_score = comm_score
            details["communication"] = comm_details

            # Calculate agent risk score
            agent_score, agent_details = self._calculate_agent_risk_score(graph)
            breakdown.agent_risk_score = agent_score
            details["agent_risk"] = agent_details
        else:
            # No graph - use basic scoring
            if agents:
                agent_count = len(agents)
                breakdown.agent_risk_score = max(0, 100 - (agent_count * 2))

        # Calculate weighted final score
        final_score = (
            breakdown.vulnerability_score * self.vulnerability_weight
            + breakdown.trust_boundary_score * self.trust_weight
            + breakdown.communication_score * self.communication_weight
            + breakdown.agent_risk_score * self.agent_weight
        )

        # Ensure score is in valid range
        final_score = max(0, min(100, int(final_score)))

        # Generate recommendations
        recommendations = self._generate_recommendations(breakdown, findings, graph)

        return ScoreResult(
            score=final_score,
            grade=calculate_grade(final_score),
            breakdown=breakdown,
            recommendations=recommendations,
            details=details,
        )

    def _calculate_vulnerability_score(
        self,
        findings: list[SecurityFinding],
    ) -> tuple[float, dict]:
        """Calculate vulnerability component score."""
        if not findings:
            return 100.0, {"finding_count": 0, "deductions": 0}

        total_deduction = 0
        severity_counts = {s: 0 for s in Severity}

        for finding in findings:
            deduction = SEVERITY_WEIGHTS.get(finding.severity, 0)
            # Apply confidence modifier
            deduction *= finding.confidence
            total_deduction += deduction
            severity_counts[finding.severity] += 1

        # Cap deduction at 100
        total_deduction = min(100, total_deduction)
        score = max(0, 100 - total_deduction)

        return score, {
            "finding_count": len(findings),
            "deductions": total_deduction,
            "by_severity": {s.value: c for s, c in severity_counts.items() if c > 0},
        }

    def _calculate_trust_score(self, graph: AgentGraph) -> tuple[float, dict]:
        """Calculate trust boundary component score."""
        trust_boundaries = graph.get_trust_boundaries()
        boundary_count = len(trust_boundaries)

        if boundary_count == 0:
            return 100.0, {"boundary_count": 0}

        # Deduct points for each trust boundary crossing
        # More crossings = higher risk
        deduction = min(50, boundary_count * 10)
        score = max(0, 100 - deduction)

        return score, {
            "boundary_count": boundary_count,
            "boundaries": trust_boundaries[:10],  # First 10
        }

    def _calculate_communication_score(self, graph: AgentGraph) -> tuple[float, dict]:
        """Calculate communication pattern component score."""
        connection_count = graph.connection_count
        agent_count = graph.agent_count

        if agent_count == 0:
            return 100.0, {"pattern": "no_agents"}

        # Calculate connectivity ratio
        max_connections = agent_count * (agent_count - 1)
        if max_connections == 0:
            return 100.0, {"pattern": "single_agent"}

        connectivity = connection_count / max_connections

        # High connectivity can indicate risk (fully connected mesh)
        # Low connectivity can indicate isolation (good)
        if connectivity > 0.7:
            score = 60  # Highly connected - risky
            pattern = "highly_connected"
        elif connectivity > 0.4:
            score = 80  # Moderately connected
            pattern = "moderate"
        else:
            score = 100  # Well isolated
            pattern = "isolated"

        return score, {
            "connectivity_ratio": round(connectivity, 2),
            "pattern": pattern,
        }

    def _calculate_agent_risk_score(self, graph: AgentGraph) -> tuple[float, dict]:
        """Calculate agent-level risk component score."""
        agents = graph.get_agents()
        if not agents:
            return 100.0, {"agent_count": 0}

        total_risk = 0
        risk_factors: dict[str, list[str]] = {
            "low_trust": [],
            "high_exposure": [],
            "many_tools": [],
        }

        for agent in agents:
            # Low trust agents are risky
            if agent.trust_level <= 2:
                total_risk += 5
                risk_factors["low_trust"].append(agent.name)

            # Entry points with low trust are very risky
            if agent.id in graph.get_entry_points() and agent.trust_level <= 2:
                total_risk += 10
                risk_factors["high_exposure"].append(agent.name)

            # Many tools = more attack surface
            if len(agent.tools) > 5:
                total_risk += 3
                risk_factors["many_tools"].append(agent.name)

        score = max(0, 100 - total_risk)

        return score, {
            "agent_count": len(agents),
            "risk_factors": {k: v for k, v in risk_factors.items() if v},
        }

    def _generate_recommendations(
        self,
        breakdown: ScoreBreakdown,
        findings: list[SecurityFinding],
        graph: AgentGraph | None,
    ) -> list[str]:
        """Generate actionable recommendations."""
        recommendations = []

        # Vulnerability recommendations
        critical_findings = [f for f in findings if f.severity == Severity.CRITICAL]
        high_findings = [f for f in findings if f.severity == Severity.HIGH]

        if critical_findings:
            recommendations.append(
                f"URGENT: Address {len(critical_findings)} critical vulnerabilities immediately"
            )
        if high_findings:
            recommendations.append(f"Address {len(high_findings)} high-severity vulnerabilities")

        # Trust boundary recommendations
        if breakdown.trust_boundary_score < 70:
            recommendations.append(
                "Review trust boundaries between agents - consider isolating untrusted agents"
            )

        # Communication recommendations
        if breakdown.communication_score < 70:
            recommendations.append(
                "Reduce agent connectivity - implement principle of least privilege"
            )

        # Agent risk recommendations
        if breakdown.agent_risk_score < 70:
            recommendations.append("Review low-trust agents at entry points - add input validation")

        if not recommendations:
            recommendations.append("No critical issues found - maintain current security posture")

        return recommendations
