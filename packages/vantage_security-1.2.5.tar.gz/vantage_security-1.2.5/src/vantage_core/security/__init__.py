"""
Vantage Core Security Module - AI Agent Security Testing Platform

This module provides security scanning and analysis capabilities for
multi-agent AI systems across multiple frameworks.
"""

from vantage_core.security.audit import AuditEvent, AuditEventType, AuditLogger
from vantage_core.security.models import (
    AgentCommunication,
    MAASCategory,
    OWASPCategory,
    SecurityAgent,
    SecurityFinding,
    SecurityScanResult,
    SecurityTool,
    Severity,
    TrustLevel,
    VulnerabilityCategory,
)
from vantage_core.security.registry import SecurityScannerRegistry

__version__ = "1.0.0"

__all__ = [
    # Enums
    "Severity",
    "OWASPCategory",
    "MAASCategory",
    "VulnerabilityCategory",
    "TrustLevel",
    # Data classes
    "SecurityFinding",
    "SecurityScanResult",
    "SecurityAgent",
    "SecurityTool",
    "AgentCommunication",
    # Registry
    "SecurityScannerRegistry",
    # Audit
    "AuditLogger",
    "AuditEvent",
    "AuditEventType",
]
