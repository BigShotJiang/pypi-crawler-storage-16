"""
Enhanced analysis modules for improved security detection.

This package contains advanced analysis capabilities:
- Entropy-based secret detection
- Usage context analysis
- Path-sensitive analysis
- Confidence scoring models
"""

from vantage_core.security.analysis.secret_context import (
    EntropyAnalysis,
    SecretContext,
    SecretContextAnalyzer,
    UsageContext,
    UsageType,
)
from vantage_core.security.analysis.severity_adjuster import (
    SeverityAdjuster,
    SeverityAdjustmentConfig,
    SeverityAdjustmentReason,
    adjust_findings,
)

__all__ = [
    "SecretContextAnalyzer",
    "EntropyAnalysis",
    "SecretContext",
    "UsageContext",
    "UsageType",
    "SeverityAdjuster",
    "SeverityAdjustmentConfig",
    "SeverityAdjustmentReason",
    "adjust_findings",
]
