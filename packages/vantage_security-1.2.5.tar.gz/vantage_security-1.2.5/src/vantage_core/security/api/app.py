"""
FastAPI Application for Vantage Security Platform.

This module configures and creates the main FastAPI application
with security middleware, CORS, and API routers.
"""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from vantage_core.security.api.config import get_settings, validate_settings_at_startup
from vantage_core.security.api.routes import router as security_router


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """
    Application lifespan handler.

    Handles startup and shutdown events for the application.
    """
    # Startup
    settings = get_settings()

    # Initialize database if enabled
    if settings.use_database:
        try:
            from vantage_core.security.api.database.connection import init_db

            await init_db()
        except Exception as e:
            print(f"Warning: Database initialization failed: {e}")

    yield

    # Shutdown
    if settings.use_database:
        try:
            from vantage_core.security.api.database.connection import close_db

            await close_db()
        except Exception:
            pass


def create_app() -> FastAPI:
    """
    Create and configure the FastAPI application.

    Returns:
        Configured FastAPI application instance
    """
    # Validate settings at startup
    try:
        settings = validate_settings_at_startup()
    except RuntimeError as e:
        # In development, create app anyway but log warning
        print(f"Warning: {e}")
        settings = None

    if settings is None:
        # Fallback settings for development
        from vantage_core.security.api.config import Settings

        try:
            settings = Settings()
        except Exception:
            # Create minimal app if settings fail
            settings = None

    app = FastAPI(
        title="Vantage Security API",
        description="Security scanning API for multi-agent AI systems",
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        lifespan=lifespan,
    )

    # CORS configuration
    cors_origins = ["http://localhost:3000"]
    if settings:
        cors_origins = settings.cors_origins

    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Global exception handler
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        """Handle uncaught exceptions."""
        return JSONResponse(
            status_code=500,
            content={
                "error": "internal_server_error",
                "message": (
                    str(exc) if settings and settings.debug else "An internal error occurred"
                ),
            },
        )

    # Health check endpoint
    @app.get("/health")
    async def health_check():
        """Health check endpoint."""
        health_status = {
            "status": "healthy",
            "version": "1.0.0",
        }

        # Check database if enabled
        if settings and settings.use_database:
            try:
                from vantage_core.security.api.database.connection import (
                    check_database_health,
                )

                db_health = await check_database_health()
                health_status["database"] = db_health.get("status", "unknown")
            except Exception:
                health_status["database"] = "unhealthy"

        return health_status

    # Include API routers
    api_prefix = "/api/v1"
    if settings:
        api_prefix = settings.api_v1_prefix

    app.include_router(security_router, prefix=api_prefix)

    # Include additional routers if available
    try:
        from vantage_core.security.api.routes_v1 import router as v1_router

        app.include_router(v1_router, prefix=api_prefix)
    except ImportError:
        pass

    try:
        from vantage_core.security.api.dashboard_routes import (
            router as dashboard_router,
        )

        app.include_router(dashboard_router, prefix=f"{api_prefix}/dashboard")
    except ImportError:
        pass

    try:
        from vantage_core.security.api.visualization_routes import router as viz_router

        app.include_router(viz_router, prefix=f"{api_prefix}/visualizations")
    except ImportError:
        pass

    try:
        from vantage_core.security.api.webhook_routes import router as webhook_router

        app.include_router(webhook_router, prefix=f"{api_prefix}/webhooks")
    except ImportError:
        pass

    return app


# Create default application instance
app = create_app()
