"""
User Repository for Vantage Security Platform.

This module provides data access operations for User entities
with specialized methods for authentication and user management.
"""

import hashlib
from collections.abc import Sequence
from datetime import datetime
from uuid import UUID

from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from vantage_core.security.api.database.models import APIKey, User, UserRole
from vantage_core.security.api.database.repositories.base import BaseRepository


class UserRepository(BaseRepository[User]):
    """
    Repository for User operations.

    Provides specialized methods for user authentication,
    management, and related operations.
    """

    def __init__(self):
        """Initialize user repository."""
        super().__init__(User)

    async def get_by_email(
        self,
        db: AsyncSession,
        email: str,
    ) -> User | None:
        """
        Get user by email (case-insensitive).

        Args:
            db: Database session
            email: User email address

        Returns:
            User if found, None otherwise
        """
        result = await db.execute(select(User).where(User.email.ilike(email)))
        return result.scalar_one_or_none()

    async def get_by_api_key(
        self,
        db: AsyncSession,
        api_key: str,
    ) -> User | None:
        """
        Get user by API key.

        Args:
            db: Database session
            api_key: Plain text API key

        Returns:
            User if found and key is valid, None otherwise
        """
        # Hash the API key for lookup
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()

        result = await db.execute(
            select(User)
            .join(APIKey, APIKey.user_id == User.id)
            .where(
                and_(
                    APIKey.key_hash == key_hash,
                    APIKey.is_active == True,
                    User.is_active == True,
                )
            )
            .options(selectinload(User.api_keys))
        )
        return result.scalar_one_or_none()

    async def create_user(
        self,
        db: AsyncSession,
        email: str,
        hashed_password: str | None = None,
        name: str | None = None,
        role: UserRole = UserRole.DEVELOPER,
        is_verified: bool = False,
    ) -> User:
        """
        Create a new user.

        Args:
            db: Database session
            email: User email address
            hashed_password: Pre-hashed password (None for OAuth-only)
            name: User display name
            role: User role for RBAC
            is_verified: Whether email is verified

        Returns:
            Created user instance
        """
        user_data = {
            "email": email.lower(),
            "hashed_password": hashed_password,
            "name": name,
            "role": role,
            "is_active": True,
            "is_verified": is_verified,
            "is_mfa_enabled": False,
            "failed_login_attempts": 0,
        }
        return await self.create(db, user_data)

    async def update_password(
        self,
        db: AsyncSession,
        user_id: UUID | str,
        hashed_password: str,
    ) -> User | None:
        """
        Update user password.

        Args:
            db: Database session
            user_id: User UUID
            hashed_password: New hashed password

        Returns:
            Updated user if found
        """
        return await self.update(
            db,
            user_id,
            {
                "hashed_password": hashed_password,
                "updated_at": datetime.utcnow(),
            },
        )

    async def verify_email(
        self,
        db: AsyncSession,
        user_id: UUID | str,
    ) -> User | None:
        """
        Mark user email as verified.

        Args:
            db: Database session
            user_id: User UUID

        Returns:
            Updated user if found
        """
        return await self.update(
            db,
            user_id,
            {
                "is_verified": True,
                "updated_at": datetime.utcnow(),
            },
        )

    async def get_active_users(
        self,
        db: AsyncSession,
        skip: int = 0,
        limit: int = 100,
    ) -> Sequence[User]:
        """
        Get active users with pagination.

        Args:
            db: Database session
            skip: Number of records to skip
            limit: Maximum records to return

        Returns:
            List of active users
        """
        result = await db.execute(
            select(User).where(User.is_active == True).offset(skip).limit(limit)
        )
        return result.scalars().all()

    async def get_by_role(
        self,
        db: AsyncSession,
        role: UserRole,
        skip: int = 0,
        limit: int = 100,
    ) -> Sequence[User]:
        """
        Get users by role.

        Args:
            db: Database session
            role: User role to filter by
            skip: Number of records to skip
            limit: Maximum records to return

        Returns:
            List of users with specified role
        """
        result = await db.execute(
            select(User)
            .where(
                and_(
                    User.role == role,
                    User.is_active == True,
                )
            )
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()

    async def increment_failed_logins(
        self,
        db: AsyncSession,
        user_id: UUID | str,
    ) -> int:
        """
        Increment failed login counter.

        Args:
            db: Database session
            user_id: User UUID

        Returns:
            New failed login count
        """
        user = await self.get_by_id(db, user_id)
        if not user:
            return 0

        new_count = user.failed_login_attempts + 1
        await self.update(db, user_id, {"failed_login_attempts": new_count})
        return new_count

    async def reset_failed_logins(
        self,
        db: AsyncSession,
        user_id: UUID | str,
    ) -> None:
        """
        Reset failed login counter and unlock account.

        Args:
            db: Database session
            user_id: User UUID
        """
        await self.update(
            db,
            user_id,
            {
                "failed_login_attempts": 0,
                "locked_until": None,
            },
        )

    async def lock_account(
        self,
        db: AsyncSession,
        user_id: UUID | str,
        until: datetime,
    ) -> User | None:
        """
        Lock user account until specified time.

        Args:
            db: Database session
            user_id: User UUID
            until: Datetime when lock expires

        Returns:
            Updated user if found
        """
        return await self.update(db, user_id, {"locked_until": until})

    async def update_last_login(
        self,
        db: AsyncSession,
        user_id: UUID | str,
    ) -> None:
        """
        Update user's last login timestamp.

        Args:
            db: Database session
            user_id: User UUID
        """
        await self.update(db, user_id, {"last_login_at": datetime.utcnow()})

    async def setup_mfa(
        self,
        db: AsyncSession,
        user_id: UUID | str,
        mfa_secret: str,
        backup_codes: list[str],
    ) -> User | None:
        """
        Configure MFA for user.

        Args:
            db: Database session
            user_id: User UUID
            mfa_secret: TOTP secret
            backup_codes: List of hashed backup codes

        Returns:
            Updated user if found
        """
        return await self.update(
            db,
            user_id,
            {
                "mfa_secret": mfa_secret,
                "mfa_backup_codes": backup_codes,
                "is_mfa_enabled": True,
            },
        )

    async def disable_mfa(
        self,
        db: AsyncSession,
        user_id: UUID | str,
    ) -> User | None:
        """
        Disable MFA for user.

        Args:
            db: Database session
            user_id: User UUID

        Returns:
            Updated user if found
        """
        return await self.update(
            db,
            user_id,
            {
                "mfa_secret": None,
                "mfa_backup_codes": None,
                "is_mfa_enabled": False,
            },
        )

    async def deactivate_user(
        self,
        db: AsyncSession,
        user_id: UUID | str,
    ) -> User | None:
        """
        Deactivate user account.

        Args:
            db: Database session
            user_id: User UUID

        Returns:
            Updated user if found
        """
        return await self.update(db, user_id, {"is_active": False})

    async def activate_user(
        self,
        db: AsyncSession,
        user_id: UUID | str,
    ) -> User | None:
        """
        Activate user account.

        Args:
            db: Database session
            user_id: User UUID

        Returns:
            Updated user if found
        """
        return await self.update(db, user_id, {"is_active": True})

    async def update_role(
        self,
        db: AsyncSession,
        user_id: UUID | str,
        role: UserRole,
    ) -> User | None:
        """
        Update user role.

        Args:
            db: Database session
            user_id: User UUID
            role: New user role

        Returns:
            Updated user if found
        """
        return await self.update(db, user_id, {"role": role})

    async def search_users(
        self,
        db: AsyncSession,
        query: str,
        skip: int = 0,
        limit: int = 100,
    ) -> Sequence[User]:
        """
        Search users by email or name.

        Args:
            db: Database session
            query: Search query string
            skip: Number of records to skip
            limit: Maximum records to return

        Returns:
            List of matching users
        """
        search_pattern = f"%{query}%"
        result = await db.execute(
            select(User)
            .where(
                and_(
                    User.is_active == True,
                    (User.email.ilike(search_pattern) | User.name.ilike(search_pattern)),
                )
            )
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()


# Global instance for convenience
user_repository = UserRepository()
