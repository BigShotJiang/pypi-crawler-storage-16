"""
Role-Based Access Control (RBAC) module for Vantage Security Scanner.

This module provides comprehensive RBAC functionality including:
- Role and Permission enumerations
- User dataclass for user representation
- RBACManager for permission checking and access control

US-607: Role-Based Access Control Implementation
"""

from dataclasses import dataclass, field
from enum import Enum, auto


class Role(Enum):
    """
    User roles defining access levels within the system.

    Roles are hierarchical in terms of permissions:
    - ADMIN: Full system access
    - SECURITY_ENGINEER: Scan and project management
    - DEVELOPER: Limited scan and project access
    - VIEWER: Read-only access
    """

    ADMIN = auto()
    SECURITY_ENGINEER = auto()
    DEVELOPER = auto()
    VIEWER = auto()


class Permission(Enum):
    """
    Granular permissions for system operations.

    Permissions are grouped by resource type:
    - SCAN_*: Security scan operations
    - PROJECT_*: Project management operations
    - USER_MANAGE: User administration
    - REPORT_EXPORT: Export report data
    - SETTINGS_UPDATE: System settings modification
    """

    # Scan permissions
    SCAN_CREATE = auto()
    SCAN_READ = auto()
    SCAN_DELETE = auto()

    # Project permissions
    PROJECT_CREATE = auto()
    PROJECT_READ = auto()
    PROJECT_UPDATE = auto()
    PROJECT_DELETE = auto()

    # Administrative permissions
    USER_MANAGE = auto()
    REPORT_EXPORT = auto()
    SETTINGS_UPDATE = auto()


# Role-Permission mapping defining what each role can do
ROLE_PERMISSIONS: dict[Role, set[Permission]] = {
    Role.ADMIN: {
        # Admin has all permissions
        Permission.SCAN_CREATE,
        Permission.SCAN_READ,
        Permission.SCAN_DELETE,
        Permission.PROJECT_CREATE,
        Permission.PROJECT_READ,
        Permission.PROJECT_UPDATE,
        Permission.PROJECT_DELETE,
        Permission.USER_MANAGE,
        Permission.REPORT_EXPORT,
        Permission.SETTINGS_UPDATE,
    },
    Role.SECURITY_ENGINEER: {
        # Security engineers can manage scans and projects, export reports
        Permission.SCAN_CREATE,
        Permission.SCAN_READ,
        Permission.SCAN_DELETE,
        Permission.PROJECT_CREATE,
        Permission.PROJECT_READ,
        Permission.PROJECT_UPDATE,
        Permission.PROJECT_DELETE,
        Permission.REPORT_EXPORT,
    },
    Role.DEVELOPER: {
        # Developers can create/read scans, read projects, export reports
        Permission.SCAN_CREATE,
        Permission.SCAN_READ,
        Permission.PROJECT_READ,
        Permission.REPORT_EXPORT,
    },
    Role.VIEWER: {
        # Viewers have read-only access
        Permission.SCAN_READ,
        Permission.PROJECT_READ,
    },
}


@dataclass
class User:
    """
    User representation for RBAC operations.

    Attributes:
        id: Unique user identifier
        email: User's email address
        role: User's assigned role
        project_ids: List of project IDs the user has access to
    """

    id: str
    email: str
    role: Role
    project_ids: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Validate user data after initialization."""
        if not self.id:
            raise ValueError("User ID cannot be empty")
        if not self.email:
            raise ValueError("User email cannot be empty")
        if not isinstance(self.role, Role):
            raise ValueError(f"Invalid role: {self.role}")


class RBACManager:
    """
    Manages Role-Based Access Control operations.

    This class provides methods to check user permissions and project access.
    It uses the ROLE_PERMISSIONS mapping to determine what actions are allowed.

    Example:
        manager = RBACManager()
        user = User(id="123", email="dev@example.com", role=Role.DEVELOPER, project_ids=["proj-1"])

        # Check if user has permission
        if manager.has_permission(user, Permission.SCAN_CREATE):
            # Allow scan creation
            pass

        # Check project access with permission
        if manager.check_permission(user, Permission.SCAN_READ, "proj-1"):
            # Allow reading scans in project
            pass
    """

    def has_permission(self, user: User, permission: Permission) -> bool:
        """
        Check if a user has a specific permission based on their role.

        Args:
            user: The user to check permissions for
            permission: The permission to check

        Returns:
            True if the user's role grants the permission, False otherwise

        Raises:
            ValueError: If user or permission is None
        """
        if user is None:
            raise ValueError("User cannot be None")
        if permission is None:
            raise ValueError("Permission cannot be None")

        role_permissions = ROLE_PERMISSIONS.get(user.role, set())
        return permission in role_permissions

    def has_project_access(self, user: User, project_id: str) -> bool:
        """
        Check if a user has access to a specific project.

        Admin users have access to all projects. Other users must have
        the project_id in their project_ids list.

        Args:
            user: The user to check access for
            project_id: The project ID to check access to

        Returns:
            True if the user has access to the project, False otherwise

        Raises:
            ValueError: If user is None or project_id is empty
        """
        if user is None:
            raise ValueError("User cannot be None")
        if not project_id:
            raise ValueError("Project ID cannot be empty")

        # Admins have access to all projects
        if user.role == Role.ADMIN:
            return True

        return project_id in user.project_ids

    def check_permission(
        self, user: User, permission: Permission, project_id: str | None = None
    ) -> bool:
        """
        Check if a user has permission, optionally within a specific project.

        This method combines permission and project access checks. If a project_id
        is provided, the user must have both the permission and access to the project.

        Args:
            user: The user to check permissions for
            permission: The permission to check
            project_id: Optional project ID to check access for

        Returns:
            True if the user has the permission (and project access if specified),
            False otherwise

        Raises:
            ValueError: If user or permission is None
        """
        if user is None:
            raise ValueError("User cannot be None")
        if permission is None:
            raise ValueError("Permission cannot be None")

        # First check if user has the permission
        if not self.has_permission(user, permission):
            return False

        # If project_id is specified, also check project access
        if project_id is not None:
            return self.has_project_access(user, project_id)

        return True


# Module-level instance for convenience
rbac_manager = RBACManager()
