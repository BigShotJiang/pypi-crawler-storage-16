"""
Baseline management for finding suppression.

Provides stable fingerprinting and suppression management for security findings.
"""

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

from vantage_core.security.models import SecurityFinding


class SuppressionReason(str, Enum):
    """Reasons for suppressing a finding."""

    FALSE_POSITIVE = "false_positive"
    ACCEPTED_RISK = "accepted_risk"
    COMPENSATING_CONTROL = "compensating_control"
    NOT_APPLICABLE = "not_applicable"
    WONT_FIX = "wont_fix"


@dataclass
class BaselineEntry:
    """A single suppressed finding in the baseline."""

    fingerprint: str
    title: str
    file_path: str
    reason: SuppressionReason
    comment: str = ""
    created_at: str = ""
    created_by: str = ""
    expires_at: str | None = None
    ticket_id: str | None = None  # Link to issue tracker

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.utcnow().isoformat()

    def is_expired(self) -> bool:
        """Check if this suppression has expired."""
        if not self.expires_at:
            return False
        try:
            expiry = datetime.fromisoformat(self.expires_at)
            return datetime.utcnow() > expiry
        except Exception:
            return False

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "fingerprint": self.fingerprint,
            "title": self.title,
            "file_path": self.file_path,
            "reason": (
                self.reason.value if isinstance(self.reason, SuppressionReason) else self.reason
            ),
            "comment": self.comment,
            "created_at": self.created_at,
            "created_by": self.created_by,
            "expires_at": self.expires_at,
            "ticket_id": self.ticket_id,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "BaselineEntry":
        """Create from dictionary."""
        reason = data.get("reason", "false_positive")
        if isinstance(reason, str):
            reason = SuppressionReason(reason)

        return cls(
            fingerprint=data["fingerprint"],
            title=data.get("title", ""),
            file_path=data.get("file_path", ""),
            reason=reason,
            comment=data.get("comment", ""),
            created_at=data.get("created_at", ""),
            created_by=data.get("created_by", ""),
            expires_at=data.get("expires_at"),
            ticket_id=data.get("ticket_id"),
        )


@dataclass
class Baseline:
    """Collection of suppressed findings."""

    version: str = "1.0"
    created_at: str = ""
    updated_at: str = ""
    entries: list[BaselineEntry] = field(default_factory=list)

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.utcnow().isoformat()
        self.updated_at = datetime.utcnow().isoformat()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "version": self.version,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "entries": [e.to_dict() for e in self.entries],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Baseline":
        """Create from dictionary."""
        entries = [BaselineEntry.from_dict(e) for e in data.get("entries", [])]
        return cls(
            version=data.get("version", "1.0"),
            created_at=data.get("created_at", ""),
            updated_at=data.get("updated_at", ""),
            entries=entries,
        )


class BaselineManager:
    """
    Manages baseline files for suppressing known findings.

    The baseline uses stable fingerprints based on:
    - Finding category
    - File path (relative)
    - Normalized code snippet

    This ensures suppressions survive minor code changes.
    """

    DEFAULT_FILENAME = ".vantage-baseline.json"

    def __init__(self, project_root: Path | None = None):
        """
        Initialize baseline manager.

        Args:
            project_root: Root directory for relative path calculation
        """
        self._project_root = project_root or Path.cwd()
        self._baseline: Baseline | None = None
        self._fingerprint_cache: dict[str, BaselineEntry] = {}

    def load(self, path: Path | None = None) -> Baseline:
        """
        Load baseline from file.

        Args:
            path: Path to baseline file (default: .vantage-baseline.json)

        Returns:
            Loaded baseline
        """
        if path is None:
            path = self._project_root / self.DEFAULT_FILENAME

        if not path.exists():
            self._baseline = Baseline()
            return self._baseline

        try:
            with open(path) as f:
                data = json.load(f)

            self._baseline = Baseline.from_dict(data)

            # Build fingerprint cache
            self._fingerprint_cache = {entry.fingerprint: entry for entry in self._baseline.entries}

            return self._baseline

        except Exception as e:
            print(f"Error loading baseline: {e}")
            self._baseline = Baseline()
            return self._baseline

    def save(self, path: Path | None = None) -> None:
        """
        Save baseline to file.

        Args:
            path: Path to save baseline (default: .vantage-baseline.json)
        """
        if path is None:
            path = self._project_root / self.DEFAULT_FILENAME

        if self._baseline is None:
            self._baseline = Baseline()

        self._baseline.updated_at = datetime.utcnow().isoformat()

        with open(path, "w") as f:
            json.dump(self._baseline.to_dict(), f, indent=2)

    def generate_fingerprint(self, finding: SecurityFinding) -> str:
        """
        Generate stable fingerprint for a finding.

        The fingerprint is based on:
        - Category
        - Relative file path
        - Normalized code snippet

        Args:
            finding: Security finding to fingerprint

        Returns:
            SHA256 fingerprint
        """
        # Get relative path
        try:
            rel_path = Path(finding.file_path).relative_to(self._project_root)
        except ValueError:
            rel_path = Path(finding.file_path)

        # Normalize code snippet
        normalized_code = self._normalize_code(finding.code_snippet)

        # Create fingerprint input
        fingerprint_input = f"{finding.category.value}:{rel_path}:{normalized_code}"

        # Generate SHA256
        return hashlib.sha256(fingerprint_input.encode()).hexdigest()

    def _normalize_code(self, code: str) -> str:
        """
        Normalize code for stable fingerprinting.

        Removes:
        - Whitespace variations
        - Line numbers
        - Comments

        Args:
            code: Code snippet to normalize

        Returns:
            Normalized code string
        """
        if not code:
            return ""

        # Remove line numbers if present
        code = re.sub(r"^\s*\d+\s*[:\|]\s*", "", code, flags=re.MULTILINE)

        # Remove comments
        code = re.sub(r"#.*$", "", code, flags=re.MULTILINE)

        # Normalize whitespace
        code = re.sub(r"\s+", " ", code)

        return code.strip().lower()

    def is_suppressed(self, finding: SecurityFinding) -> bool:
        """
        Check if a finding is suppressed in the baseline.

        Args:
            finding: Finding to check

        Returns:
            True if suppressed and not expired
        """
        if self._baseline is None:
            self.load()

        fingerprint = self.generate_fingerprint(finding)
        entry = self._fingerprint_cache.get(fingerprint)

        if entry is None:
            return False

        # Check expiration
        if entry.is_expired():
            return False

        return True

    def get_suppression(self, finding: SecurityFinding) -> BaselineEntry | None:
        """
        Get suppression entry for a finding.

        Args:
            finding: Finding to check

        Returns:
            BaselineEntry if suppressed, None otherwise
        """
        if self._baseline is None:
            self.load()

        fingerprint = self.generate_fingerprint(finding)
        return self._fingerprint_cache.get(fingerprint)

    def add_suppression(
        self,
        finding: SecurityFinding,
        reason: SuppressionReason,
        comment: str = "",
        created_by: str = "",
        expires_at: str | None = None,
        ticket_id: str | None = None,
    ) -> BaselineEntry:
        """
        Add a suppression for a finding.

        Args:
            finding: Finding to suppress
            reason: Reason for suppression
            comment: Additional comment
            created_by: Who created this suppression
            expires_at: Optional expiration date (ISO format)
            ticket_id: Optional ticket/issue reference

        Returns:
            Created baseline entry
        """
        if self._baseline is None:
            self.load()

        fingerprint = self.generate_fingerprint(finding)

        # Check if already suppressed
        if fingerprint in self._fingerprint_cache:
            # Update existing entry
            entry = self._fingerprint_cache[fingerprint]
            entry.reason = reason
            entry.comment = comment
            entry.expires_at = expires_at
            entry.ticket_id = ticket_id
            return entry

        # Create new entry
        try:
            rel_path = str(Path(finding.file_path).relative_to(self._project_root))
        except ValueError:
            rel_path = finding.file_path

        entry = BaselineEntry(
            fingerprint=fingerprint,
            title=finding.title,
            file_path=rel_path,
            reason=reason,
            comment=comment,
            created_by=created_by,
            expires_at=expires_at,
            ticket_id=ticket_id,
        )

        self._baseline.entries.append(entry)
        self._fingerprint_cache[fingerprint] = entry

        return entry

    def remove_suppression(self, finding: SecurityFinding) -> bool:
        """
        Remove suppression for a finding.

        Args:
            finding: Finding to unsuppress

        Returns:
            True if removed, False if not found
        """
        if self._baseline is None:
            self.load()

        fingerprint = self.generate_fingerprint(finding)

        if fingerprint not in self._fingerprint_cache:
            return False

        entry = self._fingerprint_cache[fingerprint]
        self._baseline.entries.remove(entry)
        del self._fingerprint_cache[fingerprint]

        return True

    def filter_findings(
        self, findings: list[SecurityFinding]
    ) -> tuple[list[SecurityFinding], list[SecurityFinding]]:
        """
        Filter findings against baseline.

        Args:
            findings: List of findings to filter

        Returns:
            Tuple of (active_findings, suppressed_findings)
        """
        if self._baseline is None:
            self.load()

        active = []
        suppressed = []

        for finding in findings:
            if self.is_suppressed(finding):
                suppressed.append(finding)
            else:
                active.append(finding)

        return active, suppressed

    def create_baseline_from_findings(
        self,
        findings: list[SecurityFinding],
        reason: SuppressionReason = SuppressionReason.FALSE_POSITIVE,
        comment: str = "Initial baseline",
        created_by: str = "",
    ) -> Baseline:
        """
        Create a baseline from current findings.

        Useful for initial baseline creation.

        Args:
            findings: Findings to add to baseline
            reason: Default reason for all suppressions
            comment: Default comment
            created_by: Creator name

        Returns:
            Created baseline
        """
        self._baseline = Baseline()
        self._fingerprint_cache = {}

        for finding in findings:
            self.add_suppression(
                finding,
                reason=reason,
                comment=comment,
                created_by=created_by,
            )

        return self._baseline

    def get_expired_entries(self) -> list[BaselineEntry]:
        """
        Get all expired baseline entries.

        Returns:
            List of expired entries
        """
        if self._baseline is None:
            self.load()

        return [entry for entry in self._baseline.entries if entry.is_expired()]

    def cleanup_expired(self) -> int:
        """
        Remove all expired entries from baseline.

        Returns:
            Number of entries removed
        """
        if self._baseline is None:
            self.load()

        expired = self.get_expired_entries()

        for entry in expired:
            self._baseline.entries.remove(entry)
            if entry.fingerprint in self._fingerprint_cache:
                del self._fingerprint_cache[entry.fingerprint]

        return len(expired)

    def get_stats(self) -> dict[str, Any]:
        """
        Get baseline statistics.

        Returns:
            Statistics dictionary
        """
        if self._baseline is None:
            self.load()

        by_reason = {}
        for entry in self._baseline.entries:
            reason = (
                entry.reason.value if isinstance(entry.reason, SuppressionReason) else entry.reason
            )
            by_reason[reason] = by_reason.get(reason, 0) + 1

        expired_count = len(self.get_expired_entries())

        return {
            "total_entries": len(self._baseline.entries),
            "by_reason": by_reason,
            "expired": expired_count,
            "active": len(self._baseline.entries) - expired_count,
        }
