"""
Enhanced Secret Detection Pipeline for Vantage Security Scanner.

This module provides entropy-based filtering, context analysis, and allowlist
management to reduce false positives in secret detection. It also includes
ML-based prompt injection classification for detecting novel injection attacks.
"""

from vantage_core.security.detection.prompt_injection_classifier import (
    InjectionClassification,
    MultiLayerInjectionDetector,
    PromptInjectionClassifier,
)
from vantage_core.security.detection.secret_detection import (
    AllowlistManager,
    AllowlistPattern,
    ContextAnalysisResult,
    ContextAnalyzer,
    EntropyCalculator,
    SecretAnalysisResult,
    SecretDetectionPipeline,
)

__all__ = [
    # Secret Detection
    "EntropyCalculator",
    "ContextAnalyzer",
    "ContextAnalysisResult",
    "AllowlistPattern",
    "AllowlistManager",
    "SecretAnalysisResult",
    "SecretDetectionPipeline",
    # Prompt Injection Detection
    "InjectionClassification",
    "PromptInjectionClassifier",
    "MultiLayerInjectionDetector",
]
