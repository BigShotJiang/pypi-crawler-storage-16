"""
Configuration and prompt extractors for Vantage Security Platform.

This module provides tools for extracting and analyzing configuration
from various formats including YAML, JSON, TOML, .env, and Python config files.
It also includes prompt extraction from Python source code for security analysis.
"""

from .config import (
    ConfigAnalysis,
    ConfigExtractor,
    ConfigFormat,
    EnvironmentVariable,
    SecretFinding,
    SecuritySettings,
)
from .prompts import (
    ExtractedPrompt,
    PromptExtractor,
    PromptSourceType,
    extract_prompts,
)

__all__ = [
    # Config extraction
    "ConfigExtractor",
    "ConfigFormat",
    "ConfigAnalysis",
    "SecretFinding",
    "SecuritySettings",
    "EnvironmentVariable",
    # Prompt extraction
    "PromptExtractor",
    "ExtractedPrompt",
    "PromptSourceType",
    "extract_prompts",
]
