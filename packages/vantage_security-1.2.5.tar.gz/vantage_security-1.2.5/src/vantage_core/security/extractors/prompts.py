"""Prompt string extraction from Python source code.

This module extracts LLM prompt strings from Python code for security analysis.
It supports multiple extraction patterns:
- Direct keyword arguments (system_message, prompt, etc.)
- Template-based prompts (ChatPromptTemplate, PromptTemplate)
- Variable assignments with prompt-related names
- Multi-field prompts (CrewAI's role/goal/backstory)
- F-string prompts with variable interpolation
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class PromptSourceType(str, Enum):
    """How the prompt was identified."""

    KEYWORD_ARG = "keyword_arg"  # system_message="..."
    TEMPLATE = "template"  # ChatPromptTemplate.from_template(...)
    ASSIGNMENT = "assignment"  # system_prompt = "..."
    FSTRING = "fstring"  # f"You are {role}"
    MULTI_FIELD = "multi_field"  # CrewAI role+goal+backstory


@dataclass
class ExtractedPrompt:
    """Represents an extracted prompt string for security scanning."""

    content: str  # The actual prompt text
    file_path: str  # Source file path
    line_number: int  # Starting line number
    end_line_number: int  # Ending line number
    confidence: float  # Extraction confidence (0.0-1.0)
    source_type: PromptSourceType  # How it was extracted
    framework: str | None = None  # langchain/crewai/autogen/None
    agent_id: str | None = None  # Agent identifier if known
    is_dynamic: bool = False  # True if contains interpolation
    variable_refs: list[str] = field(default_factory=list)  # Variables in f-strings
    code_snippet: str | None = None  # Original code context
    keyword_name: str | None = None  # The keyword arg name (e.g., "system_message")


# Keyword arguments that typically contain prompts
PROMPT_KEYWORDS = {
    # High confidence - these are explicit prompt parameters
    "system_message": 0.95,
    "system_prompt": 0.95,
    "instructions": 0.90,
    # CrewAI-specific fields that compose prompts
    "backstory": 0.85,
    "expected_output": 0.80,
}

# Variable names that suggest prompt content (must end with these patterns)
PROMPT_VARIABLE_PATTERNS = [
    r"system_prompt$",
    r"system_message$",
    r"_prompt$",  # validation_prompt, recovery_prompt, etc.
    r"_instruction$",
    r"system_instruction$",
    r"agent_prompt$",
    r"chat_prompt$",
    r"prompt_template$",  # More specific than just "template"
    r"prompt_content$",
]

# Function calls that create prompts
PROMPT_TEMPLATE_FUNCTIONS = {
    "ChatPromptTemplate.from_template": 0.90,
    "PromptTemplate": 0.90,
    "SystemMessagePromptTemplate": 0.95,
    "HumanMessagePromptTemplate": 0.85,
    "AIMessagePromptTemplate": 0.85,
    "MessagesPlaceholder": 0.70,
}

# Agent creation functions by framework
AGENT_CREATION_FUNCTIONS = {
    # LangChain
    "create_react_agent": "langchain",
    "create_openai_functions_agent": "langchain",
    "create_tool_calling_agent": "langchain",
    "AgentExecutor": "langchain",
    "ChatOpenAI": "langchain",
    # CrewAI
    "Agent": "crewai",
    "Task": "crewai",
    "Crew": "crewai",
    # AutoGen
    "AssistantAgent": "autogen",
    "UserProxyAgent": "autogen",
    "ConversableAgent": "autogen",
    "GroupChat": "autogen",
    # OpenAI
    "ChatCompletion": "openai",
    # Anthropic
    "Claude": "anthropic",
}


class PromptExtractorVisitor(ast.NodeVisitor):
    """AST visitor that extracts prompt strings from Python code."""

    def __init__(self, source_code: str, file_path: str):
        self.source_code = source_code
        self.source_lines = source_code.split("\n")
        self.file_path = file_path
        self.extracted_prompts: list[ExtractedPrompt] = []

    def _get_full_name(self, node: ast.expr) -> str:
        """Get the full dotted name from an AST expression."""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            value_name = self._get_full_name(node.value)
            return f"{value_name}.{node.attr}" if value_name else node.attr
        elif isinstance(node, ast.Call):
            return self._get_full_name(node.func)
        return ""

    def _get_string_value(self, node: ast.expr) -> tuple[str, bool, list[str]]:
        """
        Extract string value from an AST node.

        Returns:
            Tuple of (content, is_dynamic, variable_refs)
        """
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value, False, []
        elif isinstance(node, ast.Str):  # Python 3.7 compat
            return node.s, False, []
        elif isinstance(node, ast.JoinedStr):
            # F-string - extract constant parts and variable references
            parts = []
            variables = []
            for value in node.values:
                if isinstance(value, ast.Constant):
                    parts.append(str(value.value))
                elif isinstance(value, ast.FormattedValue):
                    parts.append("{...}")  # Placeholder for variable
                    if isinstance(value.value, ast.Name):
                        variables.append(value.value.id)
            return "".join(parts), True, variables
        elif isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            # String concatenation
            left, left_dynamic, left_vars = self._get_string_value(node.left)
            right, right_dynamic, right_vars = self._get_string_value(node.right)
            return left + right, left_dynamic or right_dynamic, left_vars + right_vars
        return "", False, []

    def _get_code_snippet(self, start_line: int, end_line: int, max_lines: int = 5) -> str:
        """Get code snippet around the given lines."""
        start = max(0, start_line - 1)
        end = min(len(self.source_lines), end_line + max_lines - 1)
        return "\n".join(self.source_lines[start:end])

    def _extract_from_keyword(
        self, keyword: ast.keyword, framework: str | None, agent_name: str | None = None
    ) -> ExtractedPrompt | None:
        """Extract prompt from a keyword argument."""
        if keyword.arg is None:
            return None

        arg_name = keyword.arg.lower()
        if arg_name not in PROMPT_KEYWORDS:
            return None

        content, is_dynamic, var_refs = self._get_string_value(keyword.value)
        if not content or len(content) < 50:  # Skip short strings - prompts are usually longer
            return None

        confidence = PROMPT_KEYWORDS[arg_name]

        # Reduce confidence for dynamic prompts
        if is_dynamic:
            confidence *= 0.9

        return ExtractedPrompt(
            content=content,
            file_path=self.file_path,
            line_number=(
                keyword.value.lineno if hasattr(keyword.value, "lineno") else keyword.lineno
            ),
            end_line_number=(
                keyword.value.end_lineno if hasattr(keyword.value, "end_lineno") else keyword.lineno
            ),
            confidence=confidence,
            source_type=(PromptSourceType.FSTRING if is_dynamic else PromptSourceType.KEYWORD_ARG),
            framework=framework,
            agent_id=agent_name,
            is_dynamic=is_dynamic,
            variable_refs=var_refs,
            keyword_name=keyword.arg,
            code_snippet=self._get_code_snippet(keyword.lineno, keyword.lineno),
        )

    def visit_Call(self, node: ast.Call) -> None:
        """Extract prompts from function calls."""
        func_name = self._get_full_name(node.func)

        # Check if this is an agent creation call
        framework = None
        for pattern, fw in AGENT_CREATION_FUNCTIONS.items():
            if pattern in func_name or func_name.endswith(pattern):
                framework = fw
                break

        # Check if this is a prompt template call
        if framework is None:
            for pattern in PROMPT_TEMPLATE_FUNCTIONS:
                if pattern in func_name:
                    framework = "langchain"  # Most template functions are LangChain
                    break

        # Extract agent name if available
        agent_name = None
        for keyword in node.keywords:
            if keyword.arg == "name" and isinstance(keyword.value, ast.Constant):
                agent_name = str(keyword.value.value)
                break

        # Extract prompts from keyword arguments
        for keyword in node.keywords:
            prompt = self._extract_from_keyword(keyword, framework, agent_name)
            if prompt:
                self.extracted_prompts.append(prompt)

        # Extract from positional arguments ONLY for known prompt template functions
        # Skip positional arg extraction for generic function calls to avoid false positives
        is_prompt_template_call = any(pattern in func_name for pattern in PROMPT_TEMPLATE_FUNCTIONS)

        if is_prompt_template_call:
            for i, arg in enumerate(node.args):
                content, is_dynamic, var_refs = self._get_string_value(arg)
                if content and len(content) >= 50:  # Higher threshold for template content
                    confidence = 0.75
                    for pattern in PROMPT_TEMPLATE_FUNCTIONS:
                        if pattern in func_name:
                            confidence = PROMPT_TEMPLATE_FUNCTIONS[pattern]
                            break

                    self.extracted_prompts.append(
                        ExtractedPrompt(
                            content=content,
                            file_path=self.file_path,
                            line_number=arg.lineno,
                            end_line_number=(
                                arg.end_lineno if hasattr(arg, "end_lineno") else arg.lineno
                            ),
                            confidence=confidence,
                            source_type=PromptSourceType.TEMPLATE,
                            framework=framework,
                            is_dynamic=is_dynamic,
                            variable_refs=var_refs,
                            code_snippet=self._get_code_snippet(arg.lineno, arg.lineno),
                        )
                    )

        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        """Extract from assignments like: system_prompt = '...'"""
        for target in node.targets:
            if isinstance(target, ast.Name):
                var_name = target.id.lower()

                # Check if variable name suggests a prompt
                is_prompt_var = any(
                    re.search(pattern, var_name, re.IGNORECASE)
                    for pattern in PROMPT_VARIABLE_PATTERNS
                )

                if is_prompt_var:
                    content, is_dynamic, var_refs = self._get_string_value(node.value)
                    if content and len(content) >= 50:  # Prompts are usually longer than 50 chars
                        self.extracted_prompts.append(
                            ExtractedPrompt(
                                content=content,
                                file_path=self.file_path,
                                line_number=node.lineno,
                                end_line_number=(
                                    node.end_lineno if hasattr(node, "end_lineno") else node.lineno
                                ),
                                confidence=0.85 if not is_dynamic else 0.75,
                                source_type=(
                                    PromptSourceType.FSTRING
                                    if is_dynamic
                                    else PromptSourceType.ASSIGNMENT
                                ),
                                is_dynamic=is_dynamic,
                                variable_refs=var_refs,
                                keyword_name=target.id,
                                code_snippet=self._get_code_snippet(node.lineno, node.lineno),
                            )
                        )

        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        """Handle annotated assignments: system_prompt: str = '...'"""
        if isinstance(node.target, ast.Name) and node.value:
            var_name = node.target.id.lower()

            is_prompt_var = any(
                re.search(pattern, var_name, re.IGNORECASE) for pattern in PROMPT_VARIABLE_PATTERNS
            )

            if is_prompt_var:
                content, is_dynamic, var_refs = self._get_string_value(node.value)
                if content and len(content) >= 50:  # Prompts are usually longer than 50 chars
                    self.extracted_prompts.append(
                        ExtractedPrompt(
                            content=content,
                            file_path=self.file_path,
                            line_number=node.lineno,
                            end_line_number=(
                                node.end_lineno if hasattr(node, "end_lineno") else node.lineno
                            ),
                            confidence=0.85 if not is_dynamic else 0.75,
                            source_type=(
                                PromptSourceType.FSTRING
                                if is_dynamic
                                else PromptSourceType.ASSIGNMENT
                            ),
                            is_dynamic=is_dynamic,
                            variable_refs=var_refs,
                            keyword_name=node.target.id,
                            code_snippet=self._get_code_snippet(node.lineno, node.lineno),
                        )
                    )

        self.generic_visit(node)


class PromptExtractor:
    """Extract LLM prompts from Python source code for security analysis."""

    def __init__(self):
        self._skip_patterns = [
            "test_",
            "_test.py",
            "conftest.py",
            "/tests/",
            "/test/",
            "/__tests__/",
            "/examples/",
            "/samples/",
            "/docs/",
            "__pycache__",
            ".git",
            "node_modules",
        ]

    def _should_skip_file(self, file_path: str) -> bool:
        """Check if file should be skipped."""
        path_lower = file_path.lower()
        return any(pattern in path_lower for pattern in self._skip_patterns)

    def extract_from_file(self, file_path: Path) -> list[ExtractedPrompt]:
        """Extract prompts from a single Python file."""
        if self._should_skip_file(str(file_path)):
            return []

        try:
            source_code = file_path.read_text(errors="ignore")
            return self.extract_from_source(source_code, str(file_path))
        except Exception:
            return []

    def extract_from_source(self, source_code: str, file_path: str) -> list[ExtractedPrompt]:
        """Extract prompts from Python source code string."""
        try:
            tree = ast.parse(source_code)
        except SyntaxError:
            return []

        visitor = PromptExtractorVisitor(source_code, file_path)
        visitor.visit(tree)

        # Filter out low-confidence or very short prompts
        prompts = [
            p for p in visitor.extracted_prompts if p.confidence >= 0.7 and len(p.content) >= 50
        ]

        # Deduplicate by content
        seen = set()
        unique_prompts = []
        for p in prompts:
            content_hash = hash(p.content[:100])  # Hash first 100 chars
            if content_hash not in seen:
                seen.add(content_hash)
                unique_prompts.append(p)

        return unique_prompts

    def extract_from_directory(
        self, directory: Path, max_files: int = 1000
    ) -> list[ExtractedPrompt]:
        """Extract prompts from all Python files in a directory."""
        all_prompts = []

        python_files = list(directory.rglob("*.py"))[:max_files]

        for file_path in python_files:
            prompts = self.extract_from_file(file_path)
            all_prompts.extend(prompts)

        return all_prompts


# Convenience function for quick extraction
def extract_prompts(path: Path) -> list[ExtractedPrompt]:
    """
    Extract all prompts from a file or directory.

    Args:
        path: Path to Python file or directory

    Returns:
        List of ExtractedPrompt objects
    """
    extractor = PromptExtractor()

    if path.is_file():
        return extractor.extract_from_file(path)
    else:
        return extractor.extract_from_directory(path)
