"""
History tracking and trend analysis.

Provides functionality to track scans, findings, and calculate metrics.
"""

import json
import uuid
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

from vantage_core.security.baseline import BaselineManager
from vantage_core.security.history.models import (
    FindingHistory,
    FindingStatus,
    RemediationTracking,
    ScanHistory,
    TrendData,
)
from vantage_core.security.models import SecurityFinding, SecurityScanResult, Severity


class HistoryTracker:
    """
    Tracks scan history and finding lifecycles.

    Can use file-based storage or be extended for database storage.
    """

    def __init__(self, storage_path: Path | None = None):
        """
        Initialize history tracker.

        Args:
            storage_path: Path to store history data (JSON files)
        """
        self._storage_path = storage_path or Path.cwd() / ".vantage-history"
        self._storage_path.mkdir(parents=True, exist_ok=True)

        self._scan_history: list[ScanHistory] = []
        self._finding_history: dict[str, FindingHistory] = {}  # fingerprint -> history
        self._baseline_manager = BaselineManager()

    def record_scan(
        self,
        project_id: str,
        scan_result: SecurityScanResult,
        score: float,
        grade: str,
        branch: str | None = None,
        commit_sha: str | None = None,
        triggered_by: str | None = None,
    ) -> ScanHistory:
        """
        Record a completed scan.

        Args:
            project_id: Project identifier
            scan_result: Scan results
            score: Security score
            grade: Security grade
            branch: Git branch
            commit_sha: Git commit SHA
            triggered_by: What triggered the scan

        Returns:
            Created ScanHistory record
        """
        # Count findings by severity
        critical = sum(1 for f in scan_result.findings if f.severity == Severity.CRITICAL)
        high = sum(1 for f in scan_result.findings if f.severity == Severity.HIGH)
        medium = sum(1 for f in scan_result.findings if f.severity == Severity.MEDIUM)
        low = sum(1 for f in scan_result.findings if f.severity == Severity.LOW)

        history = ScanHistory(
            id=str(uuid.uuid4()),
            project_id=project_id,
            scan_id=scan_result.scan_id,
            timestamp=scan_result.timestamp,
            duration_ms=scan_result.scan_duration_ms,
            total_findings=len(scan_result.findings),
            critical_count=critical,
            high_count=high,
            medium_count=medium,
            low_count=low,
            score=score,
            grade=grade,
            frameworks_detected=scan_result.frameworks_detected,
            agents_scanned=scan_result.agents_scanned,
            branch=branch,
            commit_sha=commit_sha,
            triggered_by=triggered_by,
        )

        self._scan_history.append(history)

        # Update finding history
        self._update_finding_history(project_id, scan_result.findings, commit_sha)

        # Persist
        self._save_scan_history(project_id, history)

        return history

    def _update_finding_history(
        self,
        project_id: str,
        findings: list[SecurityFinding],
        commit_sha: str | None = None,
    ):
        """Update finding lifecycle tracking."""
        now = datetime.utcnow()

        # Get fingerprints of current findings
        current_fingerprints = set()
        for finding in findings:
            fp = self._baseline_manager.generate_fingerprint(finding)
            current_fingerprints.add(fp)

            if fp in self._finding_history:
                # Update existing finding
                history = self._finding_history[fp]
                history.last_seen = now
                history.occurrences += 1
                if history.status == FindingStatus.FIXED:
                    # Reopened
                    history.status = FindingStatus.OPEN
                    history.fixed_at = None
                    history.fixed_in_commit = None
            else:
                # New finding
                self._finding_history[fp] = FindingHistory(
                    id=str(uuid.uuid4()),
                    project_id=project_id,
                    fingerprint=fp,
                    title=finding.title,
                    category=finding.category.value,
                    severity=finding.severity.value,
                    file_path=finding.file_path,
                    first_seen=now,
                    last_seen=now,
                    status=FindingStatus.OPEN,
                )

        # Check for fixed findings
        for fp, history in self._finding_history.items():
            if history.project_id != project_id:
                continue
            if history.status == FindingStatus.OPEN and fp not in current_fingerprints:
                history.status = FindingStatus.FIXED
                history.fixed_at = now
                history.fixed_in_commit = commit_sha

    def get_scan_history(
        self, project_id: str, days: int = 30, limit: int = 100
    ) -> list[ScanHistory]:
        """
        Get scan history for a project.

        Args:
            project_id: Project identifier
            days: Number of days to look back
            limit: Maximum number of records

        Returns:
            List of scan history records
        """
        cutoff = datetime.utcnow() - timedelta(days=days)

        history = [
            h for h in self._scan_history if h.project_id == project_id and h.timestamp >= cutoff
        ]

        # Sort by timestamp descending
        history.sort(key=lambda h: h.timestamp, reverse=True)

        return history[:limit]

    def get_finding_history(
        self, project_id: str, status: FindingStatus | None = None
    ) -> list[FindingHistory]:
        """
        Get finding history for a project.

        Args:
            project_id: Project identifier
            status: Filter by status

        Returns:
            List of finding history records
        """
        findings = [f for f in self._finding_history.values() if f.project_id == project_id]

        if status:
            findings = [f for f in findings if f.status == status]

        return findings

    def calculate_mttr(self, project_id: str, days: int = 30) -> RemediationTracking:
        """
        Calculate mean time to remediation metrics.

        Args:
            project_id: Project identifier
            days: Period to calculate over

        Returns:
            RemediationTracking with MTTR metrics
        """
        cutoff = datetime.utcnow() - timedelta(days=days)
        now = datetime.utcnow()

        # Get findings in period
        findings = self.get_finding_history(project_id)

        # Calculate metrics by severity
        fixed_by_severity: dict[str, list[float]] = defaultdict(list)
        total_fixed = 0
        total_new = 0

        for f in findings:
            if f.first_seen >= cutoff:
                total_new += 1

            if f.status == FindingStatus.FIXED and f.fixed_at and f.fixed_at >= cutoff:
                total_fixed += 1
                ttf = f.time_to_fix_hours
                if ttf is not None:
                    fixed_by_severity[f.severity].append(ttf)

        # Calculate MTTR by severity
        def avg(values: list[float]) -> float | None:
            return sum(values) / len(values) if values else None

        mttr_critical = avg(fixed_by_severity.get("critical", []))
        mttr_high = avg(fixed_by_severity.get("high", []))
        mttr_medium = avg(fixed_by_severity.get("medium", []))
        mttr_low = avg(fixed_by_severity.get("low", []))

        # Overall MTTR
        all_ttf = []
        for ttf_list in fixed_by_severity.values():
            all_ttf.extend(ttf_list)
        mttr_overall = avg(all_ttf)

        # Velocity
        velocity = total_fixed / total_new if total_new > 0 else 0.0

        return RemediationTracking(
            project_id=project_id,
            period_start=cutoff,
            period_end=now,
            total_fixed=total_fixed,
            total_new=total_new,
            mttr_critical_hours=mttr_critical,
            mttr_high_hours=mttr_high,
            mttr_medium_hours=mttr_medium,
            mttr_low_hours=mttr_low,
            mttr_overall_hours=mttr_overall,
            velocity=velocity,
        )

    def _save_scan_history(self, project_id: str, history: ScanHistory):
        """Save scan history to file."""
        history_file = self._storage_path / f"{project_id}_scans.json"

        # Load existing
        existing = []
        if history_file.exists():
            try:
                with open(history_file) as f:
                    existing = json.load(f)
            except Exception:
                pass

        # Append new
        existing.append(history.to_dict())

        # Save
        with open(history_file, "w") as f:
            json.dump(existing, f, indent=2)

    def load_history(self, project_id: str):
        """Load history from storage."""
        # Load scan history
        scan_file = self._storage_path / f"{project_id}_scans.json"
        if scan_file.exists():
            try:
                with open(scan_file) as f:
                    data = json.load(f)
                for item in data:
                    item["timestamp"] = datetime.fromisoformat(item["timestamp"])
                    self._scan_history.append(ScanHistory(**item))
            except Exception as e:
                print(f"Error loading scan history: {e}")

        # Load finding history
        finding_file = self._storage_path / f"{project_id}_findings.json"
        if finding_file.exists():
            try:
                with open(finding_file) as f:
                    data = json.load(f)
                for item in data:
                    item["first_seen"] = datetime.fromisoformat(item["first_seen"])
                    item["last_seen"] = datetime.fromisoformat(item["last_seen"])
                    if item.get("fixed_at"):
                        item["fixed_at"] = datetime.fromisoformat(item["fixed_at"])
                    item["status"] = FindingStatus(item["status"])
                    history = FindingHistory(**item)
                    self._finding_history[history.fingerprint] = history
            except Exception as e:
                print(f"Error loading finding history: {e}")


class TrendAnalyzer:
    """
    Analyzes trends from historical data.

    Provides aggregated metrics for dashboards.
    """

    def __init__(self, tracker: HistoryTracker):
        """Initialize with a history tracker."""
        self._tracker = tracker

    def get_daily_trends(self, project_id: str, days: int = 30) -> list[TrendData]:
        """
        Get daily trend data.

        Args:
            project_id: Project identifier
            days: Number of days

        Returns:
            List of daily trend data
        """
        history = self._tracker.get_scan_history(project_id, days=days, limit=1000)

        if not history:
            return []

        # Group by date
        by_date: dict[str, list[ScanHistory]] = defaultdict(list)
        for scan in history:
            date_key = scan.timestamp.date().isoformat()
            by_date[date_key].append(scan)

        # Aggregate
        trends = []
        for date_str, scans in sorted(by_date.items()):
            # Use latest scan for the day
            latest = max(scans, key=lambda s: s.timestamp)

            trends.append(
                TrendData(
                    project_id=project_id,
                    date=datetime.fromisoformat(date_str),
                    total_findings=latest.total_findings,
                    critical_count=latest.critical_count,
                    high_count=latest.high_count,
                    medium_count=latest.medium_count,
                    low_count=latest.low_count,
                    score=latest.score,
                    scan_count=len(scans),
                )
            )

        return trends

    def get_severity_breakdown(self, project_id: str, days: int = 30) -> dict[str, int]:
        """
        Get current severity breakdown.

        Args:
            project_id: Project identifier
            days: Period to consider

        Returns:
            Dict of severity -> count
        """
        history = self._tracker.get_scan_history(project_id, days=days, limit=1)

        if not history:
            return {
                "critical": 0,
                "high": 0,
                "medium": 0,
                "low": 0,
            }

        latest = history[0]
        return {
            "critical": latest.critical_count,
            "high": latest.high_count,
            "medium": latest.medium_count,
            "low": latest.low_count,
        }

    def get_improvement_rate(self, project_id: str, days: int = 30) -> float:
        """
        Calculate improvement rate (score change).

        Args:
            project_id: Project identifier
            days: Period to compare

        Returns:
            Score change (positive = improvement)
        """
        history = self._tracker.get_scan_history(project_id, days=days, limit=1000)

        if len(history) < 2:
            return 0.0

        # Compare latest to earliest
        latest = history[0]
        earliest = history[-1]

        return latest.score - earliest.score

    def get_category_distribution(self, project_id: str) -> dict[str, int]:
        """
        Get distribution of findings by category.

        Args:
            project_id: Project identifier

        Returns:
            Dict of category -> count
        """
        findings = self._tracker.get_finding_history(project_id, status=FindingStatus.OPEN)

        distribution: dict[str, int] = defaultdict(int)
        for f in findings:
            distribution[f.category] += 1

        return dict(distribution)
