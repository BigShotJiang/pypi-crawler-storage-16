"""
Data Sensitivity Classifier and Enhanced Flow Tracking.

US-205/206: Data Sensitivity and Flow Analysis Completion
Implements PII detection, credential patterns, taint propagation
with sensitivity labels, and exfiltration path detection.

Features:
- PII detection patterns (email, SSN, credit card, phone, address)
- Credential patterns (AWS keys, API tokens, passwords)
- Medical data patterns (for HIPAA)
- Taint propagation with sensitivity labels
- Exfiltration path detection to external sinks
"""

import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from vantage_core.security.models import Severity, TrustLevel
from vantage_core.security.topology.graph import AgentGraph

logger = logging.getLogger(__name__)


class DataSensitivity(str, Enum):
    """Data sensitivity classification levels."""

    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    SECRET = "secret"


class PIIType(str, Enum):
    """Types of Personally Identifiable Information."""

    EMAIL = "email"
    SSN = "ssn"
    CREDIT_CARD = "credit_card"
    PHONE = "phone"
    ADDRESS = "address"
    NAME = "name"
    DATE_OF_BIRTH = "date_of_birth"
    IP_ADDRESS = "ip_address"
    PASSPORT = "passport"
    DRIVERS_LICENSE = "drivers_license"


class CredentialType(str, Enum):
    """Types of credentials."""

    AWS_ACCESS_KEY = "aws_access_key"
    AWS_SECRET_KEY = "aws_secret_key"
    API_KEY = "api_key"
    API_TOKEN = "api_token"
    PASSWORD = "password"
    JWT_TOKEN = "jwt_token"
    OAUTH_TOKEN = "oauth_token"
    SSH_KEY = "ssh_key"
    DATABASE_CONNECTION = "database_connection"
    PRIVATE_KEY = "private_key"


class MedicalDataType(str, Enum):
    """Types of medical/HIPAA data."""

    DIAGNOSIS = "diagnosis"
    MEDICATION = "medication"
    LAB_RESULT = "lab_result"
    MEDICAL_RECORD_NUMBER = "medical_record_number"
    HEALTH_PLAN_ID = "health_plan_id"
    PATIENT_ID = "patient_id"


@dataclass
class PIIFinding:
    """Represents detected PII in text."""

    pii_type: PIIType
    value_redacted: str  # Partially redacted value for display
    confidence: float  # 0-1 confidence score
    start_position: int
    end_position: int
    context: str = ""  # Surrounding text for context


@dataclass
class CredentialFinding:
    """Represents detected credential in data."""

    credential_type: CredentialType
    key_name: str | None = None
    confidence: float = 0.0
    start_position: int = 0
    end_position: int = 0
    is_active: bool = True  # Whether credential appears valid/active


@dataclass
class DataClassification:
    """Classification result for data."""

    sensitivity: DataSensitivity
    confidence: float
    pii_findings: list[PIIFinding] = field(default_factory=list)
    credential_findings: list[CredentialFinding] = field(default_factory=list)
    data_types: list[str] = field(default_factory=list)
    risk_factors: list[str] = field(default_factory=list)


@dataclass
class DataSource:
    """Represents a source of sensitive data."""

    id: str
    agent_id: str
    sensitivity: DataSensitivity
    data_types: list[str]
    trust_level: TrustLevel
    description: str = ""


@dataclass
class TaintLabel:
    """Sensitivity label for taint tracking."""

    sensitivity: DataSensitivity
    data_types: list[str]
    source_id: str
    propagation_path: list[str] = field(default_factory=list)


@dataclass
class TaintPath:
    """Path of tainted data through the system."""

    source: DataSource
    sink_agent_id: str
    path: list[str]  # Agent IDs
    labels: list[TaintLabel]
    severity: Severity
    is_exfiltration_risk: bool = False
    recommendation: str = ""


@dataclass
class ExfiltrationRisk:
    """Identified exfiltration risk."""

    source: DataSource
    sink_agent_id: str
    path: list[str]
    sensitivity: DataSensitivity
    risk_score: float
    description: str
    recommendation: str


class DataSensitivityClassifier:
    """
    Classify data sensitivity and detect PII, credentials, and medical data.

    Uses regex patterns and heuristics to identify sensitive information.
    """

    # PII Detection Patterns
    PII_PATTERNS = {
        PIIType.EMAIL: (r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", 0.95),
        PIIType.SSN: (r"\b\d{3}[-.\s]?\d{2}[-.\s]?\d{4}\b", 0.90),
        PIIType.CREDIT_CARD: (
            r"\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12})\b",
            0.95,
        ),
        PIIType.PHONE: (
            r"\b(?:\+?1[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}\b",
            0.80,
        ),
        PIIType.IP_ADDRESS: (
            r"\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b",
            0.90,
        ),
        PIIType.DATE_OF_BIRTH: (
            r"\b(?:0[1-9]|1[0-2])[-/](?:0[1-9]|[12][0-9]|3[01])[-/](?:19|20)\d{2}\b",
            0.75,
        ),
    }

    # Credential Detection Patterns
    CREDENTIAL_PATTERNS = {
        CredentialType.AWS_ACCESS_KEY: (
            r"(?:A3T[A-Z0-9]|AKIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}",
            0.95,
        ),
        CredentialType.AWS_SECRET_KEY: (
            r'(?i)(?:aws)?_?(?:secret)?_?(?:access)?_?key["\'\s:=]+[A-Za-z0-9/+=]{40}',
            0.90,
        ),
        CredentialType.API_KEY: (
            r'(?i)(?:api[_-]?key|apikey)["\'\s:=]+[A-Za-z0-9_\-]{20,}',
            0.85,
        ),
        CredentialType.JWT_TOKEN: (
            r"eyJ[A-Za-z0-9_-]*\.eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*",
            0.95,
        ),
        CredentialType.PASSWORD: (
            r'(?i)(?:password|passwd|pwd)["\'\s:=]+[^\s"\']{8,}',
            0.80,
        ),
        CredentialType.SSH_KEY: (
            r"-----BEGIN (?:RSA |DSA |EC |OPENSSH )?PRIVATE KEY-----",
            0.99,
        ),
        CredentialType.DATABASE_CONNECTION: (
            r'(?i)(?:mysql|postgresql|mongodb|redis)://[^\s"\']+',
            0.90,
        ),
        CredentialType.PRIVATE_KEY: (
            r"-----BEGIN (?:RSA |DSA |EC )?PRIVATE KEY-----",
            0.99,
        ),
    }

    # Medical Data Patterns (HIPAA)
    MEDICAL_PATTERNS = {
        MedicalDataType.MEDICAL_RECORD_NUMBER: (
            r"(?i)(?:mrn|medical[\s_-]?record[\s_-]?(?:number|num|#)?)[:\s]*[A-Z0-9]{6,}",
            0.85,
        ),
        MedicalDataType.HEALTH_PLAN_ID: (
            r"(?i)(?:health[\s_-]?plan[\s_-]?id|hicn)[:\s]*[A-Z0-9]{9,}",
            0.85,
        ),
        MedicalDataType.PATIENT_ID: (
            r"(?i)(?:patient[\s_-]?id)[:\s]*[A-Z0-9]{6,}",
            0.80,
        ),
    }

    # Keywords that indicate medical context
    MEDICAL_KEYWORDS = [
        "diagnosis",
        "medication",
        "prescription",
        "treatment",
        "patient",
        "medical",
        "health",
        "clinical",
        "lab",
        "blood",
        "test result",
        "physician",
        "doctor",
        "hospital",
    ]

    def classify(self, data: str, context: dict | None = None) -> DataClassification:
        """
        Classify data sensitivity.

        Args:
            data: Text to classify
            context: Optional context information

        Returns:
            DataClassification with sensitivity level and findings
        """
        context = context or {}

        # Detect PII
        pii_findings = self.detect_pii(data)

        # Detect credentials
        credential_findings = self._detect_credentials(data)

        # Detect medical data
        is_medical = self._detect_medical_context(data)

        # Determine sensitivity level
        sensitivity = DataSensitivity.PUBLIC
        confidence = 0.5
        data_types: list[str] = []
        risk_factors: list[str] = []

        # Elevate sensitivity based on findings
        if credential_findings:
            sensitivity = DataSensitivity.SECRET
            confidence = max(f.confidence for f in credential_findings)
            data_types.extend([f.credential_type.value for f in credential_findings])
            risk_factors.append("Contains credentials")

        elif pii_findings:
            # SSN and credit cards are most sensitive
            if any(f.pii_type in [PIIType.SSN, PIIType.CREDIT_CARD] for f in pii_findings):
                sensitivity = DataSensitivity.SECRET
                risk_factors.append("Contains highly sensitive PII")
            else:
                sensitivity = DataSensitivity.CONFIDENTIAL
                risk_factors.append("Contains PII")

            confidence = max(f.confidence for f in pii_findings)
            data_types.extend([f.pii_type.value for f in pii_findings])

        elif is_medical:
            sensitivity = DataSensitivity.CONFIDENTIAL
            confidence = 0.8
            data_types.append("medical")
            risk_factors.append("Contains medical information (HIPAA)")

        # Check context for additional sensitivity indicators
        if context.get("trust_level") == "EXTERNAL":
            risk_factors.append("From external source")
        if context.get("contains_user_input"):
            risk_factors.append("Contains user input")

        return DataClassification(
            sensitivity=sensitivity,
            confidence=confidence,
            pii_findings=pii_findings,
            credential_findings=credential_findings,
            data_types=list(set(data_types)),
            risk_factors=risk_factors,
        )

    def detect_pii(self, text: str) -> list[PIIFinding]:
        """
        Detect PII types in text.

        Args:
            text: Text to analyze

        Returns:
            List of PIIFinding objects
        """
        findings: list[PIIFinding] = []

        for pii_type, (pattern, base_confidence) in self.PII_PATTERNS.items():
            for match in re.finditer(pattern, text):
                # Redact the value for display
                value = match.group()
                redacted = self._redact_value(value, pii_type)

                # Extract context
                start = max(0, match.start() - 20)
                end = min(len(text), match.end() + 20)
                context = text[start:end]

                finding = PIIFinding(
                    pii_type=pii_type,
                    value_redacted=redacted,
                    confidence=base_confidence,
                    start_position=match.start(),
                    end_position=match.end(),
                    context=context,
                )
                findings.append(finding)

        return findings

    def _detect_credentials(self, text: str) -> list[CredentialFinding]:
        """Detect credentials in text."""
        findings: list[CredentialFinding] = []

        for cred_type, (pattern, base_confidence) in self.CREDENTIAL_PATTERNS.items():
            for match in re.finditer(pattern, text):
                finding = CredentialFinding(
                    credential_type=cred_type,
                    confidence=base_confidence,
                    start_position=match.start(),
                    end_position=match.end(),
                )
                findings.append(finding)

        return findings

    def _detect_medical_context(self, text: str) -> bool:
        """Check if text contains medical context."""
        text_lower = text.lower()

        # Check for medical keywords
        keyword_count = sum(1 for kw in self.MEDICAL_KEYWORDS if kw in text_lower)

        # Also check for medical patterns
        for pattern, confidence in self.MEDICAL_PATTERNS.values():
            if re.search(pattern, text):
                return True

        # Threshold for medical context
        return keyword_count >= 2

    def _redact_value(self, value: str, pii_type: PIIType) -> str:
        """Redact a PII value for safe display."""
        if pii_type == PIIType.EMAIL:
            parts = value.split("@")
            if len(parts) == 2:
                return f"{parts[0][:2]}***@{parts[1]}"
        elif pii_type == PIIType.SSN:
            return "***-**-" + value[-4:]
        elif pii_type == PIIType.CREDIT_CARD:
            return "****-****-****-" + value[-4:]
        elif pii_type == PIIType.PHONE:
            return "***-***-" + value[-4:]

        # Default: show first and last 2 characters
        if len(value) > 4:
            return value[:2] + "*" * (len(value) - 4) + value[-2:]
        return "*" * len(value)


class EnhancedTaintTracker:
    """
    Track sensitive data flow with sensitivity labels.

    Extends basic taint tracking with data classification and
    exfiltration detection.
    """

    def __init__(self, graph: AgentGraph):
        """
        Initialize enhanced taint tracker.

        Args:
            graph: AgentGraph to analyze
        """
        self.graph = graph
        self.classifier = DataSensitivityClassifier()
        self._sources: list[DataSource] = []

    def identify_sensitive_sources(self) -> list[DataSource]:
        """
        Identify sources of sensitive data in the graph.

        Returns:
            List of DataSource objects
        """
        sources: list[DataSource] = []

        for node in self.graph.nodes:
            # Entry points may receive sensitive data
            if node.is_entry_point:
                source = DataSource(
                    id=f"entry_{node.id}",
                    agent_id=node.id,
                    sensitivity=DataSensitivity.CONFIDENTIAL,  # Assume user input is confidential
                    data_types=["user_input"],
                    trust_level=node.trust_level,
                    description=f"Entry point: {node.name}",
                )
                sources.append(source)

            # External access may handle sensitive data
            if node.has_external_access:
                source = DataSource(
                    id=f"external_{node.id}",
                    agent_id=node.id,
                    sensitivity=DataSensitivity.INTERNAL,
                    data_types=["external_data"],
                    trust_level=TrustLevel.EXTERNAL,
                    description=f"External access: {node.name}",
                )
                sources.append(source)

            # Database access likely handles sensitive data
            if hasattr(node, "has_database_access") and node.has_database_access:
                source = DataSource(
                    id=f"db_{node.id}",
                    agent_id=node.id,
                    sensitivity=DataSensitivity.CONFIDENTIAL,
                    data_types=["database"],
                    trust_level=TrustLevel.PRIVILEGED,
                    description=f"Database access: {node.name}",
                )
                sources.append(source)

        self._sources = sources
        return sources

    def track_flow(self, source: DataSource) -> list[TaintPath]:
        """
        Track sensitive data flow from a source.

        Args:
            source: DataSource to track from

        Returns:
            List of TaintPath objects showing data flow
        """
        taint_paths: list[TaintPath] = []

        # Find all paths from source to all other nodes
        for node in self.graph.nodes:
            if node.id == source.agent_id:
                continue

            paths = self.graph.find_paths(source.agent_id, node.id)

            for path in paths:
                # Create taint labels for each hop
                labels = self._propagate_labels(source, path)

                # Determine severity based on path characteristics
                severity = self._calculate_path_severity(source, node, labels)

                # Check for exfiltration risk
                is_exfiltration = self._is_exfiltration_risk(source, node)

                # Generate recommendation
                recommendation = self._generate_recommendation(source, node, is_exfiltration)

                taint_path = TaintPath(
                    source=source,
                    sink_agent_id=node.id,
                    path=path,
                    labels=labels,
                    severity=severity,
                    is_exfiltration_risk=is_exfiltration,
                    recommendation=recommendation,
                )
                taint_paths.append(taint_path)

        return taint_paths

    def _propagate_labels(self, source: DataSource, path: list[str]) -> list[TaintLabel]:
        """Propagate sensitivity labels through a path."""
        labels: list[TaintLabel] = []

        current_sensitivity = source.sensitivity
        current_types = list(source.data_types)

        for i, agent_id in enumerate(path):
            node = self.graph.get_node(agent_id)
            if not node:
                continue

            # Check if agent might transform data
            # Higher trust agents might sanitize
            if node.trust_level.value >= TrustLevel.INTERNAL.value:
                # Could potentially reduce sensitivity
                pass

            label = TaintLabel(
                sensitivity=current_sensitivity,
                data_types=list(current_types),
                source_id=source.id,
                propagation_path=path[: i + 1],
            )
            labels.append(label)

        return labels

    def _calculate_path_severity(
        self, source: DataSource, sink_node: Any, labels: list[TaintLabel]
    ) -> Severity:
        """Calculate severity for a taint path."""
        # Base on sensitivity level
        if source.sensitivity == DataSensitivity.SECRET:
            base_severity = Severity.CRITICAL
        elif source.sensitivity == DataSensitivity.CONFIDENTIAL:
            base_severity = Severity.HIGH
        elif source.sensitivity == DataSensitivity.INTERNAL:
            base_severity = Severity.MEDIUM
        else:
            base_severity = Severity.LOW

        # Elevate for external sinks
        if hasattr(sink_node, "has_external_access") and sink_node.has_external_access:
            if base_severity == Severity.HIGH:
                return Severity.CRITICAL
            elif base_severity == Severity.MEDIUM:
                return Severity.HIGH

        # Elevate for code execution sinks
        if hasattr(sink_node, "has_code_execution") and sink_node.has_code_execution:
            if base_severity == Severity.MEDIUM:
                return Severity.HIGH

        return base_severity

    def _is_exfiltration_risk(self, source: DataSource, sink_node: Any) -> bool:
        """Check if this path represents an exfiltration risk."""
        # Exfiltration requires sensitive data reaching external sink
        if source.sensitivity in [DataSensitivity.SECRET, DataSensitivity.CONFIDENTIAL]:
            if hasattr(sink_node, "has_external_access") and sink_node.has_external_access:
                return True
            if hasattr(sink_node, "trust_level") and sink_node.trust_level == TrustLevel.EXTERNAL:
                return True

        return False

    def _generate_recommendation(
        self, source: DataSource, sink_node: Any, is_exfiltration: bool
    ) -> str:
        """Generate recommendation for a taint path."""
        recommendations = []

        if is_exfiltration:
            recommendations.append(
                f"Block or encrypt {source.sensitivity.value} data before external transmission"
            )
            recommendations.append("Implement data loss prevention (DLP) controls")

        if source.sensitivity == DataSensitivity.SECRET:
            recommendations.append("Add authentication and authorization checks")
            recommendations.append("Implement audit logging for all access")

        if hasattr(sink_node, "has_code_execution") and sink_node.has_code_execution:
            recommendations.append("Sanitize input before code execution")
            recommendations.append("Use sandboxed execution environment")

        return "; ".join(recommendations) if recommendations else "Review data flow"

    def detect_exfiltration(self, paths: list[TaintPath]) -> list[ExfiltrationRisk]:
        """
        Identify paths where sensitive data reaches external sinks.

        Args:
            paths: List of taint paths to analyze

        Returns:
            List of ExfiltrationRisk objects
        """
        risks: list[ExfiltrationRisk] = []

        for path in paths:
            if not path.is_exfiltration_risk:
                continue

            # Calculate risk score
            risk_score = self._calculate_exfiltration_risk(path)

            risk = ExfiltrationRisk(
                source=path.source,
                sink_agent_id=path.sink_agent_id,
                path=path.path,
                sensitivity=path.source.sensitivity,
                risk_score=risk_score,
                description=f"Sensitive {path.source.sensitivity.value} data may reach external sink {path.sink_agent_id}",
                recommendation=path.recommendation,
            )
            risks.append(risk)

        # Sort by risk score descending
        risks.sort(key=lambda r: r.risk_score, reverse=True)

        return risks

    def _calculate_exfiltration_risk(self, path: TaintPath) -> float:
        """Calculate risk score for an exfiltration path."""
        score = 0.0

        # Base on sensitivity
        if path.source.sensitivity == DataSensitivity.SECRET:
            score += 0.5
        elif path.source.sensitivity == DataSensitivity.CONFIDENTIAL:
            score += 0.3
        else:
            score += 0.1

        # Shorter paths are easier to exploit
        if len(path.path) <= 2:
            score += 0.3
        elif len(path.path) <= 4:
            score += 0.1

        # Add for severity
        severity_scores = {
            Severity.CRITICAL: 0.2,
            Severity.HIGH: 0.15,
            Severity.MEDIUM: 0.1,
            Severity.LOW: 0.05,
        }
        score += severity_scores.get(path.severity, 0)

        return min(score, 1.0)

    def get_flow_statistics(self) -> dict[str, Any]:
        """
        Get overall data flow statistics.

        Returns:
            Dictionary of flow statistics
        """
        if not self._sources:
            self.identify_sensitive_sources()

        all_paths: list[TaintPath] = []
        for source in self._sources:
            paths = self.track_flow(source)
            all_paths.extend(paths)

        exfiltration_risks = self.detect_exfiltration(all_paths)

        # Count by sensitivity
        sensitivity_counts = {s.value: 0 for s in DataSensitivity}
        for source in self._sources:
            sensitivity_counts[source.sensitivity.value] += 1

        # Count exfiltration paths
        exfil_count = sum(1 for p in all_paths if p.is_exfiltration_risk)

        return {
            "total_sources": len(self._sources),
            "total_paths": len(all_paths),
            "exfiltration_risks": len(exfiltration_risks),
            "exfiltration_paths": exfil_count,
            "by_sensitivity": sensitivity_counts,
            "highest_risk_score": max((r.risk_score for r in exfiltration_risks), default=0),
        }


def classify_data_sensitivity(data: str, context: dict | None = None) -> DataClassification:
    """
    Convenience function to classify data sensitivity.

    Args:
        data: Text to classify
        context: Optional context information

    Returns:
        DataClassification result
    """
    classifier = DataSensitivityClassifier()
    return classifier.classify(data, context)


def track_sensitive_data(graph: AgentGraph) -> list[TaintPath]:
    """
    Convenience function to track all sensitive data flows.

    Args:
        graph: AgentGraph to analyze

    Returns:
        List of TaintPath objects
    """
    tracker = EnhancedTaintTracker(graph)
    sources = tracker.identify_sensitive_sources()

    all_paths: list[TaintPath] = []
    for source in sources:
        paths = tracker.track_flow(source)
        all_paths.extend(paths)

    return all_paths


def find_exfiltration_risks(graph: AgentGraph) -> list[ExfiltrationRisk]:
    """
    Convenience function to find data exfiltration risks.

    Args:
        graph: AgentGraph to analyze

    Returns:
        List of ExfiltrationRisk objects
    """
    tracker = EnhancedTaintTracker(graph)
    sources = tracker.identify_sensitive_sources()

    all_paths: list[TaintPath] = []
    for source in sources:
        paths = tracker.track_flow(source)
        all_paths.extend(paths)

    return tracker.detect_exfiltration(all_paths)
