"""
Taint Analysis for Data Flow Tracking.

US-119: Data Flow Tracking - Taint analysis for sensitive data,
tracking user input through agent chains.

Identifies sources of untrusted data, tracks propagation through
the agent system, and detects sensitive sinks where data may leak.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from vantage_core.security.models import Severity, TrustLevel
from vantage_core.security.topology.graph import AgentGraph


class TaintType(str, Enum):
    """Types of taint sources."""

    USER_INPUT = "user_input"
    EXTERNAL_API = "external_api"
    FILE_CONTENT = "file_content"
    DATABASE_QUERY = "database_query"
    ENVIRONMENT = "environment"


class SinkType(str, Enum):
    """Types of sensitive sinks."""

    CODE_EXECUTION = "code_execution"
    DATABASE_WRITE = "database_write"
    FILE_WRITE = "file_write"
    NETWORK_OUTPUT = "network_output"
    LOG_OUTPUT = "log_output"
    USER_OUTPUT = "user_output"


@dataclass
class TaintSource:
    """
    Represents a source of tainted (untrusted) data.

    Taint sources are entry points where untrusted data enters the system.
    """

    id: str
    agent_id: str
    taint_type: TaintType
    description: str
    trust_level: TrustLevel = TrustLevel.EXTERNAL
    data_types: list[str] = field(default_factory=list)
    file_path: str | None = None
    line_number: int | None = None

    @property
    def is_high_risk(self) -> bool:
        """Check if this is a high-risk taint source."""
        return self.taint_type in [TaintType.USER_INPUT, TaintType.EXTERNAL_API]


@dataclass
class TaintSink:
    """
    Represents a sensitive sink where tainted data may leak.

    Sinks are operations that could be dangerous if they receive
    untrusted data without proper sanitization.
    """

    id: str
    agent_id: str
    sink_type: SinkType
    description: str
    required_trust_level: TrustLevel = TrustLevel.INTERNAL
    file_path: str | None = None
    line_number: int | None = None

    @property
    def is_critical(self) -> bool:
        """Check if this is a critical sink."""
        return self.sink_type in [SinkType.CODE_EXECUTION, SinkType.DATABASE_WRITE]


@dataclass
class TaintPath:
    """
    Represents a path of tainted data through the agent system.

    Tracks data flow from source to sink with intermediate agents.
    """

    source: TaintSource
    sink: TaintSink
    path: list[str]  # Agent IDs in order
    trust_gap: int  # Difference between source trust and sink requirement
    severity: Severity = Severity.MEDIUM
    sanitizers: list[str] = field(default_factory=list)  # Agents that sanitize
    evidence: list[str] = field(default_factory=list)
    recommendation: str = ""

    @property
    def is_sanitized(self) -> bool:
        """Check if path includes sanitization."""
        return len(self.sanitizers) > 0

    @property
    def hop_count(self) -> int:
        """Get number of hops in the path."""
        return len(self.path) - 1


@dataclass
class SensitiveSink:
    """
    Represents a location where sensitive data may leak.

    Used for tracking potential data exfiltration points.
    """

    sink: TaintSink
    incoming_taints: list[TaintSource]
    risk_score: float
    severity: Severity
    recommendation: str


class TaintTracker:
    """
    Track tainted data flow through agent systems.

    Identifies sources of untrusted data, tracks propagation,
    and detects dangerous sink access.
    """

    def __init__(self, graph: AgentGraph):
        """
        Initialize the taint tracker.

        Args:
            graph: AgentGraph to analyze
        """
        self.graph = graph
        self._sources: list[TaintSource] = []
        self._sinks: list[TaintSink] = []

    def identify_sources(self) -> list[TaintSource]:
        """
        Identify all taint sources in the graph.

        Returns:
            List of TaintSource objects
        """
        sources = []

        for node in self.graph.nodes:
            # Entry points are taint sources
            if node.is_entry_point:
                source = TaintSource(
                    id=f"source_{node.id}",
                    agent_id=node.id,
                    taint_type=TaintType.USER_INPUT,
                    description=f"Entry point agent: {node.name}",
                    trust_level=node.trust_level,
                )
                sources.append(source)

            # External access indicates potential external data
            if node.has_external_access:
                source = TaintSource(
                    id=f"ext_source_{node.id}",
                    agent_id=node.id,
                    taint_type=TaintType.EXTERNAL_API,
                    description=f"External API access in: {node.name}",
                    trust_level=TrustLevel.EXTERNAL,
                )
                sources.append(source)

            # Low trust level agents are sources
            if node.trust_level.value <= TrustLevel.USER.value:
                source = TaintSource(
                    id=f"low_trust_{node.id}",
                    agent_id=node.id,
                    taint_type=TaintType.USER_INPUT,
                    description=f"Low-trust agent: {node.name}",
                    trust_level=node.trust_level,
                )
                if source not in sources:
                    sources.append(source)

        self._sources = sources
        return sources

    def identify_sinks(self) -> list[TaintSink]:
        """
        Identify all sensitive sinks in the graph.

        Returns:
            List of TaintSink objects
        """
        sinks = []

        for node in self.graph.nodes:
            # Code execution is a critical sink
            if node.has_code_execution:
                sink = TaintSink(
                    id=f"exec_sink_{node.id}",
                    agent_id=node.id,
                    sink_type=SinkType.CODE_EXECUTION,
                    description=f"Code execution in: {node.name}",
                    required_trust_level=TrustLevel.PRIVILEGED,
                )
                sinks.append(sink)

            # High privilege agents are sinks
            if node.trust_level.value >= TrustLevel.PRIVILEGED.value:
                sink = TaintSink(
                    id=f"priv_sink_{node.id}",
                    agent_id=node.id,
                    sink_type=SinkType.DATABASE_WRITE,
                    description=f"Privileged agent: {node.name}",
                    required_trust_level=node.trust_level,
                )
                sinks.append(sink)

            # External output is a potential leak
            if node.has_external_access and node.out_degree > 0:
                sink = TaintSink(
                    id=f"output_sink_{node.id}",
                    agent_id=node.id,
                    sink_type=SinkType.NETWORK_OUTPUT,
                    description=f"External output from: {node.name}",
                    required_trust_level=TrustLevel.INTERNAL,
                )
                sinks.append(sink)

        self._sinks = sinks
        return sinks

    def track_user_input(self) -> list[TaintPath]:
        """
        Track user input through agent chains.

        Returns:
            List of TaintPath objects showing data flow
        """
        if not self._sources:
            self.identify_sources()
        if not self._sinks:
            self.identify_sinks()

        taint_paths = []

        # Find paths from each source to each sink
        for source in self._sources:
            if source.taint_type != TaintType.USER_INPUT:
                continue

            for sink in self._sinks:
                paths = self.graph.find_paths(source.agent_id, sink.agent_id)

                for path in paths:
                    # Calculate trust gap
                    trust_gap = sink.required_trust_level.value - source.trust_level.value

                    # Determine severity
                    severity = self._calculate_severity(source, sink, trust_gap, path)

                    # Find potential sanitizers
                    sanitizers = self._find_sanitizers(path)

                    # Generate recommendation
                    recommendation = self._generate_recommendation(
                        source, sink, trust_gap, sanitizers
                    )

                    taint_path = TaintPath(
                        source=source,
                        sink=sink,
                        path=path,
                        trust_gap=trust_gap,
                        severity=severity,
                        sanitizers=sanitizers,
                        evidence=[
                            f"Data flows from {source.taint_type.value} to {sink.sink_type.value}",
                            f"Trust gap: {trust_gap} levels",
                            f"Path length: {len(path)} agents",
                        ],
                        recommendation=recommendation,
                    )
                    taint_paths.append(taint_path)

        return taint_paths

    def find_sensitive_sinks(self) -> list[SensitiveSink]:
        """
        Find sinks that may receive sensitive data.

        Returns:
            List of SensitiveSink objects
        """
        if not self._sources:
            self.identify_sources()
        if not self._sinks:
            self.identify_sinks()

        sensitive_sinks = []

        for sink in self._sinks:
            # Find all sources that can reach this sink
            incoming_sources = []
            for source in self._sources:
                paths = self.graph.find_paths(source.agent_id, sink.agent_id)
                if paths:
                    incoming_sources.append(source)

            if not incoming_sources:
                continue

            # Calculate risk score
            risk_score = self._calculate_sink_risk(sink, incoming_sources)

            # Determine severity
            if risk_score >= 0.8:
                severity = Severity.CRITICAL
            elif risk_score >= 0.6:
                severity = Severity.HIGH
            elif risk_score >= 0.4:
                severity = Severity.MEDIUM
            else:
                severity = Severity.LOW

            # Generate recommendation
            recommendation = self._generate_sink_recommendation(sink, incoming_sources)

            sensitive_sink = SensitiveSink(
                sink=sink,
                incoming_taints=incoming_sources,
                risk_score=risk_score,
                severity=severity,
                recommendation=recommendation,
            )
            sensitive_sinks.append(sensitive_sink)

        return sensitive_sinks

    def get_taint_statistics(self) -> dict[str, Any]:
        """
        Get overall taint analysis statistics.

        Returns:
            Dictionary of taint statistics
        """
        if not self._sources:
            self.identify_sources()
        if not self._sinks:
            self.identify_sinks()

        paths = self.track_user_input()
        sensitive = self.find_sensitive_sinks()

        # Count by severity
        severity_counts = {sev: 0 for sev in Severity}
        for path in paths:
            severity_counts[path.severity] += 1

        # Count by source type
        source_type_counts = {t: 0 for t in TaintType}
        for source in self._sources:
            source_type_counts[source.taint_type] += 1

        # Count by sink type
        sink_type_counts = {t: 0 for t in SinkType}
        for sink in self._sinks:
            sink_type_counts[sink.sink_type] += 1

        return {
            "total_sources": len(self._sources),
            "total_sinks": len(self._sinks),
            "total_paths": len(paths),
            "sensitive_sinks": len(sensitive),
            "by_severity": {sev.name: count for sev, count in severity_counts.items()},
            "by_source_type": {t.value: count for t, count in source_type_counts.items()},
            "by_sink_type": {t.value: count for t, count in sink_type_counts.items()},
            "unsanitized_paths": sum(1 for p in paths if not p.is_sanitized),
        }

    def analyze_agent_taint_exposure(self, agent_id: str) -> dict[str, Any]:
        """
        Analyze taint exposure for a specific agent.

        Args:
            agent_id: Agent to analyze

        Returns:
            Dictionary of taint exposure metrics
        """
        node = self.graph.get_node(agent_id)
        if not node:
            return {}

        # Check if agent is a source
        is_source = any(s.agent_id == agent_id for s in self._sources)

        # Check if agent is a sink
        is_sink = any(s.agent_id == agent_id for s in self._sinks)

        # Find paths through this agent
        all_paths = self.track_user_input()
        paths_through = [p for p in all_paths if agent_id in p.path]

        # Calculate exposure metrics
        incoming_taint_count = 0
        outgoing_taint_count = 0

        for path in paths_through:
            idx = path.path.index(agent_id)
            if idx > 0:
                incoming_taint_count += 1
            if idx < len(path.path) - 1:
                outgoing_taint_count += 1

        return {
            "agent_id": agent_id,
            "is_taint_source": is_source,
            "is_taint_sink": is_sink,
            "paths_through": len(paths_through),
            "incoming_taints": incoming_taint_count,
            "outgoing_taints": outgoing_taint_count,
            "exposure_score": incoming_taint_count + outgoing_taint_count,
        }

    def _calculate_severity(
        self, source: TaintSource, sink: TaintSink, trust_gap: int, path: list[str]
    ) -> Severity:
        """Calculate severity for a taint path."""
        # Base on trust gap
        if trust_gap >= 3:
            severity = Severity.CRITICAL
        elif trust_gap >= 2:
            severity = Severity.HIGH
        elif trust_gap >= 1:
            severity = Severity.MEDIUM
        else:
            severity = Severity.LOW

        # Elevate for critical sinks
        if sink.is_critical:
            if severity == Severity.HIGH:
                severity = Severity.CRITICAL
            elif severity == Severity.MEDIUM:
                severity = Severity.HIGH

        # Elevate for short paths (easier to exploit)
        if len(path) <= 2:
            if severity == Severity.MEDIUM:
                severity = Severity.HIGH

        return severity

    def _find_sanitizers(self, path: list[str]) -> list[str]:
        """Find agents in the path that might act as sanitizers."""
        sanitizers = []

        for agent_id in path[1:-1]:  # Exclude source and sink
            node = self.graph.get_node(agent_id)
            if not node:
                continue

            # Higher trust level suggests validation
            if node.trust_level.value >= TrustLevel.INTERNAL.value:
                # Check if it's not just passing through
                if node.out_degree < node.in_degree:
                    sanitizers.append(agent_id)

        return sanitizers

    def _calculate_sink_risk(self, sink: TaintSink, incoming_sources: list[TaintSource]) -> float:
        """Calculate risk score for a sink."""
        risk = 0.0

        # Base risk on sink type
        if sink.sink_type == SinkType.CODE_EXECUTION:
            risk += 0.4
        elif sink.sink_type == SinkType.DATABASE_WRITE:
            risk += 0.3
        elif sink.sink_type == SinkType.FILE_WRITE:
            risk += 0.2

        # Add risk for each incoming source
        for source in incoming_sources:
            source_risk = 0.0
            if source.taint_type == TaintType.USER_INPUT:
                source_risk = 0.3
            elif source.taint_type == TaintType.EXTERNAL_API:
                source_risk = 0.2
            else:
                source_risk = 0.1

            risk += source_risk

        return min(risk, 1.0)

    def _generate_recommendation(
        self,
        source: TaintSource,
        sink: TaintSink,
        trust_gap: int,
        sanitizers: list[str],
    ) -> str:
        """Generate recommendation for a taint path."""
        recommendations = []

        if not sanitizers:
            recommendations.append(f"Add input validation before {sink.agent_id}")

        if trust_gap >= 2:
            recommendations.append("Implement trust boundary checks at intermediate agents")

        if sink.is_critical:
            recommendations.append(f"Add strict access controls for {sink.sink_type.value}")

        if source.taint_type == TaintType.USER_INPUT:
            recommendations.append("Sanitize and validate all user input at entry point")

        return "; ".join(recommendations) if recommendations else "Review data flow for security"

    def _generate_sink_recommendation(
        self, sink: TaintSink, incoming_sources: list[TaintSource]
    ) -> str:
        """Generate recommendation for a sensitive sink."""
        recommendations = []

        if len(incoming_sources) > 1:
            recommendations.append(
                f"Consolidate {len(incoming_sources)} input sources through validated gateway"
            )

        if any(s.is_high_risk for s in incoming_sources):
            recommendations.append("Implement strict input validation for high-risk sources")

        if sink.is_critical:
            recommendations.append("Add defense-in-depth with multiple validation layers")

        return "; ".join(recommendations) if recommendations else "Review sink access patterns"


def track_data_flow(graph: AgentGraph) -> list[TaintPath]:
    """
    Convenience function to track tainted data flow.

    Args:
        graph: AgentGraph to analyze

    Returns:
        List of TaintPath objects
    """
    tracker = TaintTracker(graph)
    return tracker.track_user_input()


def find_data_leaks(graph: AgentGraph) -> list[SensitiveSink]:
    """
    Convenience function to find potential data leak sinks.

    Args:
        graph: AgentGraph to analyze

    Returns:
        List of SensitiveSink objects
    """
    tracker = TaintTracker(graph)
    return tracker.find_sensitive_sinks()
