"""
Per-Agent Risk Scores (US-124).

Calculates individual risk scores for each agent in the topology
to identify the highest risk agents requiring attention.
"""

from dataclasses import dataclass, field

from vantage_core.security.models import (
    SecurityAgent,
    SecurityFinding,
    Severity,
    ToolCategory,
    TrustLevel,
)
from vantage_core.security.topology.graph import AgentGraph


@dataclass
class AgentRiskProfile:
    """
    Risk profile for a single agent.

    Contains individual risk scores by category and
    an overall risk score.
    """

    agent_id: str
    agent_name: str
    overall_risk: float  # 0-100, higher is riskier
    prompt_injection_risk: float  # 0-10
    privilege_escalation_risk: float  # 0-10
    data_leakage_risk: float  # 0-10
    tool_abuse_risk: float  # 0-10
    connectivity_risk: float  # 0-10
    finding_count: int = 0
    critical_findings: int = 0
    trust_level: TrustLevel = TrustLevel.INTERNAL
    recommendations: list[str] = field(default_factory=list)

    @property
    def is_high_risk(self) -> bool:
        """Check if agent is high risk (>70)."""
        return self.overall_risk > 70.0

    @property
    def is_critical(self) -> bool:
        """Check if agent has critical risk (>85)."""
        return self.overall_risk > 85.0

    @property
    def primary_risk_factor(self) -> str:
        """Get the primary risk factor for this agent."""
        risks = {
            "prompt_injection": self.prompt_injection_risk,
            "privilege_escalation": self.privilege_escalation_risk,
            "data_leakage": self.data_leakage_risk,
            "tool_abuse": self.tool_abuse_risk,
            "connectivity": self.connectivity_risk,
        }
        return max(risks, key=risks.get)


class AgentRiskScorer:
    """
    Calculates per-agent risk scores.

    Analyzes each agent's capabilities, trust level, tools,
    and associated findings to produce risk profiles.
    """

    # Risk factor weights
    WEIGHTS = {
        "prompt_injection": 2.0,
        "privilege_escalation": 2.5,
        "data_leakage": 2.0,
        "tool_abuse": 1.5,
        "connectivity": 1.0,
    }

    def __init__(
        self,
        weights: dict[str, float] | None = None,
    ):
        """
        Initialize the scorer.

        Args:
            weights: Custom risk factor weights
        """
        self.weights = weights or self.WEIGHTS

    def score_agent(
        self,
        agent: SecurityAgent,
        graph: AgentGraph | None = None,
        findings: list[SecurityFinding] | None = None,
    ) -> AgentRiskProfile:
        """
        Calculate risk profile for a single agent.

        Args:
            agent: Agent to analyze
            graph: Topology graph for connectivity analysis
            findings: Findings associated with this agent

        Returns:
            AgentRiskProfile for the agent
        """
        # Calculate individual risk factors
        prompt_injection_risk = self._calculate_prompt_injection_risk(agent, findings)
        privilege_escalation_risk = self._calculate_privilege_escalation_risk(agent, graph)
        data_leakage_risk = self._calculate_data_leakage_risk(agent)
        tool_abuse_risk = self._calculate_tool_abuse_risk(agent)
        connectivity_risk = self._calculate_connectivity_risk(agent, graph)

        # Calculate weighted overall risk
        total_weight = sum(self.weights.values())
        weighted_sum = (
            prompt_injection_risk * self.weights["prompt_injection"]
            + privilege_escalation_risk * self.weights["privilege_escalation"]
            + data_leakage_risk * self.weights["data_leakage"]
            + tool_abuse_risk * self.weights["tool_abuse"]
            + connectivity_risk * self.weights["connectivity"]
        )
        overall_risk = (weighted_sum / total_weight) * 10  # Scale to 0-100

        # Count findings
        agent_findings = [f for f in (findings or []) if f.agent_id == agent.id]
        finding_count = len(agent_findings)
        critical_findings = sum(
            1 for f in agent_findings if f.severity in [Severity.CRITICAL, Severity.HIGH]
        )

        # Boost risk for critical findings
        if critical_findings > 0:
            overall_risk = min(100, overall_risk + critical_findings * 5)

        # Generate recommendations
        recommendations = self._generate_recommendations(
            agent,
            prompt_injection_risk,
            privilege_escalation_risk,
            data_leakage_risk,
            tool_abuse_risk,
            connectivity_risk,
        )

        return AgentRiskProfile(
            agent_id=agent.id,
            agent_name=agent.name,
            overall_risk=round(overall_risk, 2),
            prompt_injection_risk=round(prompt_injection_risk, 2),
            privilege_escalation_risk=round(privilege_escalation_risk, 2),
            data_leakage_risk=round(data_leakage_risk, 2),
            tool_abuse_risk=round(tool_abuse_risk, 2),
            connectivity_risk=round(connectivity_risk, 2),
            finding_count=finding_count,
            critical_findings=critical_findings,
            trust_level=agent.trust_level,
            recommendations=recommendations,
        )

    def score_all_agents(
        self,
        agents: list[SecurityAgent],
        graph: AgentGraph | None = None,
        findings: list[SecurityFinding] | None = None,
    ) -> dict[str, AgentRiskProfile]:
        """
        Calculate risk profiles for all agents.

        Args:
            agents: List of agents to analyze
            graph: Topology graph
            findings: All findings

        Returns:
            Dictionary of agent_id -> AgentRiskProfile
        """
        profiles = {}
        for agent in agents:
            profile = self.score_agent(agent, graph, findings)
            profiles[agent.id] = profile
        return profiles

    def get_highest_risk_agents(
        self,
        agents: list[SecurityAgent],
        graph: AgentGraph | None = None,
        findings: list[SecurityFinding] | None = None,
        limit: int = 5,
    ) -> list[AgentRiskProfile]:
        """
        Get the highest risk agents.

        Args:
            agents: List of agents
            graph: Topology graph
            findings: All findings
            limit: Number of agents to return

        Returns:
            List of AgentRiskProfile sorted by risk descending
        """
        profiles = self.score_all_agents(agents, graph, findings)
        sorted_profiles = sorted(profiles.values(), key=lambda p: p.overall_risk, reverse=True)
        return sorted_profiles[:limit]

    def _calculate_prompt_injection_risk(
        self,
        agent: SecurityAgent,
        findings: list[SecurityFinding] | None,
    ) -> float:
        """Calculate prompt injection risk (0-10)."""
        risk = 0.0

        # Base risk from trust level
        if agent.trust_level == TrustLevel.EXTERNAL:
            risk += 3.0  # External agents receive untrusted input
        elif agent.trust_level == TrustLevel.USER:
            risk += 2.0

        # Risk from system prompt
        if agent.system_prompt:
            # Check for injection-vulnerable patterns
            prompt_lower = agent.system_prompt.lower()
            risky_patterns = [
                "ignore previous",
                "execute",
                "run code",
                "system command",
            ]
            for pattern in risky_patterns:
                if pattern in prompt_lower:
                    risk += 1.5
                    break

            # Longer prompts with more complexity can be harder to protect
            if len(agent.system_prompt) > 1000:
                risk += 1.0

        # Risk from findings
        if findings:
            injection_findings = [
                f for f in findings if f.agent_id == agent.id and "injection" in f.category.value
            ]
            risk += min(len(injection_findings) * 2.0, 4.0)

        return min(risk, 10.0)

    def _calculate_privilege_escalation_risk(
        self,
        agent: SecurityAgent,
        graph: AgentGraph | None,
    ) -> float:
        """Calculate privilege escalation risk (0-10)."""
        risk = 0.0

        # Risk from trust level mismatch with tools
        if agent.tools:
            highest_tool_trust = agent.highest_tool_trust
            if highest_tool_trust.value > agent.trust_level.value:
                trust_gap = highest_tool_trust.value - agent.trust_level.value
                risk += trust_gap * 2.0

        # Risk from delegation
        if agent.allow_delegation:
            risk += 2.0
            if agent.trust_level.value < TrustLevel.PRIVILEGED.value:
                risk += 1.5  # Low-trust agent can delegate

        # Risk from graph position
        if graph:
            node = graph.get_node(agent.id)
            if node:
                # High out-degree increases escalation risk
                if node.out_degree > 3:
                    risk += 1.0
                # Being connected to privileged agents
                for neighbor_id in graph.get_neighbors(agent.id):
                    neighbor = graph.get_node(neighbor_id)
                    if neighbor and neighbor.trust_level.value > agent.trust_level.value:
                        risk += 0.5

        return min(risk, 10.0)

    def _calculate_data_leakage_risk(
        self,
        agent: SecurityAgent,
    ) -> float:
        """Calculate data leakage risk (0-10)."""
        risk = 0.0

        # Risk from external access
        if agent.has_external_access:
            risk += 3.0

        # Risk from tools with network/API access
        for tool in agent.tools:
            if ToolCategory.NETWORK in tool.categories:
                risk += 2.0
            if ToolCategory.EXTERNAL_API in tool.categories:
                risk += 1.5
            if ToolCategory.FILE_SYSTEM in tool.categories:
                risk += 1.0

        # Risk from memory scope
        if agent.memory_scope == "shared":
            risk += 1.5
        elif agent.memory_scope == "global":
            risk += 2.0

        # High trust agents have more sensitive data access
        if agent.trust_level.value >= TrustLevel.PRIVILEGED.value:
            risk += 1.5

        return min(risk, 10.0)

    def _calculate_tool_abuse_risk(
        self,
        agent: SecurityAgent,
    ) -> float:
        """Calculate tool abuse risk (0-10)."""
        risk = 0.0

        # Base risk from number of tools
        tool_count = len(agent.tools)
        if tool_count > 5:
            risk += 2.0
        elif tool_count > 2:
            risk += 1.0

        # Risk from specific tool categories
        for tool in agent.tools:
            if ToolCategory.CODE_EXECUTION in tool.categories:
                risk += 3.0
            if ToolCategory.SYSTEM in tool.categories:
                risk += 2.5
            if ToolCategory.DATABASE in tool.categories:
                risk += 1.5

            # Tools with side effects
            if tool.has_side_effects:
                risk += 1.0

            # High risk tools
            if tool.risk_score > 7:
                risk += 1.5

        return min(risk, 10.0)

    def _calculate_connectivity_risk(
        self,
        agent: SecurityAgent,
        graph: AgentGraph | None,
    ) -> float:
        """Calculate connectivity/topology risk (0-10)."""
        risk = 0.0

        if not graph:
            return risk

        node = graph.get_node(agent.id)
        if not node:
            return risk

        # Risk from high connectivity
        total_degree = node.in_degree + node.out_degree
        if total_degree > 6:
            risk += 3.0
        elif total_degree > 3:
            risk += 1.5

        # Risk from being an articulation point
        articulation_points = graph.get_articulation_points()
        if agent.id in articulation_points:
            risk += 3.0

        # Risk from being a hub
        hub_nodes = graph.get_hub_nodes()
        if agent.id in [n.id for n in hub_nodes]:
            risk += 2.0

        # Risk from being an entry point
        if node.is_entry_point:
            risk += 2.0

        return min(risk, 10.0)

    def _generate_recommendations(
        self,
        agent: SecurityAgent,
        prompt_risk: float,
        escalation_risk: float,
        leakage_risk: float,
        tool_risk: float,
        connectivity_risk: float,
    ) -> list[str]:
        """Generate agent-specific recommendations."""
        recommendations = []

        if prompt_risk > 7:
            recommendations.append(
                "High prompt injection risk: Add input validation and sanitization."
            )
        elif prompt_risk > 4:
            recommendations.append(
                "Moderate prompt injection risk: Review system prompt for injection vulnerabilities."
            )

        if escalation_risk > 7:
            recommendations.append(
                "High privilege escalation risk: Restrict tool access and delegation capabilities."
            )
        elif escalation_risk > 4:
            recommendations.append(
                "Moderate escalation risk: Review trust level assignments for tools."
            )

        if leakage_risk > 7:
            recommendations.append(
                "High data leakage risk: Add output filtering and audit logging."
            )
        elif leakage_risk > 4:
            recommendations.append(
                "Moderate leakage risk: Monitor external API calls and file access."
            )

        if tool_risk > 7:
            recommendations.append(
                "High tool abuse risk: Implement sandboxing for dangerous tools."
            )
        elif tool_risk > 4:
            recommendations.append(
                "Moderate tool risk: Add rate limiting and validation for tool inputs."
            )

        if connectivity_risk > 7:
            recommendations.append(
                "High connectivity risk: Consider isolating this agent or adding message filtering."
            )
        elif connectivity_risk > 4:
            recommendations.append(
                "Moderate connectivity risk: Monitor inter-agent communications."
            )

        return recommendations


def calculate_agent_risks(
    agents: list[SecurityAgent],
    graph: AgentGraph | None = None,
    findings: list[SecurityFinding] | None = None,
) -> dict[str, AgentRiskProfile]:
    """
    Convenience function to calculate agent risk profiles.

    Args:
        agents: List of agents
        graph: Topology graph
        findings: Security findings

    Returns:
        Dictionary of agent_id -> AgentRiskProfile
    """
    scorer = AgentRiskScorer()
    return scorer.score_all_agents(agents, graph, findings)
