"""
Score Explanation (US-126).

Generates human-readable score breakdowns with contributing
factors and their weights.
"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ContributingFactor:
    """
    A factor contributing to the security score.

    Contains the factor description, impact, and recommendations.
    """

    name: str
    description: str
    impact: float  # Points impact (positive or negative)
    weight: float  # Weight in overall calculation (0-1)
    category: str  # vulnerability, trust, communication, agent
    details: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)

    @property
    def impact_level(self) -> str:
        """Get impact level description."""
        abs_impact = abs(self.impact)
        if abs_impact > 15:
            return "critical"
        elif abs_impact > 10:
            return "high"
        elif abs_impact > 5:
            return "moderate"
        else:
            return "low"

    @property
    def is_negative(self) -> bool:
        """Check if factor has negative impact."""
        return self.impact < 0


@dataclass
class ScoreExplanation:
    """
    Complete explanation of an ATSS score.

    Contains the narrative explanation, contributing factors,
    and prioritized recommendations.
    """

    overall_score: float
    grade: str
    summary: str
    factors: list[ContributingFactor]
    top_risks: list[str]
    top_recommendations: list[str]
    detailed_breakdown: dict[str, Any] = field(default_factory=dict)

    @property
    def negative_factors(self) -> list[ContributingFactor]:
        """Get factors with negative impact."""
        return [f for f in self.factors if f.is_negative]

    @property
    def positive_factors(self) -> list[ContributingFactor]:
        """Get factors with positive impact."""
        return [f for f in self.factors if not f.is_negative]


class ScoreExplainer:
    """
    Generates human-readable explanations for ATSS scores.

    Takes score components and generates narratives, identifies
    contributing factors, and prioritizes recommendations.
    """

    def explain(
        self,
        overall_score: float,
        grade: str,
        vulnerability_score: float,
        trust_boundary_score: float,
        communication_score: float,
        agent_risk_score: float,
        finding_count: int = 0,
        agent_count: int = 0,
        high_risk_agents: int = 0,
        escalation_paths: int = 0,
        boundary_crossings: int = 0,
        hub_nodes: int = 0,
        articulation_points: int = 0,
        critical_findings: int = 0,
        metadata: dict[str, Any] | None = None,
    ) -> ScoreExplanation:
        """
        Generate complete score explanation.

        Args:
            overall_score: Overall ATSS score
            grade: Letter grade
            vulnerability_score: Vulnerability component
            trust_boundary_score: Trust boundary component
            communication_score: Communication pattern component
            agent_risk_score: Per-agent risk component
            finding_count: Total findings
            agent_count: Total agents
            high_risk_agents: Number of high-risk agents
            escalation_paths: Number of escalation paths
            boundary_crossings: Number of boundary crossings
            hub_nodes: Number of hub nodes
            articulation_points: Number of articulation points
            critical_findings: Critical/high findings
            metadata: Additional metadata

        Returns:
            ScoreExplanation with full breakdown
        """
        factors = []
        risks = []
        recommendations = []

        # Generate summary
        summary = self._generate_summary(
            overall_score,
            grade,
            agent_count,
            finding_count,
        )

        # Analyze vulnerability score
        vuln_factors = self._analyze_vulnerability_score(
            vulnerability_score,
            finding_count,
            critical_findings,
        )
        factors.extend(vuln_factors)

        # Analyze trust boundary score
        trust_factors = self._analyze_trust_score(
            trust_boundary_score,
            boundary_crossings,
            escalation_paths,
        )
        factors.extend(trust_factors)

        # Analyze communication score
        comm_factors = self._analyze_communication_score(
            communication_score,
            hub_nodes,
            articulation_points,
            agent_count,
        )
        factors.extend(comm_factors)

        # Analyze agent risk score
        agent_factors = self._analyze_agent_risk_score(
            agent_risk_score,
            high_risk_agents,
            agent_count,
        )
        factors.extend(agent_factors)

        # Sort factors by absolute impact
        factors.sort(key=lambda f: abs(f.impact), reverse=True)

        # Extract top risks
        risks = [f.description for f in factors if f.is_negative and abs(f.impact) > 5][:5]

        # Extract and prioritize recommendations
        all_recs = []
        for factor in factors:
            all_recs.extend(factor.recommendations)
        recommendations = list(dict.fromkeys(all_recs))[:7]  # Dedupe, keep top 7

        # Build detailed breakdown
        detailed_breakdown = {
            "components": {
                "vulnerability": {
                    "score": vulnerability_score,
                    "weight": 0.40,
                    "contribution": vulnerability_score * 0.40,
                },
                "trust_boundary": {
                    "score": trust_boundary_score,
                    "weight": 0.25,
                    "contribution": trust_boundary_score * 0.25,
                },
                "communication": {
                    "score": communication_score,
                    "weight": 0.20,
                    "contribution": communication_score * 0.20,
                },
                "agent_risk": {
                    "score": agent_risk_score,
                    "weight": 0.15,
                    "contribution": agent_risk_score * 0.15,
                },
            },
            "metrics": {
                "finding_count": finding_count,
                "agent_count": agent_count,
                "high_risk_agents": high_risk_agents,
                "escalation_paths": escalation_paths,
                "boundary_crossings": boundary_crossings,
            },
        }

        return ScoreExplanation(
            overall_score=overall_score,
            grade=grade,
            summary=summary,
            factors=factors,
            top_risks=risks,
            top_recommendations=recommendations,
            detailed_breakdown=detailed_breakdown,
        )

    def _generate_summary(
        self,
        score: float,
        grade: str,
        agent_count: int,
        finding_count: int,
    ) -> str:
        """Generate a narrative summary of the score."""
        if score >= 90:
            posture = "excellent"
            outlook = "The system demonstrates strong security practices."
        elif score >= 80:
            posture = "good"
            outlook = "Minor improvements could strengthen security further."
        elif score >= 70:
            posture = "acceptable"
            outlook = "Several areas need attention to reduce risk."
        elif score >= 60:
            posture = "poor"
            outlook = "Significant security improvements are required."
        else:
            posture = "critical"
            outlook = "Immediate action is needed to address severe vulnerabilities."

        summary = (
            f"The Agent Topology Security Score is {score:.1f} (Grade: {grade}), "
            f"indicating {posture} security posture. "
            f"Analysis covered {agent_count} agent(s) and identified {finding_count} finding(s). "
            f"{outlook}"
        )

        return summary

    def _analyze_vulnerability_score(
        self,
        score: float,
        finding_count: int,
        critical_count: int,
    ) -> list[ContributingFactor]:
        """Analyze vulnerability score component."""
        factors = []

        # Overall vulnerability impact
        score_diff = score - 100  # How much below perfect
        if score_diff < 0:
            impact = score_diff * 0.40  # Weight applied

            factor = ContributingFactor(
                name="Vulnerability Findings",
                description=f"{finding_count} security finding(s) detected",
                impact=round(impact, 2),
                weight=0.40,
                category="vulnerability",
                details=[
                    f"Score: {score:.1f}/100",
                    f"Total findings: {finding_count}",
                    f"Critical/High findings: {critical_count}",
                ],
            )

            if critical_count > 0:
                factor.recommendations.append(
                    f"Address {critical_count} critical/high severity finding(s) immediately"
                )
            if finding_count > 10:
                factor.recommendations.append("Review code for common vulnerability patterns")
            elif finding_count > 0:
                factor.recommendations.append(
                    "Fix identified vulnerabilities and add input validation"
                )

            factors.append(factor)

        return factors

    def _analyze_trust_score(
        self,
        score: float,
        crossings: int,
        paths: int,
    ) -> list[ContributingFactor]:
        """Analyze trust boundary score component."""
        factors = []

        score_diff = score - 100
        if score_diff < 0:
            impact = score_diff * 0.25

            details = [
                f"Score: {score:.1f}/100",
                f"Boundary crossings: {crossings}",
                f"Escalation paths: {paths}",
            ]

            recs = []
            if paths > 0:
                recs.append(f"Review and secure {paths} privilege escalation path(s)")
            if crossings > 5:
                recs.append("Reduce trust boundary crossings by consolidating trust zones")

            factor = ContributingFactor(
                name="Trust Boundary Violations",
                description=f"{crossings} boundary crossing(s) and {paths} escalation path(s)",
                impact=round(impact, 2),
                weight=0.25,
                category="trust",
                details=details,
                recommendations=recs,
            )
            factors.append(factor)

        return factors

    def _analyze_communication_score(
        self,
        score: float,
        hubs: int,
        articulation: int,
        agent_count: int,
    ) -> list[ContributingFactor]:
        """Analyze communication pattern score component."""
        factors = []

        score_diff = score - 100
        if score_diff < 0:
            impact = score_diff * 0.20

            details = [
                f"Score: {score:.1f}/100",
                f"Hub nodes: {hubs}",
                f"Single points of failure: {articulation}",
            ]

            recs = []
            if articulation > 0:
                recs.append(f"Add redundancy for {articulation} single point(s) of failure")
            if hubs > agent_count * 0.3:
                recs.append("Distribute responsibilities to reduce hub concentration")

            factor = ContributingFactor(
                name="Communication Pattern Risks",
                description=f"Topology has {hubs} hub(s) and {articulation} critical point(s)",
                impact=round(impact, 2),
                weight=0.20,
                category="communication",
                details=details,
                recommendations=recs,
            )
            factors.append(factor)

        return factors

    def _analyze_agent_risk_score(
        self,
        score: float,
        high_risk: int,
        total: int,
    ) -> list[ContributingFactor]:
        """Analyze per-agent risk score component."""
        factors = []

        score_diff = score - 100
        if score_diff < 0:
            impact = score_diff * 0.15

            pct_high_risk = (high_risk / total * 100) if total > 0 else 0

            details = [
                f"Score: {score:.1f}/100",
                f"High-risk agents: {high_risk}/{total}",
                f"Percentage: {pct_high_risk:.1f}%",
            ]

            recs = []
            if high_risk > 0:
                recs.append(f"Harden {high_risk} high-risk agent(s) with additional controls")
            if pct_high_risk > 50:
                recs.append("Review agent permissions and reduce capabilities")

            factor = ContributingFactor(
                name="Agent-Level Risks",
                description=f"{high_risk} of {total} agent(s) classified as high-risk",
                impact=round(impact, 2),
                weight=0.15,
                category="agent",
                details=details,
                recommendations=recs,
            )
            factors.append(factor)

        return factors

    def format_as_text(self, explanation: ScoreExplanation) -> str:
        """
        Format explanation as readable text.

        Args:
            explanation: ScoreExplanation to format

        Returns:
            Formatted text string
        """
        lines = [
            "# Security Score Explanation",
            "",
            f"**Score: {explanation.overall_score:.1f} (Grade: {explanation.grade})**",
            "",
            explanation.summary,
            "",
            "## Top Risks",
        ]

        for i, risk in enumerate(explanation.top_risks, 1):
            lines.append(f"{i}. {risk}")

        lines.extend(
            [
                "",
                "## Recommendations",
            ]
        )

        for i, rec in enumerate(explanation.top_recommendations, 1):
            lines.append(f"{i}. {rec}")

        lines.extend(
            [
                "",
                "## Score Breakdown",
            ]
        )

        components = explanation.detailed_breakdown.get("components", {})
        for name, data in components.items():
            lines.append(
                f"- {name.replace('_', ' ').title()}: "
                f"{data['score']:.1f} (weight: {data['weight']:.0%})"
            )

        return "\n".join(lines)


def generate_score_explanation(
    overall_score: float,
    grade: str,
    vulnerability_score: float,
    trust_boundary_score: float,
    communication_score: float,
    agent_risk_score: float,
    **kwargs,
) -> ScoreExplanation:
    """
    Convenience function to generate score explanation.

    Args:
        overall_score: Overall ATSS score
        grade: Letter grade
        vulnerability_score: Vulnerability component
        trust_boundary_score: Trust boundary component
        communication_score: Communication pattern component
        agent_risk_score: Per-agent risk component
        **kwargs: Additional parameters

    Returns:
        ScoreExplanation
    """
    explainer = ScoreExplainer()
    return explainer.explain(
        overall_score,
        grade,
        vulnerability_score,
        trust_boundary_score,
        communication_score,
        agent_risk_score,
        **kwargs,
    )
