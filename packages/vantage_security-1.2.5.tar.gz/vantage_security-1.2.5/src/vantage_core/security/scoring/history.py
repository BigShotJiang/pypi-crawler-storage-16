"""
Score History Tracking (US-125).

Tracks ATSS score changes over time for trend analysis
and regression detection.
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any


class ScoreTrend(str, Enum):
    """Direction of score trend."""

    IMPROVING = "improving"
    STABLE = "stable"
    DECLINING = "declining"
    CRITICAL_DECLINE = "critical_decline"


@dataclass
class ScoreHistoryEntry:
    """
    Single entry in score history.

    Contains the score snapshot and component breakdowns
    at a specific point in time.
    """

    timestamp: datetime
    overall_score: float
    grade: str
    vulnerability_score: float
    trust_boundary_score: float
    communication_score: float
    agent_risk_score: float
    agent_count: int
    finding_count: int
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def component_scores(self) -> dict[str, float]:
        """Get all component scores."""
        return {
            "vulnerability": self.vulnerability_score,
            "trust_boundary": self.trust_boundary_score,
            "communication": self.communication_score,
            "agent_risk": self.agent_risk_score,
        }


@dataclass
class TrendAnalysis:
    """
    Analysis of score trends over time.

    Contains trend direction, percentage changes,
    and regression alerts.
    """

    trend: ScoreTrend
    change_7d: float  # 7-day change
    change_30d: float  # 30-day change
    average_score: float
    min_score: float
    max_score: float
    is_regression: bool
    regression_severity: str | None = None  # mild, moderate, severe
    improving_components: list[str] = field(default_factory=list)
    declining_components: list[str] = field(default_factory=list)


class ScoreHistoryTracker:
    """
    Tracks and analyzes ATSS score history.

    Stores historical scores and provides trend analysis,
    regression detection, and comparison features.
    """

    def __init__(
        self,
        project_id: str = "default",
        max_entries: int = 1000,
        regression_threshold: float = 10.0,
    ):
        """
        Initialize the tracker.

        Args:
            project_id: Project identifier
            max_entries: Maximum history entries to keep
            regression_threshold: Score drop to trigger regression alert
        """
        self.project_id = project_id
        self.max_entries = max_entries
        self.regression_threshold = regression_threshold
        self._history: list[ScoreHistoryEntry] = []

    def add_entry(self, entry: ScoreHistoryEntry) -> None:
        """
        Add a score entry to history.

        Args:
            entry: Score history entry
        """
        self._history.append(entry)

        # Sort by timestamp
        self._history.sort(key=lambda e: e.timestamp)

        # Trim if exceeds max
        if len(self._history) > self.max_entries:
            self._history = self._history[-self.max_entries :]

    def record_score(
        self,
        overall_score: float,
        grade: str,
        vulnerability_score: float,
        trust_boundary_score: float,
        communication_score: float,
        agent_risk_score: float,
        agent_count: int = 0,
        finding_count: int = 0,
        metadata: dict[str, Any] | None = None,
    ) -> ScoreHistoryEntry:
        """
        Record a new score snapshot.

        Args:
            overall_score: Overall ATSS score
            grade: Letter grade
            vulnerability_score: Vulnerability component score
            trust_boundary_score: Trust boundary component score
            communication_score: Communication pattern score
            agent_risk_score: Per-agent risk score
            agent_count: Number of agents
            finding_count: Number of findings
            metadata: Additional metadata

        Returns:
            Created history entry
        """
        entry = ScoreHistoryEntry(
            timestamp=datetime.utcnow(),
            overall_score=overall_score,
            grade=grade,
            vulnerability_score=vulnerability_score,
            trust_boundary_score=trust_boundary_score,
            communication_score=communication_score,
            agent_risk_score=agent_risk_score,
            agent_count=agent_count,
            finding_count=finding_count,
            metadata=metadata or {},
        )

        self.add_entry(entry)
        return entry

    def get_history(
        self,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
        limit: int | None = None,
    ) -> list[ScoreHistoryEntry]:
        """
        Get score history within a date range.

        Args:
            start_date: Start of range (inclusive)
            end_date: End of range (inclusive)
            limit: Maximum entries to return

        Returns:
            List of history entries
        """
        entries = self._history

        if start_date:
            entries = [e for e in entries if e.timestamp >= start_date]

        if end_date:
            entries = [e for e in entries if e.timestamp <= end_date]

        if limit:
            entries = entries[-limit:]

        return entries

    def get_latest(self) -> ScoreHistoryEntry | None:
        """Get the most recent score entry."""
        if not self._history:
            return None
        return self._history[-1]

    def get_previous(self) -> ScoreHistoryEntry | None:
        """Get the second most recent score entry."""
        if len(self._history) < 2:
            return None
        return self._history[-2]

    def analyze_trend(
        self,
        days: int = 30,
    ) -> TrendAnalysis:
        """
        Analyze score trends over a period.

        Args:
            days: Number of days to analyze

        Returns:
            TrendAnalysis with trend details
        """
        if not self._history:
            return TrendAnalysis(
                trend=ScoreTrend.STABLE,
                change_7d=0.0,
                change_30d=0.0,
                average_score=0.0,
                min_score=0.0,
                max_score=0.0,
                is_regression=False,
            )

        now = datetime.utcnow()
        cutoff = now - timedelta(days=days)
        recent_entries = [e for e in self._history if e.timestamp >= cutoff]

        if not recent_entries:
            recent_entries = self._history[-10:]  # Fallback to last 10

        # Calculate basic statistics
        scores = [e.overall_score for e in recent_entries]
        avg_score = sum(scores) / len(scores)
        min_score = min(scores)
        max_score = max(scores)

        # Calculate changes
        change_7d = self._calculate_change(7)
        change_30d = self._calculate_change(30)

        # Determine trend
        if change_7d > 5:
            trend = ScoreTrend.IMPROVING
        elif change_7d < -self.regression_threshold:
            trend = ScoreTrend.CRITICAL_DECLINE
        elif change_7d < -3:
            trend = ScoreTrend.DECLINING
        else:
            trend = ScoreTrend.STABLE

        # Check for regression
        is_regression = False
        regression_severity = None

        if change_7d < -self.regression_threshold:
            is_regression = True
            if change_7d < -20:
                regression_severity = "severe"
            elif change_7d < -15:
                regression_severity = "moderate"
            else:
                regression_severity = "mild"

        # Analyze component trends
        improving = []
        declining = []

        if len(recent_entries) >= 2:
            first = recent_entries[0]
            last = recent_entries[-1]

            for component in [
                "vulnerability",
                "trust_boundary",
                "communication",
                "agent_risk",
            ]:
                first_score = first.component_scores.get(component, 0)
                last_score = last.component_scores.get(component, 0)

                if last_score > first_score + 3:
                    improving.append(component)
                elif last_score < first_score - 3:
                    declining.append(component)

        return TrendAnalysis(
            trend=trend,
            change_7d=round(change_7d, 2),
            change_30d=round(change_30d, 2),
            average_score=round(avg_score, 2),
            min_score=round(min_score, 2),
            max_score=round(max_score, 2),
            is_regression=is_regression,
            regression_severity=regression_severity,
            improving_components=improving,
            declining_components=declining,
        )

    def check_regression(self) -> tuple[bool, str | None]:
        """
        Check if latest score represents a regression.

        Returns:
            Tuple of (is_regression, description)
        """
        if len(self._history) < 2:
            return False, None

        current = self._history[-1]
        previous = self._history[-2]

        score_change = current.overall_score - previous.overall_score

        if score_change < -self.regression_threshold:
            severity = (
                "severe" if score_change < -20 else "moderate" if score_change < -15 else "mild"
            )
            description = (
                f"Score dropped by {abs(score_change):.1f} points "
                f"({previous.overall_score:.1f} -> {current.overall_score:.1f}). "
                f"Severity: {severity}"
            )
            return True, description

        return False, None

    def get_component_history(
        self,
        component: str,
        days: int = 30,
    ) -> list[tuple[datetime, float]]:
        """
        Get history for a specific score component.

        Args:
            component: Component name (vulnerability, trust_boundary, etc.)
            days: Number of days of history

        Returns:
            List of (timestamp, score) tuples
        """
        cutoff = datetime.utcnow() - timedelta(days=days)
        recent = [e for e in self._history if e.timestamp >= cutoff]

        return [(e.timestamp, e.component_scores.get(component, 0)) for e in recent]

    def compare_periods(
        self,
        period1_start: datetime,
        period1_end: datetime,
        period2_start: datetime,
        period2_end: datetime,
    ) -> dict[str, Any]:
        """
        Compare scores between two time periods.

        Args:
            period1_start: First period start
            period1_end: First period end
            period2_start: Second period start
            period2_end: Second period end

        Returns:
            Comparison metrics
        """
        period1 = self.get_history(period1_start, period1_end)
        period2 = self.get_history(period2_start, period2_end)

        if not period1 or not period2:
            return {"error": "Insufficient data for comparison"}

        # Calculate averages
        avg1 = sum(e.overall_score for e in period1) / len(period1)
        avg2 = sum(e.overall_score for e in period2) / len(period2)

        # Calculate changes
        change = avg2 - avg1
        change_pct = (change / avg1 * 100) if avg1 > 0 else 0

        return {
            "period1_avg": round(avg1, 2),
            "period1_count": len(period1),
            "period2_avg": round(avg2, 2),
            "period2_count": len(period2),
            "change": round(change, 2),
            "change_percent": round(change_pct, 2),
            "improved": change > 0,
        }

    def _calculate_change(self, days: int) -> float:
        """Calculate score change over a period."""
        if not self._history:
            return 0.0

        now = datetime.utcnow()
        cutoff = now - timedelta(days=days)

        # Find entries at start and end of period
        older_entries = [e for e in self._history if e.timestamp <= cutoff]
        if not older_entries:
            older_entries = self._history[:1]

        old_score = (
            older_entries[-1].overall_score if older_entries else self._history[0].overall_score
        )
        new_score = self._history[-1].overall_score

        return new_score - old_score

    def to_dict(self) -> dict[str, Any]:
        """
        Export history to dictionary format.

        Returns:
            Dictionary with all history entries
        """
        return {
            "project_id": self.project_id,
            "entry_count": len(self._history),
            "entries": [
                {
                    "timestamp": e.timestamp.isoformat(),
                    "overall_score": e.overall_score,
                    "grade": e.grade,
                    "components": e.component_scores,
                    "agent_count": e.agent_count,
                    "finding_count": e.finding_count,
                }
                for e in self._history
            ],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ScoreHistoryTracker":
        """
        Create tracker from dictionary.

        Args:
            data: Dictionary with history data

        Returns:
            ScoreHistoryTracker instance
        """
        tracker = cls(project_id=data.get("project_id", "default"))

        for entry_data in data.get("entries", []):
            components = entry_data.get("components", {})
            entry = ScoreHistoryEntry(
                timestamp=datetime.fromisoformat(entry_data["timestamp"]),
                overall_score=entry_data["overall_score"],
                grade=entry_data["grade"],
                vulnerability_score=components.get("vulnerability", 0),
                trust_boundary_score=components.get("trust_boundary", 0),
                communication_score=components.get("communication", 0),
                agent_risk_score=components.get("agent_risk", 0),
                agent_count=entry_data.get("agent_count", 0),
                finding_count=entry_data.get("finding_count", 0),
            )
            tracker.add_entry(entry)

        return tracker
