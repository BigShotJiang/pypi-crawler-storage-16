"""
Entry Point Identification (US-128).

Identifies potential injection entry points in the agent topology
including user inputs, external APIs, and shared resources.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from vantage_core.security.models import TrustLevel
from vantage_core.security.topology.graph import AgentGraph, GraphNode


class EntryPointType(str, Enum):
    """Types of entry points for infection."""

    USER_INPUT = "user_input"  # Direct user input
    EXTERNAL_API = "external_api"  # External API responses
    SHARED_RESOURCE = "shared_resource"  # Shared files/databases
    WEBHOOK = "webhook"  # Incoming webhooks
    MEMORY = "memory"  # Shared memory/context
    FILE_SYSTEM = "file_system"  # File reads


@dataclass
class EntryPoint:
    """
    Represents a potential infection entry point.

    Contains the agent, entry type, risk assessment,
    and analysis details.
    """

    agent_id: str
    agent_name: str
    entry_type: EntryPointType
    risk_score: float  # 0-100, higher is riskier
    trust_level: TrustLevel
    exposure_factors: list[str] = field(default_factory=list)
    description: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def risk_level(self) -> str:
        """Get risk level description."""
        if self.risk_score >= 80:
            return "critical"
        elif self.risk_score >= 60:
            return "high"
        elif self.risk_score >= 40:
            return "moderate"
        else:
            return "low"


class EntryPointIdentifier:
    """
    Identifies potential entry points for infection attacks.

    Analyzes the agent topology to find agents that could
    receive malicious inputs from external sources.
    """

    # Risk weights for different entry types
    ENTRY_TYPE_RISKS = {
        EntryPointType.USER_INPUT: 90,
        EntryPointType.EXTERNAL_API: 80,
        EntryPointType.WEBHOOK: 75,
        EntryPointType.SHARED_RESOURCE: 60,
        EntryPointType.MEMORY: 50,
        EntryPointType.FILE_SYSTEM: 55,
    }

    def __init__(
        self,
        entry_type_risks: dict[EntryPointType, int] | None = None,
    ):
        """
        Initialize the identifier.

        Args:
            entry_type_risks: Custom risk scores for entry types
        """
        self.entry_type_risks = entry_type_risks or self.ENTRY_TYPE_RISKS

    def identify(self, graph: AgentGraph) -> list[EntryPoint]:
        """
        Identify all potential entry points in the graph.

        Args:
            graph: Agent topology graph

        Returns:
            List of EntryPoint objects sorted by risk
        """
        entry_points = []

        for node in graph.nodes:
            # Check each type of entry point
            node_entry_points = self._analyze_node(node, graph)
            entry_points.extend(node_entry_points)

        # Sort by risk score descending
        entry_points.sort(key=lambda e: e.risk_score, reverse=True)

        return entry_points

    def get_highest_risk_entries(
        self,
        graph: AgentGraph,
        limit: int = 5,
    ) -> list[EntryPoint]:
        """
        Get the highest risk entry points.

        Args:
            graph: Agent topology graph
            limit: Maximum number to return

        Returns:
            List of highest risk entry points
        """
        all_entries = self.identify(graph)
        return all_entries[:limit]

    def get_entries_by_type(
        self,
        graph: AgentGraph,
        entry_type: EntryPointType,
    ) -> list[EntryPoint]:
        """
        Get entry points of a specific type.

        Args:
            graph: Agent topology graph
            entry_type: Type to filter by

        Returns:
            List of entry points of that type
        """
        all_entries = self.identify(graph)
        return [e for e in all_entries if e.entry_type == entry_type]

    def _analyze_node(
        self,
        node: GraphNode,
        graph: AgentGraph,
    ) -> list[EntryPoint]:
        """Analyze a node for entry points."""
        entry_points = []

        # Check for user input entry
        if self._is_user_input_entry(node):
            entry_points.append(
                self._create_entry_point(
                    node,
                    EntryPointType.USER_INPUT,
                    self._calculate_entry_risk(node, EntryPointType.USER_INPUT),
                    "Receives direct user input",
                )
            )

        # Check for external API entry
        if self._is_external_api_entry(node):
            entry_points.append(
                self._create_entry_point(
                    node,
                    EntryPointType.EXTERNAL_API,
                    self._calculate_entry_risk(node, EntryPointType.EXTERNAL_API),
                    "Receives external API responses",
                )
            )

        # Check for shared resource entry
        if self._is_shared_resource_entry(node):
            entry_points.append(
                self._create_entry_point(
                    node,
                    EntryPointType.SHARED_RESOURCE,
                    self._calculate_entry_risk(node, EntryPointType.SHARED_RESOURCE),
                    "Consumes from shared resources",
                )
            )

        # Check for file system entry
        if self._is_file_system_entry(node):
            entry_points.append(
                self._create_entry_point(
                    node,
                    EntryPointType.FILE_SYSTEM,
                    self._calculate_entry_risk(node, EntryPointType.FILE_SYSTEM),
                    "Reads from file system",
                )
            )

        # Check for memory entry
        if self._is_memory_entry(node):
            entry_points.append(
                self._create_entry_point(
                    node,
                    EntryPointType.MEMORY,
                    self._calculate_entry_risk(node, EntryPointType.MEMORY),
                    "Accesses shared memory/context",
                )
            )

        # Check for webhook entry
        if self._is_webhook_entry(node):
            entry_points.append(
                self._create_entry_point(
                    node,
                    EntryPointType.WEBHOOK,
                    self._calculate_entry_risk(node, EntryPointType.WEBHOOK),
                    "Receives webhook callbacks",
                )
            )

        return entry_points

    def _is_user_input_entry(self, node: GraphNode) -> bool:
        """Check if node is a user input entry point."""
        # Entry nodes with no incoming edges
        if node.in_degree == 0:
            return True

        # External trust level
        if node.trust_level == TrustLevel.EXTERNAL:
            return True

        # Check metadata for user-facing role
        metadata = node.metadata or {}
        role = metadata.get("role") or ""
        if any(term in role.lower() for term in ["user", "input", "interface", "frontend"]):
            return True

        return False

    def _is_external_api_entry(self, node: GraphNode) -> bool:
        """Check if node receives external API responses."""
        return node.has_external_access

    def _is_shared_resource_entry(self, node: GraphNode) -> bool:
        """Check if node reads from shared resources."""
        # Check for database access tool category
        metadata = node.metadata or {}
        tools = metadata.get("tools", [])

        # If we have tool information in metadata
        if tools:
            for tool in tools:
                if isinstance(tool, dict):
                    categories = tool.get("categories", [])
                    if "database" in categories or "shared" in str(categories).lower():
                        return True

        return False

    def _is_file_system_entry(self, node: GraphNode) -> bool:
        """Check if node reads from file system."""
        metadata = node.metadata or {}
        tools = metadata.get("tools", [])

        if tools:
            for tool in tools:
                if isinstance(tool, dict):
                    categories = tool.get("categories", [])
                    if "file_system" in categories:
                        return True

        return False

    def _is_memory_entry(self, node: GraphNode) -> bool:
        """Check if node accesses shared memory."""
        metadata = node.metadata or {}
        memory_scope = metadata.get("memory_scope", "")

        return memory_scope in ["shared", "global"]

    def _is_webhook_entry(self, node: GraphNode) -> bool:
        """Check if node receives webhooks."""
        metadata = node.metadata or {}
        role = metadata.get("role") or ""

        return any(term in role.lower() for term in ["webhook", "callback", "listener"])

    def _calculate_entry_risk(
        self,
        node: GraphNode,
        entry_type: EntryPointType,
    ) -> float:
        """Calculate risk score for an entry point."""
        # Base risk from entry type
        base_risk = self.entry_type_risks.get(entry_type, 50)

        # Adjust based on trust level
        trust_adjustment = {
            TrustLevel.EXTERNAL: 10,
            TrustLevel.USER: 5,
            TrustLevel.INTERNAL: 0,
            TrustLevel.PRIVILEGED: -5,
            TrustLevel.SYSTEM: -10,
        }
        risk = base_risk + trust_adjustment.get(node.trust_level, 0)

        # Increase risk for high connectivity (wide blast radius)
        if node.out_degree > 3:
            risk += 10
        elif node.out_degree > 1:
            risk += 5

        # Increase risk for code execution capability
        if node.has_code_execution:
            risk += 15

        # Increase risk for delegation capability
        if node.allow_delegation:
            risk += 10

        return min(100, max(0, risk))

    def _create_entry_point(
        self,
        node: GraphNode,
        entry_type: EntryPointType,
        risk_score: float,
        description: str,
    ) -> EntryPoint:
        """Create an EntryPoint object."""
        # Collect exposure factors
        factors = []

        if node.trust_level == TrustLevel.EXTERNAL:
            factors.append("External trust level")
        if node.in_degree == 0:
            factors.append("No input validation layer")
        if node.out_degree > 3:
            factors.append(f"High fan-out ({node.out_degree} connections)")
        if node.has_code_execution:
            factors.append("Code execution capability")
        if node.allow_delegation:
            factors.append("Can delegate to other agents")

        return EntryPoint(
            agent_id=node.id,
            agent_name=node.name,
            entry_type=entry_type,
            risk_score=risk_score,
            trust_level=node.trust_level,
            exposure_factors=factors,
            description=description,
            metadata={
                "in_degree": node.in_degree,
                "out_degree": node.out_degree,
                "framework": node.framework,
            },
        )


def identify_entry_points(graph: AgentGraph) -> list[EntryPoint]:
    """
    Convenience function to identify entry points.

    Args:
        graph: Agent topology graph

    Returns:
        List of EntryPoint objects
    """
    identifier = EntryPointIdentifier()
    return identifier.identify(graph)
