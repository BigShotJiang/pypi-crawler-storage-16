"""
Simulation Visualization Data (US-132).

Exports animation data for infection propagation visualization
with time-step based spread information.
"""

from dataclasses import dataclass, field
from typing import Any

from vantage_core.security.simulation.propagation import (
    AgentState,
    InfectionState,
    SimulationResult,
)
from vantage_core.security.topology.graph import AgentGraph


@dataclass
class NodeState:
    """
    State of a node at a specific time step.

    Used for visualization rendering.
    """

    agent_id: str
    agent_name: str
    state: str  # State name for color mapping
    infected_at: int
    infected_by: str | None
    position_x: float = 0.0  # For layout
    position_y: float = 0.0


@dataclass
class TimeStep:
    """
    Complete state at a single time step.

    Contains all node states and event information.
    """

    step: int
    node_states: list[NodeState]
    new_infections: list[str]  # Newly infected agent IDs
    events: list[str]  # Event descriptions
    metrics: dict[str, Any] = field(default_factory=dict)


@dataclass
class VisualizationData:
    """
    Complete visualization data for animation.

    Contains all time steps, layout, and metadata
    for frontend rendering.
    """

    time_steps: list[TimeStep]
    total_steps: int
    nodes: list[dict[str, Any]]  # Node metadata
    edges: list[dict[str, Any]]  # Edge metadata
    entry_point: str
    blast_radius: int
    color_scheme: dict[str, str]  # State -> color mapping
    metadata: dict[str, Any] = field(default_factory=dict)


class SimulationVisualizer:
    """
    Generates visualization data for infection simulations.

    Transforms simulation results into structured data
    suitable for frontend animation rendering.
    """

    # Default color scheme for states
    DEFAULT_COLORS = {
        InfectionState.SUSCEPTIBLE.value: "#22c55e",  # Green
        InfectionState.EXPOSED.value: "#facc15",  # Yellow
        InfectionState.INFECTED.value: "#ef4444",  # Red
        InfectionState.CONTAINED.value: "#3b82f6",  # Blue
    }

    def __init__(
        self,
        color_scheme: dict[str, str] | None = None,
    ):
        """
        Initialize the visualizer.

        Args:
            color_scheme: Custom color scheme for states
        """
        self.colors = color_scheme or self.DEFAULT_COLORS

    def generate(
        self,
        result: SimulationResult,
        graph: AgentGraph,
    ) -> VisualizationData:
        """
        Generate visualization data from simulation result.

        Args:
            result: Simulation result
            graph: Agent topology graph

        Returns:
            VisualizationData for animation
        """
        time_steps = []

        # Process each time step
        for step_idx, states in enumerate(result.time_steps):
            # Build node states
            node_states = []
            new_infections = []

            for agent_id, agent_state in states.items():
                node = graph.get_node(agent_id)
                name = node.name if node else agent_id

                node_state = NodeState(
                    agent_id=agent_id,
                    agent_name=name,
                    state=agent_state.state.value,
                    infected_at=agent_state.infected_at,
                    infected_by=agent_state.infected_by,
                )

                # Track new infections
                if agent_state.infected_at == step_idx and agent_state.state in [
                    InfectionState.EXPOSED,
                    InfectionState.INFECTED,
                ]:
                    new_infections.append(agent_id)

                node_states.append(node_state)

            # Generate events
            events = self._generate_step_events(step_idx, states, new_infections)

            # Calculate metrics
            metrics = {
                "susceptible": sum(
                    1 for s in states.values() if s.state == InfectionState.SUSCEPTIBLE
                ),
                "exposed": sum(1 for s in states.values() if s.state == InfectionState.EXPOSED),
                "infected": sum(1 for s in states.values() if s.state == InfectionState.INFECTED),
                "contained": sum(1 for s in states.values() if s.state == InfectionState.CONTAINED),
            }

            time_step = TimeStep(
                step=step_idx,
                node_states=node_states,
                new_infections=new_infections,
                events=events,
                metrics=metrics,
            )
            time_steps.append(time_step)

        # Build node metadata
        nodes = self._build_node_metadata(graph)

        # Build edge metadata
        edges = self._build_edge_metadata(graph)

        return VisualizationData(
            time_steps=time_steps,
            total_steps=len(time_steps),
            nodes=nodes,
            edges=edges,
            entry_point=result.entry_point,
            blast_radius=result.blast_radius,
            color_scheme=self.colors,
            metadata={
                "peak_infection": result.peak_infection,
                "peak_step": result.peak_step,
                "containment_points": result.containment_points,
            },
        )

    def to_json(self, data: VisualizationData) -> dict[str, Any]:
        """
        Convert visualization data to JSON-serializable format.

        Args:
            data: Visualization data

        Returns:
            JSON-serializable dictionary
        """
        return {
            "totalSteps": data.total_steps,
            "entryPoint": data.entry_point,
            "blastRadius": data.blast_radius,
            "colorScheme": data.color_scheme,
            "nodes": data.nodes,
            "edges": data.edges,
            "timeSteps": [
                {
                    "step": ts.step,
                    "nodeStates": [
                        {
                            "id": ns.agent_id,
                            "name": ns.agent_name,
                            "state": ns.state,
                            "infectedAt": ns.infected_at,
                            "infectedBy": ns.infected_by,
                        }
                        for ns in ts.node_states
                    ],
                    "newInfections": ts.new_infections,
                    "events": ts.events,
                    "metrics": ts.metrics,
                }
                for ts in data.time_steps
            ],
            "metadata": data.metadata,
        }

    def to_frames(self, data: VisualizationData) -> list[dict[str, Any]]:
        """
        Convert to frame-by-frame format for GIF generation.

        Args:
            data: Visualization data

        Returns:
            List of frame dictionaries
        """
        frames = []

        for ts in data.time_steps:
            frame = {
                "step": ts.step,
                "nodes": {},
                "newInfections": ts.new_infections,
                "caption": "; ".join(ts.events) if ts.events else f"Step {ts.step}",
            }

            for ns in ts.node_states:
                frame["nodes"][ns.agent_id] = {
                    "state": ns.state,
                    "color": data.color_scheme.get(ns.state, "#888888"),
                }

            frames.append(frame)

        return frames

    def get_summary(self, data: VisualizationData) -> dict[str, Any]:
        """
        Get summary statistics for visualization.

        Args:
            data: Visualization data

        Returns:
            Summary statistics
        """
        return {
            "totalSteps": data.total_steps,
            "totalNodes": len(data.nodes),
            "blastRadius": data.blast_radius,
            "blastPercentage": round(
                data.blast_radius / len(data.nodes) * 100 if data.nodes else 0, 2
            ),
            "peakInfection": data.metadata.get("peak_infection", 0),
            "peakStep": data.metadata.get("peak_step", 0),
            "containmentPoints": len(data.metadata.get("containment_points", [])),
        }

    def _build_node_metadata(self, graph: AgentGraph) -> list[dict[str, Any]]:
        """Build node metadata list."""
        nodes = []
        for node in graph.nodes:
            nodes.append(
                {
                    "id": node.id,
                    "name": node.name,
                    "framework": node.framework,
                    "trustLevel": node.trust_level.name,
                    "toolCount": node.tool_count,
                    "hasCodeExecution": node.has_code_execution,
                    "inDegree": node.in_degree,
                    "outDegree": node.out_degree,
                }
            )
        return nodes

    def _build_edge_metadata(self, graph: AgentGraph) -> list[dict[str, Any]]:
        """Build edge metadata list."""
        edges = []
        for edge in graph.edges:
            edges.append(
                {
                    "source": edge.source_id,
                    "target": edge.target_id,
                    "type": edge.communication_type.value,
                    "dataSensitivity": edge.data_sensitivity,
                    "trustDifferential": edge.trust_differential,
                }
            )
        return edges

    def _generate_step_events(
        self,
        step: int,
        states: dict[str, AgentState],
        new_infections: list[str],
    ) -> list[str]:
        """Generate event descriptions for a step."""
        events = []

        if step == 0:
            # Find entry point
            for agent_id, state in states.items():
                if state.infected_at == 0:
                    events.append(f"Infection started at {agent_id}")
                    break

        if new_infections:
            if len(new_infections) == 1:
                events.append(f"Agent {new_infections[0]} infected")
            else:
                events.append(f"{len(new_infections)} agents infected")

        # Check for containment
        contained = [
            agent_id
            for agent_id, state in states.items()
            if state.state == InfectionState.CONTAINED
        ]
        if contained and step > 0:
            # Only report new containments
            events.append(f"{len(contained)} agent(s) contained")

        if not events and step > 0:
            events.append(f"Propagation continues (step {step})")

        return events


def generate_visualization(
    result: SimulationResult,
    graph: AgentGraph,
) -> VisualizationData:
    """
    Convenience function to generate visualization data.

    Args:
        result: Simulation result
        graph: Agent topology graph

    Returns:
        VisualizationData
    """
    visualizer = SimulationVisualizer()
    return visualizer.generate(result, graph)
