"""
Vantage Core Security Scanner - File Upload Module

This module provides file upload handling and storage management
for the security scanning platform.
"""

from pathlib import Path


class FileUploadError(Exception):
    """Base exception for file upload errors."""

    pass


class FileSizeError(FileUploadError):
    """Exception raised when file exceeds maximum size limit."""

    def __init__(self, file_size: int, max_size: int):
        self.file_size = file_size
        self.max_size = max_size
        super().__init__(
            f"File size {file_size} bytes exceeds maximum allowed size of {max_size} bytes"
        )


class FileExtensionError(FileUploadError):
    """Exception raised when file has a disallowed extension."""

    def __init__(self, extension: str, allowed_extensions: set[str]):
        self.extension = extension
        self.allowed_extensions = allowed_extensions
        super().__init__(
            f"File extension '{extension}' is not allowed. "
            f"Allowed extensions: {', '.join(sorted(allowed_extensions))}"
        )


class FileUploadHandler:
    """
    Handles file uploads with validation and storage management.

    This class provides secure file upload handling with configurable
    size limits, extension filtering, and storage path management.

    Attributes:
        max_file_size: Maximum allowed file size in bytes.
        allowed_extensions: Set of allowed file extensions (e.g., {'.py', '.txt'}).
        upload_dir: Directory path for storing uploaded files.
    """

    DEFAULT_MAX_SIZE = 10 * 1024 * 1024  # 10 MB
    DEFAULT_EXTENSIONS = {".py", ".js", ".ts", ".json", ".yaml", ".yml", ".txt", ".md"}

    def __init__(
        self,
        upload_dir: Path | None = None,
        max_file_size: int | None = None,
        allowed_extensions: set[str] | None = None,
    ):
        """
        Initialize the FileUploadHandler.

        Args:
            upload_dir: Directory for storing uploaded files. Defaults to temp directory.
            max_file_size: Maximum file size in bytes. Defaults to 10 MB.
            allowed_extensions: Set of allowed extensions. Defaults to common code files.
        """
        self.upload_dir = upload_dir or Path("/tmp/mimic_uploads")
        self.max_file_size = max_file_size or self.DEFAULT_MAX_SIZE
        self.allowed_extensions = allowed_extensions or self.DEFAULT_EXTENSIONS.copy()

    def validate_file(self, file_path: Path) -> bool:
        """
        Validate a file against size and extension constraints.

        Args:
            file_path: Path to the file to validate.

        Returns:
            True if the file passes all validation checks.

        Raises:
            FileSizeError: If file exceeds maximum size.
            FileExtensionError: If file extension is not allowed.
            FileUploadError: If file does not exist or is not readable.
        """
        if not file_path.exists():
            raise FileUploadError(f"File does not exist: {file_path}")

        if not file_path.is_file():
            raise FileUploadError(f"Path is not a file: {file_path}")

        # Check file size
        file_size = file_path.stat().st_size
        if file_size > self.max_file_size:
            raise FileSizeError(file_size, self.max_file_size)

        # Check file extension
        extension = file_path.suffix.lower()
        if extension not in self.allowed_extensions:
            raise FileExtensionError(extension, self.allowed_extensions)

        return True

    def get_upload_path(self, filename: str) -> Path:
        """
        Get the full path for an uploaded file.

        Args:
            filename: Name of the file.

        Returns:
            Full path where the file will be stored.
        """
        return self.upload_dir / filename

    def ensure_upload_dir(self) -> Path:
        """
        Ensure the upload directory exists.

        Returns:
            Path to the upload directory.
        """
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        return self.upload_dir

    def list_uploads(self) -> list[Path]:
        """
        List all files in the upload directory.

        Returns:
            List of paths to uploaded files.
        """
        if not self.upload_dir.exists():
            return []
        return [f for f in self.upload_dir.iterdir() if f.is_file()]

    def cleanup_uploads(self) -> int:
        """
        Remove all files from the upload directory.

        Returns:
            Number of files removed.
        """
        files = self.list_uploads()
        count = 0
        for f in files:
            try:
                f.unlink()
                count += 1
            except OSError:
                pass
        return count


__all__ = [
    "FileUploadHandler",
    "FileUploadError",
    "FileSizeError",
    "FileExtensionError",
]
