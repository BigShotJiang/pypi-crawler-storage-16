"""
Intra-Procedural Taint Analyzer using Worklist Algorithm.

US-013: Variable Assignment Tracking
US-014: Function Call Propagation
US-016: Taint Path Reporting

Implements dataflow analysis for tracking taint within functions.
"""

import ast
from collections import deque
from dataclasses import dataclass

from vantage_core.security.taint.cfg import CFG, BasicBlock, build_cfg
from vantage_core.security.taint.lattice import (
    TaintedValue,
    TaintEnv,
    TaintSource,
    TaintState,
    env_equal,
    join_envs,
)
from vantage_core.security.taint.sources import (
    TaintConfiguration,
)


@dataclass
class TaintPathNode:
    """A node in a taint propagation path."""

    location: str  # file:line:col
    variable: str
    code_snippet: str


@dataclass
class TaintFinding:
    """
    A taint flow finding from source to sink.

    US-016: Taint Path Reporting
    """

    source: TaintSource
    sink_location: str
    sink_type: str
    sink_function: str
    path: list[TaintPathNode]
    severity: str
    file_path: str
    source_line: int
    sink_line: int
    code_context: str = ""

    def __repr__(self) -> str:
        return (
            f"TaintFinding({self.source.source_type} -> {self.sink_type} at line {self.sink_line})"
        )


@dataclass
class TaintAnalysisConfig:
    """Configuration for taint analysis."""

    max_depth: int = 10
    timeout_per_function_ms: int = 5000
    max_path_length: int = 50
    track_sanitizers: bool = True


class IntraProceduralTaintAnalyzer:
    """
    Intra-procedural taint analysis using worklist algorithm.

    Analyzes taint flow within a single function using
    a forward dataflow analysis on the CFG.
    """

    def __init__(
        self,
        config: TaintAnalysisConfig | None = None,
        taint_config: TaintConfiguration | None = None,
    ) -> None:
        self.config = config or TaintAnalysisConfig()
        self.taint_config = taint_config or TaintConfiguration()
        self.sources = self.taint_config.sources
        self.sinks = self.taint_config.sinks
        self.sanitizers = self.taint_config.sanitizers
        self._current_file = ""
        self._source_code = ""
        self._path_tracker: dict[str, list[TaintPathNode]] = {}

    def analyze(
        self,
        code: str,
        file_path: str,
    ) -> list[TaintFinding]:
        """
        Analyze all functions in source code for taint flows.

        Args:
            code: Source code to analyze
            file_path: Path to source file

        Returns:
            List of taint findings
        """
        self._current_file = file_path
        self._source_code = code
        findings: list[TaintFinding] = []

        try:
            tree = ast.parse(code)
        except SyntaxError:
            return findings

        # Analyze each function
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                cfg = build_cfg(node)
                func_findings = self.analyze_function(cfg, node, file_path)
                findings.extend(func_findings)

        return findings

    def analyze_function(
        self,
        cfg: CFG,
        func_node: ast.FunctionDef | ast.AsyncFunctionDef,
        file_path: str,
    ) -> list[TaintFinding]:
        """
        Analyze a single function using worklist algorithm.

        Args:
            cfg: Control flow graph of function
            func_node: Function AST node
            file_path: Source file path for findings

        Returns:
            List of taint findings (source-to-sink flows)
        """
        findings: list[TaintFinding] = []
        self._path_tracker = {}

        # Build initial taint from parameters (conservative: untainted)
        initial_taint: TaintEnv = {}
        for arg in func_node.args.args:
            initial_taint[arg.arg] = TaintedValue.untainted()

        # Initialize all blocks with empty taint
        for block in cfg.blocks.values():
            block.taint_in = {}
            block.taint_out = {}

        # Initialize entry block
        cfg.blocks[cfg.entry_block].taint_in = initial_taint.copy()

        # Worklist: start with reverse post-order for efficiency
        worklist = deque(cfg.reverse_postorder())
        iterations = 0
        max_iterations = len(cfg.blocks) * self.config.max_depth

        while worklist and iterations < max_iterations:
            iterations += 1
            block_id = worklist.popleft()
            block = cfg.blocks[block_id]

            # Compute IN as join of predecessor OUTs
            new_in: TaintEnv = {}
            for pred_id in block.predecessors:
                pred_out = cfg.blocks[pred_id].taint_out
                new_in = join_envs(new_in, pred_out)

            # Add initial taint for entry block
            if block_id == cfg.entry_block:
                new_in = join_envs(new_in, initial_taint)

            block.taint_in = new_in

            # Apply transfer functions to compute OUT
            old_out = block.taint_out.copy()
            new_out = self._transfer(block, new_in, findings, file_path)
            block.taint_out = new_out

            # Add successors to worklist if OUT changed
            if not env_equal(new_out, old_out):
                for succ_id in block.successors:
                    if succ_id not in worklist:
                        worklist.append(succ_id)

        return findings

    def _transfer(
        self,
        block: BasicBlock,
        taint_in: TaintEnv,
        findings: list[TaintFinding],
        file_path: str,
    ) -> TaintEnv:
        """
        Transfer function for a basic block.

        Processes each statement and updates taint state.
        """
        env = taint_in.copy()

        for stmt in block.statements:
            env = self._transfer_stmt(stmt, env, findings, file_path)

        return env

    def _transfer_stmt(
        self,
        stmt: ast.stmt,
        env: TaintEnv,
        findings: list[TaintFinding],
        file_path: str,
    ) -> TaintEnv:
        """Transfer function for a single statement."""
        env = env.copy()

        if isinstance(stmt, ast.Assign):
            # Handle: x = expr
            for target in stmt.targets:
                if isinstance(target, ast.Name):
                    taint = self._eval_expr_taint(stmt.value, env, file_path)
                    env[target.id] = taint
                    # Track path
                    if taint.is_tainted():
                        self._track_path(target.id, stmt.value, taint, file_path)
                elif isinstance(target, ast.Tuple):
                    # Handle: x, y = expr
                    taint = self._eval_expr_taint(stmt.value, env, file_path)
                    for elt in target.elts:
                        if isinstance(elt, ast.Name):
                            env[elt.id] = taint
                            if taint.is_tainted():
                                self._track_path(elt.id, stmt.value, taint, file_path)
                elif isinstance(target, ast.Attribute):
                    # Handle: obj.attr = expr
                    taint = self._eval_expr_taint(stmt.value, env, file_path)
                    # Track attribute as variable
                    attr_name = self._get_attr_name(target)
                    env[attr_name] = taint

        elif isinstance(stmt, ast.AugAssign):
            # Handle: x += expr
            if isinstance(stmt.target, ast.Name):
                current = env.get(stmt.target.id, TaintedValue.untainted())
                value_taint = self._eval_expr_taint(stmt.value, env, file_path)
                new_taint = current.join(value_taint)
                env[stmt.target.id] = new_taint
                if new_taint.is_tainted():
                    self._track_path(stmt.target.id, stmt.value, new_taint, file_path)

        elif isinstance(stmt, ast.AnnAssign):
            # Handle: x: int = expr
            if stmt.value and isinstance(stmt.target, ast.Name):
                taint = self._eval_expr_taint(stmt.value, env, file_path)
                env[stmt.target.id] = taint
                if taint.is_tainted():
                    self._track_path(stmt.target.id, stmt.value, taint, file_path)

        elif isinstance(stmt, ast.Expr):
            # Expression statement (e.g., function call)
            if isinstance(stmt.value, ast.Call):
                self._check_sink(stmt.value, env, findings, file_path)

        elif isinstance(stmt, ast.Return):
            # Check if return value is tainted (could report)
            pass

        elif isinstance(stmt, ast.If):
            # If statement - check condition for sinks
            if isinstance(stmt.test, ast.Call):
                self._check_sink(stmt.test, env, findings, file_path)

        elif isinstance(stmt, ast.While):
            # While statement - check condition
            if isinstance(stmt.test, ast.Call):
                self._check_sink(stmt.test, env, findings, file_path)

        elif isinstance(stmt, ast.For):
            # For statement - taint loop variable from iterator
            if isinstance(stmt.target, ast.Name):
                iter_taint = self._eval_expr_taint(stmt.iter, env, file_path)
                env[stmt.target.id] = iter_taint

        return env

    def _eval_expr_taint(
        self,
        expr: ast.expr,
        env: TaintEnv,
        file_path: str,
    ) -> TaintedValue:
        """Evaluate the taint of an expression."""
        if isinstance(expr, ast.Name):
            return env.get(expr.id, TaintedValue.untainted())

        elif isinstance(expr, ast.Call):
            func_name = self._get_func_name(expr)

            # Check if it's a source
            if func_name in self.sources:
                return TaintedValue.tainted(
                    TaintSource(
                        location=f"{file_path}:{expr.lineno}:{expr.col_offset}",
                        source_type=self.sources[func_name],
                        variable=func_name,
                    )
                )

            # Check if it's a sanitizer
            if func_name in self.sanitizers:
                return TaintedValue.untainted()

            # Propagate taint from arguments (conservative)
            arg_taints = [self._eval_expr_taint(arg, env, file_path) for arg in expr.args]
            # Also check keyword arguments
            for kw in expr.keywords:
                arg_taints.append(self._eval_expr_taint(kw.value, env, file_path))

            if arg_taints:
                result = arg_taints[0]
                for t in arg_taints[1:]:
                    result = result.join(t)
                return result

        elif isinstance(expr, ast.BinOp):
            # Binary operation: propagate taint from both operands
            left = self._eval_expr_taint(expr.left, env, file_path)
            right = self._eval_expr_taint(expr.right, env, file_path)
            return left.join(right)

        elif isinstance(expr, ast.JoinedStr):
            # f-string: propagate taint from all values
            result = TaintedValue.untainted()
            for value in expr.values:
                if isinstance(value, ast.FormattedValue):
                    result = result.join(self._eval_expr_taint(value.value, env, file_path))
            return result

        elif isinstance(expr, ast.Subscript):
            # x[i]: propagate taint from container
            return self._eval_expr_taint(expr.value, env, file_path)

        elif isinstance(expr, ast.Attribute):
            # x.attr: propagate taint from object
            return self._eval_expr_taint(expr.value, env, file_path)

        elif isinstance(expr, ast.IfExp):
            # Ternary: x if cond else y
            then_taint = self._eval_expr_taint(expr.body, env, file_path)
            else_taint = self._eval_expr_taint(expr.orelse, env, file_path)
            return then_taint.join(else_taint)

        elif isinstance(expr, ast.ListComp):
            # List comprehension: check generators
            result = TaintedValue.untainted()
            for gen in expr.generators:
                result = result.join(self._eval_expr_taint(gen.iter, env, file_path))
            return result

        elif isinstance(expr, ast.DictComp):
            # Dict comprehension
            result = TaintedValue.untainted()
            for gen in expr.generators:
                result = result.join(self._eval_expr_taint(gen.iter, env, file_path))
            return result

        elif isinstance(expr, (ast.List, ast.Tuple, ast.Set)):
            # Collection literals: propagate from elements
            result = TaintedValue.untainted()
            for elt in expr.elts:
                result = result.join(self._eval_expr_taint(elt, env, file_path))
            return result

        elif isinstance(expr, ast.Dict):
            # Dict literal: propagate from keys and values
            result = TaintedValue.untainted()
            for key in expr.keys:
                if key:
                    result = result.join(self._eval_expr_taint(key, env, file_path))
            for value in expr.values:
                result = result.join(self._eval_expr_taint(value, env, file_path))
            return result

        elif isinstance(expr, ast.UnaryOp):
            # Unary operation: propagate from operand
            return self._eval_expr_taint(expr.operand, env, file_path)

        elif isinstance(expr, ast.Compare):
            # Comparison: propagate from all values
            result = self._eval_expr_taint(expr.left, env, file_path)
            for comp in expr.comparators:
                result = result.join(self._eval_expr_taint(comp, env, file_path))
            return result

        elif isinstance(expr, ast.BoolOp):
            # Boolean operation: propagate from all values
            result = TaintedValue.untainted()
            for value in expr.values:
                result = result.join(self._eval_expr_taint(value, env, file_path))
            return result

        # Default: untainted (constants, etc.)
        return TaintedValue.untainted()

    def _check_sink(
        self,
        call: ast.Call,
        env: TaintEnv,
        findings: list[TaintFinding],
        file_path: str,
    ) -> None:
        """Check if a call is a sink with tainted arguments."""
        func_name = self._get_func_name(call)
        if func_name not in self.sinks:
            return

        for i, arg in enumerate(call.args):
            taint = self._eval_expr_taint(arg, env, file_path)
            if taint.is_tainted():
                for source in taint.sources:
                    # Build path
                    path = self._get_path(arg, taint)

                    # Get code context
                    code_context = self._get_code_context(call.lineno)

                    findings.append(
                        TaintFinding(
                            source=source,
                            sink_location=f"{file_path}:{call.lineno}:{call.col_offset}",
                            sink_type=self.sinks[func_name],
                            sink_function=func_name,
                            path=path,
                            severity=("HIGH" if taint.state == TaintState.TAINTED else "MEDIUM"),
                            file_path=file_path,
                            source_line=(
                                int(source.location.split(":")[1]) if ":" in source.location else 0
                            ),
                            sink_line=call.lineno,
                            code_context=code_context,
                        )
                    )

        # Also check keyword arguments
        for kw in call.keywords:
            taint = self._eval_expr_taint(kw.value, env, file_path)
            if taint.is_tainted():
                for source in taint.sources:
                    path = self._get_path(kw.value, taint)
                    code_context = self._get_code_context(call.lineno)

                    findings.append(
                        TaintFinding(
                            source=source,
                            sink_location=f"{file_path}:{call.lineno}:{call.col_offset}",
                            sink_type=self.sinks[func_name],
                            sink_function=func_name,
                            path=path,
                            severity=("HIGH" if taint.state == TaintState.TAINTED else "MEDIUM"),
                            file_path=file_path,
                            source_line=(
                                int(source.location.split(":")[1]) if ":" in source.location else 0
                            ),
                            sink_line=call.lineno,
                            code_context=code_context,
                        )
                    )

    def _get_func_name(self, call: ast.Call) -> str:
        """Extract function name from a Call node."""
        if isinstance(call.func, ast.Name):
            return call.func.id
        elif isinstance(call.func, ast.Attribute):
            return call.func.attr
        return ""

    def _get_attr_name(self, node: ast.Attribute) -> str:
        """Get full attribute name like obj.attr."""
        if isinstance(node.value, ast.Name):
            return f"{node.value.id}.{node.attr}"
        elif isinstance(node.value, ast.Attribute):
            return f"{self._get_attr_name(node.value)}.{node.attr}"
        return node.attr

    def _track_path(
        self, var_name: str, expr: ast.expr, taint: TaintedValue, file_path: str
    ) -> None:
        """Track the path of taint through a variable."""
        code = ast.unparse(expr) if hasattr(ast, "unparse") else str(expr)
        node = TaintPathNode(
            location=f"{file_path}:{getattr(expr, 'lineno', 0)}:{getattr(expr, 'col_offset', 0)}",
            variable=var_name,
            code_snippet=code[:100] if len(code) > 100 else code,
        )

        if var_name not in self._path_tracker:
            self._path_tracker[var_name] = []
        self._path_tracker[var_name].append(node)

    def _get_path(self, expr: ast.expr, taint: TaintedValue) -> list[TaintPathNode]:
        """Get the taint path for an expression."""
        path = []

        # Add source
        for source in taint.sources:
            path.append(
                TaintPathNode(
                    location=source.location,
                    variable=source.variable,
                    code_snippet=f"{source.source_type}()",
                )
            )

        # Add intermediate variables
        if isinstance(expr, ast.Name) and expr.id in self._path_tracker:
            path.extend(self._path_tracker[expr.id])

        return path

    def _get_code_context(self, lineno: int) -> str:
        """Get source code context around a line."""
        if not self._source_code:
            return ""

        lines = self._source_code.split("\n")
        start = max(0, lineno - 2)
        end = min(len(lines), lineno + 1)

        context_lines = []
        for i in range(start, end):
            marker = ">" if i == lineno - 1 else " "
            context_lines.append(f"{i + 1:4d} {marker} {lines[i]}")

        return "\n".join(context_lines)


def analyze_taint(
    code: str,
    file_path: str,
    config: TaintAnalysisConfig | None = None,
) -> list[TaintFinding]:
    """
    Convenience function to analyze taint in source code.

    Args:
        code: Source code to analyze
        file_path: Path to source file
        config: Optional analysis configuration

    Returns:
        List of taint findings
    """
    analyzer = IntraProceduralTaintAnalyzer(config)
    return analyzer.analyze(code, file_path)
