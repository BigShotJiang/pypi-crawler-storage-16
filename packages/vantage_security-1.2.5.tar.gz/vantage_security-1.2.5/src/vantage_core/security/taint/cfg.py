"""
Control Flow Graph Builder for Intra-Function Analysis.

US-013: Variable Assignment Tracking
Builds CFGs from Python AST for dataflow analysis.
"""

import ast
from dataclasses import dataclass, field

from vantage_core.security.taint.lattice import TaintEnv


@dataclass
class BasicBlock:
    """
    A basic block in the Control Flow Graph.

    Contains a sequence of statements with no internal
    control flow (no branches except at the end).
    """

    id: int
    statements: list[ast.stmt] = field(default_factory=list)
    predecessors: set[int] = field(default_factory=set)
    successors: set[int] = field(default_factory=set)

    # Analysis data (populated by analyzer)
    taint_in: TaintEnv = field(default_factory=dict)
    taint_out: TaintEnv = field(default_factory=dict)

    @property
    def is_entry(self) -> bool:
        """Check if this is the entry block."""
        return len(self.predecessors) == 0

    @property
    def is_exit(self) -> bool:
        """Check if this is an exit block."""
        return len(self.successors) == 0

    def __repr__(self) -> str:
        return f"BasicBlock(id={self.id}, stmts={len(self.statements)}, pred={self.predecessors}, succ={self.successors})"


@dataclass
class CFG:
    """
    Control Flow Graph for a function.

    Represents the control flow structure of a Python function
    as a graph of basic blocks.
    """

    function_name: str
    entry_block: int
    exit_block: int
    blocks: dict[int, BasicBlock]

    def reverse_postorder(self) -> list[int]:
        """
        Return block IDs in reverse post-order.

        This ordering ensures predecessors are processed before
        successors in forward dataflow analysis.

        Returns:
            List of block IDs in reverse post-order
        """
        visited: set[int] = set()
        postorder: list[int] = []

        def dfs(block_id: int) -> None:
            if block_id in visited:
                return
            visited.add(block_id)
            for succ in self.blocks[block_id].successors:
                dfs(succ)
            postorder.append(block_id)

        dfs(self.entry_block)
        return list(reversed(postorder))

    def get_all_statements(self) -> list[ast.stmt]:
        """
        Get all statements in the CFG in order.

        Returns:
            List of all AST statements
        """
        statements = []
        for block_id in self.reverse_postorder():
            statements.extend(self.blocks[block_id].statements)
        return statements

    def __repr__(self) -> str:
        return f"CFG({self.function_name}, blocks={len(self.blocks)})"


class CFGBuilder(ast.NodeVisitor):
    """
    Builds Control Flow Graphs from Python AST.

    Creates a CFG for each function in the source code,
    handling control flow constructs like if/while/for/try.
    """

    def __init__(self) -> None:
        self._block_counter = 0
        self._current_block: BasicBlock | None = None
        self._blocks: dict[int, BasicBlock] = {}
        self._break_targets: list[int] = []
        self._continue_targets: list[int] = []
        self._return_exits: list[int] = []

    def build(self, func_node: ast.FunctionDef | ast.AsyncFunctionDef) -> CFG:
        """
        Build CFG for a function.

        Args:
            func_node: Function AST node

        Returns:
            CFG representing the function's control flow
        """
        # Reset state
        self._block_counter = 0
        self._blocks = {}
        self._break_targets = []
        self._continue_targets = []
        self._return_exits = []

        # Create entry block
        entry = self._new_block()
        self._current_block = entry

        # Process function body
        for stmt in func_node.body:
            self._visit_stmt(stmt)

        # Create exit block
        exit_block = self._new_block()

        # Connect current block to exit if still active
        if self._current_block and self._current_block.id != exit_block.id:
            self._add_edge(self._current_block.id, exit_block.id)

        # Connect all return statements to exit
        for ret_block_id in self._return_exits:
            self._add_edge(ret_block_id, exit_block.id)

        return CFG(
            function_name=func_node.name,
            entry_block=entry.id,
            exit_block=exit_block.id,
            blocks=self._blocks,
        )

    def _new_block(self) -> BasicBlock:
        """Create a new basic block."""
        block = BasicBlock(id=self._block_counter)
        self._blocks[block.id] = block
        self._block_counter += 1
        return block

    def _add_edge(self, from_id: int, to_id: int) -> None:
        """Add a control flow edge between blocks."""
        if from_id in self._blocks and to_id in self._blocks:
            self._blocks[from_id].successors.add(to_id)
            self._blocks[to_id].predecessors.add(from_id)

    def _visit_stmt(self, node: ast.stmt) -> None:
        """Visit a statement node."""
        if isinstance(node, ast.If):
            self._visit_if(node)
        elif isinstance(node, ast.While):
            self._visit_while(node)
        elif isinstance(node, ast.For):
            self._visit_for(node)
        elif isinstance(node, ast.Try):
            self._visit_try(node)
        elif isinstance(node, ast.With):
            self._visit_with(node)
        elif isinstance(node, ast.Return):
            self._visit_return(node)
        elif isinstance(node, ast.Break):
            self._visit_break(node)
        elif isinstance(node, ast.Continue):
            self._visit_continue(node)
        else:
            # Regular statement - add to current block
            if self._current_block:
                self._current_block.statements.append(node)

    def _visit_if(self, node: ast.If) -> None:
        """Handle if statements."""
        # Add condition to current block
        if self._current_block:
            self._current_block.statements.append(node)

        # Create blocks for then/else branches
        then_block = self._new_block()
        merge_block = self._new_block()

        # Add edges from condition to branches
        if self._current_block:
            self._add_edge(self._current_block.id, then_block.id)

        # Process then branch
        self._current_block = then_block
        for stmt in node.body:
            self._visit_stmt(stmt)
        if self._current_block:
            self._add_edge(self._current_block.id, merge_block.id)

        # Process else branch
        if node.orelse:
            else_block = self._new_block()
            # Add edge from condition to else
            if self._blocks.get(then_block.id - 1):
                self._add_edge(then_block.id - 1, else_block.id)
            else:
                # Edge from the condition block
                for pred in then_block.predecessors:
                    self._add_edge(pred, else_block.id)

            self._current_block = else_block
            for stmt in node.orelse:
                self._visit_stmt(stmt)
            if self._current_block:
                self._add_edge(self._current_block.id, merge_block.id)
        else:
            # No else - edge from condition to merge
            for pred in then_block.predecessors:
                self._add_edge(pred, merge_block.id)

        self._current_block = merge_block

    def _visit_while(self, node: ast.While) -> None:
        """Handle while loops."""
        # Create loop header block
        header_block = self._new_block()
        body_block = self._new_block()
        exit_block = self._new_block()

        # Edge from current to header
        if self._current_block:
            self._add_edge(self._current_block.id, header_block.id)

        # Header contains condition
        header_block.statements.append(node)
        self._add_edge(header_block.id, body_block.id)  # True branch
        self._add_edge(header_block.id, exit_block.id)  # False branch

        # Process body with break/continue targets
        self._break_targets.append(exit_block.id)
        self._continue_targets.append(header_block.id)

        self._current_block = body_block
        for stmt in node.body:
            self._visit_stmt(stmt)

        # Back edge to header
        if self._current_block:
            self._add_edge(self._current_block.id, header_block.id)

        self._break_targets.pop()
        self._continue_targets.pop()

        # Handle orelse clause
        if node.orelse:
            else_block = self._new_block()
            self._add_edge(header_block.id, else_block.id)
            self._current_block = else_block
            for stmt in node.orelse:
                self._visit_stmt(stmt)
            if self._current_block:
                self._add_edge(self._current_block.id, exit_block.id)

        self._current_block = exit_block

    def _visit_for(self, node: ast.For) -> None:
        """Handle for loops."""
        # Create loop header block
        header_block = self._new_block()
        body_block = self._new_block()
        exit_block = self._new_block()

        # Edge from current to header
        if self._current_block:
            self._add_edge(self._current_block.id, header_block.id)

        # Header contains the for statement
        header_block.statements.append(node)
        self._add_edge(header_block.id, body_block.id)  # Into loop
        self._add_edge(header_block.id, exit_block.id)  # Loop done

        # Process body with break/continue targets
        self._break_targets.append(exit_block.id)
        self._continue_targets.append(header_block.id)

        self._current_block = body_block
        for stmt in node.body:
            self._visit_stmt(stmt)

        # Back edge to header
        if self._current_block:
            self._add_edge(self._current_block.id, header_block.id)

        self._break_targets.pop()
        self._continue_targets.pop()

        # Handle orelse clause
        if node.orelse:
            else_block = self._new_block()
            self._add_edge(header_block.id, else_block.id)
            self._current_block = else_block
            for stmt in node.orelse:
                self._visit_stmt(stmt)
            if self._current_block:
                self._add_edge(self._current_block.id, exit_block.id)

        self._current_block = exit_block

    def _visit_try(self, node: ast.Try) -> None:
        """Handle try/except/finally."""
        # Create blocks
        try_block = self._new_block()
        merge_block = self._new_block()

        # Edge from current to try
        if self._current_block:
            self._add_edge(self._current_block.id, try_block.id)

        # Process try body
        self._current_block = try_block
        for stmt in node.body:
            self._visit_stmt(stmt)
        if self._current_block:
            self._add_edge(self._current_block.id, merge_block.id)

        # Process except handlers
        for handler in node.handlers:
            handler_block = self._new_block()
            self._add_edge(try_block.id, handler_block.id)
            self._current_block = handler_block
            for stmt in handler.body:
                self._visit_stmt(stmt)
            if self._current_block:
                self._add_edge(self._current_block.id, merge_block.id)

        # Process else (only runs if no exception)
        if node.orelse:
            else_block = self._new_block()
            self._add_edge(try_block.id, else_block.id)
            self._current_block = else_block
            for stmt in node.orelse:
                self._visit_stmt(stmt)
            if self._current_block:
                self._add_edge(self._current_block.id, merge_block.id)

        # Process finally
        if node.finalbody:
            finally_block = self._new_block()
            self._add_edge(merge_block.id, finally_block.id)
            self._current_block = finally_block
            for stmt in node.finalbody:
                self._visit_stmt(stmt)
            merge_block = self._new_block()
            if self._current_block:
                self._add_edge(self._current_block.id, merge_block.id)

        self._current_block = merge_block

    def _visit_with(self, node: ast.With) -> None:
        """Handle with statements."""
        # Add the with statement to current block
        if self._current_block:
            self._current_block.statements.append(node)

        # Process body
        for stmt in node.body:
            self._visit_stmt(stmt)

    def _visit_return(self, node: ast.Return) -> None:
        """Handle return statements."""
        if self._current_block:
            self._current_block.statements.append(node)
            self._return_exits.append(self._current_block.id)
        # Create new unreachable block for any following code
        self._current_block = None

    def _visit_break(self, node: ast.Break) -> None:
        """Handle break statements."""
        if self._current_block and self._break_targets:
            self._current_block.statements.append(node)
            self._add_edge(self._current_block.id, self._break_targets[-1])
        # Create new unreachable block for any following code
        self._current_block = None

    def _visit_continue(self, node: ast.Continue) -> None:
        """Handle continue statements."""
        if self._current_block and self._continue_targets:
            self._current_block.statements.append(node)
            self._add_edge(self._current_block.id, self._continue_targets[-1])
        # Create new unreachable block for any following code
        self._current_block = None


def build_cfg(func_node: ast.FunctionDef | ast.AsyncFunctionDef) -> CFG:
    """
    Convenience function to build a CFG for a function.

    Args:
        func_node: Function AST node

    Returns:
        CFG representing the function's control flow
    """
    builder = CFGBuilder()
    return builder.build(func_node)
