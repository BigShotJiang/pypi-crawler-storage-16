"""Test runner for Vantage testing utilities.

This module provides utilities for running security tests against
multi-agent AI systems and collecting results.
"""

import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class TestStatus(Enum):
    """Status of a test execution."""

    PENDING = "pending"
    RUNNING = "running"
    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"
    ERROR = "error"


@dataclass
class TestResult:
    """Result of a single test execution.

    Attributes:
        test_id: Unique identifier for the test.
        test_name: Human-readable name of the test.
        status: Current status of the test.
        duration_ms: Execution time in milliseconds.
        message: Optional message describing the result.
        details: Additional details about the test result.
        errors: List of errors encountered during execution.
        metadata: Additional metadata about the test.
    """

    test_id: str
    test_name: str
    status: TestStatus
    duration_ms: float = 0.0
    message: str | None = None
    details: dict[str, Any] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def passed(self) -> bool:
        """Check if the test passed.

        Returns:
            True if the test passed, False otherwise.
        """
        return self.status == TestStatus.PASSED

    @property
    def failed(self) -> bool:
        """Check if the test failed.

        Returns:
            True if the test failed or errored, False otherwise.
        """
        return self.status in (TestStatus.FAILED, TestStatus.ERROR)

    def to_dict(self) -> dict[str, Any]:
        """Convert the result to a dictionary.

        Returns:
            Dictionary representation of the test result.
        """
        return {
            "test_id": self.test_id,
            "test_name": self.test_name,
            "status": self.status.value,
            "duration_ms": self.duration_ms,
            "message": self.message,
            "details": self.details,
            "errors": self.errors,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TestResult":
        """Create a TestResult from a dictionary.

        Args:
            data: Dictionary containing test result data.

        Returns:
            A TestResult instance.
        """
        return cls(
            test_id=data.get("test_id", str(uuid.uuid4())),
            test_name=data.get("test_name", "Unknown Test"),
            status=TestStatus(data.get("status", "pending")),
            duration_ms=data.get("duration_ms", 0.0),
            message=data.get("message"),
            details=data.get("details", {}),
            errors=data.get("errors", []),
            metadata=data.get("metadata", {}),
        )


@dataclass
class TestSuite:
    """A collection of tests to run together.

    Attributes:
        name: Name of the test suite.
        tests: List of test functions or test configurations.
        setup: Optional setup function to run before tests.
        teardown: Optional teardown function to run after tests.
    """

    name: str
    tests: list[Callable] = field(default_factory=list)
    setup: Callable | None = None
    teardown: Callable | None = None


@dataclass
class RunnerConfig:
    """Configuration for the test runner.

    Attributes:
        parallel: Whether to run tests in parallel.
        max_workers: Maximum number of parallel workers.
        timeout_seconds: Timeout for each test in seconds.
        stop_on_failure: Whether to stop on first failure.
        verbose: Whether to output verbose logging.
    """

    parallel: bool = False
    max_workers: int = 4
    timeout_seconds: float = 30.0
    stop_on_failure: bool = False
    verbose: bool = False


class TestRunner:
    """Runner for executing security tests against agent systems.

    This class provides methods to run individual tests, test suites,
    and collect aggregated results.

    Example:
        >>> runner = TestRunner()
        >>> result = runner.run_test(my_test_function, "My Test")
        >>> print(result.status)
    """

    def __init__(self, config: RunnerConfig | None = None):
        """Initialize the test runner.

        Args:
            config: Optional configuration for the runner.
        """
        self.config = config or RunnerConfig()
        self._results: list[TestResult] = []
        self._hooks: dict[str, list[Callable]] = {
            "before_test": [],
            "after_test": [],
            "before_suite": [],
            "after_suite": [],
        }

    def add_hook(self, hook_type: str, callback: Callable) -> None:
        """Add a hook callback for test events.

        Args:
            hook_type: Type of hook (before_test, after_test, etc.).
            callback: Function to call when the hook is triggered.

        Raises:
            ValueError: If hook_type is not recognized.
        """
        if hook_type not in self._hooks:
            raise ValueError(f"Unknown hook type: {hook_type}")
        self._hooks[hook_type].append(callback)

    def _trigger_hooks(self, hook_type: str, *args, **kwargs) -> None:
        """Trigger all callbacks for a hook type.

        Args:
            hook_type: Type of hook to trigger.
            *args: Positional arguments to pass to callbacks.
            **kwargs: Keyword arguments to pass to callbacks.
        """
        for callback in self._hooks.get(hook_type, []):
            try:
                callback(*args, **kwargs)
            except Exception:
                pass  # Hooks should not affect test execution

    def run_test(
        self,
        test_func: Callable,
        test_name: str | None = None,
        **kwargs,
    ) -> TestResult:
        """Run a single test function.

        Args:
            test_func: The test function to execute.
            test_name: Human-readable name for the test.
            **kwargs: Additional arguments to pass to the test function.

        Returns:
            A TestResult with the outcome of the test.
        """
        test_id = f"test_{uuid.uuid4().hex[:8]}"
        name = test_name or getattr(test_func, "__name__", "unnamed_test")

        result = TestResult(
            test_id=test_id,
            test_name=name,
            status=TestStatus.RUNNING,
        )

        self._trigger_hooks("before_test", result)

        start_time = time.time()
        try:
            output = test_func(**kwargs)
            end_time = time.time()

            result.duration_ms = (end_time - start_time) * 1000
            result.status = TestStatus.PASSED
            result.message = "Test passed successfully"

            if isinstance(output, dict):
                result.details = output

        except AssertionError as e:
            end_time = time.time()
            result.duration_ms = (end_time - start_time) * 1000
            result.status = TestStatus.FAILED
            result.message = str(e) or "Assertion failed"
            result.errors.append(str(e))

        except Exception as e:
            end_time = time.time()
            result.duration_ms = (end_time - start_time) * 1000
            result.status = TestStatus.ERROR
            result.message = f"Test error: {type(e).__name__}: {e}"
            result.errors.append(str(e))

        self._trigger_hooks("after_test", result)
        self._results.append(result)

        return result

    def run_tests(
        self,
        tests: list[Callable | tuple],
    ) -> list[TestResult]:
        """Run multiple tests.

        Args:
            tests: List of test functions or (function, name) tuples.

        Returns:
            A list of TestResult instances.
        """
        results = []
        for test in tests:
            if isinstance(test, tuple):
                func, name = test
                result = self.run_test(func, name)
            else:
                result = self.run_test(test)

            results.append(result)

            if self.config.stop_on_failure and result.failed:
                break

        return results

    def run_suite(self, suite: TestSuite) -> list[TestResult]:
        """Run a test suite.

        Args:
            suite: The test suite to execute.

        Returns:
            A list of TestResult instances from the suite.
        """
        self._trigger_hooks("before_suite", suite)

        if suite.setup:
            try:
                suite.setup()
            except Exception as e:
                error_result = TestResult(
                    test_id=f"suite_setup_{uuid.uuid4().hex[:8]}",
                    test_name=f"{suite.name} Setup",
                    status=TestStatus.ERROR,
                    message=f"Suite setup failed: {e}",
                    errors=[str(e)],
                )
                self._results.append(error_result)
                return [error_result]

        results = self.run_tests(suite.tests)

        if suite.teardown:
            try:
                suite.teardown()
            except Exception:
                pass  # Teardown failures should not affect results

        self._trigger_hooks("after_suite", suite, results)

        return results

    def get_results(self) -> list[TestResult]:
        """Get all collected test results.

        Returns:
            List of all TestResult instances from previous runs.
        """
        return list(self._results)

    def get_summary(self) -> dict[str, Any]:
        """Get a summary of test results.

        Returns:
            Dictionary with test statistics.
        """
        total = len(self._results)
        passed = sum(1 for r in self._results if r.status == TestStatus.PASSED)
        failed = sum(1 for r in self._results if r.status == TestStatus.FAILED)
        errors = sum(1 for r in self._results if r.status == TestStatus.ERROR)
        skipped = sum(1 for r in self._results if r.status == TestStatus.SKIPPED)

        total_duration = sum(r.duration_ms for r in self._results)

        return {
            "total": total,
            "passed": passed,
            "failed": failed,
            "errors": errors,
            "skipped": skipped,
            "pass_rate": (passed / total * 100) if total > 0 else 0.0,
            "total_duration_ms": total_duration,
            "average_duration_ms": (total_duration / total) if total > 0 else 0.0,
        }

    def clear_results(self) -> None:
        """Clear all collected test results."""
        self._results.clear()

    def export_results(self, format: str = "dict") -> list[dict] | str:
        """Export test results in various formats.

        Args:
            format: Output format ('dict', 'json', or 'markdown').

        Returns:
            Results in the requested format.

        Raises:
            ValueError: If format is not supported.
        """
        if format == "dict":
            return [r.to_dict() for r in self._results]

        elif format == "json":
            import json

            return json.dumps(
                [r.to_dict() for r in self._results],
                indent=2,
            )

        elif format == "markdown":
            lines = ["# Test Results\n"]
            summary = self.get_summary()
            lines.append(f"**Total:** {summary['total']} tests")
            lines.append(f"**Passed:** {summary['passed']}")
            lines.append(f"**Failed:** {summary['failed']}")
            lines.append(f"**Errors:** {summary['errors']}")
            lines.append(f"**Pass Rate:** {summary['pass_rate']:.1f}%\n")

            lines.append("## Individual Results\n")
            for result in self._results:
                status_icon = {
                    TestStatus.PASSED: "[PASS]",
                    TestStatus.FAILED: "[FAIL]",
                    TestStatus.ERROR: "[ERROR]",
                    TestStatus.SKIPPED: "[SKIP]",
                    TestStatus.PENDING: "[PENDING]",
                    TestStatus.RUNNING: "[RUNNING]",
                }.get(result.status, "[?]")

                lines.append(
                    f"- {status_icon} **{result.test_name}** " f"({result.duration_ms:.1f}ms)"
                )
                if result.message:
                    lines.append(f"  - {result.message}")

            return "\n".join(lines)

        else:
            raise ValueError(f"Unsupported format: {format}")
