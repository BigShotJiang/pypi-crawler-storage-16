"""Validation framework for Vantage analysis components.

Provides ground truth validation and comprehensive metrics for:
- MAST failure detection (precision, recall, F1)
- Connection detection accuracy
- Alignment scoring calibration
- Expected Calibration Error (ECE)
"""

from vantage_core.validation.ground_truth import (
    GroundTruthAlignment,
    GroundTruthConnection,
    GroundTruthDataset,
    GroundTruthFailure,
)
from vantage_core.validation.metrics import (
    CalibrationMetrics,
    ClassificationMetrics,
    RegressionMetrics,
    ValidationMetrics,
)

__all__ = [
    "GroundTruthFailure",
    "GroundTruthConnection",
    "GroundTruthAlignment",
    "GroundTruthDataset",
    "ClassificationMetrics",
    "RegressionMetrics",
    "CalibrationMetrics",
    "ValidationMetrics",
]
