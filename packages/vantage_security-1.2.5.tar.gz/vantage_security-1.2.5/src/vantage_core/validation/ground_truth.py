"""Ground truth dataset schema and loading for validation.

Provides dataclasses for storing expert-annotated ground truth data
for MAST failure detection, connection detection, and alignment scoring.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class GroundTruthFailure:
    """Ground truth for failure mode detection."""

    agent_id: str
    failure_code: str  # e.g., "FM-1.1"
    is_present: bool  # True if failure exists
    severity: str | None = None  # If present, the severity
    annotator: str = ""
    confidence: float = 1.0  # Annotator confidence

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GroundTruthFailure:
        """Create from dictionary."""
        return cls(**data)


@dataclass
class GroundTruthConnection:
    """Ground truth for connection detection."""

    source: str
    target: str
    exists: bool
    data_passed: list[str] = field(default_factory=list)
    annotator: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GroundTruthConnection:
        """Create from dictionary."""
        return cls(**data)


@dataclass
class GroundTruthAlignment:
    """Ground truth for alignment scoring."""

    system_id: str
    overall_score: float  # Expert-assigned 0-100
    grade: str  # A/B/C/D/F
    component_scores: dict[str, float] = field(default_factory=dict)
    annotator: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GroundTruthAlignment:
        """Create from dictionary."""
        return cls(**data)


@dataclass
class GroundTruthDataset:
    """Complete ground truth dataset."""

    failures: list[GroundTruthFailure] = field(default_factory=list)
    connections: list[GroundTruthConnection] = field(default_factory=list)
    alignments: list[GroundTruthAlignment] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def load(cls, path: Path) -> GroundTruthDataset:
        """Load dataset from JSON file.

        Args:
            path: Path to JSON file

        Returns:
            GroundTruthDataset instance

        Raises:
            FileNotFoundError: If file does not exist
            json.JSONDecodeError: If file is not valid JSON
        """
        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        failures = [GroundTruthFailure.from_dict(f) for f in data.get("failures", [])]
        connections = [GroundTruthConnection.from_dict(c) for c in data.get("connections", [])]
        alignments = [GroundTruthAlignment.from_dict(a) for a in data.get("alignments", [])]
        metadata = data.get("metadata", {})

        return cls(
            failures=failures,
            connections=connections,
            alignments=alignments,
            metadata=metadata,
        )

    def save(self, path: Path) -> None:
        """Save dataset to JSON file.

        Args:
            path: Path to save JSON file
        """
        data = {
            "failures": [f.to_dict() for f in self.failures],
            "connections": [c.to_dict() for c in self.connections],
            "alignments": [a.to_dict() for a in self.alignments],
            "metadata": self.metadata,
        }

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def add_failure(self, failure: GroundTruthFailure) -> None:
        """Add a failure annotation."""
        self.failures.append(failure)

    def add_connection(self, connection: GroundTruthConnection) -> None:
        """Add a connection annotation."""
        self.connections.append(connection)

    def add_alignment(self, alignment: GroundTruthAlignment) -> None:
        """Add an alignment annotation."""
        self.alignments.append(alignment)

    def get_failures_for_agent(self, agent_id: str) -> list[GroundTruthFailure]:
        """Get all failure annotations for a specific agent."""
        return [f for f in self.failures if f.agent_id == agent_id]

    def get_connections_for_source(self, source: str) -> list[GroundTruthConnection]:
        """Get all connections from a specific source."""
        return [c for c in self.connections if c.source == source]

    def get_alignment_for_system(self, system_id: str) -> GroundTruthAlignment | None:
        """Get alignment annotation for a specific system."""
        for a in self.alignments:
            if a.system_id == system_id:
                return a
        return None

    def summary(self) -> dict[str, Any]:
        """Get summary statistics of the dataset."""
        unique_agents = set(f.agent_id for f in self.failures)
        unique_systems = set(a.system_id for a in self.alignments)

        failure_counts: dict[str, int] = {}
        for f in self.failures:
            if f.is_present:
                failure_counts[f.failure_code] = failure_counts.get(f.failure_code, 0) + 1

        return {
            "total_failure_annotations": len(self.failures),
            "total_connection_annotations": len(self.connections),
            "total_alignment_annotations": len(self.alignments),
            "unique_agents": len(unique_agents),
            "unique_systems": len(unique_systems),
            "failure_counts": failure_counts,
            "connections_with_data": sum(1 for c in self.connections if c.data_passed),
        }
