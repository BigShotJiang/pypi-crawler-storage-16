/**
 * AgentSync Web Dashboard - Main JavaScript
 */

// API Helper
const API = {
    async get(endpoint) {
        const response = await fetch(endpoint);
        if (!response.ok) throw new Error(`API error: ${response.status}`);
        return response.json();
    },

    async post(endpoint, data) {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });
        if (!response.ok) throw new Error(`API error: ${response.status}`);
        return response.json();
    },
};

// Utility functions
const Utils = {
    formatNumber(num) {
        if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
        if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
        return num.toString();
    },

    formatPercent(value) {
        return (value * 100).toFixed(1) + '%';
    },

    getSeverityColor(severity) {
        const colors = {
            critical: '#ef4444',
            high: '#f97316',
            medium: '#eab308',
            low: '#3b82f6',
            info: '#6b7280',
        };
        return colors[severity.toLowerCase()] || colors.info;
    },

    getStateColor(state) {
        const colors = {
            susceptible: '#22c55e',
            exposed: '#f59e0b',
            infected: '#ef4444',
            contained: '#3b82f6',
        };
        return colors[state.toLowerCase()] || '#9ca3af';
    },

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },
};

// Toast notifications
const Toast = {
    container: null,

    init() {
        this.container = document.createElement('div');
        this.container.className = 'fixed bottom-4 right-4 z-50 space-y-2';
        document.body.appendChild(this.container);
    },

    show(message, type = 'info') {
        if (!this.container) this.init();

        const colors = {
            success: 'bg-green-500',
            error: 'bg-red-500',
            warning: 'bg-yellow-500',
            info: 'bg-blue-500',
        };

        const toast = document.createElement('div');
        toast.className = `${colors[type]} text-white px-6 py-3 rounded-lg shadow-lg fade-in`;
        toast.textContent = message;

        this.container.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(100%)';
            toast.style.transition = 'all 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    },

    success(message) { this.show(message, 'success'); },
    error(message) { this.show(message, 'error'); },
    warning(message) { this.show(message, 'warning'); },
    info(message) { this.show(message, 'info'); },
};

// Infection Visualizer
class InfectionVisualizer {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.svg = d3.select(`#${containerId} svg`);
        this.width = this.container.clientWidth;
        this.height = this.container.clientHeight;
        this.nodes = [];
        this.links = [];
        this.simulation = null;
        this.animationData = null;
        this.currentFrame = 0;
        this.isPlaying = false;
        this.playInterval = null;
    }

    setData(agents, connections, animationData) {
        this.nodes = agents;
        this.links = connections;
        this.animationData = animationData;
        this.currentFrame = 0;
        this.render();
    }

    render() {
        this.svg.selectAll('*').remove();

        // Create force simulation
        this.simulation = d3.forceSimulation(this.nodes)
            .force('link', d3.forceLink(this.links).id(d => d.id).distance(100))
            .force('charge', d3.forceManyBody().strength(-300))
            .force('center', d3.forceCenter(this.width / 2, this.height / 2));

        // Draw links
        const links = this.svg.append('g')
            .selectAll('line')
            .data(this.links)
            .enter()
            .append('line')
            .attr('class', 'network-link')
            .attr('stroke', 'rgba(255,255,255,0.3)')
            .attr('stroke-width', 2);

        // Draw nodes
        const nodes = this.svg.append('g')
            .selectAll('g')
            .data(this.nodes)
            .enter()
            .append('g')
            .attr('class', 'network-node')
            .call(d3.drag()
                .on('start', this.dragStarted.bind(this))
                .on('drag', this.dragged.bind(this))
                .on('end', this.dragEnded.bind(this)));

        nodes.append('circle')
            .attr('r', 25)
            .attr('fill', Utils.getStateColor('susceptible'))
            .attr('id', d => `node-${d.id}`);

        nodes.append('text')
            .text(d => d.name ? d.name.split(' ')[0] : d.id)
            .attr('text-anchor', 'middle')
            .attr('dy', 4)
            .attr('fill', 'white')
            .attr('font-size', '10px');

        // Update positions on tick
        this.simulation.on('tick', () => {
            links
                .attr('x1', d => d.source.x)
                .attr('y1', d => d.source.y)
                .attr('x2', d => d.target.x)
                .attr('y2', d => d.target.y);

            nodes.attr('transform', d => `translate(${d.x},${d.y})`);
        });
    }

    updateFrame(frameIndex) {
        if (!this.animationData || !this.animationData.frames[frameIndex]) return;

        const frame = this.animationData.frames[frameIndex];
        this.currentFrame = frameIndex;

        Object.entries(frame.agent_states).forEach(([agentId, state]) => {
            const color = Utils.getStateColor(state.state);
            d3.select(`#node-${agentId}`).attr('fill', color);
        });
    }

    play() {
        if (this.isPlaying) return;
        this.isPlaying = true;

        this.playInterval = setInterval(() => {
            if (this.currentFrame < this.animationData.frames.length - 1) {
                this.updateFrame(this.currentFrame + 1);
            } else {
                this.stop();
                this.updateFrame(0);
            }
        }, 500);
    }

    stop() {
        this.isPlaying = false;
        if (this.playInterval) {
            clearInterval(this.playInterval);
            this.playInterval = null;
        }
    }

    dragStarted(event, d) {
        if (!event.active) this.simulation.alphaTarget(0.3).restart();
        d.fx = d.x;
        d.fy = d.y;
    }

    dragged(event, d) {
        d.fx = event.x;
        d.fy = event.y;
    }

    dragEnded(event, d) {
        if (!event.active) this.simulation.alphaTarget(0);
        d.fx = null;
        d.fy = null;
    }
}

// Prompt Tester
class PromptTester {
    constructor() {
        this.results = null;
    }

    async test(prompt, options = {}) {
        const { categories = [], maxPayloads = 50 } = options;

        const response = await API.post('/api/test-prompt', {
            prompt,
            payloads: categories,
            max_payloads: maxPayloads,
        });

        this.results = response;
        return response;
    }

    async quickScan(prompt) {
        return API.post('/api/quick-scan', { prompt });
    }

    getScoreColor(score) {
        if (score >= 80) return '#22c55e';
        if (score >= 50) return '#f59e0b';
        return '#ef4444';
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    // Initialize toast system
    Toast.init();

    // Check API health
    API.get('/api/health')
        .then(data => console.log('API healthy:', data))
        .catch(err => console.error('API health check failed:', err));
});

// Export for use in templates
window.API = API;
window.Utils = Utils;
window.Toast = Toast;
window.InfectionVisualizer = InfectionVisualizer;
window.PromptTester = PromptTester;
