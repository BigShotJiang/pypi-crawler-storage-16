"""
Vantage Protocols - Interface definitions for service communication.

These protocols define the contracts between OSS and proprietary components,
allowing them to be swapped without changing the core logic.
"""

from vantage_protocols.payloads import (
    Payload,
    PayloadCategory,
    PayloadProvider,
    PayloadResult,
    PayloadSeverity,
    Severity,
)
from vantage_protocols.detection import (
    ClassificationResult,
    InjectionDetector,
    DetectionConfig,
)
from vantage_protocols.license import (
    Tier,
    LicenseInfo,
    LicenseValidator,
    Feature,
)
from vantage_protocols.scanning import (
    ScanResult,
    ScanConfig,
    Scanner,
    Finding,
    Severity,
)
from vantage_protocols.effectiveness import (
    EffectivenessReport,
    EffectivenessProvider,
    FrameworkStats,
)

__all__ = [
    # Payloads
    "Payload",
    "PayloadCategory",
    "PayloadProvider",
    "PayloadResult",
    "PayloadSeverity",
    "Severity",
    # Detection
    "ClassificationResult",
    "InjectionDetector",
    "DetectionConfig",
    # License
    "Tier",
    "LicenseInfo",
    "LicenseValidator",
    "Feature",
    # Scanning
    "ScanResult",
    "ScanConfig",
    "Scanner",
    "Finding",
    "Severity",
    # Effectiveness
    "EffectivenessReport",
    "EffectivenessProvider",
    "FrameworkStats",
]

__version__ = "1.0.0"
