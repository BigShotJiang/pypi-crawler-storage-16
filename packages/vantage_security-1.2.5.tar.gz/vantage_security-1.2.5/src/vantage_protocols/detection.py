"""
Injection Detection Protocol.

Defines the interface for ML-based and pattern-based detection.
OSS includes PatternDetector, Proprietary includes MLClassifier.
"""

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable


@dataclass
class DetectionConfig:
    """Configuration for detection."""
    confidence_threshold: float = 0.7
    use_semantic_analysis: bool = True
    use_pattern_matching: bool = True
    max_input_length: int = 10000
    batch_size: int = 32


@dataclass
class ClassificationResult:
    """Result from injection classification."""
    is_injection: bool
    confidence: float
    category: str | None = None
    matched_patterns: list[str] = field(default_factory=list)
    similar_payloads: list[str] = field(default_factory=list)
    explanation: str | None = None
    processing_time_ms: float = 0.0

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "is_injection": self.is_injection,
            "confidence": self.confidence,
            "category": self.category,
            "matched_patterns": self.matched_patterns,
            "similar_payloads": self.similar_payloads,
            "explanation": self.explanation,
            "processing_time_ms": self.processing_time_ms,
        }


@runtime_checkable
class InjectionDetector(Protocol):
    """Interface for injection detection."""

    def classify(self, text: str) -> ClassificationResult:
        """Classify text as injection or benign."""
        ...

    def batch_classify(self, texts: list[str]) -> list[ClassificationResult]:
        """Classify multiple texts."""
        ...

    def get_model_info(self) -> dict:
        """Get information about the detection model."""
        ...

    def update_config(self, config: DetectionConfig) -> None:
        """Update detection configuration."""
        ...
