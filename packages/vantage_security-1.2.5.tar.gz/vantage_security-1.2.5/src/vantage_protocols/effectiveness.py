"""
Effectiveness Tracking Protocol.

Defines the interface for tracking payload effectiveness across frameworks.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Protocol, runtime_checkable


@dataclass
class EffectivenessReport:
    """Report of payload effectiveness."""
    payload_id: str
    framework: str
    model: str | None = None
    success: bool = False
    confidence: float = 0.0
    response_snippet: str | None = None  # First 100 chars, no sensitive data
    timestamp: datetime = field(default_factory=datetime.utcnow)
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary for API transmission."""
        return {
            "payload_id": self.payload_id,
            "framework": self.framework,
            "model": self.model,
            "success": self.success,
            "confidence": self.confidence,
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class FrameworkStats:
    """Statistics for a framework."""
    framework: str
    total_tests: int
    successful_injections: int
    success_rate: float
    most_effective_payloads: list[str] = field(default_factory=list)
    least_effective_payloads: list[str] = field(default_factory=list)
    last_updated: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "framework": self.framework,
            "total_tests": self.total_tests,
            "successful_injections": self.successful_injections,
            "success_rate": self.success_rate,
            "most_effective_payloads": self.most_effective_payloads,
            "least_effective_payloads": self.least_effective_payloads,
            "last_updated": self.last_updated.isoformat(),
        }


@dataclass
class PayloadEffectiveness:
    """Effectiveness data for a single payload."""
    payload_id: str
    overall_success_rate: float
    framework_rates: dict[str, float] = field(default_factory=dict)
    model_rates: dict[str, float] = field(default_factory=dict)
    total_tests: int = 0
    last_tested: datetime | None = None

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "payload_id": self.payload_id,
            "overall_success_rate": self.overall_success_rate,
            "framework_rates": self.framework_rates,
            "model_rates": self.model_rates,
            "total_tests": self.total_tests,
            "last_tested": self.last_tested.isoformat() if self.last_tested else None,
        }


@runtime_checkable
class EffectivenessProvider(Protocol):
    """Interface for effectiveness data."""

    def report_result(self, report: EffectivenessReport) -> bool:
        """Report a test result."""
        ...

    def get_framework_stats(self, framework: str) -> FrameworkStats | None:
        """Get statistics for a framework."""
        ...

    def get_all_framework_stats(self) -> list[FrameworkStats]:
        """Get statistics for all frameworks."""
        ...

    def get_payload_effectiveness(self, payload_id: str) -> PayloadEffectiveness | None:
        """Get effectiveness data for a payload."""
        ...

    def get_recommended_payloads(
        self,
        framework: str,
        limit: int = 10,
    ) -> list[str]:
        """Get recommended payloads for a framework."""
        ...
