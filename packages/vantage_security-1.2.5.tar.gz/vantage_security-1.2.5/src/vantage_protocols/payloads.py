"""
Payload Provider Protocol.

Defines the interface for payload sources. The OSS version includes
BasicPayloadProvider with 33 payloads. The proprietary version includes
FullPayloadProvider with 206+ payloads.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Protocol, runtime_checkable


class PayloadCategory(str, Enum):
    """Categories of prompt injection attacks."""
    # Direct instruction override
    INSTRUCTION_OVERRIDE = "instruction_override"

    # Role/persona hijacking
    ROLE_HIJACKING = "role_hijacking"

    # System prompt extraction
    PROMPT_EXTRACTION = "prompt_extraction"

    # Jailbreak attempts
    JAILBREAK = "jailbreak"

    # Token-level injections ([INST], <|system|>)
    TOKEN_INJECTION = "token_injection"

    # Context manipulation
    CONTEXT_MANIPULATION = "context_manipulation"

    # Multi-turn attacks
    MULTI_TURN = "multi_turn"

    # Encoding-based (base64, rot13, etc.)
    ENCODING_ATTACK = "encoding_attack"

    # Indirect injection (via retrieved content)
    INDIRECT_INJECTION = "indirect_injection"

    # Privilege escalation between agents
    PRIVILEGE_ESCALATION = "privilege_escalation"

    # Data exfiltration
    DATA_EXFILTRATION = "data_exfiltration"

    # Tool abuse
    TOOL_ABUSE = "tool_abuse"

    # Evaluation manipulation
    EVALUATION_MANIPULATION = "evaluation_manipulation"

    # Multi-agent specific attacks
    MULTI_AGENT = "multi_agent"

    # Role manipulation
    ROLE_MANIPULATION = "role_manipulation"


class PayloadSeverity(str, Enum):
    """Severity levels for payloads."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


# Alias for backward compatibility
Severity = PayloadSeverity


@dataclass
class Payload:
    """A prompt injection payload."""
    id: str
    text: str
    category: PayloadCategory
    severity: PayloadSeverity
    name: str
    description: str
    expected_behavior: str
    target_frameworks: list[str] = field(default_factory=list)
    effectiveness_score: float | None = None
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "text": self.text,
            "category": self.category.value,
            "severity": self.severity.value,
            "name": self.name,
            "description": self.description,
            "expected_behavior": self.expected_behavior,
            "target_frameworks": self.target_frameworks,
            "effectiveness_score": self.effectiveness_score,
            "tags": self.tags,
        }


@dataclass
class PayloadResult:
    """Result of testing a payload."""
    payload_id: str
    success: bool
    response: str | None = None
    confidence: float = 0.0
    detection_bypassed: bool = False
    notes: str | None = None


@runtime_checkable
class PayloadProvider(Protocol):
    """Interface for payload providers."""

    def get_payloads(
        self,
        categories: list[PayloadCategory] | None = None,
        severity: PayloadSeverity | None = None,
        limit: int | None = None,
        offset: int = 0,
    ) -> list[Payload]:
        """Get payloads with optional filtering."""
        ...

    def get_payload_by_id(self, payload_id: str) -> Payload | None:
        """Get a specific payload by ID."""
        ...

    def get_categories(self) -> list[PayloadCategory]:
        """Get available payload categories."""
        ...

    def get_payload_count(self) -> int:
        """Get total number of payloads available."""
        ...

    def search_payloads(self, query: str) -> list[Payload]:
        """Search payloads by text content."""
        ...
