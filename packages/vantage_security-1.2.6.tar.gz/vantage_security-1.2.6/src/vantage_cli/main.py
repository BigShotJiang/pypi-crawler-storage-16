"""Vantage CLI Main Entry Point.

This is the main command-line interface for Vantage.
It provides a unified entry point for all security scanning operations.
"""

from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console

# Import commands lazily to improve startup time
from vantage_cli.commands._loaders import (
    load_analyze_commands,
    load_compliance_commands,
    load_dashboard_commands,
    load_health_commands,
    load_license_commands,
    load_ml_commands,
    load_protect_commands,
    load_scan_commands,
    load_security_commands,
    load_verify_commands,
    load_web_commands,
)

app = typer.Typer(
    name="vantage",
    help="Security scanner for multi-agent AI systems",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

console = Console()


def version_callback(value: bool):
    """Show version information."""
    if value:
        from vantage_cli import __version__

        console.print(f"Vantage CLI v{__version__}")
        raise typer.Exit()


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        help="Show version and exit",
        callback=version_callback,
        is_eager=True,
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Suppress non-essential output",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Enable verbose output",
    ),
    config: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to configuration file",
    ),
):
    """
    Vantage - Security scanner for multi-agent AI systems.

    Scan your AI agent projects for vulnerabilities, analyze agent topologies,
    and simulate prompt injection attacks across 17+ frameworks.

    Examples:
        vantage run ./your-project/
        vantage security scan ./project
        vantage verify test "You are a helpful assistant"
    """
    ctx.ensure_object(dict)
    ctx.obj["quiet"] = quiet
    ctx.obj["verbose"] = verbose
    ctx.obj["config"] = config


@app.command("run")
def run_command(
    path: Path = typer.Argument(
        ...,
        help="Path to the project directory to scan",
        exists=True,
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file path",
    ),
    format: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json, sarif, markdown",
    ),
    min_score: int | None = typer.Option(
        None,
        "--min-score",
        help="Minimum ATSS score required (0-100)",
    ),
    fail_on_high: bool = typer.Option(
        False,
        "--fail-on-high",
        help="Exit with error on high/critical findings",
    ),
    no_simulation: bool = typer.Option(
        False,
        "--no-simulation",
        help="Skip infection simulation (faster)",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Suppress non-essential output",
    ),
):
    """
    Run a full security scan on an AI agent project.

    This is the main entry point for scanning. It performs:
    - Agent detection across 17+ frameworks
    - Topology analysis and trust boundary mapping
    - Vulnerability scanning
    - Prompt injection simulation
    - Security scoring (ATSS)

    Examples:
        vantage run ./your-project/
        vantage run --no-simulation ./project/
        vantage run -o report.json ./project/
        vantage run --min-score 80 ./project/
    """
    from vantage_cli.output import get_console

    cli_console = get_console(quiet=quiet)

    if not quiet:
        cli_console.print_banner(compact=True)

    cli_console.print_header("Security Scan", f"Target: {path}")

    # Run scan using core library
    try:
        from vantage_core import SecurityPipeline

        pipeline = SecurityPipeline()

        # Create progress tracker
        progress = cli_console.create_stage_progress()
        progress.start()

        # Run the pipeline
        result = pipeline.run(
            str(path),
            skip_simulation=no_simulation,
            progress_callback=lambda stage, pct, detail: progress.update(stage, pct, detail),
        )

        progress.stop()

    except ImportError:
        cli_console.error("Core library not available. Install vantage-core.")
        raise typer.Exit(1)
    except Exception as e:
        cli_console.error(f"Scan failed: {e}")
        raise typer.Exit(1)

    # Display results
    if format == "text":
        _display_results(cli_console, result)
    elif format == "json":
        output_data = result.to_dict()
        if output:
            with open(output, "w") as f:
                json.dump(output_data, f, indent=2, default=str)
            cli_console.success(f"Results written to {output}")
        else:
            console.print_json(data=output_data)
    elif format == "sarif":
        from vantage_core.output import to_sarif

        sarif_data = to_sarif(result)
        if output:
            with open(output, "w") as f:
                json.dump(sarif_data, f, indent=2)
            cli_console.success(f"SARIF report written to {output}")
        else:
            console.print_json(data=sarif_data)

    # Check thresholds for CI/CD
    exit_code = 0

    if min_score is not None and result.score < min_score:
        cli_console.error(f"Score {result.score} below minimum {min_score}")
        exit_code = 11

    if fail_on_high:
        critical_count = result.get_severity_count("critical")
        high_count = result.get_severity_count("high")
        if critical_count > 0 or high_count > 0:
            cli_console.error(f"Found {critical_count} critical and {high_count} high findings")
            exit_code = 12 if critical_count > 0 else 10

    if exit_code == 0 and not quiet:
        cli_console.success("Scan completed successfully")

    raise typer.Exit(exit_code)


def _display_results(cli_console, result):
    """Display scan results in a formatted way."""
    # Score panel
    cli_console.print_score_panel(
        score=result.score,
        grade=result.grade,
        title="ATSS Security Score",
    )

    # Statistics
    stats = {
        "Agents Detected": len(result.agents),
        "Frameworks": ", ".join(result.frameworks) if result.frameworks else "None",
        "Connections": len(result.connections) if hasattr(result, "connections") else 0,
        "Total Findings": len(result.findings),
    }
    cli_console.print_stats_panel(stats, "Scan Summary")

    # Findings summary
    severity_counts = {
        "critical": 0,
        "high": 0,
        "medium": 0,
        "low": 0,
        "info": 0,
    }
    for finding in result.findings:
        sev = (
            finding.severity.value
            if hasattr(finding.severity, "value")
            else str(finding.severity).lower()
        )
        if sev in severity_counts:
            severity_counts[sev] += 1

    cli_console.print_findings_panel(**severity_counts)

    # Detailed findings table
    if result.findings:
        findings_dicts = []
        for f in result.findings:
            findings_dicts.append(
                {
                    "id": f.id if hasattr(f, "id") else "N/A",
                    "severity": (
                        f.severity.value if hasattr(f.severity, "value") else str(f.severity)
                    ),
                    "title": f.title if hasattr(f, "title") else f.type,
                    "location": {
                        "file_path": (f.location.file_path if hasattr(f, "location") else "N/A"),
                        "line_number": (f.location.line_number if hasattr(f, "location") else "?"),
                    },
                }
            )
        cli_console.print_findings_table(findings_dicts)


# Register subcommand groups
app.add_typer(load_scan_commands(), name="scan", help="Agent detection commands")
app.add_typer(load_security_commands(), name="security", help="Security scanning commands")
app.add_typer(load_health_commands(), name="health", help="Health check commands")
app.add_typer(load_verify_commands(), name="verify", help="Verification and testing commands")
app.add_typer(load_compliance_commands(), name="compliance", help="Compliance reporting commands")
app.add_typer(load_dashboard_commands(), name="dashboard", help="Team dashboard commands")
app.add_typer(load_license_commands(), name="license", help="License management commands")
app.add_typer(load_protect_commands(), name="protect", help="Prompt protection commands")
app.add_typer(load_ml_commands(), name="ml", help="ML detection commands")
app.add_typer(load_web_commands(), name="web", help="Web dashboard commands")
app.add_typer(load_analyze_commands(), name="analyze", help="Analysis commands")


if __name__ == "__main__":
    app()
