"""
Vantage Core - Open Source Security Scanning Library.

This is the core scanning engine for multi-agent AI systems.
It provides framework detection, topology analysis, and basic
vulnerability scanning.

MIT Licensed - Free to use, modify, and distribute.
"""

from .models import (
    DetectedAgent,
    DetectedConnection,
    ScanResult,
    SecurityFinding,
)
from .providers import (
    BasicPayloadProvider,
    PatternDetector,
)
from .scanner import CoreScanner
from .scoring.engine import ScoreResult, ScoringEngine
from .topology.graph import AgentGraph

__all__ = [
    # Main scanner
    "CoreScanner",
    # Topology
    "AgentGraph",
    # Scoring
    "ScoringEngine",
    "ScoreResult",
    # Models
    "DetectedAgent",
    "DetectedConnection",
    "SecurityFinding",
    "ScanResult",
    # Providers (OSS implementations)
    "BasicPayloadProvider",
    "PatternDetector",
]

__version__ = "1.2.6"
