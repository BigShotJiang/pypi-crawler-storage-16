"""Cost estimation for multi-agent systems with real model pricing.

Provides accurate cost estimation using actual API pricing from major providers.
Prices are updated as of November 2025.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vantage_core.core.models import Agent, AgentSystem

logger = logging.getLogger(__name__)


# Real pricing per 1M tokens (November 2025)
# Sources: OpenAI, Anthropic, Google pricing pages
MODEL_PRICING: dict[str, dict[str, float]] = {
    # OpenAI models
    "gpt-4": {"input": 30.00, "output": 60.00},
    "gpt-4-turbo": {"input": 10.00, "output": 30.00},
    "gpt-4-turbo-preview": {"input": 10.00, "output": 30.00},
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "gpt-3.5-turbo": {"input": 0.50, "output": 1.50},
    "gpt-3.5-turbo-16k": {"input": 3.00, "output": 4.00},
    "o1": {"input": 15.00, "output": 60.00},
    "o1-mini": {"input": 3.00, "output": 12.00},
    "o1-preview": {"input": 15.00, "output": 60.00},
    # Anthropic models
    "claude-3-opus": {"input": 15.00, "output": 75.00},
    "claude-3-opus-20240229": {"input": 15.00, "output": 75.00},
    "claude-3-sonnet": {"input": 3.00, "output": 15.00},
    "claude-3-sonnet-20240229": {"input": 3.00, "output": 15.00},
    "claude-3-haiku": {"input": 0.25, "output": 1.25},
    "claude-3-haiku-20240307": {"input": 0.25, "output": 1.25},
    "claude-3.5-sonnet": {"input": 3.00, "output": 15.00},
    "claude-3-5-sonnet-20241022": {"input": 3.00, "output": 15.00},
    "claude-3.5-haiku": {"input": 0.80, "output": 4.00},
    # Google models
    "gemini-pro": {"input": 0.50, "output": 1.50},
    "gemini-1.5-pro": {"input": 3.50, "output": 10.50},
    "gemini-1.5-flash": {"input": 0.075, "output": 0.30},
    "gemini-2.0-flash": {"input": 0.10, "output": 0.40},
    # Meta (via providers)
    "llama-3-70b": {"input": 0.90, "output": 0.90},
    "llama-3-8b": {"input": 0.20, "output": 0.20},
    "llama-3.1-70b": {"input": 0.88, "output": 0.88},
    "llama-3.1-405b": {"input": 3.00, "output": 3.00},
    # Mistral
    "mistral-large": {"input": 2.00, "output": 6.00},
    "mistral-medium": {"input": 2.70, "output": 8.10},
    "mistral-small": {"input": 0.20, "output": 0.60},
    "mixtral-8x7b": {"input": 0.70, "output": 0.70},
    # Default fallback
    "default": {"input": 5.00, "output": 15.00},
}


@dataclass
class AgentCostEstimate:
    """Cost estimate for a single agent."""

    agent_id: str
    agent_name: str
    model: str
    prompt_tokens: int
    estimated_response_tokens: int
    cost_per_call: float
    cost_per_1000_calls: float


@dataclass
class SystemCostEstimate:
    """Complete cost estimate for a multi-agent system."""

    total_cost_per_run: float
    total_tokens_per_run: int
    monthly_cost_1000_runs: float
    monthly_cost_10000_runs: float
    agent_costs: list[AgentCostEstimate]
    most_expensive_agent: str
    cost_breakdown_by_model: dict[str, float]
    optimization_suggestions: list[str]


class CostEstimator:
    """Estimates costs for multi-agent system execution.

    Uses real API pricing to calculate:
    - Per-run costs
    - Monthly projections
    - Cost optimization opportunities
    """

    def __init__(
        self,
        response_ratio: float = 0.3,
        custom_pricing: dict[str, dict[str, float]] | None = None,
    ):
        """Initialize cost estimator.

        Args:
            response_ratio: Estimated response tokens as ratio of max_tokens (0-1).
                Default 0.3 based on typical agent behavior.
            custom_pricing: Optional custom pricing to override defaults
        """
        if not 0 < response_ratio <= 1:
            raise ValueError(f"response_ratio must be 0-1, got {response_ratio}")

        self.response_ratio = response_ratio
        self.pricing = {**MODEL_PRICING}

        if custom_pricing:
            self.pricing.update(custom_pricing)

    def estimate_system_cost(self, system: AgentSystem) -> SystemCostEstimate:
        """Estimate costs for an entire multi-agent system.

        Args:
            system: The agent system to analyze

        Returns:
            Complete cost estimate with breakdowns and suggestions
        """
        agent_costs: list[AgentCostEstimate] = []
        cost_by_model: dict[str, float] = {}
        total_cost = 0.0
        total_tokens = 0

        for agent_id, agent in system.agents.items():
            estimate = self._estimate_agent_cost(agent)
            agent_costs.append(estimate)

            total_cost += estimate.cost_per_call
            total_tokens += estimate.prompt_tokens + estimate.estimated_response_tokens

            # Aggregate by model
            model = estimate.model
            cost_by_model[model] = cost_by_model.get(model, 0) + estimate.cost_per_call

        # Find most expensive agent
        most_expensive = max(agent_costs, key=lambda x: x.cost_per_call) if agent_costs else None
        most_expensive_name = most_expensive.agent_name if most_expensive else "N/A"

        # Generate optimization suggestions
        suggestions = self._generate_optimization_suggestions(agent_costs, cost_by_model)

        return SystemCostEstimate(
            total_cost_per_run=round(total_cost, 6),
            total_tokens_per_run=total_tokens,
            monthly_cost_1000_runs=round(total_cost * 1000, 2),
            monthly_cost_10000_runs=round(total_cost * 10000, 2),
            agent_costs=agent_costs,
            most_expensive_agent=most_expensive_name,
            cost_breakdown_by_model=cost_by_model,
            optimization_suggestions=suggestions,
        )

    def _estimate_agent_cost(self, agent: Agent) -> AgentCostEstimate:
        """Estimate cost for a single agent."""
        # Get token counts
        prompt_tokens = self._count_tokens(agent.prompt.content)
        
        # Handle None for max_tokens (default to 1000 if not specified)
        max_tokens = agent.max_tokens if agent.max_tokens is not None else 1000
        response_tokens = int(max_tokens * self.response_ratio)

        # Get pricing for model
        model_key = self._normalize_model_name(agent.model)
        pricing = self.pricing.get(model_key, self.pricing["default"])

        # Calculate cost (pricing is per 1M tokens)
        input_cost = (prompt_tokens / 1_000_000) * pricing["input"]
        output_cost = (response_tokens / 1_000_000) * pricing["output"]
        total_cost = input_cost + output_cost

        return AgentCostEstimate(
            agent_id=agent.id,
            agent_name=agent.name,
            model=agent.model,
            prompt_tokens=prompt_tokens,
            estimated_response_tokens=response_tokens,
            cost_per_call=total_cost,
            cost_per_1000_calls=total_cost * 1000,
        )

    def _count_tokens(self, text: str) -> int:
        """Estimate token count for text.

        Uses a more accurate heuristic based on GPT tokenization patterns:
        - ~4 chars per token for English
        - Words are typically 1-2 tokens
        - Special characters and numbers vary

        For production, consider using tiktoken for exact counts.
        """
        # More accurate estimation based on word count + character patterns
        words = text.split()
        word_count = len(words)

        # Average 1.3 tokens per word for English
        # Plus overhead for formatting, special tokens
        estimated = int(word_count * 1.3 + len(text) * 0.05)

        return max(estimated, 1)

    def _normalize_model_name(self, model: str) -> str:
        """Normalize model name to match pricing keys."""
        model_lower = model.lower().strip()

        # Direct match
        if model_lower in self.pricing:
            return model_lower

        # Partial matches
        for key in self.pricing:
            if key in model_lower or model_lower in key:
                return key

        # Common aliases
        aliases = {
            "gpt4": "gpt-4",
            "gpt-4-0613": "gpt-4",
            "gpt-4-1106-preview": "gpt-4-turbo",
            "claude-3-opus-latest": "claude-3-opus",
            "claude-3-sonnet-latest": "claude-3-sonnet",
            "claude": "claude-3-sonnet",
            "gemini": "gemini-pro",
        }

        for alias, canonical in aliases.items():
            if alias in model_lower:
                return canonical

        logger.warning(f"Unknown model '{model}', using default pricing")
        return "default"

    def _generate_optimization_suggestions(
        self,
        agent_costs: list[AgentCostEstimate],
        cost_by_model: dict[str, float],
    ) -> list[str]:
        """Generate cost optimization suggestions."""
        suggestions: list[str] = []

        if not agent_costs:
            return suggestions

        # Check for expensive models that could be downgraded
        expensive_models = {"gpt-4", "claude-3-opus", "o1", "o1-preview"}
        cheap_alternatives = {
            "gpt-4": "gpt-4o-mini (95% cheaper) or gpt-4o (75% cheaper)",
            "claude-3-opus": "claude-3.5-sonnet (80% cheaper) or claude-3.5-haiku (95% cheaper)",
            "o1": "o1-mini (80% cheaper) for simpler reasoning tasks",
            "o1-preview": "o1-mini (80% cheaper) for simpler reasoning tasks",
        }

        for agent in agent_costs:
            model_key = self._normalize_model_name(agent.model)
            if model_key in expensive_models:
                alt = cheap_alternatives.get(model_key, "a smaller model")
                suggestions.append(
                    f"Agent '{agent.agent_name}' uses {agent.model}. "
                    f"Consider {alt} for non-critical tasks."
                )

        # Check for large prompts
        large_prompt_agents = [a for a in agent_costs if a.prompt_tokens > 2000]
        if large_prompt_agents:
            names = [a.agent_name for a in large_prompt_agents[:3]]
            suggestions.append(
                f"Large prompts detected ({', '.join(names)}). "
                "Consider prompt compression or caching for repeated context."
            )

        # Check model diversity
        if len(cost_by_model) == 1 and len(agent_costs) > 3:
            model = list(cost_by_model.keys())[0]
            suggestions.append(
                f"All agents use {model}. Consider model routing: "
                "use smaller models for simple tasks, larger for complex ones."
            )

        # Overall cost warning
        total = sum(a.cost_per_call for a in agent_costs)
        if total > 0.10:  # More than 10 cents per run
            monthly = total * 10000
            suggestions.append(
                f"High cost per run (${total:.4f}). "
                f"At 10K runs/month = ${monthly:.2f}/month. "
                "Prioritize optimization for most expensive agents."
            )

        if not suggestions:
            suggestions.append(
                "Cost structure looks reasonable. Monitor usage to identify optimization opportunities."
            )

        return suggestions

    def compare_model_costs(self, agent: Agent) -> dict[str, float]:
        """Compare costs across different models for an agent.

        Useful for deciding which model to use.
        """
        prompt_tokens = self._count_tokens(agent.prompt.content)
        
        # Handle None for max_tokens (default to 1000 if not specified)
        max_tokens = agent.max_tokens if agent.max_tokens is not None else 1000
        response_tokens = int(max_tokens * self.response_ratio)

        comparisons: dict[str, float] = {}

        for model, pricing in self.pricing.items():
            if model == "default":
                continue

            input_cost = (prompt_tokens / 1_000_000) * pricing["input"]
            output_cost = (response_tokens / 1_000_000) * pricing["output"]
            comparisons[model] = input_cost + output_cost

        # Sort by cost
        return dict(sorted(comparisons.items(), key=lambda x: x[1]))
