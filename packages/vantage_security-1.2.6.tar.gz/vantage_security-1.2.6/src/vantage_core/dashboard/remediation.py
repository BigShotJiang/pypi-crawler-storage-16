"""Remediation tracking for Team Dashboard.

Tracks security finding remediation status and progress.
"""

import hashlib
import json
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any


class RemediationStatus(str, Enum):
    """Status of a remediation item."""

    OPEN = "open"
    IN_PROGRESS = "in_progress"
    BLOCKED = "blocked"
    RESOLVED = "resolved"
    ACCEPTED_RISK = "accepted_risk"
    FALSE_POSITIVE = "false_positive"
    WONT_FIX = "wont_fix"


class RemediationPriority(str, Enum):
    """Priority of a remediation item."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class RemediationItem:
    """A remediation tracking item."""

    item_id: str
    finding_id: str
    finding_type: str
    severity: str
    project_name: str
    agent_id: str
    agent_name: str
    title: str
    description: str
    status: RemediationStatus
    priority: RemediationPriority
    created_at: str
    updated_at: str
    due_date: str | None = None
    assignee: str = ""
    resolution_notes: str = ""
    resolved_at: str | None = None
    resolved_by: str = ""
    scan_id: str = ""
    file_path: str = ""
    line_number: int | None = None
    remediation_steps: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    comments: list[dict[str, Any]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "item_id": self.item_id,
            "finding_id": self.finding_id,
            "finding_type": self.finding_type,
            "severity": self.severity,
            "project_name": self.project_name,
            "agent_id": self.agent_id,
            "agent_name": self.agent_name,
            "title": self.title,
            "description": self.description,
            "status": self.status.value,
            "priority": self.priority.value,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "due_date": self.due_date,
            "assignee": self.assignee,
            "resolution_notes": self.resolution_notes,
            "resolved_at": self.resolved_at,
            "resolved_by": self.resolved_by,
            "scan_id": self.scan_id,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "remediation_steps": self.remediation_steps,
            "tags": self.tags,
            "comments": self.comments,
            "metadata": self.metadata,
        }

    @property
    def is_open(self) -> bool:
        """Check if item is still open."""
        return self.status in [
            RemediationStatus.OPEN,
            RemediationStatus.IN_PROGRESS,
            RemediationStatus.BLOCKED,
        ]

    @property
    def is_resolved(self) -> bool:
        """Check if item is resolved."""
        return self.status in [
            RemediationStatus.RESOLVED,
            RemediationStatus.ACCEPTED_RISK,
            RemediationStatus.FALSE_POSITIVE,
            RemediationStatus.WONT_FIX,
        ]

    @property
    def days_open(self) -> int:
        """Calculate days since creation."""
        created = datetime.fromisoformat(self.created_at)
        if self.resolved_at:
            end = datetime.fromisoformat(self.resolved_at)
        else:
            end = datetime.now()
        return (end - created).days

    @property
    def is_overdue(self) -> bool:
        """Check if item is past due date."""
        if not self.due_date or not self.is_open:
            return False
        due = datetime.fromisoformat(self.due_date)
        return datetime.now() > due


@dataclass
class RemediationSummary:
    """Summary of remediation status for a project."""

    project_name: str
    total_items: int
    open_count: int
    in_progress_count: int
    blocked_count: int
    resolved_count: int
    accepted_risk_count: int
    false_positive_count: int
    wont_fix_count: int
    by_severity: dict[str, int]
    by_priority: dict[str, int]
    overdue_count: int
    avg_resolution_days: float
    mttr_critical: float  # Mean time to remediate (critical)
    mttr_high: float
    mttr_medium: float
    mttr_low: float

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "project_name": self.project_name,
            "total_items": self.total_items,
            "open_count": self.open_count,
            "in_progress_count": self.in_progress_count,
            "blocked_count": self.blocked_count,
            "resolved_count": self.resolved_count,
            "accepted_risk_count": self.accepted_risk_count,
            "false_positive_count": self.false_positive_count,
            "wont_fix_count": self.wont_fix_count,
            "by_severity": self.by_severity,
            "by_priority": self.by_priority,
            "overdue_count": self.overdue_count,
            "avg_resolution_days": self.avg_resolution_days,
            "mttr_critical": self.mttr_critical,
            "mttr_high": self.mttr_high,
            "mttr_medium": self.mttr_medium,
            "mttr_low": self.mttr_low,
        }


class RemediationTracker:
    """SQLite database for remediation tracking."""

    def __init__(self, db_path: str | None = None):
        """Initialize database.

        Args:
            db_path: Path to SQLite database. Defaults to ~/.vantage/remediation.db
        """
        if db_path is None:
            db_dir = Path.home() / ".vantage"
            db_dir.mkdir(parents=True, exist_ok=True)
            db_path = str(db_dir / "remediation.db")

        self.db_path = db_path
        self._init_db()

    def _init_db(self) -> None:
        """Initialize database schema."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS remediation_items (
                    item_id TEXT PRIMARY KEY,
                    finding_id TEXT NOT NULL,
                    finding_type TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    project_name TEXT NOT NULL,
                    agent_id TEXT NOT NULL,
                    agent_name TEXT NOT NULL,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL,
                    status TEXT NOT NULL,
                    priority TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    due_date TEXT,
                    assignee TEXT,
                    resolution_notes TEXT,
                    resolved_at TEXT,
                    resolved_by TEXT,
                    scan_id TEXT,
                    file_path TEXT,
                    line_number INTEGER,
                    remediation_steps TEXT,
                    tags TEXT,
                    comments TEXT,
                    metadata TEXT
                )
            """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_project_status
                ON remediation_items(project_name, status)
            """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_finding_id
                ON remediation_items(finding_id)
            """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_assignee
                ON remediation_items(assignee)
            """
            )

            # Create history table for tracking status changes
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS remediation_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    item_id TEXT NOT NULL,
                    old_status TEXT,
                    new_status TEXT NOT NULL,
                    changed_by TEXT,
                    changed_at TEXT NOT NULL,
                    notes TEXT,
                    FOREIGN KEY (item_id) REFERENCES remediation_items(item_id)
                )
            """
            )
            conn.commit()

    def _generate_item_id(self, finding_id: str, project_name: str) -> str:
        """Generate unique item ID."""
        data = f"{finding_id}:{project_name}:{datetime.now().timestamp()}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]

    def create_item(
        self,
        finding: dict[str, Any],
        project_name: str,
        scan_id: str = "",
        assignee: str = "",
        due_date: str | None = None,
    ) -> RemediationItem:
        """Create a remediation item from a finding.

        Args:
            finding: Finding dictionary from scan
            project_name: Project name
            scan_id: Scan ID for correlation
            assignee: Person assigned to fix
            due_date: Due date for remediation

        Returns:
            Created RemediationItem
        """
        finding_id = finding.get("id", finding.get("finding_id", ""))
        if not finding_id:
            finding_id = self._generate_item_id(finding.get("type", "unknown"), project_name)

        item_id = self._generate_item_id(finding_id, project_name)
        now = datetime.now().isoformat()

        severity = finding.get("severity", "medium")
        priority = (
            RemediationPriority(severity)
            if severity in ["critical", "high", "medium", "low"]
            else RemediationPriority.MEDIUM
        )

        item = RemediationItem(
            item_id=item_id,
            finding_id=finding_id,
            finding_type=finding.get("type", "unknown"),
            severity=severity,
            project_name=project_name,
            agent_id=finding.get("agent_id", ""),
            agent_name=finding.get("agent_name", ""),
            title=finding.get("title", finding.get("description", "")[:100]),
            description=finding.get("description", ""),
            status=RemediationStatus.OPEN,
            priority=priority,
            created_at=now,
            updated_at=now,
            due_date=due_date,
            assignee=assignee,
            scan_id=scan_id,
            file_path=finding.get("file_path", finding.get("location", "")),
            line_number=finding.get("line_number"),
            remediation_steps=finding.get("remediation", []),
            tags=finding.get("tags", []),
            metadata=finding.get("metadata", {}),
        )

        self._save_item(item)
        self._record_history(item_id, None, RemediationStatus.OPEN, "system", "Item created")

        return item

    def _save_item(self, item: RemediationItem) -> None:
        """Save item to database."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO remediation_items (
                    item_id, finding_id, finding_type, severity, project_name,
                    agent_id, agent_name, title, description, status, priority,
                    created_at, updated_at, due_date, assignee, resolution_notes,
                    resolved_at, resolved_by, scan_id, file_path, line_number,
                    remediation_steps, tags, comments, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    item.item_id,
                    item.finding_id,
                    item.finding_type,
                    item.severity,
                    item.project_name,
                    item.agent_id,
                    item.agent_name,
                    item.title,
                    item.description,
                    item.status.value,
                    item.priority.value,
                    item.created_at,
                    item.updated_at,
                    item.due_date,
                    item.assignee,
                    item.resolution_notes,
                    item.resolved_at,
                    item.resolved_by,
                    item.scan_id,
                    item.file_path,
                    item.line_number,
                    json.dumps(item.remediation_steps),
                    json.dumps(item.tags),
                    json.dumps(item.comments),
                    json.dumps(item.metadata),
                ),
            )
            conn.commit()

    def _record_history(
        self,
        item_id: str,
        old_status: RemediationStatus | None,
        new_status: RemediationStatus,
        changed_by: str,
        notes: str = "",
    ) -> None:
        """Record status change in history."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                INSERT INTO remediation_history (
                    item_id, old_status, new_status, changed_by, changed_at, notes
                ) VALUES (?, ?, ?, ?, ?, ?)
            """,
                (
                    item_id,
                    old_status.value if old_status else None,
                    new_status.value,
                    changed_by,
                    datetime.now().isoformat(),
                    notes,
                ),
            )
            conn.commit()

    def get_item(self, item_id: str) -> RemediationItem | None:
        """Get a remediation item by ID."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute("SELECT * FROM remediation_items WHERE item_id = ?", (item_id,))
            row = cursor.fetchone()
            if not row:
                return None

            return self._row_to_item(row)

    def _row_to_item(self, row: sqlite3.Row) -> RemediationItem:
        """Convert database row to RemediationItem."""
        return RemediationItem(
            item_id=row["item_id"],
            finding_id=row["finding_id"],
            finding_type=row["finding_type"],
            severity=row["severity"],
            project_name=row["project_name"],
            agent_id=row["agent_id"],
            agent_name=row["agent_name"],
            title=row["title"],
            description=row["description"],
            status=RemediationStatus(row["status"]),
            priority=RemediationPriority(row["priority"]),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            due_date=row["due_date"],
            assignee=row["assignee"] or "",
            resolution_notes=row["resolution_notes"] or "",
            resolved_at=row["resolved_at"],
            resolved_by=row["resolved_by"] or "",
            scan_id=row["scan_id"] or "",
            file_path=row["file_path"] or "",
            line_number=row["line_number"],
            remediation_steps=json.loads(row["remediation_steps"] or "[]"),
            tags=json.loads(row["tags"] or "[]"),
            comments=json.loads(row["comments"] or "[]"),
            metadata=json.loads(row["metadata"] or "{}"),
        )

    def update_status(
        self,
        item_id: str,
        new_status: RemediationStatus,
        changed_by: str = "",
        notes: str = "",
    ) -> RemediationItem | None:
        """Update remediation item status.

        Args:
            item_id: Item ID
            new_status: New status
            changed_by: Who made the change
            notes: Notes about the change

        Returns:
            Updated RemediationItem or None
        """
        item = self.get_item(item_id)
        if not item:
            return None

        old_status = item.status
        item.status = new_status
        item.updated_at = datetime.now().isoformat()

        if new_status in [
            RemediationStatus.RESOLVED,
            RemediationStatus.ACCEPTED_RISK,
            RemediationStatus.FALSE_POSITIVE,
            RemediationStatus.WONT_FIX,
        ]:
            item.resolved_at = item.updated_at
            item.resolved_by = changed_by

        if notes:
            item.resolution_notes = notes

        self._save_item(item)
        self._record_history(item_id, old_status, new_status, changed_by, notes)

        return item

    def assign_item(
        self,
        item_id: str,
        assignee: str,
        due_date: str | None = None,
    ) -> RemediationItem | None:
        """Assign a remediation item.

        Args:
            item_id: Item ID
            assignee: Person to assign
            due_date: Optional due date

        Returns:
            Updated RemediationItem or None
        """
        item = self.get_item(item_id)
        if not item:
            return None

        item.assignee = assignee
        if due_date:
            item.due_date = due_date
        item.updated_at = datetime.now().isoformat()

        if item.status == RemediationStatus.OPEN:
            old_status = item.status
            item.status = RemediationStatus.IN_PROGRESS
            self._record_history(
                item_id, old_status, item.status, assignee, f"Assigned to {assignee}"
            )

        self._save_item(item)
        return item

    def add_comment(
        self,
        item_id: str,
        comment: str,
        author: str,
    ) -> RemediationItem | None:
        """Add a comment to an item.

        Args:
            item_id: Item ID
            comment: Comment text
            author: Comment author

        Returns:
            Updated RemediationItem or None
        """
        item = self.get_item(item_id)
        if not item:
            return None

        item.comments.append(
            {
                "text": comment,
                "author": author,
                "timestamp": datetime.now().isoformat(),
            }
        )
        item.updated_at = datetime.now().isoformat()

        self._save_item(item)
        return item

    def get_items(
        self,
        project_name: str | None = None,
        status: RemediationStatus | None = None,
        assignee: str | None = None,
        severity: str | None = None,
        limit: int = 100,
    ) -> list[RemediationItem]:
        """Get remediation items with filters.

        Args:
            project_name: Filter by project
            status: Filter by status
            assignee: Filter by assignee
            severity: Filter by severity
            limit: Maximum items to return

        Returns:
            List of RemediationItem objects
        """
        conditions = []
        params: list[Any] = []

        if project_name:
            conditions.append("project_name = ?")
            params.append(project_name)

        if status:
            conditions.append("status = ?")
            params.append(status.value)

        if assignee:
            conditions.append("assignee = ?")
            params.append(assignee)

        if severity:
            conditions.append("severity = ?")
            params.append(severity)

        where_clause = " AND ".join(conditions) if conditions else "1=1"
        params.append(limit)

        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                f"""
                SELECT * FROM remediation_items
                WHERE {where_clause}
                ORDER BY
                    CASE priority
                        WHEN 'critical' THEN 1
                        WHEN 'high' THEN 2
                        WHEN 'medium' THEN 3
                        WHEN 'low' THEN 4
                    END,
                    created_at DESC
                LIMIT ?
            """,
                params,
            )

            return [self._row_to_item(row) for row in cursor.fetchall()]

    def get_open_items(
        self,
        project_name: str | None = None,
        limit: int = 100,
    ) -> list[RemediationItem]:
        """Get all open remediation items.

        Args:
            project_name: Filter by project
            limit: Maximum items to return

        Returns:
            List of open RemediationItem objects
        """
        open_statuses = [
            RemediationStatus.OPEN.value,
            RemediationStatus.IN_PROGRESS.value,
            RemediationStatus.BLOCKED.value,
        ]
        placeholders = ",".join("?" * len(open_statuses))

        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row

            if project_name:
                cursor = conn.execute(
                    f"""
                    SELECT * FROM remediation_items
                    WHERE project_name = ? AND status IN ({placeholders})
                    ORDER BY
                        CASE priority
                            WHEN 'critical' THEN 1
                            WHEN 'high' THEN 2
                            WHEN 'medium' THEN 3
                            WHEN 'low' THEN 4
                        END,
                        created_at DESC
                    LIMIT ?
                """,
                    [project_name] + open_statuses + [limit],
                )
            else:
                cursor = conn.execute(
                    f"""
                    SELECT * FROM remediation_items
                    WHERE status IN ({placeholders})
                    ORDER BY
                        CASE priority
                            WHEN 'critical' THEN 1
                            WHEN 'high' THEN 2
                            WHEN 'medium' THEN 3
                            WHEN 'low' THEN 4
                        END,
                        created_at DESC
                    LIMIT ?
                """,
                    open_statuses + [limit],
                )

            return [self._row_to_item(row) for row in cursor.fetchall()]

    def get_overdue_items(
        self,
        project_name: str | None = None,
    ) -> list[RemediationItem]:
        """Get overdue remediation items.

        Args:
            project_name: Filter by project

        Returns:
            List of overdue RemediationItem objects
        """
        items = self.get_open_items(project_name, limit=1000)
        return [item for item in items if item.is_overdue]

    def get_summary(self, project_name: str | None = None) -> RemediationSummary:
        """Get remediation summary.

        Args:
            project_name: Filter by project

        Returns:
            RemediationSummary object
        """
        with sqlite3.connect(self.db_path) as conn:
            if project_name:
                base_query = "SELECT * FROM remediation_items WHERE project_name = ?"
                params: tuple = (project_name,)
            else:
                base_query = "SELECT * FROM remediation_items"
                params = ()

            conn.row_factory = sqlite3.Row
            cursor = conn.execute(base_query, params)
            items = [self._row_to_item(row) for row in cursor.fetchall()]

        # Calculate counts
        status_counts = {s: 0 for s in RemediationStatus}
        severity_counts: dict[str, int] = {}
        priority_counts: dict[str, int] = {}
        overdue_count = 0
        resolution_times: list[float] = []
        mttr_by_severity: dict[str, list[float]] = {
            "critical": [],
            "high": [],
            "medium": [],
            "low": [],
        }

        for item in items:
            status_counts[item.status] += 1
            severity_counts[item.severity] = severity_counts.get(item.severity, 0) + 1
            priority_counts[item.priority.value] = priority_counts.get(item.priority.value, 0) + 1

            if item.is_overdue:
                overdue_count += 1

            if item.is_resolved and item.resolved_at:
                created = datetime.fromisoformat(item.created_at)
                resolved = datetime.fromisoformat(item.resolved_at)
                days = (resolved - created).days
                resolution_times.append(days)
                if item.severity in mttr_by_severity:
                    mttr_by_severity[item.severity].append(days)

        avg_resolution = sum(resolution_times) / len(resolution_times) if resolution_times else 0

        def calc_mttr(times: list[float]) -> float:
            return sum(times) / len(times) if times else 0

        return RemediationSummary(
            project_name=project_name or "all",
            total_items=len(items),
            open_count=status_counts[RemediationStatus.OPEN],
            in_progress_count=status_counts[RemediationStatus.IN_PROGRESS],
            blocked_count=status_counts[RemediationStatus.BLOCKED],
            resolved_count=status_counts[RemediationStatus.RESOLVED],
            accepted_risk_count=status_counts[RemediationStatus.ACCEPTED_RISK],
            false_positive_count=status_counts[RemediationStatus.FALSE_POSITIVE],
            wont_fix_count=status_counts[RemediationStatus.WONT_FIX],
            by_severity=severity_counts,
            by_priority=priority_counts,
            overdue_count=overdue_count,
            avg_resolution_days=round(avg_resolution, 1),
            mttr_critical=round(calc_mttr(mttr_by_severity["critical"]), 1),
            mttr_high=round(calc_mttr(mttr_by_severity["high"]), 1),
            mttr_medium=round(calc_mttr(mttr_by_severity["medium"]), 1),
            mttr_low=round(calc_mttr(mttr_by_severity["low"]), 1),
        )

    def create_items_from_scan(
        self,
        scan_results: dict[str, Any],
        project_name: str,
        scan_id: str = "",
    ) -> list[RemediationItem]:
        """Create remediation items from scan findings.

        Args:
            scan_results: Full scan results
            project_name: Project name
            scan_id: Scan ID

        Returns:
            List of created RemediationItem objects
        """
        items = []
        findings = scan_results.get("findings", [])

        for finding in findings:
            # Check if item already exists for this finding
            finding_id = finding.get("id", finding.get("finding_id", ""))
            if finding_id:
                existing = self.get_item_by_finding(finding_id, project_name)
                if existing:
                    continue

            item = self.create_item(finding, project_name, scan_id)
            items.append(item)

        return items

    def get_item_by_finding(self, finding_id: str, project_name: str) -> RemediationItem | None:
        """Get remediation item by finding ID."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                """
                SELECT * FROM remediation_items
                WHERE finding_id = ? AND project_name = ?
                ORDER BY created_at DESC
                LIMIT 1
            """,
                (finding_id, project_name),
            )
            row = cursor.fetchone()
            if not row:
                return None
            return self._row_to_item(row)

    def get_item_history(self, item_id: str) -> list[dict[str, Any]]:
        """Get status change history for an item.

        Args:
            item_id: Item ID

        Returns:
            List of history entries
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                """
                SELECT * FROM remediation_history
                WHERE item_id = ?
                ORDER BY changed_at ASC
            """,
                (item_id,),
            )

            return [
                {
                    "old_status": row[2],
                    "new_status": row[3],
                    "changed_by": row[4],
                    "changed_at": row[5],
                    "notes": row[6],
                }
                for row in cursor.fetchall()
            ]


def create_remediation_item(
    finding: dict[str, Any],
    project_name: str,
    scan_id: str = "",
    db_path: str | None = None,
) -> RemediationItem:
    """Create a remediation item from a finding.

    Args:
        finding: Finding dictionary
        project_name: Project name
        scan_id: Scan ID
        db_path: Optional database path

    Returns:
        Created RemediationItem
    """
    tracker = RemediationTracker(db_path)
    return tracker.create_item(finding, project_name, scan_id)


def update_remediation_status(
    item_id: str,
    new_status: str,
    changed_by: str = "",
    notes: str = "",
    db_path: str | None = None,
) -> RemediationItem | None:
    """Update remediation item status.

    Args:
        item_id: Item ID
        new_status: New status string
        changed_by: Who made the change
        notes: Notes about the change
        db_path: Optional database path

    Returns:
        Updated RemediationItem or None
    """
    tracker = RemediationTracker(db_path)
    status = RemediationStatus(new_status)
    return tracker.update_status(item_id, status, changed_by, notes)


def get_remediation_summary(
    project_name: str | None = None,
    db_path: str | None = None,
) -> RemediationSummary:
    """Get remediation summary.

    Args:
        project_name: Filter by project
        db_path: Optional database path

    Returns:
        RemediationSummary object
    """
    tracker = RemediationTracker(db_path)
    return tracker.get_summary(project_name)
