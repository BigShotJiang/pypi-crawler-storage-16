"""
Simulation Report Generator (US-408).

Generates comprehensive reports from infection simulation results
including executive summary, entry point analysis, and recommendations.
"""

import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

from vantage_core.security.simulation.propagation import SimulationResult


class ReportFormat(str, Enum):
    """Supported report formats."""

    PDF = "pdf"
    HTML = "html"
    MARKDOWN = "markdown"
    JSON = "json"


@dataclass
class ExecutiveSummary:
    """
    Executive summary section of the report.

    Contains key metrics and top-level recommendations.
    """

    overall_risk_level: str  # critical, high, medium, low
    total_agents: int
    max_blast_radius: int
    max_blast_percentage: float
    fastest_full_infection: int  # steps
    avg_infection_rate: float
    critical_entry_points: list[str]
    top_recommendations: list[str]
    generated_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        return {
            "overall_risk_level": self.overall_risk_level,
            "total_agents": self.total_agents,
            "max_blast_radius": self.max_blast_radius,
            "max_blast_percentage": self.max_blast_percentage,
            "fastest_full_infection": self.fastest_full_infection,
            "avg_infection_rate": self.avg_infection_rate,
            "critical_entry_points": self.critical_entry_points,
            "top_recommendations": self.top_recommendations,
            "generated_at": self.generated_at.isoformat(),
        }


@dataclass
class EntryPointAnalysis:
    """
    Analysis of a specific entry point.

    Contains blast radius, timing, and recommendations.
    """

    entry_point: str
    risk_ranking: int
    blast_radius: int
    blast_percentage: float
    time_to_full_infection: int
    peak_infection: int
    peak_step: int
    critical_path: list[str]
    containment_points: list[str]
    recommended_mitigations: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "entry_point": self.entry_point,
            "risk_ranking": self.risk_ranking,
            "blast_radius": self.blast_radius,
            "blast_percentage": self.blast_percentage,
            "time_to_full_infection": self.time_to_full_infection,
            "peak_infection": self.peak_infection,
            "peak_step": self.peak_step,
            "critical_path": self.critical_path,
            "containment_points": self.containment_points,
            "recommended_mitigations": self.recommended_mitigations,
        }


@dataclass
class ContainmentRecommendation:
    """
    Recommendation for containment placement.

    Includes expected reduction and implementation effort.
    """

    agent_id: str
    placement_type: str  # input_validation, output_sanitization, isolation
    expected_reduction: int  # agents saved
    reduction_percentage: float
    implementation_effort: str  # low, medium, high
    description: str
    priority: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "placement_type": self.placement_type,
            "expected_reduction": self.expected_reduction,
            "reduction_percentage": self.reduction_percentage,
            "implementation_effort": self.implementation_effort,
            "description": self.description,
            "priority": self.priority,
        }


@dataclass
class Report:
    """
    Complete simulation report.

    Contains all sections and metadata for export.
    """

    title: str
    generated_at: datetime
    executive_summary: ExecutiveSummary
    entry_point_analyses: list[EntryPointAnalysis]
    containment_recommendations: list[ContainmentRecommendation]
    blast_radius_comparison: dict[str, int]
    raw_data: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "generated_at": self.generated_at.isoformat(),
            "executive_summary": self.executive_summary.to_dict(),
            "entry_point_analyses": [e.to_dict() for e in self.entry_point_analyses],
            "containment_recommendations": [c.to_dict() for c in self.containment_recommendations],
            "blast_radius_comparison": self.blast_radius_comparison,
            "metadata": self.metadata,
        }


class SimulationReportGenerator:
    """
    Generates comprehensive reports from simulation results.

    Supports multiple output formats and customization options.
    """

    def __init__(
        self,
        custom_branding: dict[str, str] | None = None,
    ):
        """
        Initialize the report generator.

        Args:
            custom_branding: Optional branding options (logo, colors, etc.)
        """
        self.custom_branding = custom_branding or {}

    def generate(
        self,
        simulation_results: list[SimulationResult],
        format: ReportFormat | str = ReportFormat.JSON,
        title: str = "Infection Simulation Report",
    ) -> Report:
        """
        Generate a complete report from simulation results.

        Args:
            simulation_results: List of simulation results
            format: Output format
            title: Report title

        Returns:
            Complete Report object
        """
        if isinstance(format, str):
            format = ReportFormat(format.lower())

        # Generate executive summary
        executive_summary = self.create_executive_summary(simulation_results)

        # Generate entry point analyses
        entry_point_analyses = []
        for i, result in enumerate(
            sorted(simulation_results, key=lambda r: r.blast_radius, reverse=True)
        ):
            analysis = self.create_entry_point_analysis(result, i + 1)
            entry_point_analyses.append(analysis)

        # Generate containment recommendations
        containment_recommendations = self._generate_containment_recommendations(simulation_results)

        # Create blast radius comparison
        blast_comparison = {r.entry_point: r.blast_radius for r in simulation_results}

        # Create report
        report = Report(
            title=title,
            generated_at=datetime.now(),
            executive_summary=executive_summary,
            entry_point_analyses=entry_point_analyses,
            containment_recommendations=containment_recommendations,
            blast_radius_comparison=blast_comparison,
            metadata={
                "format": format.value,
                "total_simulations": len(simulation_results),
                "branding": self.custom_branding,
            },
        )

        return report

    def create_executive_summary(
        self,
        results: list[SimulationResult],
    ) -> ExecutiveSummary:
        """
        Create executive summary from simulation results.

        Args:
            results: List of simulation results

        Returns:
            ExecutiveSummary object
        """
        if not results:
            return ExecutiveSummary(
                overall_risk_level="low",
                total_agents=0,
                max_blast_radius=0,
                max_blast_percentage=0.0,
                fastest_full_infection=0,
                avg_infection_rate=0.0,
                critical_entry_points=[],
                top_recommendations=["No simulations to analyze"],
            )

        # Calculate metrics
        total_agents = len(results[0].final_states)
        max_blast = max(r.blast_radius for r in results)
        max_blast_pct = (max_blast / total_agents * 100) if total_agents > 0 else 0
        fastest = min(r.total_steps for r in results)

        # Average infection rate
        avg_rate = sum(r.blast_radius / total_agents for r in results) / len(results)

        # Determine risk level
        if max_blast_pct >= 80:
            risk_level = "critical"
        elif max_blast_pct >= 60:
            risk_level = "high"
        elif max_blast_pct >= 40:
            risk_level = "medium"
        else:
            risk_level = "low"

        # Find critical entry points (>70% blast radius)
        critical_entries = [r.entry_point for r in results if r.blast_radius / total_agents >= 0.7]

        # Generate top recommendations
        recommendations = self._generate_top_recommendations(results, risk_level)

        return ExecutiveSummary(
            overall_risk_level=risk_level,
            total_agents=total_agents,
            max_blast_radius=max_blast,
            max_blast_percentage=max_blast_pct,
            fastest_full_infection=fastest,
            avg_infection_rate=avg_rate,
            critical_entry_points=critical_entries[:3],
            top_recommendations=recommendations[:3],
        )

    def create_entry_point_analysis(
        self,
        result: SimulationResult,
        ranking: int = 1,
    ) -> EntryPointAnalysis:
        """
        Create analysis for a specific entry point.

        Args:
            result: Simulation result for the entry point
            ranking: Risk ranking (1 = highest risk)

        Returns:
            EntryPointAnalysis object
        """
        total_agents = len(result.final_states)
        blast_pct = (result.blast_radius / total_agents * 100) if total_agents > 0 else 0

        # Find critical path (longest infection chain)
        critical_path = []
        if result.infection_paths:
            critical_path = max(result.infection_paths, key=len)

        # Generate mitigations based on analysis
        mitigations = self._generate_mitigations(result)

        return EntryPointAnalysis(
            entry_point=result.entry_point,
            risk_ranking=ranking,
            blast_radius=result.blast_radius,
            blast_percentage=blast_pct,
            time_to_full_infection=result.total_steps,
            peak_infection=result.peak_infection,
            peak_step=result.peak_step,
            critical_path=critical_path[:5],  # Top 5 agents in path
            containment_points=result.containment_points[:3],
            recommended_mitigations=mitigations,
        )

    def export(
        self,
        report: Report,
        format: ReportFormat | str = ReportFormat.JSON,
    ) -> bytes:
        """
        Export report in specified format.

        Args:
            report: Report to export
            format: Output format

        Returns:
            Exported report as bytes
        """
        if isinstance(format, str):
            format = ReportFormat(format.lower())

        if format == ReportFormat.JSON:
            return self._export_json(report)
        elif format == ReportFormat.HTML:
            return self._export_html(report)
        elif format == ReportFormat.MARKDOWN:
            return self._export_markdown(report)
        elif format == ReportFormat.PDF:
            return self._export_pdf(report)
        else:
            raise ValueError(f"Unsupported format: {format}")

    def _generate_top_recommendations(
        self,
        results: list[SimulationResult],
        risk_level: str,
    ) -> list[str]:
        """Generate top recommendations based on results."""
        recommendations = []

        if risk_level in ["critical", "high"]:
            recommendations.append("Implement input validation on all external-facing agents")
            recommendations.append("Add containment points at high-connectivity agents")
            recommendations.append("Reduce trust level propagation paths")

        # Find common containment points
        all_containment = []
        for r in results:
            all_containment.extend(r.containment_points)

        if all_containment:
            most_common = max(set(all_containment), key=all_containment.count)
            recommendations.append(
                f"Prioritize hardening agent '{most_common}' as key containment point"
            )

        # Check for fast infections
        fast_infections = [r for r in results if r.total_steps <= 3]
        if fast_infections:
            recommendations.append(
                "Address rapid propagation paths - some infections complete in 3 steps or less"
            )

        return recommendations[:5]

    def _generate_mitigations(self, result: SimulationResult) -> list[str]:
        """Generate specific mitigations for an entry point."""
        mitigations = []

        # Based on blast radius
        total = len(result.final_states)
        blast_pct = result.blast_radius / total if total > 0 else 0

        if blast_pct >= 0.8:
            mitigations.append(f"CRITICAL: Isolate {result.entry_point} from core agents")
            mitigations.append("Implement strict input validation and sanitization")

        if blast_pct >= 0.5:
            mitigations.append("Add output filtering to prevent prompt injection spread")
            mitigations.append("Implement rate limiting on agent communications")

        # Based on infection speed
        if result.total_steps <= 3:
            mitigations.append("Break direct connections to high-trust agents")

        # Based on containment points
        if result.containment_points:
            mitigations.append(
                f"Strengthen defenses at containment points: {', '.join(result.containment_points[:2])}"
            )

        return mitigations[:5]

    def _generate_containment_recommendations(
        self,
        results: list[SimulationResult],
    ) -> list[ContainmentRecommendation]:
        """Generate containment placement recommendations."""
        recommendations = []

        # Analyze which agents appear most in infection paths
        agent_occurrences: dict[str, int] = {}
        total_blast = sum(r.blast_radius for r in results)

        for result in results:
            for path in result.infection_paths:
                for agent in path[1:]:  # Exclude entry points
                    agent_occurrences[agent] = agent_occurrences.get(agent, 0) + 1

        # Sort by occurrence
        sorted_agents = sorted(agent_occurrences.items(), key=lambda x: x[1], reverse=True)

        # Create recommendations for top agents
        for priority, (agent_id, occurrences) in enumerate(sorted_agents[:5], 1):
            # Estimate reduction
            estimated_reduction = int(occurrences * 0.7)  # Conservative estimate
            reduction_pct = (estimated_reduction / total_blast * 100) if total_blast > 0 else 0

            # Determine effort based on occurrences
            if occurrences > 5:
                effort = "high"
                placement = "isolation"
            elif occurrences > 2:
                effort = "medium"
                placement = "input_validation"
            else:
                effort = "low"
                placement = "output_sanitization"

            recommendations.append(
                ContainmentRecommendation(
                    agent_id=agent_id,
                    placement_type=placement,
                    expected_reduction=estimated_reduction,
                    reduction_percentage=reduction_pct,
                    implementation_effort=effort,
                    description=f"Adding containment at {agent_id} would block {occurrences} infection paths",
                    priority=priority,
                )
            )

        return recommendations

    def _export_json(self, report: Report) -> bytes:
        """Export report as JSON."""
        return json.dumps(report.to_dict(), indent=2).encode("utf-8")

    def _export_html(self, report: Report) -> bytes:
        """Export report as HTML."""
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{report.title}</title>
    <style>
        body {{ font-family: 'Inter', -apple-system, sans-serif; margin: 40px; }}
        .header {{ border-bottom: 2px solid #1976D2; padding-bottom: 20px; }}
        .summary {{ background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0; }}
        .risk-critical {{ color: #D32F2F; }}
        .risk-high {{ color: #F57C00; }}
        .risk-medium {{ color: #FBC02D; }}
        .risk-low {{ color: #388E3C; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        th, td {{ border: 1px solid #ddd; padding: 12px; text-align: left; }}
        th {{ background: #1976D2; color: white; }}
        .recommendation {{ background: #E3F2FD; padding: 10px; margin: 5px 0; border-radius: 4px; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>{report.title}</h1>
        <p>Generated: {report.generated_at.strftime('%Y-%m-%d %H:%M:%S')}</p>
    </div>

    <div class="summary">
        <h2>Executive Summary</h2>
        <p><strong>Overall Risk Level:</strong>
            <span class="risk-{report.executive_summary.overall_risk_level}">
                {report.executive_summary.overall_risk_level.upper()}
            </span>
        </p>
        <p><strong>Total Agents:</strong> {report.executive_summary.total_agents}</p>
        <p><strong>Maximum Blast Radius:</strong> {report.executive_summary.max_blast_radius}
            ({report.executive_summary.max_blast_percentage:.1f}%)</p>
        <p><strong>Fastest Full Infection:</strong> {report.executive_summary.fastest_full_infection} steps</p>

        <h3>Top Recommendations</h3>
        {''.join(f'<div class="recommendation">{rec}</div>' for rec in report.executive_summary.top_recommendations)}
    </div>

    <h2>Entry Point Analysis</h2>
    <table>
        <tr>
            <th>Rank</th>
            <th>Entry Point</th>
            <th>Blast Radius</th>
            <th>Time to Full Infection</th>
            <th>Critical Path</th>
        </tr>
        {''.join(f'''<tr>
            <td>{e.risk_ranking}</td>
            <td>{e.entry_point}</td>
            <td>{e.blast_radius} ({e.blast_percentage:.1f}%)</td>
            <td>{e.time_to_full_infection} steps</td>
            <td>{' -> '.join(e.critical_path[:3])}</td>
        </tr>''' for e in report.entry_point_analyses)}
    </table>

    <h2>Containment Recommendations</h2>
    <table>
        <tr>
            <th>Priority</th>
            <th>Agent</th>
            <th>Type</th>
            <th>Expected Reduction</th>
            <th>Effort</th>
        </tr>
        {''.join(f'''<tr>
            <td>{c.priority}</td>
            <td>{c.agent_id}</td>
            <td>{c.placement_type}</td>
            <td>{c.expected_reduction} agents ({c.reduction_percentage:.1f}%)</td>
            <td>{c.implementation_effort}</td>
        </tr>''' for c in report.containment_recommendations)}
    </table>
</body>
</html>"""
        return html.encode("utf-8")

    def _export_markdown(self, report: Report) -> bytes:
        """Export report as Markdown."""
        md = f"""# {report.title}

Generated: {report.generated_at.strftime('%Y-%m-%d %H:%M:%S')}

## Executive Summary

- **Overall Risk Level**: {report.executive_summary.overall_risk_level.upper()}
- **Total Agents**: {report.executive_summary.total_agents}
- **Maximum Blast Radius**: {report.executive_summary.max_blast_radius} ({report.executive_summary.max_blast_percentage:.1f}%)
- **Fastest Full Infection**: {report.executive_summary.fastest_full_infection} steps
- **Average Infection Rate**: {report.executive_summary.avg_infection_rate:.1%}

### Critical Entry Points

{chr(10).join(f'- {ep}' for ep in report.executive_summary.critical_entry_points) or '- None identified'}

### Top Recommendations

{chr(10).join(f'{i+1}. {rec}' for i, rec in enumerate(report.executive_summary.top_recommendations))}

## Entry Point Analysis

| Rank | Entry Point | Blast Radius | Time to Full | Critical Path |
|------|-------------|--------------|--------------|---------------|
{chr(10).join(f'| {e.risk_ranking} | {e.entry_point} | {e.blast_radius} ({e.blast_percentage:.1f}%) | {e.time_to_full_infection} steps | {" -> ".join(e.critical_path[:3])} |' for e in report.entry_point_analyses)}

## Containment Recommendations

| Priority | Agent | Type | Expected Reduction | Effort |
|----------|-------|------|-------------------|--------|
{chr(10).join(f'| {c.priority} | {c.agent_id} | {c.placement_type} | {c.expected_reduction} ({c.reduction_percentage:.1f}%) | {c.implementation_effort} |' for c in report.containment_recommendations)}

## Detailed Entry Point Analyses

{chr(10).join(self._format_entry_point_md(e) for e in report.entry_point_analyses)}
"""
        return md.encode("utf-8")

    def _format_entry_point_md(self, analysis: EntryPointAnalysis) -> str:
        """Format entry point analysis as markdown section."""
        return f"""
### {analysis.entry_point}

- **Risk Ranking**: #{analysis.risk_ranking}
- **Blast Radius**: {analysis.blast_radius} agents ({analysis.blast_percentage:.1f}%)
- **Peak Infection**: {analysis.peak_infection} at step {analysis.peak_step}

**Recommended Mitigations:**

{chr(10).join(f'- {m}' for m in analysis.recommended_mitigations)}
"""

    def _export_pdf(self, report: Report) -> bytes:
        """Export report as PDF (requires WeasyPrint)."""
        # Generate HTML first
        html_content = self._export_html(report)

        try:
            from weasyprint import HTML

            pdf_bytes = HTML(string=html_content.decode("utf-8")).write_pdf()
            return pdf_bytes
        except ImportError:
            # Fallback: return HTML with PDF note
            return (
                b"PDF generation requires WeasyPrint. Install with: pip install weasyprint\n\n"
                + html_content
            )


def generate_simulation_report(
    results: list[SimulationResult],
    format: str = "json",
    title: str = "Infection Simulation Report",
) -> bytes:
    """
    Convenience function to generate a simulation report.

    Args:
        results: List of simulation results
        format: Output format (json, html, markdown, pdf)
        title: Report title

    Returns:
        Report content as bytes
    """
    generator = SimulationReportGenerator()
    report = generator.generate(results, format, title)
    return generator.export(report, format)
