"""
Core Scanner - Main scanning orchestrator.

Coordinates framework detection, topology building, and vulnerability scanning.
"""

import ast
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    FindingType,
    Framework,
    ScanResult,
    SecurityFinding,
    Severity,
)
from vantage_core.providers import BasicPayloadProvider, PatternDetector
from vantage_core.scoring.engine import ScoringEngine
from vantage_core.topology.graph import AgentGraph


@dataclass
class ScanConfig:
    """Configuration for scanning."""

    target_path: Path = field(default_factory=lambda: Path("."))
    include_patterns: list[str] = field(default_factory=lambda: ["**/*.py"])
    exclude_patterns: list[str] = field(
        default_factory=lambda: [
            "**/test*",
            "**/__pycache__",
            "**/venv",
            "**/.venv",
            "**/node_modules",
        ]
    )
    max_file_size: int = 1_000_000  # 1MB
    enable_pattern_detection: bool = True
    max_payloads: int = 33  # OSS limit


# Framework detection patterns
FRAMEWORK_PATTERNS: dict[Framework, list[str]] = {
    Framework.CREWAI: ["from crewai", "import crewai", "Agent(", "Crew("],
    Framework.LANGCHAIN: [
        "from langchain",
        "import langchain",
        "ChatOpenAI",
        "LLMChain",
    ],
    Framework.LANGGRAPH: ["from langgraph", "import langgraph", "StateGraph"],
    Framework.AUTOGEN: [
        "from autogen",
        "import autogen",
        "AssistantAgent",
        "UserProxyAgent",
    ],
    Framework.PYDANTICAI: ["from pydantic_ai", "import pydantic_ai", "Agent("],
    Framework.OPENAI_SWARM: ["from swarm", "import swarm", "Swarm("],
    Framework.LLAMAINDEX: ["from llama_index", "import llama_index"],
    Framework.SEMANTIC_KERNEL: ["from semantic_kernel", "import semantic_kernel"],
    Framework.DSPY: ["from dspy", "import dspy"],
    Framework.SMOLAGENTS: ["from smolagents", "import smolagents"],
    Framework.METAGPT: ["from metagpt", "import metagpt"],
    Framework.AGNO: ["from agno", "import agno"],
    Framework.GOOGLE_ADK: ["from google.adk", "import google.adk"],
    Framework.BROWSERUSE: ["from browser_use", "import browser_use"],
    Framework.OPENHANDS: ["from openhands", "import openhands"],
    Framework.SKYVERN: ["from skyvern", "import skyvern"],
    Framework.DIFY: ["from dify", "import dify"],
}


class CoreScanner:
    """
    Core security scanner for multi-agent AI systems.

    This is the OSS scanner that provides:
    - Framework detection (17+ frameworks)
    - Agent topology building
    - Pattern-based vulnerability detection
    - ATSS security scoring
    """

    def __init__(
        self,
        payload_provider: Any | None = None,
        detector: Any | None = None,
    ) -> None:
        """
        Initialize scanner.

        Args:
            payload_provider: Custom payload provider (default: BasicPayloadProvider)
            detector: Custom detector (default: PatternDetector)
        """
        self.payload_provider = payload_provider or BasicPayloadProvider()
        self.detector = detector or PatternDetector()
        self.scoring_engine = ScoringEngine()

    def scan(self, config: ScanConfig | None = None) -> ScanResult:
        """
        Run a security scan.

        Args:
            config: Scan configuration

        Returns:
            ScanResult with findings and score
        """
        config = config or ScanConfig()
        start_time = time.time()

        # Initialize result
        result = ScanResult(
            scan_id=str(uuid.uuid4()),
            timestamp=datetime.utcnow(),
            target_path=str(config.target_path),
        )

        # Find Python files
        files = self._find_files(config)
        result.files_scanned = len(files)

        # Detect frameworks and agents
        agents, connections, frameworks = self._detect_agents(files, config)
        result.agents = agents
        result.connections = connections
        result.frameworks_detected = [f.value for f in frameworks]

        # Build topology graph
        graph = AgentGraph()
        for agent in agents:
            graph.add_agent(agent)
        for conn in connections:
            try:
                graph.add_connection(conn)
            except ValueError as e:
                result.errors.append(str(e))

        # Detect vulnerabilities
        findings = self._detect_vulnerabilities(agents, files, config)
        result.findings = findings

        # Calculate score
        score_result = self.scoring_engine.calculate_score(
            findings=findings,
            graph=graph,
            agents=agents,
            connections=connections,
        )
        result.score = score_result.score
        result.grade = score_result.grade

        # Calculate duration
        result.duration_ms = int((time.time() - start_time) * 1000)

        return result

    def _find_files(self, config: ScanConfig) -> list[Path]:
        """Find files to scan."""
        files = []
        target = config.target_path

        if not target.exists():
            return files

        if target.is_file():
            return [target]

        for pattern in config.include_patterns:
            for path in target.glob(pattern):
                if path.is_file():
                    # Check exclusions
                    excluded = False
                    for exclude in config.exclude_patterns:
                        if path.match(exclude):
                            excluded = True
                            break
                    if not excluded:
                        # Check file size
                        if path.stat().st_size <= config.max_file_size:
                            files.append(path)

        return files

    def _detect_agents(
        self,
        files: list[Path],
        config: ScanConfig,
    ) -> tuple[list[DetectedAgent], list[DetectedConnection], set[Framework]]:
        """Detect agents and their connections."""
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        frameworks: set[Framework] = set()

        for file_path in files:
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")

                # Detect frameworks
                detected_frameworks = self._detect_frameworks(content)
                frameworks.update(detected_frameworks)

                # Parse AST and extract agents
                file_agents = self._extract_agents_from_file(
                    file_path, content, detected_frameworks
                )
                agents.extend(file_agents)

            except Exception:
                # Skip files we can't read
                continue

        # Detect connections between agents
        connections = self._detect_connections(agents)

        return agents, connections, frameworks

    def _detect_frameworks(self, content: str) -> set[Framework]:
        """Detect which frameworks are used in the content."""
        detected = set()
        for framework, patterns in FRAMEWORK_PATTERNS.items():
            for pattern in patterns:
                if pattern in content:
                    detected.add(framework)
                    break
        return detected

    def _extract_agents_from_file(
        self,
        file_path: Path,
        content: str,
        frameworks: set[Framework],
    ) -> list[DetectedAgent]:
        """Extract agent definitions from a file."""
        agents = []

        try:
            tree = ast.parse(content)
        except SyntaxError:
            return agents

        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                agent = self._extract_agent_from_call(node, file_path, frameworks)
                if agent:
                    agents.append(agent)
            elif isinstance(node, ast.Assign):
                # Check for agent assignments
                if isinstance(node.value, ast.Call):
                    agent = self._extract_agent_from_call(node.value, file_path, frameworks)
                    if agent and node.targets:
                        # Use variable name as agent name
                        if isinstance(node.targets[0], ast.Name):
                            agent.name = node.targets[0].id
                            agents.append(agent)

        return agents

    def _extract_agent_from_call(
        self,
        node: ast.Call,
        file_path: Path,
        frameworks: set[Framework],
    ) -> DetectedAgent | None:
        """Extract agent from a function call AST node."""
        # Get function name
        func_name = ""
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = node.func.attr

        # Check if this is an agent creation call
        agent_patterns = ["Agent", "AssistantAgent", "UserProxyAgent", "Swarm"]
        if func_name not in agent_patterns:
            return None

        # Determine framework
        framework = Framework.UNKNOWN
        if Framework.CREWAI in frameworks:
            framework = Framework.CREWAI
        elif Framework.AUTOGEN in frameworks:
            framework = Framework.AUTOGEN
        elif Framework.LANGCHAIN in frameworks:
            framework = Framework.LANGCHAIN

        # Extract agent details from keywords
        name = f"agent_{node.lineno}"
        system_prompt = None
        tools: list[str] = []

        for keyword in node.keywords:
            if keyword.arg in ["name", "role"]:
                if isinstance(keyword.value, ast.Constant):
                    name = str(keyword.value.value)
            elif keyword.arg in ["system_prompt", "instructions", "system_message"]:
                if isinstance(keyword.value, ast.Constant):
                    system_prompt = str(keyword.value.value)
            elif keyword.arg == "tools":
                if isinstance(keyword.value, ast.List):
                    for elt in keyword.value.elts:
                        if isinstance(elt, ast.Name):
                            tools.append(elt.id)

        return DetectedAgent(
            id=f"{file_path.stem}_{node.lineno}",
            name=name,
            framework=framework,
            file_path=str(file_path),
            line_number=node.lineno,
            system_prompt=system_prompt,
            tools=tools,
        )

    def _detect_connections(
        self,
        agents: list[DetectedAgent],
    ) -> list[DetectedConnection]:
        """Detect connections between agents."""
        connections = []

        # Simple heuristic: agents in the same file may be connected
        agents_by_file: dict[str, list[DetectedAgent]] = {}
        for agent in agents:
            if agent.file_path not in agents_by_file:
                agents_by_file[agent.file_path] = []
            agents_by_file[agent.file_path].append(agent)

        for file_path, file_agents in agents_by_file.items():
            if len(file_agents) > 1:
                # Create sequential connections between agents in same file
                for i in range(len(file_agents) - 1):
                    connections.append(
                        DetectedConnection(
                            source_id=file_agents[i].id,
                            target_id=file_agents[i + 1].id,
                            connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                            confidence=0.5,
                            confidence_level=ConnectionConfidence.INFERRED,
                            evidence=[f"Agents defined in same file: {file_path}"],
                        )
                    )

        return connections

    def _detect_vulnerabilities(
        self,
        agents: list[DetectedAgent],
        files: list[Path],
        config: ScanConfig,
    ) -> list[SecurityFinding]:
        """Detect security vulnerabilities."""
        findings: list[SecurityFinding] = []

        # Check agent system prompts
        for agent in agents:
            if agent.system_prompt:
                # Check for injection vulnerabilities in prompts
                result = self.detector.classify(agent.system_prompt)
                if result.is_injection:
                    findings.append(
                        SecurityFinding(
                            type=FindingType.PROMPT_INJECTION,
                            severity=Severity.HIGH,
                            title=f"Potential injection in {agent.name} system prompt",
                            description=result.explanation or "Injection pattern detected",
                            file_path=agent.file_path,
                            line_number=agent.line_number,
                            agent_id=agent.id,
                            confidence=result.confidence,
                        )
                    )

                # Check for hardcoded secrets
                secret_patterns = ["api_key", "secret", "password", "token"]
                prompt_lower = agent.system_prompt.lower()
                for pattern in secret_patterns:
                    if pattern in prompt_lower:
                        findings.append(
                            SecurityFinding(
                                type=FindingType.HARDCODED_SECRET,
                                severity=Severity.CRITICAL,
                                title=f"Potential hardcoded secret in {agent.name}",
                                description=f"Found '{pattern}' in system prompt",
                                file_path=agent.file_path,
                                line_number=agent.line_number,
                                agent_id=agent.id,
                                remediation="Move secrets to environment variables",
                            )
                        )

        # Check for excessive tool permissions
        for agent in agents:
            dangerous_tools = ["execute", "shell", "system", "eval", "file_write"]
            dangerous_found = [
                t for t in agent.tools if any(d in t.lower() for d in dangerous_tools)
            ]
            if dangerous_found:
                findings.append(
                    SecurityFinding(
                        type=FindingType.EXCESSIVE_PERMISSIONS,
                        severity=Severity.HIGH,
                        title=f"Dangerous tools in {agent.name}",
                        description=f"Agent has access to: {', '.join(dangerous_found)}",
                        file_path=agent.file_path,
                        line_number=agent.line_number,
                        agent_id=agent.id,
                        remediation="Review tool permissions and implement least privilege",
                    )
                )

        return findings

    def get_supported_frameworks(self) -> list[str]:
        """Get list of supported frameworks."""
        return [f.value for f in Framework if f != Framework.UNKNOWN]
