"""Framework scanners for multi-agent system detection.

This module provides scanners for detecting agents in various AI frameworks.
"""

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
)

# Register all scanners
from vantage_core.scanners import register_scanners  # noqa: F401

# Framework-specific scanners
from vantage_core.scanners.agno_scanner import AgnoScanner
from vantage_core.scanners.autogen_scanner import AutoGenScanner
from vantage_core.scanners.base import (
    BaseScanner,
    ScanResult,
)
from vantage_core.scanners.browseruse_scanner import BrowserUseScanner
from vantage_core.scanners.connection_detector import (
    MultiLevelConnectionDetector as ConnectionDetector,
)
from vantage_core.scanners.crewai_scanner import CrewAIScanner
from vantage_core.scanners.dify_scanner import DifyScanner
from vantage_core.scanners.dspy_scanner import DSPyScanner
from vantage_core.scanners.google_adk_scanner import GoogleADKScanner
from vantage_core.scanners.langchain_scanner import LangChainScanner
from vantage_core.scanners.langgraph_scanner import LangGraphScanner
from vantage_core.scanners.llamaindex_scanner import LlamaIndexScanner
from vantage_core.scanners.metagpt_scanner import MetaGPTScanner
from vantage_core.scanners.mixins import ASTExtractionMixin, ConfigFileMixin
from vantage_core.scanners.openai_scanner import OpenAIScanner
from vantage_core.scanners.openhands_scanner import OpenHandsScanner
from vantage_core.scanners.pydanticai_scanner import PydanticAIScanner
from vantage_core.scanners.registry import ScannerMetadata, ScannerRegistry
from vantage_core.scanners.semantic_kernel_scanner import SemanticKernelScanner
from vantage_core.scanners.skyvern_scanner import SkyvernScanner
from vantage_core.scanners.smolagents_scanner import SmolagentsScanner
from vantage_core.scanners.universal_scanner import UniversalScanner

__all__ = [
    # Base classes
    "BaseScanner",
    "ConnectionType",
    "ConnectionConfidence",
    "DetectedAgent",
    "DetectedConnection",
    "ScanResult",
    "ConnectionDetector",
    "ASTExtractionMixin",
    "ConfigFileMixin",
    "ScannerMetadata",
    "ScannerRegistry",
    "UniversalScanner",
    # Framework scanners
    "AgnoScanner",
    "AutoGenScanner",
    "BrowserUseScanner",
    "CrewAIScanner",
    "DifyScanner",
    "DSPyScanner",
    "GoogleADKScanner",
    "LangChainScanner",
    "LangGraphScanner",
    "LlamaIndexScanner",
    "MetaGPTScanner",
    "OpenAIScanner",
    "OpenHandsScanner",
    "PydanticAIScanner",
    "SemanticKernelScanner",
    "SkyvernScanner",
    "SmolagentsScanner",
]
