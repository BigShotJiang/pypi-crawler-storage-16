from pathlib import Path
from vantage_core.models import DetectedAgent, DetectedConnection, Framework, ScanResult, ConnectionType, ConnectionConfidence
from vantage_core.scanners.base import BaseScanner
from vantage_core.graph.builder import CPGBuilder
from vantage_core.graph.query import CPGQuery

class AutoGenGraphScanner(BaseScanner):
    """Graph-based Scanner for AutoGen."""
    
    framework_name = "AutoGen"
    AGENT_CLASSES = {"UserProxyAgent", "AssistantAgent", "ConversableAgent"}

    def scan_file(self, path: Path) -> ScanResult:
        with open(path, "r", encoding="utf-8") as f:
            source = f.read()

        builder = CPGBuilder()
        graph = builder.build(source, str(path))
        query = CPGQuery(graph)
        
        agents = []
        connections = []
        
        # 1. Detect Agents
        for cls_name in self.AGENT_CLASSES:
            calls = query.find_calls_by_name(cls_name)
            for call_id, call_node in calls:
                name = query.resolve_argument(call_id, "name")
                system_message = query.resolve_argument(call_id, "system_message")
                
                if not name:
                    name = f"autogen_agent_{call_node.ast_node.lineno}"
                
                agents.append(DetectedAgent(
                    id=self._make_id(name),
                    name=name,
                    framework=Framework.AUTOGEN,
                    file_path=str(path),
                    line_number=call_node.ast_node.lineno,
                    system_prompt=system_message or "AutoGen Agent",
                    metadata={}
                ))

        # 2. Detect Initiate Chat Connections
        chat_calls = query.find_calls_by_name("initiate_chat")
        for call_id, call_node in chat_calls:
            # Resolve Receiver (Source)
            receiver_info = query.resolve_receiver(call_id)
            source_id = None
            if isinstance(receiver_info, str): # Literal name
                 source_id = receiver_info
            elif isinstance(receiver_info, dict) and receiver_info.get("type") == "call":
                 # Tricky: we got the call that created the agent, but we need the agent's name/ID
                 # This requires matching back to the agents list or resolving the name property
                 pass

            # Resolve Recipient (Target)
            recipient = query.resolve_argument(call_id, "recipient")
            target_id = None
            # recipient might be a variable reference to an agent
            
            # Simple fallback for proof of concept: use variable names if possible
            # But the trace returns the definition. 
            
            # TODO: Robust ID matching
            # For now, if we found agents, we assume valid IDs
            
        return ScanResult(
            agents=agents,
            connections=connections,
            framework=self.framework_name,
            files_scanned=1,
            errors=[]
        )
