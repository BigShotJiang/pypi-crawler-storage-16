"""Scanner for CrewAI agent definitions."""

from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import Any

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult

logger = logging.getLogger(__name__)


class CrewAIScanner(BaseScanner):
    """Scanner for detecting CrewAI agent definitions.

    Detects agents defined via:
    - Agent() constructor calls
    - @agent decorator methods
    - YAML config files (agents.yaml)
    """

    framework_name = "CrewAI"

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a Python file for CrewAI agent definitions."""
        agents_by_line: dict[int, DetectedAgent] = {}
        connections: list[DetectedConnection] = []

        try:
            tree = self._parse_python_file(path)
        except SyntaxError:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=["Syntax Error"],
            )

        # Track task variable names to agent mappings
        task_vars: dict[str, str] = {}  # task_var_name -> task_name

        # First pass: collect agents (calls and classes)
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                # Check if this call resolves to an Agent class
                if self._is_agent_creation(node, path):
                    agent = self._parse_agent_call(node, path)
                    if agent:
                        agents_by_line[agent.line_number] = agent

            # Support for Subclassing Pattern: class MyAgent(Agent):
            if isinstance(node, ast.ClassDef):
                agent = self._parse_agent_class(node, path)
                if agent:
                    agents_by_line[agent.line_number] = agent

        agents = list(agents_by_line.values())

        # Second pass: parse Task() calls for context dependencies
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                # Track task assignments: task_var = Task(...)
                if isinstance(node.value, ast.Call):
                    func_name = self._get_call_name(node.value)
                    if func_name == "Task":
                        for target in node.targets:
                            if isinstance(target, ast.Name):
                                task_vars[target.id] = target.id

            if isinstance(node, ast.Call):
                # Parse Task() for context dependencies
                task_conns = self._parse_task_context(node, task_vars)
                connections.extend(task_conns)

                # Look for Crew() calls to extract task flow
                conns = self._parse_crew_call(node, agents)
                connections.extend(conns)

            # Check for CrewBase/Flow style classes with @agent decorators
            if isinstance(node, ast.ClassDef):
                class_agents = self._parse_class_methods_for_agents(node, path)
                for agent in class_agents:
                    agents_by_line[agent.line_number] = agent
        
        agents = list(agents_by_line.values())

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=[],
        )

    def _parse_class_methods_for_agents(
        self, node: ast.ClassDef, path: Path
    ) -> list[DetectedAgent]:
        """Parse methods decorated with @agent in a class."""
        agents: list[DetectedAgent] = []
        class_scope: dict[str, Any] = {}

        # 1. Build class scope (assignments)
        for child in node.body:
            if isinstance(child, ast.Assign):
                for target in child.targets:
                    if isinstance(target, ast.Name):
                        # Capture value info
                        val = child.value
                        if isinstance(val, ast.Call):
                            # Special handling for LLM init to capture model
                            call_name = self._get_call_name(val)
                            model_name = None
                            for kw in val.keywords:
                                if kw.arg == "model":
                                    model_name = self._extract_value(kw.value)
                            
                            class_scope[target.id] = {
                                "type": "call",
                                "name": call_name,
                                "model": model_name
                            }
                        else:
                            class_scope[target.id] = self._extract_value(val)

        # 2. Find @agent methods
        for child in node.body:
            if isinstance(child, ast.FunctionDef):
                is_agent = False
                for deco in child.decorator_list:
                    if isinstance(deco, ast.Name) and deco.id == "agent":
                        is_agent = True
                    elif isinstance(deco, ast.Call) and self._get_call_name(deco) == "agent":
                        is_agent = True
                
                if not is_agent:
                    continue
                
                # 3. Find Agent(...) call inside method
                for sub_node in ast.walk(child):
                    if isinstance(sub_node, ast.Call):
                        if self._is_agent_creation(sub_node, path):
                            agent = self._parse_agent_call(sub_node, path)
                            if agent:
                                # Use function name as default role/name if missing
                                if not agent.name or agent.name.lower() in ["agent", "crewai agent"]:
                                    agent.name = self._format_display_name(child.name)
                                    agent.id = self._make_id(child.name)                                
                                
                                # 4. Resolve self.variable references
                                if agent.metadata:
                                    for k, v in list(agent.metadata.items()):
                                        if isinstance(v, str) and v.startswith("self."):
                                            var_name = v.split(".", 1)[1]
                                            if var_name in class_scope:
                                                resolved = class_scope[var_name]
                                                # If it's the LLM structure we captured
                                                if isinstance(resolved, dict) and "model" in resolved:
                                                    if k == "llm":
                                                        agent.metadata["llm_model"] = resolved["model"]
                                                        agent.metadata["llm_provider"] = resolved["name"]
                                                else:
                                                    agent.metadata[k] = resolved
                                
                                agents.append(agent)
                                # Stop after finding the first Agent return
                                break
        
        return agents

    def _is_agent_creation(self, node: ast.Call, path: Path) -> bool:
        """Check if a call instantiates a CrewAI Agent (directly or via alias)."""
        func_name = self._get_call_name(node)

        # 1. Direct Match
        if func_name == "Agent":
            return True

        # 2. Alias Resolution (e.g. Bot = Agent)
        if hasattr(self, "symbol_table") and self.symbol_table:
            resolved = self.symbol_table.resolve_symbol(str(path), func_name)
            if resolved:
                # Check if resolved definition is an import of Agent
                if resolved.definition_type == "import":
                    import_info = resolved.value
                    if import_info.get("original_name") == "Agent":
                        return True
                # Check if assignment to Agent
                if resolved.definition_type == "assignment":
                    # Value might be "Agent" or "crewai.Agent"
                    val_str = ""
                    try:
                        if isinstance(resolved.value, ast.AST):
                            val_str = ast.unparse(resolved.value)
                        else:
                            val_str = str(resolved.value)
                    except Exception:
                        val_str = str(resolved.value)

                    if "Agent" in val_str:  # Simplified check
                        return True

        return False

    def _parse_agent_class(self, node: ast.ClassDef, path: Path) -> DetectedAgent | None:
        """Parse a class definition inheriting from Agent."""
        # Check inheritance
        is_agent_subclass = False
        for base in node.bases:
            if isinstance(base, ast.Name) and base.id == "Agent":
                is_agent_subclass = True
            elif isinstance(base, ast.Attribute) and base.attr == "Agent":
                is_agent_subclass = True

        if not is_agent_subclass:
            return None

        # Attempt to extract default attributes from __init__
        role = node.name  # Default to class name
        goal = ""
        backstory = ""
        tools = []

        # Find __init__
        init_method = next(
            (n for n in node.body if isinstance(n, ast.FunctionDef) and n.name == "__init__"),
            None,
        )
        if init_method:
            # Look for super().__init__(role=..., ...) call
            for sub_node in ast.walk(init_method):
                if isinstance(sub_node, ast.Call):
                    # Check for super().__init__
                    if (
                        isinstance(sub_node.func, ast.Attribute)
                        and sub_node.func.attr == "__init__"
                    ):
                        # Extract kwargs
                        for keyword in sub_node.keywords:
                            val = self._extract_value(keyword.value)
                            if keyword.arg == "role":
                                role = val
                            if keyword.arg == "goal":
                                goal = val
                            if keyword.arg == "backstory":
                                backstory = val
                            if keyword.arg == "tools" and isinstance(keyword.value, ast.List):
                                for elt in keyword.value.elts:
                                    if isinstance(elt, ast.Name):
                                        tools.append(elt.id)
                                    elif isinstance(elt, ast.Call):
                                        name = self._get_call_name(elt)
                                        if name:
                                            tools.append(name)

        system_prompt = f"Role: {role}\n\nGoal: {goal}\n\nBackstory: {backstory}"

        return DetectedAgent(
            id=self._make_id(node.name),
            name=node.name,  # Use class name as agent name
            framework=Framework.CREWAI,
            file_path=str(path),
            line_number=node.lineno,
            system_prompt=system_prompt,
            tools=tools,
            metadata={"type": "subclass"},
        )

    def _parse_task_context(
        self, node: ast.Call, task_vars: dict[str, str]
    ) -> list[DetectedConnection]:
        """Parse Task() call for context dependencies."""
        connections: list[DetectedConnection] = []

        func_name = self._get_call_name(node)
        if func_name != "Task":
            return connections

        # Get task name/description
        task_name = None
        for keyword in node.keywords:
            if keyword.arg == "description":
                task_name = self._extract_value(keyword.value)
                break

        if not task_name:
            task_name = "unknown_task"

        task_id = self._make_id(task_name[:50])

        # Look for context= argument
        for keyword in node.keywords:
            if keyword.arg == "context" and isinstance(keyword.value, ast.List):
                for elt in keyword.value.elts:
                    if isinstance(elt, ast.Name):
                        # This task depends on the context task
                        source_task = elt.id
                        connections.append(
                            DetectedConnection(
                                source_id=self._make_id(source_task),
                                target_id=task_id,
                                connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                                confidence=0.95,
                                confidence_level=ConnectionConfidence.FRAMEWORK,
                                evidence=[f"CrewAI Task context=[{source_task}]"],
                            )
                        )

        return connections

    def _scan_yaml_file(self, path: Path) -> ScanResult:
        """Scan CrewAI YAML config for agent definitions."""
        agents: list[DetectedAgent] = []

        # Only process agents.yaml or similar
        if "agent" not in path.stem.lower():
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=0,
                errors=[],
            )

        try:
            import yaml

            with open(path) as f:
                config = yaml.safe_load(f)

            if not isinstance(config, dict):
                return ScanResult(
                    agents=[],
                    connections=[],
                    entry_points=[],
                    exit_points=[],
                    framework=self.framework_name,
                    files_scanned=1,
                    errors=[],
                )

            for agent_id, agent_config in config.items():
                if not isinstance(agent_config, dict):
                    continue

                # Extract system prompt from role + goal + backstory
                role = agent_config.get("role", "")
                goal = agent_config.get("goal", "")
                backstory = agent_config.get("backstory", "")

                system_prompt = f"Role: {role}\n\nGoal: {goal}\n\nBackstory: {backstory}"
                
                # Use YAML key (agent_id) as fallback name if role is generic or missing
                name = role
                if not name or name == "CrewAI Agent":
                    name = self._format_display_name(agent_id)

                agent = DetectedAgent(
                    id=agent_id,
                    name=name,
                    framework=Framework.CREWAI,
                    file_path=str(path),
                    line_number=0,
                    system_prompt=system_prompt,
                    metadata=agent_config,
                )
                agents.append(agent)

        except ImportError:
            logger.warning("PyYAML not installed, skipping YAML config")
        except Exception as e:
            logger.warning(f"Error parsing YAML {path}: {e}")

        return ScanResult(
            agents=agents,
            connections=[],
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=[],
        )

    def _parse_agent_call(self, node: ast.Call, path: Path) -> DetectedAgent | None:
        """Parse an Agent() constructor call."""
        # Extract keyword arguments
        kwargs: dict[str, Any] = {}
        for keyword in node.keywords:
            if keyword.arg:
                value = self._extract_value(keyword.value)
                if value is not None:
                    kwargs[keyword.arg] = value
            elif keyword.arg is None:
                # Handle **kwargs unpacking (e.g. Agent(**config))
                if (
                    hasattr(self, "symbol_table")
                    and self.symbol_table
                    and isinstance(keyword.value, ast.Name)
                ):
                    config_var = keyword.value.id
                    resolved = self.symbol_table.resolve_symbol(str(path), config_var)

                    if resolved and resolved.definition_type == "assignment":
                        # Try to parse the dict definition
                        dict_node = resolved.value
                        if isinstance(dict_node, ast.Dict):
                            extracted = self._extract_value(dict_node)
                            if isinstance(extracted, dict):
                                kwargs.update(extracted)

        # Need at least role or name or config
        if not kwargs.get("role") and not kwargs.get("name") and not kwargs.get("config"):
            return None

        # Build system prompt from CrewAI components
        role = kwargs.get("role", "")
        goal = kwargs.get("goal", "")
        backstory = kwargs.get("backstory", "")

        # Check for explicit system_template
        system_template = kwargs.get("system_template", "")

        if system_template:
            system_prompt = system_template
        else:
            system_prompt = f"Role: {role}\n\nGoal: {goal}\n\nBackstory: {backstory}"

        # Generate ID from role
        agent_id = self._make_id(role or kwargs.get("name", "agent"))

        # Extract tools
        tools = []

        # Check explicit tools kwarg
        tools_val = kwargs.get("tools")
        if isinstance(tools_val, list):
            for t in tools_val:
                tools.append(str(t))

        # Check AST tools kwarg
        for keyword in node.keywords:
            if keyword.arg == "tools" and isinstance(keyword.value, ast.List):
                for elt in keyword.value.elts:
                    # Handle ToolClass() instantiation
                    if isinstance(elt, ast.Call):
                        tool_name = self._get_call_name(elt)
                        if tool_name:
                            tools.append(tool_name)
                    # Handle tool_function reference
                    elif isinstance(elt, ast.Name):
                        tools.append(elt.id)
        
        # Deduplicate tools while preserving order
        tools = list(dict.fromkeys(tools))

        return DetectedAgent(
            id=agent_id,
            name=role or agent_id,
            framework=Framework.CREWAI,
            file_path=str(path),
            line_number=node.lineno,
            system_prompt=system_prompt,
            tools=tools,
            metadata=kwargs,
        )

    def _parse_crew_call(
        self, node: ast.Call, agents: list[DetectedAgent]
    ) -> list[DetectedConnection]:
        """Parse a Crew() call to extract task flow."""
        connections: list[DetectedConnection] = []

        func_name = self._get_call_name(node)
        if func_name != "Crew":
            return connections

        # Check for process type
        process_type = "sequential"  # Default
        for keyword in node.keywords:
            if keyword.arg == "process":
                proc_val = self._extract_value(keyword.value)
                if proc_val and "hierarchical" in str(proc_val).lower():
                    process_type = "hierarchical"

        # Look for tasks= argument
        task_names = []
        for keyword in node.keywords:
            if keyword.arg == "tasks" and isinstance(keyword.value, ast.List):
                for elt in keyword.value.elts:
                    if isinstance(elt, ast.Name):
                        task_names.append(elt.id)

        # Create connections based on process type
        if process_type == "sequential" and len(task_names) > 1:
            # Sequential: task1 -> task2 -> task3
            for i in range(len(task_names) - 1):
                connections.append(
                    DetectedConnection(
                        source_id=self._make_id(task_names[i]),
                        target_id=self._make_id(task_names[i + 1]),
                        connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                        confidence=0.95,
                        confidence_level=ConnectionConfidence.FRAMEWORK,
                        evidence=[
                            f"CrewAI sequential Crew tasks=[..., {task_names[i]}, {task_names[i+1]}, ...]"
                        ],
                    )
                )
        elif process_type == "hierarchical" and task_names:
            # Hierarchical: manager connects to all tasks
            # Look for manager_agent
            manager_id = None
            for keyword in node.keywords:
                if keyword.arg == "manager_agent" and isinstance(keyword.value, ast.Name):
                    manager_id = self._make_id(keyword.value.id)
                    break

            if manager_id:
                for task_name in task_names:
                    connections.append(
                        DetectedConnection(
                            source_id=manager_id,
                            target_id=self._make_id(task_name),
                            connection_type=ConnectionType.HIERARCHICAL,
                            confidence=0.95,
                            confidence_level=ConnectionConfidence.FRAMEWORK,
                            evidence=[f"CrewAI hierarchical: {manager_id} -> {task_name}"],
                        )
                    )

        return connections
