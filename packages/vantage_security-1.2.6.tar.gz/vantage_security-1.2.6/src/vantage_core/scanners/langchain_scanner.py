"""Scanner for LangChain agent projects.

Detects agents, chains, and tools from LangChain codebases.
"""

from __future__ import annotations

import ast
import re
from pathlib import Path

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult


class LangChainScanner(BaseScanner):
    """Scanner for LangChain agent projects."""

    framework_name = "LangChain"

    # Patterns for LangChain agent detection
    AGENT_PATTERNS = [
        # Agent creation patterns
        r"create_react_agent",
        r"create_openai_functions_agent",
        r"create_openai_tools_agent",
        r"create_structured_chat_agent",
        r"create_json_agent",
        r"create_xml_agent",
        r"AgentExecutor",
        r"initialize_agent",
        # LLM patterns
        r"ChatOpenAI",
        r"ChatAnthropic",
        r"ChatGoogleGenerativeAI",
        r"ChatVertexAI",
        # Chain patterns that act as agents
        r"LLMChain",
        r"ConversationChain",
        r"RetrievalQA",
        r"ConversationalRetrievalChain",
    ]

    def scan_directory(self, directory: Path) -> ScanResult:
        """Scan a directory for LangChain agents."""
        agents: list[DetectedAgent] = []
        raw_connections: list[tuple[str, str]] = []
        files_scanned = 0

        # Find Python files
        python_files = list(directory.rglob("*.py"))

        for py_file in python_files:
            try:
                content = py_file.read_text(encoding="utf-8")
                files_scanned += 1

                # Check if this file uses LangChain
                if not self._is_langchain_file(content):
                    continue

                # Parse AST
                try:
                    tree = ast.parse(content)
                except SyntaxError:
                    continue

                # Extract agents
                file_agents = self._extract_agents(tree, content, py_file)
                agents.extend(file_agents)

                # Extract chains/connections
                file_connections = self._extract_connections(tree, content)
                raw_connections.extend(file_connections)

            except Exception as e:
                self._log_warning(f"Error scanning {py_file}: {e}")

        # Deduplicate agents by ID
        seen_ids: set[str] = set()
        unique_agents: list[DetectedAgent] = []
        for agent in agents:
            if agent.id not in seen_ids:
                seen_ids.add(agent.id)
                unique_agents.append(agent)

        # Convert tuple connections to DetectedConnection
        connections: list[DetectedConnection] = []
        for src, tgt in raw_connections:
            connections.append(
                DetectedConnection(
                    source_id=src,
                    target_id=tgt,
                    connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                    confidence=0.95,
                    confidence_level=ConnectionConfidence.FRAMEWORK,
                    evidence=[f"LangChain chain: {src} -> {tgt}"],
                )
            )

        return ScanResult(
            agents=unique_agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            errors=[],
            files_scanned=files_scanned,
        )

    def _is_langchain_file(self, content: str) -> bool:
        """Check if file imports from LangChain."""
        langchain_imports = [
            "from langchain",
            "import langchain",
            "from langchain_core",
            "from langchain_openai",
            "from langchain_anthropic",
            "from langchain_google",
            "from langchain_community",
        ]
        return any(imp in content for imp in langchain_imports)

    def _extract_agents(self, tree: ast.AST, content: str, file_path: Path) -> list[DetectedAgent]:
        """Extract agent definitions from AST."""
        agents: list[DetectedAgent] = []

        for node in ast.walk(tree):
            # Look for function calls that create agents
            if isinstance(node, ast.Call):
                agent = self._extract_agent_from_call(node, content, file_path)
                if agent:
                    agents.append(agent)

            # Look for class instantiations
            elif isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        agent = self._extract_agent_from_assignment(
                            target, node.value, content, file_path
                        )
                        if agent:
                            agents.append(agent)

            # Look for Subclasses
            elif isinstance(node, ast.ClassDef):
                print(f"DEBUG: Found ClassDef {node.name}")
                agent = self._parse_agent_class(node, file_path)
                if agent:
                    print(f"DEBUG: Subclass detected: {agent.name}")
                    agents.append(agent)
                else:
                    print(f"DEBUG: Class {node.name} not detected as agent")

        return agents

    def _extract_agent_from_call(
        self, node: ast.Call, content: str, file_path: Path
    ) -> DetectedAgent | None:
        """Extract agent from a function call."""
        func_name = self._get_call_name(node)

        if not func_name:
            return None

        # Check if it's an agent creation pattern
        agent_type = None

        # 1. Direct Match
        for pattern in self.AGENT_PATTERNS:
            if pattern in func_name:
                agent_type = pattern
                break

        # 2. Resolve Alias
        if not agent_type and hasattr(self, "symbol_table") and self.symbol_table:
            resolved = self.symbol_table.resolve_symbol(str(file_path), func_name)
            if resolved:
                if resolved.definition_type == "import":
                    orig = resolved.value.get("original_name", "")
                    for pattern in self.AGENT_PATTERNS:
                        if pattern in orig:
                            agent_type = pattern
                            break
                elif resolved.definition_type == "assignment":
                    val_str = ""
                    try:
                        if isinstance(resolved.value, ast.AST):
                            val_str = ast.unparse(resolved.value)
                        else:
                            val_str = str(resolved.value)
                    except Exception:
                        val_str = str(resolved.value)

                    for pattern in self.AGENT_PATTERNS:
                        if pattern in val_str:
                            agent_type = pattern
                            break

        if not agent_type:
            return None

        # Extract relevant information
        agent_id = self._generate_agent_id(func_name, node.lineno)
        name = self._extract_name_from_call(node, func_name)
        model = self._extract_model_from_call(node, content)
        prompt = self._extract_prompt_from_call(node, content)

        # Extract tools
        tools = []
        for keyword in node.keywords:
            if keyword.arg == "tools":
                tools = self._extract_tools(keyword.value)
                break

        return DetectedAgent(
            id=agent_id,
            name=name,
            framework=Framework.LANGCHAIN,
            file_path=str(file_path),
            line_number=node.lineno,
            system_prompt=prompt or f"LangChain {agent_type} agent",
            tools=tools,
            metadata={"agent_type": agent_type},
        )

    def _extract_agent_from_assignment(
        self, target: ast.Name, call: ast.Call, content: str, file_path: Path
    ) -> DetectedAgent | None:
        """Extract agent from an assignment statement."""
        func_name = self._get_call_name(call)

        if not func_name:
            return None

        # Check if it's an agent/chain creation
        agent_type = None

        # 1. Direct Match
        for pattern in self.AGENT_PATTERNS:
            if pattern in func_name:
                agent_type = pattern
                break

        # 2. Resolve Alias
        if not agent_type and hasattr(self, "symbol_table") and self.symbol_table:
            resolved = self.symbol_table.resolve_symbol(str(file_path), func_name)
            if resolved:
                if resolved.definition_type == "import":
                    orig = resolved.value.get("original_name", "")
                    for pattern in self.AGENT_PATTERNS:
                        if pattern in orig:
                            agent_type = pattern
                            break
                elif resolved.definition_type == "assignment":
                    val_str = ""
                    try:
                        if isinstance(resolved.value, ast.AST):
                            val_str = ast.unparse(resolved.value)
                        else:
                            val_str = str(resolved.value)
                    except Exception:
                        val_str = str(resolved.value)

                    for pattern in self.AGENT_PATTERNS:
                        if pattern in val_str:
                            agent_type = pattern
                            break

        if not agent_type:
            return None

        # Use variable name as agent name
        var_name = target.id
        agent_id = self._sanitize_id(var_name)
        name = self._format_name(var_name)
        model = self._extract_model_from_call(call, content)
        prompt = self._extract_prompt_from_call(call, content)

        # Extract tools
        tools = []
        for keyword in call.keywords:
            if keyword.arg == "tools":
                tools = self._extract_tools(keyword.value)
                break

        return DetectedAgent(
            id=agent_id,
            name=name,
            framework=Framework.LANGCHAIN,
            file_path=str(file_path),
            line_number=call.lineno,
            system_prompt=prompt or f"LangChain {agent_type}",
            tools=tools,
            metadata={"agent_type": agent_type, "variable_name": var_name},
        )

    def _extract_connections(self, tree: ast.AST, content: str) -> list[tuple[str, str]]:
        """Extract connections between agents/chains."""
        connections: list[tuple[str, str]] = []

        # Look for pipe operator usage (chain1 | chain2)
        for node in ast.walk(tree):
            if isinstance(node, ast.BinOp) and isinstance(node.op, ast.BitOr):
                left_name = self._get_node_name(node.left)
                right_name = self._get_node_name(node.right)
                if left_name and right_name:
                    connections.append(
                        (self._sanitize_id(left_name), self._sanitize_id(right_name))
                    )

        # Look for SequentialChain
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                func_name = self._get_call_name(node)
                if func_name and "SequentialChain" in func_name:
                    chain_names = self._extract_sequential_chains(node)
                    for i in range(len(chain_names) - 1):
                        connections.append(
                            (
                                self._sanitize_id(chain_names[i]),
                                self._sanitize_id(chain_names[i + 1]),
                            )
                        )

        return connections

    def _get_node_name(self, node: ast.AST) -> str | None:
        """Get the name from various node types."""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Call):
            return self._get_call_name(node)
        return None

    def _extract_name_from_call(self, node: ast.Call, func_name: str) -> str:
        """Extract a readable name from a call."""
        # Look for name keyword argument
        for keyword in node.keywords:
            if keyword.arg == "name" and isinstance(keyword.value, ast.Constant):
                return str(keyword.value.value)

        return self._format_name(func_name)

    def _extract_model_from_call(self, node: ast.Call, content: str) -> str:
        """Extract model name from a call."""
        # Look for model_name or model keyword
        for keyword in node.keywords:
            if keyword.arg in ("model_name", "model", "model_id"):
                if isinstance(keyword.value, ast.Constant):
                    return str(keyword.value.value)

        # Look for llm keyword which might contain model
        for keyword in node.keywords:
            if keyword.arg == "llm":
                if isinstance(keyword.value, ast.Call):
                    return self._extract_model_from_call(keyword.value, content)

        # Check positional arguments for known LLM classes
        for arg in node.args:
            if isinstance(arg, ast.Call):
                func_name = self._get_call_name(arg)
                if func_name and "Chat" in func_name:
                    return self._extract_model_from_call(arg, content)

        return "gpt-4"  # Default

    def _extract_prompt_from_call(self, node: ast.Call, content: str) -> str | None:
        """Extract prompt from a call."""
        # Look for prompt keyword
        for keyword in node.keywords:
            if keyword.arg in ("prompt", "system_message", "prefix"):
                if isinstance(keyword.value, ast.Constant):
                    return str(keyword.value.value)
                elif isinstance(keyword.value, ast.Call):
                    # Try to extract from PromptTemplate
                    return self._extract_from_prompt_template(keyword.value, content)

        # Look for tools keyword to understand agent capabilities
        for keyword in node.keywords:
            if keyword.arg == "tools":
                tools = self._extract_tools(keyword.value)
                if tools:
                    return f"Agent with tools: {', '.join(tools)}"

        return None

    def _extract_from_prompt_template(self, node: ast.Call, content: str) -> str | None:
        """Extract text from a PromptTemplate call."""
        for keyword in node.keywords:
            if keyword.arg == "template" and isinstance(keyword.value, ast.Constant):
                return str(keyword.value.value)
        return None

    def _extract_tools(self, node: ast.AST) -> list[str]:
        """Extract tool names from a tools list."""
        tools: list[str] = []
        if isinstance(node, ast.List):
            for elt in node.elts:
                if isinstance(elt, ast.Name):
                    tools.append(elt.id)
                elif isinstance(elt, ast.Call):
                    func_name = self._get_call_name(elt)
                    if func_name:
                        tools.append(func_name)
        return tools

    def _extract_sequential_chains(self, node: ast.Call) -> list[str]:
        """Extract chain names from SequentialChain."""
        chains: list[str] = []
        for keyword in node.keywords:
            if keyword.arg == "chains" and isinstance(keyword.value, ast.List):
                for elt in keyword.value.elts:
                    name = self._get_node_name(elt)
                    if name:
                        chains.append(name)
        return chains

    def _generate_agent_id(self, func_name: str, line: int) -> str:
        """Generate a unique agent ID."""
        base = self._sanitize_id(func_name)
        return f"{base}_{line}"

    def _sanitize_id(self, name: str) -> str:
        """Convert name to valid ID."""
        # Remove common prefixes/suffixes
        name = re.sub(r"(create_|_agent|Agent|Chain|_chain)", "", name)
        # Convert to snake_case
        name = re.sub(r"([A-Z])", r"_\1", name).lower().strip("_")
        return name or "agent"

    def _format_name(self, name: str) -> str:
        """Format name for display."""
        # Convert snake_case or camelCase to Title Case
        name = re.sub(r"_", " ", name)
        name = re.sub(r"([a-z])([A-Z])", r"\1 \2", name)
        return name.title()

    def _log_warning(self, message: str) -> None:
        """Log a warning message."""
        import logging

        logging.getLogger(__name__).warning(message)

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a single file for LangChain agents."""
        if not path.suffix == ".py":
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[],
            )

        try:
            content = path.read_text(encoding="utf-8")
            if not self._is_langchain_file(content):
                return ScanResult(
                    agents=[],
                    connections=[],
                    entry_points=[],
                    exit_points=[],
                    framework=self.framework_name,
                    files_scanned=1,
                    errors=[],
                )

            tree = ast.parse(content)

            # Use updated extraction logic
            agents = []
            for node in ast.walk(tree):
                # Look for function calls that create agents
                if isinstance(node, ast.Call):
                    if self._is_agent_creation(node, path):
                        agent = self._extract_agent_from_call(node, content, path)
                        if agent:
                            agents.append(agent)

                # Look for class instantiations (assignments)
                elif isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                            if self._is_agent_creation(node.value, path):
                                agent = self._extract_agent_from_assignment(
                                    target, node.value, content, path
                                )
                                if agent:
                                    agents.append(agent)

                # Look for Subclasses
                elif isinstance(node, ast.ClassDef):
                    agent = self._parse_agent_class(node, path)
                    if agent:
                        agents.append(agent)

            # Extract connections
            raw_connections = self._extract_connections(tree, content)
            connections: list[DetectedConnection] = []
            for src, tgt in raw_connections:
                connections.append(
                    DetectedConnection(
                        source_id=src,
                        target_id=tgt,
                        connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                        confidence=0.95,
                        confidence_level=ConnectionConfidence.FRAMEWORK,
                        evidence=[f"LangChain chain: {src} -> {tgt}"],
                    )
                )

            return ScanResult(
                agents=agents,
                connections=connections,
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[],
            )
        except Exception as e:
            self._log_warning(f"Error scanning {path}: {e}")
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[],
            )

    def _is_agent_creation(self, node: ast.Call, path: Path) -> bool:
        """Check if a call instantiates a LangChain Agent."""
        func_name = self._get_call_name(node)
        if not func_name:
            return False

        # 1. Direct Match
        for pattern in self.AGENT_PATTERNS:
            if pattern in func_name:
                return True

        # 2. Alias Resolution
        if hasattr(self, "symbol_table") and self.symbol_table:
            resolved = self.symbol_table.resolve_symbol(str(path), func_name)
            if resolved:
                if resolved.definition_type == "import":
                    orig = resolved.value.get("original_name", "")
                    if any(p in orig for p in self.AGENT_PATTERNS):
                        return True
                if resolved.definition_type == "assignment":
                    val_str = ""
                    try:
                        if isinstance(resolved.value, ast.AST):
                            val_str = ast.unparse(resolved.value)
                        else:
                            val_str = str(resolved.value)
                    except Exception:
                        val_str = str(resolved.value)

                    if any(p in val_str for p in self.AGENT_PATTERNS):
                        return True
        return False

    def _parse_agent_class(self, node: ast.ClassDef, path: Path) -> DetectedAgent | None:
        """Parse a class inheriting from LangChain components."""
        is_subclass = False
        for base in node.bases:
            name = ""
            if isinstance(base, ast.Name):
                name = base.id
            elif isinstance(base, ast.Attribute):
                name = base.attr

            if any(p in name for p in self.AGENT_PATTERNS):
                is_subclass = True
                break

        if not is_subclass:
            return None

        return DetectedAgent(
            id=self._sanitize_id(node.name),
            name=self._format_name(node.name),
            framework=Framework.LANGCHAIN,
            file_path=str(path),
            line_number=node.lineno,
            system_prompt=f"LangChain Subclass: {node.name}",
            metadata={"type": "subclass"},
        )
