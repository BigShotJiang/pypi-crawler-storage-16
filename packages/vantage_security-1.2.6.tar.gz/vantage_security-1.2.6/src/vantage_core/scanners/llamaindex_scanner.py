"""Scanner for LlamaIndex agent definitions.

Detects agents, query engines, and chat engines from LlamaIndex codebases.
"""

from __future__ import annotations

import ast
import logging  # Import logging
import re
from pathlib import Path
from typing import Any

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult

logger = logging.getLogger(__name__)  # Define logger at module level


class LlamaIndexScanner(BaseScanner):
    """Scanner for LlamaIndex agent definitions."""

    framework_name = "LlamaIndex"

    # Patterns for LlamaIndex agent detection
    AGENT_PATTERNS = [
        # Agent instantiations
        r"OpenAIAgent",
        r"ReActAgent",
        r"FunctionAgent",
        r"AgentRunner",  # For high-level agent orchestrators
        # Query/Chat Engines (implicitly agents)
        r"as_query_engine",
        r"as_chat_engine",
    ]

    def __init__(self, verbose: bool = False, symbol_table: Any = None):
        super().__init__(verbose, symbol_table)
        # We'll keep a list of already seen agent IDs to prevent duplicates from complex LlamaIndex structures
        self._seen_agent_ids = set()

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a single file for LlamaIndex agents."""
        logger.debug(f"LlamaIndexScanner: Scanning file {path}")  # DEBUG
        if not path.suffix == ".py":
            logger.debug(f"LlamaIndexScanner: Skipping non-Python file {path}")  # DEBUG
            return ScanResult(
                agents=[],
                connections=[],
                frameworks_detected=[self.framework_name],
                files_scanned=1,
                errors=[],
            )

        try:
            content = path.read_text(encoding="utf-8")
            if not self._is_llamaindex_file(content):
                logger.debug(f"LlamaIndexScanner: Not a LlamaIndex file {path}")  # DEBUG
                return ScanResult(
                    agents=[],
                    connections=[],
                    frameworks_detected=[self.framework_name],
                    files_scanned=1,
                    errors=[],
                )

            tree = ast.parse(content)

            agents: list[DetectedAgent] = []
            connections: list[DetectedConnection] = []

            for node in ast.walk(tree):
                # 1. Detect Agent Instantiations (e.g., OpenAIAgent(), ReActAgent())
                if isinstance(node, ast.Call):
                    if self._is_agent_creation(node, path):
                        agent = self._parse_agent_call(node, content, path)
                        if agent:
                            logger.debug(
                                f"LlamaIndexScanner: Found agent call {agent.name} in {path}"
                            )  # DEBUG
                            if agent.id not in self._seen_agent_ids:
                                agents.append(agent)
                                self._seen_agent_ids.add(agent.id)

                # 2. Detect Agents from Assignments (e.g., agent = OpenAIAgent())
                elif isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                            if self._is_agent_creation(node.value, path):
                                agent = self._parse_agent_from_assignment(
                                    target, node.value, content, path
                                )
                                if agent:
                                    logger.debug(
                                        f"LlamaIndexScanner: Found agent assignment {agent.name} in {path}"
                                    )  # DEBUG
                                    if agent.id not in self._seen_agent_ids:
                                        agents.append(agent)
                                        self._seen_agent_ids.add(agent.id)

                # 3. Detect Agents from Subclasses (e.g., class MyAgent(OpenAIAgent):)
                elif isinstance(node, ast.ClassDef):
                    agent = self._parse_agent_class(node, path)
                    if agent:
                        logger.debug(
                            f"LlamaIndexScanner: Found agent subclass {agent.name} in {path}"
                        )  # DEBUG
                        if agent.id not in self._seen_agent_ids:
                            agents.append(agent)
                            self._seen_agent_ids.add(agent.id)

                # 4. Detect Chat/Query Engines (e.g., index.as_chat_engine())
                elif isinstance(
                    node, ast.Call
                ):  # Re-check ast.Call as a separate branch for engine methods
                    if isinstance(node.func, ast.Attribute):
                        if node.func.attr in self.AGENT_PATTERNS and isinstance(
                            node.func.value, (ast.Name, ast.Call)
                        ):
                            # This is likely a chat/query engine creation
                            engine_name = self._get_node_name(node.func.value) or "LlamaIndexEngine"
                            agent_id = self._sanitize_id(
                                f"{engine_name}_{node.func.attr}_{node.lineno}"
                            )

                            agent = DetectedAgent(
                                id=agent_id,
                                name=f"{engine_name.title()} ({node.func.attr})",
                                framework=Framework.LLAMAINDEX,
                                file_path=str(path),
                                line_number=node.lineno,
                                system_prompt=f"LlamaIndex {node.func.attr} from {engine_name}",
                                metadata={"type": "engine"},
                            )
                            if agent.id not in self._seen_agent_ids:
                                agents.append(agent)
                                self._seen_agent_ids.add(agent.id)

            # Placeholder for connections logic
            # LlamaIndex connections can be complex (tools in Agents, orchestrators)
            # This would involve deeper data flow analysis
            # For now, we focus on agent detection.

            return ScanResult(
                agents=agents,
                connections=connections,
                frameworks_detected=[self.framework_name],
                files_scanned=1,
                errors=[],
            )
        except Exception as e:
            self._log_warning(f"Error scanning {path}: {e}")
            return ScanResult(
                agents=[],
                connections=[],
                frameworks_detected=[self.framework_name],
                files_scanned=1,
                errors=[f"Error scanning {path}: {e}"],
            )

    def _is_llamaindex_file(self, content: str) -> bool:
        """Check if file imports from LlamaIndex."""
        llamaindex_imports = [
            "from llama_index",
            "import llama_index",
            "from llama_index.core.agent",
            "from llama_index.agent",
            "from llama_index.core.workflow",
            "from llama_index.core.query_engine",
            "from llama_index.core.chat_engine",
        ]
        return any(imp in content for imp in llamaindex_imports)

    def _is_agent_creation(self, node: ast.Call, path: Path) -> bool:
        """Check if a call instantiates a LlamaIndex Agent (directly or via alias)."""
        func_name = self._get_call_name(node)
        if not func_name:
            return False

        # 1. Direct Match
        if func_name in self.AGENT_PATTERNS:
            return True

        # 2. Alias Resolution
        if hasattr(self, "symbol_table") and self.symbol_table:
            resolved = self.symbol_table.resolve_symbol(str(path), func_name)
            if resolved:
                if resolved.definition_type == "import":
                    orig = resolved.value.get("original_name", "")
                    if orig in self.AGENT_PATTERNS:
                        return True
                elif resolved.definition_type == "assignment":
                    val_str = ""
                    try:
                        if isinstance(resolved.value, ast.AST):
                            val_str = ast.unparse(resolved.value)
                        else:
                            val_str = str(resolved.value)
                    except Exception:
                        val_str = str(resolved.value)

                    if any(p in val_str for p in self.AGENT_PATTERNS):
                        return True
        return False

    def _parse_agent_call(
        self, node: ast.Call, content: str, file_path: Path
    ) -> DetectedAgent | None:
        """Parse a LlamaIndex agent constructor call."""
        func_name = self._get_call_name(node)

        # Extract name (from 'name' kwarg or func_name)
        name = self._extract_keyword_arg(node, "name") or func_name

        # Extract prompt
        system_prompt = self._extract_keyword_arg(node, "system_prompt")
        if not system_prompt:
            # LlamaIndex often uses 'description' or inferred from tools
            system_prompt = (
                self._extract_keyword_arg(node, "description") or f"LlamaIndex {func_name}"
            )

        # Extract tools (from 'tools' kwarg)
        tools = self._extract_tools(node)

        return DetectedAgent(
            id=self._sanitize_id(f"{name}_{node.lineno}"),
            name=self._format_name(name),
            framework=Framework.LLAMAINDEX,
            file_path=str(file_path),
            line_number=node.lineno,
            system_prompt=system_prompt,
            tools=tools,
            metadata={"type": "call", "func": func_name},
        )

    def _parse_agent_from_assignment(
        self, target: ast.Name, call: ast.Call, content: str, file_path: Path
    ) -> DetectedAgent | None:
        """Extract agent from an assignment statement (e.g., agent = OpenAIAgent())."""
        func_name = self._get_call_name(call)

        name = self._format_name(target.id)

        system_prompt = self._extract_keyword_arg(call, "system_prompt")
        if not system_prompt:
            system_prompt = (
                self._extract_keyword_arg(call, "description") or f"LlamaIndex {func_name}"
            )

        tools = self._extract_tools(call)

        return DetectedAgent(
            id=self._sanitize_id(target.id),
            name=name,
            framework=Framework.LLAMAINDEX,
            file_path=str(file_path),
            line_number=call.lineno,
            system_prompt=system_prompt,
            tools=tools,
            metadata={
                "type": "assignment",
                "func": func_name,
                "variable_name": target.id,
            },
        )

    def _parse_agent_class(self, node: ast.ClassDef, path: Path) -> DetectedAgent | None:
        """Parse a class inheriting from LlamaIndex components."""
        is_subclass = False
        for base in node.bases:
            name = ""
            if isinstance(base, ast.Name):
                name = base.id
            elif isinstance(base, ast.Attribute):
                name = base.attr

            if any(
                p in name for p in self.AGENT_PATTERNS
            ):  # Check if base class is an Agent pattern
                is_subclass = True
                break

        if not is_subclass:
            return None

        # Extract default attributes from __init__ or class attrs
        agent_name = node.name
        system_prompt = f"LlamaIndex Subclass: {node.name}"
        tools = []

        # Try to find __init__ for more details
        init_method = next(
            (n for n in node.body if isinstance(n, ast.FunctionDef) and n.name == "__init__"),
            None,
        )
        if init_method:
            for sub_node in ast.walk(init_method):
                if isinstance(sub_node, ast.Call) and self._get_call_name(sub_node) == "__init__":
                    # Look for super().__init__ or direct __init__ calls
                    if (
                        isinstance(sub_node.func, ast.Attribute)
                        and sub_node.func.attr == "__init__"
                    ):
                        # Extract kwargs from super().__init__
                        for keyword in sub_node.keywords:
                            val = self._extract_value(keyword.value)
                            if keyword.arg == "system_prompt":
                                system_prompt = val
                            if keyword.arg == "description":
                                system_prompt = val
                            if keyword.arg == "tools" and isinstance(keyword.value, ast.List):
                                for elt in keyword.value.elts:
                                    tools.append(str(self._extract_value(elt)))

        return DetectedAgent(
            id=self._sanitize_id(node.name),
            name=self._format_name(node.name),
            framework=Framework.LLAMAINDEX,
            file_path=str(path),
            line_number=node.lineno,
            system_prompt=system_prompt,
            tools=tools,
            metadata={"type": "subclass"},
        )

    def _extract_tools(self, node: ast.Call) -> list[str]:
        """Extract tool names from a 'tools' keyword argument."""
        tools_val = self._extract_keyword_arg(node, "tools")
        if isinstance(tools_val, list):
            return [
                str(self._extract_value(t)) if isinstance(t, ast.AST) else str(t) for t in tools_val
            ]
        return []

    def _extract_keyword_arg(self, node: ast.Call, arg_name: str) -> Any:
        """Extract a keyword argument value."""
        for keyword in node.keywords:
            if keyword.arg == arg_name:
                return self._extract_value(keyword.value)
        return None

    def _get_node_name(self, node: ast.AST) -> str | None:
        """Get the name from various node types."""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Call):
            return self._get_call_name(node)
        elif isinstance(node, ast.Attribute):
            return node.attr  # obj.name -> name
        return None

    def _get_call_name(self, node: ast.Call) -> str:
        """Get the name of a function call."""
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            return node.func.attr
        return ""
