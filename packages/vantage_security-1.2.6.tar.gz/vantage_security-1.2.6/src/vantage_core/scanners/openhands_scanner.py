"""Scanner for OpenHands agent definitions.

OpenHands (formerly OpenDevin) is an autonomous AI software development agent
that can write code, execute commands, and browse the web.

Example detection targets:

    # Agent subclass definition
    from openhands.controller.agent import Agent
    from openhands.core.config import AgentConfig

    class CodeActAgent(Agent):
        VERSION = '2.2'
        sandbox_plugins = [AgentSkillsRequirement(), JupyterRequirement()]

        def __init__(self, config: AgentConfig, llm_registry: LLMRegistry):
            super().__init__(config, llm_registry)

    # Agent registration
    Agent.register("CodeActAgent", CodeActAgent)

    # AgentController usage
    from openhands.controller.agent_controller import AgentController

    controller = AgentController(
        agent=CodeActAgent(config, llm_registry),
        max_iterations=100,
    )
"""

from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import Any

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult
from vantage_core.scanners.mixins import ASTExtractionMixin, ConfigFileMixin

logger = logging.getLogger(__name__)


class OpenHandsScanner(BaseScanner, ASTExtractionMixin, ConfigFileMixin):
    """Scanner for OpenHands agent definitions.

    Detects:
    - Agent subclass definitions (CodeActAgent, BrowsingAgent, etc.)
    - Agent.register() registration patterns
    - AgentController instantiations
    - AgentConfig configurations
    - config.toml configuration files
    """

    framework_name = "OpenHands"

    # Known built-in agent types
    KNOWN_AGENTS = {
        "CodeActAgent",
        "BrowsingAgent",
        "ReadOnlyAgent",
        "VisualBrowsingAgent",
        "DummyAgent",
        "LocAgent",
    }

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a Python file for OpenHands agent definitions.

        Args:
            path: Path to Python file

        Returns:
            ScanResult with detected agents
        """
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []
        errors: list[str] = []

        # Handle TOML config files
        if path.suffix == ".toml":
            return self._scan_toml_file(path)

        try:
            tree = self._parse_python_file(path)
        except SyntaxError as e:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[f"Syntax error in {path}: {e}"],
            )

        # Check for openhands imports (including legacy opendevin)
        content = path.read_text(encoding="utf-8")
        if not self._has_openhands_imports(content):
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[],
            )

        # Track detected agents to avoid duplicates
        seen_agent_ids: set[str] = set()

        # First pass: find Agent subclass definitions
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                agent = self._parse_agent_class(node, path)
                if agent and agent.id not in seen_agent_ids:
                    agents.append(agent)
                    seen_agent_ids.add(agent.id)

        # Second pass: find Agent.register() calls
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                agent = self._parse_agent_registration(node, path)
                if agent and agent.id not in seen_agent_ids:
                    agents.append(agent)
                    seen_agent_ids.add(agent.id)

        # Third pass: find AgentController instantiations
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        agent = self._parse_agent_controller(target, node.value, path)
                        if agent and agent.id not in seen_agent_ids:
                            agents.append(agent)
                            seen_agent_ids.add(agent.id)

        # Fourth pass: find AgentConfig definitions
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        config_info = self._parse_agent_config(target, node.value, path)
                        if config_info:
                            # Add config info to existing agent or create new one
                            agent_name = config_info.get("name", target.id)
                            agent_id = self._make_id(agent_name)
                            if agent_id not in seen_agent_ids:
                                agent = DetectedAgent(
                                    id=agent_id,
                                    name=self._format_display_name(agent_name),
                                    framework=Framework.OPENHANDS,
                                    file_path=str(path),
                                    line_number=node.value.lineno,
                                    system_prompt=self._build_config_prompt(config_info),
                                    metadata={"raw_config": config_info},
                                )
                                agents.append(agent)
                                seen_agent_ids.add(agent_id)

        # Fifth pass: detect agent delegation patterns
        connections = self._detect_agent_delegation(tree, agents)

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=errors,
        )

    def _has_openhands_imports(self, content: str) -> bool:
        """Check if file has OpenHands or legacy OpenDevin imports.

        Args:
            content: File content as string

        Returns:
            True if openhands imports are present
        """
        return any(
            p in content
            for p in [
                "from openhands",
                "import openhands",
                "from opendevin",
                "import opendevin",  # Legacy import
            ]
        )

    def _parse_agent_class(self, node: ast.ClassDef, path: Path) -> DetectedAgent | None:
        """Parse Agent subclass definition.

        Args:
            node: AST ClassDef node
            path: Source file path

        Returns:
            DetectedAgent or None if not an Agent subclass
        """
        # Check if inherits from Agent
        is_agent_subclass = False
        for base in node.bases:
            base_name = self._get_base_name(base)
            if base_name and "Agent" in base_name:
                is_agent_subclass = True
                break

        if not is_agent_subclass:
            return None

        # Extract docstring
        docstring = ast.get_docstring(node) or ""

        # Extract VERSION if present
        version = ""
        for item in node.body:
            if isinstance(item, ast.Assign):
                for target in item.targets:
                    if isinstance(target, ast.Name) and target.id == "VERSION":
                        version_val = self._extract_value(item.value)
                        if version_val:
                            version = str(version_val)

        # Extract sandbox_plugins
        tools: list[str] = []
        for item in node.body:
            if isinstance(item, ast.AnnAssign):
                if isinstance(item.target, ast.Name) and item.target.id == "sandbox_plugins":
                    if item.value:
                        tools = self._extract_plugin_names(item.value)
            elif isinstance(item, ast.Assign):
                for target in item.targets:
                    if isinstance(target, ast.Name) and target.id == "sandbox_plugins":
                        tools = self._extract_plugin_names(item.value)

        # Build system prompt from docstring
        system_prompt = docstring[:500] if docstring else f"OpenHands {node.name}"
        if tools:
            system_prompt += f"\n\nPlugins: {', '.join(tools)}"

        return DetectedAgent(
            id=self._make_id(node.name),
            name=self._format_display_name(node.name),
            framework=Framework.OPENHANDS,
            file_path=str(path),
            line_number=node.lineno,
            system_prompt=system_prompt,
            tools=tools,
            metadata={
                "raw_config": {
                    "version": version,
                    "class_name": node.name,
                }
            },
        )

    def _get_base_name(self, base: ast.expr) -> str | None:
        """Get the name of a base class.

        Args:
            base: AST expression for base class

        Returns:
            Base class name or None
        """
        if isinstance(base, ast.Name):
            return base.id
        elif isinstance(base, ast.Attribute):
            return base.attr
        return None

    def _extract_plugin_names(self, node: ast.expr) -> list[str]:
        """Extract plugin names from sandbox_plugins list.

        Args:
            node: AST expression for plugins list

        Returns:
            List of plugin names
        """
        names: list[str] = []
        if isinstance(node, ast.List):
            for elt in node.elts:
                if isinstance(elt, ast.Call):
                    name = self._get_call_name(elt)
                    if name:
                        # Remove "Requirement" suffix for cleaner names
                        if name.endswith("Requirement"):
                            name = name[:-11]
                        names.append(name)
        return names

    def _parse_agent_registration(self, node: ast.Call, path: Path) -> DetectedAgent | None:
        """Parse Agent.register() call.

        Args:
            node: AST Call node
            path: Source file path

        Returns:
            DetectedAgent or None if not a registration call
        """
        # Check for Agent.register() pattern
        if not isinstance(node.func, ast.Attribute):
            return None
        if node.func.attr != "register":
            return None

        # Get the object being called on
        if isinstance(node.func.value, ast.Name):
            if node.func.value.id != "Agent":
                return None
        else:
            return None

        # Get registration name (first argument)
        if len(node.args) >= 1:
            name = self._extract_value(node.args[0])
            if name and isinstance(name, str):
                return DetectedAgent(
                    id=self._make_id(name),
                    name=self._format_display_name(name),
                    framework=Framework.OPENHANDS,
                    file_path=str(path),
                    line_number=node.lineno,
                    system_prompt=f"Registered OpenHands Agent: {name}",
                    metadata={"raw_config": {"registration_name": name}},
                )
        return None

    def _parse_agent_controller(
        self, target: ast.Name, call: ast.Call, path: Path
    ) -> DetectedAgent | None:
        """Parse AgentController instantiation.

        Args:
            target: Variable name target
            call: AST Call node
            path: Source file path

        Returns:
            DetectedAgent or None if not an AgentController call
        """
        call_name = self._get_call_name(call)
        if call_name != "AgentController":
            return None

        # Extract agent parameter
        agent_node = self._get_keyword_node(call, "agent")
        agent_type = "Unknown"

        if agent_node:
            if isinstance(agent_node, ast.Call):
                agent_type = self._get_call_name(agent_node)
            elif isinstance(agent_node, ast.Name):
                agent_type = agent_node.id

        # Extract configuration
        max_iterations = self._extract_keyword_arg(call, "max_iterations")
        max_budget = self._extract_keyword_arg(call, "max_budget_per_task")

        # Build system prompt
        prompt_parts = [f"AgentController with {agent_type}"]
        if max_iterations:
            prompt_parts.append(f"Max Iterations: {max_iterations}")
        if max_budget:
            prompt_parts.append(f"Max Budget: {max_budget}")

        return DetectedAgent(
            id=self._make_id(target.id),
            name=self._format_display_name(target.id),
            framework=Framework.OPENHANDS,
            file_path=str(path),
            line_number=call.lineno,
            system_prompt="\n".join(prompt_parts),
            metadata={
                "raw_config": {
                    "controller_type": "AgentController",
                    "agent_type": agent_type,
                    "max_iterations": max_iterations,
                    "max_budget_per_task": max_budget,
                }
            },
        )

    def _get_keyword_node(self, node: ast.Call, arg_name: str) -> ast.expr | None:
        """Get the AST node for a keyword argument.

        Args:
            node: AST Call node
            arg_name: Keyword argument name

        Returns:
            AST expression node or None
        """
        for keyword in node.keywords:
            if keyword.arg == arg_name:
                return keyword.value
        return None

    def _parse_agent_config(
        self, target: ast.Name, call: ast.Call, path: Path
    ) -> dict[str, Any] | None:
        """Parse AgentConfig instantiation.

        Args:
            target: Variable name target
            call: AST Call node
            path: Source file path

        Returns:
            Configuration dict or None if not an AgentConfig call
        """
        call_name = self._get_call_name(call)
        if call_name != "AgentConfig":
            return None

        config: dict[str, Any] = {}

        # Extract all keyword arguments
        for keyword in call.keywords:
            if keyword.arg:
                value = self._extract_value(keyword.value)
                config[keyword.arg] = value

        return config

    def _build_config_prompt(self, config: dict[str, Any]) -> str:
        """Build system prompt from AgentConfig.

        Args:
            config: Configuration dictionary

        Returns:
            Formatted system prompt
        """
        parts = ["OpenHands Agent Configuration"]

        if config.get("name"):
            parts.append(f"Name: {config['name']}")

        capabilities = []
        if config.get("enable_cmd"):
            capabilities.append("Command Execution")
        if config.get("enable_browsing"):
            capabilities.append("Web Browsing")
        if config.get("enable_jupyter"):
            capabilities.append("Jupyter")
        if config.get("enable_editor"):
            capabilities.append("File Editing")

        if capabilities:
            parts.append(f"Capabilities: {', '.join(capabilities)}")

        if config.get("runtime"):
            parts.append(f"Runtime: {config['runtime']}")

        return "\n".join(parts)

    def _scan_toml_file(self, path: Path) -> ScanResult:
        """Scan a TOML configuration file for agent settings.

        Args:
            path: Path to TOML file

        Returns:
            ScanResult with detected agents
        """
        agents: list[DetectedAgent] = []

        config = self._parse_toml_config(path)
        if not config:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=[],
            )

        # Look for agent configuration in TOML
        agent_config = config.get("agent", {})
        if agent_config:
            agent_name = agent_config.get("name", "openhands_agent")

            prompt_parts = ["OpenHands Agent (from config.toml)"]

            if agent_config.get("default_agent"):
                prompt_parts.append(f"Default Agent: {agent_config['default_agent']}")

            model = agent_config.get("llm_config", {}).get("model", "gpt-4")

            agents.append(
                DetectedAgent(
                    id=self._make_id(agent_name),
                    name=self._format_display_name(agent_name),
                    framework=Framework.OPENHANDS,
                    file_path=str(path),
                    line_number=0,
                    system_prompt="\n".join(prompt_parts),
                    metadata={"model": model, "raw_config": agent_config},
                )
            )

        # Also check for core/llm configuration
        core_config = config.get("core", {})
        if core_config and not agents:
            default_agent = core_config.get("default_agent_cls", "CodeActAgent")

            agents.append(
                DetectedAgent(
                    id=self._make_id(default_agent),
                    name=self._format_display_name(default_agent),
                    framework=Framework.OPENHANDS,
                    file_path=str(path),
                    line_number=0,
                    system_prompt=f"OpenHands {default_agent} (from config.toml)",
                    metadata={"raw_config": core_config},
                )
            )

        return ScanResult(
            agents=agents,
            connections=[],
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=[],
        )

    def _detect_agent_delegation(
        self,
        tree: ast.Module,
        agents: list[DetectedAgent],
    ) -> list[DetectedConnection]:
        """Detect delegation patterns between OpenHands agents.

        Looks for patterns where one agent delegates to another:
        - AgentController with agent parameter (controller -> agent)
        - delegate_to patterns
        - agent.step() chains

        Args:
            tree: AST module
            agents: List of detected agents

        Returns:
            List of detected connections
        """
        connections: list[DetectedConnection] = []

        # Build a map of agent names to IDs
        agent_ids = {a.name.lower().replace(" ", "_"): a.id for a in agents}
        agent_ids.update({a.id: a.id for a in agents})

        # Look for AgentController that delegates to agents
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                call_name = self._get_call_name(node)

                # AgentController creates a connection from controller to agent
                if call_name == "AgentController":
                    controller_agent = self._get_keyword_node(node, "agent")
                    if controller_agent:
                        if isinstance(controller_agent, ast.Call):
                            target_name = self._get_call_name(controller_agent)
                        elif isinstance(controller_agent, ast.Name):
                            target_name = controller_agent.id
                        else:
                            continue

                        if target_name:
                            target_id = self._make_id(target_name)
                            # Find the controller variable
                            parent = self._find_parent_assign(tree, node)
                            if parent and isinstance(parent.targets[0], ast.Name):
                                controller_id = self._make_id(parent.targets[0].id)

                                # Create connection from controller to its agent
                                if target_id != controller_id:
                                    connections.append(
                                        DetectedConnection(
                                            source_id=controller_id,
                                            target_id=target_id,
                                            connection_type=ConnectionType.DELEGATION,
                                            confidence=0.95,
                                            confidence_level=ConnectionConfidence.FRAMEWORK,
                                            evidence=[
                                                f"OpenHands AgentController: {controller_id} -> {target_id}"
                                            ],
                                        )
                                    )

        return connections

    def _find_parent_assign(self, tree: ast.Module, call_node: ast.Call) -> ast.Assign | None:
        """Find the Assign node that contains this Call.

        Args:
            tree: AST module
            call_node: Call node to find assignment for

        Returns:
            Assign node or None
        """
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                if node.value is call_node:
                    return node
        return None
