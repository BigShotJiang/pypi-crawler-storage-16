"""Scanner registry for dynamic scanner discovery and lazy loading."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from importlib import import_module
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vantage_core.scanners.base import BaseScanner

logger = logging.getLogger(__name__)


@dataclass
class ScannerMetadata:
    """Metadata about a scanner for optimization and lazy loading.

    Attributes:
        name: Unique identifier for the scanner
        scanner_class: Fully qualified class path for lazy import (e.g., 'vantage_core.scanners.crewai_scanner.CrewAIScanner')
        import_patterns: Patterns that indicate framework usage in source files
        file_patterns: Glob patterns for files to scan
        priority: Scanner priority (lower = higher priority)
        config_files: Config file names this scanner recognizes
    """

    name: str
    scanner_class: str
    import_patterns: list[str]
    file_patterns: list[str] = field(default_factory=lambda: ["*.py"])
    priority: int = 100
    config_files: list[str] = field(default_factory=list)


class ScannerRegistry:
    """Registry for framework scanners with lazy loading and framework detection.

    This registry provides:
    - Dynamic scanner discovery and registration
    - Lazy loading of scanners
    - Framework detection based on import patterns
    - Scanner instance caching

    Example:
        >>> from vantage_core.scanners.registry import ScannerRegistry, ScannerMetadata
        >>>
        >>> # Register a scanner
        >>> ScannerRegistry.register(ScannerMetadata(
        ...     name="myframework",
        ...     scanner_class="mypackage.scanners.MyScanner",
        ...     import_patterns=["from myframework", "import myframework"],
        ... ))
        >>>
        >>> # Detect frameworks in a directory
        >>> detected = ScannerRegistry.detect_frameworks(Path("./my_project"))
        >>>
        >>> # Get scanner instance
        >>> scanner = ScannerRegistry.get_scanner("myframework")
    """

    _scanners: dict[str, ScannerMetadata] = {}
    _instances: dict[str, BaseScanner] = {}

    @classmethod
    def register(cls, metadata: ScannerMetadata) -> None:
        """Register a scanner with metadata.

        Args:
            metadata: Scanner metadata including class path and detection patterns
        """
        cls._scanners[metadata.name] = metadata
        if logger.isEnabledFor(logging.DEBUG):
            logger.debug(f"Registered scanner: {metadata.name}")

    @classmethod
    def unregister(cls, name: str) -> None:
        """Unregister a scanner.

        Args:
            name: Scanner name to unregister
        """
        if name in cls._scanners:
            del cls._scanners[name]
        if name in cls._instances:
            del cls._instances[name]

    @classmethod
    def get_scanner(cls, name: str, verbose: bool = False) -> BaseScanner:
        """Get or create scanner instance with lazy loading.

        The scanner class is dynamically imported on first access,
        and the instance is cached for subsequent calls.

        Args:
            name: Scanner name
            verbose: Whether to enable verbose logging

        Returns:
            Scanner instance

        Raises:
            KeyError: If scanner is not registered
            ImportError: If scanner class cannot be imported
        """
        if name not in cls._scanners:
            raise KeyError(f"Scanner '{name}' is not registered")

        # Check if we need to create a new instance
        cache_key = f"{name}:{verbose}"
        if cache_key not in cls._instances:
            metadata = cls._scanners[name]

            # Dynamic import
            try:
                module_path, class_name = metadata.scanner_class.rsplit(".", 1)
                module = import_module(module_path)
                scanner_class = getattr(module, class_name)
            except (ValueError, ImportError, AttributeError) as e:
                raise ImportError(
                    f"Failed to import scanner class '{metadata.scanner_class}': {e}"
                ) from e

            cls._instances[cache_key] = scanner_class(verbose=verbose)
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug(f"Instantiated scanner: {name}")

        return cls._instances[cache_key]

    @classmethod
    def detect_frameworks(cls, directory: Path) -> list[str]:
        """Quick scan to detect which frameworks are present in a directory.

        Samples up to 50 Python files for import patterns to determine
        which framework scanners should be activated.

        Args:
            directory: Directory to scan

        Returns:
            List of detected framework names
        """
        detected: list[str] = []

        # Sample Python files for performance
        py_files = list(directory.rglob("*.py"))[:50]

        for name, metadata in cls._scanners.items():
            for py_file in py_files:
                # Skip common non-source directories
                path_str = str(py_file)
                if any(
                    skip in path_str
                    for skip in [".venv", "venv", "__pycache__", ".git", "node_modules"]
                ):
                    continue

                try:
                    content = py_file.read_text(encoding="utf-8", errors="ignore")
                    if any(pattern in content for pattern in metadata.import_patterns):
                        detected.append(name)
                        break
                except Exception as e:
                    if logger.isEnabledFor(logging.DEBUG):
                        logger.debug(f"Error reading {py_file}: {e}")
                    continue

        # Sort by priority
        detected.sort(key=lambda n: cls._scanners[n].priority)

        return detected

    @classmethod
    def get_all_scanners(cls, verbose: bool = False) -> list[BaseScanner]:
        """Get all registered scanners sorted by priority.

        Args:
            verbose: Whether to enable verbose logging

        Returns:
            List of all scanner instances
        """
        # Sort by priority
        sorted_names = sorted(cls._scanners.keys(), key=lambda n: cls._scanners[n].priority)
        return [cls.get_scanner(name, verbose) for name in sorted_names]

    @classmethod
    def list_registered(cls) -> list[str]:
        """List all registered scanner names.

        Returns:
            List of registered scanner names
        """
        return list(cls._scanners.keys())

    @classmethod
    def get_metadata(cls, name: str) -> ScannerMetadata | None:
        """Get metadata for a registered scanner.

        Args:
            name: Scanner name

        Returns:
            Scanner metadata or None if not registered
        """
        return cls._scanners.get(name)

    @classmethod
    def clear(cls) -> None:
        """Clear all registered scanners and instances.

        Primarily used for testing.
        """
        cls._scanners.clear()
        cls._instances.clear()
