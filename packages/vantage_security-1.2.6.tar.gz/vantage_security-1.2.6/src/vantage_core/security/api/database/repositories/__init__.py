"""
Repository package for Vantage Security Platform.

This package provides data access layer implementations using
the repository pattern for clean separation of concerns.
"""

from vantage_core.security.api.database.repositories.base import BaseRepository
from vantage_core.security.api.database.repositories.user_repository import (
    UserRepository,
    user_repository,
)

__all__ = [
    "BaseRepository",
    "UserRepository",
    "user_repository",
]
