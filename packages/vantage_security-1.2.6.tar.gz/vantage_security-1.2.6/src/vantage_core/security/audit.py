"""
Audit Logging for Security Scans.

Provides immutable audit trail for scan events, findings, and actions
with cryptographic integrity verification.
"""

import hashlib
import json
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any


class AuditEventType(str, Enum):
    """Types of audit events."""

    SCAN_STARTED = "scan_started"
    SCAN_COMPLETED = "scan_completed"
    SCAN_FAILED = "scan_failed"
    FINDING_DETECTED = "finding_detected"
    FINDING_RESOLVED = "finding_resolved"
    FINDING_SUPPRESSED = "finding_suppressed"
    CONFIG_CHANGED = "config_changed"
    ACCESS_GRANTED = "access_granted"
    ACCESS_DENIED = "access_denied"
    EXPORT_REQUESTED = "export_requested"
    REMEDIATION_APPLIED = "remediation_applied"


@dataclass
class AuditEvent:
    """
    Represents a single audit event.

    Each event is immutable and includes a hash for integrity verification.
    """

    event_id: str
    event_type: AuditEventType
    timestamp: datetime
    actor: str  # User or system component
    resource_type: str  # scan, finding, config, etc.
    resource_id: str
    action: str
    outcome: str  # success, failure, denied
    details: dict[str, Any] = field(default_factory=dict)
    previous_hash: str = ""
    event_hash: str = ""

    def compute_hash(self) -> str:
        """
        Compute SHA-256 hash of the event data.

        Returns:
            Hex digest of the event hash
        """
        data = {
            "event_id": self.event_id,
            "event_type": self.event_type.value,
            "timestamp": self.timestamp.isoformat(),
            "actor": self.actor,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "action": self.action,
            "outcome": self.outcome,
            "details": self.details,
            "previous_hash": self.previous_hash,
        }
        json_str = json.dumps(data, sort_keys=True)
        return hashlib.sha256(json_str.encode()).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        """Convert event to dictionary."""
        return {
            "event_id": self.event_id,
            "event_type": self.event_type.value,
            "timestamp": self.timestamp.isoformat(),
            "actor": self.actor,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "action": self.action,
            "outcome": self.outcome,
            "details": self.details,
            "previous_hash": self.previous_hash,
            "event_hash": self.event_hash,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AuditEvent":
        """Create event from dictionary."""
        return cls(
            event_id=data["event_id"],
            event_type=AuditEventType(data["event_type"]),
            timestamp=datetime.fromisoformat(data["timestamp"]),
            actor=data["actor"],
            resource_type=data["resource_type"],
            resource_id=data["resource_id"],
            action=data["action"],
            outcome=data["outcome"],
            details=data.get("details", {}),
            previous_hash=data.get("previous_hash", ""),
            event_hash=data.get("event_hash", ""),
        )


class AuditLogger:
    """
    Immutable audit logger with cryptographic integrity.

    Maintains a hash chain of events for tamper detection.
    """

    def __init__(self, log_path: Path | None = None):
        """
        Initialize the audit logger.

        Args:
            log_path: Optional path to persist audit logs
        """
        self._events: list[AuditEvent] = []
        self._log_path = log_path
        self._logger = logging.getLogger("vantage_core.audit")
        self._last_hash = "genesis"

        # Load existing events if log file exists
        if log_path and log_path.exists():
            self._load_events()

    def log(
        self,
        event_type: AuditEventType,
        actor: str,
        resource_type: str,
        resource_id: str,
        action: str,
        outcome: str = "success",
        details: dict[str, Any] | None = None,
    ) -> AuditEvent:
        """
        Log an audit event.

        Args:
            event_type: Type of event
            actor: User or system component
            resource_type: Type of resource affected
            resource_id: ID of resource
            action: Action performed
            outcome: Result of action
            details: Additional event details

        Returns:
            Created AuditEvent
        """
        event = AuditEvent(
            event_id=str(uuid.uuid4()),
            event_type=event_type,
            timestamp=datetime.utcnow(),
            actor=actor,
            resource_type=resource_type,
            resource_id=resource_id,
            action=action,
            outcome=outcome,
            details=details or {},
            previous_hash=self._last_hash,
        )

        # Compute and set event hash
        event.event_hash = event.compute_hash()
        self._last_hash = event.event_hash

        # Store event
        self._events.append(event)

        # Persist if log path configured
        if self._log_path:
            self._persist_event(event)

        # Also log to standard logger
        self._logger.info(
            f"Audit: {event_type.value} - {actor} {action} {resource_type}/{resource_id} - {outcome}"
        )

        return event

    def log_scan_started(
        self, scan_id: str, actor: str, path: str, frameworks: list[str] | None = None
    ) -> AuditEvent:
        """Log scan started event."""
        return self.log(
            event_type=AuditEventType.SCAN_STARTED,
            actor=actor,
            resource_type="scan",
            resource_id=scan_id,
            action="start",
            outcome="success",
            details={"path": path, "frameworks": frameworks or []},
        )

    def log_scan_completed(
        self, scan_id: str, actor: str, findings_count: int, duration_ms: int
    ) -> AuditEvent:
        """Log scan completed event."""
        return self.log(
            event_type=AuditEventType.SCAN_COMPLETED,
            actor=actor,
            resource_type="scan",
            resource_id=scan_id,
            action="complete",
            outcome="success",
            details={"findings_count": findings_count, "duration_ms": duration_ms},
        )

    def log_scan_failed(self, scan_id: str, actor: str, error: str) -> AuditEvent:
        """Log scan failed event."""
        return self.log(
            event_type=AuditEventType.SCAN_FAILED,
            actor=actor,
            resource_type="scan",
            resource_id=scan_id,
            action="fail",
            outcome="failure",
            details={"error": error},
        )

    def log_finding_detected(
        self, finding_id: str, scan_id: str, severity: str, category: str
    ) -> AuditEvent:
        """Log finding detected event."""
        return self.log(
            event_type=AuditEventType.FINDING_DETECTED,
            actor="scanner",
            resource_type="finding",
            resource_id=finding_id,
            action="detect",
            outcome="success",
            details={"scan_id": scan_id, "severity": severity, "category": category},
        )

    def log_access(
        self,
        actor: str,
        resource_type: str,
        resource_id: str,
        action: str,
        granted: bool,
    ) -> AuditEvent:
        """Log access control event."""
        return self.log(
            event_type=(AuditEventType.ACCESS_GRANTED if granted else AuditEventType.ACCESS_DENIED),
            actor=actor,
            resource_type=resource_type,
            resource_id=resource_id,
            action=action,
            outcome="success" if granted else "denied",
        )

    def get_events(
        self,
        event_type: AuditEventType | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
        actor: str | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
    ) -> list[AuditEvent]:
        """
        Query audit events with filters.

        Args:
            event_type: Filter by event type
            resource_type: Filter by resource type
            resource_id: Filter by resource ID
            actor: Filter by actor
            start_time: Filter events after this time
            end_time: Filter events before this time

        Returns:
            List of matching events
        """
        results = self._events

        if event_type:
            results = [e for e in results if e.event_type == event_type]
        if resource_type:
            results = [e for e in results if e.resource_type == resource_type]
        if resource_id:
            results = [e for e in results if e.resource_id == resource_id]
        if actor:
            results = [e for e in results if e.actor == actor]
        if start_time:
            results = [e for e in results if e.timestamp >= start_time]
        if end_time:
            results = [e for e in results if e.timestamp <= end_time]

        return results

    def verify_integrity(self) -> tuple[bool, list[str]]:
        """
        Verify the integrity of the audit log chain.

        Returns:
            Tuple of (is_valid, list of error messages)
        """
        errors = []

        if not self._events:
            return True, []

        # Check first event
        if self._events[0].previous_hash != "genesis":
            errors.append(f"First event has invalid previous_hash: {self._events[0].previous_hash}")

        # Verify hash chain
        for i, event in enumerate(self._events):
            computed = event.compute_hash()
            if computed != event.event_hash:
                errors.append(f"Event {event.event_id} has invalid hash")

            if i > 0:
                if event.previous_hash != self._events[i - 1].event_hash:
                    errors.append(f"Event {event.event_id} has broken chain link")

        return len(errors) == 0, errors

    def export(self, format: str = "json") -> str:
        """
        Export audit log.

        Args:
            format: Export format (json, csv)

        Returns:
            Exported data as string
        """
        if format == "json":
            return json.dumps([e.to_dict() for e in self._events], indent=2)
        elif format == "csv":
            lines = ["event_id,event_type,timestamp,actor,resource_type,resource_id,action,outcome"]
            for e in self._events:
                lines.append(
                    f"{e.event_id},{e.event_type.value},{e.timestamp.isoformat()},{e.actor},{e.resource_type},{e.resource_id},{e.action},{e.outcome}"
                )
            return "\n".join(lines)
        else:
            raise ValueError(f"Unknown format: {format}")

    def _persist_event(self, event: AuditEvent) -> None:
        """Persist event to log file."""
        if not self._log_path:
            return

        self._log_path.parent.mkdir(parents=True, exist_ok=True)

        with open(self._log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(event.to_dict()) + "\n")

    def _load_events(self) -> None:
        """Load events from log file."""
        if not self._log_path or not self._log_path.exists():
            return

        with open(self._log_path, encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    data = json.loads(line)
                    event = AuditEvent.from_dict(data)
                    self._events.append(event)
                    self._last_hash = event.event_hash

    @property
    def event_count(self) -> int:
        """Get total number of events."""
        return len(self._events)


# Global audit logger instance
_default_audit_logger: AuditLogger | None = None


def get_audit_logger() -> AuditLogger:
    """
    Get the default global audit logger.

    Returns:
        Default AuditLogger instance
    """
    global _default_audit_logger
    if _default_audit_logger is None:
        _default_audit_logger = AuditLogger()
    return _default_audit_logger


def set_audit_logger(logger: AuditLogger) -> None:
    """
    Set the default global audit logger.

    Args:
        logger: AuditLogger instance to use as default
    """
    global _default_audit_logger
    _default_audit_logger = logger
