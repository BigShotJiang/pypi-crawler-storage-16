"""
Configuration management for Vantage security scanner.

US-009: Environment Variable Overrides
US-010: YAML/TOML Configuration File
US-011: Runtime Configuration API
US-012: Configuration Validation

This module provides comprehensive configuration management including:
- Environment variable configuration (MIMIC_ prefix)
- YAML/TOML configuration file support
- Runtime configuration API with observer pattern
- Thread-safe configuration updates
- Pydantic validation with dependency checking

Quick Start:
    >>> from vantage_core.security.config import load_config, get_config
    >>>
    >>> # Load configuration from defaults, env vars, and config file
    >>> settings = load_config()
    >>>
    >>> # Load with specific overrides
    >>> settings = get_config(log_level="DEBUG", taint_enabled=False)
    >>>
    >>> # Access settings
    >>> print(settings.entropy.api_key)
    >>> print(settings.taint.max_depth)

Environment Variables:
    Configuration can be set via environment variables with the
    MIMIC_ prefix. Nested settings use double underscores:

    MIMIC_LOG_LEVEL=DEBUG
    MIMIC_LOGGING__JSON_OUTPUT=false
    MIMIC_TAINT__ENABLED=false
    MIMIC_ENTROPY__API_KEY=4.0

Configuration Files:
    The loader searches for configuration files in this order:
    - ./vantage.toml
    - ./vantage.yaml
    - ./.vantage.toml
    - ~/.vantage.toml
    - ~/.config/vantage/config.toml

Runtime Configuration:
    >>> from vantage_core.security.config import ConfigurationManager
    >>>
    >>> manager = ConfigurationManager(settings)
    >>> manager.set("taint.max_depth", 50)
    >>> manager.add_change_callback(lambda c: print(f"Changed: {c.key}"))
"""

from vantage_core.security.config.loader import (
    ConfigurationError,
    dump_config,
    find_config_file,
    get_config,
    get_default_config,
    list_env_vars,
    load_config,
    validate_config,
)
from vantage_core.security.config.manager import (
    ConfigChange,
    ConfigurationManager,
    get_config_value,
    get_global_manager,
    initialize_global_config,
    set_config_value,
    set_global_manager,
)
from vantage_core.security.config.schema import (
    ConfidenceConfig,
    EntropyConfig,
    LoggingConfig,
    LogLevel,
    MimicSettings,
    OutputFormat,
    PerformanceConfig,
    RulesConfig,
    SeverityThresholds,
    TaintAnalysisMode,
    TaintConfig,
)

__all__ = [
    # Main settings class
    "MimicSettings",
    # Nested configuration models
    "LoggingConfig",
    "EntropyConfig",
    "ConfidenceConfig",
    "TaintConfig",
    "PerformanceConfig",
    "SeverityThresholds",
    "RulesConfig",
    # Enums
    "LogLevel",
    "OutputFormat",
    "TaintAnalysisMode",
    # Loader functions
    "load_config",
    "get_config",
    "find_config_file",
    "validate_config",
    "dump_config",
    "list_env_vars",
    "get_default_config",
    # Manager classes
    "ConfigurationManager",
    "ConfigChange",
    # Global manager functions
    "get_global_manager",
    "set_global_manager",
    "initialize_global_config",
    "get_config_value",
    "set_config_value",
    # Exceptions
    "ConfigurationError",
]
