"""
Real Data Loader for ML Secret Detection Model.

Loads and preprocesses real secret data from various sources including:
- SecLists dataset
- SecretBench (if available)
- Custom labeled datasets

Handles feature extraction, train/val/test splitting, and class balancing.
"""

import json
import pickle
import random
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent))

from src.vantage.security.detection.ml_features import FeatureExtractor
from src.vantage.security.detection.training.synthetic_data import TrainingSample


@dataclass
class RealDataset:
    """Container for real secret detection dataset."""

    train_samples: list[TrainingSample]
    val_samples: list[TrainingSample]
    test_samples: list[TrainingSample]
    metadata: dict[str, Any]

    @property
    def total_samples(self) -> int:
        """Total number of samples across all splits."""
        return len(self.train_samples) + len(self.val_samples) + len(self.test_samples)

    @property
    def class_distribution(self) -> dict[str, dict[str, int]]:
        """Get class distribution for each split."""
        return {
            "train": {
                "positive": sum(1 for s in self.train_samples if s.is_secret),
                "negative": sum(1 for s in self.train_samples if not s.is_secret),
            },
            "val": {
                "positive": sum(1 for s in self.val_samples if s.is_secret),
                "negative": sum(1 for s in self.val_samples if not s.is_secret),
            },
            "test": {
                "positive": sum(1 for s in self.test_samples if s.is_secret),
                "negative": sum(1 for s in self.test_samples if not s.is_secret),
            },
        }


class RealDataLoader:
    """Loads and preprocesses real secret detection data."""

    DATA_DIR = Path(__file__).parent.parent.parent.parent.parent.parent / "data"
    CACHE_DIR = Path(__file__).parent.parent.parent.parent.parent.parent / "data" / "cache"

    def __init__(self, seed: int = 42):
        """
        Initialize data loader.

        Args:
            seed: Random seed for reproducibility
        """
        self.seed = seed
        random.seed(seed)
        np.random.seed(seed)
        self.feature_extractor = FeatureExtractor()

    def load_seclists_dataset(self) -> list[TrainingSample]:
        """
        Load SecLists dataset.

        Returns:
            List of training samples
        """
        seclists_file = self.DATA_DIR / "real_secrets" / "seclists_dataset.json"

        if not seclists_file.exists():
            print(f"SecLists dataset not found at {seclists_file}")
            print("Run scripts/download_seclists.py first to acquire data")
            return []

        with open(seclists_file) as f:
            data = json.load(f)

        samples = []
        for sample_data in data["samples"]:
            sample = TrainingSample(
                text=sample_data["text"],
                context=sample_data["context"],
                file_path=sample_data["file_path"],
                is_secret=sample_data["is_secret"],
                source=sample_data.get("source", "seclists"),
                metadata=sample_data.get("metadata", {}),
            )
            samples.append(sample)

        print(f"Loaded {len(samples)} samples from SecLists")
        return samples

    def load_secretbench_dataset(self) -> list[TrainingSample]:
        """
        Attempt to load SecretBench dataset if available.

        Returns:
            List of training samples (empty if not available)
        """
        # Check common locations for SecretBench data
        potential_paths = [
            self.DATA_DIR / "secretbench" / "dataset.json",
            self.DATA_DIR / "SecretBench" / "data.json",
            Path.home() / "Downloads" / "SecretBench.json",
        ]

        for path in potential_paths:
            if path.exists():
                print(f"Found SecretBench data at {path}")
                try:
                    with open(path) as f:
                        data = json.load(f)

                    samples = []
                    # Parse SecretBench format (adjust based on actual format)
                    if isinstance(data, list):
                        for item in data:
                            sample = TrainingSample(
                                text=item.get("secret", item.get("text", "")),
                                context=item.get("context", ""),
                                file_path=item.get("file", "unknown.py"),
                                is_secret=item.get("label", item.get("is_secret", True)),
                                source="secretbench",
                                metadata={"repo": item.get("repo", "unknown")},
                            )
                            samples.append(sample)

                    print(f"Loaded {len(samples)} samples from SecretBench")
                    return samples

                except Exception as e:
                    print(f"Error loading SecretBench from {path}: {e}")

        print("SecretBench dataset not found (optional)")
        return []

    def augment_with_false_positives(
        self, samples: list[TrainingSample], num_fps: int = 2000
    ) -> list[TrainingSample]:
        """
        Add common false positive patterns to improve precision.

        Args:
            samples: Existing samples
            num_fps: Number of false positives to add

        Returns:
            Augmented sample list
        """
        false_positives = []

        # Common false positive patterns from real codebases
        fp_patterns = [
            # Test data
            (
                "test_token_123456789012345678901234567890",
                "test/fixtures.py",
                "test data",
            ),
            (
                "example_api_key_abcdefghijklmnopqrstuvwxyz",
                "docs/example.md",
                "documentation",
            ),
            (
                "dummy_secret_value_for_testing_purposes",
                "tests/test_config.py",
                "test fixture",
            ),
            # SHA hashes
            ("a94a8fe5ccb19ba61c4c0873d391e987982fbbd3", "commit.txt", "git sha"),
            (
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "checksums.txt",
                "sha256",
            ),
            # UUIDs
            ("550e8400-e29b-41d4-a716-446655440000", "data/users.json", "uuid"),
            ("123e4567-e89b-12d3-a456-426614174000", "logs/app.log", "uuid"),
            # Build artifacts
            (
                "node_modules/.cache/babel-loader/8d3f4a8b2c1e5d7f6g9h2j3k4l5m6n7o8p9q0r",
                "build.log",
                "cache key",
            ),
            (
                ".next/static/chunks/webpack-cb7634a8b6194820.js",
                "next.config.js",
                "build hash",
            ),
            # Base64 encoded non-secrets
            (
                "aGVsbG8gd29ybGQgdGhpcyBpcyBub3QgYSBzZWNyZXQ=",
                "data.json",
                "base64 data",
            ),
            ("eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0=", "public_key.pem", "jwt header"),
            # Version strings
            (
                "v2.3.4-alpha.1+build.20240115.sha.abc123def456",
                "package.json",
                "version",
            ),
            ("1.0.0-rc.1-next.20240115.1234567", "version.txt", "version"),
        ]

        for i in range(min(num_fps, len(fp_patterns) * 10)):
            pattern_idx = i % len(fp_patterns)
            text, file_path, fp_type = fp_patterns[pattern_idx]

            # Add some variation
            if i >= len(fp_patterns):
                suffix = "".join(random.choices("0123456789abcdef", k=8))
                text = f"{text}_{suffix}"

            sample = TrainingSample(
                text=text,
                context=f'const VALUE = "{text}"',
                file_path=file_path,
                is_secret=False,
                source="augmented_fp",
                metadata={"fp_type": fp_type},
            )
            false_positives.append(sample)

        return samples + false_positives

    def balance_dataset(
        self, samples: list[TrainingSample], target_ratio: float = 0.4
    ) -> list[TrainingSample]:
        """
        Balance dataset to achieve target positive ratio.

        Args:
            samples: Input samples
            target_ratio: Target ratio of positive samples (0.4 = 40% positive)

        Returns:
            Balanced dataset
        """
        positive_samples = [s for s in samples if s.is_secret]
        negative_samples = [s for s in samples if not s.is_secret]

        num_positive = len(positive_samples)
        num_negative = len(negative_samples)

        print(f"Original distribution: {num_positive} positive, {num_negative} negative")

        # Calculate target counts
        if num_positive / (num_positive + num_negative) < target_ratio:
            # Need more positive samples - oversample
            target_positive = int(num_negative * target_ratio / (1 - target_ratio))
            if target_positive > num_positive:
                # Oversample positive class
                additional_needed = target_positive - num_positive
                additional_positive = random.choices(positive_samples, k=additional_needed)
                positive_samples.extend(additional_positive)
                print(f"Oversampled {additional_needed} positive samples")
        else:
            # Need more negative samples - oversample or undersample positive
            target_negative = int(num_positive * (1 - target_ratio) / target_ratio)
            if target_negative > num_negative:
                # Oversample negative class
                additional_needed = target_negative - num_negative
                additional_negative = random.choices(negative_samples, k=additional_needed)
                negative_samples.extend(additional_negative)
                print(f"Oversampled {additional_needed} negative samples")
            else:
                # Undersample positive class
                positive_samples = random.sample(positive_samples, target_negative)
                print(f"Undersampled to {len(positive_samples)} positive samples")

        # Combine and shuffle
        balanced_samples = positive_samples + negative_samples
        random.shuffle(balanced_samples)

        final_positive = sum(1 for s in balanced_samples if s.is_secret)
        final_ratio = final_positive / len(balanced_samples)
        print(
            f"Final distribution: {final_positive}/{len(balanced_samples)} = {final_ratio:.2%} positive"
        )

        return balanced_samples

    def split_dataset(
        self,
        samples: list[TrainingSample],
        train_ratio: float = 0.6,
        val_ratio: float = 0.2,
        test_ratio: float = 0.2,
    ) -> tuple[list[TrainingSample], list[TrainingSample], list[TrainingSample]]:
        """
        Split dataset into train/validation/test sets.

        Args:
            samples: All samples
            train_ratio: Ratio for training set
            val_ratio: Ratio for validation set
            test_ratio: Ratio for test set

        Returns:
            Tuple of (train_samples, val_samples, test_samples)
        """
        assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 0.001, "Ratios must sum to 1"

        # Shuffle samples
        samples = samples.copy()
        random.shuffle(samples)

        # Calculate split indices
        n = len(samples)
        train_end = int(n * train_ratio)
        val_end = train_end + int(n * val_ratio)

        train_samples = samples[:train_end]
        val_samples = samples[train_end:val_end]
        test_samples = samples[val_end:]

        return train_samples, val_samples, test_samples

    def extract_features(self, samples: list[TrainingSample]) -> tuple[np.ndarray, np.ndarray]:
        """
        Extract feature vectors from samples.

        Args:
            samples: List of training samples

        Returns:
            Tuple of (features, labels)
        """
        features = []
        labels = []

        print(f"Extracting features from {len(samples)} samples...")

        for i, sample in enumerate(samples):
            if i % 1000 == 0:
                print(f"  Processed {i}/{len(samples)} samples...")

            try:
                # Extract features
                feature_obj = self.feature_extractor.extract(
                    text=sample.text, context=sample.context, file_path=sample.file_path
                )

                # Convert to vector
                feature_vector = feature_obj.to_vector()
                features.append(feature_vector)
                labels.append(1 if sample.is_secret else 0)

            except Exception as e:
                print(f"Warning: Failed to extract features for sample {i}: {e}")

        return np.array(features), np.array(labels)

    def load_complete_dataset(
        self,
        use_cache: bool = True,
        include_secretbench: bool = True,
        augment_fps: bool = True,
        balance: bool = True,
    ) -> RealDataset:
        """
        Load complete dataset with all preprocessing.

        Args:
            use_cache: Use cached dataset if available
            include_secretbench: Try to include SecretBench data
            augment_fps: Add false positive augmentation
            balance: Balance the dataset

        Returns:
            RealDataset object with train/val/test splits
        """
        # Check cache
        cache_file = self.CACHE_DIR / "real_dataset.pkl"
        if use_cache and cache_file.exists():
            print(f"Loading cached dataset from {cache_file}")
            with open(cache_file, "rb") as f:
                return pickle.load(f)

        # Load data from sources
        print("\n" + "=" * 50)
        print("Loading Real Secret Detection Dataset")
        print("=" * 50)

        samples = []

        # 1. Load SecLists (primary source)
        print("\n[1/5] Loading SecLists data...")
        seclists_samples = self.load_seclists_dataset()
        samples.extend(seclists_samples)

        # 2. Load SecretBench (if available)
        if include_secretbench:
            print("\n[2/5] Checking for SecretBench data...")
            secretbench_samples = self.load_secretbench_dataset()
            samples.extend(secretbench_samples)
        else:
            print("\n[2/5] Skipping SecretBench (disabled)")

        if not samples:
            raise ValueError("No data loaded! Run scripts/download_seclists.py first")

        print(f"\nTotal samples loaded: {len(samples)}")

        # 3. Add false positive augmentation
        if augment_fps:
            print("\n[3/5] Adding false positive augmentation...")
            samples = self.augment_with_false_positives(samples, num_fps=2000)
            print(f"Total samples after augmentation: {len(samples)}")
        else:
            print("\n[3/5] Skipping false positive augmentation")

        # 4. Balance dataset
        if balance:
            print("\n[4/5] Balancing dataset...")
            samples = self.balance_dataset(samples, target_ratio=0.4)
        else:
            print("\n[4/5] Skipping dataset balancing")

        # 5. Split dataset
        print("\n[5/5] Splitting into train/val/test...")
        train_samples, val_samples, test_samples = self.split_dataset(samples)

        print("\nFinal splits:")
        print(f"  Train: {len(train_samples)} samples")
        print(f"  Val: {len(val_samples)} samples")
        print(f"  Test: {len(test_samples)} samples")

        # Create dataset object
        dataset = RealDataset(
            train_samples=train_samples,
            val_samples=val_samples,
            test_samples=test_samples,
            metadata={
                "total_samples": len(samples),
                "sources": ["seclists"] + (["secretbench"] if include_secretbench else []),
                "augmented": augment_fps,
                "balanced": balance,
                "seed": self.seed,
            },
        )

        # Print class distribution
        print("\nClass distribution:")
        for split_name, dist in dataset.class_distribution.items():
            ratio = dist["positive"] / (dist["positive"] + dist["negative"]) * 100
            print(
                f"  {split_name}: {dist['positive']} positive, {dist['negative']} negative ({ratio:.1f}% positive)"
            )

        # Cache dataset
        if use_cache:
            self.CACHE_DIR.mkdir(parents=True, exist_ok=True)
            with open(cache_file, "wb") as f:
                pickle.dump(dataset, f)
            print(f"\nDataset cached to {cache_file}")

        return dataset


def main():
    """Test data loader."""
    loader = RealDataLoader(seed=42)

    # Load complete dataset
    dataset = loader.load_complete_dataset(
        use_cache=False, include_secretbench=True, augment_fps=True, balance=True
    )

    print("\n" + "=" * 50)
    print("Dataset Loading Complete!")
    print("=" * 50)

    # Extract features for a sample
    print("\nExtracting features for sample batch...")
    sample_batch = dataset.train_samples[:100]
    features, labels = loader.extract_features(sample_batch)

    print(f"\nFeature shape: {features.shape}")
    print(f"Label shape: {labels.shape}")
    print(f"Feature vector length: {features.shape[1]}")

    # Show sample statistics
    print("\nSample statistics:")
    print(f"  Mean feature values: {np.mean(features, axis=0)[:5]}...")
    print(f"  Std feature values: {np.std(features, axis=0)[:5]}...")
    print(f"  Positive ratio in batch: {np.mean(labels):.2%}")


if __name__ == "__main__":
    main()
