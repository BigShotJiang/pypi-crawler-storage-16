"""
Data models for historical tracking.

These models can be used with SQLAlchemy or as standalone dataclasses.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class FindingStatus(str, Enum):
    """Status of a finding over time."""

    OPEN = "open"
    SUPPRESSED = "suppressed"
    FIXED = "fixed"
    WONT_FIX = "wont_fix"


@dataclass
class ScanHistory:
    """
    Record of a security scan.

    Tracks scan metadata and summary results for trend analysis.
    """

    id: str
    project_id: str
    scan_id: str
    timestamp: datetime
    duration_ms: int
    total_findings: int
    critical_count: int
    high_count: int
    medium_count: int
    low_count: int
    score: float
    grade: str
    frameworks_detected: list[str] = field(default_factory=list)
    agents_scanned: int = 0
    branch: str | None = None
    commit_sha: str | None = None
    triggered_by: str | None = None  # "push", "pr", "schedule", "manual"
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "project_id": self.project_id,
            "scan_id": self.scan_id,
            "timestamp": self.timestamp.isoformat(),
            "duration_ms": self.duration_ms,
            "total_findings": self.total_findings,
            "critical_count": self.critical_count,
            "high_count": self.high_count,
            "medium_count": self.medium_count,
            "low_count": self.low_count,
            "score": self.score,
            "grade": self.grade,
            "frameworks_detected": self.frameworks_detected,
            "agents_scanned": self.agents_scanned,
            "branch": self.branch,
            "commit_sha": self.commit_sha,
            "triggered_by": self.triggered_by,
            "metadata": self.metadata,
        }


@dataclass
class FindingHistory:
    """
    Tracks the lifecycle of a finding.

    Used to calculate MTTR and track finding status changes.
    """

    id: str
    project_id: str
    fingerprint: str  # Stable identifier for the finding
    title: str
    category: str
    severity: str
    file_path: str
    first_seen: datetime
    last_seen: datetime
    status: FindingStatus = FindingStatus.OPEN
    fixed_at: datetime | None = None
    fixed_in_commit: str | None = None
    occurrences: int = 1
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def time_to_fix_hours(self) -> float | None:
        """Calculate time to fix in hours."""
        if self.fixed_at is None:
            return None
        delta = self.fixed_at - self.first_seen
        return delta.total_seconds() / 3600

    @property
    def age_hours(self) -> float:
        """Calculate age of finding in hours."""
        if self.fixed_at:
            end = self.fixed_at
        else:
            end = datetime.utcnow()
        delta = end - self.first_seen
        return delta.total_seconds() / 3600

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "project_id": self.project_id,
            "fingerprint": self.fingerprint,
            "title": self.title,
            "category": self.category,
            "severity": self.severity,
            "file_path": self.file_path,
            "first_seen": self.first_seen.isoformat(),
            "last_seen": self.last_seen.isoformat(),
            "status": self.status.value,
            "fixed_at": self.fixed_at.isoformat() if self.fixed_at else None,
            "fixed_in_commit": self.fixed_in_commit,
            "occurrences": self.occurrences,
            "time_to_fix_hours": self.time_to_fix_hours,
            "age_hours": self.age_hours,
            "metadata": self.metadata,
        }


@dataclass
class RemediationTracking:
    """
    Tracks remediation metrics.

    Used for MTTR calculations and remediation velocity.
    """

    project_id: str
    period_start: datetime
    period_end: datetime
    total_fixed: int
    total_new: int
    mttr_critical_hours: float | None = None
    mttr_high_hours: float | None = None
    mttr_medium_hours: float | None = None
    mttr_low_hours: float | None = None
    mttr_overall_hours: float | None = None
    velocity: float = 0.0  # fixed/new ratio

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "project_id": self.project_id,
            "period_start": self.period_start.isoformat(),
            "period_end": self.period_end.isoformat(),
            "total_fixed": self.total_fixed,
            "total_new": self.total_new,
            "mttr_critical_hours": self.mttr_critical_hours,
            "mttr_high_hours": self.mttr_high_hours,
            "mttr_medium_hours": self.mttr_medium_hours,
            "mttr_low_hours": self.mttr_low_hours,
            "mttr_overall_hours": self.mttr_overall_hours,
            "velocity": self.velocity,
        }


@dataclass
class TrendData:
    """
    Aggregated trend data for a time period.

    Used for dashboard visualizations.
    """

    project_id: str
    date: datetime
    total_findings: int
    critical_count: int
    high_count: int
    medium_count: int
    low_count: int
    score: float
    new_findings: int = 0
    fixed_findings: int = 0
    scan_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "project_id": self.project_id,
            "date": self.date.isoformat(),
            "total_findings": self.total_findings,
            "critical_count": self.critical_count,
            "high_count": self.high_count,
            "medium_count": self.medium_count,
            "low_count": self.low_count,
            "score": self.score,
            "new_findings": self.new_findings,
            "fixed_findings": self.fixed_findings,
            "scan_count": self.scan_count,
        }
