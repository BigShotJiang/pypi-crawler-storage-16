"""
Vantage Security Scanner - Git Integration Package

This package provides connectors for Git repositories, including
GitHub integration for cloning, branch listing, and repository scanning.
"""

from vantage_core.security.integrations.github import (
    GitHubService as GitCloner,
)
from vantage_core.security.integrations.github import (
    GitHubService as GitHubConnector,
)
from vantage_core.security.integrations.github import (
    RepositoryInfo as GitHubRepo,
)

__all__ = [
    "GitHubConnector",
    "GitHubRepo",
    "GitCloner",
]
