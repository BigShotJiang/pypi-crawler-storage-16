"""
Structured logging system for Vantage security scanner.

Provides high-performance structured logging with:
- Configurable log levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)
- JSON output for log aggregation systems
- Performance metrics and timing decorators
- Audit trail with hash chain integrity

Example:
    from vantage_core.security.logging import LoggerFactory, LogCategory

    # Configure once at startup
    LoggerFactory.configure(log_level="INFO", json_output=True)

    # Get logger for a component
    logger = LoggerFactory.get_logger(LogCategory.SCANNER_ANALYSIS)
    logger.info("scan_started", file_count=42)

    # Use timing decorator
    from vantage_core.security.logging import timed

    @timed("analysis")
    def analyze_file(path):
        ...
"""

from vantage_core.security.logging.audit import (
    AuditEntry,
    AuditLogger,
    AuditStorage,
    FileAuditStorage,
)
from vantage_core.security.logging.categories import (
    AuditEventType,
    FilterReason,
    LogCategory,
    MetricUnit,
)
from vantage_core.security.logging.factory import (
    LoggerFactory,
    get_logger,
)
from vantage_core.security.logging.metrics import (
    MetricsCollector,
    ScanMetrics,
    log_memory_usage,
    measure_time,
    timed,
)

__all__ = [
    # Categories
    "AuditEventType",
    "FilterReason",
    "LogCategory",
    "MetricUnit",
    # Factory
    "LoggerFactory",
    "get_logger",
    # Metrics
    "MetricsCollector",
    "ScanMetrics",
    "log_memory_usage",
    "measure_time",
    "timed",
    # Audit
    "AuditEntry",
    "AuditLogger",
    "AuditStorage",
    "FileAuditStorage",
]
