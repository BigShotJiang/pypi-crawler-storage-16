"""
Webhook Notification System for Vantage Security Scanner.

This module provides webhook functionality for notifying external systems
about security scan events, vulnerabilities, and score changes.
"""

from .webhooks import (
    WebhookConfig,
    WebhookConfigurationError,
    WebhookDeliveryError,
    WebhookError,
    WebhookEvent,
    WebhookManager,
)

__all__ = [
    "WebhookConfig",
    "WebhookEvent",
    "WebhookManager",
    "WebhookError",
    "WebhookDeliveryError",
    "WebhookConfigurationError",
]
