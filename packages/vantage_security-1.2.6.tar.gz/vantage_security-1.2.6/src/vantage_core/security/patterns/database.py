"""
AST Pattern Database for Vulnerability Detection.

US-118: AST Pattern Database - Extensible vulnerability pattern matching
for detecting security issues in agent code.

Provides a database of vulnerability patterns that can be matched
against Python AST nodes to identify security issues.
"""

import ast
import re
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from vantage_core.security.models import (
    OWASPCategory,
    Severity,
    VulnerabilityCategory,
)


class PatternType(str, Enum):
    """Types of vulnerability patterns."""

    FUNCTION_CALL = "function_call"
    ATTRIBUTE_ACCESS = "attribute_access"
    STRING_PATTERN = "string_pattern"
    ASSIGNMENT = "assignment"
    IMPORT = "import"
    CLASS_DEFINITION = "class_definition"
    CONTROL_FLOW = "control_flow"


@dataclass
class VulnerabilityPattern:
    """
    Defines a vulnerability pattern for AST matching.

    Each pattern specifies what to look for and how to report it.
    """

    id: str
    name: str
    description: str
    pattern_type: PatternType
    severity: Severity
    owasp_category: OWASPCategory
    vulnerability_category: VulnerabilityCategory

    # Pattern matching criteria
    match_criteria: dict[str, Any] = field(default_factory=dict)

    # Context requirements
    requires_context: list[str] = field(default_factory=list)
    excludes_context: list[str] = field(default_factory=list)

    # Confidence modifiers
    confidence_base: float = 0.7
    confidence_modifiers: dict[str, float] = field(default_factory=dict)

    # Remediation
    recommendation: str = ""
    cwe_id: str | None = None

    # Custom matcher
    custom_matcher: Callable | None = None


@dataclass
class PatternMatch:
    """
    Result of a pattern match against source code.

    Contains the matched pattern, location, and context.
    """

    pattern_id: str
    pattern_name: str
    file_path: str
    line_number: int
    code_snippet: str
    confidence: float
    severity: Severity
    owasp_category: OWASPCategory
    vulnerability_category: VulnerabilityCategory
    recommendation: str
    context: dict[str, Any] = field(default_factory=dict)
    evidence: list[str] = field(default_factory=list)


class PatternDatabase:
    """
    Database of vulnerability patterns.

    Provides built-in patterns for common vulnerabilities and
    allows adding custom patterns.
    """

    def __init__(self):
        """Initialize the pattern database with built-in patterns."""
        self._patterns: dict[str, VulnerabilityPattern] = {}
        self._load_builtin_patterns()

    def get_pattern(self, pattern_id: str) -> VulnerabilityPattern | None:
        """Get a pattern by ID."""
        return self._patterns.get(pattern_id)

    def get_all_patterns(self) -> list[VulnerabilityPattern]:
        """Get all registered patterns."""
        return list(self._patterns.values())

    def get_patterns_by_type(self, pattern_type: PatternType) -> list[VulnerabilityPattern]:
        """Get patterns of a specific type."""
        return [p for p in self._patterns.values() if p.pattern_type == pattern_type]

    def get_patterns_by_owasp(self, category: OWASPCategory) -> list[VulnerabilityPattern]:
        """Get patterns for an OWASP category."""
        return [p for p in self._patterns.values() if p.owasp_category == category]

    def add_pattern(self, pattern: VulnerabilityPattern):
        """Add a custom pattern to the database."""
        self._patterns[pattern.id] = pattern

    def _load_builtin_patterns(self):
        """Load built-in vulnerability patterns."""

        # Prompt Injection Patterns
        self._patterns["PROMPT-001"] = VulnerabilityPattern(
            id="PROMPT-001",
            name="Direct User Input in Prompt",
            description="User input directly concatenated into prompt without sanitization",
            pattern_type=PatternType.STRING_PATTERN,
            severity=Severity.HIGH,
            owasp_category=OWASPCategory.LLM01,
            vulnerability_category=VulnerabilityCategory.PROMPT_INJECTION,
            match_criteria={
                "patterns": [
                    r"f['\"].*\{.*user.*\}.*['\"]",
                    r"\.format\(.*user",
                    r"\+\s*user_input",
                    r"prompt\s*=.*\+.*input",
                ]
            },
            confidence_base=0.8,
            recommendation="Sanitize user input before including in prompts. "
            "Use parameterized prompts or input validation.",
            cwe_id="CWE-77",
        )

        self._patterns["PROMPT-002"] = VulnerabilityPattern(
            id="PROMPT-002",
            name="Eval with User Data",
            description="Use of eval() or exec() with potentially untrusted data",
            pattern_type=PatternType.FUNCTION_CALL,
            severity=Severity.CRITICAL,
            owasp_category=OWASPCategory.LLM01,
            vulnerability_category=VulnerabilityCategory.CODE_EXECUTION,
            match_criteria={
                "function_names": ["eval", "exec", "compile"],
            },
            confidence_base=0.9,
            recommendation="Never use eval/exec with untrusted data. "
            "Use safe alternatives like ast.literal_eval() for simple cases.",
            cwe_id="CWE-95",
        )

        # Insecure Output Handling
        self._patterns["OUTPUT-001"] = VulnerabilityPattern(
            id="OUTPUT-001",
            name="Unvalidated LLM Output Execution",
            description="LLM output executed as code without validation",
            pattern_type=PatternType.FUNCTION_CALL,
            severity=Severity.CRITICAL,
            owasp_category=OWASPCategory.LLM02,
            vulnerability_category=VulnerabilityCategory.CODE_EXECUTION,
            match_criteria={
                "patterns": [
                    r"exec\(.*response",
                    r"eval\(.*output",
                    r"subprocess.*shell=True.*response",
                ]
            },
            confidence_base=0.85,
            recommendation="Validate and sanitize LLM outputs before execution. "
            "Implement output parsing with strict schemas.",
            cwe_id="CWE-94",
        )

        # Data Leakage Patterns
        self._patterns["LEAK-001"] = VulnerabilityPattern(
            id="LEAK-001",
            name="Hardcoded Secrets",
            description="Hardcoded API keys, passwords, or tokens in source code",
            pattern_type=PatternType.STRING_PATTERN,
            severity=Severity.HIGH,
            owasp_category=OWASPCategory.LLM06,
            vulnerability_category=VulnerabilityCategory.HARDCODED_SECRET,
            match_criteria={
                "patterns": [
                    r"api_key\s*=\s*['\"][A-Za-z0-9_-]{20,}['\"]",
                    r"password\s*=\s*['\"][^'\"]+['\"]",
                    r"secret\s*=\s*['\"][^'\"]+['\"]",
                    r"token\s*=\s*['\"][A-Za-z0-9_-]{20,}['\"]",
                    r"sk-[A-Za-z0-9]{20,}",  # OpenAI keys
                    r"AKIA[A-Z0-9]{16}",  # AWS keys
                ]
            },
            confidence_base=0.9,
            recommendation="Remove hardcoded secrets. Use environment variables "
            "or secure secret management systems.",
            cwe_id="CWE-798",
        )

        self._patterns["LEAK-002"] = VulnerabilityPattern(
            id="LEAK-002",
            name="Sensitive Data Logging",
            description="Logging of potentially sensitive data",
            pattern_type=PatternType.FUNCTION_CALL,
            severity=Severity.MEDIUM,
            owasp_category=OWASPCategory.LLM06,
            vulnerability_category=VulnerabilityCategory.DATA_LEAKAGE,
            match_criteria={
                "function_patterns": [
                    r"logger?\.(debug|info|warning|error)\(.*password",
                    r"print\(.*secret",
                    r"logger?\.\w+\(.*token",
                ]
            },
            confidence_base=0.7,
            recommendation="Avoid logging sensitive data. Implement log sanitization "
            "or use structured logging with data masking.",
            cwe_id="CWE-532",
        )

        # Excessive Agency Patterns
        self._patterns["AGENCY-001"] = VulnerabilityPattern(
            id="AGENCY-001",
            name="Unrestricted Tool Access",
            description="Agent has access to dangerous tools without restrictions",
            pattern_type=PatternType.FUNCTION_CALL,
            severity=Severity.HIGH,
            owasp_category=OWASPCategory.LLM08,
            vulnerability_category=VulnerabilityCategory.EXCESSIVE_AGENCY,
            match_criteria={
                "patterns": [
                    r"allow_dangerous_requests\s*=\s*True",
                    r"run_manager.*all",
                    r"shell\s*=\s*True",
                ]
            },
            confidence_base=0.75,
            recommendation="Implement least-privilege access controls for tools. "
            "Use allowlists instead of denylists.",
            cwe_id="CWE-250",
        )

        self._patterns["AGENCY-002"] = VulnerabilityPattern(
            id="AGENCY-002",
            name="Unrestricted Delegation",
            description="Agent can delegate to any other agent without restrictions",
            pattern_type=PatternType.ATTRIBUTE_ACCESS,
            severity=Severity.MEDIUM,
            owasp_category=OWASPCategory.LLM08,
            vulnerability_category=VulnerabilityCategory.UNSAFE_DELEGATION,
            match_criteria={
                "patterns": [
                    r"allow_delegation\s*=\s*True",
                    r"delegate_to\s*=\s*['\"].*['\"]",
                ]
            },
            confidence_base=0.6,
            recommendation="Restrict delegation to specific trusted agents. "
            "Implement delegation approval workflows.",
            cwe_id="CWE-269",
        )

        # Insecure Plugin Patterns
        self._patterns["PLUGIN-001"] = VulnerabilityPattern(
            id="PLUGIN-001",
            name="Insecure Plugin Loading",
            description="Loading plugins from untrusted sources",
            pattern_type=PatternType.IMPORT,
            severity=Severity.HIGH,
            owasp_category=OWASPCategory.LLM07,
            vulnerability_category=VulnerabilityCategory.INSECURE_TOOL_USE,
            match_criteria={
                "patterns": [
                    r"importlib\.import_module\(.*input",
                    r"__import__\(.*user",
                    r"exec\(.*import",
                ]
            },
            confidence_base=0.8,
            recommendation="Only load plugins from trusted, verified sources. "
            "Implement plugin signing and verification.",
            cwe_id="CWE-829",
        )

        # Configuration Weakness Patterns
        self._patterns["CONFIG-001"] = VulnerabilityPattern(
            id="CONFIG-001",
            name="Debug Mode Enabled",
            description="Debug mode enabled in production configuration",
            pattern_type=PatternType.STRING_PATTERN,
            severity=Severity.MEDIUM,
            owasp_category=OWASPCategory.LLM06,
            vulnerability_category=VulnerabilityCategory.CONFIGURATION_WEAKNESS,
            match_criteria={
                "patterns": [
                    r"debug\s*=\s*True",
                    r"DEBUG\s*=\s*True",
                    r"verbose\s*=\s*True",
                ]
            },
            confidence_base=0.6,
            recommendation="Disable debug mode in production. "
            "Use environment-specific configurations.",
            cwe_id="CWE-489",
        )

        self._patterns["CONFIG-002"] = VulnerabilityPattern(
            id="CONFIG-002",
            name="High Temperature Setting",
            description="LLM temperature set very high, reducing predictability",
            pattern_type=PatternType.ASSIGNMENT,
            severity=Severity.LOW,
            owasp_category=OWASPCategory.LLM09,
            vulnerability_category=VulnerabilityCategory.CONFIGURATION_WEAKNESS,
            match_criteria={
                "patterns": [
                    r"temperature\s*=\s*[0-9]*\.?[89]|1\.0",
                ]
            },
            confidence_base=0.5,
            recommendation="Use lower temperature settings for predictable behavior. "
            "Consider temperature 0.0-0.3 for deterministic tasks.",
        )

        # SQL Injection
        self._patterns["SQL-001"] = VulnerabilityPattern(
            id="SQL-001",
            name="SQL Injection Risk",
            description="String formatting used in SQL queries",
            pattern_type=PatternType.STRING_PATTERN,
            severity=Severity.CRITICAL,
            owasp_category=OWASPCategory.LLM02,
            vulnerability_category=VulnerabilityCategory.CODE_EXECUTION,
            match_criteria={
                "patterns": [
                    r"execute\(['\"].*%s.*['\"].*%",
                    r"f['\"]SELECT.*\{.*\}",
                    r"['\"].*SELECT.*['\"].*\+",
                ]
            },
            confidence_base=0.85,
            recommendation="Use parameterized queries or ORM methods. "
            "Never concatenate user input into SQL strings.",
            cwe_id="CWE-89",
        )


class PatternMatcher:
    """
    Match vulnerability patterns against source code.

    Uses AST parsing and regex matching to identify potential vulnerabilities.
    """

    def __init__(self, database: PatternDatabase | None = None):
        """
        Initialize the pattern matcher.

        Args:
            database: Pattern database to use (creates default if None)
        """
        self.database = database or PatternDatabase()

    def match_file(self, file_path: str, source_code: str) -> list[PatternMatch]:
        """
        Match patterns against a source file.

        Args:
            file_path: Path to the source file
            source_code: Source code content

        Returns:
            List of PatternMatch objects
        """
        matches = []

        # Parse AST
        try:
            tree = ast.parse(source_code)
        except SyntaxError:
            # Fall back to regex-only matching
            return self._match_regex_only(file_path, source_code)

        # Get source lines for snippet extraction
        lines = source_code.split("\n")

        # Match each pattern
        for pattern in self.database.get_all_patterns():
            pattern_matches = self._match_pattern(pattern, tree, file_path, source_code, lines)
            matches.extend(pattern_matches)

        return matches

    def match_ast_node(
        self, pattern: VulnerabilityPattern, node: ast.AST, context: dict[str, Any]
    ) -> bool:
        """
        Check if an AST node matches a pattern.

        Args:
            pattern: Pattern to match
            node: AST node to check
            context: Current context information

        Returns:
            True if pattern matches
        """
        # Use custom matcher if provided
        if pattern.custom_matcher:
            return pattern.custom_matcher(node, context)

        # Match by pattern type
        if pattern.pattern_type == PatternType.FUNCTION_CALL:
            return self._match_function_call(pattern, node)
        elif pattern.pattern_type == PatternType.ATTRIBUTE_ACCESS:
            return self._match_attribute(pattern, node)
        elif pattern.pattern_type == PatternType.ASSIGNMENT:
            return self._match_assignment(pattern, node)
        elif pattern.pattern_type == PatternType.IMPORT:
            return self._match_import(pattern, node)

        return False

    def _match_pattern(
        self,
        pattern: VulnerabilityPattern,
        tree: ast.AST,
        file_path: str,
        source_code: str,
        lines: list[str],
    ) -> list[PatternMatch]:
        """Match a single pattern against the AST and source."""
        matches = []

        # Regex-based matching for string patterns
        if pattern.pattern_type == PatternType.STRING_PATTERN:
            for regex in pattern.match_criteria.get("patterns", []):
                for i, line in enumerate(lines):
                    if re.search(regex, line):
                        match = PatternMatch(
                            pattern_id=pattern.id,
                            pattern_name=pattern.name,
                            file_path=file_path,
                            line_number=i + 1,
                            code_snippet=line.strip(),
                            confidence=pattern.confidence_base,
                            severity=pattern.severity,
                            owasp_category=pattern.owasp_category,
                            vulnerability_category=pattern.vulnerability_category,
                            recommendation=pattern.recommendation,
                            evidence=[f"Matched pattern: {regex}"],
                        )
                        matches.append(match)

        # AST-based matching
        for node in ast.walk(tree):
            if self.match_ast_node(pattern, node, {}):
                line_num = getattr(node, "lineno", 1)
                snippet = lines[line_num - 1].strip() if line_num <= len(lines) else ""

                match = PatternMatch(
                    pattern_id=pattern.id,
                    pattern_name=pattern.name,
                    file_path=file_path,
                    line_number=line_num,
                    code_snippet=snippet,
                    confidence=pattern.confidence_base,
                    severity=pattern.severity,
                    owasp_category=pattern.owasp_category,
                    vulnerability_category=pattern.vulnerability_category,
                    recommendation=pattern.recommendation,
                    evidence=[f"AST match: {type(node).__name__}"],
                )
                matches.append(match)

        return matches

    def _match_function_call(self, pattern: VulnerabilityPattern, node: ast.AST) -> bool:
        """Match a function call pattern."""
        if not isinstance(node, ast.Call):
            return False

        # Get function name
        func_name = None
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = node.func.attr

        if not func_name:
            return False

        # Check against function names
        if "function_names" in pattern.match_criteria:
            if func_name in pattern.match_criteria["function_names"]:
                return True

        return False

    def _match_attribute(self, pattern: VulnerabilityPattern, node: ast.AST) -> bool:
        """Match an attribute access pattern."""
        if not isinstance(node, ast.Attribute):
            return False

        # Check patterns
        for regex in pattern.match_criteria.get("patterns", []):
            attr_str = f"{node.attr}"
            if re.search(regex, attr_str):
                return True

        return False

    def _match_assignment(self, pattern: VulnerabilityPattern, node: ast.AST) -> bool:
        """Match an assignment pattern."""
        if not isinstance(node, ast.Assign):
            return False

        # Get assignment as string for regex matching
        # This is a simplified check
        for target in node.targets:
            if isinstance(target, ast.Name):
                for regex in pattern.match_criteria.get("patterns", []):
                    if re.search(regex, target.id):
                        return True

        return False

    def _match_import(self, pattern: VulnerabilityPattern, node: ast.AST) -> bool:
        """Match an import pattern."""
        if isinstance(node, ast.Import):
            for alias in node.names:
                for regex in pattern.match_criteria.get("patterns", []):
                    if re.search(regex, alias.name):
                        return True
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            for regex in pattern.match_criteria.get("patterns", []):
                if re.search(regex, module):
                    return True

        return False

    def _match_regex_only(self, file_path: str, source_code: str) -> list[PatternMatch]:
        """Fall back to regex-only matching when AST parsing fails."""
        matches = []
        lines = source_code.split("\n")

        for pattern in self.database.get_all_patterns():
            if pattern.pattern_type == PatternType.STRING_PATTERN:
                for regex in pattern.match_criteria.get("patterns", []):
                    for i, line in enumerate(lines):
                        if re.search(regex, line):
                            match = PatternMatch(
                                pattern_id=pattern.id,
                                pattern_name=pattern.name,
                                file_path=file_path,
                                line_number=i + 1,
                                code_snippet=line.strip(),
                                confidence=pattern.confidence_base * 0.8,  # Lower confidence
                                severity=pattern.severity,
                                owasp_category=pattern.owasp_category,
                                vulnerability_category=pattern.vulnerability_category,
                                recommendation=pattern.recommendation,
                                evidence=[f"Regex match (AST unavailable): {regex}"],
                            )
                            matches.append(match)

        return matches


def scan_for_patterns(file_path: str, source_code: str) -> list[PatternMatch]:
    """
    Convenience function to scan source code for vulnerability patterns.

    Args:
        file_path: Path to the source file
        source_code: Source code content

    Returns:
        List of PatternMatch objects
    """
    matcher = PatternMatcher()
    return matcher.match_file(file_path, source_code)
