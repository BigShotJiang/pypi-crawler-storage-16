"""
OpenAI Security Scanner.

Detects OpenAI Assistants, function definitions, and chat patterns in OpenAI-based projects.
"""

import ast
import time
from pathlib import Path

from vantage_core.security.models import (
    AgentCommunication,
    CommunicationType,
    ContentType,
    SecurityAgent,
    SecurityFinding,
    SecurityScanResult,
    SecurityTool,
    ToolCategory,
    TrustLevel,
)
from vantage_core.security.scanners.base import SecurityScanner


class OpenAISecurityScanner(SecurityScanner):
    """
    Security scanner for OpenAI API.

    Detects:
    - Assistants API usage
    - Function definitions
    - Chat completions with tools
    """

    framework_name = "openai"

    def scan(self, path: Path) -> SecurityScanResult:
        """Scan OpenAI project for security issues."""
        start_time = time.time()
        findings: list[SecurityFinding] = []
        agents: list[SecurityAgent] = []
        communications: list[AgentCommunication] = []

        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()

                file_agents = self._extract_agents_from_file(file_path, code)
                agents.extend(file_agents)

                file_communications = self._extract_communications(file_path, code)
                communications.extend(file_communications)

                findings.extend(self.check_hardcoded_secrets(code, str(file_path)))
                findings.extend(self.check_dangerous_code_patterns(code, str(file_path)))

                for agent in file_agents:
                    agent_findings = self.get_vulnerabilities(agent)
                    findings.extend(agent_findings)

            except Exception:
                continue

        return self.create_scan_result(
            findings=findings,
            agents=agents,
            communications=communications,
            frameworks=["openai"],
            start_time=start_time,
        )

    def get_agents(self, path: Path) -> list[SecurityAgent]:
        """Extract OpenAI agents from path."""
        agents: list[SecurityAgent] = []
        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()
                agents.extend(self._extract_agents_from_file(file_path, code))
            except Exception:
                continue
        return agents

    def get_vulnerabilities(self, agent: SecurityAgent) -> list[SecurityFinding]:
        """Analyze OpenAI agent for vulnerabilities."""
        findings: list[SecurityFinding] = []
        file_path = agent.file_path or "unknown"
        line_number = agent.line_number or 1

        if agent.system_prompt:
            finding = self.check_prompt_injection_risk(
                agent.system_prompt, file_path, line_number, agent.id
            )
            if finding:
                findings.append(finding)

        return findings

    def _extract_agents_from_file(self, file_path: Path, code: str) -> list[SecurityAgent]:
        """Extract OpenAI agents from a single file."""
        agents: list[SecurityAgent] = []
        tree = ast.parse(code)

        class AgentVisitor(ast.NodeVisitor):
            def __init__(self, scanner: OpenAISecurityScanner):
                self.scanner = scanner
                self.agents: list[SecurityAgent] = []

            def visit_Call(self, node: ast.Call) -> None:
                func_name = self._get_func_name(node)

                # beta.assistants.create
                if "assistants.create" in func_name:
                    agent = self._extract_assistant(node)
                    if agent:
                        self.agents.append(agent)

                # chat.completions.create
                elif "completions.create" in func_name:
                    agent = self._extract_chat_completion(node)
                    if agent:
                        self.agents.append(agent)

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return self._get_attr_name(node.func)
                return ""

            def _get_attr_name(self, node: ast.Attribute) -> str:
                if isinstance(node.value, ast.Name):
                    return f"{node.value.id}.{node.attr}"
                elif isinstance(node.value, ast.Attribute):
                    return f"{self._get_attr_name(node.value)}.{node.attr}"
                return node.attr

            def _extract_assistant(self, node: ast.Call) -> SecurityAgent | None:
                name = "OpenAI Assistant"
                instructions = None
                tools: list[SecurityTool] = []

                for keyword in node.keywords:
                    if keyword.arg == "name":
                        if isinstance(keyword.value, ast.Constant):
                            name = str(keyword.value.value)
                    elif keyword.arg == "instructions":
                        if isinstance(keyword.value, ast.Constant):
                            instructions = str(keyword.value.value)
                    elif keyword.arg == "tools":
                        tools = self._extract_tools(keyword.value)

                agent_id = f"openai-assistant-{name}-{node.lineno}"

                return SecurityAgent(
                    id=agent_id,
                    name=name,
                    framework="openai",
                    system_prompt=instructions,
                    tools=tools,
                    file_path=str(file_path),
                    line_number=node.lineno,
                    trust_level=self.scanner.infer_trust_level(
                        {"name": name, "system_prompt": instructions or ""}
                    ),
                    metadata={"type": "assistant"},
                )

            def _extract_chat_completion(self, node: ast.Call) -> SecurityAgent | None:
                name = "ChatCompletion"
                system_prompt = None
                tools: list[SecurityTool] = []

                for keyword in node.keywords:
                    if keyword.arg == "messages":
                        # Try to extract system message
                        if isinstance(keyword.value, ast.List):
                            for msg in keyword.value.elts:
                                if isinstance(msg, ast.Dict):
                                    role = None
                                    content = None
                                    for k, v in zip(msg.keys, msg.values):
                                        if isinstance(k, ast.Constant):
                                            if k.value == "role" and isinstance(v, ast.Constant):
                                                role = v.value
                                            elif k.value == "content" and isinstance(
                                                v, ast.Constant
                                            ):
                                                content = v.value
                                    if role == "system" and content:
                                        system_prompt = content
                    elif keyword.arg == "tools":
                        tools = self._extract_tools(keyword.value)
                    elif keyword.arg == "model":
                        if isinstance(keyword.value, ast.Constant):
                            name = f"ChatCompletion ({keyword.value.value})"

                agent_id = f"openai-chat-{node.lineno}"

                return SecurityAgent(
                    id=agent_id,
                    name=name,
                    framework="openai",
                    system_prompt=system_prompt,
                    tools=tools,
                    file_path=str(file_path),
                    line_number=node.lineno,
                    trust_level=self.scanner.infer_trust_level(
                        {"name": name, "system_prompt": system_prompt or ""}
                    ),
                    metadata={"type": "chat_completion"},
                )

            def _extract_tools(self, node: ast.AST) -> list[SecurityTool]:
                tools: list[SecurityTool] = []
                if isinstance(node, ast.List):
                    for elt in node.elts:
                        if isinstance(elt, ast.Dict):
                            tool_type = None
                            function_name = "unknown"
                            for k, v in zip(elt.keys, elt.values):
                                if isinstance(k, ast.Constant):
                                    if k.value == "type" and isinstance(v, ast.Constant):
                                        tool_type = v.value
                                    elif k.value == "function" and isinstance(v, ast.Dict):
                                        for fk, fv in zip(v.keys, v.values):
                                            if isinstance(fk, ast.Constant) and fk.value == "name":
                                                if isinstance(fv, ast.Constant):
                                                    function_name = fv.value

                            # Determine tool category and risk
                            categories = [ToolCategory.API]
                            if tool_type == "code_interpreter":
                                categories = [ToolCategory.CODE_EXECUTION]
                            elif tool_type == "retrieval":
                                categories = [ToolCategory.DATABASE]

                            tools.append(
                                SecurityTool(
                                    name=function_name,
                                    description=f"OpenAI tool: {function_name}",
                                    categories=categories,
                                    required_trust_level=TrustLevel.INTERNAL,
                                )
                            )
                return tools

        visitor = AgentVisitor(self)
        visitor.visit(tree)
        return visitor.agents

    def _extract_communications(self, file_path: Path, code: str) -> list[AgentCommunication]:
        """Extract communications from OpenAI code."""
        communications: list[AgentCommunication] = []
        tree = ast.parse(code)

        class CommunicationVisitor(ast.NodeVisitor):
            def __init__(self):
                self.comms: list[AgentCommunication] = []

            def visit_Call(self, node: ast.Call) -> None:
                func_name = self._get_func_name(node)

                # assistants.create or completions.create with tools
                if "create" in func_name:
                    agent_name = "OpenAI Agent"
                    tools = []

                    for keyword in node.keywords:
                        if keyword.arg == "name" and isinstance(keyword.value, ast.Constant):
                            agent_name = str(keyword.value.value)
                        elif keyword.arg == "tools":
                            tools = self._extract_tool_names(keyword.value)

                    agent_id = f"openai-{agent_name}-{node.lineno}"

                    for tool in tools:
                        # Agent -> Tool
                        self.comms.append(
                            AgentCommunication(
                                source_id=agent_id,
                                target_id=tool,
                                communication_type=CommunicationType.DELEGATION.value,
                                metadata={
                                    "protocol": "tool_call",
                                    "content_type": ContentType.TEXT.value,
                                    "file_path": str(file_path),
                                    "line_number": node.lineno,
                                },
                            )
                        )

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return self._get_attr_name(node.func)
                return ""

            def _get_attr_name(self, node: ast.Attribute) -> str:
                if isinstance(node.value, ast.Name):
                    return f"{node.value.id}.{node.attr}"
                elif isinstance(node.value, ast.Attribute):
                    return f"{self._get_attr_name(node.value)}.{node.attr}"
                return node.attr

            def _extract_tool_names(self, node: ast.AST) -> list[str]:
                names = []
                if isinstance(node, ast.List):
                    for elt in node.elts:
                        if isinstance(elt, ast.Dict):
                            for k, v in zip(elt.keys, elt.values):
                                if isinstance(k, ast.Constant) and k.value == "function":
                                    if isinstance(v, ast.Dict):
                                        for fk, fv in zip(v.keys, v.values):
                                            if isinstance(fk, ast.Constant) and fk.value == "name":
                                                if isinstance(fv, ast.Constant):
                                                    names.append(fv.value)
                                elif isinstance(k, ast.Constant) and k.value == "type":
                                    if isinstance(v, ast.Constant):
                                        if v.value in ["code_interpreter", "retrieval"]:
                                            names.append(v.value)
                return names

        visitor = CommunicationVisitor()
        visitor.visit(tree)
        return visitor.comms

    @classmethod
    def can_handle(cls, path: Path) -> bool:
        """Check if this scanner can handle OpenAI projects."""
        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    content = f.read()
                    if any(x in content for x in ["from openai", "import openai"]):
                        return True
            except Exception:
                continue

        return False
