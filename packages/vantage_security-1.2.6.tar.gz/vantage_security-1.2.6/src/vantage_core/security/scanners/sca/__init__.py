"""
Software Composition Analysis (SCA) scanner.

This module provides dependency vulnerability scanning using:
- OSV (Open Source Vulnerabilities) database
- NVD (National Vulnerability Database)
- GitHub Advisory Database
"""

from vantage_core.security.scanners.sca.osv_client import (
    OSVClient,
    OSVVulnerability,
)
from vantage_core.security.scanners.sca.scanner import (
    Dependency,
    DependencyVulnerability,
    SCAResult,
    SCAScanner,
)

__all__ = [
    "SCAScanner",
    "DependencyVulnerability",
    "Dependency",
    "SCAResult",
    "OSVClient",
    "OSVVulnerability",
]
