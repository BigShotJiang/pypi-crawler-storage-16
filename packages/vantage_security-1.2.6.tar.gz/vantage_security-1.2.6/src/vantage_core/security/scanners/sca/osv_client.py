"""
OSV (Open Source Vulnerabilities) API client.

Provides integration with the OSV database for vulnerability lookup.
https://osv.dev/
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

import httpx


@dataclass
class OSVVulnerability:
    """Represents a vulnerability from OSV."""

    id: str
    summary: str
    details: str
    aliases: list[str] = field(default_factory=list)
    severity: str = "UNKNOWN"
    cvss_score: float | None = None
    affected_versions: list[str] = field(default_factory=list)
    fixed_versions: list[str] = field(default_factory=list)
    references: list[str] = field(default_factory=list)
    published: datetime | None = None
    modified: datetime | None = None

    @classmethod
    def from_osv_response(cls, data: dict[str, Any]) -> "OSVVulnerability":
        """Create from OSV API response."""
        # Extract severity from CVSS if available
        severity = "UNKNOWN"
        cvss_score = None

        if "severity" in data:
            for sev in data["severity"]:
                if sev.get("type") == "CVSS_V3":
                    score_str = sev.get("score", "")
                    try:
                        # Parse CVSS vector to get score
                        if "CVSS:3" in score_str:
                            # Extract base score from vector
                            cvss_score = cls._parse_cvss_score(score_str)
                            severity = cls._score_to_severity(cvss_score)
                    except Exception:
                        pass

        # Extract affected and fixed versions
        affected_versions = []
        fixed_versions = []

        for affected in data.get("affected", []):
            for version_range in affected.get("ranges", []):
                for event in version_range.get("events", []):
                    if "introduced" in event:
                        affected_versions.append(f">={event['introduced']}")
                    if "fixed" in event:
                        fixed_versions.append(event["fixed"])

            # Also check explicit versions
            for version in affected.get("versions", []):
                affected_versions.append(version)

        # Extract references
        references = [ref.get("url", "") for ref in data.get("references", [])]

        # Parse dates
        published = None
        modified = None
        if "published" in data:
            try:
                published = datetime.fromisoformat(data["published"].replace("Z", "+00:00"))
            except Exception:
                pass
        if "modified" in data:
            try:
                modified = datetime.fromisoformat(data["modified"].replace("Z", "+00:00"))
            except Exception:
                pass

        return cls(
            id=data.get("id", ""),
            summary=data.get("summary", ""),
            details=data.get("details", ""),
            aliases=data.get("aliases", []),
            severity=severity,
            cvss_score=cvss_score,
            affected_versions=affected_versions,
            fixed_versions=fixed_versions,
            references=references,
            published=published,
            modified=modified,
        )

    @staticmethod
    def _parse_cvss_score(vector: str) -> float:
        """Parse CVSS score from vector string."""
        # Simple extraction - in production, use a proper CVSS library
        # CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H
        # This is a simplified version - real implementation would calculate from vector
        parts = vector.split("/")
        score = 0.0

        # Simplified scoring based on key metrics
        for part in parts:
            if part.startswith("AV:N"):
                score += 2.0
            elif part.startswith("AC:L"):
                score += 1.5
            elif part.startswith("PR:N"):
                score += 1.5
            elif part.startswith("C:H"):
                score += 1.5
            elif part.startswith("I:H"):
                score += 1.5
            elif part.startswith("A:H"):
                score += 1.5

        return min(10.0, score)

    @staticmethod
    def _score_to_severity(score: float) -> str:
        """Convert CVSS score to severity string."""
        if score >= 9.0:
            return "CRITICAL"
        elif score >= 7.0:
            return "HIGH"
        elif score >= 4.0:
            return "MEDIUM"
        elif score > 0:
            return "LOW"
        return "UNKNOWN"


class OSVClient:
    """Client for the OSV API."""

    BASE_URL = "https://api.osv.dev/v1"

    def __init__(self, timeout: float = 30.0):
        """Initialize OSV client."""
        self._timeout = timeout
        self._client = httpx.Client(timeout=timeout)

    def query_package(
        self, ecosystem: str, package_name: str, version: str | None = None
    ) -> list[OSVVulnerability]:
        """
        Query OSV for vulnerabilities in a package.

        Args:
            ecosystem: Package ecosystem (PyPI, npm, etc.)
            package_name: Name of the package
            version: Specific version to check (optional)

        Returns:
            List of vulnerabilities affecting the package
        """
        payload: dict[str, Any] = {
            "package": {
                "ecosystem": ecosystem,
                "name": package_name,
            }
        }

        if version:
            payload["version"] = version

        try:
            response = self._client.post(f"{self.BASE_URL}/query", json=payload)
            response.raise_for_status()

            data = response.json()
            vulns = []

            for vuln_data in data.get("vulns", []):
                vulns.append(OSVVulnerability.from_osv_response(vuln_data))

            return vulns

        except httpx.HTTPError as e:
            # Log error but don't fail - return empty list
            print(f"OSV API error for {package_name}: {e}")
            return []

    def query_batch(self, packages: list[dict[str, str]]) -> dict[str, list[OSVVulnerability]]:
        """
        Query OSV for multiple packages at once.

        Args:
            packages: List of dicts with 'ecosystem', 'name', and optional 'version'

        Returns:
            Dict mapping package names to their vulnerabilities
        """
        results: dict[str, list[OSVVulnerability]] = {}

        # OSV supports batch queries
        queries = []
        for pkg in packages:
            query: dict[str, Any] = {
                "package": {
                    "ecosystem": pkg.get("ecosystem", "PyPI"),
                    "name": pkg["name"],
                }
            }
            if "version" in pkg:
                query["version"] = pkg["version"]
            queries.append(query)

        try:
            response = self._client.post(f"{self.BASE_URL}/querybatch", json={"queries": queries})
            response.raise_for_status()

            data = response.json()

            for i, result in enumerate(data.get("results", [])):
                pkg_name = packages[i]["name"]
                vulns = []
                for vuln_data in result.get("vulns", []):
                    vulns.append(OSVVulnerability.from_osv_response(vuln_data))
                results[pkg_name] = vulns

        except httpx.HTTPError as e:
            print(f"OSV batch query error: {e}")
            # Fall back to individual queries
            for pkg in packages:
                results[pkg["name"]] = self.query_package(
                    pkg.get("ecosystem", "PyPI"), pkg["name"], pkg.get("version")
                )

        return results

    def get_vulnerability(self, vuln_id: str) -> OSVVulnerability | None:
        """
        Get details for a specific vulnerability.

        Args:
            vuln_id: Vulnerability ID (e.g., GHSA-xxx or CVE-xxx)

        Returns:
            Vulnerability details or None if not found
        """
        try:
            response = self._client.get(f"{self.BASE_URL}/vulns/{vuln_id}")
            response.raise_for_status()

            return OSVVulnerability.from_osv_response(response.json())

        except httpx.HTTPError:
            return None

    def close(self):
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
