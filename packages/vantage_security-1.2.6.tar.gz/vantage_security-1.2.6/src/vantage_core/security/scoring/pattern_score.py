"""
Communication Pattern Score (US-123).

Scores the topology based on communication patterns,
identifying risky patterns like hub-and-spoke, mesh, chains, etc.
"""

from dataclasses import dataclass, field
from enum import Enum

from vantage_core.security.topology.graph import AgentGraph


class TopologyPattern(str, Enum):
    """Types of topology patterns."""

    HUB_AND_SPOKE = "hub_and_spoke"  # Single agent central to all comms
    MESH = "mesh"  # Fully connected
    CHAIN = "chain"  # Linear pipeline
    TREE = "tree"  # Hierarchical
    STAR = "star"  # Similar to hub, but more rigid
    RING = "ring"  # Circular dependencies
    ISOLATED = "isolated"  # Disconnected components
    BROADCAST = "broadcast"  # One-to-many pattern
    MINIMAL = "minimal"  # Very few connections


# Pattern risk scores (0-10, higher is riskier)
PATTERN_RISKS = {
    TopologyPattern.HUB_AND_SPOKE: 7.0,  # Single point of failure/attack
    TopologyPattern.MESH: 6.0,  # Large attack surface
    TopologyPattern.CHAIN: 4.0,  # Sequential risk propagation
    TopologyPattern.TREE: 3.0,  # Reasonable structure
    TopologyPattern.STAR: 6.5,  # Central risk
    TopologyPattern.RING: 8.0,  # Circular trust issues
    TopologyPattern.ISOLATED: 5.0,  # May miss communications
    TopologyPattern.BROADCAST: 7.5,  # Wide blast radius
    TopologyPattern.MINIMAL: 2.0,  # Limited exposure
}


@dataclass
class PatternScore:
    """
    Score based on communication pattern analysis.

    Higher score means better security posture.
    """

    score: float  # 0-100, higher is more secure
    detected_patterns: list[TopologyPattern]
    primary_pattern: TopologyPattern | None
    hub_nodes: list[str]  # Node IDs acting as hubs
    articulation_points: list[str]  # Single points of failure
    broadcast_sources: list[str]  # High fan-out nodes
    metrics: dict[str, float] = field(default_factory=dict)
    recommendations: list[str] = field(default_factory=list)


class CommunicationPatternScorer:
    """
    Scores topology based on communication patterns.

    Identifies risky patterns and calculates a security score
    based on topology structure.
    """

    def __init__(
        self,
        pattern_risks: dict[TopologyPattern, float] | None = None,
        hub_threshold: int = 3,
        broadcast_threshold: int = 3,
    ):
        """
        Initialize the scorer.

        Args:
            pattern_risks: Custom pattern risk scores
            hub_threshold: Minimum connections to be a hub
            broadcast_threshold: Minimum outgoing to be broadcast
        """
        self.pattern_risks = pattern_risks or PATTERN_RISKS
        self.hub_threshold = hub_threshold
        self.broadcast_threshold = broadcast_threshold

    def score(self, graph: AgentGraph) -> PatternScore:
        """
        Calculate communication pattern score.

        Args:
            graph: Agent topology graph

        Returns:
            PatternScore with details
        """
        if graph.node_count == 0:
            return PatternScore(
                score=100.0,
                detected_patterns=[],
                primary_pattern=None,
                hub_nodes=[],
                articulation_points=[],
                broadcast_sources=[],
            )

        # Analyze graph metrics
        metrics = self._compute_metrics(graph)

        # Detect patterns
        detected_patterns = self._detect_patterns(graph, metrics)

        # Identify risky nodes
        hub_nodes = [n.id for n in graph.get_hub_nodes(self.hub_threshold)]
        articulation_points = graph.get_articulation_points()
        broadcast_sources = self._find_broadcast_sources(graph)

        # Calculate score based on patterns and risky nodes
        total_risk = 0.0

        # Pattern-based risk
        for pattern in detected_patterns:
            total_risk += self.pattern_risks.get(pattern, 5.0)

        # Hub risk (normalized)
        if hub_nodes:
            hub_ratio = len(hub_nodes) / graph.node_count
            hub_risk = hub_ratio * 20.0  # Max 20 points for hubs
            total_risk += hub_risk
            metrics["hub_risk"] = round(hub_risk, 2)

        # Articulation point risk
        if articulation_points:
            ap_ratio = len(articulation_points) / graph.node_count
            ap_risk = ap_ratio * 25.0  # Max 25 points for SPOFs
            total_risk += ap_risk
            metrics["articulation_risk"] = round(ap_risk, 2)

        # Broadcast risk
        if broadcast_sources:
            broadcast_ratio = len(broadcast_sources) / graph.node_count
            broadcast_risk = broadcast_ratio * 15.0
            total_risk += broadcast_risk
            metrics["broadcast_risk"] = round(broadcast_risk, 2)

        # Calculate final score
        score = max(0.0, 100.0 - min(total_risk, 100.0))

        # Determine primary pattern
        primary_pattern = None
        if detected_patterns:
            # Sort by risk, highest first
            sorted_patterns = sorted(
                detected_patterns,
                key=lambda p: self.pattern_risks.get(p, 0),
                reverse=True,
            )
            primary_pattern = sorted_patterns[0]

        # Generate recommendations
        recommendations = self._generate_recommendations(
            detected_patterns,
            hub_nodes,
            articulation_points,
            broadcast_sources,
            graph,
        )

        return PatternScore(
            score=round(score, 2),
            detected_patterns=detected_patterns,
            primary_pattern=primary_pattern,
            hub_nodes=hub_nodes,
            articulation_points=articulation_points,
            broadcast_sources=broadcast_sources,
            metrics=metrics,
            recommendations=recommendations,
        )

    def _compute_metrics(self, graph: AgentGraph) -> dict[str, float]:
        """Compute graph metrics for pattern detection."""
        metrics = {}

        n = graph.node_count
        e = graph.edge_count

        # Density: actual edges / possible edges
        max_edges = n * (n - 1)  # Directed graph
        metrics["density"] = round(e / max_edges if max_edges > 0 else 0.0, 3)

        # Centrality metrics
        centrality = graph.compute_centrality()
        if centrality:
            avg_centrality = sum(centrality.values()) / len(centrality)
            max_centrality = max(centrality.values())
            metrics["avg_centrality"] = round(avg_centrality, 3)
            metrics["max_centrality"] = round(max_centrality, 3)
            metrics["centrality_variance"] = round(
                sum((c - avg_centrality) ** 2 for c in centrality.values()) / len(centrality),
                3,
            )

        # Degree statistics
        in_degrees = [node.in_degree for node in graph.nodes]
        out_degrees = [node.out_degree for node in graph.nodes]

        if in_degrees:
            metrics["max_in_degree"] = max(in_degrees)
            metrics["avg_in_degree"] = round(sum(in_degrees) / len(in_degrees), 2)
        if out_degrees:
            metrics["max_out_degree"] = max(out_degrees)
            metrics["avg_out_degree"] = round(sum(out_degrees) / len(out_degrees), 2)

        return metrics

    def _detect_patterns(
        self,
        graph: AgentGraph,
        metrics: dict[str, float],
    ) -> list[TopologyPattern]:
        """Detect topology patterns based on metrics."""
        patterns = []
        n = graph.node_count

        # Check density for mesh
        density = metrics.get("density", 0)
        if density > 0.7:
            patterns.append(TopologyPattern.MESH)
        elif density < 0.2:
            patterns.append(TopologyPattern.MINIMAL)

        # Check for hub-and-spoke
        max_centrality = metrics.get("max_centrality", 0)
        centrality_variance = metrics.get("centrality_variance", 0)
        if max_centrality > 0.5 and centrality_variance > 0.1:
            patterns.append(TopologyPattern.HUB_AND_SPOKE)

        # Check for star pattern
        max_in = metrics.get("max_in_degree", 0)
        max_out = metrics.get("max_out_degree", 0)
        if max_in >= n - 1 or max_out >= n - 1:
            patterns.append(TopologyPattern.STAR)

        # Check for broadcast
        if max_out >= self.broadcast_threshold and max_out > n * 0.5:
            patterns.append(TopologyPattern.BROADCAST)

        # Check for chain/linear
        avg_in = metrics.get("avg_in_degree", 0)
        avg_out = metrics.get("avg_out_degree", 0)
        if 0.8 <= avg_in <= 1.2 and 0.8 <= avg_out <= 1.2:
            patterns.append(TopologyPattern.CHAIN)

        # Check for ring (cycles)
        if self._has_cycles(graph):
            patterns.append(TopologyPattern.RING)

        # Check for tree structure
        if graph.edge_count == n - 1 and not self._has_cycles(graph):
            patterns.append(TopologyPattern.TREE)

        # Check for isolated components
        if self._has_isolated_components(graph):
            patterns.append(TopologyPattern.ISOLATED)

        return patterns

    def _has_cycles(self, graph: AgentGraph) -> bool:
        """Check if graph has cycles."""
        visited = set()
        rec_stack = set()

        def dfs(node_id: str) -> bool:
            visited.add(node_id)
            rec_stack.add(node_id)

            for neighbor in graph.get_neighbors(node_id):
                if neighbor not in visited:
                    if dfs(neighbor):
                        return True
                elif neighbor in rec_stack:
                    return True

            rec_stack.discard(node_id)
            return False

        for node in graph.nodes:
            if node.id not in visited:
                if dfs(node.id):
                    return True

        return False

    def _has_isolated_components(self, graph: AgentGraph) -> bool:
        """Check if graph has multiple disconnected components."""
        if graph.node_count <= 1:
            return False

        visited = set()

        def dfs(node_id: str):
            visited.add(node_id)
            for neighbor in graph.get_neighbors(node_id):
                if neighbor not in visited:
                    dfs(neighbor)
            for predecessor in graph.get_predecessors(node_id):
                if predecessor not in visited:
                    dfs(predecessor)

        # Start from first node
        first_node = list(graph._nodes.keys())[0]
        dfs(first_node)

        return len(visited) < graph.node_count

    def _find_broadcast_sources(self, graph: AgentGraph) -> list[str]:
        """Find nodes with high fan-out (broadcast sources)."""
        return [node.id for node in graph.nodes if node.out_degree >= self.broadcast_threshold]

    def _generate_recommendations(
        self,
        patterns: list[TopologyPattern],
        hub_nodes: list[str],
        articulation_points: list[str],
        broadcast_sources: list[str],
        graph: AgentGraph,
    ) -> list[str]:
        """Generate recommendations based on pattern analysis."""
        recommendations = []

        # Pattern-specific recommendations
        if TopologyPattern.RING in patterns:
            recommendations.append(
                "CRITICAL: Circular dependencies detected. "
                "Break cycles to prevent infinite loops and trust laundering."
            )

        if TopologyPattern.HUB_AND_SPOKE in patterns:
            recommendations.append(
                "High-risk: Hub-and-spoke topology creates single point of failure. "
                "Distribute responsibilities across multiple agents."
            )

        if TopologyPattern.BROADCAST in patterns:
            recommendations.append(
                "Warning: Broadcast patterns increase blast radius. "
                "Add message filtering and validation at broadcast sources."
            )

        if TopologyPattern.MESH in patterns:
            recommendations.append(
                "Warning: High connectivity increases attack surface. "
                "Reduce unnecessary communications between agents."
            )

        # Node-specific recommendations
        if articulation_points:
            ap_names = [graph.get_node(ap).name for ap in articulation_points if graph.get_node(ap)]
            recommendations.append(
                f"Single points of failure: {', '.join(ap_names[:3])}. "
                "Add redundancy or alternative paths."
            )

        if len(hub_nodes) == 1:
            hub_node = graph.get_node(hub_nodes[0])
            if hub_node:
                recommendations.append(
                    f"Agent '{hub_node.name}' is a critical hub. "
                    "Harden security and add monitoring."
                )

        return recommendations


def calculate_pattern_score(graph: AgentGraph) -> PatternScore:
    """
    Convenience function to calculate pattern score.

    Args:
        graph: Agent topology graph

    Returns:
        PatternScore
    """
    scorer = CommunicationPatternScorer()
    return scorer.score(graph)
