"""
Infection Simulation Module for Vantage.

Simulates infection propagation through agent topologies to identify
vulnerabilities and containment opportunities.
"""

from vantage_core.security.simulation.blast_radius import (
    BlastRadiusCalculator,
    BlastRadiusResult,
    EntryPointImpact,
)
from vantage_core.security.simulation.comparison import (
    ComparisonReport,
    ScenarioComparator,
    ScenarioResult,
)
from vantage_core.security.simulation.containment import (
    ContainmentAnalyzer,
    ContainmentPoint,
    ContainmentStrategy,
)
from vantage_core.security.simulation.entry_points import (
    EntryPoint,
    EntryPointIdentifier,
    EntryPointType,
)
from vantage_core.security.simulation.infection_simulator import (
    AgentDefenses,
    # Legacy classes for backward compatibility
    AgentTopology,
    ContainmentRecommendation,
    CriticalAgentAnalysis,
    InfectionEvent,
    InfectionSimulationResult,
    InfectionStatus,
    InfectionVector,
    LegacyPromptInfectionSimulator,
    PromptInfectionSimulator,
    SimulationResult,
)
from vantage_core.security.simulation.propagation import (
    AgentState,
    InfectionSimulator,
    InfectionState,
    SimulationConfig,
)
from vantage_core.security.simulation.visualization import (
    SimulationVisualizer,
    TimeStep,
    VisualizationData,
)

__all__ = [
    # Entry points
    "EntryPointIdentifier",
    "EntryPoint",
    "EntryPointType",
    # Propagation
    "InfectionSimulator",
    "InfectionState",
    "AgentState",
    "SimulationConfig",
    # Blast radius
    "BlastRadiusCalculator",
    "BlastRadiusResult",
    "EntryPointImpact",
    # Containment
    "ContainmentAnalyzer",
    "ContainmentPoint",
    "ContainmentStrategy",
    # Visualization
    "SimulationVisualizer",
    "VisualizationData",
    "TimeStep",
    # Comparison
    "ScenarioComparator",
    "ScenarioResult",
    "ComparisonReport",
    # Prompt Infection Simulator (NetworkX-based)
    "PromptInfectionSimulator",
    "InfectionStatus",
    "InfectionEvent",
    "AgentDefenses",
    "SimulationResult",
    # Legacy classes
    "AgentTopology",
    "LegacyPromptInfectionSimulator",
    "InfectionSimulationResult",
    "CriticalAgentAnalysis",
    "ContainmentRecommendation",
    "InfectionVector",
]
