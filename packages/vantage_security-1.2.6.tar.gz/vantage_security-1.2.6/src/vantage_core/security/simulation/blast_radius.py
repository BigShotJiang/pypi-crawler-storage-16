"""
Blast Radius Calculation (US-130).

Calculates the impact of infections from each entry point
and ranks them by blast radius.
"""

from dataclasses import dataclass, field
from typing import Any

from vantage_core.security.simulation.entry_points import EntryPoint
from vantage_core.security.simulation.propagation import (
    InfectionSimulator,
    SimulationConfig,
    SimulationResult,
)
from vantage_core.security.topology.graph import AgentGraph


@dataclass
class EntryPointImpact:
    """
    Impact assessment for a single entry point.

    Contains blast radius metrics and analysis.
    """

    entry_point_id: str
    entry_point_name: str
    blast_radius: int  # Total agents infected
    blast_percentage: float  # Percentage of total agents
    time_to_peak: int  # Steps to reach peak infection
    peak_infection: int  # Maximum simultaneous infections
    critical_paths: list[list[str]]  # Paths to critical agents
    affected_trust_levels: dict[str, int]
    risk_score: float  # 0-100
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def severity(self) -> str:
        """Get severity based on blast percentage."""
        if self.blast_percentage >= 80:
            return "critical"
        elif self.blast_percentage >= 60:
            return "high"
        elif self.blast_percentage >= 40:
            return "moderate"
        else:
            return "low"


@dataclass
class BlastRadiusResult:
    """
    Complete blast radius analysis.

    Contains all entry point impacts and comparative analysis.
    """

    impacts: list[EntryPointImpact]
    highest_impact: EntryPointImpact | None
    total_agents: int
    average_blast_radius: float
    worst_case_scenario: str
    recommendations: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


class BlastRadiusCalculator:
    """
    Calculates blast radius for infection scenarios.

    Simulates infections from each entry point and ranks
    them by impact to identify highest-risk vectors.
    """

    def __init__(
        self,
        config: SimulationConfig | None = None,
    ):
        """
        Initialize the calculator.

        Args:
            config: Simulation configuration
        """
        self.config = config or SimulationConfig()
        self.simulator = InfectionSimulator(self.config)

    def calculate(
        self,
        graph: AgentGraph,
        entry_points: list[EntryPoint] | list[str],
    ) -> BlastRadiusResult:
        """
        Calculate blast radius for all entry points.

        Args:
            graph: Agent topology graph
            entry_points: List of entry points (EntryPoint objects or IDs)

        Returns:
            BlastRadiusResult with complete analysis
        """
        impacts = []
        total_agents = graph.node_count

        # Convert to IDs if needed
        entry_point_ids = []
        entry_point_names = {}

        for ep in entry_points:
            if isinstance(ep, EntryPoint):
                entry_point_ids.append(ep.agent_id)
                entry_point_names[ep.agent_id] = ep.agent_name
            else:
                entry_point_ids.append(ep)
                node = graph.get_node(ep)
                entry_point_names[ep] = node.name if node else ep

        # Simulate from each entry point
        for entry_id in entry_point_ids:
            try:
                result = self.simulator.simulate(graph, entry_id)
                impact = self._create_impact(
                    entry_id,
                    entry_point_names.get(entry_id, entry_id),
                    result,
                    graph,
                    total_agents,
                )
                impacts.append(impact)
            except Exception:
                # Skip invalid entry points
                continue

        # Sort by blast radius descending
        impacts.sort(key=lambda i: i.blast_radius, reverse=True)

        # Get highest impact
        highest_impact = impacts[0] if impacts else None

        # Calculate average
        avg_blast = sum(i.blast_radius for i in impacts) / len(impacts) if impacts else 0

        # Determine worst case scenario
        worst_case = ""
        if highest_impact:
            worst_case = (
                f"Entry through {highest_impact.entry_point_name} could infect "
                f"{highest_impact.blast_radius} agents ({highest_impact.blast_percentage:.1f}% of topology)"
            )

        # Generate recommendations
        recommendations = self._generate_recommendations(impacts, total_agents)

        return BlastRadiusResult(
            impacts=impacts,
            highest_impact=highest_impact,
            total_agents=total_agents,
            average_blast_radius=round(avg_blast, 2),
            worst_case_scenario=worst_case,
            recommendations=recommendations,
            metadata={
                "entry_point_count": len(impacts),
                "simulation_config": {
                    "transmission_rate": self.config.transmission_rate,
                    "max_steps": self.config.max_steps,
                },
            },
        )

    def calculate_single(
        self,
        graph: AgentGraph,
        entry_point: str,
    ) -> EntryPointImpact:
        """
        Calculate blast radius for a single entry point.

        Args:
            graph: Agent topology graph
            entry_point: Entry point agent ID

        Returns:
            EntryPointImpact for the entry point
        """
        result = self.simulator.simulate(graph, entry_point)
        node = graph.get_node(entry_point)
        name = node.name if node else entry_point

        return self._create_impact(
            entry_point,
            name,
            result,
            graph,
            graph.node_count,
        )

    def compare_entry_points(
        self,
        graph: AgentGraph,
        entry_points: list[str],
    ) -> dict[str, Any]:
        """
        Compare blast radius between entry points.

        Args:
            graph: Agent topology graph
            entry_points: Entry point IDs to compare

        Returns:
            Comparison metrics
        """
        impacts = []
        for entry in entry_points:
            impact = self.calculate_single(graph, entry)
            impacts.append(impact)

        return {
            "entry_points": [
                {
                    "id": i.entry_point_id,
                    "name": i.entry_point_name,
                    "blast_radius": i.blast_radius,
                    "percentage": i.blast_percentage,
                    "severity": i.severity,
                }
                for i in impacts
            ],
            "max_blast": max(i.blast_radius for i in impacts) if impacts else 0,
            "min_blast": min(i.blast_radius for i in impacts) if impacts else 0,
            "spread": (
                max(i.blast_radius for i in impacts) - min(i.blast_radius for i in impacts)
                if impacts
                else 0
            ),
        }

    def _create_impact(
        self,
        entry_id: str,
        entry_name: str,
        result: SimulationResult,
        graph: AgentGraph,
        total_agents: int,
    ) -> EntryPointImpact:
        """Create an EntryPointImpact from simulation result."""
        # Calculate trust level distribution
        affected_trust = {}
        for path in result.infection_paths:
            for agent_id in path:
                node = graph.get_node(agent_id)
                if node:
                    trust_name = node.trust_level.name
                    affected_trust[trust_name] = affected_trust.get(trust_name, 0) + 1

        # Find critical paths (to privileged/system agents)
        critical_paths = []
        for path in result.infection_paths:
            last_node = graph.get_node(path[-1])
            if last_node and last_node.trust_level.value >= 3:  # PRIVILEGED or SYSTEM
                critical_paths.append(path)

        # Calculate risk score
        risk_score = self._calculate_risk_score(
            result.blast_radius,
            total_agents,
            result.peak_infection,
            len(critical_paths),
        )

        return EntryPointImpact(
            entry_point_id=entry_id,
            entry_point_name=entry_name,
            blast_radius=result.blast_radius,
            blast_percentage=(
                round(result.blast_radius / total_agents * 100, 2) if total_agents else 0
            ),
            time_to_peak=result.peak_step,
            peak_infection=result.peak_infection,
            critical_paths=critical_paths[:5],  # Top 5 critical paths
            affected_trust_levels=affected_trust,
            risk_score=risk_score,
            metadata={
                "total_steps": result.total_steps,
                "infection_rate": result.metrics.get("infection_rate", 0),
            },
        )

    def _calculate_risk_score(
        self,
        blast_radius: int,
        total_agents: int,
        peak_infection: int,
        critical_paths: int,
    ) -> float:
        """Calculate risk score for an entry point."""
        if total_agents == 0:
            return 0.0

        score = 0.0

        # Factor in blast percentage (up to 60 points)
        blast_pct = blast_radius / total_agents
        score += blast_pct * 60

        # Factor in peak infection rate (up to 20 points)
        peak_pct = peak_infection / total_agents
        score += peak_pct * 20

        # Factor in critical paths (up to 20 points)
        # More critical paths = higher risk
        score += min(critical_paths * 5, 20)

        return round(min(100, score), 2)

    def _generate_recommendations(
        self,
        impacts: list[EntryPointImpact],
        total_agents: int,
    ) -> list[str]:
        """Generate recommendations based on blast radius analysis."""
        recommendations = []

        if not impacts:
            return recommendations

        # Check for critical severity entries
        critical = [i for i in impacts if i.severity == "critical"]
        if critical:
            recommendations.append(
                f"CRITICAL: {len(critical)} entry point(s) can infect >80% of agents. "
                "Add input validation and segmentation."
            )

        # Check for high-impact single points
        highest = impacts[0]
        if highest.blast_percentage > 50:
            recommendations.append(
                f"High-priority: Harden entry point '{highest.entry_point_name}' "
                f"which can reach {highest.blast_percentage:.1f}% of agents."
            )

        # Check for critical path exposure
        total_critical_paths = sum(len(i.critical_paths) for i in impacts)
        if total_critical_paths > 3:
            recommendations.append(
                f"{total_critical_paths} paths to privileged agents detected. "
                "Add intermediate validation layers."
            )

        # Check for fast propagation
        fast_spread = [i for i in impacts if i.time_to_peak <= 3]
        if fast_spread:
            recommendations.append(
                f"{len(fast_spread)} entry points reach peak infection in 3 or fewer steps. "
                "Add rate limiting and monitoring."
            )

        return recommendations


def calculate_blast_radius(
    graph: AgentGraph,
    entry_points: list[str],
) -> BlastRadiusResult:
    """
    Convenience function to calculate blast radius.

    Args:
        graph: Agent topology graph
        entry_points: Entry point agent IDs

    Returns:
        BlastRadiusResult
    """
    calculator = BlastRadiusCalculator()
    return calculator.calculate(graph, entry_points)
