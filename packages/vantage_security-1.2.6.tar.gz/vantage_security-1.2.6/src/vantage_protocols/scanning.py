"""
Scanning Protocol.

Defines the interface for security scanning across frameworks.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Protocol, runtime_checkable


class Severity(str, Enum):
    """Severity levels for findings."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class FindingType(str, Enum):
    """Types of security findings."""
    PROMPT_INJECTION = "prompt_injection"
    JAILBREAK = "jailbreak"
    DATA_EXFILTRATION = "data_exfiltration"
    HARDCODED_SECRET = "hardcoded_secret"
    EXCESSIVE_PERMISSIONS = "excessive_permissions"
    INSECURE_OUTPUT = "insecure_output"
    MISSING_VALIDATION = "missing_validation"
    TOOL_ABUSE = "tool_abuse"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    INDIRECT_INJECTION = "indirect_injection"


@dataclass
class Finding:
    """A security finding."""
    id: str
    type: FindingType
    severity: Severity
    title: str
    description: str
    file_path: str | None = None
    line_number: int | None = None
    code_snippet: str | None = None
    remediation: str | None = None
    confidence: float = 1.0
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "type": self.type.value,
            "severity": self.severity.value,
            "title": self.title,
            "description": self.description,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "code_snippet": self.code_snippet,
            "remediation": self.remediation,
            "confidence": self.confidence,
            "metadata": self.metadata,
        }


@dataclass
class AgentInfo:
    """Information about a detected agent."""
    id: str
    name: str
    framework: str
    file_path: str
    line_number: int
    system_prompt: str | None = None
    tools: list[str] = field(default_factory=list)
    connections: list[str] = field(default_factory=list)
    trust_level: int = 1
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "framework": self.framework,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "system_prompt": self.system_prompt,
            "tools": self.tools,
            "connections": self.connections,
            "trust_level": self.trust_level,
        }


@dataclass
class ScanConfig:
    """Configuration for scanning."""
    target_path: Path
    frameworks: list[str] | None = None
    include_patterns: list[str] = field(default_factory=lambda: ["**/*.py"])
    exclude_patterns: list[str] = field(default_factory=lambda: ["**/test*", "**/__pycache__"])
    max_file_size: int = 1_000_000  # 1MB
    enable_ml_detection: bool = False
    enable_live_testing: bool = False
    max_payloads: int = 50
    confidence_threshold: float = 0.7


@dataclass
class ScanResult:
    """Result of a security scan."""
    scan_id: str
    timestamp: datetime
    target_path: str
    duration_ms: int
    score: int  # 0-100
    grade: str  # A-F
    agents: list[AgentInfo] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)
    frameworks_detected: list[str] = field(default_factory=list)
    files_scanned: int = 0
    errors: list[str] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)

    @property
    def critical_count(self) -> int:
        """Count of critical findings."""
        return sum(1 for f in self.findings if f.severity == Severity.CRITICAL)

    @property
    def high_count(self) -> int:
        """Count of high severity findings."""
        return sum(1 for f in self.findings if f.severity == Severity.HIGH)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "scan_id": self.scan_id,
            "timestamp": self.timestamp.isoformat(),
            "target_path": self.target_path,
            "duration_ms": self.duration_ms,
            "score": self.score,
            "grade": self.grade,
            "agents": [a.to_dict() for a in self.agents],
            "findings": [f.to_dict() for f in self.findings],
            "frameworks_detected": self.frameworks_detected,
            "files_scanned": self.files_scanned,
            "errors": self.errors,
            "critical_count": self.critical_count,
            "high_count": self.high_count,
        }


@runtime_checkable
class Scanner(Protocol):
    """Interface for security scanners."""

    def scan(self, config: ScanConfig) -> ScanResult:
        """Run a security scan."""
        ...

    def get_supported_frameworks(self) -> list[str]:
        """Get list of supported frameworks."""
        ...

    def detect_agents(self, config: ScanConfig) -> list[AgentInfo]:
        """Detect agents in the target path."""
        ...
