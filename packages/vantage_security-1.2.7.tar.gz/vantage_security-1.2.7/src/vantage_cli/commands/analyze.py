"""Analysis commands for Vantage CLI.

This module provides agent system analysis including:
- Collision detection with embeddings
- Alignment scoring
- Prompt quality assessment
- Topology visualization
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import typer

from vantage_cli.output import get_console

analyze_app = typer.Typer(
    name="analyze",
    help="Multi-agent system analysis commands.",
    no_args_is_help=True,
)


@analyze_app.command("system")
def analyze_system(
    system_file: Path = typer.Argument(
        ...,
        help="Path to agent system JSON file",
        exists=True,
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file for detailed report",
    ),
    similarity_threshold: float = typer.Option(
        0.7,
        "--threshold",
        "-t",
        help="Similarity threshold for collision detection (0-1)",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed output",
    ),
    llm_judge: bool = typer.Option(
        False,
        "--llm-judge",
        help="Use LLM-as-Judge (requires OPENROUTER_API_KEY)",
    ),
    llm_model: str = typer.Option(
        "anthropic/claude-sonnet-4-20250514",
        "--llm-model",
        help="OpenRouter model for LLM-as-Judge",
    ),
    embedding_model: str = typer.Option(
        "all-mpnet-base-v2",
        "--embedding-model",
        help="Sentence-transformers model for embeddings",
    ),
):
    """Analyze a multi-agent system with enhanced collision detection.

    Uses sentence embeddings and optional LLM-as-Judge to detect:
    - Agent responsibility collisions
    - Alignment issues
    - Prompt quality problems

    Examples:

        vantage analyze system my_system.json
        vantage analyze system my_system.json --verbose
        vantage analyze system my_system.json --llm-judge
    """
    from vantage_core.analysis.alignment import AlignmentScorer
    from vantage_core.analysis.collision import CollisionDetector
    from vantage_core.analysis.dependency import DependencyMapper

    from vantage_cli.commands._loaders import load_agent_system

    console = get_console()

    console.print(f"\n[bold blue]Analyzing: {system_file.name}[/bold blue]\n")

    # Check for API key if LLM judge requested
    if llm_judge:
        api_key = os.getenv("OPENROUTER_API_KEY")
        if not api_key:
            console.warning("OPENROUTER_API_KEY not set. LLM-as-Judge disabled.")
            llm_judge = False
        else:
            console.success(f"LLM-as-Judge enabled with {llm_model}")

    system = load_agent_system(system_file)

    # Run analysis
    console.muted(f"Using embeddings: {embedding_model}")

    detector = CollisionDetector(
        similarity_threshold=similarity_threshold,
        embedding_model=embedding_model,
        llm_model=llm_model,
        use_llm_judge=llm_judge,
    )
    scorer = AlignmentScorer(embedding_model=embedding_model)
    mapper = DependencyMapper(system)

    collisions = detector.detect_collisions(system)
    score = scorer.score_system(system, collisions)
    metrics = mapper.compute_system_metrics()

    # Display results
    _display_summary(console, system, score, collisions, metrics)

    if verbose:
        _display_collisions(console, collisions)
        _display_prompt_quality(console, system, scorer)
        _display_recommendations(console, score)
        _display_topology(console, mapper)

    # Save report if requested
    if output:
        from vantage_core.core.models import AnalysisResult

        result = AnalysisResult(
            system_name=system.name,
            alignment_score=score,
            collisions=collisions,
            total_agents=metrics["total_agents"],
            total_connections=metrics["total_connections"],
            total_tokens=sum(a.prompt.token_estimate() for a in system.agents.values()),
            dependency_graph=mapper.get_dependency_graph(),
        )

        with open(output, "w") as f:
            json.dump(result.model_dump(), f, indent=2)

        console.success(f"Report saved to: {output}")


def _display_summary(console, system, score, collisions, metrics) -> None:
    """Display analysis summary."""
    # Score panel
    if score.overall_score >= 80:
        grade = "A" if score.overall_score >= 90 else "B"
    elif score.overall_score >= 60:
        grade = "C"
    else:
        grade = "D" if score.overall_score >= 40 else "F"

    console.print_score_panel(
        score=score.overall_score,
        grade=grade,
        title="Alignment Score",
        subtitle=system.name,
    )

    # Metrics table
    console.print_stats_panel(
        {
            "Agents": metrics["total_agents"],
            "Connections": metrics["total_connections"],
            "Total Tokens": f"{sum(a.prompt.token_estimate() for a in system.agents.values()):,}",
            "Collisions": len(collisions),
        },
        title="System Metrics",
    )

    # Component scores
    console.print_subheader("Component Scores")
    console.print(f"  Responsibility Clarity: {score.responsibility_clarity:.1f}")
    console.print(f"  Handoff Quality:        {score.handoff_quality:.1f}")
    console.print(f"  Coverage Completeness:  {score.coverage_completeness:.1f}")
    console.print(f"  Redundancy:             {score.redundancy_score:.1f} (lower is better)")

    if "prompt_quality_score" in score.breakdown:
        console.print(f"  Prompt Quality:         {score.breakdown['prompt_quality_score']:.1f}")


def _display_collisions(console, collisions) -> None:
    """Display collision details."""
    if not collisions:
        console.success("\nNo collisions detected!")
        return

    console.print_subheader(f"Collisions Detected ({len(collisions)})")

    for i, collision in enumerate(collisions, 1):
        theme = console.theme
        color = theme.get_severity_color(collision.severity)

        console.print(
            f"\n  [{color}]{i}. [{collision.severity.upper()}] "
            f"{collision.collision_type}[/{color}]"
        )
        console.print(f"     Agents: {', '.join(collision.agents_involved)}")
        console.print(f"     {collision.description}")
        if collision.recommendation:
            console.print(f"     [{theme.success}]-> {collision.recommendation}[/{theme.success}]")


def _display_prompt_quality(console, system, scorer) -> None:
    """Display prompt quality summary."""
    console.print_subheader("Prompt Quality Summary")

    for agent_id, agent in system.agents.items():
        breakdown = scorer.get_prompt_quality_breakdown(agent)
        score = breakdown["score"]

        theme = console.theme
        if score >= 70:
            color = theme.success
        elif score >= 50:
            color = theme.warning
        else:
            color = theme.error

        console.print(f"  {agent.name}: [{color}]{score:.0f}%[/{color}]")


def _display_recommendations(console, score) -> None:
    """Display recommendations."""
    if not score.recommendations:
        return

    console.print_subheader("Recommendations")
    for rec in score.recommendations:
        console.print(f"  {rec}")


def _display_topology(console, mapper) -> None:
    """Display topology information."""
    console.print_subheader("Topology")
    console.print(mapper.to_ascii())


@analyze_app.command("quality")
def quality(
    system_file: Path = typer.Argument(
        ...,
        help="Path to agent system JSON file",
        exists=True,
    ),
    detailed: bool = typer.Option(
        False,
        "--detailed",
        "-d",
        help="Show detailed check results",
    ),
):
    """Check prompt quality against best practices.

    Evaluates each agent's prompt for:
    - Clear role definition
    - Goal specification
    - Constraint documentation
    - Output format specification
    - Optimal length

    Examples:

        vantage analyze quality my_system.json
        vantage analyze quality my_system.json --detailed
    """
    from vantage_core.analysis.alignment import AlignmentScorer

    from vantage_cli.commands._loaders import load_agent_system

    console = get_console()

    system = load_agent_system(system_file)
    scorer = AlignmentScorer()

    console.print(f"\n[bold]Prompt Quality Report: {system.name}[/bold]\n")

    for agent_id, agent in system.agents.items():
        breakdown = scorer.get_prompt_quality_breakdown(agent)
        score = breakdown["score"]

        theme = console.theme
        if score >= 70:
            color = theme.success
        elif score >= 50:
            color = theme.warning
        else:
            color = theme.error

        console.print(f"[bold]{agent.name}[/bold] ({agent_id})")
        console.print(f"  Quality Score: [{color}]{score:.0f}/100[/{color}]")

        if detailed:
            # Show checks
            checks = breakdown["checks"]
            for check, passed in checks.items():
                if check in ("word_count", "word_count_optimal"):
                    continue

                status = "[green][OK][/green]" if passed else "[red][X][/red]"
                check_name = check.replace("_", " ").replace("has ", "")
                console.print(f"    {status} {check_name}")

            console.print(f"    Word count: {checks['word_count']}")

        # Show suggestions
        if breakdown["suggestions"]:
            console.print(f"  [{theme.warning}]Suggestions:[/{theme.warning}]")
            for suggestion in breakdown["suggestions"]:
                console.print(f"    {suggestion}")

        console.print()


@analyze_app.command("compare")
def compare(
    agent1_file: Path = typer.Argument(
        ...,
        help="First agent prompt file",
        exists=True,
    ),
    agent2_file: Path = typer.Argument(
        ...,
        help="Second agent prompt file",
        exists=True,
    ),
):
    """Compare alignment between two agent prompts.

    Useful for checking if two agents have overlapping responsibilities
    or complementary capabilities.

    Examples:

        vantage analyze compare agent1.txt agent2.txt
    """
    from vantage_core.analysis.alignment import AlignmentScorer
    from vantage_core.core.models import Agent, Prompt

    from vantage_cli.commands._loaders import load_prompt_file

    console = get_console()

    prompt1 = load_prompt_file(agent1_file)
    prompt2 = load_prompt_file(agent2_file)

    agent1 = Agent(id="agent1", name=agent1_file.stem, prompt=Prompt(content=prompt1))
    agent2 = Agent(id="agent2", name=agent2_file.stem, prompt=Prompt(content=prompt2))

    scorer = AlignmentScorer()
    alignment_score = scorer.score_agent_pair(agent1, agent2)

    console.print(f"\n[bold]Agent Comparison: {agent1.name} <-> {agent2.name}[/bold]\n")

    theme = console.theme
    if alignment_score >= 80:
        color = theme.success
        status = "Excellent alignment"
    elif alignment_score >= 60:
        color = theme.warning
        status = "Good alignment"
    else:
        color = theme.error
        status = "Poor alignment - review for issues"

    console.print(f"Alignment Score: [{color}]{alignment_score:.1f}/100[/{color}]")
    console.print(f"Status: {status}\n")

    # Show quality for both
    console.print("[bold]Individual Quality:[/bold]")
    for agent in [agent1, agent2]:
        breakdown = scorer.get_prompt_quality_breakdown(agent)
        console.print(f"  {agent.name}: {breakdown['score']:.0f}/100")


@analyze_app.command("topology")
def topology(
    system_file: Path = typer.Argument(
        ...,
        help="Path to agent system JSON file",
        exists=True,
    ),
    format: str = typer.Option(
        "ascii",
        "--format",
        "-f",
        help="Output format: ascii, mermaid",
    ),
):
    """Display the agent system topology.

    Visualizes the agent communication graph.

    Examples:

        vantage analyze topology my_system.json
        vantage analyze topology my_system.json -f mermaid
    """
    from vantage_core.analysis.dependency import DependencyMapper

    from vantage_cli.commands._loaders import load_agent_system

    console = get_console()

    system = load_agent_system(system_file)
    mapper = DependencyMapper(system)

    if format == "mermaid":
        diagram = mapper.to_mermaid()
        console.print("\n[bold]Mermaid Diagram:[/bold]\n")
        console.print(f"```mermaid\n{diagram}\n```")
    else:
        diagram = mapper.to_ascii()
        console.print(f"\n{diagram}")

    suggestions = mapper.suggest_optimizations()
    if suggestions and suggestions[0]["type"] != "healthy":
        console.print_subheader("Optimization Suggestions")
        for s in suggestions:
            console.warning(s["message"])
