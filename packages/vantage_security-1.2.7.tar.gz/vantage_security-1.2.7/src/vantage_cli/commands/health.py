"""Health check commands for Vantage CLI.

This module provides comprehensive health checking including:
- MAST failure taxonomy detection (14 failure modes)
- Cascade risk analysis
- Cost estimation
- Overall system health scoring
"""

from __future__ import annotations

import json
from pathlib import Path

import typer

from vantage_cli.output import get_console
from vantage_cli.utils import ExitCode

health_app = typer.Typer(
    name="health",
    help="Health check and failure mode detection.",
    no_args_is_help=True,
)


@health_app.command("check")
def healthcheck(
    system_file: Path = typer.Argument(
        ...,
        help="Path to agent system JSON file",
        exists=True,
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed output",
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file for JSON report",
    ),
    threshold: float = typer.Option(
        0.3,
        "--threshold",
        "-t",
        help="Risk threshold 0-1 (lower = more sensitive)",
    ),
):
    """Run comprehensive health check with MAST failure detection.

    This is the killer feature - detects the 14 failure modes from
    "Why Do Multi-Agent LLM Systems Fail?" (Cemri et al., 2025)
    BEFORE deployment.

    Examples:

        vantage health check my_system.json
        vantage health check my_system.json --verbose
        vantage health check my_system.json -o report.json
    """
    from vantage_core.analysis.cost_estimator import CostEstimator
    from vantage_core.analysis.failure_taxonomy import MASTFailureDetector

    from vantage_cli.commands._loaders import load_agent_system

    console = get_console()

    console.print_banner()
    console.print(f"[bold blue]Health Check: {system_file.name}[/bold blue]\n")

    system = load_agent_system(system_file)

    results = {
        "system_name": system.name,
        "failure_risks": [],
        "cascade_risk": {},
        "cost_estimate": {},
        "health_score": 0,
    }

    # 1. MAST Failure Detection
    console.print_header(
        "MAST Failure Taxonomy Analysis",
        "Based on 'Why Do Multi-Agent LLM Systems Fail?' (arXiv:2503.13657)",
    )

    detector = MASTFailureDetector(risk_threshold=threshold)
    failure_risks = detector.detect_failure_risks(system)

    if failure_risks:
        _display_failure_risks(console, failure_risks, verbose)
        results["failure_risks"] = [
            {
                "code": r.failure_mode.code,
                "name": r.failure_mode.name,
                "risk_level": r.risk_level,
                "risk_score": r.risk_score,
                "agents": r.agents_at_risk,
                "recommendation": r.recommendation,
            }
            for r in failure_risks
        ]
    else:
        console.success("No significant failure risks detected!")

    # 2. Cascade Risk Analysis
    console.print_header(
        "Cascade Failure Risk",
        "Based on ICML 2025 resilience research",
    )

    cascade = detector.calculate_cascade_risk(system)
    _display_cascade_risk(console, cascade, verbose)
    results["cascade_risk"] = {
        "score": cascade.cascade_score,
        "bottleneck_agents": cascade.bottleneck_agents,
        "critical_paths": cascade.critical_paths[:3] if cascade.critical_paths else [],
        "recommendations": cascade.recommendations,
    }

    # 3. Cost Estimation
    console.print_header("Cost Estimation")

    estimator = CostEstimator()
    cost_estimate = estimator.estimate_system_cost(system)
    _display_cost_estimate(console, cost_estimate, verbose)
    results["cost_estimate"] = {
        "per_run": cost_estimate.total_cost_per_run,
        "tokens_per_run": cost_estimate.total_tokens_per_run,
        "monthly_1k_runs": cost_estimate.monthly_cost_1000_runs,
        "monthly_10k_runs": cost_estimate.monthly_cost_10000_runs,
        "most_expensive_agent": cost_estimate.most_expensive_agent,
    }

    # 4. Overall Health Score
    console.print_header("Overall Health Score")

    failure_penalty = min(len(failure_risks) * 5, 40)
    cascade_penalty = cascade.cascade_score * 0.3
    health_score = max(100 - failure_penalty - cascade_penalty, 0)
    results["health_score"] = health_score

    _display_health_score(console, health_score, system.name)

    # Summary
    _display_summary(console, system, failure_risks, cascade, cost_estimate, health_score)

    # Save report if requested
    if output:
        output.write_text(json.dumps(results, indent=2))
        console.success(f"Report saved to: {output}")

    # Exit with appropriate code
    if health_score < 50:
        raise typer.Exit(ExitCode.SECURITY_FINDINGS)


def _display_failure_risks(console, failure_risks, verbose: bool) -> None:
    """Display failure risk analysis."""
    # Group by severity
    critical = [r for r in failure_risks if r.risk_level == "critical"]
    high = [r for r in failure_risks if r.risk_level == "high"]
    medium = [r for r in failure_risks if r.risk_level == "medium"]

    if critical:
        console.error(f"{len(critical)} CRITICAL failure risks detected")
    if high:
        console.warning(f"{len(high)} high-risk failure modes")
    if medium:
        console.info(f"{len(medium)} medium-risk failure modes")

    console.print_subheader("Top Failure Risks")

    for risk in failure_risks[:5]:
        theme = console.theme
        color = theme.get_risk_color(risk.risk_level)

        console.print(
            f"\n  [{color}][{risk.risk_level.upper()}] "
            f"{risk.failure_mode.code}: {risk.failure_mode.name}[/{color}]"
        )
        console.print(f"    Risk Score: {risk.risk_score:.0f}/100")
        console.print(f"    Agents: {', '.join(risk.agents_at_risk)}")
        if verbose:
            console.print(f"    Evidence: {risk.evidence}")
        console.print(f"    [{theme.success}]Fix: {risk.recommendation}[/{theme.success}]")


def _display_cascade_risk(console, cascade, verbose: bool) -> None:
    """Display cascade risk analysis."""
    theme = console.theme

    if cascade.cascade_score >= 70:
        color = theme.error
        status = "HIGH RISK"
    elif cascade.cascade_score >= 40:
        color = theme.warning
        status = "MODERATE RISK"
    else:
        color = theme.success
        status = "LOW RISK"

    console.print(
        f"Cascade Risk Score: [{color}]{cascade.cascade_score:.0f}/100 ({status})[/{color}]"
    )

    if cascade.critical_paths and verbose:
        console.print(f"\nLongest chain: {' -> '.join(cascade.critical_paths[0])}")

    if cascade.bottleneck_agents:
        console.print(f"Bottleneck agents: {', '.join(cascade.bottleneck_agents)}")

    for rec in cascade.recommendations[:2]:
        console.warning(rec)


def _display_cost_estimate(console, cost_estimate, verbose: bool) -> None:
    """Display cost estimation."""
    console.print_stats_panel(
        {
            "Cost per run": f"${cost_estimate.total_cost_per_run:.4f}",
            "Tokens per run": f"{cost_estimate.total_tokens_per_run:,}",
            "Monthly (1K runs)": f"${cost_estimate.monthly_cost_1000_runs:.2f}",
            "Monthly (10K runs)": f"${cost_estimate.monthly_cost_10000_runs:.2f}",
            "Most expensive": cost_estimate.most_expensive_agent,
        },
        title="Cost Breakdown",
    )

    if verbose and cost_estimate.agent_costs:
        console.print_subheader("Cost by Agent")
        for ac in sorted(cost_estimate.agent_costs, key=lambda x: x.cost_per_call, reverse=True)[
            :5
        ]:
            console.print(f"  {ac.agent_name}: ${ac.cost_per_call:.4f}/call ({ac.model})")

    if cost_estimate.optimization_suggestions:
        console.print_subheader("Cost Optimization")
        for suggestion in cost_estimate.optimization_suggestions[:3]:
            console.warning(suggestion)


def _display_health_score(console, health_score: float, system_name: str) -> None:
    """Display overall health score."""
    if health_score >= 80:
        status = "HEALTHY"
        grade = "A" if health_score >= 90 else "B"
    elif health_score >= 60:
        status = "NEEDS ATTENTION"
        grade = "C"
    else:
        status = "AT RISK"
        grade = "D" if health_score >= 40 else "F"

    console.print_score_panel(
        score=health_score,
        grade=grade,
        title="Health Score",
        subtitle=f"{system_name} - {status}",
    )


def _display_summary(console, system, failure_risks, cascade, cost_estimate, health_score) -> None:
    """Display summary and priority actions."""
    console.print_subheader("Summary")
    console.print(
        f"  Agents: {len(system.agents)}, Connections: {len(system.topology.connections)}"
    )
    console.print(f"  Failure risks: {len(failure_risks)}")
    console.print(f"  Monthly cost (1K runs): ${cost_estimate.monthly_cost_1000_runs:.2f}")

    if health_score < 80:
        console.print_subheader("Priority Actions")

        critical = [r for r in failure_risks if r.risk_level == "critical"]
        if critical:
            console.error(f"1. Fix {len(critical)} critical failure risks")

        if cascade.cascade_score > 50:
            console.warning("2. Reduce cascade risk - add verification agents")

        if cost_estimate.monthly_cost_10000_runs > 1000:
            console.info("3. Optimize costs - consider smaller models")


@health_app.command("failures")
def failures(
    system_file: Path = typer.Argument(
        ...,
        help="Path to agent system JSON file",
        exists=True,
    ),
    threshold: float = typer.Option(
        0.3,
        "--threshold",
        "-t",
        help="Risk threshold 0-1 (lower = more sensitive)",
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file for JSON report",
    ),
):
    """Detect potential failure modes using MAST taxonomy.

    Based on "Why Do Multi-Agent LLM Systems Fail?"
    (Cemri et al., 2025, arXiv:2503.13657)

    Detects all 14 failure modes:
    - Specification Issues: Underspecification, Redundant Specification
    - Inter-Agent Misalignment: Goal Divergence, Role Confusion
    - Task Coordination Failures: Missequencing, Infinite Loops
    - And 8 more...

    Examples:

        vantage health failures my_system.json
        vantage health failures my_system.json --threshold 0.5
    """
    from vantage_core.analysis.failure_taxonomy import MASTFailureDetector

    from vantage_cli.commands._loaders import load_agent_system

    console = get_console()

    console.print(f"\n[bold]MAST Failure Analysis: {system_file.name}[/bold]")
    console.muted("Detecting 14 failure modes from research taxonomy\n")

    system = load_agent_system(system_file)
    detector = MASTFailureDetector(risk_threshold=threshold)
    risks = detector.detect_failure_risks(system)

    if not risks:
        console.success("No failure risks detected above threshold!")
        return

    # Display all risks
    results = []
    for risk in risks:
        theme = console.theme
        color = theme.get_risk_color(risk.risk_level)

        console.print(
            f"\n[{color}]--- {risk.failure_mode.code}: {risk.failure_mode.name} ---[/{color}]"
        )
        console.print(f"  Category: {risk.failure_mode.category.value}")
        console.print(
            f"  Risk Level: [{color}]{risk.risk_level.upper()}[/{color}] ({risk.risk_score:.0f}/100)"
        )
        console.print(f"  Description: {risk.failure_mode.description}")
        console.print(f"  Agents: {', '.join(risk.agents_at_risk)}")
        console.print(f"  [{theme.success}]Recommendation: {risk.recommendation}[/{theme.success}]")

        results.append(
            {
                "code": risk.failure_mode.code,
                "name": risk.failure_mode.name,
                "category": risk.failure_mode.category.value,
                "risk_level": risk.risk_level,
                "risk_score": risk.risk_score,
                "agents": risk.agents_at_risk,
                "recommendation": risk.recommendation,
            }
        )

    # Summary by category
    summary = detector.get_category_summary(risks)
    console.print("\n[bold]Summary by Category:[/bold]")
    for cat, data in summary.items():
        if data["count"] > 0:
            console.print(f"  {cat}")
            console.print(f"    Risks: {data['count']}, Avg Score: {data['avg_risk']:.0f}/100")

    # Save if requested
    if output:
        output.write_text(json.dumps(results, indent=2))
        console.success(f"Report saved to: {output}")


@health_app.command("cost")
def cost(
    system_file: Path = typer.Argument(
        ...,
        help="Path to agent system JSON file",
        exists=True,
    ),
    detailed: bool = typer.Option(
        False,
        "--detailed",
        "-d",
        help="Show detailed per-agent breakdown",
    ),
):
    """Estimate costs for the multi-agent system.

    Uses real API pricing to estimate operational costs.

    Examples:

        vantage health cost my_system.json
        vantage health cost my_system.json --detailed
    """
    from vantage_core.analysis.cost_estimator import CostEstimator

    from vantage_cli.commands._loaders import load_agent_system

    console = get_console()

    system = load_agent_system(system_file)
    estimator = CostEstimator()
    estimate = estimator.estimate_system_cost(system)

    console.print(f"\n[bold]Cost Estimate: {system.name}[/bold]\n")

    console.print_stats_panel(
        {
            "Cost per run": f"${estimate.total_cost_per_run:.6f}",
            "Tokens per run": f"{estimate.total_tokens_per_run:,}",
            "Monthly (100 runs)": f"${estimate.total_cost_per_run * 100:.2f}",
            "Monthly (1,000 runs)": f"${estimate.monthly_cost_1000_runs:.2f}",
            "Monthly (10,000 runs)": f"${estimate.monthly_cost_10000_runs:.2f}",
        },
        title="Cost Breakdown",
    )

    if detailed:
        console.print_subheader("Per-Agent Costs")
        for ac in sorted(estimate.agent_costs, key=lambda x: x.cost_per_call, reverse=True):
            pct = (
                (ac.cost_per_call / estimate.total_cost_per_run * 100)
                if estimate.total_cost_per_run > 0
                else 0
            )
            console.print(f"  {ac.agent_name}: ${ac.cost_per_call:.6f} ({pct:.0f}%) - {ac.model}")

    if estimate.optimization_suggestions:
        console.print_subheader("Optimization Suggestions")
        for suggestion in estimate.optimization_suggestions:
            console.warning(suggestion)
