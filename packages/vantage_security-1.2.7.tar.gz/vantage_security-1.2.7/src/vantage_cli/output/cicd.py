"""
CI/CD Gatekeeper Output Generator.

Generates GitHub Actions/GitLab CI compatible outputs to block builds
based on security findings.
"""

import json

from vantage_core.models import ScanResult


def generate_cicd_report(result: ScanResult, output_path: str = "security-report.json"):
    """Generate a machine-readable report for CI pipelines."""
    report = {
        "scan_id": result.scan_id,
        "timestamp": result.timestamp.isoformat(),
        "summary": {
            "critical": result.critical_count,
            "high": result.high_count,
            "medium": result.medium_count,
            "low": result.low_count,
            "total_agents": len(result.agents),
        },
        "findings": [],
        "annotations": [],  # For GitHub Checks API
    }

    # Convert agents to "findings" for the report
    for agent in result.agents:
        is_high_risk = agent.metadata.get("high_risk", False)
        if is_high_risk:
            # Create a finding object
            finding = {
                "rule_id": "shadow-ai-high-risk-tool",
                "severity": "CRITICAL",
                "message": f"High Risk Agent detected: {agent.name}",
                "file": agent.file_path,
                "line": agent.line_number,
                "details": agent.metadata.get("risk_reasons", []),
            }
            report["findings"].append(finding)

            # Add GitHub Annotation format
            # ::error file={name},line={line},title={title}::{message}
            report["annotations"].append(
                f"::error file={agent.file_path},line={agent.line_number},title=High Risk Agent::{finding['message']}"
            )

    # Write to file
    with open(output_path, "w") as f:
        json.dump(report, f, indent=2)

    return report


def enforce_gate(report: dict, fail_on_severity: str = "HIGH") -> int:
    """
    Determine exit code based on findings.
    Returns 0 for PASS, 1 for FAIL.
    """
    severity_map = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}
    threshold = severity_map.get(fail_on_severity.upper(), 3)

    for finding in report["findings"]:
        severity = finding.get("severity", "LOW").upper()
        level = severity_map.get(severity, 1)

        if level >= threshold:
            print(f"⛔ BUILD FAILED: Found {severity} severity issue: {finding['message']}")
            return 1

    print("✅ Build Passed Security Gate")
    return 0
