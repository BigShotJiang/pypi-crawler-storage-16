"""Professional console output for Vantage CLI.

Provides a unified interface for all CLI output with consistent styling,
progress indicators, and formatting.
"""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
from typing import Any

from rich.console import Console as RichConsole
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskID,
    TextColumn,
    TimeElapsedColumn,
)
from rich.table import Table
from rich.text import Text

from vantage_cli.output.themes import DEFAULT_THEME, Theme


class MimicConsole:
    """Professional console output handler for Vantage CLI.

    Provides:
    - Consistent theming and styling
    - Progress indicators with stages
    - Formatted panels and tables
    - Error and warning display
    - Status output for CI/CD
    """

    def __init__(self, theme: Theme = DEFAULT_THEME, quiet: bool = False):
        self.console = RichConsole()
        self.theme = theme
        self.quiet = quiet
        self._progress: Progress | None = None

    def print(self, *args: Any, **kwargs: Any) -> None:
        """Print to console if not in quiet mode."""
        if not self.quiet:
            self.console.print(*args, **kwargs)

    def print_always(self, *args: Any, **kwargs: Any) -> None:
        """Print regardless of quiet mode (for errors/critical output)."""
        self.console.print(*args, **kwargs)

    # =========================================================================
    # Brand and Headers
    # =========================================================================

    def print_banner(self, show_tagline: bool = True, compact: bool = False) -> None:
        """Print Vantage banner."""
        if compact:
            # Compact version for narrow terminals
            self.print()
            self.print(
                "[bold cyan]======================================================[/bold cyan]"
            )
            self.print(
                "[bold cyan]|[/bold cyan] [bold white]Vantage[/bold white] - Multi-Agent AI Security Scanner     [bold cyan]|[/bold cyan]"
            )
            self.print(
                "[bold cyan]======================================================[/bold cyan]"
            )
        else:
            logo = """
[bold cyan]   ╔═╗╔═╗╔═╗╔╗╔╔╦╗╔═╗╦ ╦╔╗╔╔═╗[/bold cyan]
[bold blue]   ╠═╣║ ╦║╣ ║║║ ║ ╚═╗╚╦╝║║║║  [/bold blue]
[bold magenta]   ╩ ╩╚═╝╚═╝╝╚╝ ╩ ╚═╝ ╩ ╝╚╝╚═╝[/bold magenta]"""
            self.print(logo)

        if show_tagline:
            self.print()
            self.print("   [bold white]Multi-Agent AI Security Scanner[/bold white]")
            self.print("   [dim]Secure your AI agents before deployment[/dim]")
            self.print()
            stats = "[dim]   [cyan]17+[/cyan] Frameworks * [cyan]OWASP LLM Top 10[/cyan] * [cyan]Topology Analysis[/cyan] * [cyan]Auto-Fix[/cyan][/dim]"
            self.print(stats)
        self.print()

    def print_header(self, title: str, subtitle: str = "") -> None:
        """Print a section header."""
        self.print()
        self.print(f"[{self.theme.header}]--- {title} ---[/{self.theme.header}]")
        if subtitle:
            self.print(f"[{self.theme.muted}]{subtitle}[/{self.theme.muted}]")
        self.print()

    def print_subheader(self, title: str) -> None:
        """Print a subsection header."""
        self.print(f"\n[{self.theme.subheader}]{title}[/{self.theme.subheader}]")

    # =========================================================================
    # Status Messages
    # =========================================================================

    def success(self, message: str) -> None:
        """Print success message."""
        self.print(f"[{self.theme.success}][OK][/{self.theme.success}] {message}")

    def warning(self, message: str) -> None:
        """Print warning message."""
        self.print(f"[{self.theme.warning}][WARN][/{self.theme.warning}] {message}")

    def error(self, message: str) -> None:
        """Print error message (always shown)."""
        self.print_always(f"[{self.theme.error}][ERROR][/{self.theme.error}] {message}")

    def info(self, message: str) -> None:
        """Print info message."""
        self.print(f"[{self.theme.info}][INFO][/{self.theme.info}] {message}")

    def muted(self, message: str) -> None:
        """Print muted/dim message."""
        self.print(f"[{self.theme.muted}]{message}[/{self.theme.muted}]")

    # =========================================================================
    # Panels and Boxes
    # =========================================================================

    def print_score_panel(
        self,
        score: float,
        grade: str,
        title: str = "Security Score",
        subtitle: str = "",
    ) -> None:
        """Print a score panel with grade."""
        score_color = self.theme.get_score_color(score)
        grade_color = self.theme.get_grade_color(grade)

        content = Text()
        content.append(f"{score:.1f}", style=score_color)
        content.append(" / 100  ", style="white")
        content.append(f"Grade: {grade}", style=grade_color)

        panel = Panel(
            content,
            title=f"[{self.theme.header}]{title}[/{self.theme.header}]",
            subtitle=subtitle if subtitle else None,
            border_style=self.theme.border,
            expand=False,
            padding=(1, 2),
        )
        self.print(panel)

    def print_findings_panel(
        self,
        critical: int = 0,
        high: int = 0,
        medium: int = 0,
        low: int = 0,
        info: int = 0,
    ) -> None:
        """Print a findings summary panel."""
        table = Table(show_header=False, box=None, padding=(0, 2))
        table.add_column("Severity", style="bold")
        table.add_column("Count", justify="right")

        if critical > 0:
            table.add_row(
                f"[{self.theme.critical}]CRITICAL[/{self.theme.critical}]",
                f"[{self.theme.critical}]{critical}[/{self.theme.critical}]",
            )
        else:
            table.add_row("Critical", "0")

        if high > 0:
            table.add_row(
                f"[{self.theme.high}]HIGH[/{self.theme.high}]",
                f"[{self.theme.high}]{high}[/{self.theme.high}]",
            )
        else:
            table.add_row("High", "0")

        if medium > 0:
            table.add_row(
                f"[{self.theme.medium}]Medium[/{self.theme.medium}]",
                f"[{self.theme.medium}]{medium}[/{self.theme.medium}]",
            )
        else:
            table.add_row("Medium", "0")

        table.add_row("Low", str(low))
        table.add_row("Info", str(info))

        panel = Panel(
            table,
            title=f"[{self.theme.header}]Findings Summary[/{self.theme.header}]",
            border_style=self.theme.border,
            expand=False,
        )
        self.print(panel)

    def print_stats_panel(self, stats: dict[str, Any], title: str = "Statistics") -> None:
        """Print a statistics panel."""
        table = Table(show_header=False, box=None, padding=(0, 2))
        table.add_column("Metric", style=self.theme.label)
        table.add_column("Value", style=self.theme.value)

        for key, value in stats.items():
            if isinstance(value, float):
                table.add_row(key, f"{value:.2f}")
            elif isinstance(value, list):
                table.add_row(key, ", ".join(str(v) for v in value))
            else:
                table.add_row(key, str(value))

        panel = Panel(
            table,
            title=f"[{self.theme.header}]{title}[/{self.theme.header}]",
            border_style=self.theme.border,
            expand=False,
        )
        self.print(panel)

    # =========================================================================
    # Tables
    # =========================================================================

    def create_table(
        self,
        title: str = "",
        columns: list[str] | None = None,
        show_header: bool = True,
    ) -> Table:
        """Create a styled table."""
        table = Table(
            title=(f"[{self.theme.header}]{title}[/{self.theme.header}]" if title else None),
            show_header=show_header,
            header_style=self.theme.header,
            border_style=self.theme.border,
        )

        if columns:
            for col in columns:
                table.add_column(col)

        return table

    def print_findings_table(self, findings: list[dict[str, Any]], max_items: int = 10) -> None:
        """Print a table of security findings."""
        table = self.create_table(
            "Security Findings",
            columns=["ID", "Severity", "Title", "Location"],
        )

        for finding in findings[:max_items]:
            severity = finding.get("severity", "unknown")
            severity_color = self.theme.get_severity_color(severity)

            table.add_row(
                finding.get("id", "N/A")[:12],
                f"[{severity_color}]{severity.upper()}[/{severity_color}]",
                finding.get("title", "Unknown")[:50],
                f"{finding.get('location', {}).get('file_path', 'N/A')[-40:]}:{finding.get('location', {}).get('line_number', '?')}",
            )

        if len(findings) > max_items:
            table.add_row("...", "...", f"and {len(findings) - max_items} more", "...")

        self.print(table)

    def print_agents_table(self, agents: list[dict[str, Any]], max_items: int = 15) -> None:
        """Print a table of detected agents."""
        table = self.create_table(
            "Detected Agents",
            columns=["Name", "Framework", "Trust", "Tools", "Location"],
        )

        for agent in agents[:max_items]:
            tools = agent.get("tools", [])
            tools_str = f"{len(tools)} tools" if tools else "None"

            table.add_row(
                agent.get("name", "Unknown")[:25],
                agent.get("framework", "unknown"),
                str(agent.get("trust_level", "?")),
                tools_str,
                f"{agent.get('location', {}).get('file_path', 'N/A')[-30:]}",
            )

        if len(agents) > max_items:
            table.add_row("...", "...", "...", "...", f"+{len(agents) - max_items} more")

        self.print(table)

    # =========================================================================
    # Progress Indicators
    # =========================================================================

    @contextmanager
    def progress_context(self, description: str = "Processing") -> Generator[Progress, None, None]:
        """Context manager for progress display."""
        progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=self.console,
            disable=self.quiet,
        )

        with progress:
            yield progress

    def create_stage_progress(self) -> ScanProgress:
        """Create a scan progress tracker."""
        return ScanProgress(self)


class ScanProgress:
    """Progress tracker for multi-stage scans with enhanced progress bar."""

    STAGES = [
        ("Initializing", "Setting up scan environment"),
        ("Parsing", "Analyzing source files"),
        ("Topology", "Building agent graph"),
        ("Trust Analysis", "Classifying trust boundaries"),
        ("Vulnerability Scan", "Detecting security issues"),
        ("ML Detection", "Running ML-based analysis"),
        ("Scoring", "Calculating security score"),
        ("Simulation", "Running attack simulations"),
        ("Remediation", "Generating fix suggestions"),
        ("Report", "Preparing output"),
        ("Complete", "Scan finished"),
    ]

    def __init__(self, console: MimicConsole):
        self.console = console
        self.current_stage = 0
        self._progress: Progress | None = None
        self._task_id: TaskID | None = None
        self._file_count: int = 0
        self._agent_count: int = 0

    def start(self, file_count: int = 0) -> None:
        """Start progress display.

        Args:
            file_count: Total number of files to scan (for large scan display)
        """
        if self.console.quiet:
            return

        self._file_count = file_count

        self._progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=30),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TextColumn("({task.fields[detail]})") if file_count > 0 else TextColumn(""),
            TimeElapsedColumn(),
            console=self.console.console,
            expand=False,
        )
        self._progress.start()
        self._task_id = self._progress.add_task(
            self.STAGES[0][0],
            total=len(self.STAGES) * 10,
            detail=f"{file_count} files" if file_count > 0 else "",
        )

    def update(self, stage_name: str, progress_pct: int = 0, detail: str = "") -> None:
        """Update progress with stage name and optional detail.

        Args:
            stage_name: Current stage name
            progress_pct: Progress within stage (0-100)
            detail: Optional detail text (e.g., "42/100 files", "15 agents")
        """
        if self._progress and self._task_id is not None:
            # Find stage index
            for i, (name, _) in enumerate(self.STAGES):
                if name.lower() in stage_name.lower():
                    self.current_stage = i
                    break

            advance = (self.current_stage * 10) + (progress_pct // 10)
            update_kwargs = {
                "description": stage_name,
                "completed": advance,
            }
            if detail:
                update_kwargs["detail"] = detail
            self._progress.update(self._task_id, **update_kwargs)

    def set_agent_count(self, count: int) -> None:
        """Update agent count for display."""
        self._agent_count = count

    def stop(self) -> None:
        """Stop progress display."""
        if self._progress:
            self._progress.stop()


# Global console instance
console = MimicConsole()


def get_console(quiet: bool = False, theme: Theme | None = None) -> MimicConsole:
    """Get a console instance with the specified settings."""
    return MimicConsole(theme=theme or DEFAULT_THEME, quiet=quiet)
