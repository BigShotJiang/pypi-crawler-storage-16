"""
HTML Report Generator for Vantage.

Creates a standalone, professional compliance report.
Wraps the modern HTMLReportGenerator from vantage-core.
"""

from datetime import datetime
from pathlib import Path

from vantage_core.models import ScanResult
from vantage_core.security.reports.html_report import HTMLReportGenerator
from vantage_core.security.pipeline.orchestrator import PipelineResult, ScanStage


def generate_html_report(result: ScanResult, output_path: str = "vantage_report.html"):
    """Generate a standalone HTML report using the modern generator."""
    
    # Wrap legacy ScanResult into PipelineResult
    # (Since we don't have full pipeline context, we mock the rest)
    
    # Convert core ScanResult to SecurityScanResult-like structure if needed
    # Actually, HTMLReportGenerator expects a PipelineResult which has a .scan_result
    # The scan_result in PipelineResult is typically a SecurityScanResult, 
    # but let's check if we can adapter it or if we need to convert.
    
    # Check if result is Core ScanResult or SecurityScanResult
    # If Core, we need to adapt it.
    
    # Adapting ScanResult (Core) -> SecurityScanResult (Security)
    from vantage_core.security.models import SecurityScanResult, SecurityAgent, SecurityFinding, Severity, OWASPCategory, VulnerabilityCategory
    
    # Convert Agents
    sec_agents = []
    for a in result.agents:
        sec_agents.append(SecurityAgent(
            id=a.id,
            name=a.name,
            framework=str(a.framework.value if hasattr(a.framework, "value") else a.framework),
            tools=[], # Simplification
            file_path=a.file_path,
            line_number=a.line_number
        ))
        
    # Mock Findings (Legacy scan doesn't do deep vuln scan)
    findings = []
    
    # Mock SecurityScanResult
    sec_result = SecurityScanResult(
        scan_id="LEGACY-SCAN",
        timestamp=datetime.now(),
        findings=findings,
        agents_scanned=len(result.agents),
        frameworks_detected=[result.framework] if isinstance(result.framework, str) else result.framework,
        scan_duration_ms=0,
        agents=sec_agents,
        communications=[] # Core ScanResult connections -> communications?
    )
    
    # Convert Core connections to Security communications
    from vantage_core.security.models import AgentCommunication
    if result.connections:
        for c in result.connections:
            sec_result.communications.append(AgentCommunication(
                source_id=c.source_id,
                target_id=c.target_id,
                communication_type=c.connection_type.name if hasattr(c.connection_type, 'name') else str(c.connection_type)
            ))

    pipeline_result = PipelineResult(
        scan_id="LEGACY-SCAN",
        status="completed",
        stages_completed=[ScanStage.REPORT],
        stages_failed=[],
        scan_result=sec_result,
        atss_result=None,
        simulation_results=[],
        remediations=[],
        duration_ms=0,
        started_at=datetime.now(),
        completed_at=datetime.now()
    )

    generator = HTMLReportGenerator()
    html_content = generator.generate(pipeline_result)

    # Write to file
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    return output_path
