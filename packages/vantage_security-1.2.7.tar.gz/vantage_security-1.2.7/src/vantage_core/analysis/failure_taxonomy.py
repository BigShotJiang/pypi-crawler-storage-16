"""MAST Failure Taxonomy Detection based on research paper "Why Do Multi-Agent LLM Systems Fail?"

This module implements pre-deployment detection of the 14 failure modes identified
in the MAST taxonomy (Cemri et al., 2025, arXiv:2503.13657).

Reference: https://arxiv.org/abs/2503.13657
"""

from __future__ import annotations

import logging
import math
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

import numpy as np

if TYPE_CHECKING:
    from vantage_core.core.models import AgentSystem

logger = logging.getLogger(__name__)

# Try to import sentence-transformers for semantic detection
try:
    from sentence_transformers import SentenceTransformer
    from sklearn.metrics.pairwise import cosine_similarity

    SEMANTIC_AVAILABLE = True
except ImportError:
    SEMANTIC_AVAILABLE = False
    SentenceTransformer = None
    cosine_similarity = None

# Try to import transformers for NLI
try:
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    NLI_AVAILABLE = True
except ImportError:
    NLI_AVAILABLE = False
    AutoModelForSequenceClassification = None
    AutoTokenizer = None
    torch = None


class DetectionMode(str, Enum):
    """Detection algorithm selection."""

    KEYWORD = "keyword"  # Current implementation (baseline)
    SEMANTIC = "semantic"  # Embedding-based similarity
    NLI = "nli"  # Natural language inference
    HYBRID = "hybrid"  # Combined approach


@dataclass
class SemanticFailureConfig:
    """Configuration for semantic failure detection."""

    detection_mode: DetectionMode = DetectionMode.HYBRID
    embedding_model: str = "all-MiniLM-L6-v2"
    nli_model: str = "microsoft/deberta-v3-base-mnli-fever-anli"
    similarity_threshold: float = 0.6
    nli_confidence_threshold: float = 0.7
    temperature: float = 0.1  # Risk score calibration (tau)
    beta: float = 0.0  # Decision boundary offset
    confidence_threshold: float = 0.45  # Below this, flag as uncertain
    enable_caching: bool = True
    batch_size: int = 32


@dataclass
class SemanticPrototype:
    """Semantic prototype for a failure mode."""

    failure_code: str
    positive_examples: list[str]  # Examples of safe patterns
    negative_examples: list[str]  # Examples of failure patterns
    safety_properties: list[str] = field(default_factory=list)  # NLI premises to verify


@dataclass
class NLIResult:
    """Result from NLI verification."""

    property_text: str
    label: str  # entailment, contradiction, neutral
    confidence: float
    entailment_score: float
    contradiction_score: float
    neutral_score: float


# Semantic prototypes for each failure mode
SEMANTIC_PROTOTYPES: dict[str, SemanticPrototype] = {
    "FM-1.1": SemanticPrototype(
        failure_code="FM-1.1",
        positive_examples=[
            "follow all user requirements and constraints strictly",
            "adhere to task specifications without deviation",
            "respect constraints and boundaries in all operations",
            "comply with given instructions precisely",
            "execute only within defined parameters",
        ],
        negative_examples=[
            "ignore user constraints when necessary",
            "override safety limits to complete tasks",
            "bypass restrictions for better results",
            "disregard instructions if they seem inefficient",
            "take creative liberties with specifications",
        ],
        safety_properties=[
            "Agent follows task constraints",
            "Agent respects user requirements",
        ],
    ),
    "FM-1.2": SemanticPrototype(
        failure_code="FM-1.2",
        positive_examples=[
            "your role is specifically to handle data validation",
            "you are exclusively responsible for user authentication",
            "focus only on your designated responsibilities",
            "do not attempt tasks outside your defined role",
            "stay within your area of expertise",
        ],
        negative_examples=[
            "handle any task that comes your way",
            "expand your responsibilities as needed",
            "take on additional roles when helpful",
            "assist with anything the user requests",
            "be flexible about your role boundaries",
        ],
        safety_properties=[
            "Agent has clearly defined role",
            "Agent stays within role boundaries",
        ],
    ),
    "FM-1.3": SemanticPrototype(
        failure_code="FM-1.3",
        positive_examples=[
            "once completed, move to the next step without repeating",
            "after finishing a task, proceed forward",
            "do not repeat steps that are already done",
            "mark completion and continue to next phase",
            "avoid redundant iterations of completed work",
        ],
        negative_examples=[
            "repeat the process until perfect",
            "retry steps multiple times for better results",
            "iterate on the same task repeatedly",
            "keep working on this until told to stop",
            "redo previous steps to ensure quality",
        ],
    ),
    "FM-1.4": SemanticPrototype(
        failure_code="FM-1.4",
        positive_examples=[
            "maintain context from previous interactions",
            "remember and reference earlier conversation",
            "preserve history of past exchanges",
            "build upon previous discussion points",
            "retain information from earlier messages",
        ],
        negative_examples=[
            "start fresh with each interaction",
            "treat each message independently",
            "ignore previous conversation context",
            "focus only on the current message",
            "do not reference earlier exchanges",
        ],
    ),
    "FM-1.5": SemanticPrototype(
        failure_code="FM-1.5",
        positive_examples=[
            "stop when the success criteria are met",
            "terminate task when objectives are achieved",
            "finish when all requirements are satisfied",
            "end processing when done conditions are true",
            "complete work when quality thresholds reached",
        ],
        negative_examples=[
            "continue working indefinitely",
            "keep processing without clear end point",
            "run until externally stopped",
            "operate continuously without termination",
            "proceed without checking completion status",
        ],
    ),
    "FM-2.1": SemanticPrototype(
        failure_code="FM-2.1",
        positive_examples=[
            "continue from where the previous agent left off",
            "resume the conversation with full context",
            "pick up the workflow from the last state",
            "carry on with preserved conversation history",
            "maintain dialogue continuity across handoffs",
        ],
        negative_examples=[
            "start a new conversation each time",
            "reset context when taking over",
            "begin fresh without previous state",
            "ignore prior conversation history",
            "restart dialogue from the beginning",
        ],
    ),
    "FM-2.2": SemanticPrototype(
        failure_code="FM-2.2",
        positive_examples=[
            "ask for clarification when information is unclear",
            "request more details if uncertain",
            "query other agents when data is missing",
            "seek additional information when needed",
            "confirm understanding before proceeding",
        ],
        negative_examples=[
            "make assumptions when information is missing",
            "proceed with best guess if unclear",
            "fill in gaps without verification",
            "continue without asking questions",
            "assume intent when uncertain",
        ],
    ),
    "FM-2.3": SemanticPrototype(
        failure_code="FM-2.3",
        positive_examples=[
            "stay focused on the primary objective",
            "maintain focus on the assigned task",
            "do not deviate to unrelated topics",
            "keep work aligned with stated goals",
            "avoid tangents and stay on topic",
        ],
        negative_examples=[
            "explore related topics freely",
            "investigate interesting tangents",
            "expand scope when opportunities arise",
            "pursue adjacent ideas as they come up",
            "follow wherever the work leads",
        ],
    ),
    "FM-2.4": SemanticPrototype(
        failure_code="FM-2.4",
        positive_examples=[
            "pass all relevant information to the next agent",
            "share complete data with downstream agents",
            "forward necessary context and results",
            "include all important details in handoff",
            "communicate findings fully to team members",
        ],
        negative_examples=[
            "share only essential information",
            "minimize data passed to others",
            "keep detailed information private",
            "pass summaries instead of full data",
            "withhold implementation details",
        ],
    ),
    "FM-2.5": SemanticPrototype(
        failure_code="FM-2.5",
        positive_examples=[
            "incorporate input from other agents",
            "consider and use peer recommendations",
            "build upon output from previous agents",
            "integrate feedback from team members",
            "acknowledge and process inputs received",
        ],
        negative_examples=[
            "work independently without considering others",
            "ignore suggestions from other agents",
            "proceed without reviewing peer output",
            "disregard recommendations received",
            "operate in isolation from team input",
        ],
    ),
    "FM-2.6": SemanticPrototype(
        failure_code="FM-2.6",
        positive_examples=[
            "explain your reasoning before taking action",
            "describe thought process then execute",
            "justify decisions with clear rationale",
            "show your work before presenting results",
            "think through steps before acting",
        ],
        negative_examples=[
            "act quickly without explanation",
            "execute first, explain later if asked",
            "skip reasoning to save time",
            "just do it without showing work",
            "present results without methodology",
        ],
    ),
    "FM-3.1": SemanticPrototype(
        failure_code="FM-3.1",
        positive_examples=[
            "verify all objectives are met before finishing",
            "ensure completion criteria satisfied before ending",
            "check that all requirements fulfilled before done",
            "confirm all tasks complete before terminating",
            "validate full achievement before signaling completion",
        ],
        negative_examples=[
            "finish quickly once main task done",
            "end when primary objective seems met",
            "complete when good enough achieved",
            "terminate when most work is done",
            "stop when estimated completion reached",
        ],
    ),
    "FM-3.2": SemanticPrototype(
        failure_code="FM-3.2",
        positive_examples=[
            "verify output meets quality standards",
            "validate results against acceptance criteria",
            "check response accuracy before returning",
            "test output for correctness and completeness",
            "confirm quality assurance checks pass",
        ],
        negative_examples=[
            "return output without verification",
            "skip validation to save time",
            "trust output without checking",
            "assume correctness without testing",
            "deliver results without quality review",
        ],
    ),
    "FM-3.3": SemanticPrototype(
        failure_code="FM-3.3",
        positive_examples=[
            "use specific criteria to judge success",
            "apply defined thresholds for acceptance",
            "follow clear standards for validation",
            "check against explicit benchmarks",
            "measure quality with objective metrics",
        ],
        negative_examples=[
            "use intuition to judge quality",
            "rely on subjective assessment",
            "evaluate based on general impression",
            "judge success by feel",
            "assess quality without clear criteria",
        ],
    ),
}


@dataclass
class SemanticEvidence:
    """Evidence from semantic analysis."""

    positive_similarity: float
    negative_similarity: float
    risk_score: float
    detection_method: str
    is_uncertain: bool = False


@dataclass
class SemanticFailureRisk:
    """Enhanced failure risk with semantic analysis."""

    failure_mode: FailureMode
    risk_level: str
    risk_score: float  # 0-100
    confidence: float  # 0-1
    semantic_evidence: dict[str, Any]
    agents_at_risk: list[str]
    recommendation: str


class FailureCategory(str, Enum):
    """The three main failure categories from MAST taxonomy."""

    FC1_SPECIFICATION = "FC1: Specification & System Design"
    FC2_INTER_AGENT = "FC2: Inter-Agent Misalignment"
    FC3_VERIFICATION = "FC3: Task Verification & Termination"


@dataclass
class FailureMode:
    """A specific failure mode from the MAST taxonomy."""

    code: str  # e.g., "FM-1.1"
    name: str
    category: FailureCategory
    description: str
    detection_patterns: list[str] = field(default_factory=list)
    absence_patterns: list[str] = field(default_factory=list)  # Missing these indicates risk
    risk_weight: float = 1.0  # Relative severity weight
    recommendation: str = ""


# The 14 failure modes from MAST taxonomy with detection heuristics
MAST_FAILURE_MODES: list[FailureMode] = [
    # FC1: Specification and System Design Failures
    FailureMode(
        code="FM-1.1",
        name="Disobey task specification",
        category=FailureCategory.FC1_SPECIFICATION,
        description="Agent fails to follow task constraints or requirements",
        absence_patterns=[
            r"(?:must|should|always|never|only|do\s+not)",
            r"(?:constraint|requirement|rule|boundary|limit)",
        ],
        risk_weight=1.2,
        recommendation="Add explicit constraints: 'You must...', 'Do not...', 'Only handle...'",
    ),
    FailureMode(
        code="FM-1.2",
        name="Disobey role specification",
        category=FailureCategory.FC1_SPECIFICATION,
        description="Agent oversteps defined responsibilities",
        absence_patterns=[
            r"your\s+(?:role|job|responsibility)\s+is",
            r"you\s+are\s+(?:a|an|the)",
            r"(?:exclusively|specifically|only)\s+(?:handle|responsible)",
        ],
        risk_weight=1.3,
        recommendation="Define clear role boundaries: 'Your role is...', 'You are exclusively responsible for...'",
    ),
    FailureMode(
        code="FM-1.3",
        name="Step repetition",
        category=FailureCategory.FC1_SPECIFICATION,
        description="Unnecessary reiteration of completed process steps",
        detection_patterns=[
            r"(?:repeat|again|retry|redo)\s+(?:if|when|until)",
        ],
        absence_patterns=[
            r"(?:once|after\s+completing|when\s+done)",
            r"(?:do\s+not\s+repeat|avoid\s+repeating)",
        ],
        risk_weight=0.8,
        recommendation="Add completion markers: 'Once X is done, proceed to Y without repeating'",
    ),
    FailureMode(
        code="FM-1.4",
        name="Loss of conversation history",
        category=FailureCategory.FC1_SPECIFICATION,
        description="Context truncation and reverting to earlier states",
        absence_patterns=[
            r"(?:context|history|previous|earlier|prior)",
            r"(?:remember|retain|maintain|preserve)",
        ],
        risk_weight=1.1,
        recommendation="Add context awareness: 'Based on previous interactions...', 'Retain context from...'",
    ),
    FailureMode(
        code="FM-1.5",
        name="Unaware of termination conditions",
        category=FailureCategory.FC1_SPECIFICATION,
        description="Failure to recognize when to stop",
        absence_patterns=[
            r"(?:stop|terminate|complete|finish|end)\s+(?:when|if|after)",
            r"(?:success\s+criteria|done\s+when|finished\s+when)",
        ],
        risk_weight=1.4,
        recommendation="Define termination: 'Stop when...', 'Task is complete when...', 'Success criteria: ...'",
    ),
    # FC2: Inter-Agent Misalignment
    FailureMode(
        code="FM-2.1",
        name="Conversation reset",
        category=FailureCategory.FC2_INTER_AGENT,
        description="Unwarranted dialogue restart losing context",
        absence_patterns=[
            r"(?:continue|resume|pick\s+up|carry\s+on)",
            r"(?:maintain\s+state|preserve\s+context)",
        ],
        risk_weight=1.0,
        recommendation="Add continuity instructions: 'Continue from where the previous agent left off'",
    ),
    FailureMode(
        code="FM-2.2",
        name="Fail to ask for clarification",
        category=FailureCategory.FC2_INTER_AGENT,
        description="Inability to request needed information from other agents",
        absence_patterns=[
            r"(?:ask|request|query|clarify|confirm)\s+(?:from|with)",
            r"(?:if\s+unclear|when\s+uncertain|need\s+more\s+information)",
        ],
        risk_weight=1.1,
        recommendation="Enable clarification: 'If information is unclear, ask [Agent] for clarification'",
    ),
    FailureMode(
        code="FM-2.3",
        name="Task derailment",
        category=FailureCategory.FC2_INTER_AGENT,
        description="Deviation from intended objectives",
        absence_patterns=[
            r"(?:focus\s+on|stay\s+on\s+task|primary\s+objective)",
            r"(?:do\s+not\s+deviate|avoid\s+tangents)",
        ],
        risk_weight=1.2,
        recommendation="Reinforce focus: 'Stay focused on [task]. Do not deviate to unrelated topics.'",
    ),
    FailureMode(
        code="FM-2.4",
        name="Information withholding",
        category=FailureCategory.FC2_INTER_AGENT,
        description="Failure to share critical data between agents",
        absence_patterns=[
            r"(?:pass|share|forward|send|communicate)\s+(?:to|with)",
            r"(?:include|provide|attach)\s+(?:all|relevant|necessary)",
        ],
        risk_weight=1.3,
        recommendation="Ensure data sharing: 'Pass all relevant information to [next agent]'",
    ),
    FailureMode(
        code="FM-2.5",
        name="Ignored other agent's input",
        category=FailureCategory.FC2_INTER_AGENT,
        description="Disregarding peer recommendations or outputs",
        absence_patterns=[
            r"(?:consider|review|incorporate|use)\s+(?:input|output|result)\s+from",
            r"(?:based\s+on|according\s+to)\s+(?:previous|other)\s+agent",
        ],
        risk_weight=1.2,
        recommendation="Acknowledge inputs: 'Review and incorporate the output from [Agent]'",
    ),
    FailureMode(
        code="FM-2.6",
        name="Reasoning-action mismatch",
        category=FailureCategory.FC2_INTER_AGENT,
        description="Discrepancy between stated reasoning and actual actions",
        absence_patterns=[
            r"(?:explain|justify|reason)\s+(?:before|why|your)",
            r"(?:step.by.step|think.*then.*act)",
        ],
        risk_weight=1.0,
        recommendation="Enforce reasoning: 'Explain your reasoning before taking action'",
    ),
    # FC3: Task Verification and Termination
    FailureMode(
        code="FM-3.1",
        name="Premature termination",
        category=FailureCategory.FC3_VERIFICATION,
        description="Ending interaction before objectives are met",
        absence_patterns=[
            r"(?:verify|ensure|confirm|check)\s+(?:all|every|each)",
            r"(?:before\s+(?:finishing|completing|ending))",
        ],
        risk_weight=1.4,
        recommendation="Add completion check: 'Before finishing, verify all objectives are met'",
    ),
    FailureMode(
        code="FM-3.2",
        name="No or incomplete verification",
        category=FailureCategory.FC3_VERIFICATION,
        description="Omission of proper outcome checking",
        absence_patterns=[
            r"(?:validate|verify|check|test|confirm)\s+(?:result|output|response)",
            r"(?:quality|accuracy|correctness)\s+(?:check|control|assurance)",
        ],
        risk_weight=1.5,
        recommendation="Add verification: 'Verify the output meets quality standards before returning'",
    ),
    FailureMode(
        code="FM-3.3",
        name="Incorrect verification",
        category=FailureCategory.FC3_VERIFICATION,
        description="Inadequate validation of information or decisions",
        absence_patterns=[
            r"(?:criteria|standard|threshold|benchmark)\s+for\s+(?:success|quality)",
            r"(?:accept.*if|reject.*if|valid.*when)",
        ],
        risk_weight=1.3,
        recommendation="Define criteria: 'Accept output if [criteria]. Reject and retry if [conditions].'",
    ),
]


@dataclass
class FailureRisk:
    """Detected risk of a specific failure mode."""

    failure_mode: FailureMode
    risk_level: str  # "low", "medium", "high", "critical"
    risk_score: float  # 0-100
    agents_at_risk: list[str]
    evidence: str
    recommendation: str


@dataclass
class CascadeRiskReport:
    """Report on cascade failure risk based on topology."""

    cascade_score: float  # 0-100, higher = more risk
    critical_paths: list[list[str]]  # Agent chains where errors propagate
    bottleneck_agents: list[str]  # Single points of failure
    recommendations: list[str]


class MASTFailureDetector:
    """Detects potential failure modes based on MAST taxonomy.

    This implements pre-deployment static analysis to identify risks
    of the 14 failure modes documented in "Why Do Multi-Agent LLM Systems Fail?"
    (Cemri et al., 2025).
    """

    def __init__(
        self,
        risk_threshold: float = 0.5,
        include_recommendations: bool = True,
    ):
        """Initialize the MAST failure detector.

        Args:
            risk_threshold: Minimum risk score (0-1) to report a failure mode
            include_recommendations: Whether to include fix recommendations
        """
        if not 0 <= risk_threshold <= 1:
            raise ValueError(f"risk_threshold must be 0-1, got {risk_threshold}")

        self.risk_threshold = risk_threshold
        self.include_recommendations = include_recommendations
        self._failure_modes = MAST_FAILURE_MODES

    def detect_failure_risks(self, system: AgentSystem) -> list[FailureRisk]:
        """Detect potential failure mode risks in a system.

        Args:
            system: The agent system to analyze

        Returns:
            List of detected failure risks
        """
        risks: list[FailureRisk] = []

        for fm in self._failure_modes:
            risk = self._check_failure_mode(system, fm)
            if risk and risk.risk_score >= self.risk_threshold * 100:
                risks.append(risk)

        # Sort by risk score descending
        risks.sort(key=lambda r: r.risk_score, reverse=True)

        return risks

    def _check_failure_mode(self, system: AgentSystem, fm: FailureMode) -> FailureRisk | None:
        """Check a system for a specific failure mode risk."""
        agents_at_risk: list[str] = []
        total_score = 0.0
        evidence_parts: list[str] = []

        for agent_id, agent in system.agents.items():
            prompt_lower = agent.prompt.content.lower()
            agent_score = 0.0

            # Check for absence of protective patterns
            if fm.absence_patterns:
                missing_patterns = []
                for pattern in fm.absence_patterns:
                    if not re.search(pattern, prompt_lower):
                        missing_patterns.append(pattern)
                        agent_score += 1.0 / len(fm.absence_patterns)

                if missing_patterns:
                    agents_at_risk.append(agent_id)

            # Check for presence of risky patterns
            if fm.detection_patterns:
                found_patterns = []
                for pattern in fm.detection_patterns:
                    if re.search(pattern, prompt_lower):
                        found_patterns.append(pattern)
                        agent_score += 0.5

                if found_patterns and agent_id not in agents_at_risk:
                    agents_at_risk.append(agent_id)

            total_score += agent_score

        if not agents_at_risk:
            return None

        # Normalize score to 0-100
        max_possible = len(system.agents) * (
            1.0 + 0.5 * len(fm.detection_patterns) if fm.detection_patterns else 1.0
        )
        normalized_score = (
            (total_score / max_possible) * 100 * fm.risk_weight if max_possible > 0 else 0
        )
        normalized_score = min(normalized_score, 100)

        # Determine risk level
        if normalized_score >= 80:
            risk_level = "critical"
        elif normalized_score >= 60:
            risk_level = "high"
        elif normalized_score >= 40:
            risk_level = "medium"
        else:
            risk_level = "low"

        # Build evidence string
        evidence = f"{len(agents_at_risk)}/{len(system.agents)} agents missing protective patterns for {fm.name}"

        return FailureRisk(
            failure_mode=fm,
            risk_level=risk_level,
            risk_score=normalized_score,
            agents_at_risk=agents_at_risk,
            evidence=evidence,
            recommendation=fm.recommendation if self.include_recommendations else "",
        )

    def calculate_cascade_risk(self, system: AgentSystem) -> CascadeRiskReport:
        """Calculate cascade failure risk based on topology.

        Based on research showing hierarchical structures have 5.5% performance drop
        vs 23.7% for chain structures when an agent fails.

        Reference: "On the Resilience of LLM-Based Multi-Agent Collaboration
        with Faulty Agents" (ICML 2025)
        """
        recommendations: list[str] = []

        # Analyze topology structure
        agents = list(system.agents.keys())
        connections = system.topology.connections

        if len(agents) <= 1:
            return CascadeRiskReport(
                cascade_score=0,
                critical_paths=[],
                bottleneck_agents=[],
                recommendations=["Single agent system - no cascade risk"],
            )

        # Build adjacency for path analysis
        downstream: dict[str, list[str]] = {a: [] for a in agents}
        upstream: dict[str, list[str]] = {a: [] for a in agents}

        for conn in connections:
            if conn.source in downstream:
                downstream[conn.source].append(conn.target)
            if conn.target in upstream:
                upstream[conn.target].append(conn.source)

        # Find critical paths (longest chains)
        critical_paths: list[list[str]] = []

        # Start from entry points or agents with no upstream
        entry_agents = system.topology.entry_points or [a for a in agents if not upstream.get(a)]

        def find_paths(start: str, path: list[str], visited: set[str]) -> list[list[str]]:
            if start in visited:
                return [path]

            visited.add(start)
            new_path = path + [start]

            if not downstream.get(start):
                return [new_path]

            all_paths = []
            for next_agent in downstream[start]:
                all_paths.extend(find_paths(next_agent, new_path, visited.copy()))

            return all_paths if all_paths else [new_path]

        for entry in entry_agents:
            paths = find_paths(entry, [], set())
            critical_paths.extend(paths)

        # Sort by length (longest = most cascade risk)
        critical_paths.sort(key=len, reverse=True)
        critical_paths = critical_paths[:5]  # Top 5 critical paths

        # Find bottleneck agents (high in-degree or out-degree)
        bottleneck_agents: list[str] = []
        for agent_id in agents:
            in_degree = len(upstream.get(agent_id, []))
            out_degree = len(downstream.get(agent_id, []))

            if in_degree >= 3 or out_degree >= 3:
                bottleneck_agents.append(agent_id)

        # Calculate cascade score based on topology characteristics
        # Research shows:
        # - Chain (A->B->C): 23.7% performance drop on agent failure
        # - Flat (A->[B,C,D]): 10.5% drop
        # - Hierarchical (A->(B<->C)): 5.5% drop

        longest_path = max(len(p) for p in critical_paths) if critical_paths else 0
        num_connections = len(connections)
        num_agents = len(agents)

        # Chain-like structure = high risk
        # Lots of connections relative to agents = more redundancy = lower risk
        if num_agents > 1:
            connectivity_ratio = num_connections / (num_agents * (num_agents - 1))
        else:
            connectivity_ratio = 0

        # Score components
        path_risk = min(longest_path / 5, 1.0) * 40  # Long paths = high risk
        bottleneck_risk = min(len(bottleneck_agents) / max(num_agents / 2, 1), 1.0) * 30
        connectivity_bonus = (1 - connectivity_ratio) * 30  # Low connectivity = high risk

        cascade_score = path_risk + bottleneck_risk + connectivity_bonus

        # Generate recommendations
        if longest_path >= 4:
            recommendations.append(
                f"Critical: Chain of {longest_path} agents detected. "
                "Research shows 23.7% performance drop vs 5.5% for hierarchical structures. "
                "Consider adding parallel paths or a coordinator agent."
            )

        if bottleneck_agents:
            recommendations.append(
                f"Bottleneck agents detected: {', '.join(bottleneck_agents)}. "
                "Single points of failure. Consider adding redundancy or splitting responsibilities."
            )

        if connectivity_ratio < 0.3 and num_agents > 3:
            recommendations.append(
                "Low connectivity between agents. Errors will cascade without redundant paths. "
                "Add verification agents or peer-review connections."
            )

        # Based on research: suggest Challenger + Inspector pattern
        if cascade_score > 50:
            recommendations.append(
                "Research shows adding 'Challenger' (agents question each other) and "
                "'Inspector' (independent reviewer) can recover up to 96% of lost performance."
            )

        if not recommendations:
            recommendations.append("Topology has good resilience characteristics.")

        return CascadeRiskReport(
            cascade_score=cascade_score,
            critical_paths=critical_paths,
            bottleneck_agents=bottleneck_agents,
            recommendations=recommendations,
        )

    def get_category_summary(self, risks: list[FailureRisk]) -> dict[str, dict]:
        """Get summary statistics by failure category."""
        summary: dict[str, dict] = {
            FailureCategory.FC1_SPECIFICATION.value: {
                "count": 0,
                "total_risk": 0,
                "risks": [],
            },
            FailureCategory.FC2_INTER_AGENT.value: {
                "count": 0,
                "total_risk": 0,
                "risks": [],
            },
            FailureCategory.FC3_VERIFICATION.value: {
                "count": 0,
                "total_risk": 0,
                "risks": [],
            },
        }

        for risk in risks:
            cat = risk.failure_mode.category.value
            summary[cat]["count"] += 1
            summary[cat]["total_risk"] += risk.risk_score
            summary[cat]["risks"].append(risk.failure_mode.code)

        # Calculate average risk per category
        for cat in summary:
            if summary[cat]["count"] > 0:
                summary[cat]["avg_risk"] = summary[cat]["total_risk"] / summary[cat]["count"]
            else:
                summary[cat]["avg_risk"] = 0

        return summary


class SemanticFailureDetector:
    """Semantic-aware MAST failure mode detector using embeddings.

    Uses sentence-transformers to compute semantic similarity between
    agent prompts and failure mode prototypes. Optionally uses NLI for
    safety property verification. Falls back to keyword matching if
    ML dependencies are unavailable.
    """

    def __init__(self, config: SemanticFailureConfig | None = None):
        """Initialize with configuration.

        Args:
            config: Configuration for semantic detection
        """
        self.config = config or SemanticFailureConfig()
        self._embedder = None
        self._nli_model = None
        self._nli_tokenizer = None
        self._prototype_embeddings: dict[str, dict[str, np.ndarray]] = {}
        self._embedding_cache: dict[str, np.ndarray] = {}
        self._failure_modes = MAST_FAILURE_MODES
        self._keyword_detector = MASTFailureDetector(
            risk_threshold=0.5, include_recommendations=True
        )

        # Initialize embedder if semantic mode is enabled
        if self.config.detection_mode in (
            DetectionMode.SEMANTIC,
            DetectionMode.HYBRID,
            DetectionMode.NLI,
        ):
            self._initialize_embedder()

        # Initialize NLI model if NLI mode is enabled
        if self.config.detection_mode in (DetectionMode.NLI, DetectionMode.HYBRID):
            self._initialize_nli_model()

    def _initialize_embedder(self) -> None:
        """Initialize the sentence transformer model."""
        if not SEMANTIC_AVAILABLE:
            logger.warning(
                "sentence-transformers not installed. "
                "Install with: pip install sentence-transformers. "
                "Falling back to keyword detection."
            )
            return

        try:
            self._embedder = SentenceTransformer(self.config.embedding_model)
            self._precompute_prototype_embeddings()
            logger.info(f"Loaded semantic model: {self.config.embedding_model}")
        except Exception as e:
            logger.warning(
                f"Failed to load embedding model: {e}. Falling back to keyword detection."
            )
            self._embedder = None

    def _initialize_nli_model(self) -> None:
        """Initialize the NLI model for safety property verification."""
        if not NLI_AVAILABLE:
            logger.warning(
                "transformers not installed. "
                "Install with: pip install transformers torch. "
                "NLI verification will be disabled."
            )
            return

        try:
            self._nli_tokenizer = AutoTokenizer.from_pretrained(self.config.nli_model)
            self._nli_model = AutoModelForSequenceClassification.from_pretrained(
                self.config.nli_model
            )
            self._nli_model.eval()  # Set to evaluation mode
            logger.info(f"Loaded NLI model: {self.config.nli_model}")
        except Exception as e:
            logger.warning(f"Failed to load NLI model: {e}. NLI verification will be disabled.")
            self._nli_model = None
            self._nli_tokenizer = None

    def _precompute_prototype_embeddings(self) -> None:
        """Precompute embeddings for all prototypes."""
        if not self._embedder:
            return

        for code, prototype in SEMANTIC_PROTOTYPES.items():
            # Embed positive examples
            pos_embeddings = self._embedder.encode(
                prototype.positive_examples,
                convert_to_numpy=True,
                batch_size=self.config.batch_size,
            )

            # Embed negative examples
            neg_embeddings = self._embedder.encode(
                prototype.negative_examples,
                convert_to_numpy=True,
                batch_size=self.config.batch_size,
            )

            self._prototype_embeddings[code] = {
                "positive": pos_embeddings,
                "negative": neg_embeddings,
            }

    def _verify_safety_properties(self, prompt: str, properties: list[str]) -> list[NLIResult]:
        """Verify safety properties using NLI.

        For each property, check if prompt ENTAILS the property.

        Args:
            prompt: Agent prompt text (premise)
            properties: List of safety properties to verify (hypotheses)

        Returns:
            List of NLIResult with label and confidence for each property
        """
        if not self._nli_model or not self._nli_tokenizer or not properties:
            return []

        results: list[NLIResult] = []

        # Process in batches
        for i in range(0, len(properties), self.config.batch_size):
            batch_props = properties[i : i + self.config.batch_size]

            # Format as premise/hypothesis pairs
            premises = [prompt] * len(batch_props)
            hypotheses = batch_props

            try:
                # Tokenize
                inputs = self._nli_tokenizer(
                    premises,
                    hypotheses,
                    padding=True,
                    truncation=True,
                    max_length=512,
                    return_tensors="pt",
                )

                # Run inference
                with torch.no_grad():
                    outputs = self._nli_model(**inputs)
                    logits = outputs.logits

                # Convert to probabilities
                probs = torch.softmax(logits, dim=-1).numpy()

                # DeBERTa uses: 0=contradiction, 1=neutral, 2=entailment
                for j, prop in enumerate(batch_props):
                    contradiction_score = float(probs[j][0])
                    neutral_score = float(probs[j][1])
                    entailment_score = float(probs[j][2])

                    # Determine label
                    max_score = max(entailment_score, contradiction_score, neutral_score)
                    if max_score == entailment_score:
                        label = "entailment"
                        confidence = entailment_score
                    elif max_score == contradiction_score:
                        label = "contradiction"
                        confidence = contradiction_score
                    else:
                        label = "neutral"
                        confidence = neutral_score

                    results.append(
                        NLIResult(
                            property_text=prop,
                            label=label,
                            confidence=confidence,
                            entailment_score=entailment_score,
                            contradiction_score=contradiction_score,
                            neutral_score=neutral_score,
                        )
                    )

            except Exception as e:
                logger.warning(f"NLI verification failed: {e}")
                # Return neutral results on error
                for prop in batch_props:
                    results.append(
                        NLIResult(
                            property_text=prop,
                            label="neutral",
                            confidence=0.33,
                            entailment_score=0.33,
                            contradiction_score=0.33,
                            neutral_score=0.33,
                        )
                    )

        return results

    def _compute_nli_penalty(self, nli_results: list[NLIResult]) -> float:
        """Compute NLI penalty for risk formula.

        Higher penalty when safety properties are not entailed.

        Args:
            nli_results: List of NLI verification results

        Returns:
            Penalty value (0 = all entailed, positive = some not entailed)
        """
        if not nli_results:
            return 0.0

        penalty = 0.0
        for result in nli_results:
            if result.confidence >= self.config.nli_confidence_threshold:
                if result.label == "contradiction":
                    penalty += 0.3  # High penalty for contradiction
                elif result.label == "neutral":
                    penalty += 0.1  # Small penalty for neutral
                # No penalty for entailment
            else:
                # Low confidence - small penalty for uncertainty
                penalty += 0.05

        return penalty / len(nli_results)

    def detect_failure_risks(self, system: AgentSystem) -> list[SemanticFailureRisk]:
        """Detect failure risks with semantic analysis.

        Args:
            system: The agent system to analyze

        Returns:
            List of detected failure risks with semantic evidence
        """
        if self.config.detection_mode == DetectionMode.KEYWORD or not self._embedder:
            # Fall back to keyword detection
            return self._convert_keyword_results(
                self._keyword_detector.detect_failure_risks(system)
            )

        risks: list[SemanticFailureRisk] = []

        for fm in self._failure_modes:
            if fm.code not in SEMANTIC_PROTOTYPES:
                continue

            risk = self._check_failure_mode_semantic(system, fm)
            if risk and risk.risk_score >= 50:  # 50% threshold
                risks.append(risk)

        # Sort by risk score descending
        risks.sort(key=lambda r: r.risk_score, reverse=True)

        # If hybrid mode, combine with keyword results
        if self.config.detection_mode == DetectionMode.HYBRID:
            risks = self._merge_with_keyword_results(risks, system)

        return risks

    def _check_failure_mode_semantic(
        self, system: AgentSystem, fm: FailureMode
    ) -> SemanticFailureRisk | None:
        """Check a system for a specific failure mode using semantic analysis."""
        agents_at_risk: list[str] = []
        agent_scores: list[float] = []
        agent_evidence: list[SemanticEvidence] = []

        prototype = SEMANTIC_PROTOTYPES[fm.code]

        for agent_id, agent in system.agents.items():
            prompt = agent.prompt.content

            # Compute semantic risk
            evidence = self._compute_semantic_risk(prompt, prototype)

            if evidence.risk_score > 50:  # Risk threshold
                agents_at_risk.append(agent_id)
                agent_scores.append(evidence.risk_score)
                agent_evidence.append(evidence)

        if not agents_at_risk:
            return None

        # Aggregate risk score
        avg_score = np.mean(agent_scores)

        # Determine risk level
        if avg_score >= 80:
            risk_level = "critical"
        elif avg_score >= 60:
            risk_level = "high"
        elif avg_score >= 40:
            risk_level = "medium"
        else:
            risk_level = "low"

        # Calculate confidence based on separation between pos/neg similarity
        confidences = []
        for ev in agent_evidence:
            separation = abs(ev.negative_similarity - ev.positive_similarity)
            conf = min(separation * 2, 1.0)  # Scale separation to 0-1
            confidences.append(conf)

        avg_confidence = np.mean(confidences)

        # Check for uncertainty
        any_uncertain = any(ev.is_uncertain for ev in agent_evidence)

        # Build semantic evidence dict
        semantic_evidence = {
            "detection_method": "semantic",
            "avg_positive_similarity": float(
                np.mean([e.positive_similarity for e in agent_evidence])
            ),
            "avg_negative_similarity": float(
                np.mean([e.negative_similarity for e in agent_evidence])
            ),
            "is_uncertain": any_uncertain,
            "agent_details": {
                agents_at_risk[i]: {
                    "positive_sim": float(agent_evidence[i].positive_similarity),
                    "negative_sim": float(agent_evidence[i].negative_similarity),
                    "risk_score": float(agent_evidence[i].risk_score),
                }
                for i in range(len(agents_at_risk))
            },
        }

        return SemanticFailureRisk(
            failure_mode=fm,
            risk_level=risk_level,
            risk_score=float(avg_score),
            confidence=float(avg_confidence),
            semantic_evidence=semantic_evidence,
            agents_at_risk=agents_at_risk,
            recommendation=fm.recommendation,
        )

    def _compute_semantic_risk(self, prompt: str, prototype: SemanticPrototype) -> SemanticEvidence:
        """Compute semantic risk score using the formula:

        risk = sigmoid((neg_sim - pos_sim + nli_penalty + beta) / tau)

        Args:
            prompt: The agent prompt text
            prototype: The failure mode prototype

        Returns:
            SemanticEvidence with risk score and similarities
        """
        # Get prompt embedding (with caching)
        if self.config.enable_caching and prompt in self._embedding_cache:
            prompt_embedding = self._embedding_cache[prompt]
        else:
            prompt_embedding = self._embedder.encode([prompt], convert_to_numpy=True)[0]
            if self.config.enable_caching:
                self._embedding_cache[prompt] = prompt_embedding

        # Get prototype embeddings
        proto_embeds = self._prototype_embeddings[prototype.failure_code]
        pos_embeddings = proto_embeds["positive"]
        neg_embeddings = proto_embeds["negative"]

        # Compute cosine similarities
        prompt_2d = prompt_embedding.reshape(1, -1)

        pos_similarities = cosine_similarity(prompt_2d, pos_embeddings)[0]
        neg_similarities = cosine_similarity(prompt_2d, neg_embeddings)[0]

        # Take max similarity to each prototype set
        pos_sim = float(np.max(pos_similarities))
        neg_sim = float(np.max(neg_similarities))

        # Compute NLI penalty if safety properties exist and NLI is available
        nli_penalty = 0.0
        if prototype.safety_properties and self._nli_model:
            nli_results = self._verify_safety_properties(prompt, prototype.safety_properties)
            nli_penalty = self._compute_nli_penalty(nli_results)

        # Compute risk score using sigmoid formula with NLI penalty
        tau = self.config.temperature
        beta = self.config.beta

        raw_score = (neg_sim - pos_sim + nli_penalty + beta) / tau
        risk_score = 1 / (1 + math.exp(-raw_score))

        # Scale to 0-100
        risk_score_scaled = risk_score * 100

        # Check for uncertainty (near decision boundary)
        is_uncertain = abs(risk_score - 0.5) < self.config.confidence_threshold

        return SemanticEvidence(
            positive_similarity=pos_sim,
            negative_similarity=neg_sim,
            risk_score=risk_score_scaled,
            detection_method="semantic" if nli_penalty == 0.0 else "semantic+nli",
            is_uncertain=is_uncertain,
        )

    def _convert_keyword_results(
        self, keyword_risks: list[FailureRisk]
    ) -> list[SemanticFailureRisk]:
        """Convert keyword detection results to SemanticFailureRisk format."""
        return [
            SemanticFailureRisk(
                failure_mode=risk.failure_mode,
                risk_level=risk.risk_level,
                risk_score=risk.risk_score,
                confidence=0.7,  # Default confidence for keyword detection
                semantic_evidence={
                    "detection_method": "keyword",
                    "evidence": risk.evidence,
                },
                agents_at_risk=risk.agents_at_risk,
                recommendation=risk.recommendation,
            )
            for risk in keyword_risks
        ]

    def _merge_with_keyword_results(
        self, semantic_risks: list[SemanticFailureRisk], system: AgentSystem
    ) -> list[SemanticFailureRisk]:
        """Merge semantic results with keyword results for hybrid mode."""
        keyword_risks = self._keyword_detector.detect_failure_risks(system)

        # Create dict of semantic risks by failure code
        semantic_by_code = {r.failure_mode.code: r for r in semantic_risks}

        # Add keyword-only risks
        for kr in keyword_risks:
            if kr.failure_mode.code not in semantic_by_code:
                semantic_risks.append(
                    SemanticFailureRisk(
                        failure_mode=kr.failure_mode,
                        risk_level=kr.risk_level,
                        risk_score=kr.risk_score,
                        confidence=0.6,  # Lower confidence for keyword-only
                        semantic_evidence={
                            "detection_method": "keyword",
                            "evidence": kr.evidence,
                        },
                        agents_at_risk=kr.agents_at_risk,
                        recommendation=kr.recommendation,
                    )
                )
            else:
                # Combine scores (weighted average)
                sr = semantic_by_code[kr.failure_mode.code]
                combined_score = sr.risk_score * 0.7 + kr.risk_score * 0.3
                sr.risk_score = combined_score
                sr.semantic_evidence["keyword_score"] = kr.risk_score
                sr.semantic_evidence["combined"] = True

        # Re-sort by risk score
        semantic_risks.sort(key=lambda r: r.risk_score, reverse=True)

        return semantic_risks

    def get_category_summary(self, risks: list[SemanticFailureRisk]) -> dict[str, dict]:
        """Get summary statistics by failure category."""
        summary: dict[str, dict] = {
            FailureCategory.FC1_SPECIFICATION.value: {
                "count": 0,
                "total_risk": 0,
                "risks": [],
            },
            FailureCategory.FC2_INTER_AGENT.value: {
                "count": 0,
                "total_risk": 0,
                "risks": [],
            },
            FailureCategory.FC3_VERIFICATION.value: {
                "count": 0,
                "total_risk": 0,
                "risks": [],
            },
        }

        for risk in risks:
            cat = risk.failure_mode.category.value
            summary[cat]["count"] += 1
            summary[cat]["total_risk"] += risk.risk_score
            summary[cat]["risks"].append(risk.failure_mode.code)

        # Calculate average risk per category
        for cat in summary:
            if summary[cat]["count"] > 0:
                summary[cat]["avg_risk"] = summary[cat]["total_risk"] / summary[cat]["count"]
            else:
                summary[cat]["avg_risk"] = 0

        return summary
