"""Model Registry for centralized ML model management with lazy loading.

Provides a singleton registry that manages lazy loading, caching, and lifecycle
of ML models (embedding model, NLI model). Ensures heavy dependencies are only
loaded when their features are actually used.

Reference: US-027 - Model Registry and Lazy Loading
"""

from __future__ import annotations

import hashlib
import logging
import threading
from pathlib import Path
from typing import Any

import numpy as np

logger = logging.getLogger(__name__)

# Default cache directory
MODEL_CACHE_DIR = Path.home() / ".cache" / "vantage" / "models"

# Try to import cachetools for TTL caching
try:
    from cachetools import TTLCache

    CACHETOOLS_AVAILABLE = True
except ImportError:
    CACHETOOLS_AVAILABLE = False
    TTLCache = None

# Try to import sentence-transformers
try:
    from sentence_transformers import SentenceTransformer

    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False
    SentenceTransformer = None

# Try to import transformers for NLI
try:
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False
    AutoModelForSequenceClassification = None
    AutoTokenizer = None
    torch = None


class ModelRegistry:
    """Central model registry with lazy loading and caching.

    Singleton pattern ensures models are loaded once and shared across
    the application. Thread-safe initialization.

    Example:
        registry = ModelRegistry.get_instance()
        model = registry.get_embedding_model("all-MiniLM-L6-v2")
        embeddings = registry.get_embeddings(["text1", "text2"])
    """

    _instance: ModelRegistry | None = None
    _lock = threading.Lock()

    def __new__(cls) -> ModelRegistry:
        """Singleton pattern with thread-safe initialization."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(
        self,
        embedding_cache_size: int = 1000,
        embedding_cache_ttl: int = 3600,
    ):
        """Initialize the model registry.

        Args:
            embedding_cache_size: Maximum number of embeddings to cache
            embedding_cache_ttl: Time-to-live for cached embeddings in seconds
        """
        if self._initialized:
            return

        self._embedding_models: dict[str, Any] = {}
        self._nli_models: dict[str, tuple[Any, Any]] = {}  # (model, tokenizer)
        self._model_lock = threading.Lock()

        # Initialize embedding cache
        if CACHETOOLS_AVAILABLE and TTLCache is not None:
            self._embedding_cache: TTLCache | dict = TTLCache(
                maxsize=embedding_cache_size, ttl=embedding_cache_ttl
            )
        else:
            # Fallback to simple dict (no TTL)
            self._embedding_cache = {}
            logger.debug("cachetools not available, using simple dict for embedding cache")

        self._initialized = True

    @classmethod
    def get_instance(cls) -> ModelRegistry:
        """Get the singleton instance.

        Returns:
            The ModelRegistry singleton instance
        """
        return cls()

    @classmethod
    def reset_instance(cls) -> None:
        """Reset the singleton instance (for testing).

        This clears all loaded models and caches.
        """
        with cls._lock:
            if cls._instance is not None:
                cls._instance._embedding_models.clear()
                cls._instance._nli_models.clear()
                cls._instance._embedding_cache.clear()
            cls._instance = None

    def get_embedding_model(self, name: str = "all-MiniLM-L6-v2") -> Any:
        """Lazy load embedding model.

        Args:
            name: Name of the sentence-transformers model

        Returns:
            Loaded SentenceTransformer model or None if unavailable

        Example:
            model = registry.get_embedding_model("all-mpnet-base-v2")
        """
        if not SENTENCE_TRANSFORMERS_AVAILABLE:
            logger.warning(
                "sentence-transformers not installed. "
                "Install with: pip install sentence-transformers"
            )
            return None

        if name not in self._embedding_models:
            with self._model_lock:
                if name not in self._embedding_models:
                    try:
                        logger.info(f"Loading embedding model: {name}")
                        model = SentenceTransformer(name)
                        self._embedding_models[name] = model
                        logger.info(f"Successfully loaded embedding model: {name}")
                    except Exception as e:
                        logger.error(f"Failed to load embedding model '{name}': {e}")
                        return None

        return self._embedding_models.get(name)

    def get_nli_model(
        self, name: str = "microsoft/deberta-v3-base-mnli-fever-anli"
    ) -> tuple[Any, Any] | None:
        """Lazy load NLI model and tokenizer.

        Args:
            name: Name of the HuggingFace NLI model

        Returns:
            Tuple of (model, tokenizer) or None if unavailable

        Example:
            model, tokenizer = registry.get_nli_model()
        """
        if not TRANSFORMERS_AVAILABLE:
            logger.warning(
                "transformers not installed. " "Install with: pip install transformers torch"
            )
            return None

        if name not in self._nli_models:
            with self._model_lock:
                if name not in self._nli_models:
                    try:
                        logger.info(f"Loading NLI model: {name}")
                        tokenizer = AutoTokenizer.from_pretrained(name)
                        model = AutoModelForSequenceClassification.from_pretrained(name)
                        model.eval()  # Set to evaluation mode
                        self._nli_models[name] = (model, tokenizer)
                        logger.info(f"Successfully loaded NLI model: {name}")
                    except Exception as e:
                        logger.error(f"Failed to load NLI model '{name}': {e}")
                        return None

        return self._nli_models.get(name)

    def get_embeddings(
        self,
        texts: list[str],
        model_name: str = "all-MiniLM-L6-v2",
        batch_size: int = 32,
    ) -> np.ndarray | None:
        """Get embeddings for texts with caching.

        Args:
            texts: List of texts to embed
            model_name: Name of the embedding model to use
            batch_size: Batch size for encoding

        Returns:
            Numpy array of embeddings or None if model unavailable

        Example:
            embeddings = registry.get_embeddings(["Hello", "World"])
            # embeddings.shape = (2, 384)
        """
        model = self.get_embedding_model(model_name)
        if model is None:
            return None

        # Check cache for each text
        embeddings = []
        uncached_texts = []
        uncached_indices = []

        for i, text in enumerate(texts):
            cache_key = self._get_cache_key(text, model_name)
            if cache_key in self._embedding_cache:
                embeddings.append(self._embedding_cache[cache_key])
            else:
                uncached_texts.append(text)
                uncached_indices.append(i)
                embeddings.append(None)  # Placeholder

        # Compute embeddings for uncached texts
        if uncached_texts:
            try:
                new_embeddings = model.encode(
                    uncached_texts,
                    convert_to_numpy=True,
                    batch_size=batch_size,
                    show_progress_bar=False,
                )

                # Cache and fill in results
                for j, idx in enumerate(uncached_indices):
                    embedding = new_embeddings[j]
                    text = uncached_texts[j]
                    cache_key = self._get_cache_key(text, model_name)
                    self._embedding_cache[cache_key] = embedding
                    embeddings[idx] = embedding

            except Exception as e:
                logger.error(f"Failed to compute embeddings: {e}")
                return None

        return np.array(embeddings)

    def _get_cache_key(self, text: str, model_name: str) -> str:
        """Generate cache key for text and model.

        Args:
            text: Text to embed
            model_name: Model used for embedding

        Returns:
            Cache key string
        """
        # Use hash for long texts
        text_hash = hashlib.md5(text.encode()).hexdigest()
        return f"{model_name}:{text_hash}"

    def ensure_model_cached(self, model_name: str, model_type: str = "embedding") -> Path:
        """Ensure model is downloaded and cached.

        Args:
            model_name: Name of the model
            model_type: Type of model ("embedding" or "nli")

        Returns:
            Path to the cached model directory
        """
        MODEL_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        model_dir = MODEL_CACHE_DIR / model_name.replace("/", "_")

        if model_type == "embedding":
            self.get_embedding_model(model_name)
        elif model_type == "nli":
            self.get_nli_model(model_name)

        return model_dir

    def is_embedding_available(self) -> bool:
        """Check if embedding models are available.

        Returns:
            True if sentence-transformers is installed
        """
        return SENTENCE_TRANSFORMERS_AVAILABLE

    def is_nli_available(self) -> bool:
        """Check if NLI models are available.

        Returns:
            True if transformers and torch are installed
        """
        return TRANSFORMERS_AVAILABLE

    def get_cache_stats(self) -> dict[str, Any]:
        """Get cache statistics.

        Returns:
            Dictionary with cache information
        """
        stats = {
            "embedding_models_loaded": list(self._embedding_models.keys()),
            "nli_models_loaded": list(self._nli_models.keys()),
            "embedding_cache_size": len(self._embedding_cache),
        }

        if CACHETOOLS_AVAILABLE and hasattr(self._embedding_cache, "maxsize"):
            stats["embedding_cache_maxsize"] = self._embedding_cache.maxsize

        return stats

    def clear_cache(self) -> None:
        """Clear the embedding cache."""
        self._embedding_cache.clear()
        logger.info("Cleared embedding cache")

    def unload_model(self, model_name: str, model_type: str = "embedding") -> bool:
        """Unload a model to free memory.

        Args:
            model_name: Name of the model to unload
            model_type: Type of model ("embedding" or "nli")

        Returns:
            True if model was unloaded, False if not found
        """
        with self._model_lock:
            if model_type == "embedding" and model_name in self._embedding_models:
                del self._embedding_models[model_name]
                logger.info(f"Unloaded embedding model: {model_name}")
                return True
            elif model_type == "nli" and model_name in self._nli_models:
                del self._nli_models[model_name]
                logger.info(f"Unloaded NLI model: {model_name}")
                return True
        return False


# Convenience functions for direct access
def get_model_registry() -> ModelRegistry:
    """Get the model registry singleton.

    Returns:
        The ModelRegistry singleton instance
    """
    return ModelRegistry.get_instance()


def get_embeddings(texts: list[str], model_name: str = "all-MiniLM-L6-v2") -> np.ndarray | None:
    """Convenience function to get embeddings.

    Args:
        texts: List of texts to embed
        model_name: Name of the embedding model

    Returns:
        Numpy array of embeddings or None
    """
    return get_model_registry().get_embeddings(texts, model_name)
