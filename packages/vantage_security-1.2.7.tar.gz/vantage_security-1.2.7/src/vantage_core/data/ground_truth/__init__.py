"""Ground truth dataset module for Vantage validation.

Provides utilities for loading and validating ground truth datasets
for benchmarking MAST detection, connection detection, and alignment scoring.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class GroundTruthSystem:
    """Expert-annotated ground truth multi-agent system.

    Contains all expected analysis results for validation.
    """

    system_id: str
    framework: str
    agents: list[dict[str, Any]]  # id, name, system_prompt
    expected_mast_failures: dict[str, list[str]]  # category -> agent_ids
    expected_connections: list[dict[str, Any]]  # source, target, data_passed
    expected_alignment_score: float
    annotator_id: str
    annotation_date: str
    difficulty: str  # easy, medium, hard
    system_type: str = "sequential"
    secondary_annotator_id: str = ""
    notes: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GroundTruthSystem:
        """Create from dictionary."""
        return cls(
            system_id=data["system_id"],
            framework=data["framework"],
            agents=data["agents"],
            expected_mast_failures=data.get("expected_mast_failures", {}),
            expected_connections=data.get("expected_connections", []),
            expected_alignment_score=data["expected_alignment_score"],
            annotator_id=data["annotator_id"],
            annotation_date=data["annotation_date"],
            difficulty=data["difficulty"],
            system_type=data.get("system_type", "sequential"),
            secondary_annotator_id=data.get("secondary_annotator_id", ""),
            notes=data.get("notes", ""),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "system_id": self.system_id,
            "framework": self.framework,
            "system_type": self.system_type,
            "agents": self.agents,
            "expected_mast_failures": self.expected_mast_failures,
            "expected_connections": self.expected_connections,
            "expected_alignment_score": self.expected_alignment_score,
            "annotator_id": self.annotator_id,
            "secondary_annotator_id": self.secondary_annotator_id,
            "annotation_date": self.annotation_date,
            "difficulty": self.difficulty,
            "notes": self.notes,
        }

    def to_agent_system(self) -> Any:
        """Convert to AgentSystem for analysis."""
        from vantage_core.core.models import (
            Agent,
            AgentSystem,
            Connection,
            Prompt,
            Topology,
        )

        agents = {}
        for agent_data in self.agents:
            agent = Agent(
                id=agent_data["id"],
                name=agent_data["name"],
                prompt=Prompt(content=agent_data["system_prompt"]),
                model=agent_data.get("model", "gpt-4"),
                temperature=agent_data.get("temperature", 0.7),
            )
            agents[agent.id] = agent

        connections = []
        for conn_data in self.expected_connections:
            connections.append(
                Connection(
                    source=conn_data["source"],
                    target=conn_data["target"],
                    data_passed=conn_data.get("data_passed", []),
                )
            )

        # Update agent relationships based on connections
        for conn in connections:
            if conn.source in agents:
                agents[conn.source].can_delegate_to.append(conn.target)
            if conn.target in agents:
                agents[conn.target].receives_from.append(conn.source)

        topology = Topology(connections=connections)

        return AgentSystem(
            name=self.system_id,
            description=self.notes,
            agents=agents,
            topology=topology,
        )


@dataclass
class GroundTruthCollection:
    """Collection of ground truth systems for benchmarking."""

    systems: list[GroundTruthSystem] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def load_from_directory(cls, directory: Path) -> GroundTruthCollection:
        """Load all ground truth systems from a directory.

        Args:
            directory: Path to directory containing JSON system files

        Returns:
            GroundTruthCollection with all loaded systems
        """
        systems = []

        if not directory.exists():
            logger.warning(f"Ground truth directory not found: {directory}")
            return cls(systems=[])

        for json_file in sorted(directory.glob("*.json")):
            try:
                with open(json_file, encoding="utf-8") as f:
                    data = json.load(f)
                system = GroundTruthSystem.from_dict(data)
                systems.append(system)
                logger.debug(f"Loaded ground truth system: {system.system_id}")
            except Exception as e:
                logger.error(f"Failed to load {json_file}: {e}")

        logger.info(f"Loaded {len(systems)} ground truth systems from {directory}")

        return cls(
            systems=systems,
            metadata={
                "source_directory": str(directory),
                "total_systems": len(systems),
            },
        )

    def filter_by_framework(self, framework: str) -> list[GroundTruthSystem]:
        """Filter systems by framework."""
        return [s for s in self.systems if s.framework == framework]

    def filter_by_difficulty(self, difficulty: str) -> list[GroundTruthSystem]:
        """Filter systems by difficulty level."""
        return [s for s in self.systems if s.difficulty == difficulty]

    def get_system(self, system_id: str) -> GroundTruthSystem | None:
        """Get a system by ID."""
        for system in self.systems:
            if system.system_id == system_id:
                return system
        return None

    def summary(self) -> dict[str, Any]:
        """Get summary statistics of the collection."""
        frameworks: dict[str, int] = {}
        difficulties: dict[str, int] = {}

        for system in self.systems:
            frameworks[system.framework] = frameworks.get(system.framework, 0) + 1
            difficulties[system.difficulty] = difficulties.get(system.difficulty, 0) + 1

        return {
            "total_systems": len(self.systems),
            "frameworks": frameworks,
            "difficulties": difficulties,
            "avg_alignment_score": (
                sum(s.expected_alignment_score for s in self.systems) / len(self.systems)
                if self.systems
                else 0
            ),
        }


def load_all_ground_truth() -> GroundTruthCollection:
    """Load all ground truth systems from the default location.

    Returns:
        GroundTruthCollection with all available systems
    """
    # Get the package's data directory
    package_dir = Path(__file__).parent
    systems_dir = package_dir / "systems"

    return GroundTruthCollection.load_from_directory(systems_dir)


def validate_ground_truth_file(filepath: Path) -> tuple[bool, list[str]]:
    """Validate a ground truth file against the schema.

    Args:
        filepath: Path to JSON file to validate

    Returns:
        Tuple of (is_valid, list of error messages)
    """
    errors = []

    try:
        with open(filepath, encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        return False, [f"Invalid JSON: {e}"]
    except FileNotFoundError:
        return False, [f"File not found: {filepath}"]

    from dataclasses import dataclass, field
    from pathlib import Path
    from typing import Any, Optional

    # ... (rest of the file)

    def validate_system_schema(data: dict) -> list[str]:
        errors = []

        required_fields = [
            "name",
            "description",
            "version",
            "agents",
            "topology",
        ]

        for required_field in required_fields:
            if required_field not in data:
                errors.append(f"Missing required field: {required_field}")

    # Validate framework
    valid_frameworks = [
        "langgraph",
        "crewai",
        "autogen",
        "llamaindex",
        "pydanticai",
        "mixed",
    ]
    if data.get("framework") not in valid_frameworks:
        errors.append(
            f"Invalid framework: {data.get('framework')}. Must be one of {valid_frameworks}"
        )

    # Validate difficulty
    valid_difficulties = ["easy", "medium", "hard"]
    if data.get("difficulty") not in valid_difficulties:
        errors.append(
            f"Invalid difficulty: {data.get('difficulty')}. Must be one of {valid_difficulties}"
        )

    # Validate alignment score range
    score = data.get("expected_alignment_score", 0)
    if not (0 <= score <= 100):
        errors.append(f"Alignment score must be 0-100, got {score}")

    # Validate agents
    agents = data.get("agents", [])
    if not agents:
        errors.append("At least one agent is required")

    agent_ids = set()
    for i, agent in enumerate(agents):
        if "id" not in agent:
            errors.append(f"Agent {i} missing 'id'")
        else:
            if agent["id"] in agent_ids:
                errors.append(f"Duplicate agent ID: {agent['id']}")
            agent_ids.add(agent["id"])

        if "name" not in agent:
            errors.append(f"Agent {i} missing 'name'")
        if "system_prompt" not in agent:
            errors.append(f"Agent {i} missing 'system_prompt'")

    # Validate connections reference valid agents
    connections = data.get("expected_connections", [])
    for conn in connections:
        if conn.get("source") not in agent_ids:
            errors.append(f"Connection source '{conn.get('source')}' not in agents")
        if conn.get("target") not in agent_ids:
            errors.append(f"Connection target '{conn.get('target')}' not in agents")

    # Validate MAST failures reference valid agents
    mast_failures = data.get("expected_mast_failures", {})
    valid_categories = ["manipulation", "autonomy", "secrecy", "takeover"]
    for category, agent_list in mast_failures.items():
        if category not in valid_categories:
            errors.append(f"Invalid MAST category: {category}")
        for agent_id in agent_list:
            if agent_id not in agent_ids:
                errors.append(f"MAST failure references unknown agent: {agent_id}")

    return len(errors) == 0, errors
