"""Custom exception classes for Vantage.

Provides standardized error handling with actionable guidance.
"""

from __future__ import annotations

from typing import Any


class MimicError(Exception):
    """Base exception for all Vantage errors.

    All custom exceptions inherit from this base class.
    """

    def __init__(self, message: str, details: dict[str, Any] | None = None):
        """Initialize the error with a message and optional details.

        Args:
            message: Human-readable error message
            details: Additional context for debugging
        """
        super().__init__(message)
        self.message = message
        self.details = details or {}

    def __str__(self) -> str:
        if self.details:
            return f"{self.message} | Details: {self.details}"
        return self.message


class ConfigurationError(MimicError):
    """Error in configuration or environment setup.

    Examples:
        - Missing API keys
        - Invalid configuration values
        - Missing dependencies
    """

    pass


class FileError(MimicError):
    """Error related to file operations.

    Examples:
        - File not found
        - Permission denied
        - Invalid file format
    """

    pass


class JSONParseError(FileError):
    """Error parsing JSON content.

    Provides clear guidance on JSON syntax issues.
    """

    def __init__(
        self,
        message: str,
        file_path: str | None = None,
        line: int | None = None,
        column: int | None = None,
        snippet: str | None = None,
    ):
        """Initialize JSON parse error with location information.

        Args:
            message: Error description
            file_path: Path to the problematic file
            line: Line number where error occurred
            column: Column number where error occurred
            snippet: Code snippet around the error
        """
        details = {}
        if file_path:
            details["file_path"] = file_path
        if line is not None:
            details["line"] = line
        if column is not None:
            details["column"] = column
        if snippet:
            details["snippet"] = snippet

        super().__init__(message, details)
        self.file_path = file_path
        self.line = line
        self.column = column
        self.snippet = snippet

    def __str__(self) -> str:
        parts = [self.message]

        if self.file_path:
            parts.append(f"\n  File: {self.file_path}")
        if self.line is not None:
            location = f"line {self.line}"
            if self.column is not None:
                location += f", column {self.column}"
            parts.append(f"\n  Location: {location}")
        if self.snippet:
            parts.append(f"\n  Context: ...{self.snippet}...")

        parts.append("\n  Tip: Validate your JSON at https://jsonlint.com/")

        return "".join(parts)


class ValidationError(MimicError):
    """Error in data validation.

    Examples:
        - Invalid agent configuration
        - Missing required fields
        - Invalid parameter values
    """

    def __init__(self, message: str, field: str | None = None, value: Any = None):
        """Initialize validation error.

        Args:
            message: Error description
            field: Name of the invalid field
            value: The invalid value
        """
        details = {}
        if field:
            details["field"] = field
        if value is not None:
            details["value"] = repr(value)

        super().__init__(message, details)
        self.field = field
        self.value = value


class ScannerError(MimicError):
    """Error during codebase scanning.

    Examples:
        - Invalid Python syntax
        - Unsupported framework
        - File access issues
    """

    def __init__(
        self,
        message: str,
        scanner_type: str | None = None,
        file_path: str | None = None,
    ):
        """Initialize scanner error.

        Args:
            message: Error description
            scanner_type: Type of scanner that failed
            file_path: Path to the problematic file
        """
        details = {}
        if scanner_type:
            details["scanner"] = scanner_type
        if file_path:
            details["file_path"] = file_path

        super().__init__(message, details)
        self.scanner_type = scanner_type
        self.file_path = file_path


class AnalysisError(MimicError):
    """Error during system analysis.

    Examples:
        - Invalid system structure
        - Analysis timeout
        - Resource limits exceeded
    """

    pass


class APIError(MimicError):
    """Error communicating with external APIs.

    Examples:
        - OpenRouter API errors
        - Rate limiting
        - Network issues
    """

    def __init__(
        self,
        message: str,
        service: str | None = None,
        status_code: int | None = None,
        retry_after: int | None = None,
    ):
        """Initialize API error.

        Args:
            message: Error description
            service: Name of the API service
            status_code: HTTP status code
            retry_after: Seconds to wait before retry (if rate limited)
        """
        details = {}
        if service:
            details["service"] = service
        if status_code is not None:
            details["status_code"] = status_code
        if retry_after is not None:
            details["retry_after"] = retry_after

        super().__init__(message, details)
        self.service = service
        self.status_code = status_code
        self.retry_after = retry_after

    def __str__(self) -> str:
        parts = [self.message]

        if self.status_code:
            parts.append(f"\n  Status: {self.status_code}")
        if self.retry_after:
            parts.append(f"\n  Retry after: {self.retry_after} seconds")
        if self.service:
            parts.append(f"\n  Service: {self.service}")

        return "".join(parts)


class TopologyError(MimicError):
    """Error in agent topology configuration.

    Examples:
        - Circular dependencies
        - Disconnected agents
        - Invalid connections
    """

    pass


def format_exception_for_cli(exc: Exception) -> str:
    """Format an exception for CLI display.

    Args:
        exc: The exception to format

    Returns:
        Formatted error message for terminal output
    """
    if isinstance(exc, MimicError):
        return str(exc)

    # For standard exceptions, provide basic formatting
    return f"{type(exc).__name__}: {str(exc)}"


def parse_json_error(exc: Exception, file_path: str | None = None) -> JSONParseError:
    """Convert a JSON decode error to a JSONParseError with better messaging.

    Args:
        exc: The original JSON decode exception
        file_path: Path to the file being parsed

    Returns:
        A formatted JSONParseError with actionable guidance
    """
    import json

    if isinstance(exc, json.JSONDecodeError):
        # Extract location information
        message = f"Invalid JSON syntax: {exc.msg}"
        line = exc.lineno
        column = exc.colno

        # Get snippet of problematic area
        doc = exc.doc
        start = max(0, exc.pos - 20)
        end = min(len(doc), exc.pos + 20)
        snippet = doc[start:end].replace("\n", " ")

        return JSONParseError(
            message=message,
            file_path=file_path,
            line=line,
            column=column,
            snippet=snippet,
        )

    # Generic JSON error
    return JSONParseError(
        message=f"Failed to parse JSON: {str(exc)}",
        file_path=file_path,
    )
