"""
ML-based prompt injection detector (Production Implementation).
"""

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import requests

from vantage_core.models.downloader import ensure_model_exists

logger = logging.getLogger(__name__)


@dataclass
class DetectionResult:
    is_injection: bool
    confidence: float
    metadata: dict[str, Any] = field(default_factory=dict)  # Ensure metadata is always a dict


class BaseDetector:
    def detect(self, text: str) -> DetectionResult:
        raise NotImplementedError


class KeywordDetector(BaseDetector):
    """Fallback detector using high-confidence keywords."""

    PATTERNS = [
        "ignore previous instructions",
        "ignore all previous",
        "system prompt",
        "you are now",
        "developer mode",
        "jailbreak",
        "unrestricted",
    ]

    def detect(self, text: str) -> DetectionResult:
        text_lower = text.lower()
        for pattern in self.PATTERNS:
            if pattern in text_lower:
                return DetectionResult(True, 0.95, {"reason": f"keyword: {pattern}"})
        return DetectionResult(False, 0.0, {"model_type": "keyword"})


class ONNXDetector(BaseDetector):
    """Production detector using ONNX Runtime for high-speed inference."""

    def __init__(self, model_path: str | None = None):
        self.session = None
        self.tokenizer = None

        # Try to load ONNX Runtime
        try:
            import onnxruntime as ort
            from transformers import AutoTokenizer

            # Auto-download model if not specified
            if not model_path:
                model_path = ensure_model_exists()

            if model_path and os.path.exists(model_path):
                # Check for tokenizer config next to model
                tokenizer_path = Path(model_path).parent
                if tokenizer_path.joinpath("tokenizer.json").exists():
                    self.tokenizer = AutoTokenizer.from_pretrained(str(tokenizer_path))
                    logger.info(f"Loaded Tokenizer from {tokenizer_path}")
                else:
                    self.tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")  # Fallback
                    logger.warning("No tokenizer config found, using default 'bert-base-uncased'")

                self.session = ort.InferenceSession(model_path)
                logger.info(f"Loaded ONNX model from {model_path}")
            else:
                logger.debug("No ONNX model found, skipping ONNX initialization")

        except ImportError:
            logger.debug("onnxruntime or transformers not installed")
        except Exception as e:
            logger.warning(f"Failed to load ONNX model: {e}", exc_info=True)

    def detect(self, text: str) -> DetectionResult:
        if not self.session or not self.tokenizer:
            return DetectionResult(False, 0.0, {"reason": "ONNX model not loaded"})

        try:
            # Preprocess
            inputs = self.tokenizer(
                text,
                return_tensors="np",
                padding="max_length",
                truncation=True,
                max_length=512,
            )

            # Convert inputs to ONNX compatible types (e.g., int64)
            input_ids = inputs["input_ids"].astype(np.int64)
            attention_mask = inputs["attention_mask"].astype(np.int64)

            input_feed = {
                self.session.get_inputs()[0].name: input_ids,
                self.session.get_inputs()[1].name: attention_mask,
            }

            # Inference
            outputs = self.session.run(None, input_feed)
            logits = outputs[0]

            # Softmax
            # Assuming logits are for binary classification (0: safe, 1: unsafe)
            # Apply sigmoid to get probability for the positive class (unsafe)
            confidence = 1 / (1 + np.exp(-logits[0][1]))

            return DetectionResult(
                is_injection=confidence > 0.8,  # Default threshold
                confidence=float(confidence),
                metadata={"model_type": "onnx"},
            )
        except Exception as e:
            logger.error(f"ONNX inference error: {e}", exc_info=True)
            return DetectionResult(False, 0.0, {"reason": f"ONNX inference failed: {e}"})


class RemoteDetector(BaseDetector):
    """Detector making HTTP requests to a remote (sidecar) inference endpoint."""

    def __init__(self, url: str):
        self.url = url
        logger.info(f"Initialized RemoteDetector for URL: {url}")

    def detect(self, text: str) -> DetectionResult:
        try:
            response = requests.post(
                self.url,
                json={"text": text},
                timeout=0.5,  # Small timeout for real-time applications
            )
            response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)

            data = response.json()

            return DetectionResult(
                is_injection=data.get("is_injection", False),
                confidence=data.get("confidence", 0.0),
                metadata={"model_type": "remote", "endpoint": self.url},
            )

        except requests.exceptions.Timeout:
            logger.warning(f"RemoteDetector timed out connecting to {self.url}")
            return DetectionResult(False, 0.0, {"reason": "remote_timeout"})
        except requests.exceptions.ConnectionError:
            logger.warning(f"RemoteDetector connection error to {self.url}")
            return DetectionResult(False, 0.0, {"reason": "remote_connection_error"})
        except Exception as e:
            logger.error(f"RemoteDetector unexpected error: {e}", exc_info=True)
            return DetectionResult(False, 0.0, {"reason": f"remote_error: {e}"})


class HybridDetector(BaseDetector):
    """Combines Keyword, Remote, and ONNX detectors."""

    def __init__(self):
        self.keyword = KeywordDetector()

        remote_url = os.getenv("MIMIC_INFERENCE_URL")
        self.remote = RemoteDetector(remote_url) if remote_url else None

        self.onnx = ONNXDetector()  # This will auto-download if needed

    def detect(self, text: str) -> DetectionResult:
        # 1. Fast Keyword Check (always available)
        kw_result = self.keyword.detect(text)
        if kw_result.is_injection:
            return kw_result

        # 2. Remote Service Check (if configured and available)
        remote_result = DetectionResult(False, 0.0)  # Default safe
        if self.remote:
            remote_result = self.remote.detect(text)
            if remote_result.is_injection:
                return remote_result
            # If remote service is up and says safe, we trust it over ONNX/Keyword
            if (
                remote_result.metadata.get("model_type") == "remote"
                and remote_result.reason != "remote_connection_error"
            ):
                return remote_result

        # 3. Deep Learning Check (if ONNX model loaded)
        onnx_result = self.onnx.detect(text)
        if onnx_result.is_injection:
            return onnx_result

        # If all fail, return the most confident 'safe' result
        # Compare confidence of safe results
        safe_results = [kw_result, remote_result, onnx_result]
        best_safe_result = max(safe_results, key=lambda r: r.confidence)

        return best_safe_result
