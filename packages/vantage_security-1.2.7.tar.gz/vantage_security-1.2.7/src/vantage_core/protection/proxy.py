"""
Runtime Protection Proxy/Middleware.

Provides transparent protection for LLM API calls by:
- Intercepting API calls to hardened prompts
- Filtering inputs before they reach the LLM
- Filtering outputs before they return to the application
- Logging security events

Usage:
    from vantage_core.protection import ProtectionProxy, protect_openai_client

    # Wrap an OpenAI client
    client = OpenAI(api_key="...")
    protected_client = protect_openai_client(client, secrets=["sk-key"])

    # Or use the generic proxy
    proxy = ProtectionProxy(secrets=["sk-key"])
    hardened_messages = proxy.protect_messages(messages)
    safe_output = proxy.protect_output(response)

    # Framework middleware
    from vantage_core.protection import LangChainMiddleware, CrewAIMiddleware

    # Wrap a LangChain chain
    protected_chain = LangChainMiddleware(chain, secrets=["api_key"])
    result = protected_chain.invoke({"input": user_input})
"""

import functools
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, TypeVar

from vantage_core.protection.decorators import (
    InputFilter,
    OutputFilter,
    ProtectionConfig,
    RateLimiter,
)
from vantage_core.protection.hardening import (
    Framework,
    HardeningLevel,
    PromptHardener,
)

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


@dataclass
class ProxyConfig:
    """Configuration for protection proxy."""

    secrets: list[str] = field(default_factory=list)
    harden_system_prompt: bool = True
    filter_user_input: bool = True
    filter_output: bool = True
    block_injection: bool = True
    log_events: bool = True
    framework: Framework = Framework.GENERIC
    hardening_level: HardeningLevel = HardeningLevel.STANDARD
    rate_limit_per_minute: int = 0
    max_input_length: int = 10000


@dataclass
class ProxyEvent:
    """Security event from the proxy."""

    event_type: str  # 'input_blocked', 'output_filtered', 'injection_detected', etc.
    timestamp: float
    details: dict[str, Any]
    severity: str = "info"  # 'info', 'warning', 'critical'


class ProtectionProxy:
    """
    Runtime protection proxy for LLM calls.

    Provides transparent protection by intercepting and filtering
    messages before and after LLM calls.

    Usage:
        proxy = ProtectionProxy(secrets=["sk-key", "password"])

        # Protect messages before sending to LLM
        protected_messages = proxy.protect_messages([
            {"role": "system", "content": "You are helpful..."},
            {"role": "user", "content": user_input},
        ])

        # Protect output before returning to application
        safe_output = proxy.protect_output(llm_response)
    """

    def __init__(
        self,
        secrets: list[str] | None = None,
        harden_system_prompt: bool = True,
        filter_user_input: bool = True,
        filter_output: bool = True,
        block_injection: bool = True,
        log_events: bool = True,
        framework: str | Framework = Framework.GENERIC,
        hardening_level: str | HardeningLevel = HardeningLevel.STANDARD,
        rate_limit_per_minute: int = 0,
        max_input_length: int = 10000,
    ):
        """
        Initialize the protection proxy.

        Args:
            secrets: List of secrets to protect from leakage
            harden_system_prompt: Whether to add defensive instructions
            filter_user_input: Whether to filter user input for attacks
            filter_output: Whether to filter output for secret leakage
            block_injection: Whether to block detected injection attempts
            log_events: Whether to log security events
            framework: Target framework for specialized protection
            hardening_level: Level of hardening to apply
            rate_limit_per_minute: Rate limit (0 = no limit)
            max_input_length: Maximum allowed input length
        """
        self.config = ProxyConfig(
            secrets=secrets or [],
            harden_system_prompt=harden_system_prompt,
            filter_user_input=filter_user_input,
            filter_output=filter_output,
            block_injection=block_injection,
            log_events=log_events,
            framework=Framework(framework) if isinstance(framework, str) else framework,
            hardening_level=(
                HardeningLevel(hardening_level)
                if isinstance(hardening_level, str)
                else hardening_level
            ),
            rate_limit_per_minute=rate_limit_per_minute,
            max_input_length=max_input_length,
        )

        # Initialize components
        self._hardener = PromptHardener()
        self._protection_config = ProtectionConfig(
            secrets=self.config.secrets,
            block_injection=self.config.block_injection,
            filter_output=self.config.filter_output,
            max_input_length=self.config.max_input_length,
        )
        self._input_filter = InputFilter(self._protection_config)
        self._output_filter = OutputFilter(self._protection_config)
        self._rate_limiter = RateLimiter(self.config.rate_limit_per_minute)

        # Event log
        self._events: list[ProxyEvent] = []
        self._hardened_prompts: dict[str, str] = {}  # Cache hardened prompts

    def protect_messages(
        self,
        messages: list[dict[str, str]],
    ) -> list[dict[str, str]]:
        """
        Protect a list of chat messages.

        Hardens system prompts and filters user messages.

        Args:
            messages: List of message dicts with 'role' and 'content'

        Returns:
            Protected messages

        Raises:
            ValueError: If injection detected and blocking enabled
            RuntimeError: If rate limit exceeded
        """
        # Rate limiting
        if not self._rate_limiter.check():
            self._log_event("rate_limit_exceeded", {}, "warning")
            raise RuntimeError("Rate limit exceeded")

        protected = []

        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content", "")

            if role == "system" and self.config.harden_system_prompt:
                # Harden system prompt
                protected_content = self._harden_system_prompt(content)
                protected.append({"role": role, "content": protected_content})

            elif role == "user" and self.config.filter_user_input:
                # Filter user input
                protected_content = self._filter_input(content)
                protected.append({"role": role, "content": protected_content})

            else:
                # Pass through other messages
                protected.append(msg.copy())

        return protected

    def protect_output(self, output: str) -> str:
        """
        Protect LLM output by filtering secrets.

        Args:
            output: Raw LLM output

        Returns:
            Filtered output with secrets redacted
        """
        if not self.config.filter_output:
            return output

        result = self._output_filter.filter(output)

        if result.warnings:
            self._log_event(
                "output_filtered",
                {
                    "warnings": result.warnings,
                    "output_length": len(output),
                },
                "warning",
            )

        return result.filtered_output or output

    def wrap_call(
        self,
        func: Callable[..., Any],
        messages_arg: str = "messages",
    ) -> Callable[..., Any]:
        """
        Wrap a function to automatically protect its messages.

        Args:
            func: Function to wrap (e.g., client.chat.completions.create)
            messages_arg: Name of the messages argument

        Returns:
            Wrapped function with protection
        """

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Protect messages if present
            if messages_arg in kwargs:
                kwargs[messages_arg] = self.protect_messages(kwargs[messages_arg])

            # Call original function
            result = func(*args, **kwargs)

            # Try to protect output
            try:
                if hasattr(result, "choices") and result.choices:
                    # OpenAI-style response
                    content = result.choices[0].message.content
                    if content:
                        protected_content = self.protect_output(content)
                        # Note: We can't modify the response object directly
                        # But we log the event for monitoring
                        if protected_content != content:
                            self._log_event(
                                "output_would_be_filtered",
                                {
                                    "original_length": len(content),
                                    "filtered_length": len(protected_content),
                                },
                                "warning",
                            )
            except Exception:
                pass  # Don't break on output filtering errors

            return result

        return wrapper

    def get_events(
        self,
        severity: str | None = None,
        event_type: str | None = None,
        limit: int = 100,
    ) -> list[ProxyEvent]:
        """
        Get logged security events.

        Args:
            severity: Filter by severity ('info', 'warning', 'critical')
            event_type: Filter by event type
            limit: Maximum number of events to return

        Returns:
            List of events matching filters
        """
        events = self._events

        if severity:
            events = [e for e in events if e.severity == severity]

        if event_type:
            events = [e for e in events if e.event_type == event_type]

        return events[-limit:]

    def clear_events(self):
        """Clear the event log."""
        self._events.clear()

    def _harden_system_prompt(self, prompt: str) -> str:
        """Harden a system prompt with caching."""
        # Check cache
        cache_key = f"{prompt[:100]}:{self.config.hardening_level.value}"
        if cache_key in self._hardened_prompts:
            return self._hardened_prompts[cache_key]

        # Harden prompt
        result = self._hardener.harden(
            system_prompt=prompt,
            secrets=self.config.secrets,
            framework=self.config.framework.value,
            level=self.config.hardening_level.value,
        )

        hardened = result.hardened_prompt

        self._log_event(
            "system_prompt_hardened",
            {
                "original_length": len(prompt),
                "hardened_length": len(hardened),
                "defenses_added": result.defenses_added,
            },
            "info",
        )

        # Cache result
        if len(self._hardened_prompts) < 100:  # Limit cache size
            self._hardened_prompts[cache_key] = hardened

        return hardened

    def _filter_input(self, text: str) -> str:
        """Filter user input."""
        result = self._input_filter.filter(text)

        if not result.allowed:
            self._log_event(
                "input_blocked",
                {
                    "reason": result.blocked_reason,
                    "input_preview": text[:100],
                },
                "critical",
            )

            if self.config.block_injection:
                raise ValueError(f"Input blocked: {result.blocked_reason}")

        if result.warnings:
            self._log_event(
                "input_filtered",
                {
                    "warnings": result.warnings,
                    "input_length": len(text),
                },
                "warning",
            )

        return result.filtered_input or text

    def _log_event(self, event_type: str, details: dict, severity: str):
        """Log a security event."""
        if not self.config.log_events:
            return

        event = ProxyEvent(
            event_type=event_type,
            timestamp=time.time(),
            details=details,
            severity=severity,
        )
        self._events.append(event)

        # Also log to standard logger
        log_msg = f"[ProtectionProxy] {event_type}: {details}"
        if severity == "critical":
            logger.critical(log_msg)
        elif severity == "warning":
            logger.warning(log_msg)
        else:
            logger.info(log_msg)


def protect_openai_client(
    client: Any,
    secrets: list[str] | None = None,
    harden_system_prompt: bool = True,
    filter_user_input: bool = True,
    filter_output: bool = True,
    block_injection: bool = True,
    framework: str | Framework = Framework.GENERIC,
    hardening_level: str | HardeningLevel = HardeningLevel.STANDARD,
) -> Any:
    """
    Wrap an OpenAI client with protection.

    Creates a proxy that intercepts chat.completions.create calls.

    Args:
        client: OpenAI client instance
        secrets: Secrets to protect
        harden_system_prompt: Whether to harden system prompts
        filter_user_input: Whether to filter user input
        filter_output: Whether to filter output
        block_injection: Whether to block injection attempts
        framework: Target framework
        hardening_level: Hardening level

    Returns:
        Protected client wrapper

    Example:
        from openai import OpenAI
        from vantage_core.protection import protect_openai_client

        client = OpenAI(api_key="...")
        protected = protect_openai_client(client, secrets=["sk-internal-key"])

        # Now all calls are protected
        response = protected.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are helpful."},
                {"role": "user", "content": user_input},
            ],
        )
    """
    proxy = ProtectionProxy(
        secrets=secrets,
        harden_system_prompt=harden_system_prompt,
        filter_user_input=filter_user_input,
        filter_output=filter_output,
        block_injection=block_injection,
        framework=framework,
        hardening_level=hardening_level,
    )

    # Create wrapper class that mimics the client
    class ProtectedChatCompletions:
        def __init__(self, original):
            self._original = original
            self._proxy = proxy

        def create(self, **kwargs):
            if "messages" in kwargs:
                kwargs["messages"] = self._proxy.protect_messages(kwargs["messages"])
            return self._original.create(**kwargs)

        async def acreate(self, **kwargs):
            if "messages" in kwargs:
                kwargs["messages"] = self._proxy.protect_messages(kwargs["messages"])
            return await self._original.acreate(**kwargs)

    class ProtectedChat:
        def __init__(self, original):
            self._original = original
            self.completions = ProtectedChatCompletions(original.completions)

    class ProtectedClient:
        def __init__(self, original):
            self._original = original
            self._proxy = proxy
            self.chat = ProtectedChat(original.chat)

        def __getattr__(self, name):
            return getattr(self._original, name)

    return ProtectedClient(client)


class LangChainMiddleware:
    """
    Middleware for protecting LangChain chains.

    Wraps a chain to add protection for inputs and outputs.

    Usage:
        from langchain.chains import LLMChain
        from vantage_core.protection import LangChainMiddleware

        chain = LLMChain(llm=llm, prompt=prompt)
        protected_chain = LangChainMiddleware(chain, secrets=["api_key"])

        result = protected_chain.invoke({"input": user_input})
    """

    def __init__(
        self,
        chain: Any,
        secrets: list[str] | None = None,
        harden_prompt: bool = True,
        filter_input: bool = True,
        filter_output: bool = True,
        block_injection: bool = True,
        hardening_level: str | HardeningLevel = HardeningLevel.STANDARD,
    ):
        """
        Initialize middleware.

        Args:
            chain: LangChain chain to wrap
            secrets: Secrets to protect
            harden_prompt: Whether to harden prompts
            filter_input: Whether to filter input
            filter_output: Whether to filter output
            block_injection: Whether to block injection
            hardening_level: Hardening level
        """
        self._chain = chain
        self._proxy = ProtectionProxy(
            secrets=secrets,
            harden_system_prompt=harden_prompt,
            filter_user_input=filter_input,
            filter_output=filter_output,
            block_injection=block_injection,
            framework=Framework.LANGCHAIN,
            hardening_level=hardening_level,
        )

    def invoke(self, input_dict: dict[str, Any], **kwargs) -> Any:
        """
        Invoke the chain with protection.

        Args:
            input_dict: Input dictionary for the chain
            **kwargs: Additional arguments

        Returns:
            Chain output
        """
        # Filter input values that are strings
        protected_input = {}
        for key, value in input_dict.items():
            if isinstance(value, str):
                protected_input[key] = self._proxy._filter_input(value)
            else:
                protected_input[key] = value

        # Call chain
        result = self._chain.invoke(protected_input, **kwargs)

        # Filter output if it's a string
        if isinstance(result, str):
            return self._proxy.protect_output(result)
        elif isinstance(result, dict):
            # Filter string values in dict
            return {
                k: self._proxy.protect_output(v) if isinstance(v, str) else v
                for k, v in result.items()
            }

        return result

    async def ainvoke(self, input_dict: dict[str, Any], **kwargs) -> Any:
        """Async invoke with protection."""
        protected_input = {}
        for key, value in input_dict.items():
            if isinstance(value, str):
                protected_input[key] = self._proxy._filter_input(value)
            else:
                protected_input[key] = value

        result = await self._chain.ainvoke(protected_input, **kwargs)

        if isinstance(result, str):
            return self._proxy.protect_output(result)
        elif isinstance(result, dict):
            return {
                k: self._proxy.protect_output(v) if isinstance(v, str) else v
                for k, v in result.items()
            }

        return result

    def __getattr__(self, name):
        return getattr(self._chain, name)


class CrewAIMiddleware:
    """
    Middleware for protecting CrewAI crews.

    Wraps a crew to add protection for task inputs and outputs.

    Usage:
        from crewai import Crew
        from vantage_core.protection import CrewAIMiddleware

        crew = Crew(agents=[...], tasks=[...])
        protected_crew = CrewAIMiddleware(crew, secrets=["api_key"])

        result = protected_crew.kickoff({"task": user_task})
    """

    def __init__(
        self,
        crew: Any,
        secrets: list[str] | None = None,
        harden_agent_prompts: bool = True,
        filter_input: bool = True,
        filter_output: bool = True,
        block_injection: bool = True,
        hardening_level: str | HardeningLevel = HardeningLevel.STANDARD,
    ):
        """
        Initialize middleware.

        Args:
            crew: CrewAI crew to wrap
            secrets: Secrets to protect
            harden_agent_prompts: Whether to harden agent prompts
            filter_input: Whether to filter input
            filter_output: Whether to filter output
            block_injection: Whether to block injection
            hardening_level: Hardening level
        """
        self._crew = crew
        self._proxy = ProtectionProxy(
            secrets=secrets,
            harden_system_prompt=harden_agent_prompts,
            filter_user_input=filter_input,
            filter_output=filter_output,
            block_injection=block_injection,
            framework=Framework.CREWAI,
            hardening_level=hardening_level,
        )

    def kickoff(self, inputs: dict[str, Any] | None = None) -> Any:
        """
        Kick off the crew with protection.

        Args:
            inputs: Input dictionary for the crew

        Returns:
            Crew output
        """
        if inputs:
            # Filter string inputs
            protected_inputs = {}
            for key, value in inputs.items():
                if isinstance(value, str):
                    protected_inputs[key] = self._proxy._filter_input(value)
                else:
                    protected_inputs[key] = value
        else:
            protected_inputs = None

        # Call crew
        result = self._crew.kickoff(protected_inputs)

        # Filter output
        if isinstance(result, str):
            return self._proxy.protect_output(result)
        elif hasattr(result, "raw") and isinstance(result.raw, str):
            # CrewAI output object
            result.raw = self._proxy.protect_output(result.raw)

        return result

    async def akickoff(self, inputs: dict[str, Any] | None = None) -> Any:
        """Async kickoff with protection."""
        if inputs:
            protected_inputs = {}
            for key, value in inputs.items():
                if isinstance(value, str):
                    protected_inputs[key] = self._proxy._filter_input(value)
                else:
                    protected_inputs[key] = value
        else:
            protected_inputs = None

        result = await self._crew.akickoff(protected_inputs)

        if isinstance(result, str):
            return self._proxy.protect_output(result)
        elif hasattr(result, "raw") and isinstance(result.raw, str):
            result.raw = self._proxy.protect_output(result.raw)

        return result

    def __getattr__(self, name):
        return getattr(self._crew, name)


class AutoGenMiddleware:
    """
    Middleware for protecting AutoGen agents.

    Wraps an AutoGen agent to add protection for messages.

    Usage:
        from autogen import AssistantAgent
        from vantage_core.protection import AutoGenMiddleware

        agent = AssistantAgent(name="assistant", ...)
        protected_agent = AutoGenMiddleware(agent, secrets=["password"])

        result = protected_agent.generate_reply([{"content": user_msg}])
    """

    def __init__(
        self,
        agent: Any,
        secrets: list[str] | None = None,
        harden_prompt: bool = True,
        filter_input: bool = True,
        filter_output: bool = True,
        block_injection: bool = True,
        hardening_level: str | HardeningLevel = HardeningLevel.STRICT,
    ):
        """
        Initialize middleware.

        Args:
            agent: AutoGen agent to wrap
            secrets: Secrets to protect
            harden_prompt: Whether to harden prompts
            filter_input: Whether to filter input
            filter_output: Whether to filter output
            block_injection: Whether to block injection
            hardening_level: Hardening level (STRICT by default for code execution)
        """
        self._agent = agent
        self._proxy = ProtectionProxy(
            secrets=secrets,
            harden_system_prompt=harden_prompt,
            filter_user_input=filter_input,
            filter_output=filter_output,
            block_injection=block_injection,
            framework=Framework.AUTOGEN,
            hardening_level=hardening_level,
        )

    def generate_reply(
        self,
        messages: list[dict[str, Any]] | None = None,
        **kwargs,
    ) -> str | dict | None:
        """
        Generate a reply with protection.

        Args:
            messages: List of messages
            **kwargs: Additional arguments

        Returns:
            Agent reply
        """
        if messages:
            # Filter message content
            protected_messages = []
            for msg in messages:
                protected_msg = msg.copy()
                if "content" in msg and isinstance(msg["content"], str):
                    protected_msg["content"] = self._proxy._filter_input(msg["content"])
                protected_messages.append(protected_msg)
        else:
            protected_messages = messages

        # Generate reply
        result = self._agent.generate_reply(protected_messages, **kwargs)

        # Filter output
        if isinstance(result, str):
            return self._proxy.protect_output(result)
        elif isinstance(result, dict) and "content" in result:
            if isinstance(result["content"], str):
                result["content"] = self._proxy.protect_output(result["content"])

        return result

    def __getattr__(self, name):
        return getattr(self._agent, name)
