"""
Report Generation for Vantage Security Platform.

This module provides report generators in multiple formats
including JSON, HTML, SARIF, and PDF.
"""

from vantage_core.reports.html_report import HTMLReportGenerator
from vantage_core.reports.json_report import JSONReportGenerator
from vantage_core.reports.markdown_report import MarkdownReportGenerator
from vantage_core.reports.pdf_report import PDFReportGenerator
from vantage_core.reports.sarif_report import SARIFReportGenerator
from vantage_core.reports.simulation_report import (
    ContainmentRecommendation,
    EntryPointAnalysis,
    ExecutiveSummary,
    Report,
    ReportFormat,
    SimulationReportGenerator,
    generate_simulation_report,
)

__all__ = [
    "JSONReportGenerator",
    "HTMLReportGenerator",
    "SARIFReportGenerator",
    "PDFReportGenerator",
    "MarkdownReportGenerator",
    "SimulationReportGenerator",
    "ReportFormat",
    "ExecutiveSummary",
    "EntryPointAnalysis",
    "ContainmentRecommendation",
    "Report",
    "generate_simulation_report",
]
