"""Scanner for AutoGen agent definitions."""

from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import Any

from vantage_core.models import (
    ConnectionConfidence,
    ConnectionType,
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult

logger = logging.getLogger(__name__)


class AutoGenScanner(BaseScanner):
    """Scanner for detecting AutoGen agent definitions.

    Detects agents defined via:
    - ConversableAgent() constructor
    - AssistantAgent() constructor
    - UserProxyAgent() constructor
    """

    framework_name = "AutoGen"

    # AutoGen agent class names
    AGENT_CLASSES = {
        "ConversableAgent",
        "AssistantAgent",
        "UserProxyAgent",
        "GroupChatManager",
        "Agent",
    }

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a Python file for AutoGen agent definitions."""
        agents: list[DetectedAgent] = []
        connections: list[DetectedConnection] = []

        try:
            tree = self._parse_python_file(path)
        except SyntaxError:
            return ScanResult(
                agents=[],
                connections=[],
                entry_points=[],
                exit_points=[],
                framework=self.framework_name,
                files_scanned=1,
                errors=["Syntax Error"],
            )

        # Track variable assignments for agent references
        agent_vars: dict[str, str] = {}  # var_name -> agent_id

        for node in ast.walk(tree):
            # Look for agent constructor calls
            if isinstance(node, ast.Call):
                if self._is_agent_creation(node, path):
                    agent = self._parse_agent_call(node, path)
                    if agent:
                        agents.append(agent)

            # Look for Subclasses
            elif isinstance(node, ast.ClassDef):
                agent = self._parse_agent_class(node, path)
                if agent:
                    agents.append(agent)

            # Look for initiate_chat() calls to find connections
            if isinstance(node, ast.Call):
                conn = self._parse_initiate_chat(node, agent_vars)
                if conn:
                    connections.append(conn)

            # Look for GroupChat to find multi-agent connections
            if isinstance(node, ast.Call):
                conns = self._parse_group_chat(node, agents)
                connections.extend(conns)

        # Third pass: find register_function calls to populate tools
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                self._parse_tool_registration(node, agents)

        return ScanResult(
            agents=agents,
            connections=connections,
            entry_points=[],
            exit_points=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=[],
        )

    def _is_agent_creation(self, node: ast.Call, path: Path) -> bool:
        """Check if a call instantiates an AutoGen Agent."""
        func_name = self._get_call_name(node)
        if not func_name:
            return False

        # 1. Direct Match
        if func_name in self.AGENT_CLASSES:
            return True

        # 2. Alias Resolution
        if hasattr(self, "symbol_table") and self.symbol_table:
            resolved = self.symbol_table.resolve_symbol(str(path), func_name)
            if resolved:
                if resolved.definition_type == "import":
                    orig = resolved.value.get("original_name", "")
                    if orig in self.AGENT_CLASSES:
                        return True
                elif resolved.definition_type == "assignment":
                    val_str = ""
                    try:
                        if isinstance(resolved.value, ast.AST):
                            val_str = ast.unparse(resolved.value)
                        else:
                            val_str = str(resolved.value)
                    except Exception:
                        val_str = str(resolved.value)

                    if any(cls in val_str for cls in self.AGENT_CLASSES):
                        return True
        return False

    def _parse_agent_class(self, node: ast.ClassDef, path: Path) -> DetectedAgent | None:
        """Parse a class inheriting from AutoGen components."""
        is_subclass = False
        for base in node.bases:
            name = ""
            if isinstance(base, ast.Name):
                name = base.id
            elif isinstance(base, ast.Attribute):
                name = base.attr

            if name in self.AGENT_CLASSES:
                is_subclass = True
                break

        if not is_subclass:
            return None

        return DetectedAgent(
            id=self._make_id(node.name),
            name=node.name,
            framework=Framework.AUTOGEN,
            file_path=str(path),
            line_number=node.lineno,
            system_prompt=f"AutoGen Subclass: {node.name}",
            metadata={"type": "subclass"},
        )

    def _parse_tool_registration(self, node: ast.Call, agents: list[DetectedAgent]) -> None:
        """Parse register_function() calls to add tools to agents."""
        func_name = self._get_call_name(node)

        # Check for autogen.agentchat.register_function or user_proxy.register_for_execution
        if not func_name or "register" not in func_name:
            return

        tool_name = None

        # 1. Extract tool name from first argument (the function)
        if node.args and isinstance(node.args[0], ast.Name):
            tool_name = node.args[0].id

        # 2. Or from keyword arg
        for keyword in node.keywords:
            if keyword.arg == "f" and isinstance(keyword.value, ast.Name):
                tool_name = keyword.value.id

        if not tool_name:
            return

        # 3. Determine which agent gets this tool
        # Case A: agent.register_for_execution(name="tool")
        if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name):
            caller_var = node.func.value.id
            # Find the agent matching this variable name
            target_agent = next((a for a in agents if self._make_id(caller_var) in a.id), None)
            if target_agent:
                if tool_name not in target_agent.tools:
                    target_agent.tools.append(tool_name)

        # Case B: register_function(func, caller=agent1, executor=agent2)
        for keyword in node.keywords:
            if keyword.arg in ["caller", "executor"] and isinstance(keyword.value, ast.Name):
                agent_var = keyword.value.id
                target_agent = next((a for a in agents if self._make_id(agent_var) in a.id), None)
                if target_agent:
                    if tool_name not in target_agent.tools:
                        target_agent.tools.append(tool_name)

    def _parse_agent_call(self, node: ast.Call, path: Path) -> DetectedAgent | None:
        """Parse an AutoGen agent constructor call."""
        func_name = self._get_call_name(node)

        # Extract keyword arguments
        kwargs: dict[str, Any] = {}
        for keyword in node.keywords:
            if keyword.arg:
                value = self._extract_value(keyword.value)
                if value is not None:
                    kwargs[keyword.arg] = value

        # Need at least name
        name = kwargs.get("name", "")
        if not name:
            # Try positional argument
            if node.args and isinstance(node.args[0], ast.Constant):
                name = node.args[0].value

        if not name:
            return None

        # Get system message
        system_message = kwargs.get("system_message", "")

        # For UserProxyAgent, add default behavior note
        if func_name == "UserProxyAgent" and not system_message:
            system_message = "User proxy agent - executes code and provides human input"

        # For AssistantAgent, use default if not specified
        if func_name == "AssistantAgent" and not system_message:
            system_message = "AI assistant that helps solve tasks with code and explanations"

        # Generate ID
        agent_id = self._make_id(name)

        # Extract model from llm_config
        model = "gpt-4"
        llm_config = kwargs.get("llm_config", {})
        if isinstance(llm_config, dict):
            config_list = llm_config.get("config_list", [])
            if config_list and isinstance(config_list, list) and len(config_list) > 0:
                model = config_list[0].get("model", "gpt-4")

        # Extract tools from register_function calls (approximate)
        tools = []
        function_map = kwargs.get("function_map", {})
        if isinstance(function_map, dict):
            tools.extend(list(function_map.keys()))

        return DetectedAgent(
            id=agent_id,
            name=name,
            framework=Framework.AUTOGEN,
            file_path=str(path),
            line_number=node.lineno,
            system_prompt=system_message,
            tools=tools,
            metadata=kwargs,
        )

    def _parse_initiate_chat(
        self, node: ast.Call, agent_vars: dict[str, str]
    ) -> DetectedConnection | None:
        """Parse initiate_chat() call to find connections."""
        # Check for initiate_chat or run method
        if not isinstance(node.func, ast.Attribute):
            return None

        method_name = node.func.attr
        if method_name not in ("initiate_chat", "run"):
            return None

        # Get the caller (source agent)
        source = None
        if isinstance(node.func.value, ast.Name):
            source = self._make_id(node.func.value.id)

        # Get the recipient (target agent)
        target = None
        for keyword in node.keywords:
            if keyword.arg == "recipient" and isinstance(keyword.value, ast.Name):
                target = self._make_id(keyword.value.id)
                break

        # Also check first positional arg
        if not target and node.args:
            if isinstance(node.args[0], ast.Name):
                target = self._make_id(node.args[0].id)

        if source and target:
            return DetectedConnection(
                source_id=source,
                target_id=target,
                connection_type=ConnectionType.DIRECT,
                confidence=0.95,
                confidence_level=ConnectionConfidence.FRAMEWORK,
                evidence=[f"AutoGen initiate_chat(recipient={target})"],
            )

        return None

    def _parse_group_chat(
        self, node: ast.Call, agents: list[DetectedAgent]
    ) -> list[DetectedConnection]:
        """Parse GroupChat to find multi-agent connections."""
        connections: list[DetectedConnection] = []

        func_name = self._get_call_name(node)
        if func_name != "GroupChat":
            return connections

        # Get agent names from agents= argument
        agent_names = []
        for keyword in node.keywords:
            if keyword.arg == "agents" and isinstance(keyword.value, ast.List):
                for elt in keyword.value.elts:
                    if isinstance(elt, ast.Name):
                        agent_names.append(self._make_id(elt.id))

        # Check for allowed_transitions or speaker_transitions_type
        has_transitions = False
        allowed_transitions: dict[str, list[str]] = {}

        for keyword in node.keywords:
            if keyword.arg == "allowed_or_disallowed_speaker_transitions":
                # Parse the transitions dict
                if isinstance(keyword.value, ast.Dict):
                    has_transitions = True
                    for key, value in zip(keyword.value.keys, keyword.value.values):
                        if isinstance(key, ast.Name):
                            source = self._make_id(key.id)
                            targets = []
                            if isinstance(value, ast.List):
                                for elt in value.elts:
                                    if isinstance(elt, ast.Name):
                                        targets.append(self._make_id(elt.id))
                            allowed_transitions[source] = targets

            elif keyword.arg == "speaker_transitions_type":
                trans_type = self._extract_value(keyword.value)
                if trans_type and "allowed" in str(trans_type).lower():
                    has_transitions = True

        if has_transitions and allowed_transitions:
            # Use explicit transitions
            for source, targets in allowed_transitions.items():
                for target in targets:
                    connections.append(
                        DetectedConnection(
                            source_id=source,
                            target_id=target,
                            connection_type=ConnectionType.DIRECT,
                            confidence=0.95,
                            confidence_level=ConnectionConfidence.FRAMEWORK,
                            evidence=[
                                f"AutoGen GroupChat allowed_transitions: {source} -> {target}"
                            ],
                        )
                    )
        elif agent_names:
            # Default: mesh connections (everyone can talk to everyone)
            for i, source in enumerate(agent_names):
                for target in agent_names[i + 1 :]:
                    connections.append(
                        DetectedConnection(
                            source_id=source,
                            target_id=target,
                            connection_type=ConnectionType.BROADCAST,
                            confidence=0.90,
                            confidence_level=ConnectionConfidence.FRAMEWORK,
                            evidence=[f"AutoGen GroupChat default mesh: {source} <-> {target}"],
                        )
                    )
                    connections.append(
                        DetectedConnection(
                            source_id=target,
                            target_id=source,
                            connection_type=ConnectionType.BROADCAST,
                            confidence=0.90,
                            confidence_level=ConnectionConfidence.FRAMEWORK,
                            evidence=[f"AutoGen GroupChat default mesh: {target} <-> {source}"],
                        )
                    )

        return connections
