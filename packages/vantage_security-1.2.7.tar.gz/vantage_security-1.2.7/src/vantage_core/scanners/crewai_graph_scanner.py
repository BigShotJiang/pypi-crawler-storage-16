from pathlib import Path
from vantage_core.models import DetectedAgent, Framework, ScanResult
from vantage_core.scanners.base import BaseScanner
from vantage_core.graph.builder import CPGBuilder
from vantage_core.graph.query import CPGQuery

class CrewAIGraphScanner(BaseScanner):
    """Next-generation Graph-based Scanner for CrewAI."""
    
    framework_name = "CrewAI"

    def scan_file(self, path: Path) -> ScanResult:
        with open(path, "rb") as f:
            source = f.read()

        # 1. Build CPG using Tree-Sitter (Robust)
        from vantage_core.graph.ts_builder import TSBuilder
        from vantage_core.graph.advanced_solver import AdvancedDataFlowSolver
        from vantage_core.graph.store import NodeType
        
        builder = TSBuilder()
        graph = builder.build(source)
        
        # 2. Run Data Flow Analysis (Points-To)
        solver = AdvancedDataFlowSolver(graph)
        solver.solve()
        
        agents = []
        
        # Helper to resolve value from abstract object ID
        def resolve_value(obj_id):
            # Find the LITERAL node or CALL node that created this object
            # In our solver, obj_id is the node_id of the allocation site
            node_type = graph.get_node_type(obj_id)
            if node_type == NodeType.LITERAL:
                return graph.get_attr(obj_id, "value")
            elif node_type == NodeType.CALL:
                return {"type": "call", "name": graph.get_attr(obj_id, "name")}
            return None

        # 3. Find Agent Definitions
        # Strategy A: Calls to `Agent(...)`
        for i in range(graph._count):
            if graph.get_node_type(i) == NodeType.CALL:
                name = graph.get_attr(i, "name")
                if name == "Agent":
                    role = None
                    goal = None
                    llm_info = None
                    tools = []
                    
                    # Inspect incoming edges to find arguments
                    in_edges = graph.in_edges(i)
                    for src_id, edge_type in in_edges:
                        if edge_type == 10: # EdgeType.ARGUMENT
                            arg_name = graph.get_edge_attr(src_id, i, "arg")
                            
                            # Resolve value via Points-To
                            # Src is the argument value node (Var or Literal)
                            # We want the *origin* of this value (the abstract object)
                            pts = solver.points_to.get(src_id, {src_id})
                            
                            # Taking first resolved value for now
                            resolved_val = None
                            if pts:
                                obj_id = list(pts)[0]
                                resolved_val = resolve_value(obj_id)
                            
                            if arg_name == "role":
                                role = resolved_val
                            elif arg_name == "goal":
                                goal = resolved_val
                            elif arg_name == "llm":
                                # Resolve LLM info
                                # If resolved_val is a dict {"type": "call", "name": "ChatOpenAI"}
                                llm_info = resolved_val
                    
                    # Fallback name
                    agent_name = role if isinstance(role, str) else f"Agent_{i}"
                    
                    metadata = {}
                    if isinstance(llm_info, dict):
                        metadata["llm_provider"] = llm_info.get("name")
                    
                    agents.append(DetectedAgent(
                        id=self._make_id(agent_name),
                        name=agent_name,
                        framework=Framework.CREWAI,
                        file_path=str(path),
                        line_number=0, # Need to store/retrieve line number from Node attrs
                        system_prompt=f"Role: {role}\nGoal: {goal}",
                        metadata=metadata
                    ))
                    
        return ScanResult(
            agents=agents,
            connections=[],
            framework=self.framework_name,
            files_scanned=1,
            errors=[]
        )
