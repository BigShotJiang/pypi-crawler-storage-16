from pathlib import Path
from vantage_core.models import DetectedAgent, DetectedConnection, Framework, ScanResult, ConnectionType, ConnectionConfidence
from vantage_core.scanners.base import BaseScanner
from vantage_core.graph.builder import CPGBuilder
from vantage_core.graph.query import CPGQuery

class LangChainGraphScanner(BaseScanner):
    """Graph-based Scanner for LangChain."""
    
    framework_name = "LangChain"

    # Simplified list for proof of concept
    AGENT_CREATORS = ["initialize_agent", "create_react_agent", "AgentExecutor"]

    def scan_file(self, path: Path) -> ScanResult:
        with open(path, "r", encoding="utf-8") as f:
            source = f.read()

        builder = CPGBuilder()
        graph = builder.build(source, str(path))
        query = CPGQuery(graph)
        
        agents = []
        connections = []
        
        # 1. Detect Agents via Function Calls
        for creator in self.AGENT_CREATORS:
            calls = query.find_calls_by_name(creator)
            for call_id, call_node in calls:
                # Resolve basic args
                tools_arg = query.resolve_argument(call_id, "tools")
                llm_arg = query.resolve_argument(call_id, "llm")
                agent_arg = query.resolve_argument(call_id, "agent") # For AgentExecutor
                
                name = f"langchain_agent_{call_node.ast_node.lineno}"
                
                metadata = {}
                if isinstance(llm_arg, dict) and llm_arg.get("type") == "call":
                     metadata["llm_provider"] = llm_arg.get("name")
                     
                agents.append(DetectedAgent(
                    id=name,
                    name=name,
                    framework=Framework.LANGCHAIN,
                    file_path=str(path),
                    line_number=call_node.ast_node.lineno,
                    system_prompt="LangChain Agent",
                    metadata=metadata
                ))

        # 2. Detect Chains via BitOr (|)
        chains = query.find_chains()
        for left, right in chains:
             connections.append(DetectedConnection(
                source_id=self._make_id(left),
                target_id=self._make_id(right),
                connection_type=ConnectionType.SEQUENTIAL_HANDOFF,
                confidence=0.9,
                confidence_level=ConnectionConfidence.FRAMEWORK,
                evidence=[f"LangChain Pipe: {left} | {right}"]
             ))

        return ScanResult(
            agents=agents,
            connections=connections,
            framework=self.framework_name,
            files_scanned=1,
            errors=[]
        )
