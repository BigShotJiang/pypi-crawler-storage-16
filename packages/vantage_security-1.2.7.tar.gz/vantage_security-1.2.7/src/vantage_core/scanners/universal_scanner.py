"""Universal scanner that auto-detects framework and scans accordingly."""

from __future__ import annotations

import logging
import re
from pathlib import Path

# Import to trigger scanner registration
import vantage_core.scanners.register_scanners  # noqa: F401
from vantage_core.analysis.symbol_table import ProjectSymbolTable
from vantage_core.licensing.manager import require_feature
from vantage_core.models import (
    DetectedAgent,
    DetectedConnection,
    Framework,
)
from vantage_core.scanners.base import BaseScanner, ScanResult
from vantage_core.scanners.registry import ScannerRegistry

logger = logging.getLogger(__name__)


class UniversalScanner(BaseScanner):
    """Universal scanner with registry-based framework detection.

    Automatically detects which framework(s) are used in a codebase and
    applies the appropriate scanners. Uses the ScannerRegistry for:
    - Dynamic scanner discovery
    - Lazy loading of scanners
    - Framework detection optimization
    """

    framework_name = "Universal"

    def __init__(self, verbose: bool = False, use_detection: bool = True):
        """Initialize universal scanner.

        Args:
            verbose: Log detailed information
            use_detection: Use framework detection for optimization (default True)
        """
        super().__init__(verbose=verbose)
        self._use_detection = use_detection

    def scan_directory(self, path: Path) -> ScanResult:
        """Scan directory with optimized framework detection.

        Args:
            path: Path to directory to scan

        Returns:
            ScanResult with detected agents and connections
        """
        all_agents: list[DetectedAgent] = []
        all_connections: list[DetectedConnection] = []
        all_errors: list[str] = []
        frameworks_found: list[str] = []
        total_files = 0

        # Phase 0: Index codebase for cross-file resolution (PAID FEATURE)
        symbol_table = None
        if require_feature("cross_file_resolution"):
            if self.verbose:
                logger.info("Initializing Cross-File Resolution (Pro Feature)")
            # Initialize with root path for lazy loading
            symbol_table = ProjectSymbolTable(root_path=path)
        else:
            if self.verbose:
                logger.info("Cross-File Resolution disabled (Free Tier)")

        # Determine which scanners to use
        if self._use_detection:
            detected = ScannerRegistry.detect_frameworks(path)
            if self.verbose:
                self._log_info(f"Detected frameworks: {detected}")
            if detected:
                scanners = [ScannerRegistry.get_scanner(name, self.verbose) for name in detected]
            else:
                # No frameworks detected, use all scanners
                scanners = ScannerRegistry.get_all_scanners(self.verbose)
        else:
            scanners = ScannerRegistry.get_all_scanners(self.verbose)

        # Run selected scanners
        for scanner in scanners:
            # Inject symbol table for deep resolution
            scanner.symbol_table = symbol_table

            try:
                result = scanner.scan_directory(path)

                # Always collect errors and update file count
                all_errors.extend(result.errors)
                total_files = max(total_files, result.files_scanned)

                # Collect agents and connections if any found
                if result.agents:
                    frameworks_found.append(scanner.framework_name)
                    all_agents.extend(result.agents)
                    all_connections.extend(result.connections)
            except Exception as e:
                error_msg = f"Error running {scanner.framework_name} scanner: {e}"
                all_errors.append(error_msg)
                if self.verbose:
                    logger.warning(error_msg)

        # Fallback to generic if nothing found
        if not all_agents:
            generic_result = self._scan_generic_python(path)
            all_agents.extend(generic_result.agents)
            all_connections.extend(generic_result.connections)
            total_files = generic_result.files_scanned
            if generic_result.agents:
                frameworks_found.append("Generic Python")

        # Deduplicate agents by ID
        unique_agents = self._deduplicate_agents(all_agents)

        # Post-process: Flag high-risk tools with Cross-File Resolution
        risk_keywords = {
            "shell",
            "exec",
            "os",
            "subprocess",
            "file",
            "system",
            "cmd",
            "bash",
            "sh",
            "dangerous",
        }
        for agent in unique_agents:
            high_risk_tools = []
            for tool in agent.tools:
                # 1. Check direct name
                tool_lower = tool.lower()
                if any(kw in tool_lower for kw in risk_keywords):
                    high_risk_tools.append(tool)
                    continue

                # 2. Check resolved definition via Symbol Table (if enabled)
                if symbol_table:
                    resolved = symbol_table.resolve_symbol(agent.file_path, tool)
                    if resolved:
                        # Check definition name
                        resolved_name = resolved.name.lower()
                        if any(kw in resolved_name for kw in risk_keywords):
                            high_risk_tools.append(
                                f"{tool} (resolves to {resolved.name} in {Path(resolved.file_path).name})"
                            )
                            continue

                        # Check definition VALUE (e.g. alias = os.system)
                        if resolved.definition_type == "assignment":
                            val_str = ""
                            try:
                                if isinstance(resolved.value, ast.AST):
                                    val_str = ast.unparse(resolved.value).lower()
                                else:
                                    val_str = str(resolved.value).lower()
                            except Exception:
                                pass

                            # Look for patterns like 'os.system', 'subprocess.run' in the assigned value
                            if any(
                                kw in val_str for kw in ["os.system", "subprocess", "exec", "eval"]
                            ):
                                high_risk_tools.append(f"{tool} (alias for {val_str})")

            if high_risk_tools:
                agent.metadata["high_risk"] = True
                agent.metadata["risk_reasons"] = [
                    f"Has high-risk tools: {', '.join(high_risk_tools)}"
                ]
                if self.verbose:
                    logger.warning(
                        f"HIGH RISK AGENT DETECTED: {agent.name} has tools {high_risk_tools}"
                    )

        # Determine entry/exit points
        entry_points, exit_points = self._determine_endpoints(unique_agents, all_connections)

        framework_str = " + ".join(frameworks_found) if frameworks_found else "Unknown"

        return ScanResult(
            agents=unique_agents,
            connections=all_connections,
            entry_points=entry_points,
            exit_points=exit_points,
            framework=framework_str,
            files_scanned=total_files,
            errors=all_errors,
        )

    def scan_file(self, path: Path) -> ScanResult:
        """Scan a single file with all scanners.

        Args:
            path: Path to Python file

        Returns:
            ScanResult with detected agents
        """
        all_agents: list[DetectedAgent] = []
        all_connections: list[DetectedConnection] = []
        all_errors: list[str] = []

        # Use all scanners for single file (detection doesn't help much here)
        scanners = ScannerRegistry.get_all_scanners(self.verbose)

        for scanner in scanners:
            try:
                result = scanner.scan_file(path)
                all_agents.extend(result.agents)
                all_connections.extend(result.connections)
            except Exception as e:
                if self.verbose:
                    logger.warning(f"{scanner.framework_name} scanner failed on {path}: {e}")

        # Deduplicate
        unique_agents = self._deduplicate_agents(all_agents)

        return ScanResult(
            agents=unique_agents,
            connections=all_connections,
            entry_points=[],
            exit_points=[],
            framework="Universal",
            files_scanned=1,
            errors=all_errors,
        )

    def _deduplicate_agents(self, agents: list[DetectedAgent]) -> list[DetectedAgent]:
        """Remove duplicate agents by ID.

        Args:
            agents: List of detected agents

        Returns:
            Deduplicated list of agents
        """
        seen_ids: set[str] = set()
        unique: list[DetectedAgent] = []
        for agent in agents:
            if agent.id not in seen_ids:
                seen_ids.add(agent.id)
                unique.append(agent)
        return unique

    def _scan_generic_python(self, path: Path) -> ScanResult:
        """Fallback: scan for any LLM-related patterns in Python files.

        Looks for common patterns like:
        - system_message or system_prompt variables
        - ChatCompletion calls with messages
        - prompt templates

        Args:
            path: Directory path to scan

        Returns:
            ScanResult with detected agents
        """
        agents: list[DetectedAgent] = []
        files_scanned = 0

        for py_file in path.rglob("*.py"):
            if self._should_skip_file(py_file):
                continue

            try:
                with open(py_file, encoding="utf-8") as f:
                    content = f.read()

                # Look for system message patterns
                patterns = [
                    # Variable assignments
                    r'(?:system_message|system_prompt|SYSTEM_PROMPT|SYSTEM_MESSAGE)\s*=\s*["\'](.+?)["\']',
                    r'(?:system_message|system_prompt|SYSTEM_PROMPT|SYSTEM_MESSAGE)\s*=\s*"""(.+?)"""',
                    r"(?:system_message|system_prompt|SYSTEM_PROMPT|SYSTEM_MESSAGE)\s*=\s*'''(.+?)'''",
                    # Dict patterns
                    r'["\']system["\']\s*:\s*["\'](.+?)["\']',
                ]

                for pattern in patterns:
                    matches = re.findall(pattern, content, re.DOTALL)
                    for i, match in enumerate(matches):
                        if len(match) > 20:  # Skip very short matches
                            agent_id = f"agent_{py_file.stem}_{i}"
                            agents.append(
                                DetectedAgent(
                                    id=agent_id,
                                    name=f"Agent from {py_file.name}",
                                    framework=Framework.UNKNOWN,
                                    file_path=str(py_file),
                                    line_number=0,
                                    system_prompt=match.strip(),
                                )
                            )

                files_scanned += 1

            except Exception as e:
                if self.verbose:
                    logger.warning(f"Error in generic scan of {py_file}: {e}")

        return ScanResult(
            agents=agents,
            connections=[],
            entry_points=[],
            exit_points=[],
            framework="Generic Python",
            files_scanned=files_scanned,
            errors=[],
        )
