"""
False positive elimination filters for the Vantage security scanner.

This module implements P0 (highest priority) filters to reduce false positives
in secret detection:
- US-FP-001: Test file detection (2,797 FPs)
- US-FP-002: Placeholder value recognition (568 FPs)
- US-FP-003: Constant name pattern detection (220 FPs)
- US-FP-004: OAuth/Protocol enum whitelist (60 FPs)
- US-FP-005: Class export detection (60 FPs)

Each filter returns True if the finding should be FILTERED (is a false positive).
"""

import ast
import logging
import re
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class FilterResult:
    """Result from a filter decision."""

    should_filter: bool
    confidence: float
    filter_type: str
    reasoning: list[str] = field(default_factory=list)


@dataclass
class FilterConfig:
    """Configuration for false positive filters."""

    # Test file detection
    test_file_enabled: bool = True
    test_file_threshold: float = 0.7

    # Placeholder detection
    placeholder_enabled: bool = True
    placeholder_threshold: float = 0.7

    # Constant name pattern
    constant_name_enabled: bool = True
    constant_name_threshold: float = 0.8

    # Protocol enum whitelist
    protocol_enum_enabled: bool = True
    protocol_enum_threshold: float = 0.8

    # Class export detection
    class_export_enabled: bool = True
    class_export_threshold: float = 0.8


class FalsePositiveFilter:
    """
    Multi-filter system for eliminating false positives in secret detection.

    This class provides comprehensive filtering using multiple detection strategies
    to identify common false positive patterns with high precision (>99%).

    Example:
        >>> filter = FalsePositiveFilter()
        >>> # Test file detection
        >>> filter.is_test_file_secret(finding, source_code)
        True  # Should be filtered

        >>> # Placeholder detection
        >>> filter.is_placeholder_value("your-api-key-here", line)
        True  # Should be filtered
    """

    # Test file path patterns
    TEST_PATH_PATTERNS = [
        r"/tests/",
        r"/test/",
        r"/__tests__/",
        r"/testing/",
        r"/fixtures/",
        r"/mocks/",
        r"/stubs/",
        r"/fakes/",
    ]

    # Test file name patterns
    TEST_FILE_PATTERNS = [
        r"test_[^/]+\.py$",
        r"[^/]+_test\.py$",
        r"conftest\.py$",
        r"factories\.py$",
        r"fixtures\.py$",
        r"\.test\.py$",
        r"\.spec\.py$",
    ]

    # Test function patterns
    TEST_FUNCTION_PATTERNS = [
        r"^test_",
        r"_test$",
        r"^setup_",
        r"^teardown_",
        r"^setUp$",
        r"^tearDown$",
    ]

    # Test decorator patterns
    TEST_DECORATORS = [
        "pytest.fixture",
        "pytest.mark",
        "unittest.mock",
        "patch",
        "MagicMock",
        "Mock",
        "parametrize",
        "mock.patch",
    ]

    # Mock value patterns
    MOCK_VALUE_PATTERNS = [
        r"\bmock[-_]?",
        r"\bfake[-_]?",
        r"\btest[-_]?(?:key|token|secret|password|api)",
        r"\bdummy[-_]?",
        r"\bsample[-_]?",
        r"\bfixture[-_]?",
        r"['\"]test['\"]",
        r"['\"]mock['\"]",
    ]

    # Test framework imports
    TEST_IMPORTS = [
        "pytest",
        "unittest",
        "mock",
        "unittest.mock",
        "pytest_mock",
        "faker",
        "factory_boy",
        "hypothesis",
    ]

    # Explicit placeholder patterns
    PLACEHOLDER_PATTERNS = [
        r"^your[-_]",
        r"[-_]here$",
        r"^<[^>]+>$",
        r"^\{\{[^}]+\}\}$",
        r"^\$\{[^}]+\}$",
        r"^xxx+$",
        r"^\*+$",
        r"^placeholder",
        r"^example[-_]",
        r"^insert[-_]",
        r"^change[-_]?me$",
        r"^replace[-_]?(?:me|this|with)",
        r"^todo$",
        r"^fixme$",
        r"^[a-z]+[-_]api[-_]key[-_]here$",
        r"^sk-x{16,}$",
    ]

    # Known placeholder values (exact match)
    KNOWN_PLACEHOLDERS = {
        "your-api-key",
        "your-api-key-here",
        "your-secret-key",
        "your-token-here",
        "your-openai-api-key-here",
        "insert-key-here",
        "api-key-goes-here",
        "xxxxxxxx",
        "xxxxxxxxxxxxxxxx",
        "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
        "sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
        "test-api-key",
        "example-token",
        "changeme",
        "change-me",
        "placeholder",
        "example",
        "********",
    }

    # Low entropy structural patterns
    STRUCTURAL_PATTERNS = [
        (r"^(.)\1{7,}$", "repeated_char"),
        (r"^12345678", "sequential_numbers"),
        (r"^abcdefgh", "sequential_letters"),
        (r"^qwerty", "keyboard_pattern"),
    ]

    # OAuth 2.0 grant types (RFC 6749)
    OAUTH_GRANT_TYPES = {
        "authorization_code",
        "implicit",
        "password",
        "client_credentials",
        "refresh_token",
        "urn:ietf:params:oauth:grant-type:jwt-bearer",
        "urn:ietf:params:oauth:grant-type:device_code",
    }

    # OAuth token types
    OAUTH_TOKEN_TYPES = {
        "bearer",
        "mac",
        "access_token",
        "refresh_token",
        "id_token",
        "token",
    }

    # OAuth response types
    OAUTH_RESPONSE_TYPES = {
        "code",
        "token",
        "id_token",
    }

    # HTTP auth types
    HTTP_AUTH_TYPES = {
        "basic",
        "digest",
        "bearer",
    }

    # JWT standard claims
    JWT_CLAIMS = {
        "iss",
        "sub",
        "aud",
        "exp",
        "nbf",
        "iat",
        "jti",
    }

    def __init__(self, config: FilterConfig | None = None):
        """
        Initialize the false positive filter.

        Args:
            config: Optional configuration for filter thresholds
        """
        self.config = config or FilterConfig()

        # Compile patterns for performance
        self._test_path_pattern = re.compile("|".join(self.TEST_PATH_PATTERNS), re.IGNORECASE)
        self._test_file_pattern = re.compile("|".join(self.TEST_FILE_PATTERNS), re.IGNORECASE)
        self._test_func_pattern = re.compile("|".join(self.TEST_FUNCTION_PATTERNS))
        self._mock_value_pattern = re.compile("|".join(self.MOCK_VALUE_PATTERNS), re.IGNORECASE)
        self._placeholder_patterns = [
            re.compile(p, re.IGNORECASE) for p in self.PLACEHOLDER_PATTERNS
        ]

        # Combined OAuth/protocol constants
        self._protocol_constants = (
            self.OAUTH_GRANT_TYPES
            | self.OAUTH_TOKEN_TYPES
            | self.OAUTH_RESPONSE_TYPES
            | self.HTTP_AUTH_TYPES
            | self.JWT_CLAIMS
        )

        # CamelCase pattern for class names
        self._camel_case_pattern = re.compile(r"^[A-Z][a-zA-Z0-9]*(?:[A-Z][a-z0-9]+)*$")

    def filter_finding(
        self, finding: Any, source_code: str, value: str | None = None
    ) -> FilterResult:
        """
        Main entry point to filter a finding through all enabled filters.

        This method runs the finding through all applicable filters and
        returns a combined result.

        Args:
            finding: SecurityFinding object with file_path, line_number, code_snippet
            source_code: Full source code of the file
            value: Extracted secret value (optional, will extract from finding if not provided)

        Returns:
            FilterResult indicating if finding should be filtered

        Example:
            >>> result = filter.filter_finding(finding, source_code)
            >>> if result.should_filter:
            ...     print(f"Filtered: {result.filter_type}")
            ...     print(f"Reasoning: {result.reasoning}")
        """
        # Extract value from finding if not provided
        if value is None:
            value = self._extract_value_from_snippet(finding.code_snippet)

        if not value:
            return FilterResult(
                should_filter=False,
                confidence=0.0,
                filter_type="none",
                reasoning=["Could not extract value from finding"],
            )

        # Get line from source
        lines = source_code.split("\n")
        line_number = getattr(finding, "line_number", 1)
        line = lines[line_number - 1] if line_number <= len(lines) else ""

        # Parse AST once for all filters that need it
        try:
            ast_tree = ast.parse(source_code)
        except SyntaxError:
            ast_tree = None

        file_path = getattr(finding, "file_path", "")

        # Run through filters in order of FP count (highest first)
        filters_to_check = [
            # US-FP-001: Test file secrets (2,797 FPs)
            (
                self.config.test_file_enabled,
                lambda: self.is_test_file_secret(
                    file_path, line, value, source_code, ast_tree, line_number
                ),
                "test_file",
            ),
            # US-FP-002: Placeholder values (568 FPs)
            (
                self.config.placeholder_enabled,
                lambda: self.is_placeholder_value(value, line),
                "placeholder",
            ),
            # US-FP-003: Constant name pattern (220 FPs)
            (
                self.config.constant_name_enabled,
                lambda: self.is_constant_name_pattern(line, value, ast_tree, line_number),
                "constant_name",
            ),
            # US-FP-004: OAuth/Protocol enum (60 FPs)
            (
                self.config.protocol_enum_enabled,
                lambda: self.is_protocol_enum(value, line),
                "protocol_enum",
            ),
            # US-FP-005: Class export (60 FPs)
            (
                self.config.class_export_enabled,
                lambda: self.is_class_export(line, value, source_code, ast_tree, line_number),
                "class_export",
            ),
        ]

        combined_reasoning = []
        highest_confidence = 0.0
        highest_filter_type = "none"

        for enabled, filter_func, filter_type in filters_to_check:
            if not enabled:
                continue

            result = filter_func()

            if result.should_filter:
                combined_reasoning.extend(result.reasoning)
                if result.confidence > highest_confidence:
                    highest_confidence = result.confidence
                    highest_filter_type = filter_type

        if highest_confidence > 0:
            logger.debug(
                f"Filtered finding as {highest_filter_type} "
                f"(confidence: {highest_confidence:.2f}): {combined_reasoning}"
            )

        return FilterResult(
            should_filter=highest_confidence >= self._get_threshold(highest_filter_type),
            confidence=highest_confidence,
            filter_type=highest_filter_type,
            reasoning=combined_reasoning,
        )

    def is_test_file_secret(
        self,
        file_path: str,
        line: str,
        value: str,
        source_code: str,
        ast_tree: ast.Module | None = None,
        line_number: int = 1,
    ) -> FilterResult:
        """
        Detect if the finding is a test file secret (US-FP-001).

        Implements comprehensive test file detection:
        - File path patterns: /tests/, /test_, _test.py, conftest.py
        - Test function detection: def test_, @pytest.mark, @unittest
        - Mock value patterns: mock, fake, dummy, fixture
        - Test framework imports: pytest, unittest, mock

        Args:
            file_path: Path to the file
            line: The line containing the finding
            value: The extracted value
            source_code: Full source code
            ast_tree: Parsed AST (optional)
            line_number: Line number of finding

        Returns:
            FilterResult with True if this is a test file secret

        Example:
            >>> filter.is_test_file_secret(
            ...     "/tests/test_auth.py",
            ...     'api_key = "mock-serper-key"',
            ...     "mock-serper-key",
            ...     source_code
            ... )
            FilterResult(should_filter=True, confidence=0.95, ...)
        """
        indicators = []
        confidence = 0.0

        path_lower = file_path.lower()

        # Check file path patterns
        if self._test_path_pattern.search(path_lower):
            indicators.append("File path indicates test directory")
            confidence = 0.5

        # Check file name patterns
        if self._test_file_pattern.search(path_lower):
            indicators.append("File name matches test file pattern")
            confidence = max(confidence, 0.55)

        # Check for test function context
        if ast_tree:
            func_name = self._get_enclosing_function(ast_tree, line_number)
            if func_name:
                if self._test_func_pattern.search(func_name):
                    indicators.append(f"Inside test function: {func_name}")
                    confidence = max(confidence, 0.75)

                # Check for test decorators
                decorators = self._get_function_decorators(ast_tree, func_name)
                test_decorators = [
                    d for d in decorators if any(td in d for td in self.TEST_DECORATORS)
                ]
                if test_decorators:
                    indicators.append(f"Has test decorators: {test_decorators}")
                    confidence = max(confidence, 0.85)

        # Check for mock value patterns
        if self._mock_value_pattern.search(value):
            indicators.append("Value contains mock/test pattern")
            confidence = max(confidence, 0.85)

        # Also check the line for mock patterns
        if self._mock_value_pattern.search(line):
            indicators.append("Line contains mock/test pattern")
            confidence = max(confidence, 0.80)

        # Check for test framework imports
        if any(imp in source_code for imp in self.TEST_IMPORTS):
            if confidence > 0:  # Only boost if other signals present
                indicators.append("File imports test frameworks")
                confidence = min(confidence + 0.1, 0.95)

        # Combined signal boost
        if len(indicators) >= 2:
            confidence = min(confidence + 0.15, 0.95)
            indicators.append(f"Multiple test indicators ({len(indicators)})")

        should_filter = confidence >= self.config.test_file_threshold

        logger.debug(
            f"Test file filter: file={file_path}, "
            f"confidence={confidence:.2f}, filter={should_filter}"
        )

        return FilterResult(
            should_filter=should_filter,
            confidence=confidence,
            filter_type="test_file",
            reasoning=indicators,
        )

    def is_placeholder_value(self, value: str, line: str) -> FilterResult:
        """
        Detect if the value is a placeholder (US-FP-002).

        Implements placeholder detection:
        - Explicit patterns: your-, my-, example, placeholder, change-me, TODO
        - Template patterns: <...>, {...}, xxx, ***
        - Known placeholder values whitelist
        - Low entropy structural patterns

        Args:
            value: The extracted value
            line: The line containing the finding

        Returns:
            FilterResult with True if this is a placeholder

        Example:
            >>> filter.is_placeholder_value("your-openai-api-key-here", line)
            FilterResult(should_filter=True, confidence=0.98, ...)
        """
        indicators = []
        confidence = 0.0

        value_lower = value.lower()

        # Check known placeholder values (exact match)
        if value_lower in self.KNOWN_PLACEHOLDERS:
            indicators.append("Matches known placeholder value")
            confidence = 0.99
            return FilterResult(
                should_filter=True,
                confidence=confidence,
                filter_type="placeholder",
                reasoning=indicators,
            )

        # Check explicit placeholder patterns
        for pattern in self._placeholder_patterns:
            if pattern.search(value_lower):
                indicators.append(f"Matches placeholder pattern: {pattern.pattern}")
                confidence = max(confidence, 0.95)
                break

        # Check structural patterns (low entropy)
        for pattern, pattern_name in self.STRUCTURAL_PATTERNS:
            if re.match(pattern, value):
                indicators.append(f"Matches structural pattern: {pattern_name}")
                confidence = max(confidence, 0.85)
                break

        # Check for template file context
        template_indicators = [
            ".example",
            ".template",
            ".sample",
            ".dist",
        ]
        if any(ind in line.lower() for ind in template_indicators):
            indicators.append("Line indicates template/example context")
            confidence = max(confidence, 0.70)

        # Check for documentation context (comments)
        if line.strip().startswith("#") or '"""' in line or "'''" in line:
            indicators.append("Value appears in documentation/comment")
            confidence = max(confidence, 0.70)

        should_filter = confidence >= self.config.placeholder_threshold

        return FilterResult(
            should_filter=should_filter,
            confidence=confidence,
            filter_type="placeholder",
            reasoning=indicators,
        )

    def is_constant_name_pattern(
        self,
        line: str,
        value: str,
        ast_tree: ast.Module | None = None,
        line_number: int = 1,
    ) -> FilterResult:
        """
        Detect if the value matches the variable name (US-FP-003).

        Detects patterns like:
        - API_KEY = "API_KEY"
        - SERPER_API_KEY = "SERPER_API_KEY"
        - Case-insensitive matching
        - Handle underscores vs hyphens

        Args:
            line: The line containing the finding
            value: The extracted value
            ast_tree: Parsed AST (optional)
            line_number: Line number of finding

        Returns:
            FilterResult with True if value matches variable name

        Example:
            >>> filter.is_constant_name_pattern(
            ...     'SERPER_API_KEY = "SERPER_API_KEY"',
            ...     "SERPER_API_KEY"
            ... )
            FilterResult(should_filter=True, confidence=0.95, ...)
        """
        indicators = []
        confidence = 0.0

        # Extract variable name from line
        var_match = re.search(r"(\w+)\s*=", line)
        if not var_match:
            return FilterResult(
                should_filter=False,
                confidence=0.0,
                filter_type="constant_name",
                reasoning=["Could not extract variable name from line"],
            )

        var_name = var_match.group(1)

        # Normalize both for comparison
        norm_var = var_name.lower().replace("_", "").replace("-", "")
        norm_val = value.lower().replace("_", "").replace("-", "")

        # Direct match
        if norm_var == norm_val:
            indicators.append(f"Value '{value}' matches variable name '{var_name}'")
            confidence = 0.95

        # Check for Enum class context
        if ast_tree and confidence > 0:
            if self._is_in_enum_class(ast_tree, line_number):
                indicators.append("Assignment is in an Enum class")
                confidence = 0.98

        # Check for config key lookup pattern
        config_patterns = [
            r"config\[",
            r"settings\[",
            r"environ\[",
            r"getenv\(",
        ]
        if any(re.search(p, line, re.IGNORECASE) for p in config_patterns):
            indicators.append("Appears to be a config key lookup name")
            confidence = max(confidence, 0.90)

        should_filter = confidence >= self.config.constant_name_threshold

        return FilterResult(
            should_filter=should_filter,
            confidence=confidence,
            filter_type="constant_name",
            reasoning=indicators,
        )

    def is_protocol_enum(self, value: str, line: str) -> FilterResult:
        """
        Detect if the value is a standard protocol constant (US-FP-004).

        Whitelist of standard values:
        - OAuth: refresh_token, access_token, authorization_code, client_credentials
        - Grant types: password, implicit
        - Token types: bearer, basic
        - JWT claims: iss, sub, aud, exp

        Args:
            value: The extracted value
            line: The line containing the finding

        Returns:
            FilterResult with True if this is a protocol constant

        Example:
            >>> filter.is_protocol_enum("refresh_token", line)
            FilterResult(should_filter=True, confidence=0.98, ...)
        """
        indicators = []
        confidence = 0.0

        # Normalize value
        value_normalized = value.lower().replace("-", "_")

        # Check against protocol constants whitelist
        if value_normalized in self._protocol_constants:
            indicators.append(f"'{value}' is a standard protocol constant")
            confidence = 0.98

        # Check for OAuth context in line
        oauth_indicators = [
            "oauth",
            "oidc",
            "openid",
            "grant_type",
            "grant-type",
            "token_type",
            "token-type",
            "response_type",
            "response-type",
        ]
        if any(ind in line.lower() for ind in oauth_indicators):
            if confidence > 0:
                indicators.append("Line contains OAuth context")
                confidence = min(confidence + 0.01, 0.99)

        # Check variable name for protocol indicators
        var_match = re.search(r"(\w+)\s*=", line)
        if var_match:
            var_name = var_match.group(1).lower()
            if any(ind in var_name for ind in ["oauth", "grant", "token_type", "auth_type"]):
                if confidence > 0:
                    indicators.append(f"Variable name indicates protocol usage: {var_name}")
                    confidence = min(confidence + 0.01, 0.99)
                else:
                    # Even without whitelist match, variable name is strong signal
                    indicators.append(f"Variable name indicates protocol usage: {var_name}")
                    confidence = 0.85

        should_filter = confidence >= self.config.protocol_enum_threshold

        return FilterResult(
            should_filter=should_filter,
            confidence=confidence,
            filter_type="protocol_enum",
            reasoning=indicators,
        )

    def is_class_export(
        self,
        line: str,
        value: str,
        source_code: str,
        ast_tree: ast.Module | None = None,
        line_number: int = 1,
    ) -> FilterResult:
        """
        Detect if the value is a class name in __all__ exports (US-FP-005).

        Detects:
        - AST detection of __all__ assignments
        - CamelCase pattern recognition
        - Module export context
        - Class definition verification

        Args:
            line: The line containing the finding
            value: The extracted value
            source_code: Full source code
            ast_tree: Parsed AST (optional)
            line_number: Line number of finding

        Returns:
            FilterResult with True if this is a class export

        Example:
            >>> filter.is_class_export(
            ...     '__all__ = ["TreeSelectLeafEmbeddingRetriever"]',
            ...     "TreeSelectLeafEmbeddingRetriever",
            ...     source_code
            ... )
            FilterResult(should_filter=True, confidence=0.99, ...)
        """
        indicators = []
        confidence = 0.0

        # Quick check: is this in __all__ context?
        if "__all__" not in source_code:
            return FilterResult(
                should_filter=False,
                confidence=0.0,
                filter_type="class_export",
                reasoning=["No __all__ in file"],
            )

        # Check if value is in __all__ using AST
        in_all = False
        if ast_tree:
            in_all = self._is_in_all_export(ast_tree, value, line_number)
        else:
            # Fallback: check if line contains __all__
            in_all = "__all__" in line

        if in_all:
            indicators.append("String is in __all__ export list")
            confidence = 0.99

        # Check for CamelCase class name pattern
        if self._camel_case_pattern.match(value):
            if in_all:
                indicators.append(f"'{value}' matches CamelCase class name pattern")
                # Don't boost confidence, already at 0.99
            else:
                indicators.append(f"'{value}' matches CamelCase pattern but not in __all__")
                confidence = max(confidence, 0.60)

        # Verify class exists in file
        if ast_tree and in_all:
            if self._class_exists(ast_tree, value):
                indicators.append(f"Class '{value}' is defined in this file")
                # Confidence is already 0.99
            elif self._function_exists(ast_tree, value):
                indicators.append(f"Function '{value}' is defined in this file")
                # Functions in __all__ are also valid

        should_filter = confidence >= self.config.class_export_threshold

        return FilterResult(
            should_filter=should_filter,
            confidence=confidence,
            filter_type="class_export",
            reasoning=indicators,
        )

    # -------------------------------------------------------------------------
    # Helper methods
    # -------------------------------------------------------------------------

    def _get_threshold(self, filter_type: str) -> float:
        """Get the configured threshold for a filter type."""
        thresholds = {
            "test_file": self.config.test_file_threshold,
            "placeholder": self.config.placeholder_threshold,
            "constant_name": self.config.constant_name_threshold,
            "protocol_enum": self.config.protocol_enum_threshold,
            "class_export": self.config.class_export_threshold,
            "none": 1.0,
        }
        return thresholds.get(filter_type, 0.5)

    def _extract_value_from_snippet(self, snippet: str) -> str | None:
        """Extract the string value from a code snippet."""
        # Try to find quoted strings
        patterns = [
            r'"([^"]+)"',
            r"'([^']+)'",
        ]
        for pattern in patterns:
            match = re.search(pattern, snippet)
            if match:
                return match.group(1)
        return None

    def _get_enclosing_function(self, tree: ast.Module, line_number: int) -> str | None:
        """Find the function containing the given line."""
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if hasattr(node, "end_lineno"):
                    if node.lineno <= line_number <= node.end_lineno:
                        return node.name
                elif node.lineno <= line_number:
                    # Fallback for older Python without end_lineno
                    return node.name
        return None

    def _get_function_decorators(self, tree: ast.Module, func_name: str) -> list[str]:
        """Get decorators for a function."""
        decorators = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node.name == func_name:
                    for decorator in node.decorator_list:
                        if isinstance(decorator, ast.Name):
                            decorators.append(decorator.id)
                        elif isinstance(decorator, ast.Attribute):
                            # Handle things like pytest.mark.asyncio
                            parts = []
                            current = decorator
                            while isinstance(current, ast.Attribute):
                                parts.append(current.attr)
                                current = current.value
                            if isinstance(current, ast.Name):
                                parts.append(current.id)
                            decorators.append(".".join(reversed(parts)))
                        elif isinstance(decorator, ast.Call):
                            # Handle decorator calls like @pytest.fixture()
                            if isinstance(decorator.func, ast.Name):
                                decorators.append(decorator.func.id)
                            elif isinstance(decorator.func, ast.Attribute):
                                parts = []
                                current = decorator.func
                                while isinstance(current, ast.Attribute):
                                    parts.append(current.attr)
                                    current = current.value
                                if isinstance(current, ast.Name):
                                    parts.append(current.id)
                                decorators.append(".".join(reversed(parts)))
        return decorators

    def _is_in_enum_class(self, tree: ast.Module, line_number: int) -> bool:
        """Check if line is inside an Enum class definition."""
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                # Check if class inherits from Enum
                for base in node.bases:
                    base_name = ""
                    if isinstance(base, ast.Name):
                        base_name = base.id
                    elif isinstance(base, ast.Attribute):
                        base_name = base.attr

                    if "enum" in base_name.lower():
                        # Check if line is in this class
                        if hasattr(node, "end_lineno"):
                            if node.lineno <= line_number <= node.end_lineno:
                                return True
                        elif node.lineno <= line_number:
                            return True
        return False

    def _is_in_all_export(self, tree: ast.Module, value: str, line_number: int) -> bool:
        """Check if value is in __all__ export list."""
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == "__all__":
                        # Check if this is a list containing our value
                        if isinstance(node.value, (ast.List, ast.Tuple)):
                            for elt in node.value.elts:
                                if isinstance(elt, ast.Constant):
                                    if elt.value == value:
                                        return True
                        # Also check line proximity for multi-line __all__
                        if hasattr(node, "end_lineno"):
                            if node.lineno <= line_number <= node.end_lineno:
                                return True
                        elif abs(node.lineno - line_number) < 20:
                            return True
        return False

    def _class_exists(self, tree: ast.Module, class_name: str) -> bool:
        """Check if a class is defined in the AST."""
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == class_name:
                return True
        return False

    def _function_exists(self, tree: ast.Module, func_name: str) -> bool:
        """Check if a function is defined in the AST."""
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node.name == func_name:
                    return True
        return False
