"""
Dashboard API endpoints for Vantage Security Platform.

This module provides REST API endpoints for dashboard score widgets,
trend calculations, risk contributors, and multi-project summaries.
"""

from datetime import datetime, timedelta

from fastapi import APIRouter, Query, Request
from pydantic import BaseModel, Field

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


# Response Models


class ScoreBreakdown(BaseModel):
    """Score breakdown by component."""

    topology_score: int = Field(..., description="Topology risk score")
    agent_score: int = Field(..., description="Agent risk score")
    interaction_score: int = Field(..., description="Interaction risk score")


class ScoreTrend(BaseModel):
    """Score trend indicator."""

    direction: str = Field(..., description="Trend direction: up, down, stable")
    change: int = Field(..., description="Score change from previous")
    change_percent: float = Field(..., description="Percentage change")


class RiskContributor(BaseModel):
    """Top risk contributor item."""

    id: str
    name: str
    type: str = Field(..., description="Type: agent, finding, policy")
    risk_score: int
    description: str
    recommendation: str | None = None


class QuickAction(BaseModel):
    """Quick action recommendation."""

    id: str
    title: str
    description: str
    action_type: str = Field(..., description="Type: fix, review, configure")
    priority: str = Field(..., description="Priority: high, medium, low")
    target_url: str | None = None


class ScoreWidgetResponse(BaseModel):
    """Response for score widget data."""

    project_id: str
    project_name: str
    current_score: int
    breakdown: ScoreBreakdown
    trend: ScoreTrend
    last_scan_at: datetime | None
    findings_summary: dict[str, int]
    top_risks: list[RiskContributor]
    quick_actions: list[QuickAction]

    class Config:
        json_schema_extra = {
            "example": {
                "project_id": "proj-uuid",
                "project_name": "My Agent System",
                "current_score": 72,
                "breakdown": {
                    "topology_score": 45,
                    "agent_score": 68,
                    "interaction_score": 58,
                },
                "trend": {"direction": "down", "change": -5, "change_percent": -6.5},
                "last_scan_at": "2025-11-21T10:00:00Z",
                "findings_summary": {"critical": 2, "high": 5, "medium": 12, "low": 4},
                "top_risks": [],
                "quick_actions": [],
            }
        }


class ProjectScoreSummary(BaseModel):
    """Summary of a project's score for multi-project view."""

    project_id: str
    project_name: str
    score: int
    trend_direction: str
    trend_change: int
    critical_findings: int
    high_findings: int
    last_scan_at: datetime | None


class DashboardSummaryResponse(BaseModel):
    """Multi-project dashboard summary."""

    total_projects: int
    average_score: float
    projects: list[ProjectScoreSummary]
    overall_trend: str
    total_critical_findings: int
    total_high_findings: int


class ScoreHistoryPoint(BaseModel):
    """Single point in score history."""

    date: str
    score: int
    breakdown: ScoreBreakdown | None = None


class ScoreHistoryResponse(BaseModel):
    """Response for score history/trend data."""

    project_id: str
    period: str
    current: ScoreBreakdown
    previous: ScoreBreakdown | None
    trend: str
    change: int
    history: list[ScoreHistoryPoint]


# Helper functions


def _calculate_trend(current: int, previous: int) -> ScoreTrend:
    """Calculate score trend from current and previous scores."""
    change = current - previous
    if previous > 0:
        change_percent = (change / previous) * 100
    else:
        change_percent = 0.0

    if change > 5:
        direction = "up"
    elif change < -5:
        direction = "down"
    else:
        direction = "stable"

    return ScoreTrend(
        direction=direction,
        change=change,
        change_percent=round(change_percent, 1),
    )


def _get_score_color(score: int) -> str:
    """Get color code for score visualization."""
    if score >= 85:
        return "#4CAF50"  # Green - Excellent
    elif score >= 70:
        return "#8BC34A"  # Light Green - Good
    elif score >= 55:
        return "#FFC107"  # Yellow - Fair
    elif score >= 40:
        return "#FF9800"  # Orange - Poor
    else:
        return "#F44336"  # Red - Critical


# Dashboard Endpoints


@router.get(
    "/score",
    response_model=list[ScoreWidgetResponse],
    summary="Get current user's project scores",
)
async def get_user_scores(
    request: Request,
) -> list[ScoreWidgetResponse]:
    """
    Get score widgets for all projects accessible to the current user.

    Returns current ATSS scores with breakdown, trends, and quick actions.
    """
    # TODO: Implement actual database queries
    # For now, return demo data

    demo_projects = [
        {
            "project_id": "proj-1",
            "project_name": "Payment Agent System",
            "current_score": 72,
            "breakdown": ScoreBreakdown(
                topology_score=45,
                agent_score=68,
                interaction_score=58,
            ),
            "previous_score": 77,
            "last_scan_at": datetime.utcnow() - timedelta(hours=2),
            "findings": {"critical": 2, "high": 5, "medium": 12, "low": 4},
        },
        {
            "project_id": "proj-2",
            "project_name": "Customer Service Bot",
            "current_score": 85,
            "breakdown": ScoreBreakdown(
                topology_score=80,
                agent_score=88,
                interaction_score=82,
            ),
            "previous_score": 82,
            "last_scan_at": datetime.utcnow() - timedelta(days=1),
            "findings": {"critical": 0, "high": 1, "medium": 5, "low": 8},
        },
    ]

    results = []
    for proj in demo_projects:
        trend = _calculate_trend(proj["current_score"], proj["previous_score"])

        # Generate quick actions based on findings
        actions = []
        if proj["findings"]["critical"] > 0:
            actions.append(
                QuickAction(
                    id="action-1",
                    title=f"Fix {proj['findings']['critical']} critical findings",
                    description="Critical vulnerabilities require immediate attention",
                    action_type="fix",
                    priority="high",
                )
            )

        # Generate top risks
        risks = []
        if proj["findings"]["critical"] > 0:
            risks.append(
                RiskContributor(
                    id="risk-1",
                    name="Prompt Injection Vulnerability",
                    type="finding",
                    risk_score=95,
                    description="Unvalidated user input passed to LLM",
                    recommendation="Add input validation and sanitization",
                )
            )

        results.append(
            ScoreWidgetResponse(
                project_id=proj["project_id"],
                project_name=proj["project_name"],
                current_score=proj["current_score"],
                breakdown=proj["breakdown"],
                trend=trend,
                last_scan_at=proj["last_scan_at"],
                findings_summary=proj["findings"],
                top_risks=risks,
                quick_actions=actions,
            )
        )

    return results


@router.get(
    "/summary",
    response_model=DashboardSummaryResponse,
    summary="Get multi-project overview",
)
async def get_dashboard_summary(
    request: Request,
) -> DashboardSummaryResponse:
    """
    Get summary overview of all projects for the current user.

    Provides aggregate statistics and per-project summaries.
    """
    # TODO: Implement actual database queries

    # Demo data
    projects = [
        ProjectScoreSummary(
            project_id="proj-1",
            project_name="Payment Agent System",
            score=72,
            trend_direction="down",
            trend_change=-5,
            critical_findings=2,
            high_findings=5,
            last_scan_at=datetime.utcnow() - timedelta(hours=2),
        ),
        ProjectScoreSummary(
            project_id="proj-2",
            project_name="Customer Service Bot",
            score=85,
            trend_direction="up",
            trend_change=3,
            critical_findings=0,
            high_findings=1,
            last_scan_at=datetime.utcnow() - timedelta(days=1),
        ),
        ProjectScoreSummary(
            project_id="proj-3",
            project_name="Data Pipeline Agents",
            score=65,
            trend_direction="stable",
            trend_change=0,
            critical_findings=1,
            high_findings=3,
            last_scan_at=datetime.utcnow() - timedelta(hours=12),
        ),
    ]

    total_critical = sum(p.critical_findings for p in projects)
    total_high = sum(p.high_findings for p in projects)
    avg_score = sum(p.score for p in projects) / len(projects) if projects else 0

    # Calculate overall trend
    up_count = sum(1 for p in projects if p.trend_direction == "up")
    down_count = sum(1 for p in projects if p.trend_direction == "down")
    if up_count > down_count:
        overall_trend = "improving"
    elif down_count > up_count:
        overall_trend = "declining"
    else:
        overall_trend = "stable"

    return DashboardSummaryResponse(
        total_projects=len(projects),
        average_score=round(avg_score, 1),
        projects=projects,
        overall_trend=overall_trend,
        total_critical_findings=total_critical,
        total_high_findings=total_high,
    )


@router.get(
    "/projects/{project_id}/score/widget",
    response_model=ScoreWidgetResponse,
    summary="Get single project widget data",
)
async def get_project_score_widget(
    request: Request,
    project_id: str,
) -> ScoreWidgetResponse:
    """
    Get detailed score widget data for a single project.

    Includes breakdown, trend, top risks, and quick actions.
    """
    # TODO: Implement actual database queries

    # Demo data
    return ScoreWidgetResponse(
        project_id=project_id,
        project_name="Payment Agent System",
        current_score=72,
        breakdown=ScoreBreakdown(
            topology_score=45,
            agent_score=68,
            interaction_score=58,
        ),
        trend=ScoreTrend(
            direction="down",
            change=-5,
            change_percent=-6.5,
        ),
        last_scan_at=datetime.utcnow() - timedelta(hours=2),
        findings_summary={
            "critical": 2,
            "high": 5,
            "medium": 12,
            "low": 4,
        },
        top_risks=[
            RiskContributor(
                id="risk-1",
                name="payment_agent",
                type="agent",
                risk_score=24,
                description="Excessive privileges for privileged operations",
            ),
            RiskContributor(
                id="risk-2",
                name="api_gateway",
                type="agent",
                risk_score=18,
                description="No input validation for user requests",
            ),
            RiskContributor(
                id="risk-3",
                name="Circular trust",
                type="policy",
                risk_score=15,
                description="Circular trust relationships in processing zone",
            ),
        ],
        quick_actions=[
            QuickAction(
                id="action-1",
                title="View Critical Findings",
                description="Review 2 critical severity findings",
                action_type="review",
                priority="high",
            ),
            QuickAction(
                id="action-2",
                title="Download Report",
                description="Generate PDF security report",
                action_type="configure",
                priority="medium",
            ),
        ],
    )


@router.get(
    "/projects/{project_id}/scores/history",
    response_model=ScoreHistoryResponse,
    summary="Get score history for trends",
)
async def get_score_history(
    request: Request,
    project_id: str,
    period: str = Query("30d", description="Time period: 7d, 30d, 90d"),
) -> ScoreHistoryResponse:
    """
    Get historical ATSS scores for trend charts.

    Returns score data points over the specified time period.
    """
    # Parse period
    days = 30
    if period == "7d":
        days = 7
    elif period == "90d":
        days = 90

    # TODO: Implement actual database queries

    # Generate demo history data
    history = []
    base_score = 72
    now = datetime.utcnow()

    for i in range(days, 0, -1):
        date = now - timedelta(days=i)
        # Simulate some variation
        variation = (i % 7) - 3
        score = max(0, min(100, base_score + variation))

        history.append(
            ScoreHistoryPoint(
                date=date.strftime("%Y-%m-%d"),
                score=score,
            )
        )

    # Current and previous scores
    current = ScoreBreakdown(
        topology_score=45,
        agent_score=68,
        interaction_score=58,
    )
    previous = ScoreBreakdown(
        topology_score=50,
        agent_score=70,
        interaction_score=62,
    )

    current_total = (current.topology_score + current.agent_score + current.interaction_score) // 3
    previous_total = (
        previous.topology_score + previous.agent_score + previous.interaction_score
    ) // 3
    change = current_total - previous_total

    if change > 5:
        trend = "improving"
    elif change < -5:
        trend = "declining"
    else:
        trend = "stable"

    return ScoreHistoryResponse(
        project_id=project_id,
        period=period,
        current=current,
        previous=previous,
        trend=trend,
        change=change,
        history=history,
    )
