"""
Pydantic models for Vantage Security API.

This module defines request/response models for the REST API,
including scan requests, results, and error responses.
"""

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class ScanStatus(str, Enum):
    """Status of a security scan."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ReportFormat(str, Enum):
    """Supported report output formats."""

    JSON = "json"
    HTML = "html"
    SARIF = "sarif"
    PDF = "pdf"


class ScanRequest(BaseModel):
    """Request to initiate a security scan."""

    path: str = Field(..., description="Path to the project to scan")
    include_simulation: bool = Field(
        default=True,
        description="Include infection simulation in scan",
    )
    include_remediation: bool = Field(
        default=True,
        description="Include remediation suggestions",
    )
    timeout_seconds: int = Field(
        default=300,
        ge=30,
        le=3600,
        description="Maximum scan duration in seconds",
    )


class FindingSummary(BaseModel):
    """Summary of a security finding."""

    id: str
    title: str
    severity: str
    category: str
    file_path: str | None = None
    line_number: int | None = None
    owasp_category: str | None = None


class ScanResponse(BaseModel):
    """Response containing scan results."""

    scan_id: str
    status: ScanStatus
    atss_score: int | None = None
    grade: str | None = None
    findings_count: int = 0
    critical_count: int = 0
    high_count: int = 0
    medium_count: int = 0
    low_count: int = 0
    agents_scanned: int = 0
    frameworks_detected: list[str] = Field(default_factory=list)
    duration_ms: int = 0
    created_at: datetime | None = None
    completed_at: datetime | None = None
    findings: list[FindingSummary] = Field(default_factory=list)
    message: str | None = None


class AsyncScanResponse(BaseModel):
    """Response for async scan submission."""

    scan_id: str
    status: ScanStatus
    status_url: str
    webhook_url: str | None = None
    estimated_duration_seconds: int = 60
    message: str


class ReportRequest(BaseModel):
    """Request for generating a report."""

    format: ReportFormat = ReportFormat.JSON
    include_code_snippets: bool = True
    include_remediation: bool = True


class WebhookConfig(BaseModel):
    """Webhook configuration for async scan notifications."""

    url: str = Field(..., description="Webhook URL to call on completion")
    secret: str | None = Field(
        None,
        description="Secret for HMAC signature verification",
    )
    events: list[str] = Field(
        default_factory=lambda: ["scan.completed", "scan.failed"],
        description="Events to trigger webhook",
    )


class ErrorResponse(BaseModel):
    """Standard error response."""

    error: str
    message: str
    details: dict[str, Any] | None = None
    request_id: str | None = None


class HealthResponse(BaseModel):
    """Health check response."""

    status: str
    version: str
    database: str = "unknown"
    cache: str = "unknown"


class PaginatedResponse(BaseModel):
    """Generic paginated response wrapper."""

    items: list[Any]
    total: int
    page: int
    page_size: int
    has_next: bool
    has_prev: bool


class APIKeyCreate(BaseModel):
    """Request to create an API key."""

    name: str = Field(..., min_length=1, max_length=100)
    scopes: list[str] = Field(
        default_factory=lambda: ["scan:read", "scan:write"],
    )
    expires_in_days: int | None = Field(
        None,
        ge=1,
        le=365,
        description="Days until expiration (None for no expiration)",
    )


class APIKeyResponse(BaseModel):
    """Response containing API key details."""

    id: str
    name: str
    key_prefix: str
    scopes: list[str]
    created_at: datetime
    expires_at: datetime | None = None
    last_used: datetime | None = None
    # Only included on creation
    key: str | None = None


class ProjectCreate(BaseModel):
    """Request to create a project."""

    name: str = Field(..., min_length=1, max_length=255)
    description: str | None = None
    settings: dict[str, Any] | None = None


class ProjectResponse(BaseModel):
    """Response containing project details."""

    id: str
    name: str
    description: str | None = None
    owner_id: str
    settings: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime | None = None
    scan_count: int = 0
    member_count: int = 0


class ProjectMemberAdd(BaseModel):
    """Request to add a member to a project."""

    user_email: str = Field(..., description="Email of user to add")
    role: str = Field(
        default="developer",
        description="Role: admin, security_engineer, developer, viewer",
    )


class UserResponse(BaseModel):
    """Response containing user details."""

    id: str
    email: str
    name: str | None = None
    role: str
    is_active: bool
    is_verified: bool
    is_mfa_enabled: bool
    created_at: datetime
    last_login_at: datetime | None = None


class DashboardStats(BaseModel):
    """Dashboard statistics response."""

    total_scans: int
    total_projects: int
    average_score: float
    critical_findings: int
    high_findings: int
    recent_scans: list[ScanResponse]
    score_trend: list[dict[str, Any]]


class WebhookCreate(BaseModel):
    """Request to create a webhook."""

    url: str = Field(..., description="Webhook URL")
    events: list[str] = Field(
        default_factory=lambda: ["scan.completed"],
        description="Events to trigger webhook",
    )
    secret: str | None = Field(
        None,
        description="Optional secret for signature verification",
    )


class WebhookResponse(BaseModel):
    """Response containing webhook details."""

    id: str
    project_id: str
    url: str
    events: list[str]
    is_active: bool
    created_at: datetime
    last_delivery_at: datetime | None = None
    last_delivery_status: str | None = None
