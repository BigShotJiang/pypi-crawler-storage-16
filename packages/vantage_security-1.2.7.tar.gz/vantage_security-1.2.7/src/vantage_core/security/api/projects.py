"""
Project Management API endpoints for Vantage Security Platform.

This module provides REST API endpoints for project CRUD operations,
member management, and project settings.
"""

from datetime import datetime
from typing import Any
from uuid import uuid4

from fastapi import APIRouter, HTTPException, Query, Request, status
from pydantic import BaseModel, Field

from vantage_core.security.api.rbac import (
    Role,
)

router = APIRouter(prefix="/projects", tags=["projects"])


# Request/Response Models


class ProjectCreate(BaseModel):
    """Request to create a new project."""

    name: str = Field(..., min_length=1, max_length=255, description="Project name")
    description: str | None = Field(None, max_length=2000, description="Project description")
    settings: dict[str, Any] | None = Field(default_factory=dict, description="Project settings")

    class Config:
        json_schema_extra = {
            "example": {
                "name": "My Agent System",
                "description": "Security scanning for my AI agents",
                "settings": {"default_scan_options": {"include_simulation": True}},
            }
        }


class ProjectUpdate(BaseModel):
    """Request to update a project."""

    name: str | None = Field(None, min_length=1, max_length=255)
    description: str | None = Field(None, max_length=2000)
    settings: dict[str, Any] | None = None


class ProjectMemberAdd(BaseModel):
    """Request to add a project member."""

    user_id: str = Field(..., description="User ID to add")
    role: str = Field(..., description="Role to assign")

    class Config:
        json_schema_extra = {"example": {"user_id": "user-uuid", "role": "developer"}}


class ProjectMemberResponse(BaseModel):
    """Response for a project member."""

    id: str
    user_id: str
    email: str | None = None
    name: str | None = None
    role: str
    added_at: datetime


class ProjectResponse(BaseModel):
    """Response for a project."""

    id: str
    name: str
    description: str | None
    owner_id: str
    settings: dict[str, Any]
    created_at: datetime
    updated_at: datetime
    member_count: int = 0
    scan_count: int = 0
    latest_score: int | None = None

    class Config:
        json_schema_extra = {
            "example": {
                "id": "proj-uuid",
                "name": "My Agent System",
                "description": "Security scanning for my AI agents",
                "owner_id": "user-uuid",
                "settings": {},
                "created_at": "2025-11-21T10:00:00Z",
                "updated_at": "2025-11-21T10:00:00Z",
                "member_count": 3,
                "scan_count": 10,
                "latest_score": 72,
            }
        }


class ProjectListResponse(BaseModel):
    """Paginated list of projects."""

    items: list[ProjectResponse]
    total: int
    page: int
    per_page: int


class ScanListItem(BaseModel):
    """Summary item for scan list."""

    id: str
    status: str
    source_type: str
    source_ref: str | None
    atss_score: int | None
    finding_count: int
    critical_count: int
    high_count: int
    created_at: datetime
    completed_at: datetime | None


class ScanListResponse(BaseModel):
    """Paginated list of scans."""

    items: list[ScanListItem]
    total: int
    page: int
    per_page: int


class ScanCompareResponse(BaseModel):
    """Response for scan comparison."""

    scan1_id: str
    scan2_id: str
    score_change: int
    new_findings: list[dict]
    resolved_findings: list[dict]
    unchanged_findings: int
    summary: dict[str, Any]


# In-memory storage for demo/testing
_projects: dict[str, dict] = {}
_project_members: dict[str, list[dict]] = {}


def _get_current_user(request: Request) -> dict:
    """Get current user from request state."""
    user = getattr(request.state, "user", None)
    if user is None:
        # Default test user
        return {"id": "test-user-id", "email": "test@example.com"}
    return user


# Project CRUD Endpoints


@router.post(
    "",
    response_model=ProjectResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new project",
)
async def create_project(
    request: Request,
    project: ProjectCreate,
) -> ProjectResponse:
    """
    Create a new project.

    The current user becomes the owner with admin role.
    """
    user = _get_current_user(request)
    user_id = user.get("id", "test-user")

    project_id = str(uuid4())
    now = datetime.utcnow()

    project_data = {
        "id": project_id,
        "name": project.name,
        "description": project.description,
        "owner_id": user_id,
        "settings": project.settings or {},
        "created_at": now,
        "updated_at": now,
    }

    _projects[project_id] = project_data

    # Add owner as admin member
    _project_members[project_id] = [
        {
            "id": str(uuid4()),
            "user_id": user_id,
            "role": Role.ADMIN.value,
            "added_at": now,
        }
    ]

    return ProjectResponse(
        id=project_data["id"],
        name=project_data["name"],
        description=project_data["description"],
        owner_id=project_data["owner_id"],
        settings=project_data["settings"],
        created_at=project_data["created_at"],
        updated_at=project_data["updated_at"],
        member_count=1,
        scan_count=0,
    )


@router.get(
    "",
    response_model=ProjectListResponse,
    summary="List all projects",
)
async def list_projects(
    request: Request,
    page: int = Query(1, ge=1, description="Page number"),
    per_page: int = Query(20, ge=1, le=100, description="Items per page"),
    search: str | None = Query(None, description="Search by name"),
) -> ProjectListResponse:
    """
    List all projects accessible to the current user.
    """
    user = _get_current_user(request)
    user_id = user.get("id", "test-user")

    # Filter projects by membership
    accessible_projects = []
    for project_id, project in _projects.items():
        # Owner always has access
        if project["owner_id"] == user_id:
            accessible_projects.append(project)
            continue

        # Check membership
        members = _project_members.get(project_id, [])
        if any(m["user_id"] == user_id for m in members):
            accessible_projects.append(project)

    # Apply search filter
    if search:
        accessible_projects = [
            p for p in accessible_projects if search.lower() in p["name"].lower()
        ]

    # Sort by created_at descending
    accessible_projects.sort(key=lambda x: x["created_at"], reverse=True)

    # Paginate
    total = len(accessible_projects)
    start = (page - 1) * per_page
    end = start + per_page
    page_projects = accessible_projects[start:end]

    items = []
    for project in page_projects:
        members = _project_members.get(project["id"], [])
        items.append(
            ProjectResponse(
                id=project["id"],
                name=project["name"],
                description=project["description"],
                owner_id=project["owner_id"],
                settings=project["settings"],
                created_at=project["created_at"],
                updated_at=project["updated_at"],
                member_count=len(members),
                scan_count=0,  # TODO: Get from scans
            )
        )

    return ProjectListResponse(
        items=items,
        total=total,
        page=page,
        per_page=per_page,
    )


@router.get(
    "/{project_id}",
    response_model=ProjectResponse,
    summary="Get project details",
)
async def get_project(
    request: Request,
    project_id: str,
) -> ProjectResponse:
    """
    Get detailed information about a specific project.
    """
    project = _projects.get(project_id)
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Project not found: {project_id}",
        )

    members = _project_members.get(project_id, [])

    return ProjectResponse(
        id=project["id"],
        name=project["name"],
        description=project["description"],
        owner_id=project["owner_id"],
        settings=project["settings"],
        created_at=project["created_at"],
        updated_at=project["updated_at"],
        member_count=len(members),
        scan_count=0,  # TODO: Get from scans
    )


@router.put(
    "/{project_id}",
    response_model=ProjectResponse,
    summary="Update project",
)
async def update_project(
    request: Request,
    project_id: str,
    update: ProjectUpdate,
) -> ProjectResponse:
    """
    Update project details.

    Requires admin or security_engineer role.
    """
    project = _projects.get(project_id)
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Project not found: {project_id}",
        )

    # Apply updates
    if update.name is not None:
        project["name"] = update.name
    if update.description is not None:
        project["description"] = update.description
    if update.settings is not None:
        project["settings"] = update.settings
    project["updated_at"] = datetime.utcnow()

    members = _project_members.get(project_id, [])

    return ProjectResponse(
        id=project["id"],
        name=project["name"],
        description=project["description"],
        owner_id=project["owner_id"],
        settings=project["settings"],
        created_at=project["created_at"],
        updated_at=project["updated_at"],
        member_count=len(members),
        scan_count=0,
    )


@router.delete(
    "/{project_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete project",
)
async def delete_project(
    request: Request,
    project_id: str,
):
    """
    Delete a project and all associated data.

    Requires admin role or project ownership.
    """
    if project_id not in _projects:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Project not found: {project_id}",
        )

    del _projects[project_id]
    if project_id in _project_members:
        del _project_members[project_id]

    return None


# Member Management Endpoints


@router.get(
    "/{project_id}/members",
    response_model=list[ProjectMemberResponse],
    summary="List project members",
)
async def list_project_members(
    request: Request,
    project_id: str,
) -> list[ProjectMemberResponse]:
    """
    List all members of a project.
    """
    if project_id not in _projects:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Project not found: {project_id}",
        )

    members = _project_members.get(project_id, [])

    return [
        ProjectMemberResponse(
            id=m["id"],
            user_id=m["user_id"],
            role=m["role"],
            added_at=m["added_at"],
        )
        for m in members
    ]


@router.post(
    "/{project_id}/members",
    response_model=ProjectMemberResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Add project member",
)
async def add_project_member(
    request: Request,
    project_id: str,
    member: ProjectMemberAdd,
) -> ProjectMemberResponse:
    """
    Add a new member to a project.

    Requires admin role.
    """
    if project_id not in _projects:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Project not found: {project_id}",
        )

    # Validate role
    valid_roles = [r.value for r in Role]
    if member.role not in valid_roles:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid role: {member.role}. Must be one of: {valid_roles}",
        )

    # Check if already a member
    members = _project_members.get(project_id, [])
    if any(m["user_id"] == member.user_id for m in members):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="User is already a member of this project",
        )

    # Add member
    member_data = {
        "id": str(uuid4()),
        "user_id": member.user_id,
        "role": member.role,
        "added_at": datetime.utcnow(),
    }

    if project_id not in _project_members:
        _project_members[project_id] = []
    _project_members[project_id].append(member_data)

    return ProjectMemberResponse(
        id=member_data["id"],
        user_id=member_data["user_id"],
        role=member_data["role"],
        added_at=member_data["added_at"],
    )


@router.put(
    "/{project_id}/members/{user_id}",
    response_model=ProjectMemberResponse,
    summary="Update member role",
)
async def update_member_role(
    request: Request,
    project_id: str,
    user_id: str,
    role: str = Query(..., description="New role"),
) -> ProjectMemberResponse:
    """
    Update a member's role in a project.

    Requires admin role.
    """
    if project_id not in _projects:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Project not found: {project_id}",
        )

    members = _project_members.get(project_id, [])
    member = next((m for m in members if m["user_id"] == user_id), None)

    if not member:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=f"Member not found: {user_id}"
        )

    # Validate role
    valid_roles = [r.value for r in Role]
    if role not in valid_roles:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Invalid role: {role}")

    member["role"] = role

    return ProjectMemberResponse(
        id=member["id"],
        user_id=member["user_id"],
        role=member["role"],
        added_at=member["added_at"],
    )


@router.delete(
    "/{project_id}/members/{user_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Remove project member",
)
async def remove_project_member(
    request: Request,
    project_id: str,
    user_id: str,
):
    """
    Remove a member from a project.

    Requires admin role.
    """
    if project_id not in _projects:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Project not found: {project_id}",
        )

    members = _project_members.get(project_id, [])
    member_idx = next((i for i, m in enumerate(members) if m["user_id"] == user_id), None)

    if member_idx is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=f"Member not found: {user_id}"
        )

    # Don't allow removing the owner
    project = _projects[project_id]
    if user_id == project["owner_id"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot remove project owner",
        )

    del members[member_idx]

    return None


# Scan List Endpoint


@router.get(
    "/{project_id}/scans",
    response_model=ScanListResponse,
    summary="List project scans",
)
async def list_project_scans(
    request: Request,
    project_id: str,
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    status_filter: str | None = Query(None, alias="status", description="Filter by status"),
    sort_by: str = Query("created_at", description="Sort field"),
    sort_order: str = Query("desc", description="Sort order"),
) -> ScanListResponse:
    """
    List all scans for a project with filtering and pagination.
    """
    if project_id not in _projects:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Project not found: {project_id}",
        )

    # TODO: Implement actual scan retrieval from database
    # For now, return empty list
    return ScanListResponse(
        items=[],
        total=0,
        page=page,
        per_page=per_page,
    )


@router.get(
    "/scans/compare",
    response_model=ScanCompareResponse,
    summary="Compare two scans",
)
async def compare_scans(
    request: Request,
    scan1_id: str = Query(..., description="First scan ID"),
    scan2_id: str = Query(..., description="Second scan ID"),
) -> ScanCompareResponse:
    """
    Compare findings between two scans.

    Returns new findings, resolved findings, and score changes.
    """
    # TODO: Implement actual scan comparison
    return ScanCompareResponse(
        scan1_id=scan1_id,
        scan2_id=scan2_id,
        score_change=0,
        new_findings=[],
        resolved_findings=[],
        unchanged_findings=0,
        summary={
            "scan1_score": 0,
            "scan2_score": 0,
            "scan1_findings": 0,
            "scan2_findings": 0,
        },
    )
