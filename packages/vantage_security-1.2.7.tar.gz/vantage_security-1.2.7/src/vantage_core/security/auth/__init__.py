"""
Authentication and authorization module for Vantage Security Scanner.

This module provides Role-Based Access Control (RBAC) functionality.
"""

from vantage_core.security.auth.rbac import (
    ROLE_PERMISSIONS,
    Permission,
    RBACManager,
    Role,
    User,
    rbac_manager,
)

__all__ = [
    "Permission",
    "ROLE_PERMISSIONS",
    "Role",
    "RBACManager",
    "User",
    "rbac_manager",
]
