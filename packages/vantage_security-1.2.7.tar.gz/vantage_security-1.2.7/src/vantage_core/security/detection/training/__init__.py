"""Training pipeline for ML secret detection models."""

from .synthetic_data import SyntheticDataGenerator

__all__ = ["SyntheticDataGenerator"]
