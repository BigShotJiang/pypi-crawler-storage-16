"""
Vantage Security Scanner - Integrations Package

This package contains integrations with external services and tools
for the security scanner, including Git repository connectors.
"""

from .github import (
    ConnectRepositoryRequest,
    ConnectRepositoryResponse,
    GitHubConfig,
    GitHubService,
    RepositoryInfo,
    ScanRepositoryRequest,
    ScanRepositoryResponse,
    WebhookEvent,
    github_service,
)

# Backward compatibility aliases
GitHubConnector = GitHubService
GitHubRepo = RepositoryInfo
GitCloner = GitHubService

__all__ = [
    "GitHubService",
    "GitHubConfig",
    "ConnectRepositoryRequest",
    "ConnectRepositoryResponse",
    "ScanRepositoryRequest",
    "ScanRepositoryResponse",
    "RepositoryInfo",
    "WebhookEvent",
    "github_service",
    # Backward compatibility
    "GitHubConnector",
    "GitHubRepo",
    "GitCloner",
]
