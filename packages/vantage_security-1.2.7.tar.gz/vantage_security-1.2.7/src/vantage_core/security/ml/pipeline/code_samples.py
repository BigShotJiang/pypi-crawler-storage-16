"""
Code samples for vulnerability detection training.

Contains actual vulnerable and safe code patterns for training.
"""

# Vulnerable Python samples with actual code patterns
VULNERABLE_PYTHON_SAMPLES = [
    # SQL Injection variations
    {
        "code": """def get_user(user_id):
    query = "SELECT * FROM users WHERE id = " + user_id
    return db.execute(query)""",
        "vulnerability_type": "sql_injection",
        "description": "SQL injection via string concatenation",
    },
    {
        "code": """def search_users(name):
    cursor.execute(f"SELECT * FROM users WHERE name = '{name}'")
    return cursor.fetchall()""",
        "vulnerability_type": "sql_injection",
        "description": "SQL injection via f-string",
    },
    {
        "code": """def login(username, password):
    query = "SELECT * FROM users WHERE user='%s' AND pass='%s'" % (username, password)
    return db.execute(query)""",
        "vulnerability_type": "sql_injection",
        "description": "SQL injection via % formatting",
    },
    {
        "code": """def find_product(product_id):
    sql = "SELECT * FROM products WHERE id = {}".format(product_id)
    return execute_sql(sql)""",
        "vulnerability_type": "sql_injection",
        "description": "SQL injection via format()",
    },
    {
        "code": """async def get_order(order_id: str):
    return await db.fetch_one(
        f"SELECT * FROM orders WHERE id = '{order_id}'"
    )""",
        "vulnerability_type": "sql_injection",
        "description": "Async SQL injection",
    },
    # Command injection variations
    {
        "code": """import os
def run_backup(filename):
    os.system("tar -czf backup.tar.gz " + filename)""",
        "vulnerability_type": "command_injection",
        "description": "Command injection via os.system",
    },
    {
        "code": """import subprocess
def ping_host(host):
    subprocess.call("ping -c 3 " + host, shell=True)""",
        "vulnerability_type": "command_injection",
        "description": "Command injection via subprocess with shell=True",
    },
    {
        "code": """import os
def list_files(directory):
    return os.popen(f"ls -la {directory}").read()""",
        "vulnerability_type": "command_injection",
        "description": "Command injection via os.popen",
    },
    {
        "code": """def execute_command(cmd):
    import subprocess
    result = subprocess.run(cmd, shell=True, capture_output=True)
    return result.stdout""",
        "vulnerability_type": "command_injection",
        "description": "Command injection via subprocess.run with shell=True",
    },
    {
        "code": """import os
def cleanup(path):
    os.system("rm -rf " + path)""",
        "vulnerability_type": "command_injection",
        "description": "Dangerous command injection with rm",
    },
    # XSS variations
    {
        "code": '''def render_greeting(name):
    return f"<h1>Hello, {name}!</h1>"''',
        "vulnerability_type": "xss",
        "description": "XSS via unescaped user input in HTML",
    },
    {
        "code": '''def display_message(message):
    return "<div class='alert'>" + message + "</div>"''',
        "vulnerability_type": "xss",
        "description": "XSS via string concatenation in HTML",
    },
    {
        "code": """def create_link(url, text):
    return f'<a href="{url}">{text}</a>""",
        "vulnerability_type": "xss",
        "description": "XSS via unvalidated URL and text",
    },
    {
        "code": """def render_comment(comment):
    template = "<p>{}</p>"
    return template.format(comment)""",
        "vulnerability_type": "xss",
        "description": "XSS via format in HTML",
    },
    {
        "code": '''@app.route('/search')
def search():
    query = request.args.get('q')
    return f"<p>Results for: {query}</p>"''',
        "vulnerability_type": "xss",
        "description": "XSS in Flask route",
    },
    # Path traversal variations
    {
        "code": """def read_config(filename):
    path = "/etc/configs/" + filename
    with open(path) as f:
        return f.read()""",
        "vulnerability_type": "path_traversal",
        "description": "Path traversal via concatenation",
    },
    {
        "code": """def serve_file(filename):
    base_path = "./uploads/"
    return open(base_path + filename, "rb").read()""",
        "vulnerability_type": "path_traversal",
        "description": "Path traversal in file serving",
    },
    {
        "code": """def download_attachment(attachment_id):
    path = f"attachments/{attachment_id}"
    return send_file(path)""",
        "vulnerability_type": "path_traversal",
        "description": "Path traversal via f-string",
    },
    {
        "code": """import os
def get_log(logname):
    logpath = os.path.join("/var/log/app", logname)
    return open(logpath).read()""",
        "vulnerability_type": "path_traversal",
        "description": "Path traversal even with os.path.join",
    },
    # Hardcoded credentials
    {
        "code": """API_KEY = "sk-1234567890abcdef1234567890abcdef"
def call_api():
    return requests.get(url, headers={"Authorization": f"Bearer {API_KEY}"})""",
        "vulnerability_type": "hardcoded_credentials",
        "description": "Hardcoded API key",
    },
    {
        "code": '''DATABASE_PASSWORD = "super_secret_password_123"
DB_URL = f"postgresql://admin:{DATABASE_PASSWORD}@localhost/mydb"''',
        "vulnerability_type": "hardcoded_credentials",
        "description": "Hardcoded database password",
    },
    {
        "code": '''AWS_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE"
AWS_SECRET_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"''',
        "vulnerability_type": "hardcoded_credentials",
        "description": "Hardcoded AWS credentials",
    },
    {
        "code": """def get_stripe_client():
    return stripe.Client(api_key="sk_live_abcdefghijklmnop123456789")""",
        "vulnerability_type": "hardcoded_credentials",
        "description": "Hardcoded Stripe key",
    },
    {
        "code": """SECRET_KEY = "my-super-secret-jwt-key-that-should-not-be-here"
token = jwt.encode(payload, SECRET_KEY, algorithm="HS256")""",
        "vulnerability_type": "hardcoded_credentials",
        "description": "Hardcoded JWT secret",
    },
    # Insecure deserialization
    {
        "code": """import pickle
def load_session(data):
    return pickle.loads(data)""",
        "vulnerability_type": "deserialization",
        "description": "Unsafe pickle loads",
    },
    {
        "code": """import pickle
def restore_state(session_file):
    with open(session_file, 'rb') as f:
        return pickle.load(f)""",
        "vulnerability_type": "deserialization",
        "description": "Unsafe pickle load from file",
    },
    {
        "code": """import yaml
def parse_config(yaml_str):
    return yaml.load(yaml_str)""",
        "vulnerability_type": "deserialization",
        "description": "Unsafe yaml.load",
    },
    {
        "code": """import yaml
config = yaml.load(open("config.yml"), Loader=yaml.Loader)""",
        "vulnerability_type": "deserialization",
        "description": "Yaml with unsafe Loader",
    },
    # SSRF variations
    {
        "code": """import requests
def fetch_url(url):
    return requests.get(url).content""",
        "vulnerability_type": "ssrf",
        "description": "SSRF via unvalidated URL",
    },
    {
        "code": """def proxy_request(target_url):
    response = urllib.request.urlopen(target_url)
    return response.read()""",
        "vulnerability_type": "ssrf",
        "description": "SSRF via urllib",
    },
    {
        "code": """async def fetch_resource(url: str):
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.text()""",
        "vulnerability_type": "ssrf",
        "description": "Async SSRF",
    },
    # Code injection
    {
        "code": """def calculate(expression):
    return eval(expression)""",
        "vulnerability_type": "code_injection",
        "description": "Code injection via eval",
    },
    {
        "code": """def run_code(code):
    exec(code)""",
        "vulnerability_type": "code_injection",
        "description": "Code injection via exec",
    },
    {
        "code": """def dynamic_import(module_name):
    return __import__(module_name)""",
        "vulnerability_type": "code_injection",
        "description": "Dynamic import",
    },
    {
        "code": """def compile_and_run(code_str):
    compiled = compile(code_str, '<string>', 'exec')
    exec(compiled)""",
        "vulnerability_type": "code_injection",
        "description": "Compile and exec",
    },
]

# Safe Python samples
SAFE_PYTHON_SAMPLES = [
    # Safe SQL queries
    {
        "code": """def get_user(user_id):
    query = "SELECT * FROM users WHERE id = %s"
    return db.execute(query, (user_id,))""",
        "vulnerability_type": "sql_injection",
        "description": "Parameterized query",
    },
    {
        "code": """def search_users(name):
    cursor.execute("SELECT * FROM users WHERE name = ?", (name,))
    return cursor.fetchall()""",
        "vulnerability_type": "sql_injection",
        "description": "SQLite parameterized query",
    },
    {
        "code": """def login(username, password):
    query = "SELECT * FROM users WHERE user = :user AND pass = :pass"
    return db.execute(query, {"user": username, "pass": password})""",
        "vulnerability_type": "sql_injection",
        "description": "Named parameters",
    },
    {
        "code": """async def get_order(order_id: int):
    return await db.fetch_one(
        "SELECT * FROM orders WHERE id = $1", order_id
    )""",
        "vulnerability_type": "sql_injection",
        "description": "Async parameterized query",
    },
    {
        "code": """from sqlalchemy import select
def get_products(category_id):
    stmt = select(Product).where(Product.category_id == category_id)
    return session.execute(stmt).scalars().all()""",
        "vulnerability_type": "sql_injection",
        "description": "SQLAlchemy ORM query",
    },
    # Safe command execution
    {
        "code": """import subprocess
def run_backup(filename):
    subprocess.run(["tar", "-czf", "backup.tar.gz", filename], check=True)""",
        "vulnerability_type": "command_injection",
        "description": "Safe subprocess with list",
    },
    {
        "code": """import subprocess
def ping_host(host):
    if not is_valid_hostname(host):
        raise ValueError("Invalid hostname")
    subprocess.run(["ping", "-c", "3", host], check=True)""",
        "vulnerability_type": "command_injection",
        "description": "Validated subprocess call",
    },
    {
        "code": """import shlex
import subprocess
def list_files(directory):
    if not os.path.isdir(directory):
        raise ValueError("Invalid directory")
    return subprocess.check_output(["ls", "-la", directory], text=True)""",
        "vulnerability_type": "command_injection",
        "description": "Safe directory listing",
    },
    {
        "code": """import subprocess
ALLOWED_COMMANDS = {"ls", "pwd", "whoami"}
def execute_command(cmd):
    if cmd not in ALLOWED_COMMANDS:
        raise ValueError("Command not allowed")
    return subprocess.run([cmd], capture_output=True, text=True)""",
        "vulnerability_type": "command_injection",
        "description": "Allowlist command execution",
    },
    # Safe HTML handling
    {
        "code": '''from html import escape
def render_greeting(name):
    safe_name = escape(name)
    return f"<h1>Hello, {safe_name}!</h1>"''',
        "vulnerability_type": "xss",
        "description": "HTML escaped output",
    },
    {
        "code": """from markupsafe import Markup, escape
def display_message(message):
    return Markup("<div class='alert'>") + escape(message) + Markup("</div>")""",
        "vulnerability_type": "xss",
        "description": "MarkupSafe escaping",
    },
    {
        "code": """import bleach
def sanitize_content(html_content):
    return bleach.clean(html_content, tags=['p', 'b', 'i'], strip=True)""",
        "vulnerability_type": "xss",
        "description": "Bleach HTML sanitization",
    },
    {
        "code": '''from django.utils.html import escape
def render_comment(comment):
    return f"<p>{escape(comment)}</p>"''',
        "vulnerability_type": "xss",
        "description": "Django HTML escaping",
    },
    {
        "code": """@app.route('/search')
def search():
    query = request.args.get('q', '')
    return render_template('search.html', query=query)""",
        "vulnerability_type": "xss",
        "description": "Template auto-escaping",
    },
    # Safe path handling
    {
        "code": """from pathlib import Path
def read_config(filename):
    base = Path("/etc/configs").resolve()
    target = (base / filename).resolve()
    if not target.is_relative_to(base):
        raise ValueError("Invalid path")
    return target.read_text()""",
        "vulnerability_type": "path_traversal",
        "description": "Safe path with pathlib",
    },
    {
        "code": """import os
def serve_file(filename):
    base_path = os.path.abspath("./uploads/")
    requested = os.path.abspath(os.path.join(base_path, filename))
    if not requested.startswith(base_path):
        raise ValueError("Path traversal detected")
    return open(requested, "rb").read()""",
        "vulnerability_type": "path_traversal",
        "description": "Safe path validation",
    },
    {
        "code": """import os
ALLOWED_FILES = {"readme.txt", "config.json", "data.csv"}
def download_attachment(filename):
    if filename not in ALLOWED_FILES:
        raise ValueError("File not allowed")
    return send_file(f"attachments/{filename}")""",
        "vulnerability_type": "path_traversal",
        "description": "Allowlist file access",
    },
    # Safe credential handling
    {
        "code": """import os
API_KEY = os.environ.get("API_KEY")
def call_api():
    if not API_KEY:
        raise ValueError("API_KEY not configured")
    return requests.get(url, headers={"Authorization": f"Bearer {API_KEY}"})""",
        "vulnerability_type": "hardcoded_credentials",
        "description": "Environment variable API key",
    },
    {
        "code": """from django.conf import settings
def get_database_url():
    return settings.DATABASE_URL""",
        "vulnerability_type": "hardcoded_credentials",
        "description": "Django settings for secrets",
    },
    {
        "code": """import boto3
def get_aws_client():
    # Uses IAM role or environment credentials
    return boto3.client('s3')""",
        "vulnerability_type": "hardcoded_credentials",
        "description": "AWS credentials from IAM",
    },
    {
        "code": """from cryptography.fernet import Fernet
key = Fernet.generate_key()  # Generated at runtime""",
        "vulnerability_type": "hardcoded_credentials",
        "description": "Runtime key generation",
    },
    # Safe deserialization
    {
        "code": """import json
def load_session(data):
    return json.loads(data)""",
        "vulnerability_type": "deserialization",
        "description": "Safe JSON parsing",
    },
    {
        "code": """import yaml
def parse_config(yaml_str):
    return yaml.safe_load(yaml_str)""",
        "vulnerability_type": "deserialization",
        "description": "Safe YAML loading",
    },
    {
        "code": """from pydantic import BaseModel
class UserData(BaseModel):
    name: str
    age: int

def parse_user(data: dict):
    return UserData(**data)""",
        "vulnerability_type": "deserialization",
        "description": "Pydantic validation",
    },
    # Safe URL handling
    {
        "code": """from urllib.parse import urlparse
ALLOWED_HOSTS = {"api.example.com", "cdn.example.com"}
def fetch_url(url):
    parsed = urlparse(url)
    if parsed.hostname not in ALLOWED_HOSTS:
        raise ValueError("Host not allowed")
    return requests.get(url, timeout=10).content""",
        "vulnerability_type": "ssrf",
        "description": "URL allowlist",
    },
    {
        "code": """import ipaddress
def is_internal_ip(ip):
    addr = ipaddress.ip_address(ip)
    return addr.is_private or addr.is_loopback

def fetch_url(url):
    parsed = urlparse(url)
    ip = socket.gethostbyname(parsed.hostname)
    if is_internal_ip(ip):
        raise ValueError("Internal IPs not allowed")
    return requests.get(url, timeout=10).content""",
        "vulnerability_type": "ssrf",
        "description": "IP address validation",
    },
    # Safe expression evaluation
    {
        "code": """import ast
def safe_eval(expression):
    tree = ast.parse(expression, mode='eval')
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Expression, ast.BinOp, ast.Constant,
                                 ast.Add, ast.Sub, ast.Mult, ast.Div)):
            raise ValueError("Invalid expression")
    return eval(compile(tree, '<string>', 'eval'))""",
        "vulnerability_type": "code_injection",
        "description": "AST-validated eval",
    },
    {
        "code": """import operator
OPERATORS = {'+': operator.add, '-': operator.sub, '*': operator.mul, '/': operator.truediv}
def calculate(a, op, b):
    if op not in OPERATORS:
        raise ValueError("Invalid operator")
    return OPERATORS[op](float(a), float(b))""",
        "vulnerability_type": "code_injection",
        "description": "Safe calculator without eval",
    },
]


def get_all_code_samples() -> list[dict]:
    """Get all code samples for training."""
    samples = []

    # Add vulnerable samples
    for sample in VULNERABLE_PYTHON_SAMPLES:
        samples.append(
            {
                "id": f"vuln-py-{len(samples)}",
                "code": sample["code"].strip(),
                "description": sample["description"],
                "vulnerability_type": sample["vulnerability_type"],
                "language": "python",
                "source": "code_samples",
                "is_vulnerable": True,
                "severity": "high",
            }
        )

    # Add safe samples
    for sample in SAFE_PYTHON_SAMPLES:
        samples.append(
            {
                "id": f"safe-py-{len(samples)}",
                "code": sample["code"].strip(),
                "description": sample["description"],
                "vulnerability_type": sample["vulnerability_type"],
                "language": "python",
                "source": "code_samples",
                "is_vulnerable": False,
                "severity": "none",
            }
        )

    return samples


def get_balanced_code_dataset(target_size: int = 500) -> list[dict]:
    """
    Create a balanced dataset of code samples.

    Args:
        target_size: Approximate total size of dataset

    Returns:
        Balanced list of vulnerable and safe code samples
    """
    import random

    samples = get_all_code_samples()

    vulnerable = [s for s in samples if s["is_vulnerable"]]
    safe = [s for s in samples if not s["is_vulnerable"]]

    # Calculate target per class
    target_per_class = target_size // 2

    # Expand if needed by duplicating with variation
    def expand_samples(sample_list, target):
        expanded = sample_list.copy()
        while len(expanded) < target:
            for sample in sample_list:
                if len(expanded) >= target:
                    break
                # Create variation
                variation = sample.copy()
                variation["id"] = f"{sample['id']}-var-{len(expanded)}"
                expanded.append(variation)
        return expanded[:target]

    vulnerable_expanded = expand_samples(vulnerable, target_per_class)
    safe_expanded = expand_samples(safe, target_per_class)

    # Combine and shuffle
    combined = vulnerable_expanded + safe_expanded
    random.shuffle(combined)

    return combined
