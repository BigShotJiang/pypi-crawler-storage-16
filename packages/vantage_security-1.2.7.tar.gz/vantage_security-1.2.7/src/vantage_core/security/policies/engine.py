"""
Policy Engine for Vantage Security Platform.

US-207: Policy Definition Interface Implementation
Provides YAML policy DSL parser, pre-built templates, validation,
policy evaluation engine, and inheritance support.

Features:
- YAML policy DSL parser
- Pre-built templates (default-secure, HIPAA, PCI-DSS, SOC2)
- Policy validation and conflict detection
- Policy evaluation engine
- Policy inheritance support
"""

import logging
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class PolicyAction(str, Enum):
    """Actions that can be taken when a policy rule matches."""

    DENY = "deny"
    WARN = "warn"
    REQUIRE_APPROVAL = "require_approval"
    AUDIT_LOG = "audit_log"
    ALLOW = "allow"


class TrustLevelEnum(str, Enum):
    """Trust levels for policy zones."""

    EXTERNAL = "EXTERNAL"
    USER = "USER"
    INTERNAL = "INTERNAL"
    PRIVILEGED = "PRIVILEGED"
    SYSTEM = "SYSTEM"


class DataClassification(str, Enum):
    """Data classification levels."""

    PUBLIC = "PUBLIC"
    INTERNAL = "INTERNAL"
    CONFIDENTIAL = "CONFIDENTIAL"
    SECRET = "SECRET"
    PHI = "PHI"  # Protected Health Information
    PCI = "PCI"  # Payment Card Industry data
    PII = "PII"  # Personally Identifiable Information


class RuleSeverity(str, Enum):
    """Severity levels for policy rules."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class ValidationError:
    """Represents a policy validation error."""

    message: str
    line: int | None = None
    path: str | None = None  # JSONPath-like path to the error
    suggestion: str | None = None


@dataclass
class PolicyZone:
    """Represents a trust zone in a policy."""

    name: str
    trust_level: TrustLevelEnum
    description: str = ""
    allowed_data_types: list[DataClassification] = field(default_factory=list)
    agents: list[str] = field(default_factory=list)  # Agent patterns or IDs
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class RuleCondition:
    """Condition for a policy rule."""

    source_zone: str | None = None
    destination_zone: str | None = None
    data_type: DataClassification | None = None
    trust_level: TrustLevelEnum | None = None
    tool_type: str | None = None
    agent_pattern: str | None = None
    custom_expression: str | None = None  # Advanced condition expression


@dataclass
class PolicyRule:
    """Represents a policy rule."""

    name: str
    condition: RuleCondition
    action: PolicyAction
    severity: RuleSeverity = RuleSeverity.MEDIUM
    message: str = ""
    enabled: bool = True
    priority: int = 100  # Lower number = higher priority
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Policy:
    """Represents a complete security policy."""

    name: str
    version: str = "1.0"
    description: str = ""
    extends: str | None = None  # Parent policy name
    zones: list[PolicyZone] = field(default_factory=list)
    rules: list[PolicyRule] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    is_template: bool = False

    @property
    def zone_names(self) -> list[str]:
        """Get list of zone names."""
        return [z.name for z in self.zones]


@dataclass
class PolicyViolation:
    """Represents a policy rule violation."""

    rule_name: str
    policy_name: str
    action: PolicyAction
    severity: RuleSeverity
    message: str
    context: dict[str, Any] = field(default_factory=dict)
    source_agent: str | None = None
    target_agent: str | None = None
    data_type: str | None = None
    recommendation: str = ""


@dataclass
class PolicyConflict:
    """Represents a conflict between policy rules."""

    rule1_name: str
    rule2_name: str
    conflict_type: str  # "contradicting", "redundant", "shadowing"
    description: str
    resolution: str


@dataclass
class PolicyTemplate:
    """Pre-built policy template."""

    name: str
    description: str
    policy: Policy
    use_cases: list[str] = field(default_factory=list)


class PolicyEngine:
    """
    Parse, validate, and evaluate security policies.

    Supports YAML policy definitions with inheritance,
    conflict detection, and evaluation against scan results.
    """

    def __init__(self):
        """Initialize the policy engine."""
        self._yaml_available = False
        self._check_dependencies()
        self._templates: dict[str, PolicyTemplate] = {}
        self._loaded_policies: dict[str, Policy] = {}
        self._initialize_templates()

    def _check_dependencies(self):
        """Check for YAML support."""
        try:
            import yaml

            self._yaml_available = True
            self._yaml = yaml
        except ImportError:
            logger.warning("PyYAML not available")
            self._yaml = None

    def parse_policy(self, yaml_content: str) -> Policy:
        """
        Parse a YAML policy definition.

        Args:
            yaml_content: YAML string containing policy definition

        Returns:
            Parsed Policy object

        Raises:
            ValueError: If parsing fails
        """
        if not self._yaml_available:
            raise RuntimeError("YAML parsing not available")

        try:
            data = self._yaml.safe_load(yaml_content)
        except Exception as e:
            raise ValueError(f"Invalid YAML syntax: {e}")

        if not isinstance(data, dict):
            raise ValueError("Policy must be a YAML dictionary")

        # Extract policy metadata
        policy_data = data.get("policy", data)

        name = policy_data.get("name", "unnamed")
        version = str(policy_data.get("version", "1.0"))
        description = policy_data.get("description", "")
        extends = policy_data.get("extends")

        # Parse zones
        zones: list[PolicyZone] = []
        for zone_data in policy_data.get("zones", []):
            zone = self._parse_zone(zone_data)
            zones.append(zone)

        # Parse rules
        rules: list[PolicyRule] = []
        for rule_data in policy_data.get("rules", []):
            rule = self._parse_rule(rule_data)
            rules.append(rule)

        policy = Policy(
            name=name,
            version=version,
            description=description,
            extends=extends,
            zones=zones,
            rules=rules,
            metadata=policy_data.get("metadata", {}),
        )

        # Apply inheritance if specified
        if extends:
            policy = self._apply_inheritance(policy)

        return policy

    def _parse_zone(self, zone_data: dict) -> PolicyZone:
        """Parse a zone definition."""
        name = zone_data.get("name", "unnamed")

        # Parse trust level
        trust_str = zone_data.get("trust_level", "INTERNAL")
        try:
            trust_level = TrustLevelEnum(trust_str.upper())
        except ValueError:
            trust_level = TrustLevelEnum.INTERNAL

        # Parse allowed data types
        allowed_data = []
        for dt in zone_data.get("allowed_data_types", []):
            try:
                allowed_data.append(DataClassification(dt.upper()))
            except ValueError:
                logger.warning(f"Unknown data classification: {dt}")

        return PolicyZone(
            name=name,
            trust_level=trust_level,
            description=zone_data.get("description", ""),
            allowed_data_types=allowed_data,
            agents=zone_data.get("agents", []),
            metadata=zone_data.get("metadata", {}),
        )

    def _parse_rule(self, rule_data: dict) -> PolicyRule:
        """Parse a rule definition."""
        name = rule_data.get("name", "unnamed")

        # Parse condition
        condition_data = rule_data.get("condition", {})
        condition = self._parse_condition(condition_data)

        # Parse action
        action_str = rule_data.get("action", "warn")
        try:
            action = PolicyAction(action_str.lower())
        except ValueError:
            action = PolicyAction.WARN

        # Parse severity
        severity_str = rule_data.get("severity", "medium")
        try:
            severity = RuleSeverity(severity_str.lower())
        except ValueError:
            severity = RuleSeverity.MEDIUM

        return PolicyRule(
            name=name,
            condition=condition,
            action=action,
            severity=severity,
            message=rule_data.get("message", ""),
            enabled=rule_data.get("enabled", True),
            priority=rule_data.get("priority", 100),
            metadata=rule_data.get("metadata", {}),
        )

    def _parse_condition(self, condition_data: dict | str) -> RuleCondition:
        """Parse a rule condition."""
        if isinstance(condition_data, str):
            # Simple expression format
            return RuleCondition(custom_expression=condition_data)

        # Parse data type
        data_type = None
        if "data_type" in condition_data:
            try:
                data_type = DataClassification(condition_data["data_type"].upper())
            except ValueError:
                pass

        # Parse trust level
        trust_level = None
        if "trust_level" in condition_data:
            try:
                trust_level = TrustLevelEnum(condition_data["trust_level"].upper())
            except ValueError:
                pass

        return RuleCondition(
            source_zone=condition_data.get("source_zone"),
            destination_zone=condition_data.get("destination_zone"),
            data_type=data_type,
            trust_level=trust_level,
            tool_type=condition_data.get("tool_type"),
            agent_pattern=condition_data.get("agent_pattern"),
            custom_expression=condition_data.get("expression"),
        )

    def _apply_inheritance(self, policy: Policy) -> Policy:
        """Apply policy inheritance from parent policy."""
        if not policy.extends:
            return policy

        # Find parent policy
        parent = self._templates.get(policy.extends)
        if not parent:
            parent_policy = self._loaded_policies.get(policy.extends)
            if not parent_policy:
                logger.warning(f"Parent policy '{policy.extends}' not found")
                return policy
        else:
            parent_policy = parent.policy

        # Merge zones (child overrides parent)
        zone_names = {z.name for z in policy.zones}
        merged_zones = list(policy.zones)
        for parent_zone in parent_policy.zones:
            if parent_zone.name not in zone_names:
                merged_zones.append(parent_zone)

        # Merge rules (child rules have higher priority)
        rule_names = {r.name for r in policy.rules}
        merged_rules = list(policy.rules)
        for parent_rule in parent_policy.rules:
            if parent_rule.name not in rule_names:
                merged_rules.append(parent_rule)

        policy.zones = merged_zones
        policy.rules = merged_rules

        return policy

    def validate_policy(self, policy: Policy) -> list[ValidationError]:
        """
        Validate a policy for errors and warnings.

        Args:
            policy: Policy to validate

        Returns:
            List of ValidationError objects
        """
        errors: list[ValidationError] = []

        # Check for required fields
        if not policy.name:
            errors.append(ValidationError(message="Policy name is required", path="policy.name"))

        # Validate zones
        zone_names: set[str] = set()
        for i, zone in enumerate(policy.zones):
            if not zone.name:
                errors.append(
                    ValidationError(
                        message=f"Zone at index {i} missing name",
                        path=f"policy.zones[{i}].name",
                    )
                )
            elif zone.name in zone_names:
                errors.append(
                    ValidationError(
                        message=f"Duplicate zone name: {zone.name}",
                        path=f"policy.zones[{i}].name",
                        suggestion="Use unique names for each zone",
                    )
                )
            else:
                zone_names.add(zone.name)

        # Validate rules
        rule_names: set[str] = set()
        for i, rule in enumerate(policy.rules):
            if not rule.name:
                errors.append(
                    ValidationError(
                        message=f"Rule at index {i} missing name",
                        path=f"policy.rules[{i}].name",
                    )
                )
            elif rule.name in rule_names:
                errors.append(
                    ValidationError(
                        message=f"Duplicate rule name: {rule.name}",
                        path=f"policy.rules[{i}].name",
                    )
                )
            else:
                rule_names.add(rule.name)

            # Validate zone references in conditions
            if rule.condition.source_zone and rule.condition.source_zone not in zone_names:
                errors.append(
                    ValidationError(
                        message=f"Rule '{rule.name}' references unknown source zone: {rule.condition.source_zone}",
                        path=f"policy.rules[{i}].condition.source_zone",
                        suggestion=f"Available zones: {', '.join(zone_names)}",
                    )
                )

            if (
                rule.condition.destination_zone
                and rule.condition.destination_zone not in zone_names
            ):
                errors.append(
                    ValidationError(
                        message=f"Rule '{rule.name}' references unknown destination zone: {rule.condition.destination_zone}",
                        path=f"policy.rules[{i}].condition.destination_zone",
                        suggestion=f"Available zones: {', '.join(zone_names)}",
                    )
                )

            # Check for empty conditions
            if not any(
                [
                    rule.condition.source_zone,
                    rule.condition.destination_zone,
                    rule.condition.data_type,
                    rule.condition.trust_level,
                    rule.condition.tool_type,
                    rule.condition.agent_pattern,
                    rule.condition.custom_expression,
                ]
            ):
                errors.append(
                    ValidationError(
                        message=f"Rule '{rule.name}' has empty condition (will match everything)",
                        path=f"policy.rules[{i}].condition",
                        suggestion="Add specific conditions to limit rule scope",
                    )
                )

        return errors

    def detect_conflicts(self, policies: list[Policy]) -> list[PolicyConflict]:
        """
        Detect conflicts between policy rules.

        Args:
            policies: List of policies to check

        Returns:
            List of PolicyConflict objects
        """
        conflicts: list[PolicyConflict] = []

        # Gather all rules with their policy context
        all_rules: list[tuple[str, PolicyRule]] = []
        for policy in policies:
            for rule in policy.rules:
                all_rules.append((policy.name, rule))

        # Check each pair of rules for conflicts
        for i, (policy1, rule1) in enumerate(all_rules):
            for policy2, rule2 in all_rules[i + 1 :]:
                conflict = self._check_rule_conflict(policy1, rule1, policy2, rule2)
                if conflict:
                    conflicts.append(conflict)

        return conflicts

    def _check_rule_conflict(
        self, policy1: str, rule1: PolicyRule, policy2: str, rule2: PolicyRule
    ) -> PolicyConflict | None:
        """Check if two rules conflict."""
        # Rules with different priorities don't conflict (higher priority wins)
        if rule1.priority != rule2.priority:
            return None

        # Check if conditions overlap
        if not self._conditions_overlap(rule1.condition, rule2.condition):
            return None

        # Check for contradicting actions
        if rule1.action == PolicyAction.DENY and rule2.action == PolicyAction.ALLOW:
            return PolicyConflict(
                rule1_name=f"{policy1}.{rule1.name}",
                rule2_name=f"{policy2}.{rule2.name}",
                conflict_type="contradicting",
                description="Rules have opposite actions (DENY vs ALLOW) for overlapping conditions",
                resolution="Set different priorities or refine conditions to eliminate overlap",
            )

        if rule1.action == PolicyAction.ALLOW and rule2.action == PolicyAction.DENY:
            return PolicyConflict(
                rule1_name=f"{policy1}.{rule1.name}",
                rule2_name=f"{policy2}.{rule2.name}",
                conflict_type="contradicting",
                description="Rules have opposite actions (ALLOW vs DENY) for overlapping conditions",
                resolution="Set different priorities or refine conditions to eliminate overlap",
            )

        # Check for redundant rules
        if rule1.action == rule2.action and rule1.severity == rule2.severity and policy1 == policy2:
            return PolicyConflict(
                rule1_name=rule1.name,
                rule2_name=rule2.name,
                conflict_type="redundant",
                description="Rules have identical actions for overlapping conditions",
                resolution="Consolidate into a single rule or differentiate conditions",
            )

        return None

    def _conditions_overlap(self, c1: RuleCondition, c2: RuleCondition) -> bool:
        """Check if two conditions can match the same situation."""
        # If either has custom expression, assume potential overlap
        if c1.custom_expression or c2.custom_expression:
            return True

        # Check zone overlap
        if c1.source_zone and c2.source_zone:
            if c1.source_zone != c2.source_zone:
                return False

        if c1.destination_zone and c2.destination_zone:
            if c1.destination_zone != c2.destination_zone:
                return False

        # Check data type overlap
        if c1.data_type and c2.data_type:
            if c1.data_type != c2.data_type:
                return False

        # Check trust level overlap
        if c1.trust_level and c2.trust_level:
            if c1.trust_level != c2.trust_level:
                return False

        # If we got here, conditions could overlap
        return True

    def evaluate_policy(
        self, policy: Policy, scan_results: dict[str, Any]
    ) -> list[PolicyViolation]:
        """
        Evaluate a policy against scan results.

        Args:
            policy: Policy to evaluate
            scan_results: Scan results dictionary with agents, communications, etc.

        Returns:
            List of PolicyViolation objects
        """
        violations: list[PolicyViolation] = []

        # Get data flows from scan results
        data_flows = scan_results.get("data_flows", [])
        agents = scan_results.get("agents", [])
        communications = scan_results.get("communications", [])

        # Build agent zone mapping
        agent_zones = self._map_agents_to_zones(agents, policy.zones)

        # Evaluate each rule
        for rule in policy.rules:
            if not rule.enabled:
                continue

            # Check data flows against rule
            for flow in data_flows:
                if self._rule_matches_flow(rule, flow, agent_zones, policy):
                    violation = PolicyViolation(
                        rule_name=rule.name,
                        policy_name=policy.name,
                        action=rule.action,
                        severity=rule.severity,
                        message=rule.message or f"Policy rule '{rule.name}' violated",
                        context=flow,
                        source_agent=flow.get("source"),
                        target_agent=flow.get("target"),
                        data_type=flow.get("data_type"),
                        recommendation=self._get_violation_recommendation(rule),
                    )
                    violations.append(violation)

            # Check communications against rule
            for comm in communications:
                if self._rule_matches_communication(rule, comm, agent_zones, policy):
                    violation = PolicyViolation(
                        rule_name=rule.name,
                        policy_name=policy.name,
                        action=rule.action,
                        severity=rule.severity,
                        message=rule.message or f"Policy rule '{rule.name}' violated",
                        context=comm,
                        source_agent=comm.get("source_id"),
                        target_agent=comm.get("target_id"),
                        recommendation=self._get_violation_recommendation(rule),
                    )
                    violations.append(violation)

        # Sort by severity and priority
        violations.sort(
            key=lambda v: (
                {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}.get(
                    v.severity.value, 5
                )
            )
        )

        return violations

    def _map_agents_to_zones(self, agents: list[dict], zones: list[PolicyZone]) -> dict[str, str]:
        """Map agents to their trust zones."""
        agent_zones: dict[str, str] = {}

        for agent in agents:
            agent_id = agent.get("id", "")
            agent_trust = agent.get("trust_level", "INTERNAL")

            # Find matching zone
            for zone in zones:
                # Match by agent pattern
                for pattern in zone.agents:
                    if re.match(pattern, agent_id):
                        agent_zones[agent_id] = zone.name
                        break

                # Match by trust level
                if agent_id not in agent_zones:
                    if zone.trust_level.value == agent_trust:
                        agent_zones[agent_id] = zone.name

            # Default zone based on trust level
            if agent_id not in agent_zones:
                agent_zones[agent_id] = agent_trust.lower()

        return agent_zones

    def _rule_matches_flow(
        self, rule: PolicyRule, flow: dict, agent_zones: dict[str, str], policy: Policy
    ) -> bool:
        """Check if a rule matches a data flow."""
        cond = rule.condition

        # Check source zone
        if cond.source_zone:
            source = flow.get("source", "")
            source_zone = agent_zones.get(source, "")
            if source_zone != cond.source_zone:
                return False

        # Check destination zone
        if cond.destination_zone:
            target = flow.get("target", "")
            target_zone = agent_zones.get(target, "")
            if target_zone != cond.destination_zone:
                return False

        # Check data type
        if cond.data_type:
            flow_data_type = flow.get("data_type", "").upper()
            if flow_data_type != cond.data_type.value:
                return False

        # Check custom expression
        if cond.custom_expression:
            try:
                # Simple expression evaluation
                result = self._evaluate_expression(cond.custom_expression, flow)
                if not result:
                    return False
            except Exception as e:
                logger.error(f"Error evaluating expression: {e}")
                return False

        return True

    def _rule_matches_communication(
        self, rule: PolicyRule, comm: dict, agent_zones: dict[str, str], policy: Policy
    ) -> bool:
        """Check if a rule matches a communication."""
        cond = rule.condition

        # Check source zone
        if cond.source_zone:
            source = comm.get("source_id", "")
            source_zone = agent_zones.get(source, "")
            if source_zone != cond.source_zone:
                return False

        # Check destination zone
        if cond.destination_zone:
            target = comm.get("target_id", "")
            target_zone = agent_zones.get(target, "")
            if target_zone != cond.destination_zone:
                return False

        # Check agent pattern
        if cond.agent_pattern:
            source = comm.get("source_id", "")
            target = comm.get("target_id", "")
            if not (re.match(cond.agent_pattern, source) or re.match(cond.agent_pattern, target)):
                return False

        return True

    def _evaluate_expression(self, expression: str, context: dict) -> bool:
        """Evaluate a simple expression against context."""
        # Very basic expression evaluation
        # In production, use a proper expression parser

        # Handle "data_type == X" patterns
        match = re.match(r"(\w+)\s*==\s*(\w+)", expression)
        if match:
            field = match.group(1)
            value = match.group(2)
            return str(context.get(field, "")).upper() == value.upper()

        # Handle "field.subfield == X" patterns
        match = re.match(r"(\w+)\.(\w+)\s*==\s*(\w+)", expression)
        if match:
            obj = match.group(1)
            field = match.group(2)
            value = match.group(3)
            obj_data = context.get(obj, {})
            if isinstance(obj_data, dict):
                return str(obj_data.get(field, "")).upper() == value.upper()

        return False

    def _get_violation_recommendation(self, rule: PolicyRule) -> str:
        """Get recommendation for a policy violation."""
        if rule.action == PolicyAction.DENY:
            return f"Block this operation: {rule.message or 'Policy violation detected'}"
        elif rule.action == PolicyAction.REQUIRE_APPROVAL:
            return "Require manual approval before proceeding"
        elif rule.action == PolicyAction.WARN:
            return f"Warning: {rule.message or 'Review this operation'}"
        else:
            return "Log and audit this operation"

    def get_templates(self) -> list[PolicyTemplate]:
        """Get all available policy templates."""
        return list(self._templates.values())

    def get_template(self, name: str) -> PolicyTemplate | None:
        """Get a specific policy template by name."""
        return self._templates.get(name)

    def _initialize_templates(self):
        """Initialize pre-built policy templates."""
        # Default Secure template
        self._templates["default-secure"] = PolicyTemplate(
            name="default-secure",
            description="Basic security policy with reasonable defaults",
            use_cases=["General purpose", "Getting started"],
            policy=Policy(
                name="default-secure",
                version="1.0",
                description="Default security policy for agent systems",
                zones=[
                    PolicyZone(
                        name="external",
                        trust_level=TrustLevelEnum.EXTERNAL,
                        description="External/untrusted sources",
                    ),
                    PolicyZone(
                        name="internal",
                        trust_level=TrustLevelEnum.INTERNAL,
                        description="Internal trusted agents",
                    ),
                    PolicyZone(
                        name="privileged",
                        trust_level=TrustLevelEnum.PRIVILEGED,
                        description="Privileged operations",
                    ),
                ],
                rules=[
                    PolicyRule(
                        name="no-external-to-privileged",
                        condition=RuleCondition(
                            source_zone="external",
                            destination_zone="privileged",
                        ),
                        action=PolicyAction.DENY,
                        severity=RuleSeverity.CRITICAL,
                        message="External access to privileged zone denied",
                    ),
                    PolicyRule(
                        name="log-cross-boundary",
                        condition=RuleCondition(
                            source_zone="internal",
                            destination_zone="privileged",
                        ),
                        action=PolicyAction.AUDIT_LOG,
                        severity=RuleSeverity.INFO,
                        message="Cross-boundary access logged",
                    ),
                ],
                is_template=True,
            ),
        )

        # HIPAA Compliance template
        self._templates["hipaa-compliance"] = PolicyTemplate(
            name="hipaa-compliance",
            description="HIPAA-compliant policy for healthcare data",
            use_cases=["Healthcare", "Medical records", "PHI handling"],
            policy=Policy(
                name="hipaa-compliance",
                version="1.0",
                description="HIPAA-compliant security policy",
                extends="default-secure",
                zones=[
                    PolicyZone(
                        name="phi-zone",
                        trust_level=TrustLevelEnum.PRIVILEGED,
                        description="Protected Health Information handlers",
                        allowed_data_types=[
                            DataClassification.PHI,
                            DataClassification.CONFIDENTIAL,
                        ],
                    ),
                ],
                rules=[
                    PolicyRule(
                        name="no-external-phi",
                        condition=RuleCondition(
                            data_type=DataClassification.PHI,
                            destination_zone="external",
                        ),
                        action=PolicyAction.DENY,
                        severity=RuleSeverity.CRITICAL,
                        message="PHI data cannot flow to external systems",
                    ),
                    PolicyRule(
                        name="phi-access-audit",
                        condition=RuleCondition(
                            data_type=DataClassification.PHI,
                        ),
                        action=PolicyAction.AUDIT_LOG,
                        severity=RuleSeverity.HIGH,
                        message="PHI access must be logged",
                    ),
                    PolicyRule(
                        name="phi-encryption-required",
                        condition=RuleCondition(
                            data_type=DataClassification.PHI,
                            destination_zone="internal",
                        ),
                        action=PolicyAction.WARN,
                        severity=RuleSeverity.HIGH,
                        message="PHI must be encrypted in transit",
                    ),
                ],
                is_template=True,
            ),
        )

        # PCI-DSS template
        self._templates["pci-dss"] = PolicyTemplate(
            name="pci-dss",
            description="PCI-DSS compliant policy for payment card data",
            use_cases=["Payment processing", "E-commerce", "Financial"],
            policy=Policy(
                name="pci-dss",
                version="1.0",
                description="PCI-DSS compliant security policy",
                extends="default-secure",
                zones=[
                    PolicyZone(
                        name="cardholder-data",
                        trust_level=TrustLevelEnum.SYSTEM,
                        description="Cardholder data environment",
                        allowed_data_types=[
                            DataClassification.PCI,
                            DataClassification.SECRET,
                        ],
                    ),
                ],
                rules=[
                    PolicyRule(
                        name="no-pan-logging",
                        condition=RuleCondition(
                            data_type=DataClassification.PCI,
                            tool_type="logging",
                        ),
                        action=PolicyAction.DENY,
                        severity=RuleSeverity.CRITICAL,
                        message="Primary Account Numbers must not be logged",
                    ),
                    PolicyRule(
                        name="pci-external-block",
                        condition=RuleCondition(
                            data_type=DataClassification.PCI,
                            destination_zone="external",
                        ),
                        action=PolicyAction.DENY,
                        severity=RuleSeverity.CRITICAL,
                        message="Payment card data cannot flow externally",
                    ),
                    PolicyRule(
                        name="pci-access-approval",
                        condition=RuleCondition(
                            destination_zone="cardholder-data",
                        ),
                        action=PolicyAction.REQUIRE_APPROVAL,
                        severity=RuleSeverity.HIGH,
                        message="Access to cardholder data requires approval",
                    ),
                ],
                is_template=True,
            ),
        )

        # SOC2 template
        self._templates["soc2-ready"] = PolicyTemplate(
            name="soc2-ready",
            description="SOC2 Trust Services Criteria policy",
            use_cases=["SaaS", "Cloud services", "Enterprise"],
            policy=Policy(
                name="soc2-ready",
                version="1.0",
                description="SOC2 Trust Services compliant policy",
                extends="default-secure",
                zones=[
                    PolicyZone(
                        name="customer-data",
                        trust_level=TrustLevelEnum.PRIVILEGED,
                        description="Customer data processing",
                        allowed_data_types=[
                            DataClassification.CONFIDENTIAL,
                            DataClassification.PII,
                        ],
                    ),
                ],
                rules=[
                    PolicyRule(
                        name="pii-protection",
                        condition=RuleCondition(
                            data_type=DataClassification.PII,
                            destination_zone="external",
                        ),
                        action=PolicyAction.DENY,
                        severity=RuleSeverity.CRITICAL,
                        message="PII cannot be sent to external systems",
                    ),
                    PolicyRule(
                        name="confidential-audit",
                        condition=RuleCondition(
                            data_type=DataClassification.CONFIDENTIAL,
                        ),
                        action=PolicyAction.AUDIT_LOG,
                        severity=RuleSeverity.MEDIUM,
                        message="Confidential data access logged",
                    ),
                    PolicyRule(
                        name="customer-data-boundary",
                        condition=RuleCondition(
                            source_zone="external",
                            destination_zone="customer-data",
                        ),
                        action=PolicyAction.REQUIRE_APPROVAL,
                        severity=RuleSeverity.HIGH,
                        message="External access to customer data requires approval",
                    ),
                ],
                is_template=True,
            ),
        )
