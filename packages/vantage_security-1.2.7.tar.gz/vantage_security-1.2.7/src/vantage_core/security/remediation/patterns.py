"""
Remediation Pattern Database (US-134).

Framework-specific fix patterns for common AI agent security vulnerabilities.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from vantage_core.security.models import OWASPCategory, VulnerabilityCategory


class Framework(str, Enum):
    """Supported frameworks for remediation patterns."""

    LANGCHAIN = "langchain"
    CREWAI = "crewai"
    AUTOGEN = "autogen"
    LLAMAINDEX = "llamaindex"
    SEMANTIC_KERNEL = "semantic_kernel"
    GENERIC = "generic"


class RemediationType(str, Enum):
    """Types of remediation approaches."""

    CODE_PATCH = "code_patch"
    CONFIG_CHANGE = "config_change"
    ARCHITECTURE = "architecture"
    INPUT_VALIDATION = "input_validation"
    OUTPUT_FILTERING = "output_filtering"
    ACCESS_CONTROL = "access_control"


@dataclass
class RemediationPattern:
    """
    A remediation pattern for a specific vulnerability type.

    Contains framework-specific fix templates and explanations.
    """

    id: str
    name: str
    vulnerability_category: VulnerabilityCategory
    owasp_category: OWASPCategory
    description: str
    fix_approach: str
    remediation_type: RemediationType
    framework_fixes: dict[str, dict[str, str]]  # framework -> {template, imports, explanation}
    effort_estimate: str  # low, medium, high
    cwe_ids: list[str] = field(default_factory=list)
    references: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


# Top 10 Remediation Patterns Database
REMEDIATION_PATTERNS: dict[str, RemediationPattern] = {
    "prompt_injection": RemediationPattern(
        id="REM-001",
        name="Prompt Injection Prevention",
        vulnerability_category=VulnerabilityCategory.PROMPT_INJECTION,
        owasp_category=OWASPCategory.LLM01,
        description="User input is directly incorporated into prompts without sanitization",
        fix_approach="Use input sanitization, validation, and escape special characters",
        remediation_type=RemediationType.INPUT_VALIDATION,
        effort_estimate="medium",
        cwe_ids=["CWE-77", "CWE-94"],
        references=[
            "https://owasp.org/www-project-top-10-for-large-language-model-applications/",
            "https://llm-attacks.org/",
        ],
        framework_fixes={
            Framework.LANGCHAIN: {
                "template": '''from langchain.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
import re

def sanitize_user_input(user_input: str) -> str:
    """Sanitize user input to prevent prompt injection."""
    # Remove potential injection patterns
    dangerous_patterns = [
        r"ignore\\s+previous\\s+instructions",
        r"system\\s*:",
        r"assistant\\s*:",
        r"\\[\\[.*?\\]\\]",
        r"<\\|.*?\\|>",
    ]
    sanitized = user_input
    for pattern in dangerous_patterns:
        sanitized = re.sub(pattern, "", sanitized, flags=re.IGNORECASE)
    # Escape special characters
    sanitized = sanitized.replace("{", "{{").replace("}", "}}")
    return sanitized.strip()

# Use with PromptTemplate
prompt = PromptTemplate(
    template="Answer the following user question: {sanitized_input}",
    input_variables=["sanitized_input"]
)

# In your chain
sanitized = sanitize_user_input(user_input)
result = prompt | llm | StrOutputParser()''',
                "imports": "from langchain.prompts import PromptTemplate\nimport re",
                "explanation": "Sanitize all user inputs before incorporating into prompts. Use PromptTemplate with escaped variables.",
            },
            Framework.CREWAI: {
                "template": '''from crewai import Agent, Task
import re

def validate_task_description(description: str) -> str:
    """Validate and sanitize task descriptions."""
    # Check for injection attempts
    injection_patterns = [
        r"ignore\\s+your\\s+role",
        r"you\\s+are\\s+now",
        r"new\\s+instructions:",
    ]
    for pattern in injection_patterns:
        if re.search(pattern, description, re.IGNORECASE):
            raise ValueError("Potential prompt injection detected in task description")
    return description

# Create task with validated description
task = Task(
    description=validate_task_description(user_provided_description),
    agent=researcher,
    expected_output="Research findings"
)''',
                "imports": "from crewai import Agent, Task\nimport re",
                "explanation": "Validate task descriptions and agent instructions before execution. Reject inputs containing injection patterns.",
            },
            Framework.AUTOGEN: {
                "template": '''from autogen import AssistantAgent, UserProxyAgent
import re

class SecureUserProxyAgent(UserProxyAgent):
    """User proxy with input validation."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.injection_patterns = [
            r"ignore\\s+system\\s+message",
            r"override\\s+instructions",
            r"\\[SYSTEM\\]",
        ]

    def generate_reply(self, messages, sender, config=None):
        # Validate last user message
        if messages:
            last_message = messages[-1].get("content", "")
            for pattern in self.injection_patterns:
                if re.search(pattern, last_message, re.IGNORECASE):
                    return "I cannot process this request as it contains invalid patterns."
        return super().generate_reply(messages, sender, config)

# Use secure proxy
user_proxy = SecureUserProxyAgent(
    name="user_proxy",
    human_input_mode="NEVER",
    code_execution_config=False
)''',
                "imports": "from autogen import AssistantAgent, UserProxyAgent\nimport re",
                "explanation": "Extend UserProxyAgent to validate inputs before processing. Reject messages with injection patterns.",
            },
            Framework.LLAMAINDEX: {
                "template": '''from llama_index.core import PromptTemplate
from llama_index.core.query_engine import BaseQueryEngine
import re

def create_secure_prompt(user_query: str) -> str:
    """Create a secure prompt with sanitized user input."""
    # Sanitize the query
    sanitized = re.sub(r"[\\x00-\\x1f\\x7f-\\x9f]", "", user_query)
    sanitized = sanitized.replace("ignore previous", "")
    sanitized = sanitized.replace("system:", "")

    return f"Based on the context, answer: {sanitized}"

# Custom prompt template with validation
qa_prompt = PromptTemplate(
    "Context information is below.\\n"
    "---------------------\\n"
    "{context_str}\\n"
    "---------------------\\n"
    "Given the context information, answer the query.\\n"
    "Query: {query_str}\\n"
    "Answer: "
)''',
                "imports": "from llama_index.core import PromptTemplate\nimport re",
                "explanation": "Sanitize queries before passing to query engines. Use structured prompts that separate context from user input.",
            },
            Framework.SEMANTIC_KERNEL: {
                "template": '''from semantic_kernel import Kernel
from semantic_kernel.functions import kernel_function
import re

class InputValidator:
    """Validates and sanitizes inputs for Semantic Kernel."""

    @staticmethod
    def sanitize(text: str) -> str:
        """Remove potential injection patterns."""
        patterns_to_remove = [
            r"<\\|im_start\\|>.*?<\\|im_end\\|>",
            r"\\{\\{.*?\\}\\}",
            r"\\[INST\\].*?\\[/INST\\]",
        ]
        result = text
        for pattern in patterns_to_remove:
            result = re.sub(pattern, "", result, flags=re.DOTALL)
        return result.strip()

@kernel_function(name="secure_query")
async def secure_query(kernel: Kernel, user_input: str) -> str:
    """Process user query with input validation."""
    sanitized_input = InputValidator.sanitize(user_input)
    # Use sanitized input in your function
    return await kernel.invoke("your_function", input=sanitized_input)''',
                "imports": "from semantic_kernel import Kernel\nfrom semantic_kernel.functions import kernel_function\nimport re",
                "explanation": "Create an InputValidator class to sanitize all user inputs. Apply validation in kernel functions before processing.",
            },
        },
    ),
    "excessive_agency": RemediationPattern(
        id="REM-002",
        name="Excessive Agency Control",
        vulnerability_category=VulnerabilityCategory.EXCESSIVE_AGENCY,
        owasp_category=OWASPCategory.LLM08,
        description="Agent has unrestricted access to tools without proper permission checks",
        fix_approach="Implement tool allowlists and permission checks",
        remediation_type=RemediationType.ACCESS_CONTROL,
        effort_estimate="medium",
        cwe_ids=["CWE-269", "CWE-250"],
        references=["https://owasp.org/www-project-top-10-for-large-language-model-applications/"],
        framework_fixes={
            Framework.LANGCHAIN: {
                "template": '''from langchain.tools import tool
from typing import Callable
import functools

ALLOWED_TOOLS = {"search", "calculator", "weather"}
TOOL_PERMISSIONS = {
    "file_write": {"admin"},
    "database_query": {"admin", "analyst"},
    "web_search": {"user", "admin", "analyst"},
}

def require_permission(tool_name: str):
    """Decorator to check tool permissions."""
    def decorator(func: Callable):
        @functools.wraps(func)
        def wrapper(*args, user_role: str = "user", **kwargs):
            allowed_roles = TOOL_PERMISSIONS.get(tool_name, set())
            if user_role not in allowed_roles:
                raise PermissionError(f"Role {user_role} not allowed to use {tool_name}")
            return func(*args, **kwargs)
        return wrapper
    return decorator

@tool
@require_permission("web_search")
def search_tool(query: str, user_role: str = "user") -> str:
    """Search the web with permission check."""
    return f"Results for: {query}"

# Create agent with limited tools
from langchain.agents import AgentExecutor
tools = [t for t in all_tools if t.name in ALLOWED_TOOLS]
agent = AgentExecutor(agent=agent, tools=tools)''',
                "imports": "from langchain.tools import tool\nfrom typing import Callable\nimport functools",
                "explanation": "Use tool allowlists to restrict which tools agents can access. Implement permission decorators for sensitive operations.",
            },
            Framework.CREWAI: {
                "template": '''from crewai import Agent, Task
from crewai.tools import BaseTool
from typing import Any

class PermissionCheckedTool(BaseTool):
    """Base class for tools with permission checks."""
    name: str = "protected_tool"
    description: str = "A tool with permission checks"
    required_permission: str = "basic"

    def _run(self, *args, **kwargs) -> Any:
        # Permission check happens in crew execution
        return self._execute(*args, **kwargs)

    def _execute(self, *args, **kwargs) -> Any:
        raise NotImplementedError

# Restrict delegation
researcher = Agent(
    role="Researcher",
    goal="Research topics",
    backstory="...",
    allow_delegation=False,  # Disable delegation
    tools=[search_tool],  # Limited tool set
    verbose=True
)

# Define explicit task boundaries
task = Task(
    description="Research AI safety",
    agent=researcher,
    expected_output="Summary report",
    # Don't allow dynamic tool discovery
)''',
                "imports": "from crewai import Agent, Task\nfrom crewai.tools import BaseTool",
                "explanation": "Disable delegation for agents that don't need it. Use explicit tool assignments rather than dynamic tool discovery.",
            },
            Framework.AUTOGEN: {
                "template": '''from autogen import AssistantAgent, UserProxyAgent
from typing import Dict, List

# Restrict code execution
user_proxy = UserProxyAgent(
    name="user_proxy",
    human_input_mode="NEVER",
    code_execution_config={
        "work_dir": "/tmp/sandboxed",
        "use_docker": True,  # Isolate code execution
        "timeout": 60,
        "last_n_messages": 1,  # Limit context
    },
    max_consecutive_auto_reply=3,  # Limit auto-replies
)

# Define allowed functions explicitly
def allowed_function_map() -> Dict:
    """Return only approved functions."""
    return {
        "search": search_function,
        "calculate": calculate_function,
        # Explicitly exclude dangerous functions
    }

assistant = AssistantAgent(
    name="assistant",
    llm_config={
        "config_list": config_list,
        "functions": allowed_function_map(),
    },
    system_message="You can only use the provided functions. Do not attempt to execute arbitrary code."
)''',
                "imports": "from autogen import AssistantAgent, UserProxyAgent\nfrom typing import Dict, List",
                "explanation": "Use Docker for code execution isolation. Explicitly define allowed functions and limit auto-reply chains.",
            },
            Framework.LLAMAINDEX: {
                "template": '''from llama_index.core.tools import FunctionTool, ToolMetadata
from llama_index.core.agent import ReActAgent
from typing import List

class ToolRegistry:
    """Manages approved tools with permission levels."""

    def __init__(self):
        self._tools: Dict[str, FunctionTool] = {}
        self._permissions: Dict[str, str] = {}

    def register(self, tool: FunctionTool, permission: str = "basic"):
        self._tools[tool.metadata.name] = tool
        self._permissions[tool.metadata.name] = permission

    def get_tools_for_permission(self, permission: str) -> List[FunctionTool]:
        """Get tools available for a permission level."""
        allowed = []
        permission_hierarchy = ["basic", "standard", "admin"]
        user_level = permission_hierarchy.index(permission)
        for name, tool in self._tools.items():
            tool_level = permission_hierarchy.index(self._permissions[name])
            if tool_level <= user_level:
                allowed.append(tool)
        return allowed

# Create agent with restricted tools
registry = ToolRegistry()
registry.register(search_tool, "basic")
registry.register(db_tool, "admin")

tools = registry.get_tools_for_permission(user_permission)
agent = ReActAgent.from_tools(tools, llm=llm, verbose=True)''',
                "imports": "from llama_index.core.tools import FunctionTool, ToolMetadata\nfrom llama_index.core.agent import ReActAgent",
                "explanation": "Use a ToolRegistry to manage tool permissions. Only provide tools appropriate for the user's permission level.",
            },
            Framework.SEMANTIC_KERNEL: {
                "template": '''from semantic_kernel import Kernel
from semantic_kernel.functions import kernel_function
from semantic_kernel.filters import FunctionInvocationContext

class PermissionFilter:
    """Filter to check permissions before function execution."""

    def __init__(self, user_permissions: set):
        self.user_permissions = user_permissions

    async def on_function_invocation(
        self,
        context: FunctionInvocationContext,
        next_handler
    ):
        # Check if function requires permission
        required = context.function.metadata.get("required_permission")
        if required and required not in self.user_permissions:
            raise PermissionError(
                f"Permission {required} required for {context.function.name}"
            )
        return await next_handler(context)

# Register filter
kernel = Kernel()
kernel.add_filter("function_invocation", PermissionFilter({"read", "write"}))

# Mark functions with required permissions
@kernel_function(name="delete_file")
async def delete_file(path: str) -> str:
    """Delete a file (requires admin permission)."""
    # Metadata set separately
    pass

# Set metadata
kernel.get_function("delete_file").metadata["required_permission"] = "admin"''',
                "imports": "from semantic_kernel import Kernel\nfrom semantic_kernel.functions import kernel_function\nfrom semantic_kernel.filters import FunctionInvocationContext",
                "explanation": "Use Semantic Kernel filters to check permissions before function invocation. Tag functions with required permissions.",
            },
        },
    ),
    "data_leakage": RemediationPattern(
        id="REM-003",
        name="Data Leakage Prevention",
        vulnerability_category=VulnerabilityCategory.DATA_LEAKAGE,
        owasp_category=OWASPCategory.LLM06,
        description="Sensitive information may be exposed in agent outputs or logs",
        fix_approach="Implement output filtering and data masking",
        remediation_type=RemediationType.OUTPUT_FILTERING,
        effort_estimate="medium",
        cwe_ids=["CWE-200", "CWE-532"],
        references=["https://owasp.org/www-project-top-10-for-large-language-model-applications/"],
        framework_fixes={
            Framework.LANGCHAIN: {
                "template": '''from langchain.callbacks.base import BaseCallbackHandler
from langchain_core.outputs import LLMResult
import re

class OutputSanitizer(BaseCallbackHandler):
    """Callback to sanitize LLM outputs."""

    PII_PATTERNS = {
        "email": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}",
        "ssn": r"\\b\\d{3}-\\d{2}-\\d{4}\\b",
        "credit_card": r"\\b\\d{4}[- ]?\\d{4}[- ]?\\d{4}[- ]?\\d{4}\\b",
        "phone": r"\\b\\d{3}[-.\\s]?\\d{3}[-.\\s]?\\d{4}\\b",
    }

    def on_llm_end(self, response: LLMResult, **kwargs):
        for generation in response.generations:
            for gen in generation:
                gen.text = self._mask_pii(gen.text)

    def _mask_pii(self, text: str) -> str:
        """Mask PII in text."""
        for pii_type, pattern in self.PII_PATTERNS.items():
            text = re.sub(pattern, f"[{pii_type.upper()}_REDACTED]", text)
        return text

# Use sanitizer in chain
from langchain_openai import ChatOpenAI
llm = ChatOpenAI(callbacks=[OutputSanitizer()])''',
                "imports": "from langchain.callbacks.base import BaseCallbackHandler\nfrom langchain_core.outputs import LLMResult\nimport re",
                "explanation": "Use LangChain callbacks to intercept and sanitize outputs. Mask PII patterns before returning results.",
            },
            Framework.CREWAI: {
                "template": '''from crewai import Agent, Task, Crew
import re
from typing import Any

class SecureTask(Task):
    """Task with output sanitization."""

    PII_PATTERNS = {
        "email": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}",
        "ssn": r"\\b\\d{3}-\\d{2}-\\d{4}\\b",
    }

    def execute(self, context: Any = None) -> str:
        result = super().execute(context)
        return self._sanitize_output(result)

    def _sanitize_output(self, text: str) -> str:
        """Remove sensitive data from output."""
        for pii_type, pattern in self.PII_PATTERNS.items():
            text = re.sub(pattern, f"[{pii_type.upper()}_REDACTED]", text)
        return text

# Use secure tasks
task = SecureTask(
    description="Analyze customer data",
    agent=analyst,
    expected_output="Analysis without PII"
)''',
                "imports": "from crewai import Agent, Task, Crew\nimport re",
                "explanation": "Create a SecureTask class that sanitizes outputs. Override the execute method to filter results before returning.",
            },
            Framework.AUTOGEN: {
                "template": '''from autogen import AssistantAgent
import re
from typing import Dict, List, Optional

class SecureAssistantAgent(AssistantAgent):
    """Assistant agent with output sanitization."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.sensitive_patterns = [
            (r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}", "[EMAIL]"),
            (r"\\b\\d{3}-\\d{2}-\\d{4}\\b", "[SSN]"),
            (r"password\\s*[:=]\\s*\\S+", "[PASSWORD_REDACTED]"),
        ]

    def generate_reply(
        self,
        messages: Optional[List[Dict]] = None,
        sender: Optional["Agent"] = None,
        **kwargs
    ):
        reply = super().generate_reply(messages, sender, **kwargs)
        if isinstance(reply, str):
            reply = self._sanitize(reply)
        elif isinstance(reply, dict) and "content" in reply:
            reply["content"] = self._sanitize(reply["content"])
        return reply

    def _sanitize(self, text: str) -> str:
        for pattern, replacement in self.sensitive_patterns:
            text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
        return text

assistant = SecureAssistantAgent(name="secure_assistant", llm_config=llm_config)''',
                "imports": "from autogen import AssistantAgent\nimport re\nfrom typing import Dict, List, Optional",
                "explanation": "Extend AssistantAgent to sanitize all outputs. Override generate_reply to filter sensitive data before returning.",
            },
            Framework.LLAMAINDEX: {
                "template": '''from llama_index.core.postprocessor import BaseNodePostprocessor
from llama_index.core.schema import NodeWithScore
import re
from typing import List, Optional

class PIIMaskingPostprocessor(BaseNodePostprocessor):
    """Postprocessor to mask PII in retrieved nodes."""

    def __init__(self):
        self.patterns = [
            (r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}", "[EMAIL]"),
            (r"\\b\\d{3}-\\d{2}-\\d{4}\\b", "[SSN]"),
        ]

    def _postprocess_nodes(
        self,
        nodes: List[NodeWithScore],
        query_bundle: Optional[QueryBundle] = None,
    ) -> List[NodeWithScore]:
        for node in nodes:
            text = node.node.get_content()
            for pattern, replacement in self.patterns:
                text = re.sub(pattern, replacement, text)
            node.node.set_content(text)
        return nodes

# Use in query engine
query_engine = index.as_query_engine(
    node_postprocessors=[PIIMaskingPostprocessor()]
)''',
                "imports": "from llama_index.core.postprocessor import BaseNodePostprocessor\nfrom llama_index.core.schema import NodeWithScore\nimport re",
                "explanation": "Use node postprocessors to filter sensitive data from retrieved content before it reaches the LLM.",
            },
            Framework.SEMANTIC_KERNEL: {
                "template": '''from semantic_kernel import Kernel
from semantic_kernel.filters import FunctionInvocationContext
import re

class OutputSanitizationFilter:
    """Filter to sanitize function outputs."""

    PATTERNS = [
        (r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}", "[EMAIL]"),
        (r"\\b\\d{3}-\\d{2}-\\d{4}\\b", "[SSN]"),
    ]

    async def on_function_invocation(
        self,
        context: FunctionInvocationContext,
        next_handler
    ):
        result = await next_handler(context)
        if isinstance(result, str):
            for pattern, replacement in self.PATTERNS:
                result = re.sub(pattern, replacement, result)
        return result

kernel = Kernel()
kernel.add_filter("function_invocation", OutputSanitizationFilter())''',
                "imports": "from semantic_kernel import Kernel\nfrom semantic_kernel.filters import FunctionInvocationContext\nimport re",
                "explanation": "Use function invocation filters to sanitize outputs. Filter runs after function execution to mask sensitive data.",
            },
        },
    ),
    "trust_boundary_violation": RemediationPattern(
        id="REM-004",
        name="Trust Boundary Enforcement",
        vulnerability_category=VulnerabilityCategory.TRUST_BOUNDARY_VIOLATION,
        owasp_category=OWASPCategory.LLM07,
        description="Agents can access resources beyond their trust level",
        fix_approach="Implement trust zones and boundary checks",
        remediation_type=RemediationType.ARCHITECTURE,
        effort_estimate="high",
        cwe_ids=["CWE-284", "CWE-863"],
        framework_fixes={
            Framework.LANGCHAIN: {
                "template": '''from langchain.agents import AgentExecutor
from enum import IntEnum
from typing import Any

class TrustLevel(IntEnum):
    EXTERNAL = 0
    USER = 1
    INTERNAL = 2
    PRIVILEGED = 3
    SYSTEM = 4

class TrustBoundaryAgent:
    """Agent with trust boundary enforcement."""

    def __init__(self, agent: AgentExecutor, trust_level: TrustLevel):
        self.agent = agent
        self.trust_level = trust_level
        self.tool_trust_requirements = {}

    def set_tool_trust(self, tool_name: str, required_level: TrustLevel):
        self.tool_trust_requirements[tool_name] = required_level

    def invoke(self, input_data: dict, input_trust: TrustLevel) -> Any:
        # Validate input trust level
        if input_trust > self.trust_level:
            raise ValueError(
                f"Input trust {input_trust} exceeds agent trust {self.trust_level}"
            )

        # Filter tools based on trust level
        available_tools = [
            t for t in self.agent.tools
            if self.tool_trust_requirements.get(t.name, TrustLevel.EXTERNAL) <= self.trust_level
        ]

        # Execute with filtered tools
        self.agent.tools = available_tools
        return self.agent.invoke(input_data)

# Usage
agent = TrustBoundaryAgent(agent_executor, TrustLevel.USER)
agent.set_tool_trust("file_write", TrustLevel.PRIVILEGED)''',
                "imports": "from langchain.agents import AgentExecutor\nfrom enum import IntEnum",
                "explanation": "Wrap agents with trust boundary enforcement. Filter available tools based on trust levels at runtime.",
            },
            Framework.CREWAI: {
                "template": '''from crewai import Agent, Crew, Task
from enum import IntEnum
from typing import List

class TrustLevel(IntEnum):
    EXTERNAL = 0
    USER = 1
    INTERNAL = 2
    PRIVILEGED = 3
    SYSTEM = 4

class TrustZone:
    """A collection of agents at the same trust level."""

    def __init__(self, name: str, trust_level: TrustLevel):
        self.name = name
        self.trust_level = trust_level
        self.agents: List[Agent] = []

    def add_agent(self, agent: Agent):
        self.agents.append(agent)

    def can_communicate_with(self, other_zone: "TrustZone") -> bool:
        # Only allow communication to same or lower trust
        return self.trust_level >= other_zone.trust_level

# Define trust zones
external_zone = TrustZone("external", TrustLevel.EXTERNAL)
processing_zone = TrustZone("processing", TrustLevel.INTERNAL)
privileged_zone = TrustZone("privileged", TrustLevel.PRIVILEGED)

# Assign agents to zones
external_zone.add_agent(user_interface_agent)
processing_zone.add_agent(analyzer_agent)
privileged_zone.add_agent(admin_agent)

# Validate communication before crew execution
def validate_crew_trust(crew: Crew, zones: List[TrustZone]):
    for task in crew.tasks:
        agent_zone = next(z for z in zones if task.agent in z.agents)
        # Check delegations respect trust boundaries
        if task.agent.allow_delegation:
            for other_agent in crew.agents:
                other_zone = next(z for z in zones if other_agent in z.agents)
                if not agent_zone.can_communicate_with(other_zone):
                    raise ValueError(f"Trust violation: {agent_zone.name} -> {other_zone.name}")''',
                "imports": "from crewai import Agent, Crew, Task\nfrom enum import IntEnum\nfrom typing import List",
                "explanation": "Define trust zones and assign agents. Validate crew communications respect trust boundaries before execution.",
            },
            Framework.GENERIC: {
                "template": '''from enum import IntEnum
from typing import Any, Dict
from dataclasses import dataclass

class TrustLevel(IntEnum):
    EXTERNAL = 0
    USER = 1
    INTERNAL = 2
    PRIVILEGED = 3
    SYSTEM = 4

@dataclass
class Message:
    """Message with trust metadata."""
    content: Any
    source_trust: TrustLevel
    target_trust: TrustLevel

class TrustBoundaryValidator:
    """Validates messages crossing trust boundaries."""

    def __init__(self):
        self.allowed_crossings: Dict[TrustLevel, set] = {
            TrustLevel.EXTERNAL: {TrustLevel.USER},
            TrustLevel.USER: {TrustLevel.INTERNAL},
            TrustLevel.INTERNAL: {TrustLevel.PRIVILEGED},
            TrustLevel.PRIVILEGED: {TrustLevel.SYSTEM},
        }

    def validate(self, message: Message) -> bool:
        # Same level always allowed
        if message.source_trust == message.target_trust:
            return True

        # Check if crossing is allowed
        allowed = self.allowed_crossings.get(message.source_trust, set())
        if message.target_trust in allowed:
            return True

        # Downward communication always allowed
        if message.source_trust > message.target_trust:
            return True

        return False

validator = TrustBoundaryValidator()''',
                "imports": "from enum import IntEnum\nfrom typing import Any, Dict\nfrom dataclasses import dataclass",
                "explanation": "Implement a generic trust boundary validator that checks message crossings against allowed patterns.",
            },
        },
    ),
    "insecure_tool_use": RemediationPattern(
        id="REM-005",
        name="Secure Tool Configuration",
        vulnerability_category=VulnerabilityCategory.INSECURE_TOOL_USE,
        owasp_category=OWASPCategory.LLM07,
        description="Tools are configured without proper security controls",
        fix_approach="Add input validation and output sanitization to tools",
        remediation_type=RemediationType.CODE_PATCH,
        effort_estimate="low",
        cwe_ids=["CWE-20", "CWE-116"],
        framework_fixes={
            Framework.LANGCHAIN: {
                "template": '''from langchain.tools import tool
from pydantic import BaseModel, Field, validator
from typing import Any

class SecureToolInput(BaseModel):
    """Validated input for secure tool."""
    query: str = Field(..., min_length=1, max_length=1000)

    @validator("query")
    def no_injection(cls, v):
        dangerous = ["DROP", "DELETE", "UPDATE", "--", ";"]
        for pattern in dangerous:
            if pattern.upper() in v.upper():
                raise ValueError(f"Dangerous pattern detected: {pattern}")
        return v

@tool(args_schema=SecureToolInput)
def secure_search(query: str) -> str:
    """Search with validated input."""
    # Tool implementation
    return f"Results for: {query}"''',
                "imports": "from langchain.tools import tool\nfrom pydantic import BaseModel, Field, validator",
                "explanation": "Use Pydantic schemas for tool inputs with validators. Reject inputs containing dangerous patterns.",
            },
            Framework.GENERIC: {
                "template": '''from typing import Any, Callable
import functools

def secure_tool(
    max_input_length: int = 1000,
    allowed_chars: str = None,
    blocked_patterns: list = None
):
    """Decorator to add security checks to tools."""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Validate all string arguments
            for arg in args:
                if isinstance(arg, str):
                    validate_input(arg, max_input_length, allowed_chars, blocked_patterns)
            for value in kwargs.values():
                if isinstance(value, str):
                    validate_input(value, max_input_length, allowed_chars, blocked_patterns)
            return func(*args, **kwargs)
        return wrapper
    return decorator

def validate_input(
    value: str,
    max_length: int,
    allowed_chars: str,
    blocked_patterns: list
):
    if len(value) > max_length:
        raise ValueError(f"Input exceeds max length of {max_length}")
    if blocked_patterns:
        for pattern in blocked_patterns:
            if pattern.lower() in value.lower():
                raise ValueError(f"Blocked pattern: {pattern}")

@secure_tool(blocked_patterns=["DROP", "DELETE", "script"])
def database_query(query: str) -> str:
    return f"Query result: {query}"''',
                "imports": "from typing import Any, Callable\nimport functools",
                "explanation": "Create a secure_tool decorator that validates all inputs before execution.",
            },
        },
    ),
    "unsafe_delegation": RemediationPattern(
        id="REM-006",
        name="Safe Delegation Patterns",
        vulnerability_category=VulnerabilityCategory.UNSAFE_DELEGATION,
        owasp_category=OWASPCategory.LLM08,
        description="Agents can delegate tasks without proper authorization checks",
        fix_approach="Implement delegation guards and approval workflows",
        remediation_type=RemediationType.ARCHITECTURE,
        effort_estimate="medium",
        cwe_ids=["CWE-269", "CWE-863"],
        framework_fixes={
            Framework.CREWAI: {
                "template": '''from crewai import Agent, Task
from typing import Optional

class DelegationGuard:
    """Guards delegation between agents."""

    def __init__(self):
        self.allowed_delegations = {}  # source -> [targets]

    def allow(self, source: str, target: str):
        if source not in self.allowed_delegations:
            self.allowed_delegations[source] = []
        self.allowed_delegations[source].append(target)

    def can_delegate(self, source: str, target: str) -> bool:
        return target in self.allowed_delegations.get(source, [])

guard = DelegationGuard()
guard.allow("manager", "researcher")
guard.allow("manager", "writer")
# researcher cannot delegate

# Create agents with controlled delegation
manager = Agent(
    role="Manager",
    goal="Coordinate tasks",
    backstory="...",
    allow_delegation=True,
    verbose=True
)

researcher = Agent(
    role="Researcher",
    goal="Research topics",
    backstory="...",
    allow_delegation=False,  # Cannot delegate
    verbose=True
)''',
                "imports": "from crewai import Agent, Task\nfrom typing import Optional",
                "explanation": "Use a DelegationGuard to explicitly control which agents can delegate to whom. Disable delegation by default.",
            },
            Framework.AUTOGEN: {
                "template": '''from autogen import GroupChat, GroupChatManager
from typing import List, Dict

class ControlledGroupChat(GroupChat):
    """GroupChat with delegation controls."""

    def __init__(self, *args, allowed_transitions: Dict[str, List[str]] = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.allowed_transitions = allowed_transitions or {}

    def select_speaker(self, last_speaker, selector):
        # Get next speaker from parent
        next_speaker = super().select_speaker(last_speaker, selector)

        # Validate transition
        if last_speaker and next_speaker:
            allowed = self.allowed_transitions.get(last_speaker.name, [])
            if next_speaker.name not in allowed and "*" not in allowed:
                # Fall back to manager
                next_speaker = self.admin

        return next_speaker

# Define allowed transitions
transitions = {
    "user_proxy": ["assistant", "researcher"],
    "assistant": ["researcher", "user_proxy"],
    "researcher": ["assistant"],  # Cannot talk to user directly
}

group_chat = ControlledGroupChat(
    agents=[user_proxy, assistant, researcher],
    messages=[],
    max_round=10,
    allowed_transitions=transitions
)''',
                "imports": "from autogen import GroupChat, GroupChatManager\nfrom typing import List, Dict",
                "explanation": "Extend GroupChat to control speaker transitions. Define allowed communication paths explicitly.",
            },
        },
    ),
    "code_execution": RemediationPattern(
        id="REM-007",
        name="Safe Code Execution",
        vulnerability_category=VulnerabilityCategory.CODE_EXECUTION,
        owasp_category=OWASPCategory.LLM07,
        description="Agent can execute arbitrary code without sandboxing",
        fix_approach="Use containerized execution with resource limits",
        remediation_type=RemediationType.CONFIG_CHANGE,
        effort_estimate="high",
        cwe_ids=["CWE-94", "CWE-78"],
        framework_fixes={
            Framework.AUTOGEN: {
                "template": """from autogen import UserProxyAgent

# Secure code execution configuration
secure_code_config = {
    "work_dir": "/tmp/sandbox",
    "use_docker": True,
    "timeout": 60,  # Maximum execution time
    "last_n_messages": 3,  # Limit code context
    "docker_image_name": "python:3.11-slim",  # Minimal image
}

user_proxy = UserProxyAgent(
    name="user_proxy",
    human_input_mode="TERMINATE",  # Require approval
    max_consecutive_auto_reply=2,
    code_execution_config=secure_code_config,
    is_termination_msg=lambda x: "TERMINATE" in x.get("content", ""),
)

# Alternative: Disable code execution entirely
no_code_proxy = UserProxyAgent(
    name="no_code_proxy",
    human_input_mode="NEVER",
    code_execution_config=False,  # No code execution
)""",
                "imports": "from autogen import UserProxyAgent",
                "explanation": "Always use Docker for code execution. Set timeouts and limit the number of messages used for context.",
            },
            Framework.GENERIC: {
                "template": '''import subprocess
import resource
import tempfile
import os
from typing import Tuple

class SecureExecutor:
    """Execute code with security restrictions."""

    def __init__(
        self,
        timeout: int = 30,
        max_memory_mb: int = 256,
        max_file_size_mb: int = 10
    ):
        self.timeout = timeout
        self.max_memory = max_memory_mb * 1024 * 1024
        self.max_file_size = max_file_size_mb * 1024 * 1024

    def execute(self, code: str) -> Tuple[str, str, int]:
        """Execute code in a restricted environment."""
        with tempfile.TemporaryDirectory() as tmpdir:
            script_path = os.path.join(tmpdir, "script.py")
            with open(script_path, "w") as f:
                f.write(code)

            try:
                result = subprocess.run(
                    ["python", script_path],
                    capture_output=True,
                    text=True,
                    timeout=self.timeout,
                    cwd=tmpdir,
                    env={"PATH": "/usr/bin:/bin"},  # Minimal PATH
                )
                return result.stdout, result.stderr, result.returncode
            except subprocess.TimeoutExpired:
                return "", "Execution timed out", 1

executor = SecureExecutor(timeout=30, max_memory_mb=128)''',
                "imports": "import subprocess\nimport resource\nimport tempfile\nimport os\nfrom typing import Tuple",
                "explanation": "Execute code in isolated temporary directories with timeouts and resource limits.",
            },
        },
    ),
    "unsafe_eval_exec": RemediationPattern(
        id="REM-011",
        name="Safe Alternatives to eval/exec",
        vulnerability_category=VulnerabilityCategory.CODE_EXECUTION,
        owasp_category=OWASPCategory.LLM07,
        description="Dynamic code execution via eval() or exec() with untrusted input",
        fix_approach="Replace eval/exec with safe alternatives like ast.literal_eval or structured parsers",
        remediation_type=RemediationType.CODE_PATCH,
        effort_estimate="medium",
        cwe_ids=["CWE-94", "CWE-95"],
        references=[
            "https://docs.python.org/3/library/ast.html#ast.literal_eval",
            "https://owasp.org/www-community/attacks/Code_Injection",
        ],
        framework_fixes={
            Framework.GENERIC: {
                "template": '''import ast
import operator
from typing import Any, Dict

# UNSAFE - DO NOT USE
# result = eval(user_input)

# SAFE Alternative 1: ast.literal_eval for simple literals
def safe_eval_literal(expression: str) -> Any:
    """
    Safely evaluate a string containing a Python literal.
    Only allows: strings, bytes, numbers, tuples, lists, dicts, sets, booleans, None.
    """
    try:
        return ast.literal_eval(expression)
    except (ValueError, SyntaxError) as e:
        raise ValueError(f"Invalid literal expression: {e}")

# SAFE Alternative 2: Structured calculator for math expressions
class SafeCalculator:
    """Safe calculator that only allows math operations."""

    OPERATORS = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.Pow: operator.pow,
        ast.USub: operator.neg,
        ast.Mod: operator.mod,
    }

    def calculate(self, expression: str) -> float:
        """Safely evaluate a mathematical expression."""
        try:
            tree = ast.parse(expression, mode='eval')
            return self._eval_node(tree.body)
        except (ValueError, TypeError, SyntaxError) as e:
            raise ValueError(f"Invalid expression: {e}")

    def _eval_node(self, node: ast.AST) -> float:
        if isinstance(node, ast.Num):  # Python 3.7
            return node.n
        elif isinstance(node, ast.Constant):  # Python 3.8+
            if isinstance(node.value, (int, float)):
                return node.value
            raise ValueError(f"Unsupported constant: {node.value}")
        elif isinstance(node, ast.BinOp):
            left = self._eval_node(node.left)
            right = self._eval_node(node.right)
            op_func = self.OPERATORS.get(type(node.op))
            if op_func is None:
                raise ValueError(f"Unsupported operator: {type(node.op)}")
            return op_func(left, right)
        elif isinstance(node, ast.UnaryOp):
            operand = self._eval_node(node.operand)
            op_func = self.OPERATORS.get(type(node.op))
            if op_func is None:
                raise ValueError(f"Unsupported operator: {type(node.op)}")
            return op_func(operand)
        else:
            raise ValueError(f"Unsupported node type: {type(node)}")

# SAFE Alternative 3: Allowlist-based function executor
class SafeFunctionExecutor:
    """Execute only pre-approved functions."""

    def __init__(self):
        self.allowed_functions: Dict[str, callable] = {}

    def register(self, name: str, func: callable):
        self.allowed_functions[name] = func

    def execute(self, func_name: str, *args, **kwargs) -> Any:
        if func_name not in self.allowed_functions:
            raise ValueError(f"Function {func_name} not allowed")
        return self.allowed_functions[func_name](*args, **kwargs)

# Usage examples
calc = SafeCalculator()
result = calc.calculate("2 + 3 * 4")  # Returns 14.0

# Register safe functions
executor = SafeFunctionExecutor()
executor.register("uppercase", str.upper)
executor.register("sum", sum)
result = executor.execute("uppercase", "hello")  # Returns "HELLO"''',
                "imports": "import ast\nimport operator\nfrom typing import Any, Dict",
                "explanation": "Replace eval() with ast.literal_eval() for literals, SafeCalculator for math, or SafeFunctionExecutor for controlled function calls.",
            },
            Framework.LANGCHAIN: {
                "template": '''from langchain.tools import tool
from langchain_experimental.utilities import PythonREPL
import ast

# UNSAFE - DO NOT USE
# @tool
# def execute_code(code: str) -> str:
#     return eval(code)

# SAFE Alternative 1: Use LangChain's sandboxed REPL
repl = PythonREPL()

@tool
def safe_python_tool(code: str) -> str:
    """Execute Python code in a sandboxed environment."""
    # Validate code doesn't contain dangerous patterns
    dangerous_patterns = ["import os", "import subprocess", "open(", "__import__"]
    for pattern in dangerous_patterns:
        if pattern in code:
            return f"Error: Dangerous pattern detected: {pattern}"

    try:
        result = repl.run(code)
        return result[:1000]  # Limit output
    except Exception as e:
        return f"Error: {str(e)}"

# SAFE Alternative 2: Math-only tool
@tool
def calculator_tool(expression: str) -> str:
    """Calculate mathematical expressions safely."""
    import ast
    import operator

    ops = {
        ast.Add: operator.add, ast.Sub: operator.sub,
        ast.Mult: operator.mul, ast.Div: operator.truediv,
    }

    def eval_node(node):
        if isinstance(node, ast.Constant):
            return node.value
        elif isinstance(node, ast.BinOp):
            return ops[type(node.op)](eval_node(node.left), eval_node(node.right))
        raise ValueError("Invalid expression")

    try:
        tree = ast.parse(expression, mode='eval')
        return str(eval_node(tree.body))
    except Exception as e:
        return f"Error: {str(e)}"''',
                "imports": "from langchain.tools import tool\nfrom langchain_experimental.utilities import PythonREPL\nimport ast",
                "explanation": "Use LangChain's sandboxed PythonREPL with input validation, or create math-only tools with ast parsing.",
            },
            Framework.AUTOGEN: {
                "template": '''from autogen import UserProxyAgent
import ast

# UNSAFE configuration - DO NOT USE
# user_proxy = UserProxyAgent(
#     name="user_proxy",
#     code_execution_config={"use_docker": False}
# )

# SAFE Alternative 1: Docker-isolated execution
user_proxy = UserProxyAgent(
    name="user_proxy",
    human_input_mode="NEVER",
    code_execution_config={
        "work_dir": "/tmp/sandbox",
        "use_docker": True,  # ALWAYS use Docker
        "timeout": 60,
        "last_n_messages": 1,
    },
)

# SAFE Alternative 2: No code execution, function-based
def safe_math(expression: str) -> dict:
    """Safely evaluate math expressions."""
    import operator
    ops = {ast.Add: operator.add, ast.Sub: operator.sub,
           ast.Mult: operator.mul, ast.Div: operator.truediv}

    def eval_node(node):
        if isinstance(node, ast.Constant):
            if not isinstance(node.value, (int, float)):
                raise ValueError("Only numeric values allowed")
            return node.value
        elif isinstance(node, ast.BinOp):
            return ops[type(node.op)](eval_node(node.left), eval_node(node.right))
        raise ValueError("Invalid expression")

    try:
        tree = ast.parse(expression, mode='eval')
        result = eval_node(tree.body)
        return {"result": result, "status": "success"}
    except Exception as e:
        return {"error": str(e), "status": "failed"}

# Register as function for assistant
assistant = AssistantAgent(
    name="assistant",
    llm_config={
        "functions": [
            {
                "name": "safe_math",
                "description": "Safely evaluate mathematical expressions",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "expression": {"type": "string", "description": "Math expression"}
                    },
                    "required": ["expression"]
                }
            }
        ]
    }
)''',
                "imports": "from autogen import UserProxyAgent, AssistantAgent\nimport ast",
                "explanation": "Always use Docker for code execution in AutoGen. Alternatively, use registered functions with safe evaluation.",
            },
        },
    ),
    "hardcoded_secret": RemediationPattern(
        id="REM-008",
        name="Secret Management",
        vulnerability_category=VulnerabilityCategory.HARDCODED_SECRET,
        owasp_category=OWASPCategory.LLM06,
        description="API keys or credentials are hardcoded in the source",
        fix_approach="Use environment variables or secret management services",
        remediation_type=RemediationType.CONFIG_CHANGE,
        effort_estimate="low",
        cwe_ids=["CWE-798", "CWE-259"],
        framework_fixes={
            Framework.GENERIC: {
                "template": '''import os
from typing import Optional

class SecretManager:
    """Manage secrets securely."""

    @staticmethod
    def get_secret(name: str, default: Optional[str] = None) -> str:
        """Get secret from environment variable."""
        value = os.environ.get(name, default)
        if value is None:
            raise ValueError(f"Required secret {name} not found in environment")
        return value

# Usage
api_key = SecretManager.get_secret("OPENAI_API_KEY")

# With .env file support
from dotenv import load_dotenv
load_dotenv()  # Load from .env file

# Configuration class
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    openai_api_key: str
    database_url: str
    secret_key: str

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

settings = Settings()''',
                "imports": "import os\nfrom typing import Optional",
                "explanation": "Use environment variables for all secrets. Consider using pydantic-settings for configuration management.",
            },
        },
    ),
    "configuration_weakness": RemediationPattern(
        id="REM-009",
        name="Secure Configuration",
        vulnerability_category=VulnerabilityCategory.CONFIGURATION_WEAKNESS,
        owasp_category=OWASPCategory.LLM09,
        description="Agent is configured with insecure defaults",
        fix_approach="Apply security hardening to configurations",
        remediation_type=RemediationType.CONFIG_CHANGE,
        effort_estimate="low",
        cwe_ids=["CWE-16", "CWE-1188"],
        framework_fixes={
            Framework.LANGCHAIN: {
                "template": """from langchain_openai import ChatOpenAI
from langchain.callbacks import get_openai_callback

# Secure LLM configuration
llm = ChatOpenAI(
    model="gpt-4",
    temperature=0,  # Deterministic outputs
    max_tokens=2000,  # Limit output length
    request_timeout=30,  # Prevent hanging
    max_retries=2,  # Limit retries
)

# Monitor token usage
with get_openai_callback() as cb:
    response = llm.invoke("Your prompt")
    if cb.total_tokens > 10000:
        raise ValueError("Token limit exceeded")""",
                "imports": "from langchain_openai import ChatOpenAI\nfrom langchain.callbacks import get_openai_callback",
                "explanation": "Set temperature to 0 for deterministic outputs. Limit tokens and set timeouts to prevent abuse.",
            },
            Framework.AUTOGEN: {
                "template": """from autogen import AssistantAgent

# Secure assistant configuration
assistant = AssistantAgent(
    name="assistant",
    system_message="You are a helpful assistant. Do not execute code or access external resources.",
    llm_config={
        "config_list": config_list,
        "temperature": 0,
        "timeout": 60,
        "cache_seed": None,  # Disable caching in production
    },
    max_consecutive_auto_reply=3,  # Limit chain length
)

# Secure group chat
from autogen import GroupChat, GroupChatManager

group_chat = GroupChat(
    agents=[assistant, user],
    messages=[],
    max_round=10,  # Limit conversation length
    allow_repeat_speaker=False,  # Prevent loops
)""",
                "imports": "from autogen import AssistantAgent",
                "explanation": "Limit auto-replies and conversation rounds. Set explicit timeouts and disable caching in production.",
            },
        },
    ),
    "privilege_escalation": RemediationPattern(
        id="REM-010",
        name="Privilege Escalation Prevention",
        vulnerability_category=VulnerabilityCategory.PRIVILEGE_ESCALATION,
        owasp_category=OWASPCategory.LLM08,
        description="Agent can gain elevated privileges through tool chains",
        fix_approach="Implement principle of least privilege",
        remediation_type=RemediationType.ARCHITECTURE,
        effort_estimate="high",
        cwe_ids=["CWE-269", "CWE-250"],
        framework_fixes={
            Framework.GENERIC: {
                "template": '''from enum import IntEnum
from typing import Set, Dict, List
from dataclasses import dataclass, field

class Permission(str):
    READ = "read"
    WRITE = "write"
    EXECUTE = "execute"
    ADMIN = "admin"

@dataclass
class AgentPermissions:
    """Tracks agent permissions with escalation prevention."""
    agent_id: str
    granted_permissions: Set[str] = field(default_factory=set)
    inherited_permissions: Set[str] = field(default_factory=set)

    @property
    def effective_permissions(self) -> Set[str]:
        return self.granted_permissions | self.inherited_permissions

    def can_perform(self, action: str) -> bool:
        return action in self.effective_permissions

class PrivilegeEscalationGuard:
    """Prevents privilege escalation in agent chains."""

    def __init__(self):
        self.agent_permissions: Dict[str, AgentPermissions] = {}
        self.escalation_log: List[str] = []

    def register_agent(self, agent_id: str, permissions: Set[str]):
        self.agent_permissions[agent_id] = AgentPermissions(
            agent_id=agent_id,
            granted_permissions=permissions
        )

    def validate_tool_call(
        self,
        agent_id: str,
        tool_name: str,
        required_permission: str
    ) -> bool:
        """Check if agent can call tool."""
        perms = self.agent_permissions.get(agent_id)
        if not perms:
            return False

        if perms.can_perform(required_permission):
            return True

        # Log escalation attempt
        self.escalation_log.append(
            f"{agent_id} attempted {tool_name} requiring {required_permission}"
        )
        return False

    def validate_delegation(
        self,
        source_agent: str,
        target_agent: str
    ) -> bool:
        """Ensure delegated agent doesn't gain more permissions."""
        source_perms = self.agent_permissions.get(source_agent)
        target_perms = self.agent_permissions.get(target_agent)

        if not source_perms or not target_perms:
            return False

        # Target cannot have more permissions than source
        excess = target_perms.effective_permissions - source_perms.effective_permissions
        if excess:
            self.escalation_log.append(
                f"Delegation {source_agent} -> {target_agent} would escalate: {excess}"
            )
            return False

        return True

guard = PrivilegeEscalationGuard()
guard.register_agent("user_agent", {Permission.READ})
guard.register_agent("admin_agent", {Permission.READ, Permission.WRITE, Permission.ADMIN})''',
                "imports": "from enum import IntEnum\nfrom typing import Set, Dict, List\nfrom dataclasses import dataclass, field",
                "explanation": "Implement a PrivilegeEscalationGuard that validates all tool calls and delegations. Log escalation attempts.",
            },
        },
    ),
}


class RemediationPatternDB:
    """
    Database for remediation patterns.

    Provides lookup and search functionality for finding
    appropriate remediation patterns.
    """

    def __init__(self, patterns: dict[str, RemediationPattern] | None = None):
        """Initialize with patterns."""
        self.patterns = patterns or REMEDIATION_PATTERNS

    def get_by_id(self, pattern_id: str) -> RemediationPattern | None:
        """Get pattern by ID."""
        for pattern in self.patterns.values():
            if pattern.id == pattern_id:
                return pattern
        return None

    def get_by_vulnerability(self, category: VulnerabilityCategory) -> list[RemediationPattern]:
        """Get patterns for a vulnerability category."""
        return [p for p in self.patterns.values() if p.vulnerability_category == category]

    def get_by_owasp(self, category: OWASPCategory) -> list[RemediationPattern]:
        """Get patterns for an OWASP category."""
        return [p for p in self.patterns.values() if p.owasp_category == category]

    def get_for_framework(self, framework: Framework) -> list[RemediationPattern]:
        """Get all patterns that have fixes for a specific framework."""
        return [
            p
            for p in self.patterns.values()
            if framework in p.framework_fixes or Framework.GENERIC in p.framework_fixes
        ]

    def get_by_effort(self, effort: str) -> list[RemediationPattern]:
        """Get patterns by effort estimate."""
        return [p for p in self.patterns.values() if p.effort_estimate == effort]

    def search(self, query: str) -> list[RemediationPattern]:
        """Search patterns by keyword."""
        query_lower = query.lower()
        results = []
        for pattern in self.patterns.values():
            if (
                query_lower in pattern.name.lower()
                or query_lower in pattern.description.lower()
                or query_lower in pattern.fix_approach.lower()
            ):
                results.append(pattern)
        return results

    def all_patterns(self) -> list[RemediationPattern]:
        """Get all patterns."""
        return list(self.patterns.values())
