"""
AutoGen Security Scanner.

Detects agents, group chats, and code execution patterns in AutoGen-based projects.
"""

import ast
import re
import time
from pathlib import Path

from vantage_core.security.models import (
    AgentCommunication,
    CommunicationType,
    ContentType,
    OWASPCategory,
    SecurityAgent,
    SecurityFinding,
    SecurityScanResult,
    SecurityTool,
    Severity,
    ToolCategory,
    TrustLevel,
    VulnerabilityCategory,
)
from vantage_core.security.scanners.base import SecurityScanner


class AutoGenSecurityScanner(SecurityScanner):
    """
    Security scanner for Microsoft AutoGen framework.

    Detects:
    - AssistantAgent, UserProxyAgent, GroupChatManager
    - Code execution configurations
    - Group chat setups and speaker selection
    - LLM configurations
    """

    framework_name = "autogen"

    AGENT_TYPES = [
        "AssistantAgent",
        "UserProxyAgent",
        "GroupChatManager",
        "ConversableAgent",
        "GPTAssistantAgent",
    ]

    def scan(self, path: Path) -> SecurityScanResult:
        """Scan AutoGen project for security issues."""
        start_time = time.time()
        findings: list[SecurityFinding] = []
        agents: list[SecurityAgent] = []
        communications: list[AgentCommunication] = []

        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()

                file_agents = self._extract_agents_from_file(file_path, code)
                agents.extend(file_agents)

                file_communications = self._extract_communications(file_path, code)
                communications.extend(file_communications)

                findings.extend(self.check_hardcoded_secrets(code, str(file_path)))
                findings.extend(self.check_dangerous_code_patterns(code, str(file_path)))
                findings.extend(self._check_autogen_patterns(code, str(file_path)))

                for agent in file_agents:
                    agent_findings = self.get_vulnerabilities(agent)
                    findings.extend(agent_findings)

            except Exception:
                continue

        return self.create_scan_result(
            findings=findings,
            agents=agents,
            communications=communications,
            frameworks=["autogen"],
            start_time=start_time,
        )

    def _extract_communications(self, file_path: Path, code: str) -> list[AgentCommunication]:
        """Extract communications from AutoGen code."""
        communications: list[AgentCommunication] = []
        tree = ast.parse(code)

        class CommunicationVisitor(ast.NodeVisitor):
            def __init__(self):
                self.comms: list[AgentCommunication] = []

            def visit_Call(self, node: ast.Call) -> None:
                func_name = self._get_func_name(node)

                # GroupChat(agents=[...])
                if func_name == "GroupChat":
                    agents = []
                    for keyword in node.keywords:
                        if keyword.arg == "agents":
                            agents = self._extract_agent_names(keyword.value)

                    # Create mesh topology
                    for i, source in enumerate(agents):
                        for j, target in enumerate(agents):
                            if i != j:
                                self.comms.append(
                                    AgentCommunication(
                                        source_id=source,
                                        target_id=target,
                                        communication_type=CommunicationType.BROADCAST.value,
                                        metadata={
                                            "protocol": "group_chat",
                                            "content_type": ContentType.TEXT.value,
                                            "file_path": str(file_path),
                                            "line_number": node.lineno,
                                        },
                                    )
                                )

                # GroupChatManager(groupchat=...)
                elif func_name == "GroupChatManager":
                    # Manager talks to everyone in the group (implicit)
                    # For now, we just mark the manager as a central node if we could link it to the group chat
                    pass

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return node.func.attr
                return ""

            def _extract_agent_names(self, node: ast.AST) -> list[str]:
                names = []
                if isinstance(node, ast.List):
                    for elt in node.elts:
                        if isinstance(elt, ast.Name):
                            names.append(elt.id)
                return names

        visitor = CommunicationVisitor()
        visitor.visit(tree)
        return visitor.comms

    def get_agents(self, path: Path) -> list[SecurityAgent]:
        """Extract AutoGen agents from path."""
        agents: list[SecurityAgent] = []

        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    code = f.read()
                agents.extend(self._extract_agents_from_file(file_path, code))
            except Exception:
                continue

        return agents

    def get_vulnerabilities(self, agent: SecurityAgent) -> list[SecurityFinding]:
        """Analyze AutoGen agent for vulnerabilities."""
        findings: list[SecurityFinding] = []
        file_path = agent.file_path or "unknown"
        line_number = agent.line_number or 1

        if agent.system_prompt:
            finding = self.check_prompt_injection_risk(
                agent.system_prompt, file_path, line_number, agent.id
            )
            if finding:
                findings.append(finding)

        finding = self.check_excessive_agency(agent, file_path, line_number)
        if finding:
            findings.append(finding)

        # Check code execution security
        findings.extend(self._check_code_execution_security(agent, file_path, line_number))

        return findings

    def _extract_agents_from_file(self, file_path: Path, code: str) -> list[SecurityAgent]:
        """Extract AutoGen agents from a single file."""
        agents: list[SecurityAgent] = []
        tree = ast.parse(code)

        class AgentVisitor(ast.NodeVisitor):
            def __init__(self, scanner: AutoGenSecurityScanner):
                self.scanner = scanner
                self.agents: list[SecurityAgent] = []

            def visit_Call(self, node: ast.Call) -> None:
                func_name = self._get_func_name(node)

                if func_name in AutoGenSecurityScanner.AGENT_TYPES:
                    agent = self._extract_agent_from_call(node, func_name)
                    if agent:
                        self.agents.append(agent)

                self.generic_visit(node)

            def _get_func_name(self, node: ast.Call) -> str:
                if isinstance(node.func, ast.Name):
                    return node.func.id
                elif isinstance(node.func, ast.Attribute):
                    return node.func.attr
                return ""

            def _extract_agent_from_call(
                self, node: ast.Call, agent_type: str
            ) -> SecurityAgent | None:
                name = agent_type
                system_message = None
                has_code_execution = False
                tools: list[SecurityTool] = []

                for keyword in node.keywords:
                    if keyword.arg == "name":
                        if isinstance(keyword.value, ast.Constant):
                            name = str(keyword.value.value)
                    elif keyword.arg == "system_message":
                        if isinstance(keyword.value, ast.Constant):
                            system_message = str(keyword.value.value)
                    elif keyword.arg == "code_execution_config":
                        has_code_execution = True
                        if isinstance(keyword.value, ast.Dict):
                            # Extract code execution settings
                            config = self._extract_code_exec_config(keyword.value)
                            if config.get("use_docker") == False:
                                tools.append(
                                    SecurityTool(
                                        name="code_execution_no_docker",
                                        description="Code execution without Docker isolation",
                                        categories=[ToolCategory.CODE_EXECUTION],
                                        required_trust_level=TrustLevel.SYSTEM,
                                        has_side_effects=True,
                                        risk_score=9.0,
                                    )
                                )
                            else:
                                tools.append(
                                    SecurityTool(
                                        name="code_execution_docker",
                                        description="Code execution with Docker",
                                        categories=[ToolCategory.CODE_EXECUTION],
                                        required_trust_level=TrustLevel.PRIVILEGED,
                                        has_side_effects=True,
                                        risk_score=6.0,
                                    )
                                )

                # UserProxyAgent typically has code execution
                if agent_type == "UserProxyAgent" and not has_code_execution:
                    tools.append(
                        SecurityTool(
                            name="human_input",
                            description="Human input capability",
                            categories=[],
                            required_trust_level=TrustLevel.USER,
                        )
                    )

                agent_id = f"autogen-{name}-{node.lineno}"

                return SecurityAgent(
                    id=agent_id,
                    name=name,
                    framework="autogen",
                    system_prompt=system_message,
                    tools=tools,
                    file_path=str(file_path),
                    line_number=node.lineno,
                    trust_level=self.scanner.infer_trust_level(
                        {"name": name, "system_prompt": system_message or ""}
                    ),
                    metadata={
                        "agent_type": agent_type,
                        "has_code_execution": has_code_execution,
                    },
                )

            def _extract_code_exec_config(self, node: ast.Dict) -> dict:
                config = {}
                for key, value in zip(node.keys, node.values):
                    if isinstance(key, ast.Constant) and isinstance(value, ast.Constant):
                        config[key.value] = value.value
                return config

        visitor = AgentVisitor(self)
        visitor.visit(tree)
        return visitor.agents

    def _check_autogen_patterns(self, code: str, file_path: str) -> list[SecurityFinding]:
        """Check for AutoGen-specific security patterns."""
        findings: list[SecurityFinding] = []
        lines = code.split("\n")

        for i, line in enumerate(lines, 1):
            # Check for code execution without Docker
            if re.search(r"use_docker\s*[=:]\s*False", line):
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Code Execution Without Docker Isolation",
                        description="Code execution is configured without Docker, allowing direct system access.",
                        severity=Severity.CRITICAL,
                        confidence=0.95,
                        owasp_category=OWASPCategory.LLM07,
                        category=VulnerabilityCategory.CODE_EXECUTION,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Enable Docker isolation for code execution: use_docker=True",
                        cwe_id="CWE-94",
                    )
                )

            # Check for unlimited execution
            if re.search(r"timeout\s*[=:]\s*None", line):
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Code Execution Without Timeout",
                        description="Code execution has no timeout configured, risking denial of service.",
                        severity=Severity.MEDIUM,
                        confidence=0.85,
                        owasp_category=OWASPCategory.LLM04,
                        category=VulnerabilityCategory.CODE_EXECUTION,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Set a reasonable timeout for code execution.",
                        cwe_id="CWE-400",
                    )
                )

            # Check for human_input_mode NEVER
            if re.search(r"human_input_mode\s*=\s*['\"]NEVER['\"]", line):
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="No Human Oversight for Agent",
                        description="Agent is configured to never require human input, reducing oversight.",
                        severity=Severity.MEDIUM,
                        confidence=0.7,
                        owasp_category=OWASPCategory.LLM08,
                        category=VulnerabilityCategory.EXCESSIVE_AGENCY,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Consider requiring human approval for sensitive operations.",
                        cwe_id="CWE-862",
                    )
                )

            # Check for unlimited max_consecutive_auto_reply
            if re.search(r"max_consecutive_auto_reply\s*=\s*None", line):
                findings.append(
                    SecurityFinding(
                        id=SecurityFinding.generate_id(),
                        title="Unlimited Auto-Reply",
                        description="Agent can auto-reply indefinitely, risking runaway execution.",
                        severity=Severity.MEDIUM,
                        confidence=0.8,
                        owasp_category=OWASPCategory.LLM04,
                        category=VulnerabilityCategory.CODE_EXECUTION,
                        file_path=file_path,
                        line_number=i,
                        code_snippet=line.strip(),
                        recommendation="Set a reasonable max_consecutive_auto_reply limit.",
                        cwe_id="CWE-400",
                    )
                )

        return findings

    def _check_code_execution_security(
        self, agent: SecurityAgent, file_path: str, line_number: int
    ) -> list[SecurityFinding]:
        """Check code execution security for AutoGen agent."""
        findings: list[SecurityFinding] = []

        has_code_exec = agent.metadata.get("has_code_execution", False)

        if has_code_exec:
            for tool in agent.tools:
                if "no_docker" in tool.name:
                    findings.append(
                        SecurityFinding(
                            id=SecurityFinding.generate_id(),
                            title="High-Risk Code Execution Configuration",
                            description=f"Agent '{agent.name}' executes code without container isolation.",
                            severity=Severity.CRITICAL,
                            confidence=0.95,
                            owasp_category=OWASPCategory.LLM07,
                            category=VulnerabilityCategory.CODE_EXECUTION,
                            file_path=file_path,
                            line_number=line_number,
                            code_snippet=f"Agent: {agent.name}, code_execution without Docker",
                            recommendation="Enable Docker isolation and implement strict code validation.",
                            agent_id=agent.id,
                            cwe_id="CWE-94",
                        )
                    )

        return findings

    @classmethod
    def can_handle(cls, path: Path) -> bool:
        """Check if this scanner can handle AutoGen projects."""
        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        for file_path in files:
            try:
                with open(file_path, encoding="utf-8") as f:
                    content = f.read()
                    if any(x in content for x in ["from autogen", "import autogen", "pyautogen"]):
                        return True
            except Exception:
                continue

        return False
