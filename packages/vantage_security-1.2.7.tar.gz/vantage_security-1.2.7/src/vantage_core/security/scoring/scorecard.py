"""
Multi-Dimensional Security Scorecard

Replaces single letter grade with comprehensive security assessment.
This gives stakeholders ACTIONABLE insights, not just a letter.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Any

import networkx as nx


class RiskLevel(Enum):
    """Risk level classification."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    MINIMAL = "minimal"


@dataclass
class DimensionScore:
    """Score for a single security dimension."""

    score: int  # 0-100
    risk_level: RiskLevel
    findings_count: int
    top_issues: list[str]
    recommendations: list[str]


@dataclass
class SecurityScorecard:
    """
    Comprehensive security scorecard with multiple dimensions.

    Much more informative than single letter grade.
    """

    # Overall
    overall_score: int  # 0-100
    overall_risk: RiskLevel
    primary_concern: str

    # Dimension scores
    threat_resistance: DimensionScore
    resilience: DimensionScore
    transparency: DimensionScore
    compliance: DimensionScore

    # Attack surface
    attack_surface_score: int
    exposed_agents: int
    high_privilege_agents: int

    # Blast radius (from simulation)
    simulated_blast_radius: float
    worst_case_compromise: int

    # Trends
    trend: str  # "improving", "stable", "degrading"

    # Executive summary
    executive_summary: str

    # Detailed recommendations
    immediate_actions: list[str]
    short_term_actions: list[str]
    long_term_actions: list[str]


class ScorecardGenerator:
    """Generate comprehensive security scorecards."""

    def __init__(self):
        """Initialize the scorecard generator."""
        self._severity_weights = {
            "CRITICAL": 15,
            "HIGH": 8,
            "MEDIUM": 3,
            "LOW": 1,
            "INFO": 0,
        }

    def generate_scorecard(
        self,
        findings: list,  # SecurityFinding list
        topology: Any,  # Agent topology (nx.DiGraph or AgentGraph)
        simulation_result: Any = None,  # Optional simulation result
    ) -> SecurityScorecard:
        """
        Generate comprehensive security scorecard.

        Args:
            findings: List of security findings
            topology: Agent network topology
            simulation_result: Optional attack simulation result

        Returns:
            SecurityScorecard with multi-dimensional analysis
        """
        # Calculate dimension scores
        threat_resistance = self._calculate_threat_resistance(findings)
        resilience = self._calculate_resilience(findings, topology)
        transparency = self._calculate_transparency(findings, topology)
        compliance = self._calculate_compliance(findings)

        # Calculate overall score (weighted average)
        overall_score = int(
            threat_resistance.score * 0.35
            + resilience.score * 0.25
            + transparency.score * 0.20
            + compliance.score * 0.20
        )

        # Determine overall risk
        overall_risk = self._score_to_risk(overall_score)

        # Find primary concern
        primary_concern = self._identify_primary_concern(
            threat_resistance, resilience, transparency, compliance
        )

        # Attack surface analysis
        attack_surface_score, exposed, high_priv = self._analyze_attack_surface(topology)

        # Simulation results
        blast_radius = 0.0
        worst_case = 0
        if simulation_result:
            # Handle both SimulationResult (new) and InfectionSimulationResult (legacy)
            if hasattr(simulation_result, "blast_radius"):
                blast_radius = simulation_result.blast_radius
                if isinstance(blast_radius, int):
                    # Legacy format: blast_radius is count, not percentage
                    total = getattr(simulation_result, "total_agents", 1)
                    worst_case = blast_radius
                    blast_radius = blast_radius / max(total, 1)
                else:
                    # New format: blast_radius is percentage
                    worst_case = len(getattr(simulation_result, "compromised_agents", []))

        # Generate recommendations
        immediate, short_term, long_term = self._generate_recommendations(
            findings, threat_resistance, resilience, topology
        )

        # Executive summary
        summary = self._generate_executive_summary(
            overall_score, overall_risk, primary_concern, findings
        )

        return SecurityScorecard(
            overall_score=overall_score,
            overall_risk=overall_risk,
            primary_concern=primary_concern,
            threat_resistance=threat_resistance,
            resilience=resilience,
            transparency=transparency,
            compliance=compliance,
            attack_surface_score=attack_surface_score,
            exposed_agents=exposed,
            high_privilege_agents=high_priv,
            simulated_blast_radius=blast_radius,
            worst_case_compromise=worst_case,
            trend="stable",  # Would need historical data
            executive_summary=summary,
            immediate_actions=immediate,
            short_term_actions=short_term,
            long_term_actions=long_term,
        )

    def _calculate_threat_resistance(self, findings: list) -> DimensionScore:
        """Calculate threat resistance score."""
        # Start at 100, deduct for findings
        score = 100

        # Count by severity
        critical = sum(1 for f in findings if self._get_severity_name(f) == "CRITICAL")
        high = sum(1 for f in findings if self._get_severity_name(f) == "HIGH")
        medium = sum(1 for f in findings if self._get_severity_name(f) == "MEDIUM")
        low = sum(1 for f in findings if self._get_severity_name(f) == "LOW")

        score -= critical * self._severity_weights["CRITICAL"]
        score -= high * self._severity_weights["HIGH"]
        score -= medium * self._severity_weights["MEDIUM"]
        score -= low * self._severity_weights["LOW"]

        score = max(0, min(100, score))

        # Top issues
        top_issues = []
        sorted_findings = sorted(findings, key=lambda x: self._get_severity_value(x), reverse=True)
        for f in sorted_findings[:5]:
            issue = self._get_finding_title(f)
            if issue:
                top_issues.append(issue)

        recommendations = []
        if score < 70:
            recommendations.extend(
                [
                    "Address critical findings immediately",
                    "Implement input validation across all agents",
                    "Add prompt hardening to system prompts",
                ]
            )
        else:
            recommendations.append("Maintain current security posture")

        return DimensionScore(
            score=score,
            risk_level=self._score_to_risk(score),
            findings_count=len(findings),
            top_issues=top_issues,
            recommendations=recommendations,
        )

    def _calculate_resilience(self, findings: list, topology: Any) -> DimensionScore:
        """Calculate resilience score (detection + recovery capability)."""
        score = 70  # Base score

        # Check for monitoring/logging keywords in findings
        findings_str = str(findings).lower()
        has_logging = "logging" in findings_str
        has_monitoring = "monitor" in findings_str

        if not has_logging:
            score -= 15
        if not has_monitoring:
            score -= 10

        # Topology analysis
        if topology is not None:
            nodes = self._get_topology_nodes(topology)

            # Check for single points of failure
            if len(nodes) < 3:
                score -= 10  # Small network less resilient

            # Bonus for well-connected topology
            if len(nodes) >= 5:
                score += 5

        score = max(0, min(100, score))

        top_issues = []
        if score < 70:
            top_issues.append("Limited detection capability")

        recommendations = []
        if score < 70:
            recommendations.extend(
                [
                    "Implement comprehensive logging",
                    "Add anomaly detection for agent behavior",
                    "Create incident response procedures",
                ]
            )
        else:
            recommendations.append("Continue monitoring")

        return DimensionScore(
            score=score,
            risk_level=self._score_to_risk(score),
            findings_count=0,
            top_issues=top_issues,
            recommendations=recommendations,
        )

    def _calculate_transparency(self, findings: list, topology: Any) -> DimensionScore:
        """Calculate transparency score (visibility into agent behavior)."""
        score = 65  # Base score

        # Would analyze audit trail, logging completeness, etc.
        # Simplified for now

        return DimensionScore(
            score=score,
            risk_level=self._score_to_risk(score),
            findings_count=0,
            top_issues=[],
            recommendations=[
                "Add detailed audit logging",
                "Implement agent behavior tracking",
            ],
        )

    def _calculate_compliance(self, findings: list) -> DimensionScore:
        """Calculate compliance score."""
        score = 75  # Base score

        # Check for compliance-related findings
        compliance_keywords = ["pii", "gdpr", "hipaa", "pci", "sox"]
        compliance_findings = []
        for f in findings:
            finding_str = str(f).lower()
            if any(k in finding_str for k in compliance_keywords):
                compliance_findings.append(f)

        score -= len(compliance_findings) * 10
        score = max(0, min(100, score))

        top_issues = [self._get_finding_title(f) or str(f) for f in compliance_findings[:3]]

        recommendations = []
        if compliance_findings:
            recommendations.extend(
                ["Review data handling practices", "Implement data classification"]
            )

        return DimensionScore(
            score=score,
            risk_level=self._score_to_risk(score),
            findings_count=len(compliance_findings),
            top_issues=top_issues,
            recommendations=recommendations,
        )

    def _score_to_risk(self, score: int) -> RiskLevel:
        """Convert score to risk level."""
        if score >= 90:
            return RiskLevel.MINIMAL
        elif score >= 75:
            return RiskLevel.LOW
        elif score >= 50:
            return RiskLevel.MEDIUM
        elif score >= 25:
            return RiskLevel.HIGH
        else:
            return RiskLevel.CRITICAL

    def _identify_primary_concern(self, *dimensions: DimensionScore) -> str:
        """Identify the primary security concern."""
        lowest = min(dimensions, key=lambda d: d.score)

        if lowest.top_issues:
            return lowest.top_issues[0]

        return "Overall security posture needs improvement"

    def _analyze_attack_surface(self, topology: Any) -> tuple[int, int, int]:
        """Analyze attack surface from topology."""
        if topology is None:
            return 50, 0, 0

        nodes = self._get_topology_nodes(topology)
        if not nodes:
            return 50, 0, 0

        exposed = 0
        high_priv = 0

        for node_id in nodes:
            node_data = self._get_node_data(topology, node_id)
            if node_data.get("external_exposure", False):
                exposed += 1
            trust_level = node_data.get("trust_level", 0)
            # Handle both numeric and enum trust levels
            if isinstance(trust_level, int):
                if trust_level >= 3:  # PRIVILEGED or higher
                    high_priv += 1
            elif hasattr(trust_level, "value"):
                if trust_level.value >= 3:
                    high_priv += 1

        # Score based on attack surface
        score = 100
        score -= exposed * 10
        score -= high_priv * 5
        score = max(0, min(100, score))

        return score, exposed, high_priv

    def _generate_recommendations(
        self,
        findings: list,
        threat_resistance: DimensionScore,
        resilience: DimensionScore,
        topology: Any,
    ) -> tuple[list[str], list[str], list[str]]:
        """Generate prioritized recommendations."""
        immediate: list[str] = []
        short_term: list[str] = []
        long_term: list[str] = []

        # Immediate: Critical findings
        critical_findings = [f for f in findings if self._get_severity_name(f) == "CRITICAL"]
        if critical_findings:
            immediate.append(f"Fix {len(critical_findings)} critical vulnerabilities")

        if threat_resistance.score < 50:
            immediate.append("Implement input validation on all entry points")

        # Short-term
        if resilience.score < 70:
            short_term.append("Implement comprehensive logging and monitoring")

        short_term.append("Add prompt hardening to all agent system prompts")
        short_term.append("Segment agent network by trust level")

        # Long-term
        long_term.append("Implement continuous security monitoring")
        long_term.append("Establish regular security review cadence")
        long_term.append("Build automated remediation capabilities")

        return immediate, short_term, long_term

    def _generate_executive_summary(
        self, score: int, risk: RiskLevel, concern: str, findings: list
    ) -> str:
        """Generate executive summary."""
        critical = sum(1 for f in findings if self._get_severity_name(f) == "CRITICAL")
        high = sum(1 for f in findings if self._get_severity_name(f) == "HIGH")

        action_required = "IMMEDIATE" if risk in [RiskLevel.CRITICAL, RiskLevel.HIGH] else "PLANNED"

        summary = f"""Security Assessment: {risk.value.upper()} RISK (Score: {score}/100)

Primary Concern: {concern}

Summary:
- {len(findings)} total security findings identified
- {critical} critical, {high} high severity issues require immediate attention
- Recommended focus: {"Address critical vulnerabilities" if critical > 0 else "Strengthen detection capabilities"}

Action Required: {action_required}
"""
        return summary

    # Helper methods for handling different finding/topology formats

    def _get_severity_name(self, finding: Any) -> str:
        """Get severity name from finding."""
        if hasattr(finding, "severity"):
            sev = finding.severity
            if hasattr(sev, "name"):
                return sev.name
            return str(sev).upper()
        return "UNKNOWN"

    def _get_severity_value(self, finding: Any) -> int:
        """Get severity value for sorting."""
        if hasattr(finding, "severity"):
            sev = finding.severity
            if hasattr(sev, "value"):
                return sev.value
            # Map string to value
            severity_map = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0}
            return severity_map.get(str(sev).upper(), 0)
        return 0

    def _get_finding_title(self, finding: Any) -> str | None:
        """Get title from finding."""
        if hasattr(finding, "title"):
            return finding.title
        if hasattr(finding, "description"):
            return (
                finding.description[:100] if len(finding.description) > 100 else finding.description
            )
        return None

    def _get_topology_nodes(self, topology: Any) -> list:
        """Get nodes from topology (nx.DiGraph or AgentGraph)."""
        if isinstance(topology, nx.DiGraph):
            return list(topology.nodes())
        if hasattr(topology, "nodes"):
            nodes = topology.nodes
            if callable(nodes):
                return list(nodes())
            return list(nodes)
        return []

    def _get_node_data(self, topology: Any, node_id: str) -> dict:
        """Get node data from topology."""
        if isinstance(topology, nx.DiGraph):
            return dict(topology.nodes.get(node_id, {}))
        if hasattr(topology, "nodes"):
            nodes = topology.nodes
            if isinstance(nodes, dict):
                return dict(nodes.get(node_id, {}))
            elif hasattr(topology, "get_node"):
                node = topology.get_node(node_id)
                if node and hasattr(node, "__dict__"):
                    return vars(node)
        return {}


def generate_security_scorecard(
    findings: list, topology: Any, simulation_result: Any = None
) -> SecurityScorecard:
    """
    Convenience function to generate security scorecard.

    Args:
        findings: List of security findings
        topology: Agent network topology
        simulation_result: Optional attack simulation result

    Returns:
        SecurityScorecard with comprehensive analysis
    """
    generator = ScorecardGenerator()
    return generator.generate_scorecard(findings, topology, simulation_result)
