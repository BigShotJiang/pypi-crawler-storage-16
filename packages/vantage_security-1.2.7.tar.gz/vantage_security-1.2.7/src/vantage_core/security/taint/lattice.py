"""
Taint Lattice Data Structures for Intra-Function Analysis.

US-013: Variable Assignment Tracking
Defines the taint lattice with states and join/meet operations
for dataflow analysis.
"""

from dataclasses import dataclass, field
from enum import IntEnum


class TaintState(IntEnum):
    """
    Taint lattice states.

    BOTTOM < UNTAINTED < TAINTED < TOP (MAYBE)

    - BOTTOM: No information (unreachable code)
    - UNTAINTED: Definitely safe
    - TAINTED: Definitely tainted
    - TOP/MAYBE: May be tainted (conservative approximation)
    """

    BOTTOM = 0
    UNTAINTED = 1
    TAINTED = 2
    TOP = 3  # MAYBE_TAINTED

    @staticmethod
    def join(a: "TaintState", b: "TaintState") -> "TaintState":
        """
        Lattice join (least upper bound).

        Used when merging dataflow from multiple predecessors.

        Args:
            a: First taint state
            b: Second taint state

        Returns:
            Joined taint state
        """
        if a == b:
            return a
        if a == TaintState.BOTTOM:
            return b
        if b == TaintState.BOTTOM:
            return a
        # TAINTED join UNTAINTED = TOP
        return TaintState.TOP

    @staticmethod
    def meet(a: "TaintState", b: "TaintState") -> "TaintState":
        """
        Lattice meet (greatest lower bound).

        Used for must-analysis.

        Args:
            a: First taint state
            b: Second taint state

        Returns:
            Meet of taint states
        """
        if a == b:
            return a
        if a == TaintState.TOP:
            return b
        if b == TaintState.TOP:
            return a
        return TaintState.BOTTOM


@dataclass(frozen=True)
class TaintSource:
    """
    Represents where taint originated.

    Immutable to allow use in sets.
    """

    location: str  # file:line:col
    source_type: str  # "user_input", "file_read", etc.
    variable: str
    label: str = ""  # Optional label for tracking

    def __repr__(self) -> str:
        return f"TaintSource({self.source_type}:{self.variable}@{self.location})"


@dataclass
class TaintedValue:
    """
    A value with taint information.

    Tracks both the taint state and the sources that
    contributed to this taint.
    """

    state: TaintState
    sources: frozenset[TaintSource] = field(default_factory=frozenset)

    def join(self, other: "TaintedValue") -> "TaintedValue":
        """
        Join two tainted values (union of sources).

        Args:
            other: Another tainted value to join with

        Returns:
            New TaintedValue with joined state and sources
        """
        return TaintedValue(
            state=TaintState.join(self.state, other.state),
            sources=self.sources | other.sources,
        )

    def is_tainted(self) -> bool:
        """
        Check if value is potentially tainted.

        Returns:
            True if state is TAINTED or TOP
        """
        return self.state in (TaintState.TAINTED, TaintState.TOP)

    @classmethod
    def untainted(cls) -> "TaintedValue":
        """
        Create an untainted value.

        Returns:
            TaintedValue with UNTAINTED state
        """
        return cls(TaintState.UNTAINTED)

    @classmethod
    def tainted(cls, source: TaintSource) -> "TaintedValue":
        """
        Create a tainted value from source.

        Args:
            source: The taint source

        Returns:
            TaintedValue with TAINTED state and source
        """
        return cls(TaintState.TAINTED, frozenset([source]))

    @classmethod
    def bottom(cls) -> "TaintedValue":
        """
        Create a bottom value (no information).

        Returns:
            TaintedValue with BOTTOM state
        """
        return cls(TaintState.BOTTOM)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, TaintedValue):
            return False
        return self.state == other.state and self.sources == other.sources

    def __hash__(self) -> int:
        return hash((self.state, self.sources))

    def __repr__(self) -> str:
        return f"TaintedValue({self.state.name}, sources={len(self.sources)})"


# Type alias for taint environment
TaintEnv = dict[str, TaintedValue]  # variable name -> taint info


def join_envs(env1: TaintEnv, env2: TaintEnv) -> TaintEnv:
    """
    Join two taint environments.

    Args:
        env1: First environment
        env2: Second environment

    Returns:
        Joined environment with union of variables
    """
    result = env1.copy()
    for var, taint in env2.items():
        if var in result:
            result[var] = result[var].join(taint)
        else:
            result[var] = taint
    return result


def env_equal(env1: TaintEnv, env2: TaintEnv) -> bool:
    """
    Check if two environments are equal.

    Args:
        env1: First environment
        env2: Second environment

    Returns:
        True if environments are equal
    """
    if set(env1.keys()) != set(env2.keys()):
        return False
    for var in env1:
        if env1[var] != env2[var]:
            return False
    return True
