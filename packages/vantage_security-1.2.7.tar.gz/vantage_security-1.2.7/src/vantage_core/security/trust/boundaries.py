"""
Trust Boundary Crossing and Privilege Escalation Detection.

US-115: Boundary Crossing Detection - Identify data flows crossing trust boundaries
US-116: Privilege Escalation Detection - Find paths from low to high privilege

Analyzes agent topologies to find security-relevant boundary crossings
and potential privilege escalation paths.
"""

from dataclasses import dataclass, field
from typing import Any

from vantage_core.security.models import Severity, TrustLevel
from vantage_core.security.topology.graph import AgentGraph, GraphEdge, GraphNode


@dataclass
class BoundaryCrossing:
    """
    Represents a data flow crossing a trust boundary.

    Each crossing is analyzed for security implications and
    assigned a severity based on risk factors.
    """

    source_agent: str
    target_agent: str
    source_trust: TrustLevel
    target_trust: TrustLevel
    data_types: list[str] = field(default_factory=list)
    data_sensitivity: str = "internal"
    trust_differential: int = 0
    severity: Severity = Severity.INFO
    recommendation: str = ""
    evidence: list[str] = field(default_factory=list)

    @property
    def is_elevation(self) -> bool:
        """Check if crossing goes from low to high trust."""
        return self.trust_differential < 0

    @property
    def is_demotion(self) -> bool:
        """Check if crossing goes from high to low trust."""
        return self.trust_differential > 0


@dataclass
class EscalationPath:
    """
    Represents a privilege escalation path through the agent graph.

    Contains the full path from entry point to privileged operation
    along with risk metrics.
    """

    path: list[str]  # Agent IDs in order
    start_trust: TrustLevel
    end_trust: TrustLevel
    total_escalation: int  # Total trust level increase
    hop_count: int
    severity: Severity = Severity.HIGH
    exploitability: float = 0.5  # 0-1 scale
    crossings: list[BoundaryCrossing] = field(default_factory=list)
    recommendation: str = ""

    @property
    def escalation_per_hop(self) -> float:
        """Calculate average escalation per hop."""
        if self.hop_count == 0:
            return 0.0
        return self.total_escalation / self.hop_count

    @property
    def is_direct(self) -> bool:
        """Check if this is a direct escalation (single hop)."""
        return self.hop_count == 1


class BoundaryAnalyzer:
    """
    Analyze trust boundaries and detect security violations.

    Identifies boundary crossings, privilege escalation paths,
    and generates recommendations for remediation.
    """

    def __init__(self, graph: AgentGraph):
        """
        Initialize the boundary analyzer.

        Args:
            graph: AgentGraph to analyze
        """
        self.graph = graph

    def find_crossings(self) -> list[BoundaryCrossing]:
        """
        Find all trust boundary crossings in the graph.

        Returns:
            List of BoundaryCrossing objects
        """
        crossings = []

        for edge in self.graph.edges:
            if not edge.crosses_trust_boundary:
                continue

            source_node = self.graph.get_node(edge.source_id)
            target_node = self.graph.get_node(edge.target_id)

            if not source_node or not target_node:
                continue

            # Determine severity
            severity = self._calculate_crossing_severity(
                edge.trust_differential, edge.data_sensitivity
            )

            # Generate recommendation
            recommendation = self._generate_crossing_recommendation(source_node, target_node, edge)

            crossing = BoundaryCrossing(
                source_agent=edge.source_id,
                target_agent=edge.target_id,
                source_trust=source_node.trust_level,
                target_trust=target_node.trust_level,
                data_sensitivity=edge.data_sensitivity,
                trust_differential=edge.trust_differential,
                severity=severity,
                recommendation=recommendation,
            )

            # Add evidence
            crossing.evidence.append(
                f"Trust level change: {source_node.trust_level.name} -> {target_node.trust_level.name}"
            )
            if edge.data_sensitivity in ["confidential", "secret"]:
                crossing.evidence.append(
                    f"Sensitive data ({edge.data_sensitivity}) crossing boundary"
                )

            crossings.append(crossing)

        return crossings

    def find_escalation_paths(
        self, max_depth: int = 10, min_escalation: int = 2
    ) -> list[EscalationPath]:
        """
        Find all privilege escalation paths in the graph.

        Args:
            max_depth: Maximum path length to consider
            min_escalation: Minimum trust level increase for a valid path

        Returns:
            List of EscalationPath objects sorted by severity
        """
        escalation_paths = []

        # Find low-trust entry points
        entry_points = [
            node for node in self.graph.nodes if node.trust_level.value <= TrustLevel.USER.value
        ]

        # Find high-trust targets
        targets = [
            node
            for node in self.graph.nodes
            if node.trust_level.value >= TrustLevel.PRIVILEGED.value
        ]

        # Find paths between each pair
        for entry in entry_points:
            for target in targets:
                paths = self.graph.find_paths(entry.id, target.id, max_depth)

                for path in paths:
                    # Calculate total escalation
                    total_escalation = target.trust_level.value - entry.trust_level.value

                    if total_escalation >= min_escalation:
                        # Analyze the path
                        escalation_path = self._analyze_escalation_path(
                            path, entry.trust_level, target.trust_level
                        )
                        escalation_paths.append(escalation_path)

        # Sort by severity and exploitability
        escalation_paths.sort(
            key=lambda p: (p.severity.value, -p.exploitability),
            reverse=False,  # Critical first
        )

        return escalation_paths

    def find_shortest_escalation(self) -> EscalationPath | None:
        """
        Find the shortest privilege escalation path.

        Returns:
            Shortest EscalationPath or None if no escalations exist
        """
        all_paths = self.find_escalation_paths()

        if not all_paths:
            return None

        # Sort by hop count
        return min(all_paths, key=lambda p: p.hop_count)

    def find_critical_boundaries(self) -> list[tuple[str, str]]:
        """
        Find the most critical boundary crossings.

        Returns:
            List of (source_id, target_id) tuples for critical crossings
        """
        critical = []

        for crossing in self.find_crossings():
            if crossing.severity in [Severity.CRITICAL, Severity.HIGH]:
                critical.append((crossing.source_agent, crossing.target_agent))

        return critical

    def get_boundary_statistics(self) -> dict[str, Any]:
        """
        Get statistics about boundary crossings.

        Returns:
            Dictionary of boundary statistics
        """
        crossings = self.find_crossings()

        # Count by severity
        severity_counts = {sev: 0 for sev in Severity}
        for crossing in crossings:
            severity_counts[crossing.severity] += 1

        # Count elevations vs demotions
        elevations = sum(1 for c in crossings if c.is_elevation)
        demotions = sum(1 for c in crossings if c.is_demotion)

        # Count by trust level pairs
        level_pairs: dict[tuple[str, str], int] = {}
        for crossing in crossings:
            key = (crossing.source_trust.name, crossing.target_trust.name)
            level_pairs[key] = level_pairs.get(key, 0) + 1

        # Convert tuple keys to strings for JSON serialization
        level_pairs_str = {f"{src}->{tgt}": count for (src, tgt), count in level_pairs.items()}

        return {
            "total_crossings": len(crossings),
            "elevations": elevations,
            "demotions": demotions,
            "by_severity": {sev.name: count for sev, count in severity_counts.items()},
            "by_trust_pair": level_pairs_str,
        }

    def analyze_agent_exposure(self, agent_id: str) -> dict[str, Any]:
        """
        Analyze the boundary exposure of a specific agent.

        Args:
            agent_id: Agent to analyze

        Returns:
            Dictionary of exposure metrics
        """
        node = self.graph.get_node(agent_id)
        if not node:
            return {}

        # Find all crossings involving this agent
        crossings = self.find_crossings()
        incoming = [c for c in crossings if c.target_agent == agent_id]
        outgoing = [c for c in crossings if c.source_agent == agent_id]

        # Calculate exposure score
        exposure_score = len(incoming) + len(outgoing) * 0.5

        # Find escalation paths through this agent
        all_paths = self.find_escalation_paths()
        paths_through = [p for p in all_paths if agent_id in p.path]

        return {
            "agent_id": agent_id,
            "trust_level": node.trust_level.name,
            "incoming_crossings": len(incoming),
            "outgoing_crossings": len(outgoing),
            "exposure_score": exposure_score,
            "escalation_paths_through": len(paths_through),
            "is_chokepoint": len(paths_through) > 2,
        }

    def _calculate_crossing_severity(
        self, trust_differential: int, data_sensitivity: str
    ) -> Severity:
        """Calculate severity for a boundary crossing."""
        # Base severity on trust differential
        abs_diff = abs(trust_differential)

        if abs_diff >= 3:
            base_severity = Severity.CRITICAL
        elif abs_diff >= 2:
            base_severity = Severity.HIGH
        elif abs_diff >= 1:
            base_severity = Severity.MEDIUM
        else:
            base_severity = Severity.LOW

        # Elevate for sensitive data
        if data_sensitivity == "secret":
            if base_severity == Severity.LOW:
                base_severity = Severity.MEDIUM
            elif base_severity == Severity.MEDIUM:
                base_severity = Severity.HIGH
        elif data_sensitivity == "confidential":
            if base_severity == Severity.LOW:
                base_severity = Severity.MEDIUM

        return base_severity

    def _generate_crossing_recommendation(
        self, source_node: GraphNode, target_node: GraphNode, edge: GraphEdge
    ) -> str:
        """Generate a recommendation for a boundary crossing."""
        recommendations = []

        # Check direction
        if edge.trust_differential < 0:  # Elevation
            recommendations.append(f"Add input validation before {target_node.name} receives data")
            recommendations.append("Implement least-privilege access controls")
        else:  # Demotion
            recommendations.append(
                f"Sanitize output from {source_node.name} before sending to lower trust"
            )

        # Check data sensitivity
        if edge.data_sensitivity in ["confidential", "secret"]:
            recommendations.append("Add encryption for sensitive data in transit")
            recommendations.append("Implement access logging for audit trail")

        # Check capabilities
        if target_node.has_code_execution and edge.trust_differential < 0:
            recommendations.append(
                "Implement sandboxing for code execution from lower-trust sources"
            )

        return "; ".join(recommendations)

    def _analyze_escalation_path(
        self, path: list[str], start_trust: TrustLevel, end_trust: TrustLevel
    ) -> EscalationPath:
        """Analyze a specific escalation path."""
        hop_count = len(path) - 1
        total_escalation = end_trust.value - start_trust.value

        # Collect crossings along the path
        crossings = []
        for i in range(len(path) - 1):
            edge = self.graph.get_edge(path[i], path[i + 1])
            if edge and edge.crosses_trust_boundary:
                source_node = self.graph.get_node(path[i])
                target_node = self.graph.get_node(path[i + 1])

                if source_node and target_node:
                    crossing = BoundaryCrossing(
                        source_agent=path[i],
                        target_agent=path[i + 1],
                        source_trust=source_node.trust_level,
                        target_trust=target_node.trust_level,
                        trust_differential=edge.trust_differential,
                        data_sensitivity=edge.data_sensitivity,
                    )
                    crossings.append(crossing)

        # Calculate exploitability
        exploitability = self._calculate_exploitability(path, crossings)

        # Determine severity
        if total_escalation >= 3:
            severity = Severity.CRITICAL
        elif total_escalation >= 2:
            severity = Severity.HIGH
        else:
            severity = Severity.MEDIUM

        # Higher severity for direct paths
        if hop_count == 1:
            if severity == Severity.HIGH:
                severity = Severity.CRITICAL

        # Generate recommendation
        recommendation = self._generate_escalation_recommendation(
            path, start_trust, end_trust, crossings
        )

        return EscalationPath(
            path=path,
            start_trust=start_trust,
            end_trust=end_trust,
            total_escalation=total_escalation,
            hop_count=hop_count,
            severity=severity,
            exploitability=exploitability,
            crossings=crossings,
            recommendation=recommendation,
        )

    def _calculate_exploitability(
        self, path: list[str], crossings: list[BoundaryCrossing]
    ) -> float:
        """Calculate exploitability score for an escalation path."""
        # Base exploitability
        exploitability = 0.5

        # Shorter paths are more exploitable
        hop_count = len(path) - 1
        if hop_count == 1:
            exploitability += 0.3
        elif hop_count <= 3:
            exploitability += 0.1

        # Direct entry from external
        first_node = self.graph.get_node(path[0])
        if first_node and first_node.trust_level == TrustLevel.EXTERNAL:
            exploitability += 0.2

        # Sensitive data in crossings
        for crossing in crossings:
            if crossing.data_sensitivity in ["confidential", "secret"]:
                exploitability -= 0.1  # Harder to exploit without detection

        return min(max(exploitability, 0.0), 1.0)

    def _generate_escalation_recommendation(
        self,
        path: list[str],
        start_trust: TrustLevel,
        end_trust: TrustLevel,
        crossings: list[BoundaryCrossing],
    ) -> str:
        """Generate recommendation for an escalation path."""
        recommendations = []

        # General recommendations
        recommendations.append(
            f"Review the {len(path) - 1}-hop path from {start_trust.name} to {end_trust.name}"
        )

        # Suggest breaking the path
        if len(path) > 2:
            middle_node = self.graph.get_node(path[len(path) // 2])
            if middle_node:
                recommendations.append(
                    f"Consider adding validation at {middle_node.name} to break escalation chain"
                )

        # Suggest strengthening weakest link
        if crossings:
            max_crossing = max(crossings, key=lambda c: abs(c.trust_differential))
            recommendations.append(
                f"Strengthen boundary between {max_crossing.source_agent} and {max_crossing.target_agent}"
            )

        return "; ".join(recommendations)


def find_boundary_violations(graph: AgentGraph) -> list[BoundaryCrossing]:
    """
    Convenience function to find all boundary crossings.

    Args:
        graph: AgentGraph to analyze

    Returns:
        List of BoundaryCrossing objects
    """
    analyzer = BoundaryAnalyzer(graph)
    return analyzer.find_crossings()


def find_privilege_escalations(graph: AgentGraph, min_escalation: int = 2) -> list[EscalationPath]:
    """
    Convenience function to find privilege escalation paths.

    Args:
        graph: AgentGraph to analyze
        min_escalation: Minimum trust level increase

    Returns:
        List of EscalationPath objects
    """
    analyzer = BoundaryAnalyzer(graph)
    return analyzer.find_escalation_paths(min_escalation=min_escalation)
