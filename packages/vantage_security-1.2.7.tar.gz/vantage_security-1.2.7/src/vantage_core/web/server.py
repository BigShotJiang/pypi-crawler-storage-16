"""
Vantage Web Server.

Flask-based web server for the Vantage dashboard.
Provides REST API endpoints and serves the web UI.
"""

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

from flask import Flask, jsonify, render_template, request

from vantage_core.security.detection.prompt_injection_classifier import (
    PromptInjectionClassifier,
)
from vantage_core.verification.effectiveness import EffectivenessDatabase
from vantage_core.verification.oracle import DetectionOracle
from vantage_core.verification.payloads import (
    PayloadCategory,
    PayloadDatabase,
    Severity,
)


def create_app(config: dict | None = None) -> Flask:
    """Create and configure the Flask application."""

    # Get the directory containing this file
    base_dir = Path(__file__).parent

    app = Flask(
        __name__,
        template_folder=str(base_dir / "templates"),
        static_folder=str(base_dir / "static"),
    )

    # Apply configuration
    app.config.update(
        SECRET_KEY=os.environ.get("MIMIC_SECRET_KEY", "dev-secret-key"),
        JSON_SORT_KEYS=False,
    )

    if config:
        app.config.update(config)

    # Initialize components
    payload_db = PayloadDatabase()
    classifier = PromptInjectionClassifier()
    oracle = DetectionOracle()

    # ==========================================================================
    # Page Routes
    # ==========================================================================

    @app.route("/")
    def index():
        """Main dashboard page."""
        return render_template("index.html")

    @app.route("/demo")
    def demo():
        """Prompt testing demo page."""
        return render_template("demo.html")

    @app.route("/visualization")
    def visualization():
        """Infection visualization page."""
        return render_template("visualization.html")

    @app.route("/compare")
    def compare():
        """Competitor comparison page."""
        return render_template("compare.html")

    @app.route("/effectiveness")
    def effectiveness():
        """Effectiveness data page."""
        return render_template("effectiveness.html")

    # ==========================================================================
    # API Routes - Prompt Testing
    # ==========================================================================

    @app.route("/api/test-prompt", methods=["POST"])
    def test_prompt():
        """
        Test a system prompt for injection vulnerabilities.

        Request body:
            {
                "prompt": "You are a helpful assistant...",
                "payloads": ["category1", "category2"] (optional),
                "max_payloads": 10 (optional)
            }

        Returns:
            {
                "vulnerable": true/false,
                "score": 0-100,
                "findings": [...],
                "tested_payloads": 10,
                "vulnerabilities_found": 3
            }
        """
        data = request.get_json()

        if not data or "prompt" not in data:
            return jsonify({"error": "Missing 'prompt' in request body"}), 400

        prompt = data["prompt"]
        categories = data.get("payloads", [])
        max_payloads = data.get("max_payloads", 20)

        # Get payloads to test
        if categories:
            payloads = []
            for cat in categories:
                try:
                    category = PayloadCategory(cat)
                    payloads.extend(payload_db.get_by_category(category))
                except ValueError:
                    pass
        else:
            payloads = payload_db.all()[:max_payloads]

        # Test each payload
        findings = []
        vulnerabilities = 0

        for payload in payloads[:max_payloads]:
            # Simulate injection attempt
            injected_input = f"User input here\n\n{payload.payload}"

            # Classify the injection
            result = classifier.classify(injected_input)

            if result.is_injection:
                vulnerabilities += 1
                findings.append(
                    {
                        "payload_id": payload.id,
                        "payload_name": payload.name,
                        "category": (
                            payload.category.value
                            if hasattr(payload.category, "value")
                            else str(payload.category)
                        ),
                        "severity": (
                            payload.severity.value
                            if hasattr(payload.severity, "value")
                            else str(payload.severity)
                        ),
                        "confidence": result.confidence,
                        "detected_by": result.matched_category or "ml",
                    }
                )

        # Calculate vulnerability score (0 = fully vulnerable, 100 = secure)
        if len(payloads) > 0:
            vulnerability_rate = vulnerabilities / len(payloads[:max_payloads])
            security_score = round((1 - vulnerability_rate) * 100, 1)
        else:
            security_score = 100

        return jsonify(
            {
                "vulnerable": vulnerabilities > 0,
                "score": security_score,
                "findings": findings,
                "tested_payloads": len(payloads[:max_payloads]),
                "vulnerabilities_found": vulnerabilities,
                "timestamp": datetime.utcnow().isoformat(),
            }
        )

    @app.route("/api/quick-scan", methods=["POST"])
    def quick_scan():
        """
        Quick ML-based scan of a prompt.

        Request body:
            {"prompt": "..."}

        Returns:
            {
                "is_injection": true/false,
                "confidence": 0.0-1.0,
                "detection_method": "ml|regex|encoding",
                "patterns_found": [...]
            }
        """
        data = request.get_json()

        if not data or "prompt" not in data:
            return jsonify({"error": "Missing 'prompt' in request body"}), 400

        result = classifier.classify(data["prompt"])

        return jsonify(
            {
                "is_injection": result.is_injection,
                "confidence": result.confidence,
                "detection_method": result.matched_category or "ml",
                "patterns_found": (result.similar_patterns if result.similar_patterns else []),
                "explanation": result.reasoning if result.reasoning else "",
            }
        )

    # ==========================================================================
    # API Routes - Payloads
    # ==========================================================================

    @app.route("/api/payloads")
    def get_payloads():
        """Get available payloads with optional filtering."""
        category = request.args.get("category")
        severity = request.args.get("severity")
        limit = int(request.args.get("limit", 50))

        payloads = payload_db.all()

        if category:
            try:
                cat = PayloadCategory(category)
                payloads = [p for p in payloads if p.category == cat]
            except ValueError:
                pass

        if severity:
            try:
                sev = Severity(severity)
                payloads = [p for p in payloads if p.severity == sev]
            except ValueError:
                pass

        return jsonify(
            {
                "total": len(payloads),
                "returned": min(limit, len(payloads)),
                "payloads": [
                    {
                        "id": p.id,
                        "name": p.name,
                        "category": (
                            p.category.value if hasattr(p.category, "value") else str(p.category)
                        ),
                        "severity": (
                            p.severity.value if hasattr(p.severity, "value") else str(p.severity)
                        ),
                        "description": p.description[:200] if p.description else "",
                    }
                    for p in payloads[:limit]
                ],
            }
        )

    @app.route("/api/payloads/categories")
    def get_payload_categories():
        """Get all payload categories with counts."""
        categories = {}
        for payload in payload_db.all():
            cat = (
                payload.category.value
                if hasattr(payload.category, "value")
                else str(payload.category)
            )
            categories[cat] = categories.get(cat, 0) + 1

        return jsonify(
            {
                "categories": [
                    {"name": name, "count": count} for name, count in sorted(categories.items())
                ]
            }
        )

    @app.route("/api/payloads/stats")
    def get_payload_stats():
        """Get payload database statistics."""
        payloads = payload_db.all()

        by_category = {}
        by_severity = {}

        for p in payloads:
            cat = p.category.value if hasattr(p.category, "value") else str(p.category)
            sev = p.severity.value if hasattr(p.severity, "value") else str(p.severity)

            by_category[cat] = by_category.get(cat, 0) + 1
            by_severity[sev] = by_severity.get(sev, 0) + 1

        return jsonify(
            {
                "total_payloads": len(payloads),
                "by_category": by_category,
                "by_severity": by_severity,
            }
        )

    # ==========================================================================
    # API Routes - Infection Simulation
    # ==========================================================================

    @app.route("/api/simulate", methods=["POST"])
    def simulate_infection():
        """
        Run infection simulation and return visualization data.

        Request body:
            {
                "agents": [
                    {"id": "agent1", "name": "API Agent", "trust_level": 1},
                    {"id": "agent2", "name": "Data Agent", "trust_level": 2}
                ],
                "connections": [
                    {"source": "agent1", "target": "agent2"}
                ],
                "entry_point": "agent1",
                "payload_strength": 0.8,
                "max_steps": 10
            }

        Returns:
            Animation data for D3.js visualization
        """
        data = request.get_json()

        if not data:
            return jsonify({"error": "Missing request body"}), 400

        agents = data.get("agents", [])
        connections = data.get("connections", [])
        entry_point = data.get("entry_point")
        max_steps = data.get("max_steps", 10)

        if not agents or not entry_point:
            return jsonify({"error": "Missing 'agents' or 'entry_point'"}), 400

        # Generate mock animation data for web demo
        animation = _generate_mock_animation(agents, connections, entry_point, max_steps)
        return jsonify(animation)

    @app.route("/api/simulate/example")
    def simulate_example():
        """Get an example simulation for demo purposes."""
        example_agents = [
            {"id": "api-gateway", "name": "API Gateway", "trust_level": 1},
            {"id": "auth-agent", "name": "Auth Agent", "trust_level": 2},
            {"id": "data-agent", "name": "Data Agent", "trust_level": 2},
            {"id": "report-agent", "name": "Report Agent", "trust_level": 3},
            {"id": "email-agent", "name": "Email Agent", "trust_level": 3},
            {"id": "slack-agent", "name": "Slack Agent", "trust_level": 3},
        ]

        example_connections = [
            {"source": "api-gateway", "target": "auth-agent"},
            {"source": "api-gateway", "target": "data-agent"},
            {"source": "data-agent", "target": "report-agent"},
            {"source": "report-agent", "target": "email-agent"},
            {"source": "report-agent", "target": "slack-agent"},
        ]

        animation = _generate_mock_animation(
            example_agents, example_connections, "api-gateway", max_steps=6
        )

        return jsonify(
            {
                "agents": example_agents,
                "connections": example_connections,
                "animation": animation,
                "summary": {
                    "total_frames": len(animation["frames"]),
                    "duration_ms": animation["duration_ms"],
                    "entry_point": animation["entry_point"],
                    "total_agents": animation["total_agents"],
                    "blast_radius": animation["blast_radius"],
                },
            }
        )

    def _generate_mock_animation(
        agents: list, connections: list, entry_point: str, max_steps: int = 10
    ) -> dict:
        """Generate mock animation data for web demo."""
        import math

        # Build adjacency list
        adjacency = {}
        for agent in agents:
            adjacency[agent["id"]] = []
        for conn in connections:
            if conn["source"] in adjacency:
                adjacency[conn["source"]].append(conn["target"])

        # Calculate positions (circular layout)
        positions = {}
        n = len(agents)
        for i, agent in enumerate(agents):
            angle = (2 * math.pi * i) / n
            positions[agent["id"]] = {
                "x": 300 + 150 * math.cos(angle),
                "y": 300 + 150 * math.sin(angle),
            }

        # Simulate infection spread
        frames = []
        infected = {entry_point}
        infected_at = {entry_point: 0}

        for step in range(max_steps):
            agent_states = {}
            for agent in agents:
                aid = agent["id"]
                if aid in infected:
                    state = "infected"
                else:
                    state = "susceptible"

                agent_states[aid] = {
                    "agent_id": aid,
                    "state": state,
                    "color": "#ef4444" if state == "infected" else "#22c55e",
                    "infected_at": infected_at.get(aid, -1),
                    "infected_by": None,
                    "position": positions[aid],
                }

            # Spread infection
            new_infected = set()
            for source in infected:
                for target in adjacency.get(source, []):
                    if target not in infected:
                        new_infected.add(target)
                        infected_at[target] = step + 1
                        agent_states[target]["infected_by"] = source

            infected.update(new_infected)

            frames.append(
                {
                    "frame_number": step,
                    "timestamp_ms": step * 500,
                    "agent_states": agent_states,
                    "active_infections": [],
                    "metrics": {
                        "susceptible": len(agents) - len(infected),
                        "infected": len(infected),
                        "infection_rate": len(infected) / len(agents),
                    },
                }
            )

            if len(infected) == len(agents):
                break

        return {
            "frames": frames,
            "duration_ms": len(frames) * 500,
            "fps": 30,
            "agent_positions": positions,
            "entry_point": entry_point,
            "total_agents": len(agents),
            "blast_radius": len(infected),
            "metadata": {
                "total_steps": len(frames),
                "peak_infection": len(infected),
            },
        }

    # ==========================================================================
    # API Routes - Effectiveness Data
    # ==========================================================================

    @app.route("/api/effectiveness/stats")
    def get_effectiveness_stats():
        """Get overall effectiveness statistics."""
        try:
            db = EffectivenessDatabase()
            stats = db.get_statistics()
            return jsonify(stats)
        except Exception as e:
            return (
                jsonify(
                    {
                        "error": str(e),
                        "message": "Effectiveness database not available. Run some tests first.",
                    }
                ),
                404,
            )

    @app.route("/api/effectiveness/by-model")
    def get_effectiveness_by_model():
        """Get effectiveness data grouped by model."""
        try:
            db = EffectivenessDatabase()
            models = db.get_models_tested()

            results = []
            for model in models:
                profile = db.get_model_vulnerability_profile(model)
                results.append(
                    {
                        "model": model,
                        "vulnerability_rate": profile.vulnerability_rate,
                        "total_tests": profile.total_tests,
                        "compromised": profile.total_compromised,
                        "resisted": profile.total_resisted,
                    }
                )

            return jsonify({"models": results})
        except Exception as e:
            return jsonify({"error": str(e)}), 404

    @app.route("/api/effectiveness/by-category")
    def get_effectiveness_by_category():
        """Get effectiveness data grouped by payload category."""
        try:
            db = EffectivenessDatabase()
            stats = db.get_category_statistics()
            return jsonify({"categories": stats})
        except Exception as e:
            return jsonify({"error": str(e)}), 404

    # ==========================================================================
    # API Routes - Comparison Data
    # ==========================================================================

    @app.route("/api/compare/features")
    def get_comparison_features():
        """Get feature comparison data vs competitors."""
        return jsonify(
            {
                "last_updated": "2025-12-06",
                "competitors": [
                    {
                        "name": "Vantage",
                        "type": "This Tool",
                        "features": {
                            "multi_agent_scanning": True,
                            "topology_analysis": True,
                            "infection_simulation": True,
                            "blast_radius": True,
                            "live_llm_testing": True,
                            "effectiveness_tracking": True,
                            "custom_payloads": True,
                            "frameworks_supported": 24,
                            "payloads_count": 227,
                            "owasp_mapping": True,
                            "soc2_evidence": True,
                            "cicd_integration": True,
                            "pricing_free_tier": True,
                            "open_source": "Partial",
                        },
                    },
                    {
                        "name": "Lakera Guard",
                        "type": "Competitor",
                        "features": {
                            "multi_agent_scanning": False,
                            "topology_analysis": False,
                            "infection_simulation": False,
                            "blast_radius": False,
                            "live_llm_testing": True,
                            "effectiveness_tracking": False,
                            "custom_payloads": True,
                            "frameworks_supported": 20,
                            "payloads_count": "Unknown",
                            "owasp_mapping": True,
                            "soc2_evidence": False,
                            "cicd_integration": True,
                            "pricing_free_tier": True,
                            "open_source": False,
                        },
                    },
                    {
                        "name": "Arthur Shield",
                        "type": "Competitor",
                        "features": {
                            "multi_agent_scanning": False,
                            "topology_analysis": False,
                            "infection_simulation": False,
                            "blast_radius": False,
                            "live_llm_testing": True,
                            "effectiveness_tracking": True,
                            "custom_payloads": True,
                            "frameworks_supported": 10,
                            "payloads_count": "Unknown",
                            "owasp_mapping": True,
                            "soc2_evidence": True,
                            "cicd_integration": True,
                            "pricing_free_tier": False,
                            "open_source": False,
                        },
                    },
                    {
                        "name": "LLM Guard",
                        "type": "Competitor",
                        "features": {
                            "multi_agent_scanning": False,
                            "topology_analysis": False,
                            "infection_simulation": False,
                            "blast_radius": False,
                            "live_llm_testing": False,
                            "effectiveness_tracking": False,
                            "custom_payloads": True,
                            "frameworks_supported": 5,
                            "payloads_count": 50,
                            "owasp_mapping": False,
                            "soc2_evidence": False,
                            "cicd_integration": True,
                            "pricing_free_tier": True,
                            "open_source": True,
                        },
                    },
                    {
                        "name": "Rebuff",
                        "type": "Competitor",
                        "features": {
                            "multi_agent_scanning": False,
                            "topology_analysis": False,
                            "infection_simulation": False,
                            "blast_radius": False,
                            "live_llm_testing": True,
                            "effectiveness_tracking": False,
                            "custom_payloads": False,
                            "frameworks_supported": 3,
                            "payloads_count": "Unknown",
                            "owasp_mapping": False,
                            "soc2_evidence": False,
                            "cicd_integration": False,
                            "pricing_free_tier": True,
                            "open_source": True,
                        },
                    },
                ],
                "unique_features": [
                    {
                        "feature": "Multi-Agent Topology Analysis",
                        "description": "Only tool that maps agent-to-agent connections and trust boundaries",
                        "mimic_only": True,
                    },
                    {
                        "feature": "Infection Simulation",
                        "description": "Simulates how prompt injection spreads through agent networks",
                        "mimic_only": True,
                    },
                    {
                        "feature": "Blast Radius Calculation",
                        "description": "Shows percentage of agents compromised from any entry point",
                        "mimic_only": True,
                    },
                    {
                        "feature": "24 Framework Support",
                        "description": "Most comprehensive multi-framework scanning in the market",
                        "mimic_only": True,
                    },
                ],
            }
        )

    # ==========================================================================
    # Health Check
    # ==========================================================================

    @app.route("/api/health")
    def health():
        """Health check endpoint."""
        return jsonify(
            {
                "status": "healthy",
                "version": "1.0.0",
                "timestamp": datetime.utcnow().isoformat(),
            }
        )

    return app


def run_server(
    host: str = "0.0.0.0",
    port: int = 8080,
    debug: bool = False,
) -> None:
    """Run the web server."""
    app = create_app()
    app.run(host=host, port=port, debug=debug)


if __name__ == "__main__":
    run_server(debug=True)
