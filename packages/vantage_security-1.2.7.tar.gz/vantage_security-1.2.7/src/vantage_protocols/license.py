"""
License Validation Protocol.

Defines the interface for license validation and feature gating.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Protocol, runtime_checkable


class Tier(str, Enum):
    """License tiers."""
    COMMUNITY = "community"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"


class Feature(str, Enum):
    """Available features that can be gated by license."""
    BASIC_SCANNING = "basic_scanning"
    FULL_PAYLOADS = "full_payloads"
    ML_DETECTION = "ml_detection"
    LIVE_LLM_TESTING = "live_llm_testing"
    COMPLIANCE_REPORTS = "compliance_reports"
    TEAM_DASHBOARD = "team_dashboard"
    CUSTOM_PAYLOADS = "custom_payloads"
    SSO_SAML = "sso_saml"
    AUDIT_LOGGING = "audit_logging"
    PRIORITY_SUPPORT = "priority_support"
    API_ACCESS = "api_access"
    WEBHOOKS = "webhooks"


# Feature availability by tier
TIER_FEATURES: dict[Tier, set[Feature]] = {
    Tier.COMMUNITY: {
        Feature.BASIC_SCANNING,
    },
    Tier.PROFESSIONAL: {
        Feature.BASIC_SCANNING,
        Feature.FULL_PAYLOADS,
        Feature.ML_DETECTION,
        Feature.LIVE_LLM_TESTING,
        Feature.COMPLIANCE_REPORTS,
        Feature.TEAM_DASHBOARD,
        Feature.API_ACCESS,
    },
    Tier.ENTERPRISE: {
        Feature.BASIC_SCANNING,
        Feature.FULL_PAYLOADS,
        Feature.ML_DETECTION,
        Feature.LIVE_LLM_TESTING,
        Feature.COMPLIANCE_REPORTS,
        Feature.TEAM_DASHBOARD,
        Feature.CUSTOM_PAYLOADS,
        Feature.SSO_SAML,
        Feature.AUDIT_LOGGING,
        Feature.PRIORITY_SUPPORT,
        Feature.API_ACCESS,
        Feature.WEBHOOKS,
    },
}


@dataclass
class LicenseInfo:
    """License information."""
    valid: bool
    tier: Tier
    organization: str | None = None
    email: str | None = None
    features: list[Feature] = field(default_factory=list)
    expires_at: datetime | None = None
    is_trial: bool = False
    seats: int = 1
    metadata: dict = field(default_factory=dict)

    def has_feature(self, feature: Feature) -> bool:
        """Check if license includes a feature."""
        return feature in self.features

    def is_expired(self) -> bool:
        """Check if license is expired."""
        if self.expires_at is None:
            return False
        return datetime.utcnow() > self.expires_at

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "valid": self.valid,
            "tier": self.tier.value,
            "organization": self.organization,
            "email": self.email,
            "features": [f.value for f in self.features],
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "is_trial": self.is_trial,
            "seats": self.seats,
        }


@runtime_checkable
class LicenseValidator(Protocol):
    """Interface for license validation."""

    def validate(self, key: str) -> LicenseInfo:
        """Validate a license key."""
        ...

    def check_feature(self, feature: Feature) -> bool:
        """Check if a feature is available with current license."""
        ...

    def get_current_license(self) -> LicenseInfo | None:
        """Get the currently active license."""
        ...

    def activate(self, key: str, device_id: str | None = None) -> LicenseInfo:
        """Activate a license key."""
        ...

    def deactivate(self) -> bool:
        """Deactivate the current license."""
        ...
