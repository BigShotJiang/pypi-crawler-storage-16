from .client import client

setup = client.setup
context = client.context
log = client.log
metric = client.metric
timer = client.timer
