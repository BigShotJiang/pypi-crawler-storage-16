from .core import fetch_random_lore

__all__ = ["fetch_random_lore"]
