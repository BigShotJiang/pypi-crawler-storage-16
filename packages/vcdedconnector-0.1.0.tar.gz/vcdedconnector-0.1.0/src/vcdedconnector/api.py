from __future__ import annotations

import json
import socket
import threading
import time
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Callable, List, Optional


class Vector3:
    __slots__ = ("x", "y", "z")

    def __init__(self, x: float, y: float, z: float) -> None:
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)

    def normalized(self) -> "Vector3":
        length = (self.x ** 2 + self.y ** 2 + self.z ** 2) ** 0.5
        if length == 0:
            return Vector3(0.0, 0.0, 0.0)
        return Vector3(self.x / length, self.y / length, self.z / length)

    def __iter__(self):
        yield self.x
        yield self.y
        yield self.z

    def __repr__(self) -> str:
        return f"Vector3(x={self.x!r}, y={self.y!r}, z={self.z!r})"


@dataclass
class Player:
    id: int
    nick: str
    kills: int
    deaths: int
    ping: int
    item_in_hand: int
    side: int
    class_id: int
    ip: str
    x: float
    y: float
    z: float

    @property
    def location(self) -> Vector3:
        return Vector3(self.x, self.y, self.z)


@dataclass
class MapEntry:
    index: int
    name: str
    type: int
    value: int
    current: bool = False

    @property
    def end_rule_type(self) -> int:
        return self.type

    @property
    def end_rule(self) -> str:
        if self.type == 1:
            return "time"
        elif self.type == 2:
            return "frags"
        elif self.type == 4:
            return "points"
        return "unknown"

    @property
    def end_rule_value(self) -> int:
        if self.type == 1:
            return int(self.value / 60)
        return self.value


@dataclass
class ChatMessageEventArgs:
    player: Optional[Player]
    message: str
    args: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.message:
            self.args = self.message.strip().split()


@dataclass
class ConnectionEventArgs:
    player: Optional[Player]


class MessageType(IntEnum):
    HOST_ON_DC = 1
    SERVER_MESSAGE = 2
    CONSOLE = 3


class Item(IntEnum):
    M16 = 1
    AK47 = 2
    M1Garand = 4
    PPS41 = 6
    ColtM1911 = 7
    TokarevPistol = 8
    MakarovPistol = 9
    Revolver38 = 10
    RemmingtonShotgun = 11
    WinchesterSniper = 12
    SVDDragunov = 14
    SksSimonov = 15
    M60Machinegun = 17
    Degtarjev = 18
    USM3 = 19
    Thompson = 21
    SaWModelSilenced = 22
    PPSH43 = 23
    M1Carabine = 25
    MosinNagant = 26
    M79GrenadeLauncher = 27
    DoubleBarelledShotgun = 28
    VCGrenade = 50
    C4Explosive = 55
    USGrenade = 59
    Radio = 60
    Medibag = 62
    Medikit = 63
    RedFlare = 140
    WhiteFlare = 149


class ExplosionType(IntEnum):
    Grenade = 1
    GrenadeLauncher = 2
    Mortar = 3


class VcdedAPI:
    """
    Python port C# třídy VcdedAPI.

    Příklad použití:

        api = VcdedAPI("127.0.0.1", 8192, allow_unsafe_communication=True)

        def on_chat(e: ChatMessageEventArgs):
            print(f"[CHAT] {e.player.nick if e.player else 'Unknown'}: {e.message}")

        api.add_chat_listener(on_chat)
    """

    def __init__(self, server_ip: str, port: int, allow_unsafe_communication: bool = False) -> None:
        self.server_ip: Optional[str] = None
        self.port: int = 0
        self._buffer_size = 8192

        self._chat_listeners: List[Callable[[ChatMessageEventArgs], None]] = []
        self._connection_listeners: List[Callable[[ConnectionEventArgs], None]] = []
        self._stop_event = threading.Event()

        if (
            server_ip.lower() != "localhost"
            and "127.0.0.1" not in server_ip
            and not allow_unsafe_communication
        ):
            print("Unsafe communication isn't allowed, allow it to use connector for remotes.")
            return

        self.server_ip = server_ip
        self.port = int(port)

        threading.Thread(target=self._monitor_chat, daemon=True).start()
        threading.Thread(target=self._monitor_connections, daemon=True).start()

    # Public API ---------------------------------------------------------

    def dispose(self) -> None:
        """Zastaví monitorovací thready."""
        self._stop_event.set()

    # Eventy -------------------------------------------------------------

    def add_chat_listener(self, callback: Callable[[ChatMessageEventArgs], None]) -> None:
        self._chat_listeners.append(callback)

    def remove_chat_listener(self, callback: Callable[[ChatMessageEventArgs], None]) -> None:
        if callback in self._chat_listeners:
            self._chat_listeners.remove(callback)

    def add_connection_listener(self, callback: Callable[[ConnectionEventArgs], None]) -> None:
        self._connection_listeners.append(callback)

    def remove_connection_listener(self, callback: Callable[[ConnectionEventArgs], None]) -> None:
        if callback in self._connection_listeners:
            self._connection_listeners.remove(callback)

    # Game actions -------------------------------------------------------

    def kick_player(self, player: Player) -> None:
        self.exec_raw(f"kick {player.id}")

    def ban_player(self, player: Player, time_minutes: int = 2) -> None:
        self.exec_raw(f"ban {player.id} {time_minutes}")

    def allow_player_spawn(self, player: Player) -> None:
        self._send_message(f"allowspawn {player.id}")

    def swap_player(self, player: Player) -> None:
        self._send_message(f"exec swapplayer {player.id}")

    def teleport_player(self, player: Player, location: Vector3) -> None:
        self._send_message(f"tp {location.x} {location.y} {location.z} {player.id}")

    def teleport_player_coords(self, player: Player, x: float, y: float, z: float) -> None:
        self._send_message(f"tp {x} {y} {z} {player.id}")

    def send_message_to_player(self, message_type: MessageType, player: Player, content: str) -> None:
        type_int = int(message_type)
        if type_int > 0:
            self._send_message(f"msg {player.id} {type_int} {content}")

    def restart_map(self) -> None:
        self._send_message("exec restartmap")

    def switch_map(self, map_entry: Optional[MapEntry] = None, index: Optional[int] = None) -> None:
        if map_entry is not None:
            self._send_message(f"exec nextmap {map_entry.index}")
        elif index is not None and index > -1:
            self._send_message(f"exec nextmap {index}")
        else:
            self._send_message("exec nextmap")

    def enable_friendly_fire(self, enabled: bool) -> None:
        self._send_message(f"exec set srvff {1 if enabled else 0}")

    def enable_vietnam_mode(self, enabled: bool) -> None:
        self._send_message(f"exec set srvvm {1 if enabled else 0}")

    def enable_vietnam_mode_chat(self, enabled: bool) -> None:
        self._send_message(f"exec set srvvmchat {1 if enabled else 0}")

    def enable_black_death_screen(self, enabled: bool) -> None:
        self._send_message(f"exec set srvbd {1 if enabled else 0}")

    def set_server_password(self, password: Optional[str] = None) -> None:
        self._send_message(f"exec set srvpassword {password or ''}")

    def set_admin_password(self, password: Optional[str] = None) -> None:
        self._send_message(f"exec set srvadmin {password or ''}")

    def set_spectators(self, count: int, delay: int) -> None:
        self._send_message(f"exec set srvspectators {count} {delay}")

    def say(self, message: str) -> None:
        safe = message.replace('"', "''")
        self._send_message(f'exec say "{safe}"')

    def admin_say(self, message: str) -> None:
        safe = message.replace('"', "''")
        self._send_message(f'exec adminsay "{safe}"')

    def ignore_messages_starts_with(self, symbol: str) -> None:
        if not symbol:
            return
        self._send_message(f"set_chat_prefix {symbol[0]}")

    # World actions ------------------------------------------------------

    def create_explosion(self, position: Vector3, explosion_type: ExplosionType) -> None:
        self._send_message(
            f"explosion {position.x} {position.y} {position.z} {int(explosion_type)}"
        )

    def spawn_item(self, position: Vector3, item: Item) -> None:
        self._send_message(
            f"spawnitem {position.x} {position.y} {position.z} {int(item)}"
        )

    def spawn_item_with_direction(self, position: Vector3, direction: Vector3, item: Item) -> None:
        self._send_message(
            f"spawnitemwithdirection {position.x} {position.y} {position.z} "
            f"{direction.x} {direction.y} {direction.z} {int(item)}"
        )

    # Queries ------------------------------------------------------------

    def get_players(self) -> List[Player]:
        if not self.server_ip or not self.port:
            return []

        json_str = self._send_message("get_players", wait_for_read=True)
        if not json_str:
            return []

        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            return []

        players_raw = data.get("players") or data.get("Players")
        if not players_raw:
            return []

        players: List[Player] = []
        for p in players_raw:
            try:
                players.append(
                    Player(
                        id=int(p.get("id")),
                        nick=p.get("nick", ""),
                        kills=int(p.get("kills", 0)),
                        deaths=int(p.get("deaths", 0)),
                        ping=int(p.get("ping", 0)),
                        item_in_hand=int(p.get("item", 0)),
                        side=int(p.get("side", 0)),
                        class_id=int(p.get("class", 0)),
                        ip=p.get("ip", ""),
                        x=float(p.get("x", 0.0)),
                        y=float(p.get("y", 0.0)),
                        z=float(p.get("z", 0.0)),
                    )
                )
            except (TypeError, ValueError):
                continue

        return players

    def get_players_count(self) -> int:
        return len(self.get_players())

    def get_maplist(self) -> List[MapEntry]:
        if not self.server_ip or not self.port:
            return []

        json_str = self._send_message("maplist", wait_for_read=True)
        if not json_str:
            return []

        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            return []

        maps_raw = data.get("maps") or data.get("Maps")
        if not maps_raw:
            return []

        maps: List[MapEntry] = []
        for m in maps_raw:
            try:
                maps.append(
                    MapEntry(
                        index=int(m.get("index")),
                        name=m.get("name", ""),
                        type=int(m.get("type", 0)),
                        value=int(m.get("value", 0)),
                        current=bool(m.get("current", False)),
                    )
                )
            except (TypeError, ValueError):
                continue

        return maps

    def get_current_map(self) -> Optional[MapEntry]:
        for m in self.get_maplist():
            if m.current:
                return m
        return None

    def exec_raw(self, command: str, recursive: bool = False) -> None:
        # V původním C# recursive stejně vždy skončí na SendMessage("exec " + command)
        self._send_message(f"exec {command}")

    # Internal helpers ---------------------------------------------------

    def _get_last_chat_message(self) -> Optional[str]:
        return self._send_message("last_message", wait_for_read=True)

    def _get_last_connected_player_raw(self) -> Optional[str]:
        return self._send_message("last_joined_player", wait_for_read=True)

    def _monitor_chat(self) -> None:
        last_chat_message = self._get_last_chat_message()
        while not self._stop_event.is_set():
            current_msg = self._get_last_chat_message()

            if (
                current_msg
                and current_msg != last_chat_message
                and ":|:" in current_msg
            ):
                parts = current_msg.split(":|:")
                if len(parts) >= 3:
                    try:
                        player_id = int(parts[1])
                    except ValueError:
                        player_id = -1

                    players = self.get_players()
                    player = next((pl for pl in players if pl.id == player_id), None)
                    content = parts[2].strip()
                    event = ChatMessageEventArgs(player=player, message=content)
                    for cb in list(self._chat_listeners):
                        try:
                            cb(event)
                        except Exception:
                            # nechceme shodit ostatní listenery
                            continue

            if current_msg is not None:
                last_chat_message = current_msg

            time.sleep(0.02)

    def _monitor_connections(self) -> None:
        last_connection = self._get_last_connected_player_raw()
        while not self._stop_event.is_set():
            current = self._get_last_connected_player_raw()

            if (
                current
                and current != last_connection
                and ":|:" in current
            ):
                parts = current.split(":|:")
                if len(parts) >= 2:
                    try:
                        player_id = int(parts[1])
                    except ValueError:
                        player_id = -1

                    players = self.get_players()
                    player = next((pl for pl in players if pl.id == player_id), None)
                    event = ConnectionEventArgs(player=player)
                    for cb in list(self._connection_listeners):
                        try:
                            cb(event)
                        except Exception:
                            continue

            if current is not None:
                last_connection = current

            time.sleep(0.02)

    def _send_message(self, message: str, wait_for_read: bool = False) -> Optional[str]:
        if not self.server_ip or not self.port:
            return None

        try:
            with socket.create_connection((self.server_ip, self.port)) as sock:
                sock.sendall(message.encode("utf-8"))

                if not wait_for_read:
                    return None

                sock.shutdown(socket.SHUT_WR)
                data = sock.recv(self._buffer_size)
                if not data:
                    return None
                return data.decode("utf-8", errors="replace")
        except OSError:
            return None


# Volitelné aliasy ve "C# stylu" (aby se to líp portovalo 1:1) ----------------

VcdedAPI.GetPlayers = VcdedAPI.get_players
VcdedAPI.GetMaplist = VcdedAPI.get_maplist
VcdedAPI.GetCurrentMap = VcdedAPI.get_current_map
VcdedAPI.KickPlayer = VcdedAPI.kick_player
VcdedAPI.BanPlayer = VcdedAPI.ban_player
VcdedAPI.AllowPlayerSpawn = VcdedAPI.allow_player_spawn
VcdedAPI.SwapPlayer = VcdedAPI.swap_player
VcdedAPI.TeleportPlayer = VcdedAPI.teleport_player
VcdedAPI.SendMessageToPlayer = VcdedAPI.send_message_to_player
VcdedAPI.RestartMap = VcdedAPI.restart_map
VcdedAPI.SwitchMap = VcdedAPI.switch_map
VcdedAPI.EnableFriendlyFire = VcdedAPI.enable_friendly_fire
VcdedAPI.EnableVietnamMode = VcdedAPI.enable_vietnam_mode
VcdedAPI.EnableVietnamModeChat = VcdedAPI.enable_vietnam_mode_chat
VcdedAPI.EnableBlackDeathScreen = VcdedAPI.enable_black_death_screen
VcdedAPI.SetServerPassword = VcdedAPI.set_server_password
VcdedAPI.SetAdminPassword = VcdedAPI.set_admin_password
VcdedAPI.SetSpectators = VcdedAPI.set_spectators
VcdedAPI.Say = VcdedAPI.say
VcdedAPI.AdminSay = VcdedAPI.admin_say
VcdedAPI.IgnoreMessagesStartsWith = VcdedAPI.ignore_messages_starts_with
VcdedAPI.CreateExplosion = VcdedAPI.create_explosion
VcdedAPI.SpawnItem = VcdedAPI.spawn_item
VcdedAPI.SpawnItemWithDirection = VcdedAPI.spawn_item_with_direction
VcdedAPI.GetPlayersCount = VcdedAPI.get_players_count
VcdedAPI.ExecRaw = VcdedAPI.exec_raw
