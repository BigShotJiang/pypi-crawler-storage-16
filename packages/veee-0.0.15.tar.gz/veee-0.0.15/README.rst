.. image:: https://images.unsplash.com/photo-1518292036709-53cac0e202c2
  :width: 700
  :alt: Alternative text

.. image:: https://img.shields.io/pypi/v/Veee.svg
    :alt: PyPI-Server
    :target: https://pypi.org/project/Veee/
.. image:: https://github.com/Clivern/Veee/actions/workflows/ci.yml/badge.svg
    :alt: Build Status
    :target: https://github.com/Clivern/Veee/actions/workflows/ci.yml

|

=====
Veee
=====

    API Integrations for Social Media Platforms.

