

```
python make_pipseeker_test_data.py \
  --out-root test_pipseeker_data \
  --n-genes 500 \
  --n-cells 100 \
  --lambda-total 1.2 \
  --lambda-exonic-fraction 0.7 \
  --seed 42
```
