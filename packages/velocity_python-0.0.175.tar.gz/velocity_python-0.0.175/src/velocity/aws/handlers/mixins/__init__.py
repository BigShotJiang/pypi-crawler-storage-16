"""
Mixins for AWS Lambda handlers.

This package exposes a single WebHandler mixin that unifies activity tracking,
logging, and error handling helpers for Lambda handlers.
"""

from .web_handler import WebHandler

__all__ = ['WebHandler']
