vfbLib.cmdline.vfb2ufo
======================

.. currentmodule:: vfbLib.cmdline

.. autofunction:: vfb2ufo