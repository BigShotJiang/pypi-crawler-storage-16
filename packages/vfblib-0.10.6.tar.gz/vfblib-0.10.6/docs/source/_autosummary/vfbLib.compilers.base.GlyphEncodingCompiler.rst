vfbLib.compilers.base.GlyphEncodingCompiler
===========================================

.. currentmodule:: vfbLib.compilers.base

.. autoclass:: GlyphEncodingCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GlyphEncodingCompiler.__init__
      ~GlyphEncodingCompiler.compile
      ~GlyphEncodingCompiler.compile_hex
      ~GlyphEncodingCompiler.merge
      ~GlyphEncodingCompiler.write_bytes
      ~GlyphEncodingCompiler.write_double
      ~GlyphEncodingCompiler.write_doubles
      ~GlyphEncodingCompiler.write_int16
      ~GlyphEncodingCompiler.write_int32
      ~GlyphEncodingCompiler.write_str
      ~GlyphEncodingCompiler.write_str_with_len
      ~GlyphEncodingCompiler.write_uint16
      ~GlyphEncodingCompiler.write_uint32
      ~GlyphEncodingCompiler.write_uint8
      ~GlyphEncodingCompiler.write_value
   
   

   
   
   