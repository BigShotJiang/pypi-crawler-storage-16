vfbLib.compilers.bitmap.BackgroundBitmapCompiler
================================================

.. currentmodule:: vfbLib.compilers.bitmap

.. autoclass:: BackgroundBitmapCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BackgroundBitmapCompiler.__init__
      ~BackgroundBitmapCompiler.compile
      ~BackgroundBitmapCompiler.compile_hex
      ~BackgroundBitmapCompiler.merge
      ~BackgroundBitmapCompiler.write_bytes
      ~BackgroundBitmapCompiler.write_double
      ~BackgroundBitmapCompiler.write_doubles
      ~BackgroundBitmapCompiler.write_int16
      ~BackgroundBitmapCompiler.write_int32
      ~BackgroundBitmapCompiler.write_str
      ~BackgroundBitmapCompiler.write_str_with_len
      ~BackgroundBitmapCompiler.write_uint16
      ~BackgroundBitmapCompiler.write_uint32
      ~BackgroundBitmapCompiler.write_uint8
      ~BackgroundBitmapCompiler.write_value
   
   

   
   
   