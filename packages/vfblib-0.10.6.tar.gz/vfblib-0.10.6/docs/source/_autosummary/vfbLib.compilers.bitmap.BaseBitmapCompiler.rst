vfbLib.compilers.bitmap.BaseBitmapCompiler
==========================================

.. currentmodule:: vfbLib.compilers.bitmap

.. autoclass:: BaseBitmapCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BaseBitmapCompiler.__init__
      ~BaseBitmapCompiler.compile
      ~BaseBitmapCompiler.compile_hex
      ~BaseBitmapCompiler.merge
      ~BaseBitmapCompiler.write_bytes
      ~BaseBitmapCompiler.write_double
      ~BaseBitmapCompiler.write_doubles
      ~BaseBitmapCompiler.write_int16
      ~BaseBitmapCompiler.write_int32
      ~BaseBitmapCompiler.write_str
      ~BaseBitmapCompiler.write_str_with_len
      ~BaseBitmapCompiler.write_uint16
      ~BaseBitmapCompiler.write_uint32
      ~BaseBitmapCompiler.write_uint8
      ~BaseBitmapCompiler.write_value
   
   

   
   
   