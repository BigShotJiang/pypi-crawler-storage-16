vfbLib.compilers.glyph.GlyphUnicodesCompiler
============================================

.. currentmodule:: vfbLib.compilers.glyph

.. autoclass:: GlyphUnicodesCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GlyphUnicodesCompiler.__init__
      ~GlyphUnicodesCompiler.compile
      ~GlyphUnicodesCompiler.compile_hex
      ~GlyphUnicodesCompiler.merge
      ~GlyphUnicodesCompiler.write_bytes
      ~GlyphUnicodesCompiler.write_double
      ~GlyphUnicodesCompiler.write_doubles
      ~GlyphUnicodesCompiler.write_int16
      ~GlyphUnicodesCompiler.write_int32
      ~GlyphUnicodesCompiler.write_str
      ~GlyphUnicodesCompiler.write_str_with_len
      ~GlyphUnicodesCompiler.write_uint16
      ~GlyphUnicodesCompiler.write_uint32
      ~GlyphUnicodesCompiler.write_uint8
      ~GlyphUnicodesCompiler.write_value
   
   

   
   
   