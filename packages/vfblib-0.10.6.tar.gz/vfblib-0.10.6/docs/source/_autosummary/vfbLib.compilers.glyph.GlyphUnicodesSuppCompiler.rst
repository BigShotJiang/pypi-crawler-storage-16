vfbLib.compilers.glyph.GlyphUnicodesSuppCompiler
================================================

.. currentmodule:: vfbLib.compilers.glyph

.. autoclass:: GlyphUnicodesSuppCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GlyphUnicodesSuppCompiler.__init__
      ~GlyphUnicodesSuppCompiler.compile
      ~GlyphUnicodesSuppCompiler.compile_hex
      ~GlyphUnicodesSuppCompiler.merge
      ~GlyphUnicodesSuppCompiler.write_bytes
      ~GlyphUnicodesSuppCompiler.write_double
      ~GlyphUnicodesSuppCompiler.write_doubles
      ~GlyphUnicodesSuppCompiler.write_int16
      ~GlyphUnicodesSuppCompiler.write_int32
      ~GlyphUnicodesSuppCompiler.write_str
      ~GlyphUnicodesSuppCompiler.write_str_with_len
      ~GlyphUnicodesSuppCompiler.write_uint16
      ~GlyphUnicodesSuppCompiler.write_uint32
      ~GlyphUnicodesSuppCompiler.write_uint8
      ~GlyphUnicodesSuppCompiler.write_value
   
   

   
   
   