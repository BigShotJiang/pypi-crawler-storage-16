vfbLib.compilers.glyph.InstructionsCompiler
===========================================

.. currentmodule:: vfbLib.compilers.glyph

.. autoclass:: InstructionsCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~InstructionsCompiler.__init__
      ~InstructionsCompiler.compile
      ~InstructionsCompiler.compile_hex
      ~InstructionsCompiler.merge
      ~InstructionsCompiler.write_bytes
      ~InstructionsCompiler.write_double
      ~InstructionsCompiler.write_doubles
      ~InstructionsCompiler.write_int16
      ~InstructionsCompiler.write_int32
      ~InstructionsCompiler.write_str
      ~InstructionsCompiler.write_str_with_len
      ~InstructionsCompiler.write_uint16
      ~InstructionsCompiler.write_uint32
      ~InstructionsCompiler.write_uint8
      ~InstructionsCompiler.write_value
   
   

   
   
   