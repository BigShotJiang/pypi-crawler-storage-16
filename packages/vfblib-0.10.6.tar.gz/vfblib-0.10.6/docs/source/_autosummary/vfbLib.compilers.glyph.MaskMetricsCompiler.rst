vfbLib.compilers.glyph.MaskMetricsCompiler
==========================================

.. currentmodule:: vfbLib.compilers.glyph

.. autoclass:: MaskMetricsCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MaskMetricsCompiler.__init__
      ~MaskMetricsCompiler.compile
      ~MaskMetricsCompiler.compile_hex
      ~MaskMetricsCompiler.merge
      ~MaskMetricsCompiler.write_bytes
      ~MaskMetricsCompiler.write_double
      ~MaskMetricsCompiler.write_doubles
      ~MaskMetricsCompiler.write_int16
      ~MaskMetricsCompiler.write_int32
      ~MaskMetricsCompiler.write_str
      ~MaskMetricsCompiler.write_str_with_len
      ~MaskMetricsCompiler.write_uint16
      ~MaskMetricsCompiler.write_uint32
      ~MaskMetricsCompiler.write_uint8
      ~MaskMetricsCompiler.write_value
   
   

   
   
   