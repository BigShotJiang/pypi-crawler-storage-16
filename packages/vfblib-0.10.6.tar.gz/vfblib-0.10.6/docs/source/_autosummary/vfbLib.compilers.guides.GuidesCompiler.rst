vfbLib.compilers.guides.GuidesCompiler
======================================

.. currentmodule:: vfbLib.compilers.guides

.. autoclass:: GuidesCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GuidesCompiler.__init__
      ~GuidesCompiler.compile
      ~GuidesCompiler.compile_hex
      ~GuidesCompiler.merge
      ~GuidesCompiler.write_bytes
      ~GuidesCompiler.write_double
      ~GuidesCompiler.write_doubles
      ~GuidesCompiler.write_int16
      ~GuidesCompiler.write_int32
      ~GuidesCompiler.write_str
      ~GuidesCompiler.write_str_with_len
      ~GuidesCompiler.write_uint16
      ~GuidesCompiler.write_uint32
      ~GuidesCompiler.write_uint8
      ~GuidesCompiler.write_value
   
   

   
   
   