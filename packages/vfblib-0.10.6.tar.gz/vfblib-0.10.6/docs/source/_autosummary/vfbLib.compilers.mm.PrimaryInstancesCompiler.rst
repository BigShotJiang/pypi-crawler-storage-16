vfbLib.compilers.mm.PrimaryInstancesCompiler
============================================

.. currentmodule:: vfbLib.compilers.mm

.. autoclass:: PrimaryInstancesCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PrimaryInstancesCompiler.__init__
      ~PrimaryInstancesCompiler.compile
      ~PrimaryInstancesCompiler.compile_hex
      ~PrimaryInstancesCompiler.merge
      ~PrimaryInstancesCompiler.write_bytes
      ~PrimaryInstancesCompiler.write_double
      ~PrimaryInstancesCompiler.write_doubles
      ~PrimaryInstancesCompiler.write_int16
      ~PrimaryInstancesCompiler.write_int32
      ~PrimaryInstancesCompiler.write_str
      ~PrimaryInstancesCompiler.write_str_with_len
      ~PrimaryInstancesCompiler.write_uint16
      ~PrimaryInstancesCompiler.write_uint32
      ~PrimaryInstancesCompiler.write_uint8
      ~PrimaryInstancesCompiler.write_value
   
   

   
   
   