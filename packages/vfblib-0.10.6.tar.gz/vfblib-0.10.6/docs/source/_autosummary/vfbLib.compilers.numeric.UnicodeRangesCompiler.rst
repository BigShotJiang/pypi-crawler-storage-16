vfbLib.compilers.numeric.UnicodeRangesCompiler
==============================================

.. currentmodule:: vfbLib.compilers.numeric

.. autoclass:: UnicodeRangesCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~UnicodeRangesCompiler.__init__
      ~UnicodeRangesCompiler.compile
      ~UnicodeRangesCompiler.compile_hex
      ~UnicodeRangesCompiler.merge
      ~UnicodeRangesCompiler.write_bytes
      ~UnicodeRangesCompiler.write_double
      ~UnicodeRangesCompiler.write_doubles
      ~UnicodeRangesCompiler.write_int16
      ~UnicodeRangesCompiler.write_int32
      ~UnicodeRangesCompiler.write_str
      ~UnicodeRangesCompiler.write_str_with_len
      ~UnicodeRangesCompiler.write_uint16
      ~UnicodeRangesCompiler.write_uint32
      ~UnicodeRangesCompiler.write_uint8
      ~UnicodeRangesCompiler.write_value
   
   

   
   
   