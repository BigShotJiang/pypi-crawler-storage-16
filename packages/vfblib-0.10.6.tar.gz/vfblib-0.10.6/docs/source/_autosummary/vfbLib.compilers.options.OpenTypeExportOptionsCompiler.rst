vfbLib.compilers.options.OpenTypeExportOptionsCompiler
======================================================

.. currentmodule:: vfbLib.compilers.options

.. autoclass:: OpenTypeExportOptionsCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~OpenTypeExportOptionsCompiler.__init__
      ~OpenTypeExportOptionsCompiler.compile
      ~OpenTypeExportOptionsCompiler.compile_hex
      ~OpenTypeExportOptionsCompiler.merge
      ~OpenTypeExportOptionsCompiler.write_bytes
      ~OpenTypeExportOptionsCompiler.write_double
      ~OpenTypeExportOptionsCompiler.write_doubles
      ~OpenTypeExportOptionsCompiler.write_int16
      ~OpenTypeExportOptionsCompiler.write_int32
      ~OpenTypeExportOptionsCompiler.write_str
      ~OpenTypeExportOptionsCompiler.write_str_with_len
      ~OpenTypeExportOptionsCompiler.write_uint16
      ~OpenTypeExportOptionsCompiler.write_uint32
      ~OpenTypeExportOptionsCompiler.write_uint8
      ~OpenTypeExportOptionsCompiler.write_value
   
   

   
   
   