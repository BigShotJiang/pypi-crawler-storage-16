vfbLib.compilers.ps.PostScriptGlyphHintingOptionsCompiler
=========================================================

.. currentmodule:: vfbLib.compilers.ps

.. autoclass:: PostScriptGlyphHintingOptionsCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PostScriptGlyphHintingOptionsCompiler.__init__
      ~PostScriptGlyphHintingOptionsCompiler.compile
      ~PostScriptGlyphHintingOptionsCompiler.compile_hex
      ~PostScriptGlyphHintingOptionsCompiler.merge
      ~PostScriptGlyphHintingOptionsCompiler.write_bytes
      ~PostScriptGlyphHintingOptionsCompiler.write_double
      ~PostScriptGlyphHintingOptionsCompiler.write_doubles
      ~PostScriptGlyphHintingOptionsCompiler.write_int16
      ~PostScriptGlyphHintingOptionsCompiler.write_int32
      ~PostScriptGlyphHintingOptionsCompiler.write_str
      ~PostScriptGlyphHintingOptionsCompiler.write_str_with_len
      ~PostScriptGlyphHintingOptionsCompiler.write_uint16
      ~PostScriptGlyphHintingOptionsCompiler.write_uint32
      ~PostScriptGlyphHintingOptionsCompiler.write_uint8
      ~PostScriptGlyphHintingOptionsCompiler.write_value
   
   

   
   
   