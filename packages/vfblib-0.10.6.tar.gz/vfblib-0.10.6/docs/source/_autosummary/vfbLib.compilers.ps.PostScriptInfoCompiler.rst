vfbLib.compilers.ps.PostScriptInfoCompiler
==========================================

.. currentmodule:: vfbLib.compilers.ps

.. autoclass:: PostScriptInfoCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PostScriptInfoCompiler.__init__
      ~PostScriptInfoCompiler.compile
      ~PostScriptInfoCompiler.compile_hex
      ~PostScriptInfoCompiler.merge
      ~PostScriptInfoCompiler.write_bytes
      ~PostScriptInfoCompiler.write_double
      ~PostScriptInfoCompiler.write_doubles
      ~PostScriptInfoCompiler.write_int16
      ~PostScriptInfoCompiler.write_int32
      ~PostScriptInfoCompiler.write_str
      ~PostScriptInfoCompiler.write_str_with_len
      ~PostScriptInfoCompiler.write_uint16
      ~PostScriptInfoCompiler.write_uint32
      ~PostScriptInfoCompiler.write_uint8
      ~PostScriptInfoCompiler.write_value
   
   

   
   
   