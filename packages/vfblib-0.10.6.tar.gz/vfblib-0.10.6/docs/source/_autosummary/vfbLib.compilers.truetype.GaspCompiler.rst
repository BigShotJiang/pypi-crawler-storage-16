vfbLib.compilers.truetype.GaspCompiler
======================================

.. currentmodule:: vfbLib.compilers.truetype

.. autoclass:: GaspCompiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GaspCompiler.__init__
      ~GaspCompiler.compile
      ~GaspCompiler.compile_hex
      ~GaspCompiler.merge
      ~GaspCompiler.write_bytes
      ~GaspCompiler.write_double
      ~GaspCompiler.write_doubles
      ~GaspCompiler.write_int16
      ~GaspCompiler.write_int32
      ~GaspCompiler.write_str
      ~GaspCompiler.write_str_with_len
      ~GaspCompiler.write_uint16
      ~GaspCompiler.write_uint32
      ~GaspCompiler.write_uint8
      ~GaspCompiler.write_value
   
   

   
   
   