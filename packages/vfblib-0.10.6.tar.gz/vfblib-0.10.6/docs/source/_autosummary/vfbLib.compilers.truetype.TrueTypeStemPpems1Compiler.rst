vfbLib.compilers.truetype.TrueTypeStemPpems1Compiler
====================================================

.. currentmodule:: vfbLib.compilers.truetype

.. autoclass:: TrueTypeStemPpems1Compiler
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TrueTypeStemPpems1Compiler.__init__
      ~TrueTypeStemPpems1Compiler.compile
      ~TrueTypeStemPpems1Compiler.compile_hex
      ~TrueTypeStemPpems1Compiler.merge
      ~TrueTypeStemPpems1Compiler.write_bytes
      ~TrueTypeStemPpems1Compiler.write_double
      ~TrueTypeStemPpems1Compiler.write_doubles
      ~TrueTypeStemPpems1Compiler.write_int16
      ~TrueTypeStemPpems1Compiler.write_int32
      ~TrueTypeStemPpems1Compiler.write_str
      ~TrueTypeStemPpems1Compiler.write_str_with_len
      ~TrueTypeStemPpems1Compiler.write_uint16
      ~TrueTypeStemPpems1Compiler.write_uint32
      ~TrueTypeStemPpems1Compiler.write_uint8
      ~TrueTypeStemPpems1Compiler.write_value
   
   

   
   
   