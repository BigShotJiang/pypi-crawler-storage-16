vfbLib.compilers.value.write\_value
===================================

.. currentmodule:: vfbLib.compilers.value

.. autofunction:: write_value