vfbLib.cu2qu.vfbcu2qu
=====================

.. currentmodule:: vfbLib.cu2qu

.. autofunction:: vfbcu2qu