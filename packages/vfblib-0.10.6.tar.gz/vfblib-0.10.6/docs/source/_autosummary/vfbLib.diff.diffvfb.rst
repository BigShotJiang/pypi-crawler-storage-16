vfbLib.diff.diffvfb
===================

.. currentmodule:: vfbLib.diff

.. autofunction:: diffvfb