vfbLib.helpers.binaryToIntList
==============================

.. currentmodule:: vfbLib.helpers

.. autofunction:: binaryToIntList