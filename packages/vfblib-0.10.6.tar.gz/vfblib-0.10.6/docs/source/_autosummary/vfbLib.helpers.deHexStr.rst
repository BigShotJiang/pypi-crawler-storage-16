vfbLib.helpers.deHexStr
=======================

.. currentmodule:: vfbLib.helpers

.. autofunction:: deHexStr