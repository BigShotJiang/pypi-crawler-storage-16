vfbLib.parsers.base
===================

.. automodule:: vfbLib.parsers.base
  
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      BaseParser
      EncodedKeyValuesParser
      EncodedValueListParser
      EncodedValueListWithCountParser
      GlyphEncodingParser
      MappingModeParser
      OpenTypeKerningClassFlagsParser
      OpenTypeMetricsClassFlagsParser
      StreamReader
   
   

   
   
   



