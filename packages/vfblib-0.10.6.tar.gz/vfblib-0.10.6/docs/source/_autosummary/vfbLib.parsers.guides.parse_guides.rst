vfbLib.parsers.guides.parse\_guides
===================================

.. currentmodule:: vfbLib.parsers.guides

.. autofunction:: parse_guides