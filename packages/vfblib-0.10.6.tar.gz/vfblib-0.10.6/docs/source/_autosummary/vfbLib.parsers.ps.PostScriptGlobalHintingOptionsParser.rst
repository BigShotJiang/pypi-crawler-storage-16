vfbLib.parsers.ps.PostScriptGlobalHintingOptionsParser
======================================================

.. currentmodule:: vfbLib.parsers.ps

.. autoclass:: PostScriptGlobalHintingOptionsParser
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PostScriptGlobalHintingOptionsParser.__init__
      ~PostScriptGlobalHintingOptionsParser.parse
      ~PostScriptGlobalHintingOptionsParser.parse_hex
      ~PostScriptGlobalHintingOptionsParser.read_double
      ~PostScriptGlobalHintingOptionsParser.read_doubles
      ~PostScriptGlobalHintingOptionsParser.read_int16
      ~PostScriptGlobalHintingOptionsParser.read_int32
      ~PostScriptGlobalHintingOptionsParser.read_int8
      ~PostScriptGlobalHintingOptionsParser.read_str
      ~PostScriptGlobalHintingOptionsParser.read_str_all
      ~PostScriptGlobalHintingOptionsParser.read_str_with_len
      ~PostScriptGlobalHintingOptionsParser.read_uint16
      ~PostScriptGlobalHintingOptionsParser.read_uint32
      ~PostScriptGlobalHintingOptionsParser.read_uint8
      ~PostScriptGlobalHintingOptionsParser.read_value
   
   

   
   
   