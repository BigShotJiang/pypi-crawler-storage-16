vfbLib.parsers.ps.PostScriptGlyphHintingOptionsParser
=====================================================

.. currentmodule:: vfbLib.parsers.ps

.. autoclass:: PostScriptGlyphHintingOptionsParser
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PostScriptGlyphHintingOptionsParser.__init__
      ~PostScriptGlyphHintingOptionsParser.parse
      ~PostScriptGlyphHintingOptionsParser.parse_hex
      ~PostScriptGlyphHintingOptionsParser.read_double
      ~PostScriptGlyphHintingOptionsParser.read_doubles
      ~PostScriptGlyphHintingOptionsParser.read_int16
      ~PostScriptGlyphHintingOptionsParser.read_int32
      ~PostScriptGlyphHintingOptionsParser.read_int8
      ~PostScriptGlyphHintingOptionsParser.read_str
      ~PostScriptGlyphHintingOptionsParser.read_str_all
      ~PostScriptGlyphHintingOptionsParser.read_str_with_len
      ~PostScriptGlyphHintingOptionsParser.read_uint16
      ~PostScriptGlyphHintingOptionsParser.read_uint32
      ~PostScriptGlyphHintingOptionsParser.read_uint8
      ~PostScriptGlyphHintingOptionsParser.read_value
   
   

   
   
   