vfbLib.parsers.truetype.TrueTypeStemPpems1Parser
================================================

.. currentmodule:: vfbLib.parsers.truetype

.. autoclass:: TrueTypeStemPpems1Parser
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TrueTypeStemPpems1Parser.__init__
      ~TrueTypeStemPpems1Parser.parse
      ~TrueTypeStemPpems1Parser.parse_hex
      ~TrueTypeStemPpems1Parser.read_double
      ~TrueTypeStemPpems1Parser.read_doubles
      ~TrueTypeStemPpems1Parser.read_int16
      ~TrueTypeStemPpems1Parser.read_int32
      ~TrueTypeStemPpems1Parser.read_int8
      ~TrueTypeStemPpems1Parser.read_str
      ~TrueTypeStemPpems1Parser.read_str_all
      ~TrueTypeStemPpems1Parser.read_str_with_len
      ~TrueTypeStemPpems1Parser.read_uint16
      ~TrueTypeStemPpems1Parser.read_uint32
      ~TrueTypeStemPpems1Parser.read_uint8
      ~TrueTypeStemPpems1Parser.read_value
   
   

   
   
   