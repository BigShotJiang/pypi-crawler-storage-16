vfbLib.parsers.value.read\_value
================================

.. currentmodule:: vfbLib.parsers.value

.. autofunction:: read_value