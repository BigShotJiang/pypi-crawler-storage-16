﻿vfbLib.templates
================

.. automodule:: vfbLib.templates
  
   
   
   

   
   
   

   
   
   

   
   
   



.. rubric:: Modules

.. autosummary::
   :toctree:
   :template: custom-module-template.rst
   :recursive:

   glyph

