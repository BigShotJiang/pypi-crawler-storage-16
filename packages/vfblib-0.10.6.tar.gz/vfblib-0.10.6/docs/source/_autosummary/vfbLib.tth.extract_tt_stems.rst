vfbLib.tth.extract\_tt\_stems
=============================

.. currentmodule:: vfbLib.tth

.. autofunction:: extract_tt_stems