vfbLib.typing.BBoxDict
======================

.. currentmodule:: vfbLib.typing

.. autoclass:: BBoxDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BBoxDict.__init__
      ~BBoxDict.clear
      ~BBoxDict.copy
      ~BBoxDict.fromkeys
      ~BBoxDict.get
      ~BBoxDict.items
      ~BBoxDict.keys
      ~BBoxDict.pop
      ~BBoxDict.popitem
      ~BBoxDict.setdefault
      ~BBoxDict.update
      ~BBoxDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~BBoxDict.xMin
      ~BBoxDict.yMin
      ~BBoxDict.xMax
      ~BBoxDict.yMax
   
   