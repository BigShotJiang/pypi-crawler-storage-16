vfbLib.typing.BackgroundImageDict
=================================

.. currentmodule:: vfbLib.typing

.. autoclass:: BackgroundImageDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BackgroundImageDict.__init__
      ~BackgroundImageDict.clear
      ~BackgroundImageDict.copy
      ~BackgroundImageDict.fromkeys
      ~BackgroundImageDict.get
      ~BackgroundImageDict.items
      ~BackgroundImageDict.keys
      ~BackgroundImageDict.pop
      ~BackgroundImageDict.popitem
      ~BackgroundImageDict.setdefault
      ~BackgroundImageDict.update
      ~BackgroundImageDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~BackgroundImageDict.origin
      ~BackgroundImageDict.size_units
      ~BackgroundImageDict.size_pixels
      ~BackgroundImageDict.bitmap
   
   