vfbLib.typing.FeatureDict
=========================

.. currentmodule:: vfbLib.typing

.. autoclass:: FeatureDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FeatureDict.__init__
      ~FeatureDict.clear
      ~FeatureDict.copy
      ~FeatureDict.fromkeys
      ~FeatureDict.get
      ~FeatureDict.items
      ~FeatureDict.keys
      ~FeatureDict.pop
      ~FeatureDict.popitem
      ~FeatureDict.setdefault
      ~FeatureDict.update
      ~FeatureDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~FeatureDict.tag
      ~FeatureDict.code
   
   