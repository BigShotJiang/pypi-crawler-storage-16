vfbLib.typing.GuideDict
=======================

.. currentmodule:: vfbLib.typing

.. autoclass:: GuideDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GuideDict.__init__
      ~GuideDict.clear
      ~GuideDict.copy
      ~GuideDict.fromkeys
      ~GuideDict.get
      ~GuideDict.items
      ~GuideDict.keys
      ~GuideDict.pop
      ~GuideDict.popitem
      ~GuideDict.setdefault
      ~GuideDict.update
      ~GuideDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~GuideDict.angle
      ~GuideDict.pos
   
   