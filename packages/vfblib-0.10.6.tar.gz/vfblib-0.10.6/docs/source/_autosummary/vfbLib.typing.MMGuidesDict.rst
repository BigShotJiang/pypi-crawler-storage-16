vfbLib.typing.MMGuidesDict
==========================

.. currentmodule:: vfbLib.typing

.. autoclass:: MMGuidesDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MMGuidesDict.__init__
      ~MMGuidesDict.clear
      ~MMGuidesDict.copy
      ~MMGuidesDict.fromkeys
      ~MMGuidesDict.get
      ~MMGuidesDict.items
      ~MMGuidesDict.keys
      ~MMGuidesDict.pop
      ~MMGuidesDict.popitem
      ~MMGuidesDict.setdefault
      ~MMGuidesDict.update
      ~MMGuidesDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MMGuidesDict.h
      ~MMGuidesDict.v
   
   