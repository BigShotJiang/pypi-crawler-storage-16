vfbLib.typing.MMHintsDict
=========================

.. currentmodule:: vfbLib.typing

.. autoclass:: MMHintsDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MMHintsDict.__init__
      ~MMHintsDict.clear
      ~MMHintsDict.copy
      ~MMHintsDict.fromkeys
      ~MMHintsDict.get
      ~MMHintsDict.items
      ~MMHintsDict.keys
      ~MMHintsDict.pop
      ~MMHintsDict.popitem
      ~MMHintsDict.setdefault
      ~MMHintsDict.update
      ~MMHintsDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MMHintsDict.h
      ~MMHintsDict.v
      ~MMHintsDict.hintmasks
   
   