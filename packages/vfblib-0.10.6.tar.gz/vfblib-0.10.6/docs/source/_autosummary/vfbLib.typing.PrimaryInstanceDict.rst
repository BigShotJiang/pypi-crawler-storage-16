vfbLib.typing.PrimaryInstanceDict
=================================

.. currentmodule:: vfbLib.typing

.. autoclass:: PrimaryInstanceDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PrimaryInstanceDict.__init__
      ~PrimaryInstanceDict.clear
      ~PrimaryInstanceDict.copy
      ~PrimaryInstanceDict.fromkeys
      ~PrimaryInstanceDict.get
      ~PrimaryInstanceDict.items
      ~PrimaryInstanceDict.keys
      ~PrimaryInstanceDict.pop
      ~PrimaryInstanceDict.popitem
      ~PrimaryInstanceDict.setdefault
      ~PrimaryInstanceDict.update
      ~PrimaryInstanceDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~PrimaryInstanceDict.name
   
   