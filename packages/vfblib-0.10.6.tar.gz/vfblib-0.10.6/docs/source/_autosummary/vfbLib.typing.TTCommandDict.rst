vfbLib.typing.TTCommandDict
===========================

.. currentmodule:: vfbLib.typing

.. autoclass:: TTCommandDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TTCommandDict.__init__
      ~TTCommandDict.clear
      ~TTCommandDict.copy
      ~TTCommandDict.fromkeys
      ~TTCommandDict.get
      ~TTCommandDict.items
      ~TTCommandDict.keys
      ~TTCommandDict.pop
      ~TTCommandDict.popitem
      ~TTCommandDict.setdefault
      ~TTCommandDict.update
      ~TTCommandDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TTCommandDict.name
      ~TTCommandDict.params
   
   