vfbLib.typing.TTStemDict
========================

.. currentmodule:: vfbLib.typing

.. autoclass:: TTStemDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TTStemDict.__init__
      ~TTStemDict.clear
      ~TTStemDict.copy
      ~TTStemDict.fromkeys
      ~TTStemDict.get
      ~TTStemDict.items
      ~TTStemDict.keys
      ~TTStemDict.pop
      ~TTStemDict.popitem
      ~TTStemDict.setdefault
      ~TTStemDict.update
      ~TTStemDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TTStemDict.name
      ~TTStemDict.round
      ~TTStemDict.stem
      ~TTStemDict.value
   
   