vfbLib.ufo.designspace.get\_ds\_design\_location
================================================

.. currentmodule:: vfbLib.ufo.designspace

.. autofunction:: get_ds_design_location