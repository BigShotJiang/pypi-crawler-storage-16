vfbLib.ufo.designspace
======================

.. automodule:: vfbLib.ufo.designspace
  
   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      get_ds_design_location
      get_ds_location
   
   

   
   
   

   
   
   



