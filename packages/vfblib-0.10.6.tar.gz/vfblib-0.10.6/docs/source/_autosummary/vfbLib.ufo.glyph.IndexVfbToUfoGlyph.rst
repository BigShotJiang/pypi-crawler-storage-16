vfbLib.ufo.glyph.IndexVfbToUfoGlyph
===================================

.. currentmodule:: vfbLib.ufo.glyph

.. autoclass:: IndexVfbToUfoGlyph
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~IndexVfbToUfoGlyph.__init__
      ~IndexVfbToUfoGlyph.get_point_label
      ~IndexVfbToUfoGlyph.set_mark
      ~IndexVfbToUfoGlyph.set_mask
   
   

   
   
   