vfbLib.ufo.glyph.VfbToUfoGlyph
==============================

.. currentmodule:: vfbLib.ufo.glyph

.. autoclass:: VfbToUfoGlyph
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VfbToUfoGlyph.__init__
      ~VfbToUfoGlyph.get_point_label
      ~VfbToUfoGlyph.set_mark
      ~VfbToUfoGlyph.set_mask
   
   

   
   
   