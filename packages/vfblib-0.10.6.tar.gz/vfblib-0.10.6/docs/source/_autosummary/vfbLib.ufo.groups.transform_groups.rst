vfbLib.ufo.groups.transform\_groups
===================================

.. currentmodule:: vfbLib.ufo.groups

.. autofunction:: transform_groups