vfbLib.ufo.kerning
==================

.. automodule:: vfbLib.ufo.kerning
  
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      UfoKerning
   
   

   
   
   



