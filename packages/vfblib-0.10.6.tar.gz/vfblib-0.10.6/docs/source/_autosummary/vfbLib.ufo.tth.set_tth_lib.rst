vfbLib.ufo.tth.set\_tth\_lib
============================

.. currentmodule:: vfbLib.ufo.tth

.. autofunction:: set_tth_lib