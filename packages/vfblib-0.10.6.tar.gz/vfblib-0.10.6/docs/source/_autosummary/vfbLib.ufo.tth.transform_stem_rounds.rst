vfbLib.ufo.tth.transform\_stem\_rounds
======================================

.. currentmodule:: vfbLib.ufo.tth

.. autofunction:: transform_stem_rounds