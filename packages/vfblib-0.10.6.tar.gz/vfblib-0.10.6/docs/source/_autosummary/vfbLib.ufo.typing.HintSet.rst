vfbLib.ufo.typing.HintSet
=========================

.. currentmodule:: vfbLib.ufo.typing

.. autoclass:: HintSet
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~HintSet.__init__
      ~HintSet.clear
      ~HintSet.copy
      ~HintSet.fromkeys
      ~HintSet.get
      ~HintSet.items
      ~HintSet.keys
      ~HintSet.pop
      ~HintSet.popitem
      ~HintSet.setdefault
      ~HintSet.update
      ~HintSet.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~HintSet.pointTag
      ~HintSet.stems
   
   