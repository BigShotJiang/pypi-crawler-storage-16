vfbLib.ufo.typing.TUfoRawStemsDict
==================================

.. currentmodule:: vfbLib.ufo.typing

.. autoclass:: TUfoRawStemsDict
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TUfoRawStemsDict.__init__
      ~TUfoRawStemsDict.clear
      ~TUfoRawStemsDict.copy
      ~TUfoRawStemsDict.fromkeys
      ~TUfoRawStemsDict.get
      ~TUfoRawStemsDict.items
      ~TUfoRawStemsDict.keys
      ~TUfoRawStemsDict.pop
      ~TUfoRawStemsDict.popitem
      ~TUfoRawStemsDict.setdefault
      ~TUfoRawStemsDict.update
      ~TUfoRawStemsDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TUfoRawStemsDict.ttStemsH
      ~TUfoRawStemsDict.ttStemsV
   
   