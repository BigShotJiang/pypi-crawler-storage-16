vfbLib.vfb.glyph.VfbGlyph
=========================

.. currentmodule:: vfbLib.vfb.glyph

.. autoclass:: VfbGlyph
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VfbGlyph.__init__
      ~VfbGlyph.clearContours
      ~VfbGlyph.decompile
      ~VfbGlyph.draw
      ~VfbGlyph.drawPoints
      ~VfbGlyph.drawPointsDirect
      ~VfbGlyph.empty
      ~VfbGlyph.getPen
      ~VfbGlyph.getPointPen
      ~VfbGlyph.resolve_hint_sets
      ~VfbGlyph.resolve_hints
      ~VfbGlyph.resolve_links
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~VfbGlyph.name
   
   