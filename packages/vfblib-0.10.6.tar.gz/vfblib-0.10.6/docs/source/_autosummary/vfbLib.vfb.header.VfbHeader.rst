vfbLib.vfb.header.VfbHeader
===========================

.. currentmodule:: vfbLib.vfb.header

.. autoclass:: VfbHeader
   :members:
   :show-inheritance:
   :inherited-members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VfbHeader.__init__
      ~VfbHeader.as_dict
      ~VfbHeader.compile
      ~VfbHeader.decompile
      ~VfbHeader.read
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~VfbHeader.data
   
   