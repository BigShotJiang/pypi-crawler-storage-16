#!/usr/bin/python3
# Initialisation for the vhsdecode package.
