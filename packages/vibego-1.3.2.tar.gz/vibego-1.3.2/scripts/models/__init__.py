"""模型脚本目录，标记为 Python 包以便 setuptools 正确打包。"""

# 仅用于声明包存在，shell 脚本会作为 package data 一起分发。
