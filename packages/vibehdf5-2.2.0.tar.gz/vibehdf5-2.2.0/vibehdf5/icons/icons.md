Icons from https://www.flaticon.com

<a href="https://www.flaticon.com/free-icons/csv-file" title="csv file icons">Csv file icons created by juicy_fish - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/json-file" title="json file icons">Json file icons created by Smashicons - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/html" title="html icons">Html icons created by Smashicons - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/markdown" title="markdown icons">Markdown icons created by brajaomar_j - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/microsoft-excel-file" title="microsoft excel file icons">Microsoft excel file icons created by mpanicon - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/files-and-folders" title="files and folders icons">Files and folders icons created by nangicon - Flaticon</a>