"""FastAPI API for VibeLab."""

from .app import app

__all__ = ["app"]
