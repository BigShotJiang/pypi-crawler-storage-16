"""CLI commands for VibeLab."""

from .main import app

__all__ = ["app"]
