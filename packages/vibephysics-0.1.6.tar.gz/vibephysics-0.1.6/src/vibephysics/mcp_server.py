#!/usr/bin/env python3
"""
VibePhysics MCP Server - Connects Cursor to Blender

This script runs as an MCP server that Cursor can launch.
It connects to Blender's socket server (mcp_addon_vibephysics.py) on port 9527.

Usage:
    uvx vibephysics-mcp
    # or
    python -m vibephysics.mcp_server
"""

import json
import socket
import sys

# MCP Protocol helpers
def send_response(response):
    """Send JSON-RPC response to stdout."""
    msg = json.dumps(response)
    sys.stdout.write(f"Content-Length: {len(msg)}\r\n\r\n{msg}")
    sys.stdout.flush()

def read_request():
    """Read JSON-RPC request from stdin."""
    headers = {}
    while True:
        line = sys.stdin.readline()
        if line == "\r\n" or line == "\n":
            break
        if ":" in line:
            key, value = line.split(":", 1)
            headers[key.strip()] = value.strip()
    
    content_length = int(headers.get("Content-Length", 0))
    if content_length > 0:
        content = sys.stdin.read(content_length)
        return json.loads(content)
    return None

def send_to_blender(command, params=None, host="localhost", port=9527):
    """Send command to Blender and get response."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((host, port))
        sock.settimeout(30.0)
        
        message = {"type": command, "params": params or {}}
        sock.sendall(json.dumps(message).encode("utf-8"))
        
        response = b""
        while True:
            chunk = sock.recv(8192)
            if not chunk:
                break
            response += chunk
            try:
                return json.loads(response.decode("utf-8"))
            except json.JSONDecodeError:
                continue
        
        sock.close()
        return {"error": "No response from Blender"}
    except ConnectionRefusedError:
        return {"error": "Cannot connect to Blender. Make sure the addon is running."}
    except Exception as e:
        return {"error": str(e)}

# Tool definitions for MCP
TOOLS = [
    {
        "name": "get_scene_info",
        "description": "Get information about the current Blender scene",
        "inputSchema": {"type": "object", "properties": {}}
    },
    {
        "name": "execute_code",
        "description": "Execute Python code in Blender",
        "inputSchema": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "Python code to execute"}
            },
            "required": ["code"]
        }
    },
    {
        "name": "vp_init_simulation",
        "description": "Initialize a physics simulation scene",
        "inputSchema": {
            "type": "object",
            "properties": {
                "start_frame": {"type": "integer", "default": 1},
                "end_frame": {"type": "integer", "default": 250},
                "clear": {"type": "boolean", "default": True}
            }
        }
    },
    {
        "name": "vp_create_visual_water",
        "description": "Create visual water surface with waves",
        "inputSchema": {
            "type": "object",
            "properties": {
                "scale": {"type": "number", "description": "Size of water plane"},
                "wave_scale": {"type": "number", "description": "Scale of waves"},
                "start_frame": {"type": "integer", "default": 1},
                "end_frame": {"type": "integer", "default": 250}
            },
            "required": ["scale", "wave_scale"]
        }
    },
    {
        "name": "vp_create_falling_spheres",
        "description": "Create falling spheres with physics",
        "inputSchema": {
            "type": "object",
            "properties": {
                "positions": {"type": "array", "description": "List of [x, y, z] positions"},
                "radius_range": {"type": "array", "default": [0.15, 0.3]}
            },
            "required": ["positions"]
        }
    },
    {
        "name": "vp_setup_lighting",
        "description": "Setup scene lighting",
        "inputSchema": {
            "type": "object",
            "properties": {
                "resolution_x": {"type": "integer", "default": 1920},
                "resolution_y": {"type": "integer", "default": 1080},
                "start_frame": {"type": "integer", "default": 1},
                "end_frame": {"type": "integer", "default": 250}
            }
        }
    },
    {
        "name": "vp_save_blend",
        "description": "Save the Blender file",
        "inputSchema": {
            "type": "object",
            "properties": {
                "filepath": {"type": "string", "description": "Path to save the .blend file"}
            }
        }
    },
    {
        "name": "list_available_commands",
        "description": "List all available vibephysics commands",
        "inputSchema": {"type": "object", "properties": {}}
    }
]

def handle_request(request):
    """Handle incoming MCP request."""
    method = request.get("method")
    params = request.get("params", {})
    req_id = request.get("id")
    
    if method == "initialize":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "vibephysics-mcp", "version": "0.1.0"}
            }
        }
    
    elif method == "tools/list":
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {"tools": TOOLS}
        }
    
    elif method == "tools/call":
        tool_name = params.get("name")
        tool_args = params.get("arguments", {})
        
        # Send to Blender
        result = send_to_blender(tool_name, tool_args)
        
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "content": [{"type": "text", "text": json.dumps(result, indent=2)}]
            }
        }
    
    elif method == "notifications/initialized":
        return None  # No response needed
    
    else:
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "error": {"code": -32601, "message": f"Unknown method: {method}"}
        }

def main():
    """Main MCP server loop."""
    while True:
        try:
            request = read_request()
            if request is None:
                break
            
            response = handle_request(request)
            if response:
                send_response(response)
                
        except KeyboardInterrupt:
            break
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            break

if __name__ == "__main__":
    main()
