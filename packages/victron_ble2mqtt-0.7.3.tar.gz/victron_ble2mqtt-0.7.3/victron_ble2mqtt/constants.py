from pathlib import Path

import victron_ble2mqtt


CLI_EPILOG = 'Project Homepage: https://github.com/jedie/victron-ble2mqtt'

BASE_PATH = Path(victron_ble2mqtt.__file__).parent
