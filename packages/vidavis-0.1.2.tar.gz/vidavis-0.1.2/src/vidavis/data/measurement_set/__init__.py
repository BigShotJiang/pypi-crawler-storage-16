''' Module to access MeasurementSet data using MsData class. '''
