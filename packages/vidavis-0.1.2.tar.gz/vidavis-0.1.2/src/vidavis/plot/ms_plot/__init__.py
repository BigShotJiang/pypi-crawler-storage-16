''' This module contains classes and utilities to support MS plotting '''
