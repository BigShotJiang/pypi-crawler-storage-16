# VideoSDK Assembly AI Plugin

Agent Framework plugin for STT services from Assembly AI.

## Installation

```bash
pip install videosdk-plugins-assemblyai
```