# VideoSDK Papla Media Plugin

Agent Framework plugin for TTS services from Papla Media.

## Installation

```bash
pip install videosdk-plugins-papla
```