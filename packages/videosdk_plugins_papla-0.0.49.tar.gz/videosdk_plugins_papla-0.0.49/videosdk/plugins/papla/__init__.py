from .tts import PaplaTTS

__all__ = [
    'PaplaTTS',
]