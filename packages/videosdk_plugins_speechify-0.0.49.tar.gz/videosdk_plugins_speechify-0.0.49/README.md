# VideoSDK Speechify Plugin

Agent Framework plugin for TTS services from Speechify.

## Installation

```bash
pip install videosdk-plugins-speechify
```
