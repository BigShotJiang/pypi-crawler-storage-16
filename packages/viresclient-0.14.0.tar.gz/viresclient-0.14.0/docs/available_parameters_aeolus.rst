Available parameters for Aeolus
===============================

.. note::
  Details to follow. See https://notebooks.aeolus.services for examples.
