"""Tests for the virgo.actions package."""
