"""Tests for the virgo.cli package."""
