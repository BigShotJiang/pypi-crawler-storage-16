"""Main entry point for the Virgo CLI."""

from virgo.cli import app

if __name__ == "__main__":
    app()
