"""This package contains classes that extend the KnitGraph data structure to retain a history of needle movements associated with creation of a knitted object on a machine."""
