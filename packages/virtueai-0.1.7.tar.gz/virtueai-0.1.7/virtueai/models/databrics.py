from enum import Enum

class DatabricksDbModel(Enum):
    META_LLAMA_3_1_8B_INSTRUCT = "databricks-meta-llama-3-1-8b-instruct"
