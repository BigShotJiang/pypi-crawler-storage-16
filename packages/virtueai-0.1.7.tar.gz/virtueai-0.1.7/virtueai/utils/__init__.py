from .logger import init_logger

__all__ = [
    "init_logger"
]