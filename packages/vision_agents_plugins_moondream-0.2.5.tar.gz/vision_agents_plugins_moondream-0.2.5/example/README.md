## Moondream example
Please see root readme for details. 