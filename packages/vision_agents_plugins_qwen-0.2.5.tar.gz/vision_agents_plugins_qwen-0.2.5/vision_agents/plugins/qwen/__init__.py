from .qwen_realtime import Qwen3Realtime as Realtime

__all__ = ["Realtime"]
