from .vogent_turn_detection import VogentTurnDetection
from .vogent_turn_detection import VogentTurnDetection as TurnDetection


__all__ = ["TurnDetection", "VogentTurnDetection"]
