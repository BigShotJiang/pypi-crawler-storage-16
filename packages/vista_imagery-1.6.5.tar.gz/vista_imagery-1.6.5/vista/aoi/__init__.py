"""AOI (Area of Interest) / ROI (Region of Interest) package"""
from .aoi import AOI

__all__ = ['AOI']
