import pathlib


SIMULATION_DATA_DIR = pathlib.Path(__file__).parent
EARTH_IMAGE = SIMULATION_DATA_DIR / "earth_image.png"