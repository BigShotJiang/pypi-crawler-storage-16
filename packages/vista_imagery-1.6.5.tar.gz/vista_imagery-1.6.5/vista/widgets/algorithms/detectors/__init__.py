"""Detection algorithm widgets"""
from .cfar_widget import CFARWidget
from .simple_threshold_widget import SimpleThresholdWidget

__all__ = ['CFARWidget', 'SimpleThresholdWidget']
