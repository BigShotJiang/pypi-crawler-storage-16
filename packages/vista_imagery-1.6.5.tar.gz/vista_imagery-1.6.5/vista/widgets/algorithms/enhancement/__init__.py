"""Image enhancement widgets"""
from .coaddition_widget import CoadditionWidget

__all__ = ['CoadditionWidget']
