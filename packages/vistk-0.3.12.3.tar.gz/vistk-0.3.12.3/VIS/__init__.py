__version__="0.2.0"
__author__="Elijah Love"
__all__ = [
    "menu",
    "fUtil"
]