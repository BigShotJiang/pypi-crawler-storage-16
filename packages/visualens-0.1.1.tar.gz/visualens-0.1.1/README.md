# Lenstool GUI

A visual interface to explore astronomical images, catalogs, and lens models created using Lenstool.






Notes:
- If you install Spyder in a conda virtual environment where you have previously installed visualens with pip, it might crash (this is because of pyQt5's install required by visualens). Instead, install Spyder first and everything should be fine.
