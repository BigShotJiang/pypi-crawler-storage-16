## TO DO: source extraction that doesn't depend on SExtractor being installed ##


def source_extract() :
    return None


def source_extract_DIM() :
    return None














