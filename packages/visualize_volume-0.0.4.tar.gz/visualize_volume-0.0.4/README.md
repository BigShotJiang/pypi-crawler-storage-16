# visualize_volume
Visualize 3D volume data.

GitHub project: [https://github.com/GGN-2015/visualize_volume](https://github.com/GGN-2015/visualize_volume)

## Installation
```bash
pip install visualize_volume
```

## Usage
```python
import visualize_volume
data3d = visualize_volume.create_centered_cube_3d((64, 64, 64), 24)
visualize_volume.visualize_volume(data3d) # you can fill in your numpy data
```

## Default Values

Argument `value_rgba_color_map` gives the map from data value to the color (RGBA).

```python
def visualize_volume(data: np.ndarray, 
    value_rgba_color_map=[
        (-5.0, 0.0, 0.0,   0.8, 0.9), # Dark blue
        (-4.0, 0.5, 0.0,   0.5, 0.9), # Purple
        (-3.0, 1.0, 0.0,   1.0, 0.9), # Magenta
        (-2.0, 0.0, 1.0,   1.0, 0.9), # Cyan
        (-1.0, 0.0, 0.8,   0.0, 0.9), # Dark green
        ( 0.0, 0.0, 0.0,   0.0, 0.0), # Transparent
        ( 1.0, 1.0, 0.0,   0.0, 0.9), # Red
        ( 2.0, 1.0, 0.843, 0.0, 0.9), # Gold
    ], 
    back_ground_color=(0.1, 0.2, 0.3), # Dark slate blue background
    back_ground_alpha=1.0
): ...
```
