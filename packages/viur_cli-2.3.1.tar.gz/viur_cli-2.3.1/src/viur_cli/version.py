__version__ = "2.3.1"
MINIMAL_PIPENV = "2023.11.15"
