**1.0.2 - 12/10/25**

 - Add dependency: sphinx-rtd-theme>=2.0.0

**1.0.1 - 8/1/25**

 - Add dependency: numpy<2.0.0

**1.0.0 - 7/31/25**

 - Initial release

**0.1.0 - 7/29/25**

 - Initial release candidate
