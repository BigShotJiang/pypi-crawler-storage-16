.. automodule:: vivarium_public_health.population.add_new_birth_cohorts
