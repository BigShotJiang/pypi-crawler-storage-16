.. automodule:: vivarium_public_health.results.stratification
