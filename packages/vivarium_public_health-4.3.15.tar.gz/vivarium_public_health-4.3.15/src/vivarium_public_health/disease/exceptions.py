from vivarium.exceptions import VivariumError


class DiseaseModelError(VivariumError):
    pass
