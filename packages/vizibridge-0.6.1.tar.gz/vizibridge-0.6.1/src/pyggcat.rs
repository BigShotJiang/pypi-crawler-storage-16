use vizitig_lib::ggcat_integration::{build_gcalm};
use std::path::PathBuf;
use pyo3::pyfunction;

/// This function provides an entry-point into ggcat-api to build a graph from a collections of
/// files. 
///
/// input_files: is a list of path toward possibly compressed files
/// thread_count: provides a limit on the number of thread used by ggcat
/// output: is a path to write the resulting graph
/// k: is the kmer size
/// min_multiplicity is the minimal number of time a kmer should be encoutered to be considered
#[pyfunction]
pub fn build_graph(
    input_files: Vec<PathBuf>,
    thread_count: usize,
    output: PathBuf,
    k: usize,
    min_multiplicity: usize,
) {
    build_gcalm(input_files, 2.0, thread_count, output, k, min_multiplicity)
}
