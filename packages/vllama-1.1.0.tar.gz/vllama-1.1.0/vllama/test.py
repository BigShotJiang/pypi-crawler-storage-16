from core import *

if __name__ == "__main__":
    # text_to_speech("Hello world this is Manvith building the text to speech module with in built library of python")
    # text_to_speech()
    # text_to_speech("exit")

    # list_downloads()
    translation = translate_fast("Hello world, My name is Manvith I am from india")
    print(translation)