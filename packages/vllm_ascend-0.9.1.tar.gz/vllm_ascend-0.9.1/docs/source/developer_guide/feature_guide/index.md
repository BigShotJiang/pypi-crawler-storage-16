# Feature Guide

This section provides an overview of the features implemented in vLLM Ascend. Developers can refer to this guide to understand how vLLM Ascend works.

:::{toctree}
:caption: Feature Guide
:maxdepth: 1
patch
:::
