# Modeling

This section provides tutorials of how to implement and register a new model into vllm-ascend.

:::{toctree}
:caption: Modeling
:maxdepth: 1
adding_a_new_model
adding_a_new_multimodal_model
:::
