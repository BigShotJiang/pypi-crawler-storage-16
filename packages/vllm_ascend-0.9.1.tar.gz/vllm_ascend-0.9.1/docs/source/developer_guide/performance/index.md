# Performance

:::{toctree}
:caption: Performance
:maxdepth: 1
performance_benchmark
profile_execute_duration
optimization_and_tuning
:::
