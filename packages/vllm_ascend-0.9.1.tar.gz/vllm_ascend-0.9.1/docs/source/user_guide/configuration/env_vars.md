# Environment Variables

vllm-ascend uses the following environment variables to configure the system:

:::{literalinclude} ../../../../vllm_ascend/envs.py
:language: python
:start-after: begin-env-vars-definition
:end-before: end-env-vars-definition
:::
