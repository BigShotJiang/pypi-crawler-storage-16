"""vLLM MCP Server - Expose vLLM capabilities to MCP clients."""

__version__ = "0.1.0"

