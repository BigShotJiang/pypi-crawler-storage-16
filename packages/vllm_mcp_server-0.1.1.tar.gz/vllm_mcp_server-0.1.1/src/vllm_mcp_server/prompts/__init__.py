"""MCP Prompts for vLLM Server."""

from vllm_mcp_server.prompts.system_prompts import PROMPTS, get_prompt

__all__ = ["PROMPTS", "get_prompt"]

