"""Tests for vLLM MCP Server."""

