from __future__ import annotations

import os
import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Literal

import torch

from .planner import make_plan, Plan

PerfMode = Literal["throughput", "latency"]


@dataclass
class SamplingConfig:
    temperature: float = 0.0
    top_p: float = 1.0
    max_tokens: int = 32
    stop: Optional[List[str]] = None


def _configure_python_logging(debug: bool) -> None:
    level = logging.DEBUG if debug else logging.INFO
    root = logging.getLogger()
    if not root.handlers:
        logging.basicConfig(
            level=level,
            format="[%(asctime)s] %(levelname)s %(name)s:%(lineno)d: %(message)s",
        )
    else:
        root.setLevel(level)


class AutoVLLMClient:
    def __init__(
            self,
            model_name: str,
            context_len: int,
            *,
            device_index: int = 0,
            perf_mode: PerfMode = "throughput",
            trust_remote_code: bool = False,
            prefer_fp8_kv_cache: bool = False,
            enforce_eager: bool = False,
            local_files_only: bool = False,
            cache_plan: bool = True,
            debug: bool = False,
            vllm_logging_level: Optional[str] = None,
            # Mistral compatibility knobs (set these when you load a Mistral-formatted model)
            tokenizer_mode: Optional[str] = None,
            load_format: Optional[str] = None,
            config_format: Optional[str] = None,
    ):
        self.model_name = model_name
        self.context_len = int(context_len)
        self.debug = bool(debug)

        _configure_python_logging(self.debug)
        log = logging.getLogger(__name__)

        # Must be set BEFORE importing vllm anywhere
        os.environ.setdefault("VLLM_ENABLE_V1_MULTIPROCESSING", "0")
        if vllm_logging_level is None:
            vllm_logging_level = "DEBUG" if self.debug else "INFO"
        os.environ.setdefault("VLLM_LOGGING_LEVEL", vllm_logging_level.upper())

        # Import vLLM after env vars
        from vllm import LLM, SamplingParams, TokensPrompt  # noqa: WPS433

        self._LLM = LLM
        self._SamplingParams = SamplingParams
        self._TokensPrompt = TokensPrompt

        self.plan: Plan = make_plan(
            model_name=model_name,
            context_len=self.context_len,
            device_index=device_index,
            perf_mode=perf_mode,
            trust_remote_code=trust_remote_code,
            prefer_fp8_kv_cache=prefer_fp8_kv_cache,
            enforce_eager=enforce_eager,
            local_files_only=local_files_only,
            cache=cache_plan,
        )

        # Debug: let vLLM print more internal stats
        if self.debug:
            self.plan.vllm_kwargs["disable_log_stats"] = False

        # We will use vLLM's tokenizer, so tokenizer init must NOT be skipped.
        # (Otherwise you get EOS=None behavior / warnings.)
        self.plan.vllm_kwargs["skip_tokenizer_init"] = False

        # Mistral compatibility (per vLLM docs: tokenizer_mode/load_format/config_format="mistral")
        # Only set if explicitly provided, to avoid forcing a format for non-Mistral models.
        if tokenizer_mode is not None:
            self.plan.vllm_kwargs["tokenizer_mode"] = tokenizer_mode
        if load_format is not None:
            self.plan.vllm_kwargs["load_format"] = load_format
        if config_format is not None:
            self.plan.vllm_kwargs["config_format"] = config_format

        log.info("AutoVLLMClient plan cache_key=%s", self.plan.cache_key)
        log.info("Plan notes: %s", self.plan.notes)
        if self.plan.notes.get("fp8_ignored_reason"):
            log.warning(self.plan.notes["fp8_ignored_reason"])

        self.llm = self._LLM(**self.plan.vllm_kwargs)

        # Use vLLM-selected tokenizer (can be HF-backed wrapper or a custom tokenizer like Mistral)
        self.tokenizer = self.llm.get_tokenizer()

    def _messages_to_text(self, messages: List[Dict[str, str]]) -> str:
        # vLLM tokenizer wrappers typically follow HF apply_chat_template behavior:
        # tokenize=False => returns a string prompt.
        return self.tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )

    def _batch_tokenize_messages(self, prompts: List[Dict[str, Any]]) -> List[Any]:
        texts = [self._messages_to_text(p["messages"]) for p in prompts]
        enc = self.tokenizer(
            texts,
            padding=False,
            truncation=False,
            add_special_tokens=False,
            return_attention_mask=False,
        )
        return [self._TokensPrompt(prompt_token_ids=ids) for ids in enc["input_ids"]]

    def run_batch(
            self,
            prompts: List[Dict[str, Any]],
            sampling: SamplingConfig,
            output_field: str = "output",
    ) -> List[Dict[str, Any]]:
        stop_token_ids = None
        eos_id = getattr(self.tokenizer, "eos_token_id", None)
        if eos_id is not None:
            stop_token_ids = [int(eos_id)]

        params = self._SamplingParams(
            temperature=float(sampling.temperature),
            top_p=float(sampling.top_p),
            max_tokens=int(sampling.max_tokens),
            stop=sampling.stop,
            stop_token_ids=stop_token_ids,
        )

        tokenized = self._batch_tokenize_messages(prompts)
        outputs = self.llm.generate(
            prompts=tokenized,
            sampling_params=params,
            use_tqdm=self.debug,
        )

        results: List[Dict[str, Any]] = []
        for i, out in enumerate(outputs):
            meta = prompts[i].get("metadata", {})
            comp = out.outputs[0]

            token_ids = getattr(comp, "token_ids", None)
            if token_ids is not None:
                text = self.tokenizer.decode(token_ids, skip_special_tokens=True)
            else:
                text = (getattr(comp, "text", "") or "")

            results.append({**meta, output_field: text.strip()})
        return results

    def close(self) -> None:
        try:
            del self.llm
        finally:
            torch.cuda.empty_cache()
            try:
                import torch.distributed as dist

                if dist.is_available() and dist.is_initialized():
                    dist.destroy_process_group()
            except Exception:
                pass
