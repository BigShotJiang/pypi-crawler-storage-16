# voraus logging library

A library that helps with setting up the logger compliant to our coding and system guidelines.


## Documentation

Please read the [documentation](https://vorausrobotik.github.io/voraus-logging-lib/) for more a more
detailed introduction.
