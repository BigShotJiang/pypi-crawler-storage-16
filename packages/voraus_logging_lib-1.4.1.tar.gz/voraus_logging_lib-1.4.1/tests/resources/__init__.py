"""This sub-package contains test resources that are needed for your tests (e.g., images)."""
