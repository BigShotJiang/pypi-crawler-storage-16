"""vox8 Python SDK for real-time speech translation."""

from vox8.client import Vox8Client

__version__ = "0.1.0"
__all__ = ["Vox8Client"]
