from .parse_solomon import parse_solomon as parse_solomon
from .parse_solution import parse_solution as parse_solution
from .parse_vrplib import parse_vrplib as parse_vrplib
