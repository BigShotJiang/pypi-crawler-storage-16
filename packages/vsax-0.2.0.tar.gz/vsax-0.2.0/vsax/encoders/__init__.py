"""Encoders for structured data."""

# Placeholder for iteration 4
# Will contain: AbstractEncoder, ScalarEncoder, DictEncoder

__all__ = []
