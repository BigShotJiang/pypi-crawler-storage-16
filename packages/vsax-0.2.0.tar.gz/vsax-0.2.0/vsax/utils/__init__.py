"""Utility functions."""

# Placeholder for iterations 3 and 5
# Will contain: coerce_to_array, vmap_bind, vmap_bundle, pretty_repr

__all__ = []
