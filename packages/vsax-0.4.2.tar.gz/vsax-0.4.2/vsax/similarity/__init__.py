"""Similarity metrics for hypervectors."""

# Placeholder for iteration 5
# Will contain: cosine_similarity, dot_similarity, hamming_similarity

__all__ = []
