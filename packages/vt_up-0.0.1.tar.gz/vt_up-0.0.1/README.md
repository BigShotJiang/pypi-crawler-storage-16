# vt-up
A CLI program that uses the
[vt-py library](https://github.com/VirusTotal/vt-py) to upload files
to VirusTotal for analysis.

It is based on the example script
[upload-files.py](https://github.com/VirusTotal/vt-py/blob/abe86d88e2c1b20d87cb9ceb572565e0c2dc8003/examples/upload_files.py);
more specifically, commit `e53590d`.

# Notable features
- Recursive directory scan.

# Installation and usage
Get it [from PyPI](https://pypi.org/project/vt-up/).

File upload example:
```sh
vt-up --api-key="API_KEY" --workers=4 --path=/path/to/file_or_folder
```

See `vt-up -h` for help.

# Development
```sh
pipenv install --dev
pipenv shell
```

```sh
python -m build
python -m twine upload dist/*
```