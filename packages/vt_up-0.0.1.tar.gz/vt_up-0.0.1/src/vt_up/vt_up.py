# Copyright © 2019 The vt-py authors. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# THIS FILE WAS MODIFIED FROM THE ORIGINAL.

"""Upload files to VirusTotal"""

import argparse
import asyncio
import itertools
import os
import sys

import vt


async def _scan_dir(queue, path) -> int:
    """Recursively scan a directory for files."""
    n_files = 0

    with os.scandir(path) as children:
        for child in children:
            if child.is_file():
                await queue.put(child.path)
                n_files += 1

            if child.is_dir():
                n_files += await _scan_dir(queue, child)

    return n_files


async def _queue_files(queue, path) -> int:
    """Put the selected files in the queue."""
    if os.path.isfile(path):
        await queue.put(path)
        return 1

    n_files = await _scan_dir(queue, path)

    return n_files


async def _upload_hashes(queue, apikey):
    """Upload selected files to VirusTotal."""
    return_values = []

    async with vt.Client(apikey) as client:
        while not queue.empty():
            file_path = await queue.get()
            with open(file_path, 'rb') as f:
                analysis = await client.scan_file_async(file=f)
                print(f"File {file_path} uploaded.")
                queue.task_done()
                return_values.append((analysis, file_path))

    return return_values


async def _process_analysis_results(apikey, analysis, file_path):
    """Print the analysis results."""
    async with vt.Client(apikey) as client:
        results = await client.wait_for_analysis_completion(analysis)

        print(f'Results for {file_path}')

        for key, value in results.stats.items():
            print(f'{key}: {value}')

        print(f"Analysis id: {results.id}")


async def _vt_upload():
    parser = argparse.ArgumentParser(
        description="Upload files to VirusTotal.")

    parser.add_argument(
        "--api-key", "-k",
        required=True,
        help="Your VirusTotal API key"
    )
    parser.add_argument(
        "--path", "-p",
        required=True,
        help="Path to the file/directory to upload."
    )
    parser.add_argument(
            "--workers",
            type=int,
            required=False,
            default=4,
            help="Number of concurrent workers",
    )

    args = parser.parse_args()

    if not os.path.exists(args.path):
        print(f"Error: File {args.path} not found.")
        sys.exit(1)

    queue = asyncio.Queue()
    n_files = await _queue_files(queue, args.path)

    worker_tasks = []
    for _ in range(min(args.workers, n_files)):
        worker_tasks.append(
            asyncio.create_task(_upload_hashes(queue, args.api_key)))

    # Wait until all worker tasks has completed.
    analyses = itertools.chain.from_iterable(
        await asyncio.gather(*worker_tasks))

    await asyncio.gather(
        *[
            asyncio.create_task(_process_analysis_results(args.api_key, a, f))
            for a, f in analyses
        ]
    )


def main():
    asyncio.run(_vt_upload())


if __name__ == "__main__":
    main()
