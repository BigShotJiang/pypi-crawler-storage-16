# vt-up
A CLI program that uses the
[vt-py library](https://github.com/VirusTotal/vt-py) to upload files
to VirusTotal for analysis.

It is based on the example script
[upload-files.py](https://github.com/VirusTotal/vt-py/blob/abe86d88e2c1b20d87cb9ceb572565e0c2dc8003/examples/upload_files.py);
more specifically, commit `e53590d`.

### Notable additions
- API key storage.
- Recursive directory scan.

# Installation and usage
Get it [from PyPI](https://pypi.org/project/vt-up/).

### 1. Setup your VirusTotal API key:
```sh
vt-up key API_KEY
```

It will be stored in a configuration file with strict permissions.

### 2. Analyze files:
```sh
vt-up scan /path/to/file_or_folder
```

# Development notes
### Environment setup
```sh
pipenv install --dev
pipenv shell
```

### Packaging
```sh
python -m build
python -m twine upload dist/*
```