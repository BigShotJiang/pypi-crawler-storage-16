# Copyright © 2019 The vt-py authors. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# THIS FILE WAS MODIFIED FROM THE ORIGINAL.

"""Upload files to VirusTotal"""

import argparse
import asyncio
import itertools
import os
import configparser
from pathlib import Path

import vt
from platformdirs import PlatformDirs


_CONFIG_FILENAME = 'config.ini'


async def _queue_dir(queue, path) -> int:
    """
    Recursively scan a directory for files and put them in the queue.
    """
    n_files = 0

    with os.scandir(path) as children:
        for child in children:
            if child.is_file():
                await queue.put(child.path)
                n_files += 1

            if child.is_dir():
                n_files += await _queue_dir(queue, child)

    return n_files


async def _queue_files(queue, path) -> int:
    """Put the selected files in the queue."""
    if os.path.isfile(path):
        await queue.put(path)
        return 1

    n_files = await _queue_dir(queue, path)  # It's a directory
    return n_files


async def _upload_hashes(queue, apikey):
    """Upload selected files to VirusTotal."""
    return_values = []

    async with vt.Client(apikey) as client:
        while not queue.empty():
            file_path = await queue.get()
            with open(file_path, 'rb') as f:
                analysis = await client.scan_file_async(file=f)
                print(f"File {file_path} uploaded.")
                queue.task_done()
                return_values.append((analysis, file_path))

    return return_values


async def _process_analysis_results(apikey, analysis, file_path):
    """Print the analysis results."""
    async with vt.Client(apikey) as client:
        results = await client.wait_for_analysis_completion(analysis)

        print(f'Results for {file_path}')

        for key, value in results.stats.items():
            print(f'{key}: {value}')

        print(f"Analysis id: {results.id}")


def _init_platformdirs() -> PlatformDirs:
    platform_dirs = PlatformDirs(appname="vt-up", appauthor="Douglas Silva")
    platform_dirs.user_config_path.mkdir(
        mode=0o0700, parents=True, exist_ok=True)

    return platform_dirs


def _save_config(config: configparser.ConfigParser, config_path: Path):
    """
    Save the configuration file to disk.
    """
    try:
        with open(config_path, mode='w', encoding='utf-8') as file:
            config.write(file)
    except (configparser.Error, OSError) as error:
        raise RuntimeError('Failed to save config to file.') from error


def _init_config(platform_dirs: PlatformDirs) -> configparser.ConfigParser:
    config = configparser.ConfigParser(allow_no_value=True)
    config_file = platform_dirs.user_config_path / _CONFIG_FILENAME

    if not config_file.exists():
        config_file.touch(mode=0o0600)

        config['api'] = {
            'key': None
        }

        _save_config(config, config_file)

    config.read(config_file)

    return config


def _set_api_key(args: argparse.Namespace):
    """
    Save an API key to the configuration file.

    This is an argparse action.
    """
    platform_dirs = _init_platformdirs()
    config = _init_config(platform_dirs)
    config_path = platform_dirs.user_config_path / _CONFIG_FILENAME

    config['api']['key'] = args.key
    _save_config(config, config_path)

    print('Key is set. Ready to upload.')
    raise SystemExit(0)


async def _scan_files(args: argparse.Namespace):
    """
    Orchestrate the asynchronous file submission.

    This is an argparse action.
    """
    platform_dirs = _init_platformdirs()
    config = _init_config(platform_dirs)

    if not os.path.exists(args.file):
        print(f"File {args.file} not found.")
        raise SystemExit(1)

    if not config['api']['key']:
        print('Please set your API key using the "key" command.')
        raise SystemExit(1)

    queue = asyncio.Queue()
    n_files = await _queue_files(queue, args.file)

    worker_tasks = []
    for _ in range(min(args.workers, n_files)):
        worker_tasks.append(
            asyncio.create_task(_upload_hashes(queue, config['api']['key'])))

    # Wait until all worker tasks has completed.
    analyses = itertools.chain.from_iterable(
        await asyncio.gather(*worker_tasks))

    await asyncio.gather(
        *[
            asyncio.create_task(
                _process_analysis_results(config['api']['key'], a, f)
            )
            for a, f in analyses
        ]
    )

    raise SystemExit(0)


def main():
    """
    Run the script entry point.
    """
    parser = argparse.ArgumentParser(
        description="Send files to VirusTotal for analysis.")

    commands = parser.add_subparsers(
        title='Commands', required=True)


    scan_command = commands.add_parser(
        'scan', help='Analyze files.'
    )
    scan_command.add_argument(
        'file', help='File or directory to analyze.',
        metavar='PATH'
    )
    scan_command.add_argument(
        '-w', '--workers',
        type=int, default=4,
        help='Number of concurrent workers (default=4).'
    )
    scan_command.set_defaults(async_action=_scan_files)


    key_command = commands.add_parser(
        'key', help='Manage your API key.'
    )
    key_command.add_argument(
        'key', help='Set your VirusTotal API key.',
        metavar='API_KEY'
    )
    key_command.set_defaults(action=_set_api_key)


    args = parser.parse_args()

    if 'action' in args:
        args.action(args)

    if 'async_action' in args:
        asyncio.run(args.async_action(args))

    raise NotImplementedError(
        'Parser action should exit from the interpreter.')


if __name__ == "__main__":
    main()
