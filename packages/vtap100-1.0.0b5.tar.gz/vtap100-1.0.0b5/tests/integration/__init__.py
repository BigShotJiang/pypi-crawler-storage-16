"""Integration tests for VTAP100 CLI and workflows."""
