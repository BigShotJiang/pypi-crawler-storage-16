from enum import Enum


class SupportedFileFormat(Enum):
    CSV = "CSV"
    PARQUET = "PARQUET"
