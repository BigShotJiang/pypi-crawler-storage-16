"""AES-256-GCM encryption service."""

import base64
import os
from typing import Optional

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from pydantic import BaseModel

from vulkan_engine.logging import get_logger

logger = get_logger(__name__)


class EncryptedData(BaseModel):
    """Encrypted data container."""

    encrypted_value: str
    nonce: str
    tag: str
    encryption_version: int = 1


class EncryptionService:
    """AES-256-GCM encryption service."""

    def __init__(self, key_b64: str):
        if not key_b64:
            raise ValueError("Encryption key is required")

        try:
            self.key = base64.b64decode(key_b64)
            if len(self.key) != 32:
                raise ValueError(f"Key must be 32 bytes, got {len(self.key)}")
            self.aesgcm = AESGCM(self.key)
            logger.info("encryption_service_initialized", key_length=len(self.key))
        except Exception as e:
            logger.error("encryption_init_failed", error=str(e))
            raise ValueError(f"Invalid encryption key: {str(e)}") from e

    def encrypt(self, plaintext: str, version: int = 1) -> EncryptedData:
        """Encrypt plaintext using AES-256-GCM."""
        try:
            nonce = os.urandom(12)

            plaintext_bytes = plaintext.encode("utf-8")
            ciphertext_with_tag = self.aesgcm.encrypt(nonce, plaintext_bytes, None)

            ciphertext = ciphertext_with_tag[:-16]
            tag = ciphertext_with_tag[-16:]

            return EncryptedData(
                encrypted_value=base64.b64encode(ciphertext).decode("ascii"),
                nonce=base64.b64encode(nonce).decode("ascii"),
                tag=base64.b64encode(tag).decode("ascii"),
                encryption_version=version,
            )
        except Exception as e:
            logger.error("encryption_failed", error=str(e))
            raise ValueError(f"Encryption failed: {str(e)}") from e

    def decrypt(
        self, encrypted_value: str, nonce: str, tag: str, version: int = 1
    ) -> str:
        """Decrypt ciphertext using AES-256-GCM."""
        # Support for legacy unencrypted data (version 0)
        if version == 0:
            return base64.b64decode(encrypted_value).decode("utf-8")

        try:
            ciphertext = base64.b64decode(encrypted_value)
            nonce_bytes = base64.b64decode(nonce)
            tag_bytes = base64.b64decode(tag)

            ciphertext_with_tag = ciphertext + tag_bytes
            plaintext_bytes = self.aesgcm.decrypt(
                nonce_bytes, ciphertext_with_tag, None
            )

            return plaintext_bytes.decode("utf-8")
        except Exception as e:
            logger.error("decryption_failed", error=str(e), version=version)
            raise ValueError(f"Decryption failed (tampering detected?): {str(e)}")


_encryption_service: Optional[EncryptionService] = None


def get_encryption_service() -> EncryptionService:
    """Get encryption service singleton."""
    global _encryption_service

    if _encryption_service is None:
        key_b64 = os.getenv("CREDENTIAL_ENCRYPTION_KEY", "")
        _encryption_service = EncryptionService(key_b64=key_b64)

    return _encryption_service
