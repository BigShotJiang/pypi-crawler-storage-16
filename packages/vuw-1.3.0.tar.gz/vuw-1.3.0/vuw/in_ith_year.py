import pandas as pd
from datetime import datetime
from dateutil.relativedelta import relativedelta


def in_ith_year(claims_df, udate, n_years, types=None):
    """
    claims_df를 받아 해당 ID가 최근 n년 이내 통원(out)/입원(hos)/수술(sur) 관련 치료 내역이 있는지 확인.
    ID별로 집계하여 반환.
    
    성능 최적화:
    - 날짜 변환 최소화 (한 번만 변환)
    - 벡터화 연산 활용
    - 각 치료 유형별 필터링을 먼저 수행하여 데이터 크기 축소
    - 여러 n값과 여러 치료 유형을 효율적으로 처리
    
    Parameters:
    -----------
    claims_df : pd.DataFrame
        청구 데이터프레임. 'ID', 'hosout', 'sur', 'sdate', 'edate' 컬럼이 있어야 함
    udate : str or datetime
        기준 날짜 (yyyy-mm-dd 형식의 문자열 또는 datetime 객체)
    n_years : int or list of int
        확인할 년 수. 예: 1 또는 [1, 3, 5]
    types : str or list of str, optional
        확인할 치료 유형. 'out', 'hos', 'sur' 중 하나 또는 여러 개. 기본값: ['out', 'hos', 'sur']
    
    Returns:
    --------
    pd.DataFrame
        ID별 집계 결과. 컬럼: 'ID', '{type}_pst_{n}y' (type은 out/hos/sur, n은 n_years 값)
        치료 내역이 있으면 1, 없으면 0
    """
    # n_years를 리스트로 변환
    if isinstance(n_years, int):
        n_years_list = [n_years]
    elif isinstance(n_years, (list, tuple)):
        n_years_list = list(n_years)
    else:
        raise ValueError("n_years는 int 또는 list of int여야 합니다.")
    
    # types 처리 (기본값: 모든 유형)
    if types is None:
        types_list = ['out', 'hos', 'sur']
    elif isinstance(types, str):
        types_list = [types]
    elif isinstance(types, (list, tuple)):
        types_list = list(types)
    else:
        raise ValueError("types는 str 또는 list of str여야 합니다.")
    
    # 유효한 유형인지 확인
    valid_types = {'out', 'hos', 'sur'}
    invalid_types = set(types_list) - valid_types
    if invalid_types:
        raise ValueError(f"유효하지 않은 치료 유형: {invalid_types}. 유효한 유형: {valid_types}")
    
    # udate를 datetime으로 변환 (한 번만)
    if isinstance(udate, str):
        udate_dt = pd.to_datetime(udate)
    elif isinstance(udate, datetime):
        udate_dt = pd.to_datetime(udate)
    else:
        raise ValueError("udate는 문자열(yyyy-mm-dd) 또는 datetime 객체여야 합니다.")
    
    # 모든 고유 ID 가져오기 (claims_df의 모든 ID)
    all_ids = claims_df['ID'].unique()
    result_df = pd.DataFrame({'ID': all_ids})
    
    # 날짜 변환 (한 번만, 원본 DataFrame은 수정하지 않음)
    sdate_dt = pd.to_datetime(claims_df['sdate'])
    edate_dt = pd.to_datetime(claims_df['edate'])
    
    # 각 치료 유형별로 처리
    for treat_type in types_list:
        # 치료 유형에 따른 필터링 마스크 (한 번만 생성)
        if treat_type == 'out':
            type_mask = (claims_df['hosout'] == 2.0)
        elif treat_type == 'hos':
            type_mask = (claims_df['hosout'] == 1.0)
        elif treat_type == 'sur':
            type_mask = (claims_df['sur'] == 1.0)
        else:
            continue
        
        # 각 n값에 대해 컬럼 생성
        for n in n_years_list:
            # n년 이전 날짜 계산
            start_date = udate_dt - relativedelta(years=n)
            
            # 한 번에 필터링 (슬라이싱 없이 전체 Series에서 boolean 마스크 사용)
            # sdate < udate AND edate >= start_date AND type_mask (기간이 겹치는 경우)
            # udate는 포함하지 않음 (udate 직전일까지만 포함)
            period_mask = (sdate_dt < udate_dt) & (edate_dt >= start_date) & type_mask
            
            # 해당 기간 내 치료가 있는 ID들 (고유값) - 벡터화 연산
            ids_with_treatment = claims_df.loc[period_mask, 'ID'].unique()
            
            # 컬럼명 생성
            col_name = f'{treat_type}_pst_{n}y'
            
            # ID별로 1 또는 0 할당 (벡터화 연산)
            result_df[col_name] = result_df['ID'].isin(ids_with_treatment).astype(int)
    
    return result_df

