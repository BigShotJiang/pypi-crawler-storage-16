import pandas as pd
from datetime import datetime
import numpy as np

try:
    from numba import njit
    NUMBA_AVAILABLE = True
except ImportError:
    NUMBA_AVAILABLE = False
    # Numba가 없으면 데코레이터를 무시하는 dummy 함수 생성
    def njit(*args, **kwargs):
        def decorator(func):
            return func
        if len(args) == 1 and callable(args[0]):
            return args[0]
        return decorator


def merge_overlapping_date_range(claims_df, interval, threshold, udate, years):
    """
    claims_df를 받아 통원 청구건만 대상으로 동일한 ID 내에서 겹치거나 interval 일수 이내로 
    떨어진 날짜 범위를 병합. 더이상 병합할 수 없을 때까지 반복하여 각 ID별로 연속된 치료 기간의 합을 계산.
    
    성능 최적화:
    - 통원 청구건만 필터링 (hosout != 1.0)
    - udate 기준으로 먼저 필터링하여 처리할 데이터 양 최소화
    - 날짜를 정수로 한 번만 변환 (Timedelta 연산 제거)
    - NumPy 벡터화 연산 활용
    - 효율적인 단일 패스 병합 알고리즘
    - 불필요한 복사 및 변환 최소화
    - threshold 기반 early termination
    
    Parameters:
    -----------
    claims_df : pd.DataFrame
        청구 데이터프레임. 'ID', 'sdate', 'edate', 'hosout' 컬럼이 있어야 함 (yyyy-mm-dd 형식)
    interval : int
        연속으로 간주할 일수 간격. 예: 7이면 7일 이내로 떨어져 있는 치료건들을 연속으로 간주하여 병합
        연속 여부 판단 기준: 두 치료건 사이 간격이 interval 일수 이내면 연속으로 간주
    threshold : int
        성능 최적화용 임계값. 해당 값 이상이면 조건 통과 실패이므로 계산을 중단하여 성능 향상.
        예: threshold=7이면, 연속 치료 기간이 7일 이상이 되면 더 이상 계산하지 않고 즉시 반환
        정확한 계산이 필요하면 큰 값(예: 999) 사용
    udate : str or datetime
        기준 날짜 (yyyy-mm-dd 형식). 이 날짜 기준으로 years년 전 이후 데이터만 사용.
        udate는 포함하지 않음 (udate 직전일까지만 포함).
    years : int
        udate 기준 이전 n년 데이터만 사용. 예: 5이면 udate 기준 5년 전(start_date)부터 
        udate 직전까지의 데이터만 사용. start_date는 포함하고 udate는 포함하지 않음.
    
    Returns:
    --------
    pd.DataFrame
        ID별 최대 연속 치료 기간 (통원만). 컬럼: 'ID', 'trt{interval}_pst_{years}y'
        각 ID당 연속해서 통원 치료받은 가장 많은 기간(일수)의 합
    """
    # 컬럼 이름 동적 생성
    col_name = f'trt{interval}_pst_{years}y'
    
    if len(claims_df) == 0:
        return pd.DataFrame({'ID': [], col_name: []})
    
    # udate를 datetime으로 변환 (한 번만)
    udate_dt = pd.to_datetime(udate)
    udate_int = int(udate_dt.value // 10**9 // 86400)
    
    # relativedelta를 사용하여 정확한 년 계산 (윤년 고려)
    from dateutil.relativedelta import relativedelta
    start_date_dt = udate_dt - relativedelta(years=years)
    start_date_int = int(start_date_dt.value // 10**9 // 86400)
    
    # 필수 컬럼 확인
    required_cols = ['ID', 'sdate', 'edate', 'hosout']
    missing_cols = [col for col in required_cols if col not in claims_df.columns]
    if missing_cols:
        raise ValueError(f"claims_df에 필수 컬럼이 없습니다: {missing_cols}")
    
    # 성능 최적화: 통원 청구건만 필터링 (hosout != 1.0)
    # 필요한 컬럼만 추출 (view 사용하여 메모리 절약)
    outpatient_mask = claims_df['hosout'] != 1.0
    
    if not outpatient_mask.any():
        return pd.DataFrame({'ID': [], col_name: []})
    
    work_df = claims_df.loc[outpatient_mask, ['ID', 'sdate', 'edate']].reset_index(drop=True)
    
    # 날짜를 datetime으로 변환 (한 번만)
    sdate_dt = pd.to_datetime(work_df['sdate'], errors='coerce')
    edate_dt = pd.to_datetime(work_df['edate'], errors='coerce')
    
    # 유효한 날짜만 필터링 (NaT 제외)
    valid_mask = sdate_dt.notna() & edate_dt.notna()
    
    if not valid_mask.any():
        return pd.DataFrame({'ID': [], col_name: []})
    
    # 날짜를 정수로 변환 (epoch days) - 유효한 날짜만 변환하여 메모리 절약
    sdate_int = (sdate_dt[valid_mask].view('int64') // 10**9 // 86400).astype(np.int32)
    edate_int = (edate_dt[valid_mask].view('int64') // 10**9 // 86400).astype(np.int32)
    
    # udate 기준 years년 전 이후 데이터만 필터링
    # 다른 함수들(in_ith_year, kcd_ith_year)과 일관성 유지:
    # sdate < udate AND edate >= start_date (기간이 겹치는 경우)
    # start_date는 포함하고, udate는 포함하지 않음
    date_filter_mask = (sdate_int < udate_int) & (edate_int >= start_date_int)
    
    if not date_filter_mask.any():
        return pd.DataFrame({'ID': [], col_name: []})
    
    # 최종 필터링된 데이터만 추출 (인덱싱 최소화)
    valid_indices = np.where(valid_mask)[0]
    date_filtered_indices = valid_indices[date_filter_mask]
    
    # 날짜 범위를 [start_date, udate) 구간으로 클리핑 (중요!)
    # 치료 기간이 start_date 이전부터 시작하거나 udate 이후까지 지속되는 경우
    # 실제 계산에는 [start_date, udate) 구간만 포함해야 함
    sdate_clipped = np.maximum(sdate_int[date_filter_mask], start_date_int)
    edate_clipped = np.minimum(edate_int[date_filter_mask], udate_int - 1)
    
    # 클리핑 후 유효하지 않은 범위 제외 (sdate > edate인 경우)
    valid_clipped_mask = sdate_clipped <= edate_clipped
    
    if not valid_clipped_mask.any():
        return pd.DataFrame({'ID': [], col_name: []})
    
    # 유효한 클리핑된 데이터만 추출
    valid_clipped_indices = date_filtered_indices[valid_clipped_mask]
    
    # 필요한 데이터만 추출하여 DataFrame 생성 (한 번만) - 직접 인덱싱으로 최적화
    work_df = pd.DataFrame({
        'ID': work_df['ID'].values[valid_clipped_indices],
        'sdate_int': sdate_clipped[valid_clipped_mask],
        'edate_int': edate_clipped[valid_clipped_mask]
    })
    
    # 성능 최적화: 정렬을 먼저 수행한 후 중복 제거 (더 빠름)
    # ID별로 정렬 (한 번만) - sdate_int, edate_int 모두 고려하여 정렬
    work_df = work_df.sort_values(['ID', 'sdate_int', 'edate_int'], kind='quicksort')
    
    # (ID, sdate, edate) 조합으로 중복 제거 (정렬 후이므로 더 빠름)
    work_df = work_df.drop_duplicates(subset=['ID', 'sdate_int', 'edate_int'], keep='first')
    
    # 인덱스 리셋
    work_df = work_df.reset_index(drop=True)
    
    # ID별로 그룹화하여 처리 - NumPy 배열로 직접 작업
    ids = work_df['ID'].values
    sdate_ints = work_df['sdate_int'].values
    edate_ints = work_df['edate_int'].values
    
    # ID 변경 지점 찾기 (벡터화) - 더 효율적인 방법
    if len(ids) > 0:
        id_changes = np.where(ids[:-1] != ids[1:])[0] + 1
        id_starts = np.concatenate([[0], id_changes])
        id_ends = np.concatenate([id_changes, [len(ids)]])
    else:
        id_starts = np.array([0])
        id_ends = np.array([0])
    
    # 결과 배열 생성
    unique_ids = ids[id_starts] if len(id_starts) > 0 else np.array([], dtype=ids.dtype)
    max_days_array = np.zeros(len(unique_ids), dtype=np.int32)
    
    # 진행 상황 표시 (대용량 데이터 처리 시)
    total_ids = len(unique_ids)
    show_progress = total_ids > 10000
    
    # 각 ID별로 병합 계산
    for i in range(len(unique_ids)):
        if show_progress and i % 10000 == 0:
            print(f"  진행 중: {i:,}/{total_ids:,} ID 처리 완료 ({i/total_ids*100:.1f}%)", end='\r')
        
        start_idx = id_starts[i]
        end_idx = id_ends[i]
        
        # 해당 ID의 날짜 범위 추출
        id_sdate = sdate_ints[start_idx:end_idx]
        id_edate = edate_ints[start_idx:end_idx]
        
        # 최대 연속 치료 기간 계산
        max_days_array[i] = _calculate_max_consecutive_days_fast(
            id_sdate, id_edate, interval, threshold
        )
    
    if show_progress:
        print(f"  진행 중: {total_ids:,}/{total_ids:,} ID 처리 완료 (100.0%)")
    
    # 결과 데이터프레임 생성
    result_df = pd.DataFrame({
        'ID': unique_ids,
        col_name: max_days_array
    })
    
    return result_df


@njit(cache=True)
def _merge_ranges_numba(sdate_array, edate_array, interval, threshold):
    """
    Numba JIT 컴파일 버전: 초고속 날짜 범위 병합 및 실제 치료 일수 합산.
    
    Parameters:
    -----------
    sdate_array : np.ndarray
        시작 날짜 정수 배열 (정렬된 상태)
    edate_array : np.ndarray
        종료 날짜 정수 배열
    interval : int
        병합 간격 (일)
    threshold : int
        조기 종료 threshold (-1이면 무시)
    
    Returns:
    --------
    int
        최대 연속 치료 기간 (일) - 실제 치료 일수의 합
    """
    n = len(sdate_array)
    if n == 0:
        return 0
    
    if n == 1:
        return int(edate_array[0] - sdate_array[0] + 1)
    
    max_days = 0
    current_group_days = int(edate_array[0] - sdate_array[0] + 1)
    current_last_edate = edate_array[0]
    
    for i in range(1, n):
        next_start = sdate_array[i]
        next_end = edate_array[i]
        
        # 병합 가능 여부 확인 (interval 이내면 같은 그룹)
        if current_last_edate >= next_start or (next_start - current_last_edate - 1) <= interval:
            # 같은 그룹: 실제 치료 일수만 추가 (겹치는 부분 제외, 간격도 제외)
            if next_end > current_last_edate:
                if next_start <= current_last_edate:
                    # 겹치는 경우: 겹치지 않는 부분만 추가
                    additional_days = int(next_end - current_last_edate)
                else:
                    # 간격이 있는 경우: 간격은 제외하고 실제 치료 일수만 추가
                    additional_days = int(next_end - next_start + 1)
                
                current_group_days += additional_days
                current_last_edate = next_end
            # else: next_end가 current_last_edate 이하면 완전히 포함되므로 추가 안 함
        else:
            # 새 그룹 시작: 이전 그룹 완료
            if current_group_days > max_days:
                max_days = current_group_days
            
            # threshold 체크
            if threshold > 0 and max_days >= threshold:
                return max_days
            
            # 새 그룹 시작
            current_group_days = int(next_end - next_start + 1)
            current_last_edate = next_end
    
    # 마지막 그룹 처리
    if current_group_days > max_days:
        max_days = current_group_days
    
    return max_days


def _calculate_max_consecutive_days_fast(sdate_array, edate_array, interval, threshold=None):
    """
    초고속 버전: 정수 연산만 사용하여 날짜 범위 병합 및 최대 치료 기간 계산.
    Numba가 있으면 JIT 컴파일 버전 사용, 없으면 순수 Python 버전 사용.
    
    Parameters:
    -----------
    sdate_array : np.ndarray
        시작 날짜 정수 배열 (epoch days)
    edate_array : np.ndarray
        종료 날짜 정수 배열 (epoch days)
    interval : int
        병합 간격 (일)
    threshold : int, optional
        조기 종료를 위한 threshold
    
    Returns:
    --------
    int
        최대 연속 치료 기간 (일)
    """
    # threshold 처리: None이면 -1로 변환 (Numba용)
    thresh_val = threshold if threshold is not None else -1
    
    if NUMBA_AVAILABLE:
        # Numba JIT 컴파일 버전 사용 (10-100배 빠름)
        return _merge_ranges_numba(sdate_array, edate_array, interval, thresh_val)
    else:
        # 순수 Python 버전 (Numba 없을 때)
        n = len(sdate_array)
        if n == 0:
            return 0
        
        if n == 1:
            return int(edate_array[0] - sdate_array[0] + 1)
        
        max_days = 0
        current_group_days = int(edate_array[0] - sdate_array[0] + 1)
        current_last_edate = edate_array[0]
        
        for i in range(1, n):
            next_start = sdate_array[i]
            next_end = edate_array[i]
            
            # 병합 가능 여부 확인 (interval 이내면 같은 그룹)
            if current_last_edate >= next_start or (next_start - current_last_edate - 1) <= interval:
                # 같은 그룹: 실제 치료 일수만 추가 (겹치는 부분 제외, 간격도 제외)
                if next_end > current_last_edate:
                    if next_start <= current_last_edate:
                        # 겹치는 경우: 겹치지 않는 부분만 추가
                        additional_days = int(next_end - current_last_edate)
                    else:
                        # 간격이 있는 경우: 간격은 제외하고 실제 치료 일수만 추가
                        additional_days = int(next_end - next_start + 1)
                    
                    current_group_days += additional_days
                    current_last_edate = next_end
                # else: next_end가 current_last_edate 이하면 완전히 포함되므로 추가 안 함
            else:
                # 새 그룹 시작: 이전 그룹 완료
                max_days = max(max_days, current_group_days)
                
                if threshold is not None and max_days >= threshold:
                    return max_days
                
                # 새 그룹 시작
                current_group_days = int(next_end - next_start + 1)
                current_last_edate = next_end
        
        # 마지막 그룹 처리
        max_days = max(max_days, current_group_days)
        
        return max_days
