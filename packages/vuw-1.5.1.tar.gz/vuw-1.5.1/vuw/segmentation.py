"""
세그멘테이션 모듈

ID별 집계 데이터를 병합하고, 고객 우량도 기반 세그멘테이션을 수행합니다.
"""

from .make_merge_ins import make_merge_ins
from .make_segmentation import (
    make_segmentation,
    prepare_segmentation_columns,
    make_segmentation_from_scratch
)

__all__ = [
    'make_merge_ins',
    'make_segmentation',
    'prepare_segmentation_columns',
    'make_segmentation_from_scratch'
]

