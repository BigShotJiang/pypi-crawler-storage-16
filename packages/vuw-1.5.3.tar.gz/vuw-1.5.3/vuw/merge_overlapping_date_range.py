import pandas as pd
import numpy as np
from numba import njit
from numba.typed import List as NumbaList
from joblib import Parallel, delayed
from .glue_code import glue_code_

@njit
def merge_engine_numba_unique(sdates, edates, kcd_codes, add_values, interval):
    n = len(sdates)
    results = NumbaList()

    # 첫 block 초기화
    current_start = sdates[0]
    current_end = edates[0]

    current_kcds = NumbaList()
    current_kcds.append(kcd_codes[0])

    current_row_ids = NumbaList()
    current_row_ids.append(0)

    for i in range(1, n):

        # additional_col 동일 여부 확인
        same = True
        for j in range(add_values.shape[1]):
            if add_values[i, j] != add_values[i - 1, j]:
                same = False
                break

        # 병합 조건: 날짜 이어짐 + 추가 컬럼 동일
        if (sdates[i] <= current_end + np.timedelta64(interval + 1, 'D')) and same:
            if edates[i] > current_end:
                current_end = edates[i]
            current_kcds.append(kcd_codes[i])
            current_row_ids.append(i)
        else:
            # block 종료
            results.append((current_start, current_end, current_kcds, current_row_ids))

            # 새 block 시작
            current_start = sdates[i]
            current_end = edates[i]

            current_kcds = NumbaList()
            current_kcds.append(kcd_codes[i])

            current_row_ids = NumbaList()
            current_row_ids.append(i)

    # 마지막 block 추가
    results.append((current_start, current_end, current_kcds, current_row_ids))

    return results

def merge_group(group, additional_col, interval=0):

    # 날짜 정렬
    group = group.sort_values(by=["sdate"] + additional_col)

    # --------------------------
    # 1) KCD factorize
    # --------------------------
    kcd_codes, kcd_unique = pd.factorize(group["kcd"])
    kcd_unique = np.array(kcd_unique, dtype=object)

    # --------------------------
    # 2) additional_col factorize
    # --------------------------
    add_unique_map = {}
    add_values = []

    for col in additional_col:
        codes, uniques = pd.factorize(group[col])
        add_unique_map[col] = np.array(uniques, dtype=object)
        add_values.append(codes)

    # === 중요! ===
    # numba는 (n,0) shape의 배열을 지원하지 않음 → (n,1) dummy 생성
    if len(add_values) == 0:
        add_values = np.zeros((len(group), 1), dtype=np.int64)
    else:
        add_values = np.vstack(add_values).T  # shape (n, p)

    # --------------------------
    # 3) 날짜 배열 → datetime64[D]
    # --------------------------
    sdates = group["sdate"].values.astype("datetime64[D]")
    edates = group["edate"].values.astype("datetime64[D]")

    # --------------------------
    # 4) numba 엔진 실행
    # --------------------------
    blocks = merge_engine_numba_unique(
        sdates,
        edates,
        kcd_codes.astype(np.int64),
        add_values.astype(np.int64),
        interval,
    )

    # --------------------------
    # 5) block 후처리: 고유 날짜 stay + 문자열 복원
    # --------------------------
    out = []

    for (start, end, kcd_code_list, row_ids) in blocks:

        # kcd 복원
        decoded_kcd_list = [kcd_unique[i] for i in kcd_code_list]
        merged_kcd = glue_code_(decoded_kcd_list)

        # additional_col 복원
        restored_add_cols = {}
        first_row = row_ids[0]
        for idx, col in enumerate(additional_col):
            restored_add_cols[col] = add_unique_map[col][add_values[first_row, idx]]

        # stay = 고유 날짜 개수
        unique_days = set()
        for rid in row_ids:
            day = sdates[rid]
            end_day = edates[rid]
            while day <= end_day:
                unique_days.add(day)
                day += np.timedelta64(1, "D")

        stay_unique = len(unique_days)

        # 대표 행 → 첫 행 정보 사용
        first_g = group.iloc[first_row]

        row = {
            "ID": first_g["ID"],
            "gender": first_g["gender"],
            "age": first_g["age"],
            "age_band": first_g["age_band"],
            "kcd": merged_kcd,
            "sdate": pd.Timestamp(start),
            "edate": pd.Timestamp(end),
            "stay": stay_unique,
        }

        row.update(restored_add_cols)
        out.append(row)

    return out

def merge_overlapping_date_range(df, additional_col=[], interval=0, n_jobs=-1):

    tmp = df.copy()

    # datetime 표준화
    tmp["sdate"] = pd.to_datetime(tmp["sdate"]).dt.floor("D")
    tmp["edate"] = pd.to_datetime(tmp["edate"]).dt.floor("D")

    # ID 단위 병렬화
    groups = [g for _, g in tmp.groupby("ID")]

    results = Parallel(n_jobs=n_jobs)(
        delayed(merge_group)(g, additional_col, interval)
        for g in groups
    )

    final = [row for grp in results for row in grp]

    return pd.DataFrame(final)

