"""
시각화 모듈

RR_calculator 결과를 시각화하는 함수를 제공합니다.
"""

from .plot_risk_comparison import (
    plot_risk_comparison,
    plot_risk_comparison_vertical
)

__all__ = ['plot_risk_comparison', 'plot_risk_comparison_vertical']

