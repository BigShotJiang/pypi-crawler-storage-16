"""
리포트 생성 모듈

RR_calculator와 kcd_counter 결과를 바탕으로 위험도 리포트를 자동 생성합니다.
"""

from .generate_report import generate_report

__all__ = ['generate_report']

