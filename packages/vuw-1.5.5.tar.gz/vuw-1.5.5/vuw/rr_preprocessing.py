import pandas as pd
import re
import numpy as np


def add_dis_inj_column(claims_df, disease_pattern, injury_pattern):
    """
    claims_df를 받아 disease와 injury 정규표현식을 바탕으로 'dis_inj' 컬럼을 추가.
    
    성능 최적화:
    - 정규표현식 컴파일 최소화 (한 번만)
    - 벡터화 연산 활용 (str.contains 사용)
    - 불필요한 복사 최소화
    - 조건 우선순위: disease > injury > none
    - 메모리 효율화: apply 대신 str.contains 사용
    
    Parameters:
    -----------
    claims_df : pd.DataFrame
        청구 데이터프레임 (ins_df와 left join된 형태). 'kcd' 컬럼이 있어야 함
    disease_pattern : str
        disease를 판별하는 정규표현식 패턴
    injury_pattern : str
        injury를 판별하는 정규표현식 패턴
    
    Returns:
    --------
    pd.DataFrame
        'dis_inj' 컬럼이 추가된 claims_df
        - 'dis': disease 패턴에 매칭
        - 'inj': injury 패턴에 매칭 (disease가 아닌 경우)
        - 'none': 둘 다 매칭되지 않는 경우
    """
    if len(claims_df) == 0:
        return claims_df.copy()
    
    # 원본 복사 (원본 보존)
    result_df = claims_df.copy()
    
    # kcd 코드를 문자열로 변환 (한 번만, inplace=False로 메모리 효율적)
    kcd_str = result_df['kcd'].astype(str)
    
    # disease 매칭 (str.contains 사용 - apply보다 메모리 효율적이고 빠름)
    disease_match = kcd_str.str.contains(disease_pattern, regex=True, na=False)
    
    # injury 매칭 (str.contains 사용 - apply보다 메모리 효율적이고 빠름)
    injury_match = kcd_str.str.contains(injury_pattern, regex=True, na=False)
    
    # dis_inj 컬럼 생성 (우선순위: disease > injury > none)
    # numpy.where를 사용하여 벡터화 연산
    result_df['dis_inj'] = np.where(
        disease_match,
        'dis',
        np.where(injury_match, 'inj', 'none')
    )
    
    return result_df

