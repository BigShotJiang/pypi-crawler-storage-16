# VUW

A Python package for users doing Underwriting(U/W) in insurance companies.

## Features

- Easy-to-use utilities for data processing.
- Compatible with Python 3.8 and above.

## Installation

Install the package using pip:

```bash
pip install vuw

