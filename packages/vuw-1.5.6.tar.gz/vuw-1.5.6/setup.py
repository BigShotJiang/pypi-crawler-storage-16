from setuptools import setup, find_packages

setup(
    name='vuw',
    version='1.5.6',
    author='Jiwon Chae',
    author_email='jwchae106@gmail.com',
    description='보험 데이터 분석용 Python 패키지',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/lalapetitechae/vuw',
    download_url='https://github.com/lalapetitechae/vuw/archive/refs/tags/v0.1.0.tar.gz',
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
    ],
    install_requires=['pandas', 'numpy'],
    python_requires='>=3.7',
    license='MIT',
)

