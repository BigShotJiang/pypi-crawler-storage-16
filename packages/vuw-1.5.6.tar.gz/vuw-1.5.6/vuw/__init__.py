"""
VUW (Virtual UnderWriting) 라이브러리

보험 청구 데이터를 기반으로 위험률을 개발하고 분석하는 가상 언더라이팅 시스템입니다.

사용 예시:
    >>> import vuw
    >>> from vuw import preprocessing, aggregation, calculator
    >>> 
    >>> # 데이터 전처리
    >>> claims_df = vuw.preprocessing.split_date_range(claims_df, '2018-01-01')
    >>> claims_df = vuw.preprocessing.add_dis_inj_column(claims_df, disease_pattern, injury_pattern)
    >>> 
    >>> # ID별 집계
    >>> result = vuw.aggregation.in_ith_mon(claims_df, '2018-01-01', 3)
    >>> 
    >>> # 위험도 계산
    >>> claims_df_A = claims_df[claims_df['gender'] == 1]  # 그룹 A
    >>> claims_df_B = claims_df[claims_df['gender'] == 2]  # 그룹 B
    >>> rr_result = vuw.calculator.RR_calculator(claims_df_A, claims_df_B, start, end)
"""

__version__ = '1.1.0'
__author__ = 'VUW Development Team'

# 모듈 import
from . import preprocessing
from . import aggregation
from . import calculator
from . import visualization
from . import reporting
from . import segmentation
from . import quality
from . import utils
from . import analysis

# 주요 함수들을 최상위 레벨에서 직접 import 가능하게
from .preprocessing import (
    split_date_range,
    add_dis_inj_column,
    kj_preprocessing,
    kj_preprocessing_and_remove
)

from .aggregation import (
    in_ith_mon,
    in_ith_year,
    kcd_in_ith_mon,
    kcd_in_ith_year
)

from .calculator import (
    n_calculator,
    n_hos_calculator,
    RR_calculator,
    kcd_counter
)

from .visualization import (
    plot_risk_comparison,
    plot_risk_comparison_vertical
)

from .reporting import (
    generate_report
)

from .segmentation import (
    make_merge_ins,
    make_segmentation,
    prepare_segmentation_columns,
    make_segmentation_from_scratch
)

from .quality import (
    check_data_quality
)

from .utils import (
    subset_id_with_kcd_terms,
    merge_overlapping_date_range
)

from .analysis import (
    test_rr_significance,
    analyze_risk_trend,
    analyze_cohort_risk,
    identify_high_risk_customers
)

__all__ = [
    # 모듈
    'preprocessing',
    'aggregation',
    'calculator',
    'visualization',
    'reporting',
    'segmentation',
    'quality',
    'utils',
    'analysis',
    # 함수들
    'split_date_range',
    'add_dis_inj_column',
    'kj_preprocessing',
    'kj_preprocessing_and_remove',
    'in_ith_mon',
    'in_ith_year',
    'kcd_in_ith_mon',
    'kcd_in_ith_year',
    'n_calculator',
    'n_hos_calculator',
    'RR_calculator',
    'kcd_counter',
    'plot_risk_comparison',
    'plot_risk_comparison_vertical',
    'generate_report',
    'make_merge_ins',
    'make_segmentation',
    'prepare_segmentation_columns',
    'make_segmentation_from_scratch',
    'check_data_quality',
    'subset_id_with_kcd_terms',
    'merge_overlapping_date_range',
    'test_rr_significance',
    'analyze_risk_trend',
    'analyze_cohort_risk',
    'identify_high_risk_customers',
]

