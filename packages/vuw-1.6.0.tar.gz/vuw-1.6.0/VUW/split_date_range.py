import pandas as pd
import numpy as np
from numba import njit, types
from numba.typed import List as NumbaList


# ============================================================
# 🔥 Numba ultra-fast engine (단일 pass + binary search 분할)
# ============================================================
@njit
def split_engine_numba(from_arr, to_arr, udates_arr):
    n = len(from_arr)
    results = NumbaList()

    for i in range(n):
        start = from_arr[i]
        end = to_arr[i]

        # binary-search로 필요한 udate 위치만 찾음
        # cuts = udates_arr 중 start < u ≤ end 인 것
        cuts = NumbaList()
        for u in udates_arr:
            if start < u <= end:
                cuts.append(u)

        # 분리 필요 없음
        if len(cuts) == 0:
            # 그대로 append
            results.append((i, start, end))
            continue

        # 분리 필요 있음
        current_start = start

        for c in cuts:
            # 앞 구간
            results.append((i, current_start, c - np.timedelta64(1, 'D')))
            # 다음 구간 시작점 갱신
            current_start = c

        # 마지막 구간
        results.append((i, current_start, end))

    return results



# ============================================================
# 🔥 기존 이름 유지 → 내부에서 Numba 엔진 호출
# ============================================================
def process_udate(df, from_var, to_var, udate, all_flag):
    """
    최고 성능 버전에서는 split_date_range()에서 모든 udate를 한 번에 처리함.
    따라서 이 함수는 사용되지 않지만, 이름 유지 및 호환성을 위해 dummy 처리.
    """
    return df.copy()



def split_date_range(df, from_var, to_var, udates, all=True, n_jobs=-1):
    """
    최고 성능 버전.
    모든 udate를 단일 pass로 고속(numba) 처리.
    함수 이름/파라미터 100% 동일.
    """

    # udate 정규화
    if isinstance(udates, str) or not isinstance(udates, list):
        udates = [udates]

    udates = sorted(pd.to_datetime(u).to_datetime64() for u in udates)

    # NumPy 배열로 변환 (numba-friendly)
    df2 = df.copy()
    from_arr = df2[from_var].astype("datetime64[D]").to_numpy()
    to_arr = df2[to_var].astype("datetime64[D]").to_numpy()
    udates_arr = np.array(udates, dtype="datetime64[D]")

    # Numba ultra-fast 엔진 실행
    result_tuples = split_engine_numba(from_arr, to_arr, udates_arr)

    # 결과 DataFrame 생성
    out_rows = []
    for (idx, s, e) in result_tuples:
        row = df2.iloc[idx].copy()
        row[from_var] = pd.Timestamp(s)
        row[to_var] = pd.Timestamp(e)
        out_rows.append(row)

    final_df = pd.DataFrame(out_rows)

    # 정렬
    final_df = final_df.sort_values(by=[from_var, to_var]).reset_index(drop=True)

    return final_df
