"""Entry point for python -m w2t_bkin.cli"""

from . import app

if __name__ == "__main__":
    app()
