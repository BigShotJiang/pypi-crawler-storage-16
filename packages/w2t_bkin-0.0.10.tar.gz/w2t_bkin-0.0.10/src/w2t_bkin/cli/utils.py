"""Shared CLI utilities for formatting and display."""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


def setup_logging(level: str) -> None:
    """Configure logging for CLI.

    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    """
    logging.basicConfig(
        level=level.upper(),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )


def display_session_result(result) -> None:
    """Display session processing result.

    Args:
        result: SessionResult from process_session_flow
    """
    if result.success:
        console.print(f"\n[green]✓ Success![/green] NWB file: {result.nwb_path}")
        console.print(f"  Duration: [dim]{result.duration_seconds:.2f}s[/dim]")

        if result.validation:
            critical = sum(1 for r in result.validation if r.get("severity") == "CRITICAL")
            errors = sum(1 for r in result.validation if r.get("severity") == "ERROR")
            warnings = sum(1 for r in result.validation if r.get("severity") == "WARNING")

            if critical > 0 or errors > 0:
                console.print(f"[yellow]⚠ Validation issues: {critical} critical, {errors} errors, {warnings} warnings[/yellow]")
            else:
                console.print(f"[green]✓ Validation passed ({warnings} warnings)[/green]")
    else:
        console.print(f"\n[red]✗ Failed: {result.error}[/red]")


def display_batch_result(result) -> None:
    """Display batch processing results.

    Args:
        result: BatchResult from batch_process_flow
    """
    table = Table(title="Batch Processing Results")
    table.add_column("Metric", style="bold")
    table.add_column("Count", justify="right")

    table.add_row("Total", str(result.total))
    table.add_row("Successful", str(result.successful), style="green")
    table.add_row("Failed", str(result.failed), style="red")
    table.add_row("Skipped", str(result.skipped), style="dim")

    console.print(table)

    if result.errors:
        console.print("\n[bold red]Failed Sessions:[/bold red]")
        for session_key, error in result.errors.items():
            console.print(f"  • {session_key}: {error}")


def format_discoveries(sessions: List[Dict[str, Any]], output_format: str) -> str:
    """Format session discoveries as JSON/TSV/plain.

    Args:
        sessions: List of session dictionaries
        output_format: Output format (json, tsv, plain)

    Returns:
        Formatted string
    """
    if output_format == "json":
        return json.dumps(sessions, indent=2)
    elif output_format == "tsv":
        return "\n".join(f"{s['subject']}\t{s['session']}" for s in sessions)
    else:  # plain
        table = Table(title=f"Found {len(sessions)} session(s)")
        table.add_column("Subject", style="cyan")
        table.add_column("Session", style="yellow")
        table.add_column("Metadata", style="dim")

        for session in sessions:
            table.add_row(
                session["subject"],
                session["session"],
                session["metadata_file"],
            )

        # Render to string
        from io import StringIO

        string_io = StringIO()
        temp_console = Console(file=string_io, force_terminal=True)
        temp_console.print(table)
        return string_io.getvalue()


def display_validation_results(results: list, show_warnings: bool) -> None:
    """Display NWB validation results.

    Args:
        results: List of validation results from nwbinspector
        show_warnings: Whether to show warnings
    """
    if not results:
        console.print("[green]✓ No issues found - file is valid![/green]")
        return

    # Categorize results
    critical = [r for r in results if r.severity.name == "CRITICAL"]
    errors = [r for r in results if r.severity.name == "ERROR"]
    warnings = [r for r in results if r.severity.name == "WARNING"]

    # Display summary
    table = Table(title="Validation Summary")
    table.add_column("Severity", style="bold")
    table.add_column("Count", justify="right")

    if critical:
        table.add_row("CRITICAL", str(len(critical)), style="red bold")
    if errors:
        table.add_row("ERROR", str(len(errors)), style="red")
    if warnings:
        table.add_row("WARNING", str(len(warnings)), style="yellow")

    console.print(table)

    # Display details
    if critical or errors or (warnings and show_warnings):
        console.print("\n[bold]Details:[/bold]")

        for result in critical + errors:
            console.print(f"\n[red]●[/red] [{result.severity.name}] {result.check_function_name}")
            console.print(f"  {result.message}")
            console.print(f"  Location: {result.location}")

        if show_warnings:
            for result in warnings:
                console.print(f"\n[yellow]●[/yellow] [WARNING] {result.check_function_name}")
                console.print(f"  {result.message}")


def display_nwb_structure(nwbfile, show_acquisition: bool, show_trials: bool, show_devices: bool) -> None:
    """Display NWB file structure.

    Args:
        nwbfile: Opened NWBFile object
        show_acquisition: Whether to show acquisition data
        show_trials: Whether to show trials table
        show_devices: Whether to show devices
    """
    # File info
    console.print(
        Panel.fit(
            f"[bold cyan]NWB File Inspection[/bold cyan]\n" f"Identifier: [yellow]{nwbfile.identifier}[/yellow]\n" f"Session: [dim]{nwbfile.session_description}[/dim]",
            border_style="cyan",
        )
    )

    # Session metadata
    meta_table = Table(title="Session Metadata", show_header=False)
    meta_table.add_column("Field", style="bold")
    meta_table.add_column("Value")

    meta_table.add_row("Start Time", str(nwbfile.session_start_time))
    if nwbfile.timestamps_reference_time:
        meta_table.add_row("Reference Time", str(nwbfile.timestamps_reference_time))
    if nwbfile.experimenter:
        meta_table.add_row("Experimenter", ", ".join(nwbfile.experimenter))
    if nwbfile.lab:
        meta_table.add_row("Lab", nwbfile.lab)
    if nwbfile.institution:
        meta_table.add_row("Institution", nwbfile.institution)

    console.print(meta_table)

    # Subject
    if nwbfile.subject:
        subject_table = Table(title="Subject", show_header=False)
        subject_table.add_column("Field", style="bold")
        subject_table.add_column("Value")

        subject_table.add_row("ID", nwbfile.subject.subject_id)
        if nwbfile.subject.species:
            subject_table.add_row("Species", nwbfile.subject.species)
        if nwbfile.subject.sex:
            subject_table.add_row("Sex", nwbfile.subject.sex)
        if nwbfile.subject.age:
            subject_table.add_row("Age", nwbfile.subject.age)

        console.print(subject_table)

    # Devices
    if show_devices and nwbfile.devices:
        devices_table = Table(title="Devices")
        devices_table.add_column("Name", style="cyan")
        devices_table.add_column("Description")

        for name, device in nwbfile.devices.items():
            devices_table.add_row(name, device.description or "")

        console.print(devices_table)

    # Acquisition
    if show_acquisition and nwbfile.acquisition:
        acq_table = Table(title="Acquisition Data")
        acq_table.add_column("Name", style="yellow")
        acq_table.add_column("Type", style="dim")

        for name, obj in nwbfile.acquisition.items():
            acq_table.add_row(name, type(obj).__name__)

        console.print(acq_table)

    # Processing modules
    if nwbfile.processing:
        proc_table = Table(title="Processing Modules")
        proc_table.add_column("Module", style="green")
        proc_table.add_column("Containers", style="dim")

        for name, module in nwbfile.processing.items():
            containers = ", ".join(module.data_interfaces.keys())
            proc_table.add_row(name, containers)

        console.print(proc_table)

    # Trials
    if show_trials and nwbfile.trials is not None:
        console.print(f"\n[bold]Trials:[/bold] {len(nwbfile.trials)} trials")
        console.print(f"Columns: {', '.join(nwbfile.trials.colnames)}")


def _load_template(template_name: str) -> str:
    """Load template file from package templates directory.

    All templates are stored in src/w2t_bkin/templates/ as the single source of truth.
    Script templates are in scripts/ subdirectory.

    Args:
        template_name: Name of template file (e.g., ".env.template" or "scripts/start-server.sh.template")

    Returns:
        Template content as string

    Raises:
        FileNotFoundError: If template not found
    """
    import w2t_bkin

    template_dir = Path(w2t_bkin.__file__).parent / "templates"
    template_path = template_dir / template_name

    if not template_path.exists():
        raise FileNotFoundError(f"Template not found: {template_name} " f"(expected at {template_path})")

    return template_path.read_text()


def generate_docker_env(root_path: Path, env_path: Path) -> None:
    """Generate .env file for Docker Compose deployment using template.

    Args:
        root_path: Experiment root path
        env_path: Path to .env file to create
    """
    # Ensure docker directory exists
    env_path.parent.mkdir(parents=True, exist_ok=True)

    # Load template and substitute variables
    # Paths are relative to docker/ subdirectory (where docker-compose.yml lives)
    template = _load_template(".env.template")
    env_content = template.replace("{{DATA_ROOT}}", "../data")
    env_content = env_content.replace("{{MODELS_ROOT}}", "../models")
    env_content = env_content.replace("{{CONFIG_ROOT}}", "..")
    env_content = env_content.replace("{{OUTPUT_ROOT}}", "../data/processed")
    # Use 'dev' branch images by default (latest development images)
    env_content = env_content.replace("{{BRANCH}}", "dev")

    env_path.write_text(env_content)


def copy_docker_compose_template(dest_path: Path) -> bool:
    """Copy docker-compose.yml template to experiment directory.

    Args:
        dest_path: Destination path for docker-compose.yml

    Returns:
        True if successful, False otherwise
    """
    try:
        # Load from single source of truth in package templates/
        template = _load_template("docker-compose.yml.template")
        dest_path.write_text(template)
        return True
    except FileNotFoundError:
        console.print("[red]✗ docker-compose.yml template not found[/red]")
        return False
    except Exception as e:
        console.print(f"[red]✗ Failed to copy docker-compose.yml: {e}[/red]")
        return False


def copy_dockerfile(dest_path: Path) -> bool:
    """Copy Dockerfile from repository to experiment directory.

    Args:
        dest_path: Destination path for Dockerfile

    Returns:
        True if successful, False otherwise
    """
    try:
        import w2t_bkin

        # Try to find Dockerfile in repository root
        package_root = Path(w2t_bkin.__file__).parent.parent
        dockerfile_path = package_root / "Dockerfile"

        if dockerfile_path.exists():
            dest_path.write_text(dockerfile_path.read_text())
            return True
        else:
            return False
    except Exception as e:
        console.print(f"[yellow]⚠ Could not copy Dockerfile: {e}[/yellow]")
        return False


def create_startup_scripts(root_path: Path) -> None:
    """Create click-to-start scripts from templates.

    Args:
        root_path: Experiment root path
    """
    import platform

    # Script mapping: output filename -> template name (now in scripts/ subdirectory)
    scripts = {
        "start-server.bat": "scripts/start-server.bat.template",
        "start-server.sh": "scripts/start-server.sh.template",
        "stop-server.bat": "scripts/stop-server.bat.template",
        "stop-server.sh": "scripts/stop-server.sh.template",
        "view-logs.bat": "scripts/view-logs.bat.template",
        "view-logs.sh": "scripts/view-logs.sh.template",
        "open-ui.bat": "scripts/open-ui.bat.template",
        "open-ui.sh": "scripts/open-ui.sh.template",
    }

    for script_name, template_name in scripts.items():
        try:
            template = _load_template(template_name)
            script_path = root_path / script_name
            script_path.write_text(template)

            # Make shell scripts executable on Unix-like systems
            if script_name.endswith(".sh") and platform.system() != "Windows":
                script_path.chmod(0o755)
        except FileNotFoundError:
            console.print(f"[yellow]⚠ Template not found: {template_name}[/yellow]")
