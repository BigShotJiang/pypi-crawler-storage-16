# CjkCMS management commands

## Optional initialization of collections
If you tend to re-initialize the same set of collections on your websites, you can simplify the task by running the following command:
```
./manage.py init-collections.py
```
It will add the following collections:

["Covers", "Logos", "Resources", "People", "Articles", "Cards", "Icons"]

---
@TODO: add option to specify custom list of collectiosn