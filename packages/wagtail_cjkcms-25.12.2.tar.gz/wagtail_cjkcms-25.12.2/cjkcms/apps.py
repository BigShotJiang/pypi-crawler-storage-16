from django.apps import AppConfig


class CjkcmsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "cjkcms"
    verbose_name = "Cjk CMS"
