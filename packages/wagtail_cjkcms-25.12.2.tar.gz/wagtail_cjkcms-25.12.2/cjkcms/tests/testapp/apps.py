from django.apps import AppConfig


class TestAppConfig(AppConfig):
    name = "cjkcms.tests.testapp"  # replace `myapp` with your app name
    verbose_name = "TestApp"
