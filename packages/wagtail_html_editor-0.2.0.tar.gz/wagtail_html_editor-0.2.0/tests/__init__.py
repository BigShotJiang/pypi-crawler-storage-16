"""Tests for wagtail-html-editor."""
