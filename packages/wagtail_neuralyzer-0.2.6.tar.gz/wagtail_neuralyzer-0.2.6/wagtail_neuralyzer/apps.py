from django.apps import AppConfig


class WagtailNeuralyzerConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "wagtail_neuralyzer"
    label = "wagtail_neuralyzer"
