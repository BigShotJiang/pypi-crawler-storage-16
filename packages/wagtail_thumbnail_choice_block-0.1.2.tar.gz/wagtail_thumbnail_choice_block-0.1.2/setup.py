"""
Setup configuration for wagtail-thumbnail-choice-block.

This file exists for backwards compatibility but the configuration
is in pyproject.toml.
"""

from setuptools import setup

setup()
