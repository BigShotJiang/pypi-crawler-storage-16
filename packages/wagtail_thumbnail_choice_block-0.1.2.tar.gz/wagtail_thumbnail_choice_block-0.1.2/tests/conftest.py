"""
Pytest configuration for wagtail-thumbnail-choice-block tests.
"""

# This file can be used for pytest fixtures if needed.
# Django settings are configured via tests/settings.py
# and the DJANGO_SETTINGS_MODULE environment variable in pytest.ini
