"""Setup file for the package."""

__import__("setuptools").setup()
