# Security Policy

## Reporting a Vulnerability

Please report security issues by emailing `development @ waldiez.io` .

The project maintainers will then work with you to resolve any issues where required, prior to any public disclosure.
