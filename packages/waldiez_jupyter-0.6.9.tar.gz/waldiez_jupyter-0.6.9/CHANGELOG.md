# Changelog

## [unreleased]

## v0.1.19

- Updated waldiez to v0.1.19
- Updated @waldiez/react to v0.1.21
- Updated dev js dependencies

## v0.1.18

- Updated waldiez to v0.1.17
- Updated @waldiez/react to v0.1.20
- Updated other js dependencies
- Updated other py dependencies

## v0.1.17

- Updated @waldiez/react to v0.1.18
- Updated waldiez to v0.1.14
- Updated other js dependencies
- Updated other py dependencies

## v0.1.16

- Updated @waldiez/react to v0.1.17
- Changed filtering of flow messages
- Other js dependencies updates
- Other py dependencies updates

## v0.1.15

- Updated waldiez to v0.1.13

## v0.1.14

- Updated @waldiez/react to v0.16
- Updated waldiez to v0.1.12
- Other js dependencies
- Other py dependencies

## v0.1.13

- Updated @waldiez/react to v0.15
- Updated waldiez to v0.1.11
- Added travel planning and guardrails examples
- Updated js dependencies
- Updated py dependencies

## v0.1.12

- Updated @waldiez/react to v0.1.12

## v0.1.11

- Updated waldiez to v0.1.10

## v0.1.10

- Updated waldiez to v0.1.9

## v0.1.9

- Updated @waldiez/react to v0.1.11
- Updated waldiez to v0.1.8
- Other py and js dependencies updated

## v0.1.8

- Updated @waldiez/react to v0.1.10
- Dependency updates
- Minor bug fixes

## v0.1.7

- Updated @waldiez/react to v0.1.9

## v0.1.6

- Updated waldiez py to v0.1.6
- Updated frontend dependencies

## v0.1.5

- Updated waldiez py to v0.1.5
- Updated frontend dependencies
- Bug fixes
- Added examples

## v0.1.4

- Updated dependencies

## v0.1.3

- Updated dependencies

## v0.1.2

- Updated dependencies

## v0.1.1

- Updated frontend dependencies

## v0.1.0

- Initial release
