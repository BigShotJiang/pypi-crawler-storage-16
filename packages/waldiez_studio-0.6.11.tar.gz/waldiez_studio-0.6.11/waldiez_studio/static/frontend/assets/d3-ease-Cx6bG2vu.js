function n(n){return((n*=2)<=1?n*n*n:(n-=2)*n*n+2)/2}export{n as c};
