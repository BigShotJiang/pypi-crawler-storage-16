# Wanalysis, a mini library for microtonal analysis, like compare EDOs, absolute error, ratios, etc.
Compare EDOs (EDO = Equal Division of Octave), Cents, etc. In python?
1. What's the module **wamusica**?
    Wamusica is a module of wanalysis, compare EDOs, absolute error and relative error, etc. (microtonality), wamusica is only data for APIs
2. What's the module watexto?
    Watexto is the **visual wamusica**, It's like this:
    * watexto is for *humans*
    * and wamusica is for *PCs*
3. How do I install it?
    You only need Python 3.6 or more, Why? f-strings :3
    Now you can install it with ```pip install wanalysis``` (published in [PyPI](https://pypi.org/project/wanalysis/))
4. How do I use this?
    If you need data: use wamusica, If you need text: use watexto
    Wanalysis is open source
5. Some examples:
    Code in Wamusica:
    * Code:
        ```PY
        import wanalysis.wamusica as wm

        print(wm.compare(5/4, [12, 17]))
        ```
    * Console:
        ```PY
        {'12-edo': {'abs_error': 13.68629, 'rel_error': 0.03543}, '17-edo': {'abs_error': 33.37254, 'rel_error': 0.08639}}
        ```

    Other code in wamusica:
    * Code:
        ```PY
        import wanalysis.wamusica as wm

        print(wm.results(7/4, 31))
        ```
    * Console:
        ```PY
        {'steps_of_31-edo': {'steps': 25, 'cents': 967.74194}, 'cents_of_1.750': 968.82591, 'abs_error': 1.08397, 'rel_error': 0.00112}
        ```

    Code in Watexto:
    * Code
        ```PY
        import wanalysis.watexto as wtxt

        print(wtxt.text_results(5/4, 17))
        ```
    * Console:
        ```
        Steps of 17-edo: 5 (352.941 cents)
        Cents of 1.250: 386.314 cents
        Absolute error: 33.373 cents
        Relative error: 8.6387%

        ```
Thanks for read!