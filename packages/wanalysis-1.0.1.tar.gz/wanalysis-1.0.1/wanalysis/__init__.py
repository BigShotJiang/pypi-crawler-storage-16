from .wamusica import results, compare, cents_of
from .watexto import text_results, BOLD, UNDER_LINED, RESET