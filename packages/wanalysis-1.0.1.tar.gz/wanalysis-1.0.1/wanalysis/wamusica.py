import math

def cents_of(num: float):
        return (1200 * math.log2(num))
def micromidi(hz: float):
     return(69 + (12 * math.log2(hz / 440)))
def errors(v, v_aprox):
    abs_error = abs(v - v_aprox)
    if abs_error == 0:
        rel_error = 0
    else:
        rel_error = abs_error / v
    return {
        "abs_error": abs_error,
        "rel_error": rel_error
        }
def results(ratio: float, edo_: int):
    if not isinstance(ratio, (float, int)):
         raise ValueError("the ratio has to be a float or int")
    if ratio <= 0:
         raise ValueError("the ratio has to be more than 0")
    if not isinstance(edo_, int):
         raise ValueError("the edo has to be a int")
    if edo_ <= 0:
         raise ValueError("the edo has to be more than 0")
    edo = int(edo_)
    cents = cents_of(ratio)
    step = 1200 / edo
    steps = round(cents / step)
    steps_cents = steps * step
    abs__error = errors(cents, steps_cents)["abs_error"]
    rel__error = errors(cents, steps_cents)["rel_error"]
    return {
        f"steps_of_{edo}-edo": {
            "steps": steps,"cents": round(steps_cents, 5)
            },
        f"cents_of_{ratio:.3f}": round(cents, 5),
        "abs_error": round(abs__error, 5),
        "rel_error": round(rel__error, 5)
        }
def compare(ratio: float, edo_list: list[int]):
    if not isinstance(edo_list, list):
         raise TypeError("the edo list has to be a list")
    result = {}
    for edo in edo_list:
        data = results(ratio, edo)
        result[f"{edo}-edo"] = {
            "abs_error": data["abs_error"], "rel_error": data["rel_error"]
            }
    return result