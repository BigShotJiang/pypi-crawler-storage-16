import math
from . import wamusica as wm

BOLD = "\033[1m"
RESET = "\033[0m"
UNDER_LINED = "\033[4m"
def key_value(key: tuple[str], value: tuple[str, int, float]):
    return (f"{key}: {value}")
def decoration(text):
    return (f"{text}\n{ '-' * len(text) }")
def text_results(ratio: float, edo_: int):
    edo = int(edo_)
    cents = wm.cents_of(ratio)
    step = 1200 / edo
    steps = round(cents / step)
    steps_cents = steps * step
    error_s = wm.errors(cents, steps_cents)
    j = "\n"
    line1 =  key_value(f"{j}Steps of {edo}-edo", f"{steps} ({steps_cents:.3f} cents){j}") + key_value(f"Cents of {ratio:.3f}", f"{cents:.3f} cents{j}")
    line2 = key_value("Absolute error", f"{error_s['abs_error']:.3f} cents{j}") + key_value("Relative error", f"{error_s['rel_error'] * 100:.4f}%{j}")
    return (line1 + line2)