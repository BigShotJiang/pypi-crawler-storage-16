OPENROUTER_URL = "https://openrouter.ai/api/v1"
DASHBOARD_URL = "https://app.waveassist.io"
OPENROUTER_API_STORED_DATA_KEY = "open_router_key"

