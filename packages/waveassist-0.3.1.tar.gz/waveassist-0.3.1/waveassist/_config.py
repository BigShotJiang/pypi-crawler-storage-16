# waveassist/_config.py

# Module-level variable to hold the login token
LOGIN_TOKEN = None
PROJECT_KEY = None
ENVIRONMENT_KEY = None
RUN_ID = None
DEFAULT_ENVIRONMENT_KEY = None
DEFAULT_LOGIN_TOKEN = None
DEFAULT_PROJECT_KEY = None
DEFAULT_RUN_ID = None
VERSION = "0.3.1"
