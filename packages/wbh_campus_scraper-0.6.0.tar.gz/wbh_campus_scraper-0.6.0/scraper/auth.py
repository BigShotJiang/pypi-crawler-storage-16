"""
WBH Online Campus Authentication Module

Handles login and session management for the WBH Online Campus.
"""

import logging
import time
from typing import Optional, Dict, Any
import requests
from urllib.parse import urljoin, urlparse, parse_qs

logger = logging.getLogger(__name__)


class WBHAuthenticator:
    """Handles authentication for WBH Online Campus."""

    BASE_URL = "https://www.wb-online-campus.de"
    LOGIN_PAGE_URL = f"{BASE_URL}/login"
    LOGIN_API_URL = f"{BASE_URL}/api/v2/auth/login"  # API v2 endpoint (POST)
    STUDY_PROGRAMS_URL = f"{BASE_URL}/servlet/Lerner?cmd=1&fromHistory=1&display=main"

    def __init__(self):
        """Initialize authenticator with session."""
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache',
            'Referer': 'https://www.wb-online-campus.de/login'
        })
        self.logged_in = False

    def login(self, username: str, password: str) -> bool:
        """
        Login to WBH Online Campus using their API.

        Args:
            username: Campus username
            password: Campus password

        Returns:
            True if login successful, False otherwise
        """
        try:
            # First, get the login page to establish session
            logger.info("Establishing session...")
            self.session.get(self.LOGIN_PAGE_URL)

            # Login via API v2 using POST request with JSON body
            logger.info(f"Attempting login for user: {username}")

            # Make login request with credentials in JSON body
            response = self.session.post(
                self.LOGIN_API_URL,
                json={'username': username, 'password': password},
                headers={
                    **self.session.headers,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json, text/plain, */*',
                }
            )

            logger.debug(f"Login response status: {response.status_code}")

            # Check response
            if response.status_code == 200:
                # Successful login
                logger.info("Login successful!")
                self.logged_in = True

                # Log session cookie
                if 'JSESSIONID' in self.session.cookies:
                    logger.debug(f"Session established: JSESSIONID={self.session.cookies['JSESSIONID'][:10]}...")

                # Try to parse response
                try:
                    data = response.json()
                    logger.debug(f"Login response data: {data}")
                except:
                    # Might not be JSON
                    logger.debug(f"Response text: {response.text}")

                return True

            elif response.status_code == 401:
                # Authentication failed
                logger.error("Login failed - invalid credentials (401)")
                return False

            else:
                logger.warning(f"Unexpected response status: {response.status_code}")
                logger.debug(f"Response text: {response.text[:500]}")
                return False

        except Exception as e:
            logger.error(f"Login error: {e}")
            return False

    def get_study_programs_page(self) -> Optional[str]:
        """
        Get the study programs page HTML.

        Returns:
            HTML content of study programs page or None if failed
        """
        if not self.logged_in:
            logger.error("Not logged in. Please login first.")
            return None

        try:
            logger.info("Fetching study programs page...")
            response = self.session.get(self.STUDY_PROGRAMS_URL)

            if response.status_code == 200:
                return response.text
            else:
                logger.error(f"Failed to fetch study programs. Status: {response.status_code}")
                return None

        except Exception as e:
            logger.error(f"Error fetching study programs: {e}")
            return None

    def get_study_program_detail(self, program_url: str, force_reload: bool = True) -> Optional[str]:
        """
        Get the detailed page for a specific study program.

        Args:
            program_url: URL or path to the study program
            force_reload: Whether to reload the page to ensure JSON data is present

        Returns:
            HTML content with study program details or None if failed
        """
        if not self.logged_in:
            logger.error("Not logged in. Please login first.")
            return None

        try:
            # Decode HTML entities in URL
            from html import unescape
            program_url = unescape(program_url)

            # Make URL absolute if it's relative
            if not program_url.startswith('http'):
                program_url = urljoin(self.BASE_URL, program_url)

            logger.info(f"Fetching study program detail: {program_url}")
            response = self.session.get(program_url)

            if response.status_code != 200:
                logger.error(f"Failed to fetch program. Status: {response.status_code}")
                return None

            html_content = response.text

            # Check if JSON data is present
            if "WL.DEBUG.iCurriculumJSON" not in html_content and force_reload:
                logger.info("JSON data not found, reloading page...")
                # Force reload by adding a cache-busting parameter
                separator = '&' if '?' in program_url else '?'
                reload_url = f"{program_url}{separator}_={int(time.time() * 1000)}"
                response = self.session.get(reload_url)
                html_content = response.text

                if "WL.DEBUG.iCurriculumJSON" in html_content:
                    logger.info("JSON data found after reload!")
                else:
                    logger.warning("JSON data still not found after reload")

            return html_content

        except Exception as e:
            logger.error(f"Error fetching study program detail: {e}")
            return None

    def logout(self):
        """Logout from the campus."""
        if self.logged_in:
            try:
                # Try to find and call logout URL
                logout_url = f"{self.BASE_URL}/logout"
                self.session.get(logout_url)
                logger.info("Logged out successfully")
            except:
                pass
            finally:
                self.logged_in = False
                self.session.close()
                self.session = requests.Session()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - ensure logout."""
        self.logout()