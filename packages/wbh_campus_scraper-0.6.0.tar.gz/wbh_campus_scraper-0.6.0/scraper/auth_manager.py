"""
Cross-platform secure credential management for WBH Campus Scraper.

Supports:
- macOS: Keychain
- Linux: Secret Service (GNOME Keyring, KWallet)
- Windows: Windows Credential Manager
"""

import sys
import logging
from typing import Optional, Tuple
import getpass

logger = logging.getLogger(__name__)

# Try to import keyring
try:
    import keyring
    KEYRING_AVAILABLE = True
except ImportError:
    KEYRING_AVAILABLE = False
    logger.warning("keyring not available - credentials will not be stored")

SERVICE_NAME = "wbh-campus"


class CredentialManager:
    """
    Secure credential management across platforms.

    Uses the system's native credential storage:
    - macOS: Keychain
    - Windows: Credential Manager
    - Linux: Secret Service/Keyring
    """

    def __init__(self, use_keyring: bool = True):
        """
        Initialize credential manager.

        Args:
            use_keyring: Whether to use keyring if available
        """
        self.use_keyring = use_keyring and KEYRING_AVAILABLE

        if self.use_keyring:
            backend = keyring.get_keyring()
            logger.debug(f"Using keyring backend: {backend.__class__.__name__}")

    def get_credentials(self, username: Optional[str] = None) -> Tuple[str, str]:
        """
        Get credentials from secure storage or prompt user.

        Args:
            username: Optional username. If not provided, will prompt.

        Returns:
            Tuple of (username, password)
        """

        # Get username
        if not username:
            username = input("WBH Campus username: ")

        # Try to get from keyring
        password = None
        if self.use_keyring:
            try:
                password = keyring.get_password(SERVICE_NAME, username)
                if password:
                    logger.info(f"Retrieved credentials for '{username}' from secure storage")
            except Exception as e:
                logger.warning(f"Could not retrieve from keyring: {e}")

        # If not in keyring, prompt
        if not password:
            password = getpass.getpass(f"WBH Campus password for {username}: ")

            # Offer to save
            if self.use_keyring:
                print("\n" + "="*60)
                print("SECURITY WARNING")
                print("Only store credentials on your PERSONAL computer!")
                print("Never store credentials on shared or public computers.")
                print("="*60)
                save = input("\nSave password securely? (y/n): ").lower()
                if save == 'y':
                    try:
                        keyring.set_password(SERVICE_NAME, username, password)
                        logger.info("Password saved to secure storage")
                    except Exception as e:
                        logger.warning(f"Could not save to keyring: {e}")

        return username, password

    def store_credentials(self, username: str, password: str) -> bool:
        """
        Store credentials in secure storage.

        Args:
            username: WBH Campus username
            password: WBH Campus password

        Returns:
            True if successfully stored
        """
        if not self.use_keyring:
            logger.warning("Keyring not available - credentials not stored")
            return False

        try:
            keyring.set_password(SERVICE_NAME, username, password)
            logger.info(f"Stored credentials for '{username}' in secure storage")
            return True
        except Exception as e:
            logger.error(f"Failed to store credentials: {e}")
            return False

    def delete_credentials(self, username: str) -> bool:
        """
        Delete credentials from secure storage.

        Args:
            username: Username to delete credentials for

        Returns:
            True if successfully deleted
        """
        if not self.use_keyring:
            return False

        try:
            keyring.delete_password(SERVICE_NAME, username)
            logger.info(f"Deleted credentials for '{username}'")
            return True
        except Exception as e:
            logger.error(f"Failed to delete credentials: {e}")
            return False

    @staticmethod
    def is_available() -> bool:
        """Check if keyring is available on this system."""
        return KEYRING_AVAILABLE

    @staticmethod
    def get_backend_info() -> str:
        """Get information about the current keyring backend."""
        if not KEYRING_AVAILABLE:
            return "Keyring not available"

        try:
            backend = keyring.get_keyring()
            return f"{backend.__class__.__name__} on {sys.platform}"
        except:
            return "Unknown backend"


# Convenience functions
def get_credentials(username: Optional[str] = None) -> Tuple[str, str]:
    """
    Get WBH Campus credentials from secure storage.

    This is a convenience function that creates a temporary CredentialManager.

    Args:
        username: Optional username

    Returns:
        Tuple of (username, password)
    """
    manager = CredentialManager()
    return manager.get_credentials(username)


def reset_credentials():
    """
    Reset/delete stored credentials.
    """
    print("=" * 60)
    print("Reset WBH Campus Credentials")
    print("=" * 60)

    if not KEYRING_AVAILABLE:
        print("\nKeyring not available - no credentials stored")
        return

    manager = CredentialManager()
    print(f"\nUsing: {manager.get_backend_info()}")

    username = input("\nUsername to reset (or 'all' for all users): ")

    if username.lower() == 'all':
        print("\nNote: Bulk deletion not supported. Please delete individually.")
        username = input("Enter specific username to delete: ")

    if username:
        confirm = input(f"\nReally delete credentials for '{username}'? (yes/no): ")
        if confirm.lower() == 'yes':
            if manager.delete_credentials(username):
                print(f"\nCredentials for '{username}' have been deleted.")
            else:
                print(f"\nNo credentials found for '{username}' or deletion failed.")
        else:
            print("\nDeletion cancelled.")


def setup_credentials():
    """Interactive setup for storing credentials."""
    print("=" * 60)
    print("WBH Campus Credential Setup")
    print("=" * 60)
    print("\nSECURITY WARNING:")
    print("Only store credentials on your PERSONAL computer!")
    print("Never use this on shared or public computers.")
    print("=" * 60)

    if not KEYRING_AVAILABLE:
        print("\nWarning: Keyring module not installed!")
        print("Install with: pip install keyring")
        return

    manager = CredentialManager()
    print(f"\nUsing: {manager.get_backend_info()}")

    username = input("\nWBH Campus username: ")
    password = getpass.getpass("WBH Campus password: ")

    if manager.store_credentials(username, password):
        print(f"\nCredentials stored securely for '{username}'")

        # Test retrieval
        test_user, test_pass = manager.get_credentials(username)
        if test_pass == password:
            print("Verification successful!")
        else:
            print("Warning: Verification failed")
    else:
        print("Error: Failed to store credentials")


if __name__ == "__main__":
    # Run setup if called directly
    setup_credentials()