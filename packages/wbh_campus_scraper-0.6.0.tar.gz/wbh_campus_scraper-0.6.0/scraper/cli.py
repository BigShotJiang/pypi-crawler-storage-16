#!/usr/bin/env python3
"""
WBH Campus Data Extractor CLI

Command-line interface for extracting study data from WBH Online Campus HTML exports.
"""

import argparse
import json
import sys
from pathlib import Path

from . import WBHScraper


def main():
    """Main CLI function."""
    parser = argparse.ArgumentParser(
        description="Extract study data from WBH Online Campus",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s curriculum.html                    # Extract from local HTML file
  %(prog)s curriculum.html -o output.json     # Custom output file
  %(prog)s --online -u USERNAME               # Extract directly from campus (prompts for password)
  %(prog)s --online -u USERNAME -p PASSWORD   # Extract with credentials
  %(prog)s --online -u USERNAME --program 0   # Select specific study program
  %(prog)s curriculum.html --debug            # Enable debug mode
        """
    )

    parser.add_argument(
        "input",
        type=Path,
        nargs='?',  # Make optional for online mode
        help="Input HTML file (e.g., curriculum.html). Not required with --online"
    )

    parser.add_argument(
        "-o", "--output",
        type=Path,
        default=Path("data.json"),
        help="Output JSON file (default: data.json)"
    )

    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug mode (saves raw JSON)"
    )

    parser.add_argument(
        "--pretty",
        action="store_true",
        default=True,
        help="Pretty print JSON output (default: True)"
    )

    parser.add_argument(
        "--no-pretty",
        dest="pretty",
        action="store_false",
        help="Disable pretty printing for compact JSON"
    )

    # Online mode arguments
    parser.add_argument(
        "--online",
        action="store_true",
        help="Scrape directly from WBH Online Campus"
    )

    parser.add_argument(
        "-u", "--username",
        help="Campus username (for online mode)"
    )

    parser.add_argument(
        "-p", "--password",
        help="Campus password (for online mode, will prompt if not provided)"
    )

    parser.add_argument(
        "--program",
        type=int,
        help="Index of study program to select if multiple (for online mode)"
    )

    # Credential management arguments
    parser.add_argument(
        "--setup-credentials",
        action="store_true",
        help="Setup/store credentials in system keychain (PERSONAL computers only!)"
    )

    parser.add_argument(
        "--reset-credentials",
        action="store_true",
        help="Delete stored credentials from system keychain"
    )

    parser.add_argument(
        "-v", "--version",
        action="version",
        version="%(prog)s 0.6.0"
    )

    args = parser.parse_args()

    # Handle credential management commands
    if args.setup_credentials:
        try:
            from .auth_manager import setup_credentials
            setup_credentials()
            return 0
        except ImportError:
            print("Error: keyring module not installed")
            print("Install with: pip install keyring")
            return 1
        except Exception as e:
            print(f"Error setting up credentials: {e}")
            return 1

    if args.reset_credentials:
        try:
            from .auth_manager import reset_credentials
            reset_credentials()
            return 0
        except ImportError:
            print("Error: keyring module not installed")
            print("Install with: pip install keyring")
            return 1
        except Exception as e:
            print(f"Error resetting credentials: {e}")
            return 1

    # Handle online mode
    if args.online:
        # Try to use secure credential storage
        try:
            from .auth_manager import CredentialManager
            cred_manager = CredentialManager()

            # Get credentials (from keyring or prompt)
            if args.username:
                username, password = cred_manager.get_credentials(args.username)
            else:
                username, password = cred_manager.get_credentials()

            # Override with command-line password if provided
            if args.password:
                password = args.password

        except ImportError:
            # Fallback to traditional method
            if not args.username:
                print("Error: Username required for online mode (use -u USERNAME)")
                sys.exit(1)

            username = args.username
            password = args.password
            if not password:
                import getpass
                password = getpass.getpass("Campus password: ")

        try:
            # Initialize scraper
            scraper = WBHScraper(debug=args.debug)

            # Check if we need to select a program
            program_index = args.program
            if program_index is None:
                # Try to get available programs first
                print(f"Checking available programs for {username}...")
                available = scraper.get_available_programs(username, password)

                if available and len(available) > 1:
                    # Multiple programs - ask user to select
                    print(f"\nFound {len(available)} study programs:")
                    for idx, name, _ in available:
                        print(f"  [{idx}] {name}")

                    # Interactive selection if in terminal
                    if sys.stdin.isatty():
                        while True:
                            try:
                                choice = input(f"\nSelect program (0-{len(available)-1}): ").strip()
                                program_index = int(choice)
                                if 0 <= program_index < len(available):
                                    break
                                print(f"Invalid choice. Please enter 0-{len(available)-1}")
                            except (ValueError, KeyboardInterrupt):
                                print("\nAborted.")
                                sys.exit(1)
                    else:
                        # Non-interactive - use first program
                        print("\nNo program specified. Using first program.")
                        program_index = 0
                elif available and len(available) == 1:
                    # Single program - auto-select
                    program_index = 0
                    print(f"Auto-selecting single program: {available[0][1]}")

            # Scrape online with selected program
            print(f"\nLogging in as {username}...")
            study_program = scraper.scrape_online(
                username=username,
                password=password,
                program_index=program_index
            )

            if not study_program:
                print("Error: Failed to scrape data from campus")
                sys.exit(1)

            print(f"Successfully extracted data")

            # Save to file
            scraper.save_to_file(args.output, pretty=args.pretty)
            print(f"Data saved to {args.output}")

            # Show brief info
            print()
            print(f"{study_program.study_program.number} - {study_program.study_program.name}")
            print(f"   {len(study_program.modules)} modules, {len(study_program.elements)} elements")

            return 0

        except Exception as e:
            print(f"Error: {e}")
            if args.debug:
                import traceback
                traceback.print_exc()
            return 1

    # Handle file mode (existing functionality)
    else:
        if not args.input:
            print("Error: Input file required (or use --online for campus scraping)")
            sys.exit(1)

        if not args.input.exists():
            print(f"Error: Input file '{args.input}' not found!")
            sys.exit(1)

        try:
            # Initialize scraper with file path
            print(f"Loading {args.input}...")
            scraper = WBHScraper(file_path=args.input, debug=args.debug)

            # Transform data (automatically loads from file path)
            study_program = scraper.transform()

            print(f"Successfully extracted data")

            # Save to file
            scraper.save_to_file(args.output, pretty=args.pretty)
            print(f"Data saved to {args.output}")

            # Show brief info
            print()
            print(f"{study_program.study_program.number} - {study_program.study_program.name}")
            print(f"   {len(study_program.modules)} modules, {len(study_program.elements)} elements")

            return 0

        except Exception as e:
            print(f"Error: {e}")
            if args.debug:
                import traceback
                traceback.print_exc()
            return 1


if __name__ == "__main__":
    sys.exit(main())