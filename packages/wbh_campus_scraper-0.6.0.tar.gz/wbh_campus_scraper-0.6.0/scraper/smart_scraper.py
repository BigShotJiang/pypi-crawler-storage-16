"""
Smart WBH Campus Scraper with automatic credential management.

This module provides a high-level interface that handles:
- Automatic credential retrieval from keychain
- First-time setup with save prompt
- Automatic retry on auth failure
- Password change detection
"""

import logging
from typing import Optional, List, Tuple
from .scraper import WBHScraper
from .models import StudyPlanData

logger = logging.getLogger(__name__)

# Try to import credential manager
try:
    from .auth_manager import CredentialManager
    KEYRING_AVAILABLE = True
except ImportError:
    KEYRING_AVAILABLE = False
    logger.info("Keyring not available - credentials won't be persisted")


class SmartWBHScraper:
    """
    Smart scraper that handles credentials automatically.

    Perfect for integration in other apps - just call scrape() and it handles everything!
    """

    def __init__(self, username: Optional[str] = None, auto_save: bool = True):
        """
        Initialize smart scraper.

        Args:
            username: Optional username to use (will prompt if not provided)
            auto_save: Whether to automatically offer to save credentials (default: True)
        """
        self.username = username
        self.auto_save = auto_save
        self.scraper = WBHScraper()
        self.cred_manager = CredentialManager() if KEYRING_AVAILABLE else None
        self._cached_password = None

    def scrape(self, program_index: Optional[int] = None, retry_on_fail: bool = True) -> Optional[StudyPlanData]:
        """
        Smart scrape with automatic credential handling.

        This method handles everything:
        1. Gets credentials (from keychain, cache, or prompt)
        2. Attempts login
        3. On failure: clears saved password and retries (once)
        4. Returns scraped data or None

        Args:
            program_index: Optional program index if multiple programs
            retry_on_fail: Whether to retry with new password on auth failure

        Returns:
            StudyPlanData object or None if failed
        """
        # Get credentials
        username, password = self._get_credentials()
        if not username or not password:
            logger.error("No credentials provided")
            return None

        # Try to scrape
        logger.info(f"Attempting to scrape for user: {username}")
        result = self.scraper.scrape_online(username, password, program_index)

        # Handle failure
        if not result and retry_on_fail:
            logger.warning("Authentication failed - password may have changed")

            # Clear saved password
            if self.cred_manager:
                logger.info("Clearing saved password...")
                self.cred_manager.delete_credentials(username)

            # Clear cache
            self._cached_password = None

            # Retry with fresh credentials
            print("\nWarning: Authentication failed - please enter credentials again")
            username, password = self._get_credentials(force_prompt=True)

            if username and password:
                logger.info("Retrying with new credentials...")
                result = self.scraper.scrape_online(username, password, program_index)

                if result:
                    logger.info("Success with new credentials!")
                else:
                    logger.error("Authentication still failing - check credentials or campus availability")

        return result

    def get_available_programs(self) -> Optional[List[Tuple[int, str, str]]]:
        """
        Get list of available programs with automatic auth.

        Returns:
            List of (index, name, url) tuples or None
        """
        username, password = self._get_credentials()
        if not username or not password:
            return None

        return self.scraper.get_available_programs(username, password)

    def scrape_all_programs(self) -> List[StudyPlanData]:
        """
        Scrape all available programs.

        Returns:
            List of StudyPlanData objects
        """
        programs = self.get_available_programs()
        if not programs:
            return []

        results = []
        for idx, name, _ in programs:
            logger.info(f"Scraping program {idx}: {name}")
            result = self.scrape(program_index=idx, retry_on_fail=False)
            if result:
                results.append(result)

        return results

    def _get_credentials(self, force_prompt: bool = False) -> Tuple[Optional[str], Optional[str]]:
        """
        Get credentials with smart handling.

        Priority:
        1. Cached password (if not forcing prompt)
        2. Keychain (if available and not forcing)
        3. Prompt user

        Args:
            force_prompt: Force prompting even if credentials are saved

        Returns:
            Tuple of (username, password) or (None, None)
        """
        # Use cached if available
        if not force_prompt and self._cached_password and self.username:
            logger.debug("Using cached credentials")
            return self.username, self._cached_password

        # Get username
        if not self.username:
            self.username = input("WBH Campus username: ")

        # Try keychain first (unless forcing prompt)
        password = None
        if not force_prompt and self.cred_manager:
            try:
                _, password = self.cred_manager.get_credentials(self.username)
                if password:
                    logger.info("Retrieved password from secure storage")
                    self._cached_password = password
                    return self.username, password
            except:
                pass

        # Prompt for password
        import getpass
        password = getpass.getpass(f"WBH Campus password for {self.username}: ")

        # Offer to save (if auto_save enabled)
        if password and self.auto_save and self.cred_manager:
            save = input("Save password securely for future use? (y/n): ").lower()
            if save == 'y':
                try:
                    self.cred_manager.store_credentials(self.username, password)
                    logger.info("Password saved to secure storage")
                except Exception as e:
                    logger.warning(f"Could not save password: {e}")

        # Cache for this session
        self._cached_password = password
        return self.username, password


def quick_scrape(username: Optional[str] = None) -> Optional[StudyPlanData]:
    """
    Convenience function for quick scraping.

    Just call this and it handles everything!

    Args:
        username: Optional username (will prompt if not provided)

    Returns:
        StudyPlanData or None

    Example:
        >>> from scraper.smart_scraper import quick_scrape
        >>> data = quick_scrape()  # Handles everything!
        >>> if data:
        ...     print(f"Got {len(data.modules)} modules")
    """
    scraper = SmartWBHScraper(username)
    return scraper.scrape()


# For apps like your organizer
class WBHDataProvider:
    """
    Simple interface for app integration.

    Example for your app:
        provider = WBHDataProvider()
        data = provider.get_study_data()  # That's it!
    """

    def __init__(self):
        self.scraper = SmartWBHScraper(auto_save=True)

    def get_study_data(self) -> Optional[dict]:
        """
        Get study data as dictionary.

        Handles all authentication automatically.
        First time: Prompts for credentials and offers to save.
        Next times: Uses saved credentials.
        On failure: Re-prompts automatically.

        Returns:
            Dictionary with study data or None
        """
        result = self.scraper.scrape()
        if result:
            return result.to_dict()
        return None

    def get_available_programs(self) -> Optional[list]:
        """Get list of available programs."""
        programs = self.scraper.get_available_programs()
        if programs:
            return [{"index": idx, "name": name} for idx, name, _ in programs]
        return None

    def get_specific_program(self, index: int) -> Optional[dict]:
        """Get specific program by index."""
        result = self.scraper.scrape(program_index=index)
        if result:
            return result.to_dict()
        return None