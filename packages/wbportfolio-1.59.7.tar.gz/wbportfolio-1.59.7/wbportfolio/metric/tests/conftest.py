from wbfdm.contrib.metric.factories import InstrumentMetricFactory
from wbportfolio.tests.conftest import *  # noqa

register(InstrumentMetricFactory)
