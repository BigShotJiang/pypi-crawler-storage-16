from django.apps import AppConfig


class WbtasksConfig(AppConfig):
    name = "wbtasks"
