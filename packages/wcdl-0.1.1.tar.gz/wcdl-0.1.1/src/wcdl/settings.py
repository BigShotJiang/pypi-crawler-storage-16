SITE = "https://weebcentral.com/"
SEARCH_URL = SITE + "search/data"
CHAPTER_LIST_URL = "https://weebcentral.com/series/{}/full-chapter-list"
CHAPTER_IMAGES_URL = "https://weebcentral.com/chapters/{}/images"