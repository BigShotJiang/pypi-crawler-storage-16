from typing import Any
import httpx
from mcp.server.fastmcp import FastMCP 

mcp = FastMCP("weather")

@mcp.tool()
async def get_weather(latitude: float, longitude: float) -> str:
    """
    특정위치(위도, 경도)의 날씨 정보를 반환합니다.
    Args:
        latitude : 위도 (예: 37.56) 
        longitude : 경도 (예: 126.97)
        
    """
    url = f"https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&current=temperature_2m,wind_speed_10m&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m"

    async with httpx.AsyncClient() as client:
        response = await client.get(url)
        data = response.json()
        
        return str(data)

def main():
    mcp.run()


if __name__ == "__main__":
    main()
