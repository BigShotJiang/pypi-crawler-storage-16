from typing import Any
import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("weather")

# tool은 함수, AI가 사용할 수 있는 도구 , OpenAPI
@mcp.tool()
async def get_weather_custom(latitude: float, longitude: float) -> str:
    """
    Docstring for get_weather_custom
    
    특정 위치(위도, 경도)의 날씨 예보를 반환합니다. 
    Args: 
        - latitude: 위도 ( 예: 37.56)
        - longtitude: 경도(예: 126.97)
    """
    url = f"https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&current=temperature_2m,wind_speed_10m&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m"    

    async with httpx.AsyncClient() as client:
        response = await client.get(url)
        data = response.json()
    
    return str(data)



def main():
    mcp.run()


# 이 파일을 직접적으로 실행한 경우
if __name__ == "__main__":
    main()
