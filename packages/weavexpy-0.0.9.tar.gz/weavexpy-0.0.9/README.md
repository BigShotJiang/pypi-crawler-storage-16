# WeavexPy - 0.0.8 - beta

**0.0.1** -> **0.0.3** = not available

---
**0.0.4** = test launch

---
**0.0.5** = official beta version

---
**0.0.6** = In this version, we added a function that displays all the application console data (logs, errors, etc.) in the Python console, for example:

Web console:

Hello World

Python console:

DD/MM/YYYY HH:MM:SS - [console:log] - Hello World

---
**0.0.7** = In this version we can use `@keyframes` animations, and a simple object has been added that allows you to create a navigation menu when you right-click on the screen. To add it to the page, call `NavMenu()`, which is basically a Brython script. In addition, you can create message boxes.

---
**0.0.8** = new `WindowServer`.

---
**0.0.9** = + brython.

---