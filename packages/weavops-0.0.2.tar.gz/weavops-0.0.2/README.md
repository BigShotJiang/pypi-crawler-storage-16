# weavops
WeavOps bridges GitOps with MCP-powered AI agents, automatically weaving your Git source of truth into autonomous, context-aware operations
