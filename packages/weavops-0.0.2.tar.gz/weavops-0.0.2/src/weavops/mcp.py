from fastmcp import FastMCP

mcp = FastMCP("weavops")
