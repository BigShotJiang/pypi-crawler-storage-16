"""Data access layer."""

from .database import ConfigDatabase

__all__ = ["ConfigDatabase"]
