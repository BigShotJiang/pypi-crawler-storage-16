"""Web Alert - A modern web monitoring and alert system."""

__version__ = "1.0.2"
__author__ = "Web Alert Team"
