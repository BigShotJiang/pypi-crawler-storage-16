---
name: Feature Request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

- [ ] I checked to make sure that this is not a duplicate issue

### Describe the solution you'd like
A clear and concise description of what you want to happen.
