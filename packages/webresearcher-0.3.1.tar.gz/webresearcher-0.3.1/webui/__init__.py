# -*- coding: utf-8 -*-
"""
WebResearcher Web UI
"""
__version__ = "0.2.0"
