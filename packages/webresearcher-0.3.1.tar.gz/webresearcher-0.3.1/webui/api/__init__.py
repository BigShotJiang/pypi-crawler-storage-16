# -*- coding: utf-8 -*-
"""
API Layer for WebResearcher Web UI
"""
