# -*- coding: utf-8 -*-
"""
Configuration module for WebResearcher Web UI
"""
