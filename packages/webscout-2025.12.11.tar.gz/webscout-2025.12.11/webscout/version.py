__version__ = "2025.12.11"
__prog__ = "webscout"
