__version__ = "2025.12.9"
__prog__ = "webscout"
