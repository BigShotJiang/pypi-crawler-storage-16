def test_import():
    import webtools  # noqa: F401
