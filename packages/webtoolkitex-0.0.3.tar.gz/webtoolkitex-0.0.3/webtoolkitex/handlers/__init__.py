"""
Provides special handling for individual pages
"""

from .handlervideoyoutube import *
from .handlerchannelyoutube import *
