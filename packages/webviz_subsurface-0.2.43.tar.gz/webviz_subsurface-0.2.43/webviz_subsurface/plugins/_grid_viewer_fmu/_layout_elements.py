class ElementIds:
    # pylint: disable=too-few-public-methods
    ID = "grid-view"
    IJK_CROP_STORE = "ijk-filter-store"
