from ._crossplot_figure import update_crossplot
from ._errorplot_figure import update_errorplot
