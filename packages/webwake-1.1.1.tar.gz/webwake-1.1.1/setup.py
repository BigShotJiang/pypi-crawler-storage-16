from setuptools import setup, find_packages

setup(
    name="webwake",
    version="1.1.1",
    author="Starexx",
    author_email="starexx.m@gmail.com",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "requests",
        "pybase69"
    ],
    entry_points={
        "console_scripts": ["wake=webwake:main"]
    },
    python_requires=">=3.7",
)