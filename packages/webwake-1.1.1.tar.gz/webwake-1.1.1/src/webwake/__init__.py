#!/usr/bin/env python3

import json as _a
import requests as _b
import sys as _c
import os as _d
import getpass as _e
import time as _f
import base64 as _g

def _h(i):
    try:
        import base69
        j = base69.b69decode(i)
        k = "XKLM"
        l = ""
        for m in range(len(j)):
            l += chr(j[m] ^ ord(k[m % 4]))
        return l
    except ImportError:
        print("ImportError: pyBase69 not installed")
        _c.exit(1)

class Stary:
    def __init__(self):
        self._n = "BUf3jL^8BCvxPaVJL5B@9RHDwzKrBMukrTZZhCj#q=if7gJW5gGeYNWYX=tpmYuU64g!PGbrQMc8M.pD2teNyJ36%U+J@cAM&&pBt?hA~Aec9j8soC42ZmGUY."
        self._o = "5vJX^GWQsZ4bE~"
        self._p = "MkzJ"
        self._q = _d.path.expanduser('~/.webwake')
        self._r = _d.path.join(self._q, 'config.json')
        _d.makedirs(self._q, exist_ok=True)
        self._s = self._t()
    
    def _t(self):
        if _d.path.exists(self._r):
            try:
                with open(self._r, 'r') as u:
                    return _a.load(u)
            except:
                return {}
        return {}
    
    def _u(self):
        with open(self._r, 'w') as u:
            _a.dump(self._s, u)
    
    def _v(self, w):
        x = _h(self._n)
        y = _h(self._o)
        z = _h(self._p)
        aa = f'https://api.github.com/repos/{y}/{z}'
        ab = {'Authorization': f'token {x}', 'Accept': 'application/vnd.github.v3+json'}
        ac = _b.put(f"{aa}/contents/{w}", headers=ab, json={"message": "Create", "content": _g.b64encode(w.encode()).decode(), "branch": "main"})
        return ac.status_code == 201
    
    def _w(self, w, ad, ae):
        x = _h(self._n)
        y = _h(self._o)
        z = _h(self._p)
        aa = f'https://api.github.com/repos/{y}/{z}'
        ab = {'Authorization': f'token {x}', 'Accept': 'application/vnd.github.v3+json'}
        ac = _b.put(f"{aa}/contents/{w}", headers=ab, json={"message": "Update", "content": _g.b64encode(ad.encode()).decode(), "sha": ae, "branch": "main"})
        return ac.status_code == 200
    
    def _x(self, w):
        x = _h(self._n)
        y = _h(self._o)
        z = _h(self._p)
        aa = f'https://api.github.com/repos/{y}/{z}'
        ab = {'Authorization': f'token {x}', 'Accept': 'application/vnd.github.v3+json'}
        ac = _b.get(f"{aa}/contents/{w}", headers=ab)
        if ac.status_code == 200:
            af = ac.json()
            ag = _g.b64decode(af['content']).decode('utf-8')
            return ag, af['sha']
        return None, None
    
    def _y(self, w, ae):
        x = _h(self._n)
        y = _h(self._o)
        z = _h(self._p)
        aa = f'https://api.github.com/repos/{y}/{z}'
        ab = {'Authorization': f'token {x}', 'Accept': 'application/vnd.github.v3+json'}
        ac = _b.delete(f"{aa}/contents/{w}", headers=ab, json={"message": "Delete", "sha": ae, "branch": "main"})
        return ac.status_code == 200
    
    def _z(self):
        ah, _ = self._x("users.json")
        if ah:
            try:
                return _a.loads(ah)
            except:
                return {}
        return {}
    
    def _A(self, ai):
        aj = _a.dumps(ai, indent=2)
        ak, al = self._x("users.json")
        if ak:
            return self._w("users.json", aj, al)
        return self._v("users.json")
    
    def _B(self, am, an, ao):
        ap = f"users/{am}/{an}"
        aq, ar = self._x(ap)
        if aq:
            return self._w(ap, ao, ar)
        return self._v(ap)
    
    def _C(self, am, an):
        ap = f"users/{am}/{an}"
        as_, ar = self._x(ap)
        if as_ and ar:
            return self._y(ap, ar)
        return False
    
    def _D(self, am):
        at = f"users/{am}"
        au = []
        x = _h(self._n)
        y = _h(self._o)
        z = _h(self._p)
        aa = f'https://api.github.com/repos/{y}/{z}'
        ab = {'Authorization': f'token {x}', 'Accept': 'application/vnd.github.v3+json'}
        av = _b.get(f"{aa}/contents/{at}", headers=ab)
        if av.status_code == 200:
            for aw in av.json():
                if aw['type'] == 'file' and aw['name'].endswith('.html'):
                    au.append(aw['name'][:-5])
        return au
    
    def _E(self):
        ax = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
        ay = _f.time() + 5.0
        az = 0
        while _f.time() < ay:
            _c.stdout.write(f"\rCreating your site please wait... {ax[az % len(ax)]}")
            _c.stdout.flush()
            _f.sleep(0.1)
            az += 1
        _c.stdout.write("\r" + " " * 45 + "\r")
        _c.stdout.flush()
    
    def _F(self, aA):
        aB = _d.path.splitext(_d.path.basename(aA))[0]
        return ''.join(aC for aC in aB if aC.isalnum() or aC in ['-', '_']).lower()
    
    def _G(self):
        print("Please enter your credentials:")
        am = input("Username: ").strip()
        aD = _e.getpass("Password: ")
        
        if not am or not aD:
            print("Username and password are required")
            return False
        
        ai = self._z()
        
        if am in ai:
            if ai[am] == aD:
                self._s['username'] = am
                self._u()
                print(f"\nLogin successful as \033[1m{am}\033[0m\n")
                return True
            else:
                print("Invalid credentials")
                return False
        else:
            ai[am] = aD
            if self._A(ai):
                self._s['username'] = am
                self._u()
                print(f"\nLogin successful as \033[1m{am}\033[0m\n")
                return True
            else:
                print("Failed to create account")
                return False
    
    def _H(self):
        if 'username' not in self._s:
            return self._G()
        
        am = self._s['username']
        au = self._D(am)
        
        if not au:
            print("No wakesites have been published yet.\n")
            return True
        
        print("My published websites:")
        for aE in au:
            print(f"{aE} - https://webwake.vercel.app/{am}/{aE}")
        
        print("\nFor assistance or troubleshooting, type 'wake help'\n")
        return True
    
    def _I(self, aF):
        if 'username' not in self._s:
            if not self._G():
                return False
        
        am = self._s['username']
        
        if not _d.path.exists(aF):
            print(f"File not found: {aF}")
            return False
        
        if not aF.lower().endswith('.html'):
            print("Only HTML files are supported")
            return False
        
        try:
            with open(aF, 'r') as aG:
                ao = aG.read()
        except:
            print(f"Cannot read file: {aF}")
            return False
        
        aH = self._F(aF)
        
        self._E()
        
        if self._B(am, f"{aH}.html", ao):
            print(f"Site deployed at: https://webwake.vercel.app/{am}/{aH}\n")
            return True
        else:
            print("Deployment failed\n")
            return False
    
    def _J(self, aI):
        if 'username' not in self._s:
            if not self._G():
                return False
        
        try:
            aJ, aK = aI.split('/')
        except:
            print("Invalid format. Use: username/filename")
            return False
        
        if aJ != self._s['username']:
            print("You can only remove your own sites")
            return False
        
        aL = self._F(aK)
        
        aM = input(f"Are you sure you want to delete this site? (y/n): ").strip().lower()
        if aM != 'y':
            print("Operation cancelled\n")
            return False
        
        if self._C(aJ, f"{aL}.html"):
            print(f"{aL} has been successfully removed\n")
            return True
        else:
            print("Removal failed\n")
            return False
    
    def _K(self):
        if 'username' in self._s:
            self._s = {}
            self._u()
            print("You have been logged out from your session\n")
        else:
            print("No active session\n")
    
    def _L(self):
        print("Create a new site: wake -d filename.html")
        print("Remove an existing site: wake -r username/filename")
        print("Logout your account: wake logout\n")
    
    def run(self):
        if len(_c.argv) == 1:
            self._H()
        elif _c.argv[1] == "-d" and len(_c.argv) == 3:
            self._I(_c.argv[2])
        elif _c.argv[1] == "-r" and len(_c.argv) == 3:
            self._J(_c.argv[2])
        elif _c.argv[1] == "logout":
            self._K()
        elif _c.argv[1] == "help":
            self._L()
        else:
            print("Invalid command. Type 'wake help' for usage information\n")

def main():
    cli = Stary()
    cli.run()

if __name__ == "__main__":
    main()