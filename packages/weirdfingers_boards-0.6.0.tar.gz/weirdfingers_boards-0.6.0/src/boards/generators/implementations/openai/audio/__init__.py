"""OpenAI audio generators."""
