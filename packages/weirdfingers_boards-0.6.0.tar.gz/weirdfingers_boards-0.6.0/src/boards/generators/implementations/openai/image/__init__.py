"""OpenAI image generators."""
