# Demo Pages

These pages are meant to serve as demonstrational apps that just show what is possible and what isn't.
Currently, the following apps exist.

- [Base](/demo/demo)
