# Billing API

API های پرداخت و بیلینگ.

## POST /api/billing/payments

ایجاد پرداخت جدید.

## GET /api/billing/payments

لیست پرداخت‌ها.

## مراحل بعدی

- [Authentication API](./authentication.md)
- [User Management API](./user-management.md)

