# User Management API

API های مدیریت کاربران.

## GET /api/users

لیست کاربران (نیاز به Admin).

## GET /api/users/{user_id}

اطلاعات یک کاربر.

## مراحل بعدی

- [Authentication API](./authentication.md)
- [Billing API](./billing.md)

