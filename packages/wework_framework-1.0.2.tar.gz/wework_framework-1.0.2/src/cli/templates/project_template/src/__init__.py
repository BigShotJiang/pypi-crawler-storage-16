"""
{{PROJECT_NAME}} - WeWork Framework Project
"""

