"""
WeWork Utils - Utility functions
"""

