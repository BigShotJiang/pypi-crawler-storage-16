"""
WeWork CLI Templates
"""

