"""
Configuration settings
"""

