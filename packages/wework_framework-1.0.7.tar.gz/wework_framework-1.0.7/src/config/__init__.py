"""
WeWork Configuration - Settings and configuration management
"""

