from .wfuzzserver import main

main()
