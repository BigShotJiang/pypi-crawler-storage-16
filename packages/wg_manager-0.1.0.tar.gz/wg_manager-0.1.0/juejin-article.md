# 告别繁琐配置！我用 Python 写了一个 WireGuard 管理神器

## 前言

作为一名开发者，搭建 VPN 是日常需求——无论是远程访问公司内网、安全连接云服务器，还是给团队搭建安全通道。**WireGuard** 凭借其简洁高效的设计，已经成为 VPN 领域的新宠。

但用过 WireGuard 的朋友都知道，它有个痛点：**配置管理太繁琐**。

每次添加新客户端，你需要：
1. 手动生成密钥对（私钥、公钥、预共享密钥）
2. 手动分配 IP 地址（还得记住哪些 IP 已经用过了）
3. 编辑服务端配置文件，添加 `[Peer]` 段
4. 生成客户端配置文件
5. SSH 登录服务器，上传配置
6. 重启 WireGuard 服务
7. 把配置发给使用者（手机用户还得手动输入一堆字符串）

**一个客户端就要这么多步骤，10 个客户端呢？100 个呢？**

于是，我花了一周时间，用 Python 写了这个工具——**wg-manager**，让 WireGuard 配置管理变得像呼吸一样简单。

---

## 一分钟体验

```bash
# 安装
pip install wg-manager
# 或者用 uv（更快）
uv tool install wg-manager

# 初始化服务端
wg-manager init -e your-server-ip

# 添加客户端（自动生成密钥、分配 IP、显示配置）
wg-manager add -n my-phone

# 直接显示二维码，手机扫一扫就能连
wg-manager export -n my-phone --qr
```

就这么简单，**3 条命令**搞定一个完整的 VPN 配置。

---

## 核心功能一览

### 1. 交互式菜单 —— 新手友好

不想记命令？没关系，直接运行 `wg-manager` 进入交互式菜单：

```
╭─────────────────────────────────────────────╮
│            WireGuard 管理工具               │
├─────────────────────────────────────────────┤
│  当前服务端: vpn.example.com:wg0            │
│  客户端数量: 5 (启用: 4, 禁用: 1)           │
│  SSH 状态: ✓ 已配置                         │
├─────────────────────────────────────────────┤
│  1. 添加客户端                              │
│  2. 列出所有客户端                          │
│  3. 导出客户端配置                          │
│  4. 显示客户端二维码                        │
│  5. 删除客户端                              │
│  ...                                        │
╰─────────────────────────────────────────────╯
```

所有操作一目了然，选个数字就能执行。

### 2. 自动化一切

**自动分配 IP**：添加客户端时自动从 `.2` 开始递增分配，不用担心 IP 冲突。

**自动生成密钥**：私钥、公钥、预共享密钥一键生成，安全可靠。

**自动生成配置**：服务端配置、客户端配置自动生成，格式标准无错误。

### 3. SSH 自动同步 —— 真正的一键部署

这是我最喜欢的功能。配置好 SSH 后，添加/删除客户端会**自动同步到远程服务器**：

```bash
# 一次性配置 SSH
wg-manager ssh --host your-server-ip

# 之后每次添加客户端，自动同步
wg-manager add -n new-laptop
# 输出: ✓ 客户端已添加
#       ✓ 配置已同步到远程服务器
#       ✓ WireGuard 已热重载
```

**热重载**意味着现有的 VPN 连接**不会中断**。你可以在生产环境放心添加新用户，不影响其他人。

### 4. 二维码快连 —— 手机用户的福音

```bash
wg-manager export -n my-phone --qr
```

终端直接显示二维码，手机打开 WireGuard App 扫一扫，**3 秒连上 VPN**。

再也不用手动输入那一串公钥私钥了！

### 5. 多服务端 / 多网段管理

企业级场景下，你可能需要：
- 一台服务器跑多个 WireGuard 接口（不同部门用不同网段）
- 管理多台 VPN 服务器

wg-manager 完美支持：

```bash
# 同一服务器，不同网段
wg-manager init -e vpn.company.com -a 10.0.0.1/24 -p 51820 -i wg0  # 研发部
wg-manager init -e vpn.company.com -a 10.1.0.1/24 -p 51821 -i wg1  # 运维部
wg-manager init -e vpn.company.com -a 10.2.0.1/24 -p 51822 -i wg2  # 测试部

# 切换到指定网段
wg-manager use vpn.company.com -i wg1
```

每个网段独立管理，互不影响。

---

## 实战：5 分钟搭建企业级 VPN

### 场景

你有一台云服务器（IP: `1.2.3.4`），想给团队 5 个人搭建 VPN，实现远程访问内网资源。

### Step 1: 服务器安装 WireGuard

```bash
# Ubuntu/Debian
sudo apt update && sudo apt install wireguard

# CentOS/RHEL
sudo yum install wireguard-tools
```

### Step 2: 本地安装 wg-manager

```bash
pip install wg-manager
```

### Step 3: 初始化并配置 SSH

```bash
# 初始化服务端配置
wg-manager init -e 1.2.3.4

# 配置 SSH 自动同步
wg-manager ssh --host 1.2.3.4
```

### Step 4: 批量添加客户端

```bash
wg-manager add -n alice-macbook
wg-manager add -n bob-windows
wg-manager add -n charlie-phone
wg-manager add -n david-laptop
wg-manager add -n eve-ipad
```

每个命令执行后，配置**自动同步到服务器**，用户立即可以连接。

### Step 5: 分发配置

```bash
# 导出配置文件
wg-manager export -n alice-macbook    # 生成 alice-macbook.conf

# 或者直接显示二维码给手机用户
wg-manager export -n charlie-phone --qr
```

**搞定！** 整个过程不超过 5 分钟。

---

## 技术实现亮点

### 1. 零依赖 SSH

很多 Python 项目用 `paramiko` 实现 SSH，但它依赖繁重。wg-manager 直接调用系统的 `ssh`/`scp` 命令，**安装更简单，兼容性更好**。

### 2. SQLite 持久化

所有配置存储在 `~/.wg_manager/wg_manager.db`，一个文件搞定备份恢复：

```bash
# 备份
cp ~/.wg_manager/wg_manager.db ~/backup/

# 恢复
cp ~/backup/wg_manager.db ~/.wg_manager/
```

### 3. 热重载不中断

使用 `wg syncconf` 而非 `wg-quick down && wg-quick up`，添加/删除客户端时**现有连接继续工作**。

### 4. 纯 Python 二维码

使用 `qrcode` 库在终端渲染 ASCII 二维码，不依赖系统的 `qrencode` 命令，跨平台兼容。

---

## 与其他方案对比

| 特性 | wg-manager | 手动配置 | wg-easy (Web) |
|------|------------|----------|---------------|
| 安装复杂度 | pip install | 无需安装 | Docker 部署 |
| 学习成本 | 低 | 高 | 中 |
| 自动化支持 | ✓ CLI | ✗ | ✗ |
| 多服务端管理 | ✓ | 手动 | ✗ |
| SSH 自动同步 | ✓ | ✗ | ✗ |
| 离线使用 | ✓ | ✓ | ✗ |
| 二维码生成 | ✓ | 需工具 | ✓ |
| 适合场景 | 开发者/运维 | 单机少量 | 小白用户 |

---

## 适用场景

- **个人用户**：给自己的手机、电脑配置 VPN，安全访问家庭 NAS
- **小团队**：给 5-50 人的团队快速搭建 VPN，管理方便
- **运维场景**：脚本化批量管理，集成到 CI/CD 流程
- **多网段隔离**：不同部门/项目使用不同网段，权限隔离

---

## 开源地址

**GitHub**: [https://github.com/your-username/wg-manager](https://github.com/your-username/wg-manager)

欢迎 Star ⭐ 和 PR！

如果你觉得这个工具有用，请帮忙点个 Star，这是对开源作者最大的鼓励 🙏

---

## 常见问题

### Q: 需要在服务器上安装 wg-manager 吗？

**不需要**。wg-manager 只需在你的本地电脑运行，通过 SSH 管理远程服务器。

### Q: 支持 Windows 吗？

支持！Python 3.10+ 跨平台运行。但 SSH 自动同步功能需要安装 OpenSSH 客户端。

### Q: 数据安全吗？

所有数据存储在本地 `~/.wg_manager/` 目录，私钥不会上传到任何第三方服务。

### Q: pip 安装后找不到命令？

检查 `~/.local/bin` 是否在 PATH 中：

```bash
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

---

## 写在最后

WireGuard 本身是一个优秀的协议，但配置管理确实是个痛点。wg-manager 的目标就是**让 WireGuard 配置管理变得简单**，让你把时间花在更有价值的事情上。

如果你正在使用 WireGuard，或者打算搭建 VPN，不妨试试 wg-manager。

有任何问题或建议，欢迎在评论区留言，或者到 GitHub 提 Issue！

---

> 🔗 **相关链接**
> - WireGuard 官网: https://www.wireguard.com/
> - wg-manager GitHub: https://github.com/your-username/wg-manager
> - WireGuard 协议白皮书: https://www.wireguard.com/papers/wireguard.pdf
