from .whatsapp import WhatsappClient
from .whatsapp_instanced import send_media, send_message