from setuptools import setup, find_packages
from pathlib import Path

# Read files safely
this_dir = Path(__file__).parent
long_description = (this_dir / "README.md").read_text(encoding="utf-8")
requirements = (this_dir / "requirements.txt").read_text().splitlines()

setup(
    name="Wi-Fi-Attack",               # PyPI package name
    version="3.1.1",

    # --- FIXED AUTHOR FIELDS ---
    author="cyb2rS2c",
    author_email="",
    url="https://github.com/cyb2rS2c/Wi-Fi_ATTACK",

    description="Wi-Fi attack toolkit for penetration testing (educational use only)",

    # Python package structure
    packages=find_packages(where="src"),
    package_dir={"": "src"},

    install_requires=requirements,
    include_package_data=True,

    entry_points={
        "console_scripts": [
            "wifi-cracker=wi_fi_attack.wifi_cracker:main"
        ]
    },

    long_description=long_description,
    long_description_content_type="text/markdown",

    license="MIT",

    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Environment :: Console",
    ],

    python_requires=">=3.6",
)
