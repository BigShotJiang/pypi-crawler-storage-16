from .main import wikipedia_tablo_cek, tablo_kaydet, tum_tablolari_goster

__version__ = "1.0.1"
__all__ = ["wikipedia_tablo_cek", "tablo_kaydet", "tum_tablolari_goster"]