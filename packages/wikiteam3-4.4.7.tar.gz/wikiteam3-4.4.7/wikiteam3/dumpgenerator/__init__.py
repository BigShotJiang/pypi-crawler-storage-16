from wikiteam3.dumpgenerator.dump import DumpGenerator

def main():
    DumpGenerator()
