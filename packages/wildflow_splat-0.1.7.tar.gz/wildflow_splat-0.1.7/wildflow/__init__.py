"""
wildflow - modeling natural ecosystems
"""

__version__ = "0.1.4"

__path__ = __import__('pkgutil').extend_path(__path__, __name__)
