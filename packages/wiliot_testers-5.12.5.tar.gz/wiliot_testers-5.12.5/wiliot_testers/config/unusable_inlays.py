from enum import Enum


class UnusableInlayTypes(Enum):
    TEO_086 = 'non-prod'
    TIKI_096 = 'non-prod'
    BATTERY_107 = 'non-prod'
    TIKI_118 = 'non-prod'
