# This file was auto generated; Do not modify, if you value your sanity!
import ctypes
import enum



class get_component_versions(ctypes.Structure):
    _pack_ = 2
    _fields_ = [
        ('reserved', ctypes.c_uint32 * 2),
    ]


_GetComponentVersions = get_component_versions
GetComponentVersions = get_component_versions

