from .version import __version__

__author__ = "Kurtis Fafard"
