# This file was auto generated; Do not modify, if you value your sanity!
import ctypes
import enum



class ew_bms_instance_t(enum.IntEnum):
    """A ctypes-compatible IntEnum superclass."""
    @classmethod
    def from_param(cls, obj):
        return int(obj)

    ewBMSInstance0  = 0
    ewBMSInstance1 = enum.auto()


_EwBMSInstance_t = ew_bms_instance_t
EwBMSInstance_t = ew_bms_instance_t

