# This file was auto generated; Do not modify, if you value your sanity!
import ctypes
import enum



class s_pluto_avb_params_s(ctypes.Structure):
    _pack_ = 2
    _fields_ = [
        ('destmeta', ctypes.c_uint64),
        ('srcmeta', ctypes.c_uint64),
    ]


SPluto_AVBParams_s = s_pluto_avb_params_s
SPluto_AVBParams = s_pluto_avb_params_s

