# This file was auto generated; Do not modify, if you value your sanity!
import ctypes
import enum



class stop_dhcp_server_command(ctypes.Structure):
    _pack_ = 2
    _fields_ = [
        ('networkId', ctypes.c_uint16),
    ]


_StopDHCPServerCommand = stop_dhcp_server_command
StopDHCPServerCommand = stop_dhcp_server_command

