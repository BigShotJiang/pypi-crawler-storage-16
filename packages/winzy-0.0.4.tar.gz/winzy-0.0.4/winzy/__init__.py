from .hookspecs import hookimpl
from .hookspecs import hookspec
