render = 'JSON'
source = 'national'

# GD/T/1982/29 GD/A/1981/19 GD/B/1973/21 GD/C/1972/38 
appnum_mask = ['GD/T/(\\d{4})/(\\d*)', 'GD/T/(\\d*)/(\\d*)', 'GD/A/(\\d{4})/(\\d*)', 'GD/B/(\\d{4})/(\\d*)', 'GD/C/(\\d{4})/(\\d*)']

