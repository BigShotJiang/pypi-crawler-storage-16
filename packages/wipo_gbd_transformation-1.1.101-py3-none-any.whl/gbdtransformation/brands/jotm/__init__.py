render = 'JSON'
source = 'national'

# J2/T/1/41852
# JO/T/1/101834
appnum_mask = [ 'JO/T/1/(\\d*)',
                'J(2)/T/1/(\\d*)',
                'J(3)/T/1/(\\d*)' ]
