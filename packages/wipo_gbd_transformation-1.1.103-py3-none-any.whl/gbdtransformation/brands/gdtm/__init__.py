render = 'JSON'
source = 'national'

# GD/T/1982/29 GD/A/1981/19 GD/B/1973/21 GD/C/1972/38 
appnum_mask = ['GD/[TABC]/(\\d{4})/(\\d*)', 'GD/[TABC]/(\\d*)/(\\d*)']
