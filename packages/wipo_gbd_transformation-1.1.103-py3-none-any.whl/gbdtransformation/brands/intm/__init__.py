# instruction to render the output to JSON format
render = 'JSON'
source = 'national' # national | multinational | international

appnum_mask = '(.*)'
regnum_mask = '(.*)'
