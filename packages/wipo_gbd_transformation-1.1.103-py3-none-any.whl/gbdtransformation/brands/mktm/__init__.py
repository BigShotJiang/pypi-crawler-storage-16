# instruction to render the output to JSON format
render = 'JSON'
source = 'national'

# 201500024
appnum_mask = '\\d{4}(\\d*)'
