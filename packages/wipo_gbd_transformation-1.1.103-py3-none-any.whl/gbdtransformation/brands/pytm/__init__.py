# instruction to render the output to JSON format
render = 'JSON'
source = 'national'

appnum_mask = [ "PY/M/(\\d{4})/(\\d*)", "PY/M/\\d{4}/(\\d*)" ]
regnum_mask = [ "(\\d{4})/(\\d*)", "\\d{4}/(\\d*)"]
