render = 'JSON'
source = 'national'

# 2006/1843
appnum_mask = '\\d{4}/(\\d*)'
