render = 'JSON'
source = 'national'

# PH/3/2011/000001 A/3/1994/009794
appnum_mask = ['PH/\\d*/(\\d*)/(\\d*)', 'A/\\d*/\\d*/(\\d*)']
