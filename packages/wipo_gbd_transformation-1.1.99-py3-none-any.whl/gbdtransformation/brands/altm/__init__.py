render = 'JSON'
source = 'national'

# AL/T/2004/000072
# AL/E/2004/000072
appnum_mask = 'AL/(T|E|D)/\\d*/(\\d*)'
