render = 'JSON'
source = 'national'

# MG/M/2017/798
# MG/D/1/1471845
appnum_mask = [ 'MG/(M|C)/\\d{4}/(\\d*)',
                'MG/(D)/1/(\\d*)' ]
