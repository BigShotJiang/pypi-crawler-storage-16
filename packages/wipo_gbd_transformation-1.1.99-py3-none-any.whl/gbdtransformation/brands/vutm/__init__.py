render = 'JSON'
source = 'national'

# 1977/424
appnum_mask = '\\d{4}/(\\d*)'
