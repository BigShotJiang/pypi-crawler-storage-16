render = 'JSON'
source = 'national'

#KH/D/2019/00125
appnum_mask = 'KH/D/\\d*/(\\d*)'
