###########
WireViz-Web
###########

.. image:: https://github.com/wireviz/wireviz-web/workflows/Tests/badge.svg
    :target: https://github.com/wireviz/wireviz-web/actions?workflow=Tests
.. image:: https://codecov.io/gh/wireviz/wireviz-web/branch/main/graph/badge.svg
    :target: https://codecov.io/gh/wireviz/wireviz-web

.. image:: https://img.shields.io/pypi/v/wireviz-web.svg
    :target: https://pypi.org/project/wireviz-web/
.. image:: https://pepy.tech/badge/wireviz-web/month
    :target: https://pepy.tech/project/wireviz-web

.. image:: https://img.shields.io/pypi/pyversions/wireviz-web.svg
    :target: https://pypi.org/project/wireviz-web/
.. image:: https://img.shields.io/pypi/status/wireviz-web.svg
    :target: https://pypi.org/project/wireviz-web/
.. image:: https://img.shields.io/github/license/wireviz/wireviz-web
    :target: https://github.com/wireviz/wireviz-web/blob/main/LICENSE


*****
About
*****

WireViz-Web is a wrapper around the excellent WireViz_ by `Daniel Rojas`_
for bringing it to the web.

Originally, it has been conceived within a `WireViz fork`_ by `Jürgen Key`_.
For compatibility with PlantUML_, it includes a `PlantUML Text Encoding format`_
decoder by `Dyno Fu`_ and `Rudi Yardley`_.

Thanks!


*******
Details
*******

WireViz
=======

WireViz is a tool for easily documenting cables, wiring harnesses and connector pinouts.
It takes plain text, YAML-formatted files as input and produces beautiful graphical output
(SVG, PNG, ...) thanks to Graphviz_.
It handles automatic BOM (Bill of Materials) creation and has a lot of extra features.

WireViz-Web
===========

WireViz-Web wraps WireViz with a REST API using Flask. It also provides specific rendering
endpoints for PlantUML.


*****
Setup
*****

Install prerequisites::

    {apt,brew,dnf,yum,zypper} install python3 graphviz

Install package::

    pip install wireviz-web

*********
Container
*********

Use Docker or Podman::

    docker run --rm --publish 3005:3005 ghcr.io/wireviz/wireviz-web:latest --listen 0.0.0.0:3005

Use Docker Compose or Podman Compose:

.. code:: yaml

    services:
      wireviz-web:
        image: ghcr.io/wireviz/wireviz-web:latest
        environment:
          WIREVIZ_LISTEN: 0.0.0.0:3005
        ports:
          - "3005:3005"
        healthcheck:
          test: [ "CMD", "curl", "--fail", "http://localhost:3005/status" ]
          start_period: 2s
          interval: 10s

*****
Usage
*****

Run server::

    wireviz-web

Run server, listening on all interfaces::

    wireviz-web --listen=0.0.0.0:3005

Invoke requests::

    # Acquire WireViz YAML file.
    wget https://raw.githubusercontent.com/wireviz/wireviz-web/main/tests/demo01.yaml

    # Render HTML page with SVG image and BOM table.
    http --form http://localhost:3005/render yml_file@demo01.yaml Accept:text/html

    # Render images.
    http --form http://localhost:3005/render yml_file@demo01.yaml Accept:image/svg+xml
    http --form http://localhost:3005/render yml_file@demo01.yaml Accept:image/png

    # Render BOM in TSV format.
    http --form http://localhost:3005/render yml_file@demo01.yaml Accept:text/plain

    # Render BOM in JSON format.
    http --form http://localhost:3005/render yml_file@demo01.yaml Accept:application/json

    # Render a PlantUML request.
    http http://localhost:3005/plantuml/svg/SyfFKj2rKt3CoKnELR1Io4ZDoSa700==
    http http://localhost:3005/plantuml/png/SyfFKj2rKt3CoKnELR1Io4ZDoSa700==

.. note::

    The ``http`` command used in the examples is the excellent HTTPie_ program.

For visiting the Swagger OpenAPI spec, go to http://localhost:3005/doc.



*******************
Project information
*******************

Contributions
=============

Every kind of contribution, feedback, or patch, is much welcome. `Create an
issue`_ or submit a patch if you think we should include a new feature, or to
report or fix a bug.

In order to follow the general development discussion, please see `Bringing
WireViz to the Web`_.

Development
===========

In order to setup a development environment on your workstation, please head
over to the `development sandbox`_ documentation. When you see the software
tests succeed, you should be ready to start hacking.

Resources
=========

- `Source code repository <https://github.com/wireviz/wireviz-web>`_
- `Documentation <https://github.com/wireviz/wireviz-web/blob/main/README.rst>`_
- `Python Package Index (PyPI) <https://pypi.org/project/wireviz-web/>`_

License
=======

The project is licensed under the terms of the GNU AGPL license.


.. _Bringing WireViz to the Web: https://community.hiveeyes.org/t/bringing-wireviz-to-the-web/3700
.. _create an issue: https://github.com/wireviz/wireviz-web/issues
.. _Daniel Rojas: https://github.com/formatc1702
.. _development sandbox: https://github.com/wireviz/wireviz-web/blob/main/doc/sandbox.rst
.. _Dyno Fu: https://github.com/dyno
.. _Graphviz: https://www.graphviz.org/
.. _HTTPie: https://httpie.io/
.. _Jürgen Key: https://github.com/elbosso
.. _PlantUML: https://plantuml.com/
.. _PlantUML Text Encoding format: https://plantuml.com/text-encoding
.. _Rudi Yardley: https://github.com/ryardley
.. _WireViz: https://github.com/formatc1702/WireViz
.. _WireViz fork: https://github.com/elbosso/WireViz
