# Changelog

## 0.1.0 (2025-12-11)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/witanlabs/witan-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([71a4e5e](https://github.com/witanlabs/witan-python/commit/71a4e5efdd5c0aaa01452cc4e1bb97fd006f6791))
* **api:** manual updates ([f2bbfc1](https://github.com/witanlabs/witan-python/commit/f2bbfc133b23425b43e2e7391627fc60baf45a51))
* **api:** manual updates ([d8d5e3b](https://github.com/witanlabs/witan-python/commit/d8d5e3b689c173151606e191efa339d35e3e3fab))
* **api:** manual updates ([7f44c7e](https://github.com/witanlabs/witan-python/commit/7f44c7e308854d4cbe4d56725695ef2839637213))
* **api:** manual updates ([c2514b6](https://github.com/witanlabs/witan-python/commit/c2514b64880441830e9149c46c2aa2a98bde1fb8))
* **api:** manual updates ([4533c1c](https://github.com/witanlabs/witan-python/commit/4533c1c26efdd6f469e0f5927da4b99cc9027ed5))
* **api:** manual updates ([050bd0c](https://github.com/witanlabs/witan-python/commit/050bd0c8c8eb59ea7a08710c18c59be8170830c0))
* **api:** manual updates ([699dade](https://github.com/witanlabs/witan-python/commit/699dade47e855cf1282b342438edcb2220b115b0))
* **api:** manual updates ([4d8652c](https://github.com/witanlabs/witan-python/commit/4d8652cbf916c8d29e37e2d45b53c242e295c155))


### Chores

* update SDK settings ([5356e42](https://github.com/witanlabs/witan-python/commit/5356e4236efde5550472edca65e231cf54dc61e1))
