Wizard vs IRS is a game where as a wizard, **you have to escape taxes by defending yourself** from IRS agents.

[![Demo Video](https://img.youtube.com/vi/LS8gdDG8taE/hqdefault.jpg)](https://youtu.be/LS8gdDG8taE)

You can install from PyPI as `pip3 install wizard-vs-irs` and run as `python3 -m wizard-vs-irs` or for UV, `uv tool run wizard-vs-irs`

For each IRS agent you defend, you evade some taxes, and after defending enough, you climb to a new level of tax evasion.

Currently, you have Fireball, Ball of Lightning and Ice Blast as spells/weapons you can use.
During fights, you get mana, which you can spend on abilities:
- Dash: Quickly dash away to escape
- Tax Shield: Permanent 1000$ shield until it breaks
- Audit Bomb: Blow up nearby IRS agents
- Freeze Audit: Freeze each IRS agent for 4 seconds

In the Shop, you can upgrade the DMG and Attack Speed of each spell, improve the accuracy of the wizard, upgrade the player and bullet speed and get the best upgrade: **The Dark Mode Wizard**.

**WARNING: This project is a joke, i don't approve of any illegal activities done whatsoever.**