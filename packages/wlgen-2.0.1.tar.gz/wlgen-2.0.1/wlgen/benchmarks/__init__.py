"""Benchmark suite for wordlist generation implementations"""
