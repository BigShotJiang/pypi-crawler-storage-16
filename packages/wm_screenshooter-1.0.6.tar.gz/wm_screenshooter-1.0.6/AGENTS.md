# Agent Guidelines for ScreenShooter

## Build/Lint/Test Commands
- Format code: `ruff format src/`
- Lint code: `ruff check src/`
- Install dependencies: `uv pip install -e ".[dev]"` or `uv pip install -e .`
- Run single test: `pytest tests/path/to/test.py::test_function` (when tests exist)

## Code Style Guidelines
- Python 3.9+ required, use `uv` for package management
- Double quotes for strings, 100 char line length, 4-space indentation
- Type hints required for all function parameters and return values
- Import order: stdlib → third-party → local imports
- Classes: PascalCase, Functions: snake_case, Constants: UPPERCASE_WITH_UNDERSCORES
- Google style docstrings for all modules, classes, and functions
- Specific exceptions in try/except blocks, use logging module for errors
- Follow PEP 8, run ruff format/check before commits

## Project Structure
Main entry: `src/screenshooter/main.py`
Modules in `src/screenshooter/modules/`: clients, database, reports, s3, screenshot, settings
Each module has `__init__.py` and may include `main.py` or `cli.py` for CLI entry points
Dependencies defined in `pyproject.toml`, dev tools in `[dependency-groups]`

## Cursor Rules
Follow all guidelines in `.cursor/rules/` directory:
- code-style.mdc: Python/dependency management, formatting, naming, documentation, error handling
- database-module.mdc: SQLite database integration, schema design, operations layer usage
- database-migrations.mdc: Versioned SQL migration system, migration file conventions, rollback procedures
- dependency-management.mdc: Package management and dependency handling
- directory-structure.mdc: Project organization and file placement
- project-structure.mdc: Overall architecture and module organization
- Module-specific rules: backup-module.mdc, clients-module.mdc, reports-module.mdc, reports.mdc, s3-module.mdc, screenshot-module.mdc, settings-module.mdc

## Database Guidelines
- Use SQLite database for structured data (clients, projects, sessions, screenshots, notes)
- Always use `DatabaseOperations` for CRUD operations, never raw SQL directly
- Maintain dual logging: file-based logs remain authoritative, DB writes are supplementary
- Use `DatabaseNoteType` enum for note categorization (NOTE, CAPTION, SESSION_START, SESSION_END)
- Schema changes via versioned migrations in `versions/` directory, not direct DB modifications
- Test migrations against database copies before applying to production data