# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build/Lint/Test Commands

```bash
# Install dependencies
uv pip install -e .           # Production install
uv pip install -e ".[dev]"    # With dev dependencies

# Install as CLI tool
uv tool install .
screenshooter --version

# Format and lint
ruff format src/
ruff check src/

# Run tests
pytest tests/                                    # All tests
pytest tests/path/to/test.py::test_function     # Single test
```

## Code Style

- Python 3.9+, use `uv` for package management
- Double quotes, 100 char line length, 4-space indentation
- Type hints required for all function parameters and return values
- Import order: stdlib → third-party → local
- Naming: Classes=PascalCase, functions=snake_case, constants=UPPERCASE_WITH_UNDERSCORES
- Google style docstrings
- Use specific exceptions in try/except, use logging module for errors
- Rich console formatting for UI; input prompts on new line prefixed with `>`

## Architecture

**Entry Point:** `src/screenshooter/main.py`

**Modules** (`src/screenshooter/modules/`):
- `clients/` - Client management, data models, CLI
- `screenshot/` - Screenshot capture, session management, timer
- `reports/` - PDF report generation and email delivery
- `database/` - SQLite storage, migrations, operations layer
- `s3/` - S3/R2 cloud storage integration
- `settings/` - Application settings models and manager

Each module has `__init__.py` and may include `main.py` or `cli.py` for CLI entry points.

## Database Guidelines

SQLite database at `~/.config/screenshooter/screenshooter.db` stores clients, projects, sessions, screenshots, and notes.

- **Always use `DatabaseOperations`** for CRUD - never raw SQL directly
- **Dual logging**: File-based logs remain authoritative; DB writes are supplementary
- **Note types**: Use `DatabaseNoteType` enum (NOTE, CAPTION, SESSION_START, SESSION_END) - no separate caption table
- **Schema changes**: Use versioned migrations in `versions/` directory, not direct DB modifications
- Migration files: `XXX_descriptive_name.sql` with transaction wrapping and rollback sections

## User Data Structure

Screenshots and client data stored at `~/WorkMaster_Screenshooter/`:
```
~/WorkMaster_Screenshooter/
└── CLIENT_NAME/
    ├── client_info.json
    └── PROJECT_NAME/
        ├── PROJECT_NAME_log.txt
        ├── reports/
        └── sessions/YYYY-MM-DD_HH-MM-SS/
            ├── session.log
            └── screenshots/
```

## Cursor Rules Reference

Additional module-specific guidelines exist in `.cursor/rules/`:
- `database-module.mdc` - SQLite integration, schema, operations layer
- `database-migrations.mdc` - Versioned migration system
- `clients-module.mdc`, `reports-module.mdc`, `s3-module.mdc`, `screenshot-module.mdc`, `settings-module.mdc`
