# ScreenShooter Project Roadmap

Below is a list of features and improvements that are planned for the ScreenShooter application. Please refer to the issues on the project's GitLab for details on current planned features and implementation progress.

## Current Features In Active Development

- Adding tests for the application.

## Planned Features in Future Releases

- Update minimum version of Python to 3.12.
- Tutorial Documentation mode for creating step-by-step guides for clients.
- Implement something like Textual to provide a more immersive/polished experience for the user.

## Known Issues

Any known issues with the application will be listed here. If not critical the issue will have an associated release version number where it will be fixed.
