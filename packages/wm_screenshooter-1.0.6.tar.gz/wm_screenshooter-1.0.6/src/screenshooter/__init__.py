"""ScreenShooter - A sophisticated screenshot cross-platform screenshot tool."""

import importlib.metadata

try:
    __version__ = importlib.metadata.version("screenshooter")
except importlib.metadata.PackageNotFoundError:
    # Fallback for development environments where package isn't installed
    __version__ = "dev"

# Available modules
# - main: Main entry point with interactive menu
# - modules.client: Client management functionality
# - modules.screenshot: Screenshot capture functionality
# - modules.report: PDF report generation and email
