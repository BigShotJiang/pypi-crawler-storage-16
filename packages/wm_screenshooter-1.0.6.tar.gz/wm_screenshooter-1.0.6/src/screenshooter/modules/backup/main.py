#!/usr/bin/env python3
"""Backup functionality for ScreenShooter Mac.

This module provides helpers and a CLI entry point for creating backups of:

- settings.json
- the SQLite database (screenshooter.db)
- the full screenshots directory (including the database), plus settings.json

Backups are created as ZIP archives and can be optionally password protected.
"""

import logging
import os
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional

import click
import pyzipper
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from screenshooter.modules.database import get_default_database_path
from screenshooter.modules.settings.models import AppSettings, BackupSettings, SettingsManager
from screenshooter.modules.settings.settings_helper import get_screenshots_dir

logger = logging.getLogger(__name__)
console = Console()

BACKUP_TYPES = ("settings", "db", "all")


class BackupError(Exception):
    """Custom exception for backup-related errors."""


def _get_settings_and_file() -> tuple[AppSettings, Path]:
    """Load application settings and return them with their file path."""
    manager = SettingsManager()
    settings = manager.load_settings()
    return settings, manager.settings_file


def _resolve_output_directory(backup_settings: BackupSettings, output_dir: Optional[str]) -> Path:
    """Resolve the output directory for backups.

    Preference order:
    1. CLI-provided output directory
    2. Configured backup_directory in settings
    3. Default to <screenshots_dir>/backups
    """
    if output_dir:
        target_dir = Path(output_dir).expanduser()
    elif backup_settings.backup_directory:
        target_dir = Path(backup_settings.backup_directory).expanduser()
    else:
        target_dir = Path(get_screenshots_dir()) / "backups"

    target_dir.mkdir(parents=True, exist_ok=True)
    return target_dir


def _add_file_to_zip(zip_file: zipfile.ZipFile, source: Path, arcname: str, verbosity: str) -> None:
    """Add a single file to the given ZIP archive."""
    if not source.exists():
        raise BackupError(f"Source file not found: {source}")
    if verbosity == "full":
        # Lightweight progress indicator so user can see per-file activity
        console.print(f"[dim]Adding to backup:[/dim] {arcname}")
    zip_file.write(source, arcname=arcname)


def _add_directory_to_zip(
    zip_file: zipfile.ZipFile,
    root_dir: Path,
    exclude_dir: Optional[Path],
    verbosity: str,
) -> None:
    """Recursively add a directory to the ZIP archive.

    Args:
        zip_file: Open pyzipper AESZipFile instance.
        root_dir: Root directory to add.
        exclude_dir: Optional directory to exclude (e.g., the backup directory itself).
    """
    root_dir = root_dir.resolve()
    exclude_dir = exclude_dir.resolve() if exclude_dir else None

    seen_summaries: set[str] = set()

    for dirpath, _, filenames in os.walk(root_dir):
        current_dir = Path(dirpath).resolve()
        if exclude_dir and str(current_dir).startswith(str(exclude_dir)):
            continue

        for filename in filenames:
            file_path = current_dir / filename
            if exclude_dir and str(file_path).startswith(str(exclude_dir)):
                continue

            # Store paths relative to the screenshots root directory
            arcname_path = file_path.relative_to(root_dir)
            arcname = str(arcname_path)

            if verbosity == "summary":
                # Show a single line per client/project pair (or top-level path if shallower)
                parts = arcname_path.parts
                if len(parts) >= 2:
                    summary_key = f"{parts[0]}/{parts[1]}"
                elif parts:
                    summary_key = parts[0]
                else:
                    summary_key = arcname

                if summary_key not in seen_summaries:
                    console.print(f"[dim]Adding to backup (client/project):[/dim] {summary_key}")
                    seen_summaries.add(summary_key)

                _add_file_to_zip(zip_file, file_path, arcname=arcname, verbosity="off")
            else:
                _add_file_to_zip(zip_file, file_path, arcname=arcname, verbosity=verbosity)


def perform_backup(
    backup_type: str,
    output_dir: Optional[str] = None,
    verbosity: Optional[str] = None,
    settings: Optional[AppSettings] = None,
) -> Path:
    """Perform a backup of the requested type.

    Args:
        backup_type: One of "settings", "db", or "all".
        output_dir: Optional directory in which to write the backup ZIP.

    Returns:
        Path to the created ZIP file.

    Raises:
        BackupError: If backup_type is invalid or a required source file is missing.
    """
    backup_type = backup_type.lower()
    if backup_type not in BACKUP_TYPES:
        raise BackupError(f"Invalid backup type '{backup_type}'. Must be one of {BACKUP_TYPES}.")

    if settings is None:
        settings, settings_file = _get_settings_and_file()
    else:
        # If settings provided, get the settings file path for including in backups
        manager = SettingsManager()
        settings_file = manager.settings_file

    backup_settings = getattr(settings, "backup", BackupSettings())

    # Determine effective verbosity, falling back to settings and then default "full"
    effective_verbosity = (
        verbosity or getattr(backup_settings, "verbosity", "full") or "full"
    ).lower()
    if effective_verbosity not in ("off", "summary", "full"):
        effective_verbosity = "full"

    screenshots_dir = Path(get_screenshots_dir()).resolve()
    db_path = get_default_database_path().expanduser().resolve()

    output_base_dir = _resolve_output_directory(backup_settings, output_dir)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_path = output_base_dir / f"screenshooter_backup_{backup_type}_{timestamp}.zip"

    password: Optional[bytes] = None
    if backup_settings.password_enabled and backup_settings.password:
        password = backup_settings.password.encode("utf-8")

    try:
        console.print("[bold]Creating backup...[/bold]")
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task("Creating backup...", total=None)

            if password:
                # Encrypted ZIP using pyzipper
                with pyzipper.AESZipFile(
                    zip_path,
                    "w",
                    compression=pyzipper.ZIP_DEFLATED,
                    encryption=pyzipper.WZ_AES,
                ) as zip_file:
                    zip_file.setpassword(password)

                    if backup_type == "settings":
                        _add_file_to_zip(
                            zip_file,
                            settings_file,
                            arcname="settings.json",
                            verbosity=effective_verbosity,
                        )
                    elif backup_type == "db":
                        if not db_path.exists():
                            raise BackupError(
                                f"Database file not found at {db_path}. Have you initialized the database yet?"
                            )
                        _add_file_to_zip(
                            zip_file,
                            db_path,
                            arcname="screenshooter.db",
                            verbosity=effective_verbosity,
                        )
                    elif backup_type == "all":
                        # Full screenshots directory (includes DB if present)
                        try:
                            # If output directory is inside screenshots_dir, exclude it
                            output_base_dir.relative_to(screenshots_dir)
                            backup_dir_inside_root: Optional[Path] = output_base_dir
                        except ValueError:
                            backup_dir_inside_root = None

                        _add_directory_to_zip(
                            zip_file,
                            screenshots_dir,
                            exclude_dir=backup_dir_inside_root,
                            verbosity=effective_verbosity,
                        )

                        # Include the database even though it's outside the screenshots directory
                        if db_path.exists():
                            _add_file_to_zip(
                                zip_file,
                                db_path,
                                arcname="screenshooter.db",
                                verbosity=effective_verbosity,
                            )

                        # Also include settings.json
                        if settings_file.exists():
                            _add_file_to_zip(
                                zip_file,
                                settings_file,
                                arcname="settings.json",
                                verbosity=effective_verbosity,
                            )
            else:
                # Unencrypted ZIP using standard library
                with zipfile.ZipFile(
                    zip_path,
                    "w",
                    compression=zipfile.ZIP_DEFLATED,
                ) as zip_file:
                    if backup_type == "settings":
                        _add_file_to_zip(
                            zip_file,
                            settings_file,
                            arcname="settings.json",
                            verbosity=effective_verbosity,
                        )
                    elif backup_type == "db":
                        if not db_path.exists():
                            raise BackupError(
                                f"Database file not found at {db_path}. Have you initialized the database yet?"
                            )
                        _add_file_to_zip(
                            zip_file,
                            db_path,
                            arcname="screenshooter.db",
                            verbosity=effective_verbosity,
                        )
                    elif backup_type == "all":
                        # Full screenshots directory (includes DB if present)
                        try:
                            # If output directory is inside screenshots_dir, exclude it
                            output_base_dir.relative_to(screenshots_dir)
                            backup_dir_inside_root = output_base_dir
                        except ValueError:
                            backup_dir_inside_root = None

                        _add_directory_to_zip(
                            zip_file,
                            screenshots_dir,
                            exclude_dir=backup_dir_inside_root,
                            verbosity=effective_verbosity,
                        )

                        # Include the database even though it's outside the screenshots directory
                        if db_path.exists():
                            _add_file_to_zip(
                                zip_file,
                                db_path,
                                arcname="screenshooter.db",
                                verbosity=effective_verbosity,
                            )

                        # Also include settings.json
                        if settings_file.exists():
                            _add_file_to_zip(
                                zip_file,
                                settings_file,
                                arcname="settings.json",
                                verbosity=effective_verbosity,
                            )

    except OSError as exc:
        logger.error("Backup failed due to file system error: %s", exc)
        raise BackupError(f"Backup failed due to file system error: {exc}") from exc

    return zip_path


@click.command()
@click.argument("backup_type", type=click.Choice(BACKUP_TYPES))
@click.option(
    "--outputdir",
    "output_dir",
    type=click.Path(file_okay=False, dir_okay=True, path_type=str),
    help="Directory to write the backup ZIP file to.",
)
@click.option(
    "--verbosity",
    type=click.Choice(["off", "summary", "full"]),
    help="Backup output verbosity (default from settings).",
)
def main(backup_type: str, output_dir: Optional[str], verbosity: Optional[str]) -> None:
    """CLI entry point for the backup module.

    Typically invoked via the main `screenshooter` CLI, but can be run directly for testing:

    python -m screenshooter.modules.backup.main settings --outputdir /path/to/dir
    """
    try:
        zip_path = perform_backup(backup_type, output_dir, verbosity=verbosity)
        console.print(f"[green]Backup completed successfully:[/green] {zip_path}")
    except BackupError as exc:
        console.print(f"[bold red]Backup failed:[/bold red] {exc}")
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
