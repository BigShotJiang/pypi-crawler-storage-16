"""Client management module for ScreenShooter Mac."""

# Export models
# Export CLI functions
from screenshooter.modules.clients.cli import (
    create_new_client,
    interactive_client_management,
    list_all_clients,
    list_client_projects,
    manage_client,
)

# Export manager
from screenshooter.modules.clients.manager import ClientManager
from screenshooter.modules.clients.models import ClientInfo

# Export utilities
from screenshooter.modules.clients.utils import (
    get_client_dir,
    get_client_info_path,
    get_client_project_path,
    get_client_project_reports_path,
    get_client_project_sessions_path,
    get_clients_base_dir,
    load_client_info,
    save_client_info,
)


# Define a function that dynamically imports and runs main to avoid circular imports
def main():
    """Main entry point, delegates to main.py's main function."""
    from screenshooter.modules.clients.main import main as clients_main

    return clients_main()
