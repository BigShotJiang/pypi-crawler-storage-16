#!/usr/bin/env python3
"""Main entry point for clients module when run directly."""

from screenshooter.modules.clients.main import main

# Allow running the module directly with python -m
if __name__ == "__main__":
    main()
