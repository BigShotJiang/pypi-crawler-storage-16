#!/usr/bin/env python3
"""Client CLI functionality for ScreenShooter Mac."""

import shutil
from typing import Any, Optional

from rich.console import Console

from screenshooter.modules.clients.models import ClientInfo
from screenshooter.modules.clients.utils import slugify_name

# Initialize rich console
console = Console()


def _prompt_ask_on_new_line(prompt_text: str, **kwargs: Any) -> str:
    """Prompt with choices/default on one line, input on a clean `> ` line below."""
    choices = kwargs.get("choices")
    default = kwargs.get("default")

    if choices:
        choices_str = "/".join(str(c) for c in choices)
        extra = f" [{choices_str}]"
        if default is not None:
            extra += f" ({default})"
        # Disable rich markup so literal square brackets for choices render correctly
        console.print(f"{prompt_text}{extra}:", markup=False)
    else:
        # Show default value even when there are no choices
        extra = ""
        if default is not None:
            extra = f" ({default})"
        console.print(f"{prompt_text}{extra}:", markup=False)

    while True:
        raw = input("> ").strip()
        if not raw and default is not None:
            raw = str(default)
        if choices:
            if raw in [str(c) for c in choices]:
                return raw
            console.print(
                f"[red]Invalid choice: {raw}. Please enter one of: {', '.join(str(c) for c in choices)}[/red]"
            )
            continue
        return raw


def _confirm_on_new_line(prompt_text: str, **kwargs: Any) -> bool:
    """Yes/No confirm with indicator on question line and `> ` for input."""
    default = kwargs.get("default", False)
    indicator = "[Y/n]" if default else "[y/N]"
    default_choice = "y" if default else "n"
    console.print(f"{prompt_text} {indicator} ({default_choice}):", markup=False)
    default_choice = "y" if default else "n"

    while True:
        raw = input("> ").strip().lower()
        if not raw:
            raw = default_choice
        if raw in ("y", "n"):
            return raw == "y"
        console.print("[red]Please enter 'y' or 'n'.[/red]")


def edit_client_info_interactive(manager, directory_name: str) -> str:
    """Interactive editor for client information."""
    client_info = manager.load_client_info_from_directory(directory_name)

    console.print("\n[bold]Edit Client Information[/bold]")
    console.print("=======================")

    # Ask for client display name with the current name as default
    new_client_name = _prompt_ask_on_new_line(
        "Client name (display name)", default=client_info.client_name
    )

    # Ask if user wants to change directory name (optional)
    change_directory = False
    new_directory_name = directory_name

    if _confirm_on_new_line(
        "Would you like to change the directory name? (Advanced)", default=False
    ):
        new_directory_name = _prompt_ask_on_new_line(
            "Directory name", default=client_info.directory_name
        )
        if new_directory_name != directory_name:
            change_directory = True

    # Display current values and get new ones
    company_name = _prompt_ask_on_new_line("Company name", default=client_info.company_name)
    contact_name = _prompt_ask_on_new_line("Contact name", default=client_info.contact_name)
    contact_email = _prompt_ask_on_new_line("Contact email", default=client_info.contact_email)

    # Update preferences
    console.print("\n[bold]Preferences[/bold]")
    console.print("===========")

    delivery_options = ["local", "email", "cloud"]
    screenshot_delivery = _prompt_ask_on_new_line(
        "Screenshot delivery method",
        choices=delivery_options,
        default=client_info.preferences.get("screenshot_delivery", "local"),
    )

    notification_options = ["all", "important", "none"]
    notification_preferences = _prompt_ask_on_new_line(
        "Notification preferences",
        choices=notification_options,
        default=client_info.preferences.get("notification_preferences", "all"),
    )

    reporting_options = ["daily", "weekly", "monthly", "none"]
    reporting_frequency = _prompt_ask_on_new_line(
        "Reporting frequency",
        choices=reporting_options,
        default=client_info.preferences.get("reporting_frequency", "none"),
    )

    # Add PDF security options
    security_options = ["none", "password"]
    pdf_security = _prompt_ask_on_new_line(
        "PDF security",
        choices=security_options,
        default=client_info.preferences.get("pdf_security", "none"),
    )

    # Ask for password if security is set to password
    pdf_password = ""
    if pdf_security == "password":
        while True:
            pdf_password = _prompt_ask_on_new_line("Enter PDF password", password=True)
            if pdf_password:
                # Confirm password
                confirm_password = _prompt_ask_on_new_line("Confirm PDF password", password=True)
                if pdf_password == confirm_password:
                    break
                else:
                    console.print("[bold red]Passwords do not match. Please try again.[/bold red]")
            else:
                console.print(
                    "[bold yellow]Password cannot be empty for password security.[/bold yellow]"
                )

    # Add page size options
    page_size_options = ["A4", "letter"]
    page_size = _prompt_ask_on_new_line(
        "PDF page size",
        choices=page_size_options,
        default=client_info.preferences.get("page_size", "A4"),
    )

    # Handle directory name change if requested
    if change_directory:
        # Handle directory name change (involves directory renaming)
        old_client_dir = manager.base_dir / directory_name
        new_client_dir = manager.base_dir / new_directory_name

        # Check if the new directory already exists
        if new_client_dir.exists() and (new_client_dir / "client_info.json").exists():
            console.print(
                f"[bold red]A client directory with the name '{new_directory_name}' already exists![/bold red]"
            )
            if not _confirm_on_new_line(
                "Do you want to continue with the directory change? This will merge the directories."
            ):
                console.print(
                    "[yellow]Directory name change cancelled. Keeping other updates.[/yellow]"
                )
                new_directory_name = directory_name  # Revert the directory name change
                change_directory = False

        if change_directory:  # Only proceed if the directory change wasn't cancelled
            try:
                # Create the new directory if it doesn't exist
                new_client_dir.mkdir(parents=True, exist_ok=True)

                # Copy all contents from old directory to new directory, except client_info.json
                for item in old_client_dir.glob("*"):
                    if item.name != "client_info.json":
                        if item.is_dir():
                            # Copy directory and its contents
                            target_dir = new_client_dir / item.name
                            if target_dir.exists():
                                # If target directory exists, copy contents file by file
                                for sub_item in item.glob("**/*"):
                                    if sub_item.is_file():
                                        rel_path = sub_item.relative_to(item)
                                        target_path = target_dir / rel_path
                                        target_path.parent.mkdir(parents=True, exist_ok=True)
                                        shutil.copy2(sub_item, target_path)
                            else:
                                # If target directory doesn't exist, copy the whole directory
                                shutil.copytree(item, target_dir)
                        else:
                            # Copy file
                            shutil.copy2(item, new_client_dir / item.name)

                # Remove the old directory after successful transfer
                shutil.rmtree(old_client_dir)
                console.print(
                    f"[bold green]Directory renamed successfully from '{directory_name}' to '{new_directory_name}'.[/bold green]"
                )

            except Exception as e:
                console.print(f"[bold red]Error during directory name change: {e}[/bold red]")
                console.print("[yellow]Continuing with other updates...[/yellow]")
                new_directory_name = (
                    directory_name  # Keep the original directory name if there was an error
                )
                change_directory = False

    # Update client info object
    client_info.client_name = new_client_name
    client_info.directory_name = new_directory_name
    client_info.company_name = company_name
    client_info.contact_name = contact_name
    client_info.contact_email = contact_email
    client_info.preferences["screenshot_delivery"] = screenshot_delivery
    client_info.preferences["notification_preferences"] = notification_preferences
    client_info.preferences["reporting_frequency"] = reporting_frequency
    client_info.preferences["pdf_security"] = pdf_security
    client_info.pdf_password = pdf_password
    client_info.preferences["page_size"] = page_size

    # Save the updated info
    manager.save_client_info(client_info)

    # Return the new directory name for the caller
    return new_directory_name


def create_new_client_for_screenshot() -> Optional[str]:
    """Create a new client interactively and return the client name for screenshot module.

    Returns:
        str: The client name if successful, None if cancelled
    """
    from screenshooter.modules.clients.manager import ClientManager

    manager = ClientManager()

    console.print("[bold]Create New Client[/bold]")
    console.print("=================")
    console.print("(Leave blank and press Enter to cancel)")

    client_name = _prompt_ask_on_new_line("Client name (display name)", default="")
    if not client_name:
        console.print("[yellow]Client creation cancelled.[/yellow]")
        return None

    # Use a safe slug of the client name as the initial directory name
    directory_name = slugify_name(client_name)

    # Advanced option for custom directory name
    if _confirm_on_new_line(
        "Would you like to use a custom directory name? (Advanced)", default=False
    ):
        directory_name = _prompt_ask_on_new_line("Directory name", default=directory_name)

    # Check if client already exists
    if manager.client_exists(directory_name):
        if not _confirm_on_new_line(
            f"Client directory '{directory_name}' already exists. Would you like to edit it?"
        ):
            return None

        # Display existing client info
        manager.display_client_info(directory_name)

        # Ask if they want to update this client's information
        if _confirm_on_new_line("Would you like to update this client's information?"):
            # Edit existing client
            new_directory_name = edit_client_info_interactive(manager, directory_name)
            if new_directory_name and new_directory_name != directory_name:
                directory_name = new_directory_name

        # For existing clients, just return the client name after any editing
        client_info = manager.load_client_info_from_directory(directory_name)
        return client_info.client_name
    else:
        # Create new client with basic info
        client_info = ClientInfo(client_name=client_name, directory_name=directory_name)

        # Ask for additional details immediately instead of creating and then editing
        console.print("\n[bold]Additional Client Information[/bold]")
        console.print("==========================")
        company_name = _prompt_ask_on_new_line("Company name", default="")
        contact_name = _prompt_ask_on_new_line("Contact name", default="")
        contact_email = _prompt_ask_on_new_line("Contact email", default="")

        # Update preferences
        console.print("\n[bold]Preferences[/bold]")
        console.print("===========")

        delivery_options = ["local", "email", "cloud"]
        screenshot_delivery = _prompt_ask_on_new_line(
            "Screenshot delivery method", choices=delivery_options, default="local"
        )

        notification_options = ["all", "important", "none"]
        notification_preferences = _prompt_ask_on_new_line(
            "Notification preferences", choices=notification_options, default="all"
        )

        reporting_options = ["daily", "weekly", "monthly", "none"]
        reporting_frequency = _prompt_ask_on_new_line(
            "Reporting frequency", choices=reporting_options, default="none"
        )

        # Add PDF security options
        security_options = ["none", "password"]
        pdf_security = _prompt_ask_on_new_line(
            "PDF security", choices=security_options, default="none"
        )

        # Ask for password if security is set to password
        pdf_password = ""
        if pdf_security == "password":
            while True:
                pdf_password = _prompt_ask_on_new_line("Enter PDF password", password=True)
                if pdf_password:
                    # Confirm password
                    confirm_password = _prompt_ask_on_new_line(
                        "Confirm PDF password", password=True
                    )
                    if pdf_password == confirm_password:
                        break
                    else:
                        console.print(
                            "[bold red]Passwords do not match. Please try again.[/bold red]"
                        )
                else:
                    console.print(
                        "[bold yellow]Password cannot be empty for password security.[/bold yellow]"
                    )

        # Add page size options
        page_size_options = ["A4", "letter"]
        page_size = _prompt_ask_on_new_line(
            "PDF page size", choices=page_size_options, default="A4"
        )

        # Update client info with collected data
        client_info.company_name = company_name
        client_info.contact_name = contact_name
        client_info.contact_email = contact_email
        client_info.preferences["screenshot_delivery"] = screenshot_delivery
        client_info.preferences["notification_preferences"] = notification_preferences
        client_info.preferences["reporting_frequency"] = reporting_frequency
        client_info.preferences["pdf_security"] = pdf_security
        client_info.pdf_password = pdf_password
        client_info.preferences["page_size"] = page_size

        # Save the client info with all the details
        manager.save_client_info(client_info)

        # Display final client info
        manager.display_client_info(directory_name)

        # Return the directory name for the screenshot module
        return client_info.directory_name


def create_new_client() -> None:
    """Create a new client interactively."""
    from screenshooter.modules.clients.manager import ClientManager

    manager = ClientManager()

    console.print("[bold]Create New Client[/bold]")
    console.print("=================")
    console.print("(Leave blank and press Enter to cancel)")

    client_name = _prompt_ask_on_new_line("Client name (display name)", default="")
    if not client_name:
        console.print("[yellow]Client creation cancelled.[/yellow]")
        return

    # Use a safe slug of the client name as the initial directory name
    directory_name = slugify_name(client_name)

    # Advanced option for custom directory name
    if _confirm_on_new_line(
        "Would you like to use a custom directory name? (Advanced)", default=False
    ):
        directory_name = _prompt_ask_on_new_line("Directory name", default=directory_name)

    # Check if client already exists
    if manager.client_exists(directory_name):
        if not _confirm_on_new_line(
            f"Client directory '{directory_name}' already exists. Would you like to edit it?"
        ):
            return

        # Display existing client info
        manager.display_client_info(directory_name)

        # Ask if they want to update this client's information
        if _confirm_on_new_line("Would you like to update this client's information?"):
            # Edit existing client
            new_directory_name = edit_client_info_interactive(manager, directory_name)
            if new_directory_name and new_directory_name != directory_name:
                directory_name = new_directory_name
    else:
        # Create new client with basic info
        client_info = ClientInfo(client_name=client_name, directory_name=directory_name)

        # Ask for additional details immediately instead of creating and then editing
        console.print("\n[bold]Additional Client Information[/bold]")
        console.print("==========================")
        company_name = _prompt_ask_on_new_line("Company name", default="")
        contact_name = _prompt_ask_on_new_line("Contact name", default="")
        contact_email = _prompt_ask_on_new_line("Contact email", default="")

        # Update preferences
        console.print("\n[bold]Preferences[/bold]")
        console.print("===========")

        delivery_options = ["local", "email", "cloud"]
        screenshot_delivery = _prompt_ask_on_new_line(
            "Screenshot delivery method", choices=delivery_options, default="local"
        )

        notification_options = ["all", "important", "none"]
        notification_preferences = _prompt_ask_on_new_line(
            "Notification preferences", choices=notification_options, default="all"
        )

        reporting_options = ["daily", "weekly", "monthly", "none"]
        reporting_frequency = _prompt_ask_on_new_line(
            "Reporting frequency", choices=reporting_options, default="none"
        )

        # Add PDF security options
        security_options = ["none", "password"]
        pdf_security = _prompt_ask_on_new_line(
            "PDF security", choices=security_options, default="none"
        )

        # Ask for password if security is set to password
        pdf_password = ""
        if pdf_security == "password":
            while True:
                pdf_password = _prompt_ask_on_new_line("Enter PDF password", password=True)
                if pdf_password:
                    # Confirm password
                    confirm_password = _prompt_ask_on_new_line(
                        "Confirm PDF password", password=True
                    )
                    if pdf_password == confirm_password:
                        break
                    else:
                        console.print(
                            "[bold red]Passwords do not match. Please try again.[/bold red]"
                        )
                else:
                    console.print(
                        "[bold yellow]Password cannot be empty for password security.[/bold yellow]"
                    )

        # Add page size options
        page_size_options = ["A4", "letter"]
        page_size = _prompt_ask_on_new_line(
            "PDF page size", choices=page_size_options, default="A4"
        )

        # Update client info with collected data
        client_info.company_name = company_name
        client_info.contact_name = contact_name
        client_info.contact_email = contact_email
        client_info.preferences["screenshot_delivery"] = screenshot_delivery
        client_info.preferences["notification_preferences"] = notification_preferences
        client_info.preferences["reporting_frequency"] = reporting_frequency
        client_info.preferences["pdf_security"] = pdf_security
        client_info.pdf_password = pdf_password
        client_info.preferences["page_size"] = page_size

        # Save the client info with all the details
        manager.save_client_info(client_info)

    # Display final client info
    manager.display_client_info(directory_name)

    # After creating/viewing, offer options
    console.print("\n[bold]Options:[/bold]")
    console.print("e: Edit client information")
    console.print("p: List projects")
    console.print("b: Go back")

    choice = _prompt_ask_on_new_line(
        "\nWhat would you like to do?", choices=["e", "p", "b"], default="b"
    )

    if choice == "e":
        # Get the possibly new directory name after editing
        new_directory_name = edit_client_info_interactive(manager, directory_name)
        # Use the new directory if it was changed
        if new_directory_name and new_directory_name != directory_name:
            directory_name = new_directory_name
        manager.display_client_info(directory_name)
        # After editing, give option to go back or do something else
        manage_client(directory_name)
    elif choice == "p":
        list_client_projects(directory_name)


def manage_client(client_name_or_directory: str) -> None:
    """Manage an existing client."""
    from screenshooter.modules.clients.manager import ClientManager

    manager = ClientManager()

    # Try to find the directory based on client name or use it directly
    try:
        directory_name = manager.get_directory_from_client_name(client_name_or_directory)
        if not directory_name:
            if manager.client_exists(client_name_or_directory):
                directory_name = client_name_or_directory
            else:
                console.print(
                    f"[bold red]Client '{client_name_or_directory}' not found.[/bold red]"
                )
                if _confirm_on_new_line("Would you like to create this client?"):
                    client_info = ClientInfo(
                        client_name=client_name_or_directory,
                        directory_name=slugify_name(client_name_or_directory),
                    )
                    manager.save_client_info(client_info)
                    # Get the possibly new directory name after editing
                    new_directory_name = edit_client_info_interactive(
                        manager, client_name_or_directory
                    )
                    # Use the new directory if it was changed
                    if new_directory_name and new_directory_name != client_name_or_directory:
                        directory_name = new_directory_name
                    else:
                        directory_name = client_name_or_directory
                else:
                    return
    except Exception as e:
        console.print(f"[bold red]Error accessing client data: {e}[/bold red]")
        console.print(
            "[yellow]Please check your database configuration or data source settings.[/yellow]"
        )
        return

    # Display client info
    manager.display_client_info(directory_name)

    # Check if client is archived
    is_archived = False
    try:
        # First try database check
        from screenshooter.modules.settings.settings_helper import should_use_database

        if should_use_database():
            from screenshooter.modules.database import DatabaseOperations

            db_ops = DatabaseOperations()
            db_client = db_ops.get_client_by_directory(directory_name)
            if not db_client:
                db_client = db_ops.get_client_by_name(client_name_or_directory)
            if db_client and db_client.archived_at:
                is_archived = True
        else:
            # Fallback to filesystem check
            client_info_file = manager.get_client_info_path(directory_name)
            if client_info_file.exists():
                import json

                data = json.loads(client_info_file.read_text())
                is_archived = bool(data.get("archived_at") or data.get("archived", False))
    except Exception:
        pass

    # Show options
    console.print("\n[bold]Options:[/bold]")
    console.print("e: Edit client information")
    console.print("p: List projects")
    if is_archived:
        console.print("u: Unarchive client")
        choices = ["e", "p", "u", "b"]
    else:
        console.print("a: Archive client")
        choices = ["e", "p", "a", "b"]
    console.print("b: Go back")

    choice = _prompt_ask_on_new_line("\nWhat would you like to do?", choices=choices, default="e")

    if choice == "e":
        # Get the possibly new directory name after editing
        new_directory_name = edit_client_info_interactive(manager, directory_name)
        # Use the new directory if it was changed
        if new_directory_name and new_directory_name != directory_name:
            directory_name = new_directory_name
        manager.display_client_info(directory_name)
        # After editing, give option to go back or do something else
        manage_client(directory_name)
    elif choice == "p":
        list_client_projects(directory_name)
    elif choice == "a":
        # Archive client
        client_info = manager.load_client_info_from_directory(directory_name)
        if _confirm_on_new_line(
            f"Are you sure you want to archive client '{client_info.client_name}'? "
            "This will hide it from the main screenshot flow."
        ):
            success = manager.archive_client(directory_name)
            if success:
                console.print(
                    f"[bold green]Client '{client_info.client_name}' has been archived.[/bold green]"
                )
                console.print(
                    "[yellow]You can access it via 'List all clients' in the client management menu.[/yellow]"
                )
            else:
                console.print(
                    f"[bold red]Failed to archive client '{client_info.client_name}'.[/bold red]"
                )
        else:
            console.print("[yellow]Archive cancelled.[/yellow]")
    elif choice == "u":
        # Unarchive client
        client_info = manager.load_client_info_from_directory(directory_name)
        if _confirm_on_new_line(
            f"Are you sure you want to unarchive client '{client_info.client_name}'? "
            "This will make it available in the main screenshot flow."
        ):
            success = manager.unarchive_client(directory_name)
            if success:
                console.print(
                    f"[bold green]Client '{client_info.client_name}' has been unarchived.[/bold green]"
                )
                console.print("[yellow]It will now appear in the main client list.[/yellow]")
            else:
                console.print(
                    f"[bold red]Failed to unarchive client '{client_info.client_name}'.[/bold red]"
                )
        else:
            console.print("[yellow]Unarchive cancelled.[/yellow]")


def list_all_clients() -> None:
    """List all clients with basic information and provide options."""
    from screenshooter.modules.clients.manager import ClientManager

    manager = ClientManager()
    try:
        directory_names = manager.list_clients(
            include_archived=True
        )  # Include all clients to show archive status
    except Exception as e:
        console.print(f"[bold red]Error accessing client data: {e}[/bold red]")
        console.print(
            "[yellow]Please check your database configuration or data source settings.[/yellow]"
        )
        return

    if not directory_names:
        console.print("[yellow]No clients found.[/yellow]")
        if _confirm_on_new_line("Would you like to create a new client?"):
            create_new_client()
        return

    # Pagination Loop
    PAGE_SIZE = 10
    page = 0

    while True:
        total_items = len(directory_names)
        if total_items == 0:
            total_pages = 1
        else:
            total_pages = (total_items + PAGE_SIZE - 1) // PAGE_SIZE

        if page >= total_pages:
            page = total_pages - 1
        page = max(page, 0)

        start_idx = page * PAGE_SIZE
        end_idx = min(start_idx + PAGE_SIZE, total_items)
        page_items = directory_names[start_idx:end_idx]

        if total_pages > 1:
            console.print(f"\n[bold]Available Clients (Page {page + 1}/{total_pages}):[/bold]")
        else:
            console.print("\n[bold]Available Clients:[/bold]")
        console.print("==================")

        # Display clients with numbers for selection
        import json

        for i, directory_name in enumerate(page_items):
            client_info = manager.load_client_info_from_directory(directory_name)
            display_idx = start_idx + i + 1

            # Check if client is archived (check both database and filesystem)
            is_archived = False
            try:
                # First try database check
                from screenshooter.modules.settings.settings_helper import should_use_database

                if should_use_database():
                    from screenshooter.modules.database import DatabaseOperations

                    db_ops = DatabaseOperations()
                    db_client = db_ops.get_client_by_directory(directory_name)
                    if not db_client:
                        db_client = db_ops.get_client_by_name(client_info.client_name)
                    if db_client and db_client.archived_at:
                        is_archived = True
                else:
                    # Fallback to filesystem check
                    client_info_file = manager.get_client_info_path(directory_name)
                    if client_info_file.exists():
                        data = json.loads(client_info_file.read_text())
                        is_archived = data.get("archived", False)
            except Exception:
                pass

            # Display client with archive status
            if is_archived:
                console.print(
                    f"{display_idx}. [bold]{client_info.client_name}[/bold] ({client_info.company_name}) [dim](Archived)[/dim]"
                )
            else:
                console.print(
                    f"{display_idx}. [bold]{client_info.client_name}[/bold] ({client_info.company_name})"
                )

        console.print("\n[bold]Options:[/bold]")
        console.print(f"{start_idx + 1}-{end_idx}: Select client")
        console.print("c: Create new client")
        console.print("b: Go back to client menu")

        extra_options = []
        if page < total_pages - 1:
            console.print("n: Next Page")
            extra_options.append("n")
        if page > 0:
            console.print("p: Previous Page")
            extra_options.append("p")

        # Create choices list with client numbers, 'c', 'b', and navigation
        choices = (
            [str(start_idx + i + 1) for i in range(len(page_items))] + ["c", "b"] + extra_options
        )

        choice = _prompt_ask_on_new_line(
            "\nWhat would you like to do?", choices=choices, default="b"
        )

        if choice == "c":
            create_new_client()
            # Refresh list after creation? Usually good idea, loop again
            directory_names = manager.list_clients()
            # Reset to last page to show new item? Or just stay.
            # Let's just loop; page might be invalid if deleted, but creation adds.
            # total_items will update next loop.
        elif choice == "b":
            return
        elif choice == "n":
            page += 1
        elif choice == "p":
            page -= 1
        else:
            # User selected a client
            selected_dir = directory_names[int(choice) - 1]
            manage_client(selected_dir)
            # After managing, return to list? Loop continues.


def list_client_projects(directory_name: str) -> None:
    """List all projects for a specific client and provide options."""
    from screenshooter.modules.clients.manager import ClientManager
    from screenshooter.modules.settings.settings_helper import should_use_database

    manager = ClientManager()
    client_db_id = None
    db_ops = None

    try:
        client_exists = manager.client_exists(directory_name)
    except Exception as e:
        console.print(f"[bold red]Error checking client existence: {e}[/bold red]")
        console.print(
            "[yellow]Please check your database configuration or data source settings.[/yellow]"
        )
        return

    if not client_exists:
        console.print(f"[bold red]Client directory '{directory_name}' not found.[/bold red]")
        if _confirm_on_new_line("Would you like to create this client?"):
            # Ask for a client name first, using the directory name as default
            client_name = _prompt_ask_on_new_line(
                "Client name (display name)", default=directory_name
            )
            client_info = ClientInfo(client_name=client_name, directory_name=directory_name)
            manager.save_client_info(client_info)
            # Get the possibly new directory name after editing
            new_directory_name = edit_client_info_interactive(manager, directory_name)
            # Use the new directory if it was changed
            if new_directory_name and new_directory_name != directory_name:
                directory_name = new_directory_name
        return

    try:
        use_database = should_use_database()
        if use_database:
            from screenshooter.modules.database import DatabaseOperations

            db_ops = DatabaseOperations()
            db_client = db_ops.get_client_by_directory(directory_name) or db_ops.get_client_by_name(
                directory_name
            )
            client_db_id = db_client.id if db_client else None
    except Exception as e:
        console.print(f"[bold red]Error accessing project data: {e}[/bold red]")
        console.print(
            "[yellow]Please check your database configuration or data source settings.[/yellow]"
        )
        return

    def _fetch_projects():
        """Return ordered list of project entries (active first)."""
        projects_list = []
        archived_list = []

        if db_ops and client_db_id:
            try:
                db_active = db_ops.list_projects(client_db_id, active_only=True)
                db_archived = db_ops.list_archived_projects(client_db_id)
                for project in db_active:
                    projects_list.append(
                        {
                            "display_name": project.name,
                            "directory_name": project.directory_name,
                            "archived": False,
                            "project_id": project.id,
                        }
                    )
                for project in db_archived:
                    archived_list.append(
                        {
                            "display_name": project.name,
                            "directory_name": project.directory_name,
                            "archived": True,
                            "project_id": project.id,
                        }
                    )
            except Exception as exc:  # noqa: BLE001 - user-facing message already handled
                console.print(f"[bold red]Error accessing project data: {exc}[/bold red]")
                console.print(
                    "[yellow]Please check your database configuration or data source settings.[/yellow]"
                )
                return [], []
        else:
            import json

            client_dir = manager.base_dir / directory_name
            if not client_dir.exists():
                return [], []

            for project_dir in sorted(client_dir.iterdir()):
                if project_dir.is_dir():
                    project_file = project_dir / "project.json"
                    if not project_file.exists():
                        continue
                    try:
                        data = json.loads(project_file.read_text())
                        display_name = data.get("project_name", project_dir.name)
                        is_archived = bool(data.get("archived_at") or data.get("archived", False))
                        entry = {
                            "display_name": display_name,
                            "directory_name": project_dir.name,
                            "archived": is_archived,
                            "project_id": None,
                        }
                        if is_archived:
                            archived_list.append(entry)
                        else:
                            projects_list.append(entry)
                    except (json.JSONDecodeError, IOError):
                        continue

        return projects_list, archived_list

    projects, archived_projects = _fetch_projects()
    client_info = manager.load_client_info_from_directory(directory_name)

    console.print(f"\n[bold]Client:[/bold] {client_info.client_name}")
    console.print(f"[bold]Directory:[/bold] {client_info.directory_name}")
    console.print(f"[bold]Company:[/bold] {client_info.company_name}")

    if not projects and not archived_projects:
        console.print("[yellow]No projects found for this client.[/yellow]")
        console.print("\n[bold]Options:[/bold]")
        console.print("e: Edit client")
        console.print("b: Go back")

        choice = _prompt_ask_on_new_line(
            "\nWhat would you like to do?", choices=["e", "b"], default="b"
        )

        if choice == "e":
            manage_client(directory_name)
        return

    page = 0
    view_archived = False
    page_size = 10

    while True:
        current_list = archived_projects if view_archived else projects
        total_items = len(current_list)
        total_pages = (total_items + page_size - 1) // page_size if total_items else 1
        page = min(max(page, 0), max(total_pages - 1, 0))

        start_idx = page * page_size
        end_idx = min(start_idx + page_size, total_items)
        page_items = current_list[start_idx:end_idx]

        heading = "Archived Projects" if view_archived else "Active Projects"
        if total_pages > 1:
            console.print(f"\n[bold]{heading} (Page {page + 1}/{total_pages}):[/bold]")
        else:
            console.print(f"\n[bold]{heading}:[/bold]")
        console.print("==================")

        if not page_items:
            console.print("[dim]No projects to display.[/dim]")

        for i, project in enumerate(page_items):
            display_idx = start_idx + i + 1
            suffix = " [dim](Archived)[/dim]" if project.get("archived") else ""
            console.print(f"{display_idx}. [bold]{project.get('display_name')}[/bold]{suffix}")

        console.print("\n[bold]Options:[/bold]")
        if page_items:
            console.print(f"{start_idx + 1}-{end_idx}: Select project")
        if not view_archived and archived_projects:
            console.print(f"a: Show archived projects ({len(archived_projects)})")
        if view_archived and projects:
            console.print("v: Show active projects")
        console.print("e: Edit client")
        console.print("b: Go back")

        extra_options = []
        if page < total_pages - 1:
            console.print("n: Next Page")
            extra_options.append("n")
        if page > 0:
            console.print("p: Previous Page")
            extra_options.append("p")

        choices = ["e", "b"] + extra_options
        if not view_archived and archived_projects:
            choices.append("a")
        if view_archived and projects:
            choices.append("v")
        if page_items:
            choices.extend([str(start_idx + i + 1) for i in range(len(page_items))])

        choice = _prompt_ask_on_new_line(
            "\nWhat would you like to do?", choices=choices, default="b"
        )

        if choice == "e":
            manage_client(directory_name)
        elif choice == "b":
            return
        elif choice == "n":
            page += 1
        elif choice == "p":
            page -= 1
        elif choice == "a" and not view_archived:
            view_archived = True
            page = 0
        elif choice == "v" and view_archived:
            view_archived = False
            page = 0
        else:
            if not isinstance(choice, str) or not choice.isdigit():
                console.print("[red]Invalid selection.[/red]")
                continue
            idx = int(choice) - 1
            if 0 <= idx < len(page_items):
                selected_project = page_items[idx]
                changed = project_detail_view(
                    manager=manager,
                    client_directory=directory_name,
                    project_entry=selected_project,
                    db_ops=db_ops,
                    client_db_id=client_db_id,
                )
                if changed:
                    projects, archived_projects = _fetch_projects()
                    page = 0
            else:
                console.print("[red]Invalid selection.[/red]")


def project_detail_view(
    *,
    manager,
    client_directory: str,
    project_entry: dict,
    db_ops=None,
    client_db_id=None,
) -> bool:
    """Show project details and allow rename/archive actions.

    Returns:
        True if project state changed, False otherwise.
    """

    def _resolve_project_id() -> Optional[int]:
        project_id = project_entry.get("project_id")
        if project_id:
            return project_id
        if db_ops and client_db_id:
            try:
                db_project = db_ops.get_project_by_directory(
                    client_db_id, project_entry.get("directory_name")
                )
                if db_project and db_project.id:
                    project_entry["project_id"] = db_project.id
                    return db_project.id
            except Exception:
                return None
        return None

    changed = False
    project_dir = project_entry.get("directory_name")
    metadata = manager.load_project_metadata(client_directory, project_dir)

    # Keep display name in sync with metadata when available
    display_name = metadata.project_name or project_entry.get("display_name") or project_dir
    project_entry["display_name"] = display_name
    archived = project_entry.get("archived") or bool(metadata.archived_at)

    while True:
        console.print("\n[bold]Project Details[/bold]")
        console.print("------------------")
        console.print(f"Project: [bold]{display_name}[/bold]")
        console.print(f"Directory: {metadata.directory_name}")
        console.print(f"Started: {metadata.started_at}")
        console.print(f"Last Updated: {metadata.last_updated}")
        console.print(f"Finished: {metadata.finished_at}")
        console.print(f"Archived At: {metadata.archived_at or 'Active'}")

        console.print("\n[bold]Options:[/bold]")
        console.print("e: Edit project name")
        if archived:
            console.print("u: Unarchive project")
            choices = ["e", "u", "b"]
        else:
            console.print("a: Archive project")
            choices = ["e", "a", "b"]
        console.print("b: Go back")

        choice = _prompt_ask_on_new_line(
            "\nWhat would you like to do?", choices=choices, default="b"
        )

        if choice == "b":
            return changed
        if choice == "e":
            new_name = _prompt_ask_on_new_line("New project name", default=display_name)
            if not new_name:
                console.print("[yellow]Project name cannot be empty.[/yellow]")
                continue
            if new_name == display_name:
                console.print("[yellow]No changes made to the project name.[/yellow]")
                continue

            fs_success = manager.update_project_display_name(
                client_directory, project_dir, new_name
            )

            db_success = True
            project_id = _resolve_project_id()
            if db_ops and project_id:
                try:
                    db_success = db_ops.update_project_name(project_id, new_name)
                except Exception as exc:  # noqa: BLE001 - user-facing message already handled
                    console.print(f"[red]Failed to update project name in database: {exc}[/red]")
                    db_success = False

            manager.append_project_log(
                client_directory, project_dir, f"Project renamed: {display_name} -> {new_name}"
            )

            if fs_success or db_success:
                console.print(f"[green]Project name updated to '{new_name}'.[/green]")
                display_name = new_name
                metadata = manager.load_project_metadata(client_directory, project_dir)
                project_entry["display_name"] = new_name
                changed = True
            else:
                console.print("[red]Failed to update project name.[/red]")
        elif choice == "a" and not archived:
            if not _confirm_on_new_line(
                f"Archive project '{display_name}'? This will mark it as completed."
            ):
                console.print("[yellow]Archive cancelled.[/yellow]")
                continue

            fs_success = manager.update_project_archive_status(
                client_directory, project_dir, archived=True
            )

            db_success = True
            project_id = _resolve_project_id()
            if db_ops and project_id:
                try:
                    db_success = db_ops.archive_project(project_id)
                except Exception as exc:  # noqa: BLE001 - user-facing message already handled
                    console.print(f"[red]Failed to archive project in database: {exc}[/red]")
                    db_success = False

            manager.append_project_log(
                client_directory, project_dir, f"Project {display_name} archived"
            )

            if fs_success or db_success:
                console.print(f"[green]Project '{display_name}' archived.[/green]")
                archived = True
                project_entry["archived"] = True
                metadata = manager.load_project_metadata(client_directory, project_dir)
                changed = True
            else:
                console.print("[red]Failed to archive project.[/red]")
        elif choice == "u" and archived:
            if not _confirm_on_new_line(
                f"Unarchive project '{display_name}'? This will make it active."
            ):
                console.print("[yellow]Unarchive cancelled.[/yellow]")
                continue

            fs_success = manager.update_project_archive_status(
                client_directory, project_dir, archived=False
            )

            db_success = True
            project_id = _resolve_project_id()
            if db_ops and project_id:
                try:
                    db_success = db_ops.unarchive_project(project_id)
                except Exception as exc:  # noqa: BLE001 - user-facing message already handled
                    console.print(f"[red]Failed to unarchive project in database: {exc}[/red]")
                    db_success = False

            manager.append_project_log(
                client_directory, project_dir, f"Project {display_name} unarchived"
            )

            if fs_success or db_success:
                console.print(f"[green]Project '{display_name}' unarchived.[/green]")
                archived = False
                project_entry["archived"] = False
                metadata = manager.load_project_metadata(client_directory, project_dir)
                changed = True
            else:
                console.print("[red]Failed to unarchive project.[/red]")
        else:
            console.print("[red]Invalid selection.[/red]")


def interactive_client_management() -> None:
    """Interactive client management menu."""
    console.print("[bold]Client Management[/bold]")
    console.print("=================")
    console.print("(Enter 'b' at any prompt to go back to the previous menu)")

    options = [
        "Manage active clients",
        "List all clients",
        "Create new client",
        "Exit",
    ]
    console.print("\nOptions:")
    for i, option in enumerate(options, 1):
        console.print(f"{i}. {option}")

    choice = _prompt_ask_on_new_line(
        "\nWhat would you like to do? (or 'b' to go back)",
        choices=[str(i) for i in range(1, len(options) + 1)] + ["b"],
        default="1",
    )

    if choice == "b":
        console.print("[yellow]Cancelled. Returning to main menu.[/yellow]")
        return
    if choice == "1":
        # Manage active clients - similar to old "Manage existing client"
        from screenshooter.modules.clients.manager import ClientManager

        manager = ClientManager()
        directory_names = manager.list_clients(include_archived=False)

        if not directory_names:
            console.print("[yellow]No active clients found.[/yellow]")
            if _confirm_on_new_line("Would you like to create a new client?"):
                create_new_client()
            return

        # Allow selection from list with clear labeling
        console.print("\n[bold]Active Clients:[/bold]")
        client_display = []
        for i, directory in enumerate(directory_names, 1):
            client_info = manager.load_client_info_from_directory(directory)
            client_display.append(f"{i}. {client_info.client_name}")
            console.print(f"{i}. {client_info.client_name}")

        client_idx = _prompt_ask_on_new_line(
            "\nEnter client number to manage",
            choices=[str(i) for i in range(1, len(directory_names) + 1)],
            default="1",
        )

        selected_dir = directory_names[int(client_idx) - 1]
        manage_client(selected_dir)
    elif choice == "2":
        list_all_clients()
    elif choice == "3":
        create_new_client()
    elif choice == "4":
        console.print("Exiting client management.")


def manage_archived_clients() -> None:
    """Manage archived clients."""
    from screenshooter.modules.clients.manager import ClientManager

    manager = ClientManager()
    archived_clients = manager.list_archived_clients()

    if not archived_clients:
        console.print("[yellow]No archived clients found.[/yellow]")
        _prompt_ask_on_new_line("Press Enter to continue...", choices=[""], default="")
        return

    # Pagination for archived clients
    PAGE_SIZE = 10
    page = 0
    total_pages = (len(archived_clients) + PAGE_SIZE - 1) // PAGE_SIZE

    while True:
        if page >= total_pages:
            page = total_pages - 1
        page = max(page, 0)

        start_idx = page * PAGE_SIZE
        end_idx = min(start_idx + PAGE_SIZE, len(archived_clients))
        page_items = archived_clients[start_idx:end_idx]

        console.print(f"\n[bold]Archived Clients (Page {page + 1}/{total_pages}):[/bold]")
        console.print("[dim]These clients are hidden from the main screenshot flow.[/dim]")

        for i, client_name in enumerate(page_items):
            display_idx = start_idx + i + 1
            console.print(f"{display_idx}. {client_name} [dim](Archived)[/dim]")

        console.print("\n[bold]Options:[/bold]")
        console.print(f"{start_idx + 1}-{end_idx}: Select client to unarchive")
        console.print("b: Go back")

        extra_options = []
        if page < total_pages - 1:
            console.print("n: Next Page")
            extra_options.append("n")
        if page > 0:
            console.print("p: Previous Page")
            extra_options.append("p")

        choices = [str(start_idx + i + 1) for i in range(len(page_items))] + extra_options
        default_choice = "1" if page_items else "b"

        choice = _prompt_ask_on_new_line(
            "Select a client to unarchive or go back",
            choices=choices,
            default=default_choice,
        )

        if choice == "b":
            return
        elif choice == "n":
            page += 1
        elif choice == "p":
            page -= 1
        elif isinstance(choice, str) and choice.isdigit():
            selected_idx = int(choice) - 1
            if 0 <= selected_idx < len(archived_clients):
                selected_client_name = archived_clients[selected_idx]

                # Get directory name for the client
                try:
                    directory_name = manager.get_directory_from_client_name(selected_client_name)
                    if not directory_name:
                        # Try to find by treating the name as directory
                        if manager.client_exists(selected_client_name):
                            directory_name = selected_client_name
                except Exception as e:
                    console.print(f"[bold red]Error accessing client data: {e}[/bold red]")
                    console.print(
                        "[yellow]Please check your database configuration or data source settings.[/yellow]"
                    )
                    continue

                if directory_name:
                    # Confirm unarchive
                    if _confirm_on_new_line(
                        f"Unarchive client '{selected_client_name}' and make it available in the main screenshot flow?"
                    ):
                        success = manager.unarchive_client(directory_name)
                        if success:
                            console.print(
                                f"[bold green]Client '{selected_client_name}' has been unarchived.[/bold green]"
                            )
                            console.print(
                                "[yellow]It will now appear in the main client list.[/yellow]"
                            )
                            # Refresh the list
                            archived_clients = manager.list_archived_clients()
                            total_pages = (len(archived_clients) + PAGE_SIZE - 1) // PAGE_SIZE
                            if page >= total_pages and total_pages > 0:
                                page = total_pages - 1
                        else:
                            console.print(
                                f"[bold red]Failed to unarchive client '{selected_client_name}'.[/bold red]"
                            )
                    else:
                        console.print("[yellow]Unarchive cancelled.[/yellow]")
                else:
                    console.print(
                        f"[red]Could not find directory for client '{selected_client_name}'.[/red]"
                    )
            else:
                console.print("[red]Invalid selection.[/red]")
