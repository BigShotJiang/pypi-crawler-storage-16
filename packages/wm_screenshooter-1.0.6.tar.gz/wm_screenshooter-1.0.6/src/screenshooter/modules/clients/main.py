#!/usr/bin/env python3
"""Client management main module for ScreenShooter Mac."""

from typing import Optional

import click
from rich.console import Console

from screenshooter.modules.clients.cli import (
    create_new_client,
    interactive_client_management,
    list_all_clients,
    list_client_projects,
    manage_client,
)
from screenshooter.modules.clients.manager import ClientManager

# Initialize rich console
console = Console()


@click.command()
@click.option("--list", is_flag=True, help="List all clients")
@click.option("--new", is_flag=True, help="Create a new client")
@click.option("--client", help="Client name or directory to manage")
@click.option("--list-projects", is_flag=True, help="List projects for the specified client")
@click.option("--migrate", is_flag=True, help="Migrate existing client data to new format")
def main(list: bool, new: bool, client: Optional[str], list_projects: bool, migrate: bool) -> None:
    """Client management for Screenshooter Mac."""
    manager = ClientManager()

    # Always run migration on startup, but only show messages if --migrate flag is used
    if migrate:
        migrated = manager.migrate_client_data()
        if migrated == 0:
            console.print("[green]All client data is already in the latest format.[/green]")
    else:
        # Run silently
        manager.migrate_client_data()

    if list:
        list_all_clients()
    elif new:
        create_new_client()
    elif client and list_projects:
        # Try to find directory by client name or use directly
        manager = ClientManager()
        try:
            directory = manager.get_directory_from_client_name(client)
            if directory:
                list_client_projects(directory)
            # Try as directory directly
            elif manager.client_exists(client):
                list_client_projects(client)
            else:
                console.print(f"[bold red]Client '{client}' not found.[/bold red]")
                if click.confirm("Would you like to create this client?"):
                    create_new_client()
        except Exception as e:
            console.print(f"[bold red]Error accessing client data: {e}[/bold red]")
            console.print("[yellow]Please check your database configuration or data source settings.[/yellow]")
    elif client:
        manage_client(client)
    else:
        # Interactive menu if no options provided
        interactive_client_management()


if __name__ == "__main__":
    main()
