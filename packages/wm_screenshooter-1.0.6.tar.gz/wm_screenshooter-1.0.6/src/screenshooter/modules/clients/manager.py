#!/usr/bin/env python3
"""Client manager functionality for ScreenShooter Mac."""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from rich.console import Console

from screenshooter.modules.clients.models import ClientInfo
from screenshooter.modules.screenshot.project import ProjectMetadata
from screenshooter.modules.settings.settings_helper import (
    get_screenshots_dir,
    should_use_database,
)

# Configure logging
logger = logging.getLogger(__name__)

# Initialize rich console
console = Console()


class ClientManager:
    """Client management functionality."""

    def __init__(self, screenshots_dir: Optional[str] = None):
        """Initialize client manager with base directory for client data."""
        self.screenshots_dir = screenshots_dir or get_screenshots_dir()
        self.base_dir = Path(self.screenshots_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def get_client_info_path(self, directory_name: str) -> Path:
        """Get the path to a client's info file (new name: client.json)."""
        client_dir = self.base_dir / directory_name
        client_dir.mkdir(parents=True, exist_ok=True)
        return client_dir / "client.json"

    @staticmethod
    def _legacy_client_info_path(client_dir: Path) -> Path:
        return client_dir / "client_info.json"

    def _migrate_legacy_client_file(self, client_dir: Path) -> None:
        """Migrate legacy client_info.json to client.json, converting archived -> archived_at."""
        legacy = self._legacy_client_info_path(client_dir)
        target = client_dir / "client.json"
        if not legacy.exists():
            return
        try:
            data = json.loads(legacy.read_text())
        except Exception:
            data = {}

        archived_val = data.pop("archived", False)
        archived_at = data.get("archived_at", "")
        if not archived_at and archived_val:
            archived_at = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

        data["archived_at"] = archived_at

        # Ensure required fields
        data.setdefault("client_name", client_dir.name)
        data.setdefault("directory_name", client_dir.name)

        target.write_text(json.dumps(data, indent=2))
        legacy.unlink(missing_ok=True)

    def list_clients(self, include_archived: bool = False) -> List[str]:
        """List existing clients.

        Args:
            include_archived: If True, include archived clients in the list

        Raises:
            Exception: When database is enabled but fails
        """
        # Check if we should use database
        if should_use_database():
            try:
                from screenshooter.modules.database import DatabaseOperations

                db_ops = DatabaseOperations()
                if include_archived:
                    db_clients = db_ops.list_clients()  # All clients
                else:
                    db_clients = db_ops.list_clients(active_only=True)  # Only active clients
                # Return client names from database
                return [client.name for client in db_clients if client.name]
            except Exception as e:
                logger.error(f"Database error in list_clients: {e}")
                # Raise exception when DB is enabled but fails - no silent fallback
                raise Exception(f"Database error: {e}")

        # Filesystem mode: prefer client.json (migrate legacy client_info.json)
        import json

        clients = []
        for d in self.base_dir.iterdir():
            if not d.is_dir():
                continue
            client_json = d / "client.json"
            if not client_json.exists():
                self._migrate_legacy_client_file(d)
            if client_json.exists():
                try:
                    client_info = json.loads(client_json.read_text())
                    is_archived = bool(
                        client_info.get("archived_at") or client_info.get("archived", False)
                    )
                    if include_archived or not is_archived:
                        client_name = client_info.get("client_name", d.name)
                        clients.append(client_name)
                except (json.JSONDecodeError, IOError):
                    clients.append(d.name)
        return clients

    def list_projects(self, directory_name: str) -> List[str]:
        """List all projects for a specific client.

        Raises:
            Exception: When database is enabled but fails
        """
        # Check if we should use database
        if should_use_database():
            try:
                from screenshooter.modules.database import DatabaseOperations

                db_ops = DatabaseOperations()

                # First get the client by directory name or name
                client = db_ops.get_client_by_directory(directory_name)
                if not client:
                    client = db_ops.get_client_by_name(directory_name)

                if client and client.id:
                    db_projects = db_ops.list_projects(client.id)
                    return [project.name for project in db_projects if project.name]
                else:
                    logger.warning(f"Client '{directory_name}' not found in database")
                    return []
            except Exception as e:
                logger.error(f"Database error in list_projects: {e}")
                # Raise exception when DB is enabled but fails - no silent fallback
                raise Exception(f"Database error: {e}")

        # Filesystem mode: use project.json files
        import json

        client_dir = self.base_dir / directory_name
        if not client_dir.exists():
            return []

        projects = []
        for d in client_dir.iterdir():
            if d.is_dir() and (d / "project.json").exists():
                try:
                    project_info = json.loads((d / "project.json").read_text())
                    is_archived = bool(
                        project_info.get("archived_at") or project_info.get("archived", False)
                    )
                    if not is_archived:  # Only include active projects
                        # Use the project_name from the JSON file, not directory name
                        project_name = project_info.get("project_name", d.name)
                        projects.append(project_name)
                except (json.JSONDecodeError, IOError):
                    # Include projects with corrupted info files
                    projects.append(d.name)
        return projects

    def list_archived_projects(self, directory_name: str) -> List[str]:
        """List all archived projects for a specific client."""
        # Check if we should use database
        if should_use_database():
            try:
                from screenshooter.modules.database import DatabaseOperations

                db_ops = DatabaseOperations()

                # First get the client by directory name or name
                client = db_ops.get_client_by_directory(directory_name)
                if not client:
                    client = db_ops.get_client_by_name(directory_name)

                if client and client.id:
                    db_projects = db_ops.list_archived_projects(client.id)
                    return [project.name for project in db_projects if project.name]
                else:
                    # Client not found or no ID, return empty
                    return []
            except Exception as e:
                logger.warning(f"Failed to get archived projects from database: {e}")
                return []

        # Filesystem: check project.json markers
        client_dir = self.base_dir / directory_name
        if not client_dir.exists():
            return []

        archived: List[str] = []
        for d in client_dir.iterdir():
            if d.is_dir() and (d / "project.json").exists():
                try:
                    project_info = json.loads((d / "project.json").read_text())
                    is_archived = bool(
                        project_info.get("archived_at") or project_info.get("archived", False)
                    )
                    if is_archived:
                        archived.append(project_info.get("project_name", d.name))
                except (json.JSONDecodeError, IOError):
                    continue
        return archived

    def client_exists(self, directory_name: str) -> bool:
        """Check if a client exists.

        Raises:
            Exception: When database is enabled but fails
        """
        # Check if we should use database
        if should_use_database():
            try:
                from screenshooter.modules.database import DatabaseOperations

                db_ops = DatabaseOperations()

                # Check by directory name first, then by name
                client = db_ops.get_client_by_directory(directory_name)
                if not client:
                    client = db_ops.get_client_by_name(directory_name)

                return client is not None
            except Exception as e:
                logger.error(f"Database error in client_exists: {e}")
                # Raise exception when DB is enabled but fails - no silent failure
                raise Exception(f"Database error: {e}")

        # Filesystem mode: check for client_info.json
        return self.get_client_info_path(directory_name).exists()

    def client_name_exists(self, client_name: str) -> bool:
        """Check if a client with the given display name exists.

        Raises:
            Exception: When database is enabled but fails
        """
        # Check if we should use database
        if should_use_database():
            try:
                from screenshooter.modules.database import DatabaseOperations

                db_ops = DatabaseOperations()
                client = db_ops.get_client_by_name(client_name)
                return client is not None
            except Exception as e:
                logger.error(f"Database error in client_name_exists: {e}")
                # Raise exception when DB is enabled but fails - no silent failure
                raise Exception(f"Database error: {e}")

        # Filesystem mode: check client info files
        for directory in self.list_clients():
            client_info = self.load_client_info_from_directory(directory)
            if client_info.client_name == client_name:
                return True
        return False

    def get_directory_from_client_name(self, client_name: str) -> Optional[str]:
        """Get directory name for a client by its display name.

        Raises:
            Exception: When database is enabled but fails
        """
        # Check if we should use database
        if should_use_database():
            try:
                from screenshooter.modules.database import DatabaseOperations

                db_ops = DatabaseOperations()
                client = db_ops.get_client_by_name(client_name)
                if client:
                    return client.directory_name
                return None
            except Exception as e:
                logger.error(f"Database error in get_directory_from_client_name: {e}")
                # Raise exception when DB is enabled but fails - no silent failure
                raise Exception(f"Database error: {e}")

        # Filesystem mode: check client info files
        for directory in self.list_clients():
            client_info = self.load_client_info_from_directory(directory)
            if client_info.client_name == client_name:
                return directory
        return None

    def load_client_info_from_directory(self, directory_name: str) -> ClientInfo:
        """Load client information from file by directory name or create default."""
        # Check if we should use database
        if should_use_database():
            try:
                from screenshooter.modules.database import DatabaseOperations

                db_ops = DatabaseOperations()

                # Try to get client by directory name first, then by name
                db_client = db_ops.get_client_by_directory(directory_name)
                if not db_client:
                    db_client = db_ops.get_client_by_name(directory_name)

                if db_client:
                    # Convert DatabaseClient to ClientInfo
                    return ClientInfo(
                        client_name=db_client.name,
                        directory_name=db_client.directory_name or directory_name,
                        company_name=db_client.company_name or "",
                        contact_name=db_client.contact_name or "",
                        contact_email=db_client.contact_email or "",
                        pdf_password=db_client.pdf_password or "",
                        preferences=db_client.preferences or {},
                        last_updated=db_client.updated_at.strftime("%Y-%m-%d %H:%M:%S")
                        if db_client.updated_at
                        else "",
                    )
            except Exception as e:
                logger.error(f"Database error in load_client_info_from_directory: {e}")
                # No fallback - return default ClientInfo when DB is enabled but fails
                return ClientInfo(
                    client_name=directory_name,
                    directory_name=directory_name,
                    company_name="",
                    contact_name="",
                    contact_email="",
                    pdf_password="",
                    preferences={},
                    last_updated="",
                )

        # Filesystem mode: load from client.json (migrating legacy if present)
        client_dir = self.base_dir / directory_name
        self._migrate_legacy_client_file(client_dir)
        client_info_file = self.get_client_info_path(directory_name)

        if client_info_file.exists():
            try:
                client_info = ClientInfo.model_validate_json(client_info_file.read_text())
                if not client_info.directory_name:
                    client_info.directory_name = directory_name
                return client_info
            except Exception as e:
                console.print(f"[bold red]Error loading client info: {e}[/bold red]")

        return ClientInfo(client_name=directory_name, directory_name=directory_name)

    def load_client_info(self, client_name_or_directory: str) -> ClientInfo:
        """Load client information by client display name or directory name."""
        # First try to treat the input as a directory name
        if self.client_exists(client_name_or_directory):
            return self.load_client_info_from_directory(client_name_or_directory)

        # Next, try to find directory by client name
        directory = self.get_directory_from_client_name(client_name_or_directory)
        if directory:
            return self.load_client_info_from_directory(directory)

        # If all fails, return a new client with the input as both name and directory
        return ClientInfo(
            client_name=client_name_or_directory, directory_name=client_name_or_directory
        )

    def save_client_info(self, client_info: ClientInfo) -> None:
        """Save client information to both database and filesystem."""
        # Update the last_updated field
        client_info.last_updated = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Always save to database (if available) for consistency
        try:
            from screenshooter.modules.database import DatabaseOperations
            from screenshooter.modules.database.models import DatabaseClient

            db_ops = DatabaseOperations()

            # Try to find existing client by directory name or name
            existing_client = db_ops.get_client_by_directory(client_info.directory_name)
            if not existing_client:
                existing_client = db_ops.get_client_by_name(client_info.client_name)

            if existing_client and existing_client.id:
                # Update existing client
                db_client = DatabaseClient(
                    id=existing_client.id,
                    name=client_info.client_name,
                    directory_name=client_info.directory_name,
                    company_name=client_info.company_name,
                    contact_name=client_info.contact_name,
                    contact_email=client_info.contact_email,
                    pdf_password=client_info.pdf_password,
                    preferences=client_info.preferences,
                )
                success = db_ops.update_client(db_client)
                if success:
                    console.print(
                        "[bold green]Client information updated successfully in database![/bold green]"
                    )
                else:
                    console.print("[bold red]Failed to update client in database.[/bold red]")
            else:
                # Create new client
                db_client = DatabaseClient(
                    name=client_info.client_name,
                    directory_name=client_info.directory_name,
                    company_name=client_info.company_name,
                    contact_name=client_info.contact_name,
                    contact_email=client_info.contact_email,
                    pdf_password=client_info.pdf_password,
                    preferences=client_info.preferences,
                )
                client_id = db_ops.create_client(db_client)
                if client_id:
                    console.print(
                        "[bold green]Client information saved successfully to database![/bold green]"
                    )
                else:
                    console.print("[bold red]Failed to save client to database.[/bold red]")

        except Exception as e:
            console.print(f"[bold red]Database error: {e}[/bold red]")
            console.print("[yellow]Client information saved to filesystem only.[/yellow]")

        # Always save to filesystem for screenshot storage compatibility
        client_info_file = self.get_client_info_path(client_info.directory_name)
        client_info_file.write_text(client_info.model_dump_json(indent=2))
        console.print("[bold green]Client information saved to filesystem![/bold green]")

    def display_client_info(self, directory_name: str) -> None:
        """Display client information."""
        client_info = self.load_client_info_from_directory(directory_name)
        console.print("\n[bold]Client Information:[/bold]")
        console.print("------------------")
        console.print(f"Client: [bold]{client_info.client_name}[/bold]")
        console.print(f"Directory: {client_info.directory_name}")
        console.print(f"Company: {client_info.company_name}")
        console.print(f"Contact: {client_info.contact_name}")
        console.print(f"Email: {client_info.contact_email}")

        console.print("\n[bold]Preferences:[/bold]")
        console.print(
            f"Screenshot Delivery: {client_info.preferences.get('screenshot_delivery', 'local')}"
        )
        console.print(
            f"Notifications: {client_info.preferences.get('notification_preferences', 'all')}"
        )
        console.print(f"Reporting: {client_info.preferences.get('reporting_frequency', 'none')}")
        console.print(f"PDF Security: {client_info.preferences.get('pdf_security', 'none')}")
        if client_info.preferences.get("pdf_security") == "password" and client_info.pdf_password:
            console.print(f"PDF Password: {'*' * len(client_info.pdf_password)}")
        console.print(f"PDF Page Size: {client_info.preferences.get('page_size', 'A4')}")
        console.print(f"Last Updated: {client_info.last_updated}\n")

    def edit_client_info(self, directory_name: str) -> str:
        """Interactive editor for client information."""
        # This function is moved to cli.py since it's interactive
        from screenshooter.modules.clients.cli import edit_client_info_interactive

        return edit_client_info_interactive(self, directory_name)

    def migrate_client_data(self) -> int:
        """Migrate existing client data to the new schema with directory_name field."""
        clients = self.list_clients()
        migrated_count = 0

        for directory_name in clients:
            client_info_file = self.get_client_info_path(directory_name)

            if client_info_file.exists():
                try:
                    # Try to load the file content as JSON first
                    import json

                    data = json.loads(client_info_file.read_text())

                    # Check if fields are missing
                    needs_update = False

                    # Add directory_name field if missing
                    if "directory_name" not in data:
                        data["directory_name"] = directory_name
                        needs_update = True

                    # Add pdf_password field if missing
                    if "pdf_password" not in data:
                        data["pdf_password"] = ""
                        needs_update = True

                    # Add pdf_security preference if missing
                    if "preferences" in data and "pdf_security" not in data["preferences"]:
                        data["preferences"]["pdf_security"] = "none"
                        needs_update = True

                    # Add page_size preference if missing
                    if "preferences" in data and "page_size" not in data["preferences"]:
                        data["preferences"]["page_size"] = "A4"
                        needs_update = True

                    # Write back the updated data if any changes were made
                    if needs_update:
                        client_info_file.write_text(json.dumps(data, indent=2))
                        migrated_count += 1

                except Exception as e:
                    console.print(
                        f"[bold yellow]Warning: Could not migrate client data for '{directory_name}': {e}[/bold yellow]"
                    )

        if migrated_count > 0:
            console.print(
                f"[bold green]Successfully migrated {migrated_count} client(s) to the new format.[/bold green]"
            )

        return migrated_count

    def list_archived_clients(self) -> List[str]:
        """List all archived clients."""
        # Check if we should use database
        if should_use_database():
            try:
                from screenshooter.modules.database import DatabaseOperations

                db_ops = DatabaseOperations()
                archived_clients = db_ops.list_archived_clients()
                return [client.name for client in archived_clients if client.name]
            except Exception as e:
                logger.warning(f"Failed to get archived clients from database: {e}")
                return []

        # Log files/filesystem - check for archived flag in client_info.json
        archived_clients = []
        for directory in self.base_dir.iterdir():
            if directory.is_dir() and (directory / "client_info.json").exists():
                try:
                    import json

                    client_info = json.loads((directory / "client_info.json").read_text())
                    if client_info.get("archived", False):
                        archived_clients.append(client_info.get("client_name", directory.name))
                except (json.JSONDecodeError, IOError):
                    continue
        return archived_clients

    def archive_client(self, directory_name: str) -> bool:
        """Archive a client."""
        # Check if we should use database
        if should_use_database():
            try:
                from screenshooter.modules.database import DatabaseOperations

                db_ops = DatabaseOperations()

                # Get client by directory name or name
                client = db_ops.get_client_by_directory(directory_name)
                if not client:
                    client = db_ops.get_client_by_name(directory_name)

                if client and client.id:
                    success = db_ops.archive_client(client.id)
                    if success:
                        # Also update filesystem for consistency
                        self._update_filesystem_archive_status(
                            client.directory_name or directory_name, True
                        )
                    return success
                else:
                    console.print(
                        f"[bold red]Client '{directory_name}' not found in database.[/bold red]"
                    )
                    return False
            except Exception as e:
                logger.warning(
                    f"Failed to archive client in database, falling back to filesystem: {e}"
                )

        # Fallback to filesystem
        return self._update_filesystem_archive_status(directory_name, True)

    def unarchive_client(self, directory_name: str) -> bool:
        """Unarchive a client."""
        # Check if we should use database
        if should_use_database():
            try:
                from screenshooter.modules.database import DatabaseOperations

                db_ops = DatabaseOperations()

                # Get client by directory name or name
                client = db_ops.get_client_by_directory(directory_name)
                if not client:
                    client = db_ops.get_client_by_name(directory_name)

                if client and client.id:
                    success = db_ops.unarchive_client(client.id)
                    if success:
                        # Also update filesystem for consistency
                        self._update_filesystem_archive_status(
                            client.directory_name or directory_name, False
                        )
                    return success
                else:
                    console.print(
                        f"[bold red]Client '{directory_name}' not found in database.[/bold red]"
                    )
                    return False
            except Exception as e:
                logger.warning(
                    f"Failed to unarchive client in database, falling back to filesystem: {e}"
                )

        # Fallback to filesystem
        return self._update_filesystem_archive_status(directory_name, False)

    def _update_filesystem_archive_status(self, directory_name: str, archived: bool) -> bool:
        """Update archive status in filesystem client_info.json."""
        try:
            client_info_file = self.get_client_info_path(directory_name)
            if client_info_file.exists():
                import json

                client_info = json.loads(client_info_file.read_text())
                client_info["archived"] = archived
                client_info_file.write_text(json.dumps(client_info, indent=2))
                return True
            else:
                console.print(
                    f"[bold red]Client info file not found for '{directory_name}'.[/bold red]"
                )
                return False
        except Exception as e:
            console.print(f"[bold red]Failed to update archive status: {e}[/bold red]")
            return False

    def get_client_id_from_directory(self, directory_name: str) -> Optional[int]:
        """Get client ID from directory name."""
        if should_use_database():
            try:
                from screenshooter.modules.database import DatabaseOperations

                db_ops = DatabaseOperations()
                client = db_ops.get_client_by_directory(directory_name)
                if not client:
                    client = db_ops.get_client_by_name(directory_name)
                return client.id if client else None
            except Exception as e:
                logger.warning(f"Failed to get client ID from database: {e}")
                return None
        return None

    def init_and_migrate(self) -> None:
        """Initialize client manager and migrate existing data."""
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self.migrate_client_data()

    def _get_project_dir(self, client_directory: str, project_directory: str) -> Path:
        """Return the path to a project's directory."""
        return self.base_dir / client_directory / project_directory

    def load_project_metadata(
        self, client_directory: str, project_directory: str
    ) -> ProjectMetadata:
        """Load project metadata from filesystem, with sensible defaults."""
        project_file = self._get_project_dir(client_directory, project_directory) / "project.json"

        if project_file.exists():
            try:
                return ProjectMetadata.model_validate_json(project_file.read_text())
            except Exception as exc:  # noqa: BLE001 - user-facing message already handled
                console.print(f"[bold red]Error loading project metadata: {exc}[/bold red]")

        return ProjectMetadata(
            project_name=project_directory,
            directory_name=project_directory,
            client_name=client_directory,
        )

    def save_project_metadata(self, metadata: ProjectMetadata) -> bool:
        """Persist project metadata to filesystem."""
        try:
            metadata.last_updated = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            project_dir = self._get_project_dir(metadata.client_name, metadata.directory_name)
            project_dir.mkdir(parents=True, exist_ok=True)
            project_file = project_dir / "project.json"
            project_file.write_text(metadata.model_dump_json(indent=2))
            return True
        except Exception as exc:  # noqa: BLE001 - user-facing message already handled
            console.print(f"[bold red]Failed to save project metadata: {exc}[/bold red]")
            return False

    def update_project_display_name(
        self, client_directory: str, project_directory: str, new_name: str
    ) -> bool:
        """Update the display name for a project in project.json."""
        metadata = self.load_project_metadata(client_directory, project_directory)
        metadata.project_name = new_name
        if not metadata.directory_name:
            metadata.directory_name = project_directory
        if not metadata.client_name:
            metadata.client_name = client_directory
        return self.save_project_metadata(metadata)

    def update_project_archive_status(
        self, client_directory: str, project_directory: str, archived: bool
    ) -> bool:
        """Set archived status for a project in project.json."""
        metadata = self.load_project_metadata(client_directory, project_directory)
        if archived:
            timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            metadata.archived_at = metadata.archived_at or timestamp
            if not metadata.finished_at:
                metadata.finished_at = timestamp
        else:
            metadata.archived_at = ""
            metadata.finished_at = ""
        return self.save_project_metadata(metadata)

    def append_project_log(
        self, client_directory: str, project_directory: str, message: str
    ) -> None:
        """Append a timestamped entry to the project's log file."""
        project_dir = self._get_project_dir(client_directory, project_directory)
        project_dir.mkdir(parents=True, exist_ok=True)
        log_file = project_dir / f"{project_directory}_log.txt"
        log_file.touch(exist_ok=True)
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(log_file, "a", encoding="utf-8") as handle:
            handle.write(f"[{timestamp}] {message}\n")
