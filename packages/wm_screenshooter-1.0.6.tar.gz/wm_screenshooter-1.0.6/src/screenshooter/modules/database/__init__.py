#!/usr/bin/env python3
"""Database module for ScreenShooter Mac.

This module provides SQLite database functionality to track clients, projects,
sessions, screenshots, notes, and captions alongside existing file logging.
"""

from .database import (
    DatabaseManager,
    get_database_manager,
    get_default_database_path,
    get_legacy_database_path,
)
from .migration_models import AppliedMigration, Migration, MigrationStatus
from .migration_runner import MigrationRunner
from .migrations import DatabaseMigrator, LogFileParser
from .models import (
    DatabaseClient,
    DatabaseNote,
    DatabaseNoteType,
    DatabaseProject,
    DatabaseScreenshot,
    DatabaseSession,
)
from .operations import DatabaseOperations

__all__ = [
    "DatabaseClient",
    "DatabaseManager",
    "DatabaseMigrator",
    "DatabaseNote",
    "DatabaseNoteType",
    "DatabaseOperations",
    "DatabaseProject",
    "DatabaseScreenshot",
    "DatabaseSession",
    "LogFileParser",
    "get_database_manager",
    "get_default_database_path",
    "get_legacy_database_path",
]
