#!/usr/bin/env python3
"""Database migration utilities for ScreenShooter Mac.

Provides functionality to migrate existing log file data to the SQLite database.
"""

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .models import (
    DatabaseClient,
    DatabaseNote,
    DatabaseNoteType,
    DatabaseProject,
    DatabaseScreenshot,
    DatabaseSession,
)
from .operations import DatabaseOperations


class LogFileParser:
    """Parses existing log files to extract session data."""

    def __init__(self, log_file_path: Path):
        """Initialize parser with log file path.

        Args:
            log_file_path: Path to log file
        """
        self.log_file_path = log_file_path

    def parse_session_log(self) -> Dict[str, Any]:
        """Parse session log file and extract structured data.

        Returns:
            Dictionary containing parsed session data
        """
        if not self.log_file_path.exists():
            return {}

        content = self.log_file_path.read_text()
        lines = content.strip().split("\n")

        session_data = {"screenshots": [], "notes": [], "captions": {}, "session_info": {}}

        # Parse session info from session.json if it exists
        session_json_path = self.log_file_path.parent / "session.json"
        if session_json_path.exists():
            try:
                session_info = json.loads(session_json_path.read_text())
                session_data["session_info"] = session_info
            except json.JSONDecodeError:
                pass

        # Parse log entries
        for line in lines:
            if not line.strip():
                continue

            # Parse timestamp and message
            timestamp_match = re.match(r"^\[([^\]]+)\] (.+)$", line)
            if not timestamp_match:
                continue

            timestamp_str, message = timestamp_match.groups()
            try:
                timestamp = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S")
            except ValueError:
                continue

            # Parse different types of log entries
            if "Screenshot saved:" in message:
                screenshot_data = self._parse_screenshot_entry(message, timestamp)
                if screenshot_data:
                    session_data["screenshots"].append(screenshot_data)

            elif message.startswith("NOTE: "):
                note_data = self._parse_note_entry(message, timestamp)
                if note_data:
                    session_data["notes"].append(note_data)

            elif message.startswith("SESSION START NOTE: "):
                content = message[len("SESSION START NOTE: ") :].strip()
                if content:
                    session_data["notes"].append(
                        {
                            "content": content,
                            "timestamp": timestamp,
                            "note_type": DatabaseNoteType.SESSION_START,
                        }
                    )

            elif message.startswith("SESSION PAUSED: "):
                content = message[len("SESSION PAUSED: ") :].strip()
                if content:
                    session_data["notes"].append(
                        {
                            "content": content,
                            "timestamp": timestamp,
                            "note_type": DatabaseNoteType.PAUSE,
                        }
                    )

            elif message.startswith("Paused for "):
                session_data["notes"].append(
                    {
                        "content": message.strip(),
                        "timestamp": timestamp,
                        "note_type": DatabaseNoteType.RESUME,
                    }
                )

            elif message.startswith("SESSION RESUMED"):
                session_data["notes"].append(
                    {
                        "content": message.strip(),
                        "timestamp": timestamp,
                        "note_type": DatabaseNoteType.RESUME,
                    }
                )

            elif "CAPTION for screenshot set #" in message:
                caption_data = self._parse_caption_entry(message, timestamp)
                if caption_data:
                    set_id, content = caption_data
                    session_data["captions"][str(set_id)] = {
                        "content": content,
                        "timestamp": timestamp,
                    }

        return session_data

    def _parse_screenshot_entry(
        self, message: str, timestamp: datetime
    ) -> Optional[Dict[str, Any]]:
        """Parse screenshot log entry.

        Args:
            message: Log message
            timestamp: Entry timestamp

        Returns:
            Screenshot data dictionary or None
        """
        # Example: "Set #1 - Screenshot saved: /path/to/file.jpg (all)"
        match = re.search(r"Set #(\d+) - Screenshot saved: (.+?) \((.+?)\)", message)
        if match:
            set_id, file_path, suffix = match.groups()
            return {
                "set_id": int(set_id),
                "file_path": file_path.strip(),
                "suffix": suffix.strip(),
                "timestamp": timestamp,
            }
        return None

    def _parse_note_entry(self, message: str, timestamp: datetime) -> Optional[Dict[str, Any]]:
        """Parse note log entry.

        Args:
            message: Log message
            timestamp: Entry timestamp

        Returns:
            Note data dictionary or None
        """
        # Example: "NOTE: This is a note"
        content = message[6:].strip()  # Remove "NOTE: " prefix
        if content:
            return {"content": content, "timestamp": timestamp}
        return None

    def _parse_caption_entry(self, message: str, timestamp: datetime) -> Optional[Tuple[int, str]]:
        """Parse caption log entry.

        Args:
            message: Log message
            timestamp: Entry timestamp

        Returns:
            Tuple of (set_id, content) or None
        """
        # Example: "CAPTION for screenshot set #1: This is a caption"
        match = re.search(r"CAPTION for screenshot set #(\d+): (.+)", message)
        if match:
            set_id, content = match.groups()
            return int(set_id), content.strip()
        return None


class DatabaseMigrator:
    """Migrates existing log file data to database."""

    def __init__(self, db_operations: DatabaseOperations):
        """Initialize migrator with database operations.

        Args:
            db_operations: Database operations instance
        """
        self.db_ops = db_operations

    def _load_image_relocations(self, project_dir: Path) -> Dict[str, str]:
        """Load image relocation mappings from project directory.

        Args:
            project_dir: Project directory path

        Returns:
            Dictionary mapping original paths to relocated paths
        """
        relocation_lookup = {}
        relocation_log_path = project_dir / "image_relocation_log.json"

        if relocation_log_path.exists():
            try:
                with open(relocation_log_path) as f:
                    relocations = json.load(f)

                for entry in relocations:
                    original_path = entry.get("original_path")
                    found_path = entry.get("found_path")
                    if original_path and found_path:
                        relocation_lookup[original_path] = found_path

                print(
                    f"Loaded {len(relocation_lookup)} image relocations from {relocation_log_path}"
                )

            except Exception as e:
                print(f"Error loading image relocations: {e}")

        return relocation_lookup

    def migrate_client_data(self, base_dir: Path) -> Dict[str, int]:
        """Migrate all client data from file structure to database.

        Args:
            base_dir: Base screenshots directory

        Returns:
            Dictionary mapping client directory names to database IDs
        """
        client_mappings = {}

        for client_dir in base_dir.iterdir():
            if not client_dir.is_dir():
                continue

            client_info_file = client_dir / "client.json"
            if not client_info_file.exists():
                continue

            try:
                client_info = json.loads(client_info_file.read_text())

                # Check if client already exists
                existing_client = self.db_ops.get_client_by_directory(client_dir.name)
                if existing_client:
                    client_mappings[client_dir.name] = existing_client.id
                    continue

                # Create new client record
                db_client = DatabaseClient(
                    name=client_info.get("client_name", client_dir.name),
                    directory_name=client_dir.name,
                    company_name=client_info.get("company_name", ""),
                    contact_name=client_info.get("contact_name", ""),
                    contact_email=client_info.get("contact_email", ""),
                    pdf_password=client_info.get("pdf_password", ""),
                    preferences=client_info.get("preferences", {}),
                )

                client_id = self.db_ops.create_client(db_client)
                client_mappings[client_dir.name] = client_id

            except (json.JSONDecodeError, Exception):
                # Skip problematic client directories
                continue

        return client_mappings

    def migrate_project_data(
        self, base_dir: Path, client_mappings: Dict[str, int]
    ) -> Dict[str, int]:
        """Migrate project data for all clients.

        Args:
            base_dir: Base screenshots directory
            client_mappings: Client directory name to ID mapping

        Returns:
            Dictionary mapping project paths to database IDs
        """
        project_mappings = {}

        for client_dir_name, client_id in client_mappings.items():
            client_dir = base_dir / client_dir_name

            # Check for archive directory
            archive_dir = client_dir / "archive"
            regular_projects = []
            archived_projects = []

            # Process regular project directories
            for project_dir in client_dir.iterdir():
                if not project_dir.is_dir() or project_dir.name == "archive":
                    continue

                sessions_dir = project_dir / "sessions"
                if not sessions_dir.exists():
                    continue

                regular_projects.append(project_dir)

            # Process archived project directories if archive directory exists
            if archive_dir.exists() and archive_dir.is_dir():
                for project_dir in archive_dir.iterdir():
                    if not project_dir.is_dir():
                        continue

                    sessions_dir = project_dir / "sessions"
                    if not sessions_dir.exists():
                        continue

                    archived_projects.append(project_dir)

            # Process regular projects (archive = 0)
            for project_dir in regular_projects:
                # Check if project already exists
                existing_project = self.db_ops.get_project_by_name(client_id, project_dir.name)
                if existing_project:
                    project_mappings[str(project_dir)] = existing_project.id
                    continue

                # Create new project record
                db_project = DatabaseProject(
                    client_id=client_id,
                    name=project_dir.name,
                    directory_name=project_dir.name,
                    active=True,
                )

                project_id = self.db_ops.create_project(db_project)
                project_mappings[str(project_dir)] = project_id

            # Process archived projects (active = False)
            for project_dir in archived_projects:
                # Check if project already exists
                existing_project = self.db_ops.get_project_by_name(client_id, project_dir.name)
                if existing_project:
                    project_mappings[str(project_dir)] = existing_project.id
                    continue

                # Create new project record with active = False
                db_project = DatabaseProject(
                    client_id=client_id,
                    name=project_dir.name,
                    directory_name=project_dir.name,
                    active=False,
                )

                project_id = self.db_ops.create_project(db_project)
                project_mappings[str(project_dir)] = project_id

            # Process archived projects (archive = 1)
            for project_dir in archived_projects:
                # Check if project already exists
                existing_project = self.db_ops.get_project_by_name(client_id, project_dir.name)
                if existing_project:
                    project_mappings[str(project_dir)] = existing_project.id
                    continue

                # Create new project record with archive = 1
                db_project = DatabaseProject(
                    client_id=client_id,
                    name=project_dir.name,
                    directory_name=project_dir.name,
                    archive=1,
                )

                project_id = self.db_ops.create_project(db_project)
                project_mappings[str(project_dir)] = project_id

        return project_mappings

    def migrate_session_data(self, base_dir: Path, project_mappings: Dict[str, int]) -> None:
        """Migrate session data for all projects.

        Args:
            base_dir: Base screenshots directory
            project_mappings: Project path to ID mapping
        """
        for project_path, project_id in project_mappings.items():
            project_dir = Path(project_path)
            sessions_dir = project_dir / "sessions"

            if not sessions_dir.exists():
                continue

            for session_dir in sessions_dir.iterdir():
                if not session_dir.is_dir():
                    continue

                self._migrate_single_session(session_dir, project_id)

    def _migrate_single_session(self, session_dir: Path, project_id: int) -> None:
        """Migrate a single session directory.

        Args:
            session_dir: Session directory path
            project_id: Project database ID
        """
        # Parse session log
        log_file = session_dir / "session.log"
        parser = LogFileParser(log_file)
        session_data = parser.parse_session_log()

        if not session_data:
            return

        # Load image relocation data if available
        project_dir = session_dir.parent.parent
        relocation_lookup = self._load_image_relocations(project_dir)

        # Apply relocations to screenshot paths
        for screenshot in session_data.get("screenshots", []):
            original_path = screenshot["file_path"]
            if original_path in relocation_lookup:
                screenshot["file_path"] = relocation_lookup[original_path]
                print(f"Applied relocation: {original_path} -> {screenshot['file_path']}")

        # Extract session info from ``session.json`` if available
        session_info = session_data.get("session_info", {})

        # For database compatibility we always use the session directory name
        # (timestamp string) as the session ``name``. This is what the live
        # screenshot module uses when creating DB-backed sessions and what the
        # reports module expects when looking sessions up.
        session_name = session_dir.name

        # Parse start time from legacy JSON, falling back to now if missing.
        start_time_raw = session_info.get("session_start_time")
        if isinstance(start_time_raw, str):
            try:
                start_time = datetime.strptime(start_time_raw, "%Y-%m-%d_%H-%M-%S")
            except ValueError:
                start_time = datetime.now()
        else:
            start_time = datetime.now()

        # ``timer`` in the legacy ``session.json`` can be stored as an int
        # (e.g. 5) or a string; normalize to a string for ``timer_mode``.
        raw_timer = session_info.get("timer")
        timer_mode: Optional[str]
        if raw_timer is None:
            timer_mode = None
        else:
            timer_mode = str(raw_timer)

        # Check if session already exists
        existing_session = self.db_ops.get_session_by_name(project_id, session_name)
        if existing_session:
            session_id = existing_session.id
            session_start_for_duration = existing_session.start_time
            session_timer_mode_for_update = existing_session.timer_mode
        else:
            # Create new session record
            db_session = DatabaseSession(
                project_id=project_id,
                name=session_name,
                start_time=start_time,
                timer_mode=timer_mode,
            )

            session_id = self.db_ops.create_session(db_session)
            session_start_for_duration = start_time
            session_timer_mode_for_update = timer_mode

            # If a session_note exists in session info (older format), store it as a
            # SESSION_START note
            session_note_text = session_info.get("session_note")
            if session_note_text:
                db_session_note = DatabaseNote(
                    session_id=session_id,
                    content=session_note_text,
                    note_type=DatabaseNoteType.SESSION_START,
                    timestamp=start_time,
                )
                self.db_ops.create_note(db_session_note)

        # Migrate screenshots, notes, and captions
        if session_id is not None:
            # Track all event timestamps so we can infer an end time and duration.
            event_timestamps: List[datetime] = []

            for screenshot_data in session_data.get("screenshots", []):
                event_timestamps.append(screenshot_data["timestamp"])
                db_screenshot = DatabaseScreenshot(
                    session_id=session_id,
                    set_id=screenshot_data["set_id"],
                    file_path=screenshot_data["file_path"],
                    timestamp=screenshot_data["timestamp"],
                    suffix=screenshot_data.get("suffix", ""),
                    # Legacy logs do not explicitly store display_mode, so we
                    # approximate by using the parsed suffix (e.g. "all",
                    # "main") as the display_mode as well.
                    display_mode=screenshot_data.get("suffix", ""),
                )
                self.db_ops.create_screenshot(db_screenshot)

            # Migrate notes
            for note_data in session_data.get("notes", []):
                event_timestamps.append(note_data["timestamp"])
                db_note = DatabaseNote(
                    session_id=session_id,
                    content=note_data["content"],
                    note_type=note_data.get("note_type", DatabaseNoteType.NOTE),
                    timestamp=note_data["timestamp"],
                )
                self.db_ops.create_note(db_note)

            # Migrate captions as notes with CAPTION type
            for set_id_str, caption_data in session_data.get("captions", {}).items():
                content = caption_data["content"]
                timestamp = caption_data["timestamp"]
                event_timestamps.append(timestamp)
                db_caption_note = DatabaseNote(
                    session_id=session_id,
                    content=f"[set #{set_id_str}] {content}",
                    note_type=DatabaseNoteType.CAPTION,
                    timestamp=timestamp,
                )
                self.db_ops.create_note(db_caption_note)

            # Infer basic end_time and duration from the last event in the
            # session so reports have useful timings.
            if event_timestamps:
                end_time = max(event_timestamps)
                duration_seconds = int((end_time - session_start_for_duration).total_seconds())
                try:
                    updated_session = DatabaseSession(
                        id=session_id,
                        project_id=project_id,
                        name=session_name,
                        start_time=session_start_for_duration,
                        end_time=end_time,
                        duration_seconds=duration_seconds,
                        timer_mode=session_timer_mode_for_update,
                    )
                    self.db_ops.update_session(updated_session)
                except Exception:
                    # If anything goes wrong here, we still keep the migrated
                    # screenshots/notes; timing info is nice-to-have.
                    pass

    def migrate_all_data(self, base_dir: Optional[Path] = None) -> None:
        """Migrate all existing data from file structure to database.

        Args:
            base_dir: Base screenshots directory. If None, uses settings.
        """
        if base_dir is None:
            from screenshooter.modules.settings.settings_helper import get_screenshots_dir

            base_dir = Path(get_screenshots_dir())

        print(f"Migrating data from {base_dir} to database...")

        # Migrate clients
        print("Migrating clients...")
        client_mappings = self.migrate_client_data(base_dir)
        print(f"Migrated {len(client_mappings)} clients")

        # Migrate projects
        print("Migrating projects...")
        project_mappings = self.migrate_project_data(base_dir, client_mappings)
        print(f"Migrated {len(project_mappings)} projects")

        # Migrate sessions
        print("Migrating sessions...")
        self.migrate_session_data(base_dir, project_mappings)
        print("Session migration completed")

        print("Data migration completed successfully!")
