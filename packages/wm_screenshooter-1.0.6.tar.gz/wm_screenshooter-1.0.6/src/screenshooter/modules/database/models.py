#!/usr/bin/env python3
"""Database models for ScreenShooter Mac.

Pydantic models that represent database entities for clients, projects,
sessions, screenshots, notes, and captions.
"""

from datetime import datetime
from typing import Dict, Optional

from pydantic import BaseModel, Field, field_validator


class DatabaseClient(BaseModel):
    """Database model for client information."""

    id: Optional[int] = None
    name: str
    directory_name: str
    company_name: str = ""
    contact_name: str = ""
    contact_email: str = ""
    pdf_password: str = ""
    preferences: Dict[str, str] = Field(default_factory=dict)
    # Timestamp when the client was archived; NULL means active
    archived_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @field_validator("preferences", mode="before")
    def parse_preferences(cls, v) -> Dict[str, str]:
        """Parse preferences from JSON string if needed."""
        if isinstance(v, str):
            import json

            try:
                return json.loads(v)
            except json.JSONDecodeError:
                return {}
        return v or {}


class DatabaseProject(BaseModel):
    """Database model for project information."""

    id: Optional[int] = None
    client_id: int
    name: str
    directory_name: str
    active: bool = True
    # Timestamp when the project was archived; NULL means active
    archived_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class DatabaseNoteType(str):
    """Enumeration for note types."""

    NOTE = "note"
    CAPTION = "caption"
    SESSION_START = "session_start"
    SESSION_END = "session_end"
    PAUSE = "pause"
    RESUME = "resume"


class DatabaseSession(BaseModel):
    """Database model for session information."""

    id: Optional[int] = None
    project_id: int
    name: str
    start_time: datetime
    end_time: Optional[datetime] = None
    duration_seconds: Optional[int] = None
    timer_mode: Optional[str] = None
    created_at: Optional[datetime] = None
    active: bool = True  # For soft delete/archive functionality
    # Timestamp when the session was archived; NULL means active
    archived_at: Optional[datetime] = None


class DatabaseScreenshot(BaseModel):
    """Database model for screenshot information."""

    id: Optional[int] = None
    session_id: int
    set_id: int
    file_path: str
    timestamp: datetime
    display_mode: Optional[str] = None
    suffix: Optional[str] = None
    active: bool = True
    # Timestamp when the screenshot was archived; NULL means active
    archived_at: Optional[datetime] = None
    created_at: Optional[datetime] = None


class DatabaseNote(BaseModel):
    """Database model for note information."""

    id: Optional[int] = None
    session_id: int
    content: str
    note_type: str = DatabaseNoteType.NOTE
    timestamp: datetime
    active: bool = True
    # Timestamp when the note was archived; NULL means active
    archived_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
