-- Migration: 002_add_active_columns.sql
-- Purpose: Add active columns to screenshots and notes tables for consistency
-- Description: Adds active BOOLEAN field to screenshots and notes tables to match existing schema pattern

BEGIN TRANSACTION;

-- Add active column to screenshots table
ALTER TABLE screenshots ADD COLUMN active BOOLEAN DEFAULT TRUE;

-- Add active column to notes table  
ALTER TABLE notes ADD COLUMN active BOOLEAN DEFAULT TRUE;

-- Create indexes for active fields for better query performance
CREATE INDEX IF NOT EXISTS idx_screenshots_active ON screenshots (active);
CREATE INDEX IF NOT EXISTS idx_notes_active ON notes (active);

-- Rollback: 
-- ALTER TABLE screenshots DROP COLUMN active;
-- ALTER TABLE notes DROP COLUMN active;
-- DROP INDEX IF EXISTS idx_screenshots_active;
-- DROP INDEX IF EXISTS idx_notes_active;

COMMIT;