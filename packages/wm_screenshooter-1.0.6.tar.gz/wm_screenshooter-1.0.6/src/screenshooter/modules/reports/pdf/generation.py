#!/usr/bin/env python3
"""PDF generation methods for the ReportGenerator class."""

import logging
import traceback
from datetime import datetime
from pathlib import Path

from reportlab.lib.units import inch
from reportlab.platypus import KeepTogether, PageBreak, Paragraph, Spacer, Table, TableStyle

from screenshooter.modules.reports.pdf.components import (
    add_report_title,
    add_section_header,
    add_subsection_header,
)
from screenshooter.modules.reports.pdf.helper import (
    add_screenshot,
    create_pdf_document,
    get_pdf_styles,
)
from screenshooter.modules.reports.pdf.tables import (
    add_client_info_table,
    add_session_summary_table,
)
from screenshooter.modules.reports.pdf.utils import handle_image_relocations

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("pdf_generation")


def generate_single_session_pdf(report_generator) -> Path:
    """Generate PDF report for a single session.

    Args:
        report_generator: The ReportGenerator instance

    Returns:
        Path to the generated PDF
    """
    # Create a list to track relocated images
    relocation_log = []

    if not report_generator.session_log:
        error_msg = "No session data loaded"
        report_generator.log_entry(error_msg, level="error")
        raise ValueError(error_msg)

    # Determine report title and filename
    project_name = (
        report_generator.project_name or report_generator.screenshots_dir.parent.parent.name
    )
    session_date = report_generator.session_date or report_generator.screenshots_dir.parent.name
    report_title = f"{project_name} - {session_date}"

    # Create PDF filename
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf_filename = f"{project_name}_Session_Report_{timestamp}.pdf"
    report_generator.pdf_file = report_generator.output_dir / pdf_filename

    report_generator.log_entry(f"Creating PDF at: {report_generator.pdf_file}", level="debug")

    # Create PDF document with optional password
    pdf_password = None
    if (
        report_generator.client_info
        and report_generator.client_info.preferences.get("pdf_security") == "password"
        and report_generator.client_info.pdf_password
    ):
        pdf_password = report_generator.client_info.pdf_password
        # Log to file only, suppress logger output during progress display
        report_generator.log_entry(
            "Applying password protection to PDF", level="info", suppress_logger=True
        )

    # Create the PDF document
    doc = create_pdf_document(
        output_path=report_generator.pdf_file,
        page_size=report_generator.page_size,
        compress_pdf=report_generator.compress_pdf,
        pdf_password=pdf_password,
    )

    # Get styles
    styles = get_pdf_styles()

    # Document content
    story = []

    # Title and subtitles using common components
    add_report_title(story, "Screenshot Session Report", styles)
    add_section_header(story, report_title, styles)

    # Client information (if available)
    if report_generator.client_info:
        add_client_info_table(
            story=story, client_info=report_generator.client_info.dict(), styles=styles
        )

    # Session summary
    add_section_header(story, "Session Summary", styles)

    if report_generator.session_log.session_start and report_generator.session_log.session_end:
        # Compute note count including:
        # - Standard notes
        # - Per-screenshot captions
        # - Per-set captions
        # - Session start note (if present)
        # - Caption-only events (from database)
        note_count = len(report_generator.session_log.notes)
        note_count += len(getattr(report_generator.session_log, "captions", {}))
        note_count += len(getattr(report_generator.session_log, "set_captions", {}))
        if report_generator.session_log.session_note:
            note_count += 1
        note_count += sum(
            1
            for e in getattr(report_generator.session_log, "chronological_events", [])
            if e.get("type") == "caption"
        )

        # Add session summary table
        add_session_summary_table(
            story=story,
            session_start=report_generator.session_log.session_start,
            session_end=report_generator.session_log.session_end,
            session_duration=report_generator.session_log.session_duration,
            screenshot_count=len(report_generator.session_log.screenshots),
            note_count=note_count,
            styles=styles,
        )

    # Session note
    if report_generator.session_log.session_note:
        add_section_header(story, "Session Notes", styles)
        story.append(Paragraph(report_generator.session_log.session_note, styles["Note"]))
        story.append(Spacer(1, 0.3 * inch))

    # Process screenshots by set
    current_set = None
    screenshot_count = 0
    # Find indices of all screenshots for easier lookahead
    screenshot_indices = [
        i
        for i, e in enumerate(report_generator.session_log.chronological_events)
        if e["type"] == "screenshot"
    ]
    for idx, event in enumerate(report_generator.session_log.chronological_events):
        if event["type"] == "screenshot":
            screenshot_count += 1
            set_id = event["set_id"]

            # Create a block for the screenshot content
            screenshot_block = []

            # If we're starting a new set, add header *inside* the block
            if set_id != current_set:
                if current_set is not None:
                    story.append(PageBreak())  # Page break before the new set block
                current_set = set_id
                screenshot_block.append(Paragraph(f"Set #{set_id}", styles["Heading3Bold"]))
                screenshot_block.append(Spacer(1, 0.1 * inch))

            screenshot_data = report_generator.session_log.screenshots[event["index"]]
            add_screenshot(
                target_story=screenshot_block,
                screenshot_data=screenshot_data,
                screenshot_num=screenshot_count,
                screenshots_dir=report_generator.screenshots_dir,
                captions=report_generator.session_log.captions,
                image_quality=report_generator.image_quality,
                image_dpi=report_generator.image_dpi,
                image_format=report_generator.image_format,
                max_dimension=report_generator.max_dimension,
                use_thumbnails=report_generator.use_thumbnails,
                thumbnail_size=report_generator.thumbnail_size,
                debug=report_generator.image_search_debug
                if hasattr(report_generator, "image_search_debug")
                else report_generator.debug,
                styles=styles,
                temp_files=report_generator.temp_files,
                client_base_dir=report_generator.client_dir,
                report_relocations=True,
                relocation_log=relocation_log,
                project_dir=report_generator.project_dir,
            )
            # Add the screenshot block wrapped in KeepTogether
            story.append(KeepTogether(screenshot_block))

            # Only after the last screenshot in a set, insert set caption
            is_last_screenshot = False
            if idx in screenshot_indices:
                this_set = set_id
                # Find the next screenshot event, if any
                next_screenshot_idx = None
                for j in screenshot_indices:
                    if j > idx:
                        next_screenshot_idx = j
                        break
                if (
                    next_screenshot_idx is None
                    or report_generator.session_log.chronological_events[next_screenshot_idx][
                        "set_id"
                    ]
                    != this_set
                ):
                    is_last_screenshot = True
            if is_last_screenshot:
                set_captions = getattr(report_generator.session_log, "set_captions", {})
                if set_captions and current_set:
                    set_id_int = None
                    try:
                        set_id_int = int(current_set)
                    except Exception:
                        pass
                    if set_id_int and set_id_int in set_captions:
                        _, set_caption = set_captions[set_id_int]
                        # Render caption directly beneath the set
                        story.append(
                            Paragraph(f"Caption: {set_caption}", styles["Caption"])
                        )
                        story.append(Spacer(1, 0.1 * inch))
        elif event["type"] == "note":
            # Standard note block
            story.append(Paragraph(f"Note at {event['timestamp']}:", styles["Heading3Bold"]))
            story.append(Paragraph(event["content"], styles["Note"]))
            story.append(Spacer(1, 0.2 * inch))
        elif event["type"] == "caption":
            # Caption-only entries (e.g., DB captions without set metadata)
            story.append(Paragraph(f"Caption: {event['content']}", styles["Caption"]))
            story.append(Spacer(1, 0.2 * inch))

    # Handle image relocations (without adding to PDF report)
    changes_saved = False  # Initialize to False by default
    if relocation_log:
        changes_saved = handle_image_relocations(report_generator, relocation_log)
        report_generator.log_entry(
            f"Processed {len(relocation_log)} image relocations (changes: {changes_saved})",
            level="debug",
        )

    # Build the PDF
    try:
        doc.build(story)
        report_generator.log_entry(
            f"PDF report generated successfully: {report_generator.pdf_file}",
            terminal_message="",
        )
        return report_generator.pdf_file
    except Exception as e:
        error_msg = f"Error building PDF: {e}"
        report_generator.log_entry(error_msg, level="error")
        if report_generator.debug:
            report_generator.log_entry(f"Stack trace: {traceback.format_exc()}", level="debug")
        raise


def generate_multi_session_pdf(report_generator) -> Path:
    """Generate PDF report for multiple sessions (day or project).

    Args:
        report_generator: The ReportGenerator instance

    Returns:
        Path to the generated PDF
    """
    # Create a list to track relocated images
    relocation_log = []

    if not report_generator.multi_sessions:
        error_msg = "No multi-session data loaded"
        report_generator.log_entry(error_msg, level="error")
        raise ValueError(error_msg)

    # Determine report title and filename
    project_name = report_generator.project_name
    if report_generator.report_type == "day":
        date_str = report_generator.specific_date or datetime.now().strftime("%Y-%m-%d")
        report_title = f"{project_name} - Day Report ({date_str})"
        report_type_str = "Day"
    else:  # project
        report_title = f"{project_name} - Project Report"
        report_type_str = "Project"

    # Create PDF filename
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf_filename = f"{project_name}_{report_type_str}_Report_{timestamp}.pdf"
    report_generator.pdf_file = report_generator.output_dir / pdf_filename

    report_generator.log_entry(f"Creating PDF at: {report_generator.pdf_file}", level="debug")

    # Create PDF document with optional password
    pdf_password = None
    if (
        report_generator.client_info
        and report_generator.client_info.preferences.get("pdf_security") == "password"
        and report_generator.client_info.pdf_password
    ):
        pdf_password = report_generator.client_info.pdf_password
        # Log to file only, suppress logger output during progress display
        report_generator.log_entry(
            "Applying password protection to PDF", level="info", suppress_logger=True
        )

    # Create the PDF document
    doc = create_pdf_document(
        output_path=report_generator.pdf_file,
        page_size=report_generator.page_size,
        compress_pdf=report_generator.compress_pdf,
        pdf_password=pdf_password,
    )

    # Get styles
    styles = get_pdf_styles()

    # Document content
    story = []

    # Title and subtitles using common components
    if report_generator.report_type == "day":
        add_report_title(story, "Screenshot Day Report", styles)
    else:  # project
        add_report_title(story, "Screenshot Project Report", styles)
    add_section_header(story, report_title, styles)

    # Client information (if available)
    if report_generator.client_info:
        add_client_info_table(
            story=story, client_info=report_generator.client_info.dict(), styles=styles
        )

    # Summary statistics
    stats = report_generator.multi_sessions.get_combined_stats()
    add_section_header(story, "Report Summary", styles)

    # Create summary data table
    summary_data = [
        ["Total Sessions", str(stats["total_sessions"])],
        ["Total Screenshots", str(stats["total_screenshots"])],
        ["Total Notes", str(stats["total_notes"])],
        ["Total Duration", stats["formatted_total_duration"]],
    ]

    if report_generator.report_type == "project":
        summary_data.insert(1, ["Days Covered", str(stats["days_covered"])])

    if stats["earliest_session_str"]:
        summary_data.append(["First Session", stats["earliest_session_str"]])
    if stats["latest_session_str"]:
        summary_data.append(["Last Session", stats["latest_session_str"]])

    # Create and add the summary table
    summary_table = Table(summary_data, colWidths=[2 * inch, 3 * inch])
    summary_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (0, -1), styles["Heading3Bold"].backColor),
                ("TEXTCOLOR", (0, 0), (0, -1), styles["Heading3Bold"].textColor),
                ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                ("FONTNAME", (1, 0), (1, -1), "Helvetica"),
                ("FONTSIZE", (0, 0), (-1, -1), 10),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("GRID", (0, 0), (-1, -1), 0.5, styles["Heading3Bold"].textColor),
            ]
        )
    )
    story.append(summary_table)
    story.append(Spacer(1, 0.3 * inch))

    # Process sessions by day
    for day, sessions in sorted(report_generator.multi_sessions.sessions_by_day.items()):
        # Add day header
        story.append(Paragraph(f"Day: {day}", styles["DayHeader"]))
        story.append(Spacer(1, 0.1 * inch))

        # Process each session for this day
        for session_dir in sessions:
            session_name = session_dir.name
            session_time = session_name.split("_")[1].replace("-", ":")

            # Get session log
            session_log = report_generator.multi_sessions.session_logs.get(session_name)
            if not session_log:
                report_generator.log_entry(
                    f"Session log for {session_name} not loaded", level="warning"
                )
                continue

            # Add session header
            add_subsection_header(story, f"Session: {session_time}", styles)

            # Add session summary if we have start/end times
            if session_log.session_start and session_log.session_end:
                # Compute note count including:
                # - Standard notes
                # - Per-screenshot captions
                # - Per-set captions
                # - Session start note (if present)
                # - Caption-only events (from database)
                note_count = len(session_log.notes)
                note_count += len(getattr(session_log, "captions", {}))
                note_count += len(getattr(session_log, "set_captions", {}))
                if session_log.session_note:
                    note_count += 1
                note_count += sum(
                    1
                    for e in getattr(session_log, "chronological_events", [])
                    if e.get("type") == "caption"
                )

                add_session_summary_table(
                    story=story,
                    session_start=session_log.session_start,
                    session_end=session_log.session_end,
                    session_duration=session_log.session_duration,
                    screenshot_count=len(session_log.screenshots),
                    note_count=note_count,
                    styles=styles,
                )

            # Session note
            if session_log.session_note:
                story.append(Paragraph("Session Note:", styles["Heading3Bold"]))
                story.append(Paragraph(session_log.session_note, styles["Note"]))
                story.append(Spacer(1, 0.2 * inch))

            # Process screenshots for this session
            # For database sessions, screenshots are stored with absolute paths
            # For log file sessions, use the session's screenshots directory
            if str(session_dir).startswith("/mock_sessions/"):
                # Database session - use project screenshots directory
                screenshots_dir = report_generator.screenshots_dir
            else:
                # Log file session - use traditional session subdirectory
                screenshots_dir = session_dir / "screenshots"
            current_set = None
            screenshot_count = 0

            # Find indices of all screenshots for easier lookahead
            screenshot_indices = [
                i
                for i, e in enumerate(session_log.chronological_events)
                if e["type"] == "screenshot"
            ]

            for idx, event in enumerate(session_log.chronological_events):
                if event["type"] == "screenshot":
                    screenshot_count += 1
                    set_id = event["set_id"]

                    # Create a block for the screenshot content
                    screenshot_block = []

                    # If we're starting a new set, add header *inside* the block
                    if set_id != current_set:
                        if current_set is not None:
                            # For multi-session reports, don't add a page break between sets
                            # as we want to keep sessions together
                            story.append(Spacer(1, 0.3 * inch))
                        current_set = set_id
                        if set_id:  # Only add set header if set exists
                            screenshot_block.append(
                                Paragraph(f"Set #{set_id}", styles["Heading3Bold"])
                            )
                            screenshot_block.append(Spacer(1, 0.1 * inch))

                    screenshot_data = session_log.screenshots[event["index"]]
                    add_screenshot(
                        target_story=screenshot_block,
                        screenshot_data=screenshot_data,
                        screenshot_num=screenshot_count,
                        screenshots_dir=screenshots_dir,
                        captions=session_log.captions,
                        image_quality=report_generator.image_quality,
                        image_dpi=report_generator.image_dpi,
                        image_format=report_generator.image_format,
                        max_dimension=report_generator.max_dimension,
                        use_thumbnails=report_generator.use_thumbnails,
                        thumbnail_size=report_generator.thumbnail_size,
                        debug=report_generator.image_search_debug
                        if hasattr(report_generator, "image_search_debug")
                        else report_generator.debug,
                        styles=styles,
                        temp_files=report_generator.temp_files,
                        client_base_dir=report_generator.client_dir,
                        report_relocations=True,
                        relocation_log=relocation_log,
                        project_dir=report_generator.project_dir,
                    )
                    # Add the screenshot block wrapped in KeepTogether
                    story.append(KeepTogether(screenshot_block))

                    # Only after the last screenshot in a set, insert set caption
                    is_last_screenshot = False
                    if idx in screenshot_indices:
                        this_set = set_id
                        # Find the next screenshot event, if any
                        next_screenshot_idx = None
                        for j in screenshot_indices:
                            if j > idx:
                                next_screenshot_idx = j
                                break
                        if (
                            next_screenshot_idx is None
                            or session_log.chronological_events[next_screenshot_idx]["set_id"]
                            != this_set
                        ):
                            is_last_screenshot = True
                    if is_last_screenshot and set_id:
                        set_captions = getattr(session_log, "set_captions", {})
                        if set_captions and current_set:
                            set_id_int = None
                            try:
                                set_id_int = int(current_set)
                            except Exception:
                                pass
                            if set_id_int and set_id_int in set_captions:
                                _, set_caption = set_captions[set_id_int]
                                # Render caption directly beneath the set
                                story.append(
                                    Paragraph(f"Caption: {set_caption}", styles["Caption"])
                                )
                                story.append(Spacer(1, 0.1 * inch))
                elif event["type"] == "note":
                    # Standard note block
                    story.append(
                        Paragraph(f"Note at {event['timestamp']}:", styles["Heading3Bold"])
                    )
                    story.append(Paragraph(event["content"], styles["Note"]))
                    story.append(Spacer(1, 0.2 * inch))
                elif event["type"] == "caption":
                    # Caption-only entries (e.g., DB captions without set metadata)
                    story.append(Paragraph(f"Caption: {event['content']}", styles["Caption"]))
                    story.append(Spacer(1, 0.2 * inch))

            # Add a page break after each session except the last one in the last day
            if not (
                day == list(sorted(report_generator.multi_sessions.sessions_by_day.keys()))[-1]
                and session_dir == sessions[-1]
            ):
                story.append(PageBreak())

    # Handle image relocations (without adding to PDF report)
    changes_saved = False  # Initialize to False by default
    if relocation_log:
        changes_saved = handle_image_relocations(report_generator, relocation_log)
        report_generator.log_entry(
            f"Processed {len(relocation_log)} image relocations (changes: {changes_saved})",
            level="debug",
        )

    # Build the PDF
    try:
        doc.build(story)
        report_generator.log_entry(
            f"PDF report generated successfully: {report_generator.pdf_file}",
            terminal_message="",
        )
        return report_generator.pdf_file
    except Exception as e:
        error_msg = f"Error building PDF: {e}"
        report_generator.log_entry(error_msg, level="error")
        if report_generator.debug:
            report_generator.log_entry(f"Stack trace: {traceback.format_exc()}", level="debug")
        raise
