#!/usr/bin/env python3
"""PDF generation helper functions for ScreenShooter Mac."""

import logging
import os
import tempfile
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Import reportlab for PDF generation
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, letter
from reportlab.lib.pdfencrypt import StandardEncryption
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    Image,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
)

# Try importing PIL with error handling
try:
    from PIL import Image as PILImage

    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    logging.warning("Pillow (PIL) not available. PDF optimization features will be limited.")

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("pdf_helper")


def get_pdf_styles():
    """Get the standard styles dictionary for PDF generation with custom styles added."""
    styles = getSampleStyleSheet()

    # Define custom styles
    custom_styles = {
        "Heading1Bold": ParagraphStyle(
            name="Heading1Bold",
            parent=styles["Heading1"],
            fontName="Helvetica-Bold",
            fontSize=18,
            spaceAfter=12,
        ),
        "Heading2Bold": ParagraphStyle(
            name="Heading2Bold",
            parent=styles["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=16,
            spaceAfter=10,
        ),
        "Heading3Bold": ParagraphStyle(
            name="Heading3Bold",
            parent=styles["Heading3"],
            fontName="Helvetica-Bold",
            fontSize=14,
            spaceAfter=8,
        ),
        "Caption": ParagraphStyle(
            name="Caption", fontName="Helvetica-Oblique", fontSize=10, leading=12, spaceAfter=12
        ),
        "Note": ParagraphStyle(
            name="Note",
            fontName="Helvetica",
            fontSize=12,
            backColor=colors.lightgrey,
            borderPadding=5,
            spaceAfter=12,
        ),
        "Timestamp": ParagraphStyle(
            name="Timestamp",
            fontName="Helvetica-Bold",
            fontSize=10,
            textColor=colors.darkblue,
            spaceAfter=4,
        ),
        "DayHeader": ParagraphStyle(
            name="DayHeader",
            fontName="Helvetica-Bold",
            fontSize=14,
            textColor=colors.darkblue,
            backColor=colors.lightgrey,
            borderPadding=5,
            spaceAfter=8,
        ),
    }

    # Add custom styles if they don't already exist
    for style_name, style in custom_styles.items():
        if style_name not in styles:
            styles.add(style)

    return styles


def optimize_image(
    img_path: Path,
    image_quality: int = 85,
    image_format: str = "JPEG",
    max_dimension: int = 1500,
    use_thumbnails: bool = False,
    thumbnail_size: int = 800,
    debug: bool = False,
) -> Optional[str]:
    """Optimize an image for PDF inclusion.

    Args:
        img_path: Path to the image file
        image_quality: JPEG quality (1-100)
        image_format: Format for optimized image (JPEG, PNG, WebP)
        max_dimension: Maximum dimension for resizing
        use_thumbnails: Whether to use small thumbnails
        thumbnail_size: Size for thumbnails
        debug: Enable debug logging

    Returns:
        Path to the temporary optimized image, or None if optimization failed
    """
    if not PIL_AVAILABLE:
        return None

    if not img_path.exists():
        return None

    try:
        # Process image with PIL to optimize it
        pil_img = PILImage.open(str(img_path))

        # Step 1: Resize if needed (keep aspect ratio)
        original_width, original_height = pil_img.size
        if use_thumbnails:
            # Use thumbnail size if thumbnails are enabled
            target_size = thumbnail_size
        else:
            # Otherwise use the max dimension setting
            target_size = max_dimension

        # Only resize if image is larger than target size
        if original_width > target_size or original_height > target_size:
            if original_width > original_height:
                new_width = target_size
                new_height = int(original_height * (target_size / original_width))
            else:
                new_height = target_size
                new_width = int(original_width * (target_size / original_height))

            pil_img = pil_img.resize((new_width, new_height), PILImage.LANCZOS)
            if debug:
                logger.debug(
                    f"Resized image from {original_width}x{original_height} to {new_width}x{new_height}"
                )

        # Step 2: Convert to preferred format and compress
        # Use chosen format or fallback to JPEG for best compression
        save_format = image_format
        save_params = {"quality": image_quality}

        # Handle special formats
        if save_format.upper() == "JPEG" and pil_img.mode == "RGBA":
            # Convert RGBA to RGB for JPEG format which doesn't support alpha
            pil_img = pil_img.convert("RGB")

        # Create a temporary file for the optimized image
        with tempfile.NamedTemporaryFile(
            delete=False, suffix=f".{save_format.lower()}"
        ) as temp_file:
            temp_path = temp_file.name

        # Save the optimized image to the temporary file
        pil_img.save(temp_path, format=save_format, **save_params)

        # Log compression stats if debug is enabled
        if debug:
            original_size = os.path.getsize(img_path)
            compressed_size = os.path.getsize(temp_path)
            compression_ratio = (1 - (compressed_size / original_size)) * 100
            logger.debug(
                f"Compressed image: {original_size} bytes -> {compressed_size} bytes ({compression_ratio:.1f}% reduction)"
            )

        return temp_path
    except Exception as e:
        logger.error(f"Error optimizing image {img_path}: {e}")
        return None


def create_pdf_document(
    output_path: Path,
    page_size: str = "A4",
    compress_pdf: bool = True,
    pdf_password: Optional[str] = None,
) -> SimpleDocTemplate:
    """Create a PDF document with the specified settings.

    Args:
        output_path: Path where the PDF will be saved
        page_size: Page size (A4, letter)
        compress_pdf: Whether to compress the PDF
        pdf_password: Optional password for PDF encryption

    Returns:
        SimpleDocTemplate with the configured settings
    """
    # Determine page size
    pdf_page_size = A4
    if page_size == "letter":
        pdf_page_size = letter

    # Create document with encryption if needed
    if pdf_password:
        encryption = StandardEncryption(pdf_password, canPrint=1, canModify=0, canCopy=0)
        doc = SimpleDocTemplate(
            str(output_path),
            pagesize=pdf_page_size,
            rightMargin=0.5 * inch,
            leftMargin=0.5 * inch,
            topMargin=0.5 * inch,
            bottomMargin=0.5 * inch,
            compress=compress_pdf,
            encrypt=encryption,
        )
    else:
        doc = SimpleDocTemplate(
            str(output_path),
            pagesize=pdf_page_size,
            rightMargin=0.5 * inch,
            leftMargin=0.5 * inch,
            topMargin=0.5 * inch,
            bottomMargin=0.5 * inch,
            compress=compress_pdf,
        )

    return doc


def find_image_path(
    screenshot_path: str,
    screenshots_dir: Path,
    client_base_dir: Path = None,
    debug: bool = False,
    report_relocation: bool = True,
    project_dir: Path = None,
) -> tuple[Optional[Path], Optional[dict]]:
    """Find the actual image path from the screenshot path in the log.

    This handles relocations and different path formats.

    Args:
        screenshot_path: Path from log entry
        screenshots_dir: Base directory for screenshots
        client_base_dir: Optional base client directory
        debug: Enable debug logging
        report_relocation: Whether to track relocations
        project_dir: Optional project directory for caching lookups

    Returns:
        Tuple of (found path or None, relocation info or None)
    """
    if debug:
        logger.debug(f"Looking for image: {screenshot_path}")
        logger.debug(f"Base screenshots dir: {screenshots_dir}")

    # Check if path is absolute or relative
    path_obj = Path(screenshot_path)

    # Try direct lookup first
    # 1. Try the exact path from the log
    if path_obj.exists():
        if debug:
            logger.debug(f"Found image at exact path: {path_obj}")
        return path_obj, None

    # 2. Try relative to screenshots dir
    rel_path = screenshots_dir / path_obj.name
    if rel_path.exists():
        if debug:
            logger.debug(f"Found image in screenshots dir: {rel_path}")

        if report_relocation:
            return rel_path, {
                "original_path": str(screenshot_path),
                "found_path": str(rel_path),
                "method": "screenshots_dir",
            }
        return rel_path, None

    # 3. Try relative to client base dir if provided
    if client_base_dir:
        # Try to find the image in client directory structure
        # This handles cases where images might have been moved to different projects
        if debug:
            logger.debug(f"Searching in client base dir: {client_base_dir}")

        # First check image relocation cache if we have project dir
        relocation_info = None
        if project_dir and report_relocation:
            relocation_log_path = project_dir / "image_relocation_log.json"
            if relocation_log_path.exists():
                try:
                    import json

                    with open(relocation_log_path) as f:
                        relocations = json.load(f)

                    # Check if this image is in the cache
                    for entry in relocations:
                        if entry.get("original_path") == str(screenshot_path):
                            found_path = Path(entry.get("found_path"))
                            if found_path.exists():
                                if debug:
                                    logger.debug(
                                        f"Found image using relocation cache: {found_path}"
                                    )
                                # Return the cached path with a marker that it came from cache
                                entry_with_cache_marker = entry.copy()
                                entry_with_cache_marker["from_cache"] = True
                                return found_path, entry_with_cache_marker
                except Exception as e:
                    if debug:
                        logger.debug(f"Error checking relocation cache: {e}")

        # Search in the client directory structure
        for root, _, files in os.walk(client_base_dir):
            root_path = Path(root)

            # Check for the filename in this directory
            if path_obj.name in files:
                found_path = root_path / path_obj.name
                if debug:
                    logger.debug(f"Found image in client tree: {found_path}")

                if report_relocation:
                    return found_path, {
                        "original_path": str(screenshot_path),
                        "found_path": str(found_path),
                        "method": "client_tree_search",
                    }
                return found_path, None

    if debug:
        logger.debug(f"Image not found: {screenshot_path}")

    return None, None


def add_screenshot(
    target_story: List,
    screenshot_data: Tuple,
    screenshot_num: int,
    screenshots_dir: Path,
    captions: Dict[int, Tuple[str, str]],
    image_quality: int = 85,
    image_dpi: int = 150,
    image_format: str = "JPEG",
    max_dimension: int = 1500,
    use_thumbnails: bool = False,
    thumbnail_size: int = 800,
    debug: bool = False,
    styles: Dict = None,
    temp_files: List[str] = None,
    client_base_dir: Path = None,
    report_relocations: bool = True,
    relocation_log: List = None,
    project_dir: Path = None,
) -> None:
    """Add a screenshot to the PDF story.

    Args:
        target_story: The story list to append to
        screenshot_data: Tuple containing (timestamp, path, set_id, suffix)
        screenshot_num: Screenshot number
        screenshots_dir: Directory where screenshots are stored
        captions: Dictionary of screenshot captions
        image_quality: JPEG quality for compression
        image_dpi: DPI for images
        image_format: Format for image conversion
        max_dimension: Maximum dimension for images
        use_thumbnails: Whether to use small thumbnails
        thumbnail_size: Size for thumbnails
        debug: Enable debug logging
        styles: Dictionary of paragraph styles
        temp_files: List to track temporary files
        client_base_dir: Base directory for client files
        report_relocations: Whether to track image relocations
        relocation_log: List to log image relocations
        project_dir: Project directory for caching relocations
    """
    if not styles:
        styles = get_pdf_styles()

    if not temp_files:
        temp_files = []

    if debug:
        logger.debug(f"Adding screenshot #{screenshot_num}: {screenshot_data}")

    # Extract data from the tuple
    timestamp, screenshot_path, set_id, suffix = screenshot_data

    # Find the image (handles relocations)
    img_path, relocation_info = find_image_path(
        screenshot_path=screenshot_path,
        screenshots_dir=screenshots_dir,
        client_base_dir=client_base_dir,
        debug=debug,
        report_relocation=report_relocations,
        project_dir=project_dir,
    )

    # Track relocation if needed
    if relocation_info and relocation_log is not None:
        relocation_log.append(relocation_info)

    # Add timestamp
    target_story.append(
        Paragraph(f"Screenshot #{screenshot_num} at {timestamp}", styles["Timestamp"])
    )

    # Add set ID if available
    if set_id:
        target_story.append(Paragraph(f"Set: {set_id}", styles["Caption"]))

    # Add image if found
    if img_path and img_path.exists():
        # Optimize the image
        optimized_path = optimize_image(
            img_path=img_path,
            image_quality=image_quality,
            image_format=image_format,
            max_dimension=max_dimension,
            use_thumbnails=use_thumbnails,
            thumbnail_size=thumbnail_size,
            debug=debug,
        )

        if optimized_path:
            # Track temporary file for cleanup
            temp_files.append(optimized_path)

            # Add the image to the document
            img = Image(optimized_path, width=540, height=720, kind="proportional")
            img.hAlign = "CENTER"
            target_story.append(img)
        else:
            # If optimization failed, use original
            try:
                img = Image(str(img_path), width=540, height=720, kind="proportional")
                img.hAlign = "CENTER"
                target_story.append(img)
            except Exception as e:
                logger.error(f"Error adding image {img_path}: {e}")
                target_story.append(
                    Paragraph(f"[Image not available: {img_path.name}]", styles["Note"])
                )
    else:
        # Image not found
        target_story.append(Paragraph(f"[Image not found: {screenshot_path}]", styles["Note"]))

    # Add caption if available
    if screenshot_num in captions:
        _, caption_text = captions[screenshot_num]
        target_story.append(Paragraph(f"Caption: {caption_text}", styles["Caption"]))

    # Add spacer
    target_story.append(Spacer(1, 0.2 * inch))


def cleanup_temp_files(temp_files: List[str], debug: bool = False) -> None:
    """Clean up temporary files created during PDF generation.

    Args:
        temp_files: List of paths to temporary files
        debug: Enable debug logging
    """
    if debug:
        logger.debug(f"Cleaning up {len(temp_files)} temporary files")

    for file_path in temp_files:
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                if debug:
                    logger.debug(f"Removed temporary file: {file_path}")
        except Exception as e:
            logger.error(f"Error removing temporary file {file_path}: {e}")
