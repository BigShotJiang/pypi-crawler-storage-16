#!/usr/bin/env python3
"""Report data models for ScreenShooter Mac."""

import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

from pydantic import BaseModel, Field

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("report_models")


class ClientInfo(BaseModel):
    """Client information model."""

    client_name: str
    company_name: str = ""
    contact_name: str = ""
    contact_email: str = ""
    pdf_password: str = ""  # Password for PDF encryption
    preferences: Dict[str, str] = Field(
        default_factory=lambda: {
            "screenshot_delivery": "local",
            "notification_preferences": "all",
            "reporting_frequency": "none",
            "pdf_security": "none",  # Options: none, password
            "page_size": "A4",  # Options: A4, letter
        }
    )
    last_updated: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


class SessionLog:
    """Class to parse and represent a session log."""

    def __init__(self, log_file: Optional[Path] = None):
        self.log_file = log_file
        self.entries = []
        self.notes = []
        self.captions = {}
        self.set_captions = {}  # Add this for per-set captions
        self.screenshots = []
        self.session_note = ""
        self.session_start = None
        self.session_end = None
        self.session_duration = ""
        # New attribute for chronological events
        self.chronological_events = []
        # Track screenshot sets
        self.screenshot_sets = {}

        # Only parse if we have a real log file
        if log_file and log_file.exists() and not str(log_file).startswith("/mock/"):
            self.parse_log()

    def parse_log(self):
        """Parse the session log file to extract entries."""
        try:
            with open(self.log_file) as f:
                for line in f:
                    self.entries.append(line.strip())
                    # Check for session start
                    if "SESSION START NOTE:" in line:
                        self.session_note = line.split("SESSION START NOTE:")[1].strip()
                    # Check for notes
                    elif "NOTE:" in line:
                        timestamp = line.split("]")[0].strip("[")
                        note_text = line.split("NOTE:")[1].strip()
                        self.notes.append((timestamp, note_text))
                        self.chronological_events.append(
                            {"type": "note", "timestamp": timestamp, "content": note_text}
                        )
                    # Check for per-screenshot captions
                    elif "CAPTION for screenshot set #" in line:
                        try:
                            parts = line.split("CAPTION for screenshot set #")
                            timestamp = parts[0].split("]")[0].strip("[")
                            remaining = parts[1]
                            set_num, caption = remaining.split(":", 1)
                            self.set_captions[int(set_num)] = (timestamp, caption.strip())
                        except Exception as e:
                            logger.warning(f"Malformed set caption line: {line.strip()} ({e})")
                            continue
                    elif "CAPTION for screenshot #" in line:
                        try:
                            parts = line.split("CAPTION for screenshot #")
                            timestamp = parts[0].split("]")[0].strip("[")
                            remaining = parts[1]
                            screenshot_num, caption = remaining.split(":", 1)
                            self.captions[int(screenshot_num)] = (timestamp, caption.strip())
                        except Exception as e:
                            logger.warning(f"Malformed caption line: {line.strip()} ({e})")
                            continue
                    # Check for screenshots
                    elif "Screenshot saved:" in line:
                        timestamp = line.split("]")[0].strip("[")

                        # Robustly parse screenshot path and suffix, even when paths contain spaces
                        # Expected log format (from ScreenshooterConfig.log_entry):
                        #   "[timestamp] Set #<n> - Screenshot saved: <path> (<suffix>)"
                        match = re.search(r"Set #(\d+) - Screenshot saved: (.+?) \((.+?)\)", line)

                        if match:
                            set_num, screenshot_path, suffix = match.groups()
                            set_info = set_num
                        else:
                            # Fallback parsing to avoid hard failures if format changes slightly
                            # Take everything after "Screenshot saved:" and strip the trailing suffix
                            remainder = line.split("Screenshot saved:", 1)[1].strip()
                            if " (" in remainder:
                                path_part, suffix_part = remainder.rsplit(" (", 1)
                                screenshot_path = path_part.strip()
                                suffix = suffix_part.rstrip(")")
                            else:
                                screenshot_path = remainder
                                suffix = ""
                            set_info = (
                                line.split("Set #")[1].split(" -")[0] if "Set #" in line else ""
                            )

                        screenshot_data = (timestamp, screenshot_path, set_info, suffix)
                        self.screenshots.append(screenshot_data)
                        self.chronological_events.append(
                            {
                                "type": "screenshot",
                                "timestamp": timestamp,
                                "set_id": set_info,
                                "suffix": suffix,
                                "path": screenshot_path,
                                "index": len(self.screenshots) - 1,
                            }
                        )
                        if set_info:
                            if set_info not in self.screenshot_sets:
                                self.screenshot_sets[set_info] = []
                            self.screenshot_sets[set_info].append(screenshot_data)
                    # Check for session duration
                    elif "Session Duration:" in line:
                        self.session_duration = line.split("Session Duration:")[1].strip()
                        self.session_end = line.split("]")[0].strip("[")
            if self.entries:
                first_entry = self.entries[0]
                self.session_start = first_entry.split("]")[0].strip("[")
            self.chronological_events.sort(key=lambda x: x["timestamp"])
        except Exception as e:
            logger.error(f"Error parsing log file {self.log_file}: {e}")
            raise
