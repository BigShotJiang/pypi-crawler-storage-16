#!/usr/bin/env python3
"""Multi-session report handling for ScreenShooter Mac."""

import logging
import re
import traceback
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from screenshooter.modules.reports.pdf.models import SessionLog

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("multi_session_report")


class MultiSessionReport:
    """Class to handle multiple screenshot sessions for day or project based reports.

    This class loads and organizes multiple session logs for generating comprehensive reports
    across days or for an entire project.
    """

    def __init__(
        self,
        client_name: str,
        project_name: str,
        sessions_dir: Path,
        report_type: str = "day",  # "day" or "project"
        specific_date: Optional[str] = None,  # For day reports: YYYY-MM-DD
        date_range: Optional[Tuple[str, str]] = None,  # For project reports: (start_date, end_date)
        debug: bool = False,
    ):
        self.client_name = client_name
        self.project_name = project_name
        self.sessions_dir = sessions_dir
        self.report_type = report_type
        self.specific_date = specific_date
        self.date_range = date_range
        self.debug = debug

        # Initialize logger
        self.logger = logging.getLogger("multi_session_report")
        if debug:
            self.logger.setLevel(logging.DEBUG)

        # Data structures to organize sessions
        self.sessions_by_day = defaultdict(
            list
        )  # Dict mapping YYYY-MM-DD to list of session directories
        self.session_logs = {}  # Dict mapping session_name to SessionLog object

        # Statistics
        self.total_screenshots = 0
        self.total_notes = 0
        self.total_duration = timedelta()
        self.earliest_session = None
        self.latest_session = None

        self.logger.debug(f"Initialized MultiSessionReport for {client_name}/{project_name}")

    def load_session_logs(self) -> None:
        """Load all relevant session logs based on report type and date criteria."""
        self.logger.debug(f"Loading session logs for {self.report_type} report")

        # Find all session directories
        if not self.sessions_dir.exists():
            self.logger.error(f"Sessions directory not found: {self.sessions_dir}")
            raise FileNotFoundError(f"Sessions directory not found: {self.sessions_dir}")

        # List all session directories
        session_dirs = [d for d in self.sessions_dir.iterdir() if d.is_dir()]
        self.logger.debug(f"Found {len(session_dirs)} total session directories")

        # Process based on report type
        if self.report_type == "day":
            # Use specified date or default to today
            target_date = self.specific_date or datetime.now().strftime("%Y-%m-%d")
            self.logger.debug(f"Filtering sessions for date: {target_date}")

            # Filter sessions for the target date
            for session_dir in session_dirs:
                session_date = session_dir.name.split("_")[0]  # Format: YYYY-MM-DD_HH-MM-SS
                if session_date == target_date:
                    self.sessions_by_day[target_date].append(session_dir)

            # Sort sessions chronologically
            for day, sessions in self.sessions_by_day.items():
                self.sessions_by_day[day] = sorted(sessions, key=lambda d: d.name)

        elif self.report_type == "project":
            # Process all sessions or filter by date range
            start_date = end_date = None
            if self.date_range:
                start_date, end_date = self.date_range
                self.logger.debug(f"Filtering sessions for date range: {start_date} to {end_date}")

            # Group sessions by day
            for session_dir in session_dirs:
                # Extract date from directory name (YYYY-MM-DD_HH-MM-SS)
                try:
                    session_date = session_dir.name.split("_")[0]

                    # Apply date range filter if specified
                    if start_date and session_date < start_date:
                        continue
                    if end_date and session_date > end_date:
                        continue

                    self.sessions_by_day[session_date].append(session_dir)
                except Exception as e:
                    self.logger.warning(
                        f"Error processing session directory {session_dir.name}: {e}"
                    )

            # Sort sessions for each day chronologically
            for day, sessions in self.sessions_by_day.items():
                self.sessions_by_day[day] = sorted(sessions, key=lambda d: d.name)

        # Load all session logs
        for day, sessions in self.sessions_by_day.items():
            for session_dir in sessions:
                session_name = session_dir.name
                log_file = session_dir / "session.log"
                if log_file.exists():
                    try:
                        session_log = SessionLog(log_file)
                        self.session_logs[session_name] = session_log

                        # Update statistics
                        self.total_screenshots += len(session_log.screenshots)

                        # Notes count should include:
                        # - Standard notes
                        # - Per-screenshot captions
                        # - Per-set captions
                        # - Session start note (if present)
                        # - Caption-only events (from database)
                        note_count = len(session_log.notes)
                        note_count += len(getattr(session_log, "captions", {}))
                        note_count += len(getattr(session_log, "set_captions", {}))
                        if session_log.session_note:
                            note_count += 1
                        note_count += sum(
                            1
                            for e in getattr(session_log, "chronological_events", [])
                            if e.get("type") == "caption"
                        )
                        self.total_notes += note_count

                        # Update duration if available
                        if session_log.session_duration:
                            try:
                                # Parse duration strings
                                hours = minutes = seconds = 0

                                hour_match = re.search(r"(\d+) hour", session_log.session_duration)
                                if hour_match:
                                    hours = int(hour_match.group(1))

                                minute_match = re.search(
                                    r"(\d+) minute", session_log.session_duration
                                )
                                if minute_match:
                                    minutes = int(minute_match.group(1))

                                second_match = re.search(
                                    r"(\d+) second", session_log.session_duration
                                )
                                if second_match:
                                    seconds = int(second_match.group(1))

                                duration = timedelta(hours=hours, minutes=minutes, seconds=seconds)
                                self.total_duration += duration
                            except Exception as e:
                                if self.debug:
                                    self.logger.debug(
                                        f"Failed to parse duration '{session_log.session_duration}': {e}"
                                    )

                        # Track earliest and latest sessions
                        if session_log.session_start:
                            session_datetime = datetime.strptime(
                                session_log.session_start, "%Y-%m-%d %H:%M:%S"
                            )
                            if (
                                not self.earliest_session
                                or session_datetime < self.earliest_session
                            ):
                                self.earliest_session = session_datetime

                        if session_log.session_end:
                            session_end_datetime = datetime.strptime(
                                session_log.session_end, "%Y-%m-%d %H:%M:%S"
                            )
                            if (
                                not self.latest_session
                                or session_end_datetime > self.latest_session
                            ):
                                self.latest_session = session_end_datetime

                    except Exception as e:
                        self.logger.error(f"Error loading session log {log_file}: {e}")
                        if self.debug:
                            self.logger.debug(traceback.format_exc())
                else:
                    self.logger.warning(f"Session log file not found: {log_file}")

        self.logger.debug(
            f"Loaded {len(self.session_logs)} session logs across {len(self.sessions_by_day)} days"
        )

    def get_combined_stats(self) -> Dict[str, Any]:
        """Get combined statistics for all loaded sessions."""
        # Format timestamps for display
        earliest_session_str = ""
        latest_session_str = ""

        if self.earliest_session:
            earliest_session_str = self.earliest_session.strftime("%Y-%m-%d %H:%M:%S")

        if self.latest_session:
            latest_session_str = self.latest_session.strftime("%Y-%m-%d %H:%M:%S")

        # Format total duration
        total_seconds = self.total_duration.total_seconds()
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)

        formatted_total_duration = ""
        if hours > 0:
            formatted_total_duration += f"{int(hours)} hour{'s' if hours != 1 else ''} "
        if minutes > 0:
            formatted_total_duration += f"{int(minutes)} minute{'s' if minutes != 1 else ''} "
        if seconds > 0 or (hours == 0 and minutes == 0):
            formatted_total_duration += f"{int(seconds)} second{'s' if seconds != 1 else ''}"

        # Return combined stats
        return {
            "total_sessions": len(self.session_logs),
            "days_covered": len(self.sessions_by_day),
            "total_screenshots": self.total_screenshots,
            "total_notes": self.total_notes,
            "total_duration": self.total_duration,
            "formatted_total_duration": formatted_total_duration,
            "earliest_session": self.earliest_session,
            "latest_session": self.latest_session,
            "earliest_session_str": earliest_session_str,
            "latest_session_str": latest_session_str,
        }
