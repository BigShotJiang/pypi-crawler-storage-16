#!/usr/bin/env python3
"""PDF table components for consistent report design."""

from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import Spacer, Table, TableStyle


def add_client_info_table(story: list, client_info: dict, styles: dict) -> None:
    """Add client information table to the PDF story."""
    client_data = [
        ["Client:", client_info.get("client_name", "")],
        ["Company:", client_info.get("company_name", "")],
        ["Contact:", client_info.get("contact_name", "")],
        ["Email:", client_info.get("contact_email", "")],
    ]
    client_table = Table(client_data, colWidths=[1.5 * inch, 4 * inch])
    client_table.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("BACKGROUND", (0, 0), (0, -1), colors.lightgrey),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("PADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    story.append(client_table)
    story.append(Spacer(1, 0.3 * inch))


def add_session_summary_table(
    story: list,
    session_start: str,
    session_end: str,
    session_duration: str,
    screenshot_count: int,
    note_count: int,
    styles: dict,
) -> None:
    """Add session summary table to the PDF story."""
    session_data = [
        ["Start Time:", session_start],
        ["End Time:", session_end],
        ["Duration:", session_duration],
        ["Screenshots:", str(screenshot_count)],
        ["Notes:", str(note_count)],
    ]
    session_table = Table(session_data, colWidths=[1.5 * inch, 4 * inch])
    session_table.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("BACKGROUND", (0, 0), (0, -1), colors.lightgrey),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("PADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    story.append(session_table)
    story.append(Spacer(1, 0.2 * inch))
