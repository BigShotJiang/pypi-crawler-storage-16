#!/usr/bin/env python3
"""Utility functions for PDF generation, re-exporting from report_pdf_helper."""

import json
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("pdf_utils")


def handle_image_relocations(report_generator, relocation_log):
    """Handle image relocations by smartly merging with existing data and updating logs.

    Args:
        report_generator: The ReportGenerator instance
        relocation_log: List of relocation information entries

    Returns:
        bool: True if changes were saved to the relocation log, False if only cached data was used
    """
    # Track new vs existing relocations
    new_relocations = []
    updated_relocations = []

    # Get the path to the relocation log file
    relocation_log_path = report_generator.project_dir / "image_relocation_log.json"

    # Load existing relocation data if available
    existing_relocations = []
    if relocation_log_path.exists():
        try:
            with open(relocation_log_path) as f:
                existing_relocations = json.load(f)
        except Exception as e:
            report_generator.log_entry(
                f"Error reading existing relocation log: {e}", level="warning"
            )

    # Create a lookup of existing relocations by original path
    existing_lookup = {}
    for entry in existing_relocations:
        orig_path = entry.get("original_path")
        if orig_path:
            existing_lookup[orig_path] = entry

    # Merge new relocations with existing ones
    merged_relocations = existing_relocations.copy()

    for entry in relocation_log:
        orig_path = entry.get("original_path")

        # Skip entries loaded from cache - they don't need to be merged
        if entry.get("from_cache"):
            continue

        # Check if this is a new relocation or an update to an existing one
        if orig_path in existing_lookup:
            # Entry already exists - check if anything has changed
            existing_entry = existing_lookup[orig_path]
            if existing_entry.get("found_path") != entry.get("found_path"):
                # Path has changed - update the existing entry
                for key, value in entry.items():
                    existing_entry[key] = value
                updated_relocations.append(entry)
        else:
            # New entry - add it to the merged list
            merged_relocations.append(entry)
            new_relocations.append(entry)

    # Only write to file if there are changes
    if new_relocations or updated_relocations:
        # Write the updated relocation log
        with open(relocation_log_path, "w") as f:
            json.dump(merged_relocations, f, indent=4)

        # Log the changes
        if new_relocations and updated_relocations:
            new_count = len(new_relocations)
            updated_count = len(updated_relocations)
            report_generator.log_entry(
                f"Found {new_count} new relocated images and updated {updated_count} entries",
                f"[yellow]Found {new_count} new relocated images and updated "
                f"{updated_count} existing entries[/yellow]",
                level="info",
            )
        elif new_relocations:
            new_count = len(new_relocations)
            report_generator.log_entry(
                f"Found {new_count} new relocated images",
                f"[yellow]Found {new_count} new relocated images[/yellow]",
                level="info",
            )
        elif updated_relocations:
            updated_count = len(updated_relocations)
            report_generator.log_entry(
                f"Updated {updated_count} existing relocation entries",
                f"[yellow]Updated {updated_count} existing relocation entries[/yellow]",
                level="info",
            )

        # Changes were saved
        return True
    else:
        # No changes to the relocation log, count entries retrieved from cache
        from_cache_count = sum(1 for r in relocation_log if r.get("from_cache", False))

        if from_cache_count > 0:
            report_generator.log_entry(
                f"Used existing image relocation data for {from_cache_count} images",
                f"[blue]Used existing image relocation data for {from_cache_count} images[/blue]",
                level="info",
            )
        else:
            report_generator.log_entry(
                "No image relocations were needed",
                "[green]No image relocations were needed[/green]",
                level="info",
            )

        # No changes were saved
        return False
