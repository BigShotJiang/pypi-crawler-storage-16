#!/usr/bin/env python3
"""Command-line interface for report generation."""

import logging
import re
import sys
from pathlib import Path
from typing import Any, List, Optional, Tuple, Union

import click
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from screenshooter.modules.clients.utils import slugify_name
from screenshooter.modules.reports.pdf import (
    ReportGenerator,
    generate_multi_session_pdf,
    generate_single_session_pdf,
)
from screenshooter.modules.reports.report_email import send_email
from screenshooter.modules.settings.settings_helper import (
    get_email_settings,
    get_pdf_optimization_settings,
    get_screenshots_dir,
    should_optimize_pdf,
    should_use_database,
)

# Initialize rich console
console = Console()


def _prompt_on_new_line(prompt_text: str, **kwargs: Any) -> str:
    """Prompt with choices/default on one line, input on a clean `> ` line below."""
    choices = kwargs.get("choices")
    default = kwargs.get("default")

    prompt_text = prompt_text.strip()

    if choices:
        choices_str = "/".join(str(c) for c in choices)
        # Escape opening bracket to prevent rich from interpreting it as a style tag
        extra = f" \\[{choices_str}]"
        if default is not None:
            extra += f" ({default})"
        console.print(f"{prompt_text}{extra}:")
    else:
        console.print(f"{prompt_text}:")

    while True:
        raw = input("> ").strip()
        if not raw and default is not None:
            raw = str(default)
        if choices:
            if raw in [str(c) for c in choices]:
                return raw
            console.print(
                f"[red]Invalid choice: {raw}. Please enter one of: {', '.join(str(c) for c in choices)}[/red]"
            )
            continue
        return raw


def _confirm_on_new_line(prompt_text: str, **kwargs: Any) -> bool:
    """Yes/No confirm with indicator on question line and `> ` for input."""
    default = kwargs.get("default", False)
    indicator = "[Y/n]" if default else "[y/N]"
    console.print(f"{prompt_text} {indicator}:")
    default_choice = "y" if default else "n"

    while True:
        raw = input("> ").strip().lower()
        if not raw:
            raw = default_choice
        if raw in ("y", "n"):
            return raw == "y"
        console.print("[red]Please enter 'y' or 'n'.[/red]")


# Notes parsing (mirrors post_session flow) ----------------------------------
def _parse_notes_lines(note_line: str) -> List[str]:
    """Parse notes text into ordered lines with explicit bullets.

    - '/n', '\n', and '<br>' create new lines
    - '/b' starts a bullet item; multiple '/b' create multiple bullets
    - A plain '-' does not create a bullet
    """
    if not note_line:
        return []
    normalized = note_line.replace("<br>", "\n").replace("/n", "\n").replace("\\n", "\n")
    result_lines: List[str] = []
    for raw_line in normalized.splitlines():
        segment = raw_line.strip()
        if not segment:
            continue
        parts = segment.split("/b")
        head_text = parts[0].strip()
        if head_text:
            result_lines.append(head_text)
        for bullet_text in parts[1:]:
            cleaned = bullet_text.strip()
            if cleaned:
                result_lines.append(f"- {cleaned}")
    return result_lines


# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("report_cli")

# Sentinel value for 'back' option - Consider moving to a shared utils module
BACK_OPTION = object()


def _resolve_client_dir(base_dir: Path, client_name: str) -> Path:
    """Resolve the filesystem directory for a client for reports."""
    # Try database first
    if should_use_database():
        try:
            from screenshooter.modules.database import DatabaseOperations

            db_ops = DatabaseOperations()
            client = db_ops.get_client_by_name(client_name) or db_ops.get_client_by_directory(
                client_name
            )
            if client and getattr(client, "directory_name", None):
                return base_dir / client.directory_name
        except Exception:
            pass

    # Try filesystem via ClientManager
    try:
        from screenshooter.modules.clients.manager import ClientManager

        manager = ClientManager(str(base_dir))
        client_info = manager.load_client_info(client_name)
        if getattr(client_info, "directory_name", None):
            return base_dir / client_info.directory_name
    except Exception:
        pass

    # Fallback to slug or raw name
    slug = slugify_name(client_name)
    return base_dir / (slug or client_name)


def _resolve_project_dir(base_dir: Path, client_name: str, project_name: str) -> Path:
    """Resolve the filesystem directory for a project within a client for reports."""
    client_dir = _resolve_client_dir(base_dir, client_name)

    # Try database first
    if should_use_database():
        try:
            from screenshooter.modules.database import DatabaseOperations

            db_ops = DatabaseOperations()
            client = db_ops.get_client_by_name(client_name) or db_ops.get_client_by_directory(
                client_name
            )
            if client and getattr(client, "id", None):
                project = db_ops.get_project_by_name(client.id, project_name)
                if project and getattr(project, "directory_name", None):
                    return client_dir / project.directory_name
        except Exception:
            pass

    # Prefer slugged directory if it already exists
    slug = slugify_name(project_name)
    slug_dir = client_dir / slug
    if slug_dir.exists():
        return slug_dir

    # Legacy fallback: raw project name
    return client_dir / project_name


def _prompt_with_back(
    prompt_text: str, choices: List[str], default: Optional[str] = None, show_choices: bool = True
) -> Union[str, object]:
    """Prompt helper that adds a 'b' for back, with clean spacing around the back hint."""
    base_choices = [str(c) for c in choices]
    valid_choices = base_choices + ["b"]

    while True:
        response = _prompt_on_new_line(
            f"{prompt_text} (or 'b' to go back)",
            choices=valid_choices,
            default=default,
        )
        if response.lower() == "b":
            return BACK_OPTION
        if response in base_choices:
            return response


def _select_client_report(base_dir: Path) -> Union[str, object, None]:
    """Handle interactive client selection for reports."""
    console.print("\n[bold]Client Selection[/bold]")

    clients = []
    db_checked = False
    if should_use_database():
        db_checked = True
        try:
            from screenshooter.modules.database import DatabaseOperations

            db_ops = DatabaseOperations()
            db_clients = db_ops.list_clients()
            clients = sorted([c.name for c in db_clients if c.name])
        except Exception as e:
            logger.warning(f"Failed to get clients from database: {e}")

    if not clients:
        if db_checked:
            console.print(
                "[yellow]No clients found in database (or database unavailable).[/yellow]"
            )
            if not _confirm_on_new_line(
                "Would you like to check the filesystem for clients?", default=True
            ):
                return None

        clients = [
            d.name for d in base_dir.iterdir() if d.is_dir() and (d / "client_info.json").exists()
        ]

    if not clients:
        console.print(
            "[bold yellow]No clients found with client_info.json or in database.[/bold yellow]"
        )
        return None  # Cannot proceed

    # Pagination Loop
    PAGE_SIZE = 10
    page = 0

    while True:
        total_items = len(clients)
        if total_items == 0:
            total_pages = 1
        else:
            total_pages = (total_items + PAGE_SIZE - 1) // PAGE_SIZE

        if page >= total_pages:
            page = total_pages - 1
        page = max(page, 0)

        start_idx = page * PAGE_SIZE
        end_idx = min(start_idx + PAGE_SIZE, total_items)
        page_items = clients[start_idx:end_idx]

        if total_pages > 1:
            console.print(f"\n[bold]Available Clients (Page {page + 1}/{total_pages}):[/bold]")
        else:
            console.print("\n[bold]Available Clients:[/bold]")

        for i, client in enumerate(page_items):
            display_idx = start_idx + i + 1
            console.print(f"{display_idx}. {client}")

        # Build choices
        choices = [str(start_idx + i + 1) for i in range(len(page_items))]
        extra_options = []

        if page < total_pages - 1:
            console.print("n. Next Page")
            extra_options.append("n")

        if page > 0:
            console.print("p. Previous Page")
            extra_options.append("p")

        prompt_text = "Select client number"
        default_choice = choices[0] if choices else None

        choice = _prompt_with_back(
            prompt_text,
            choices=choices + extra_options,
            default=default_choice,
        )

        if choice is BACK_OPTION:
            return BACK_OPTION
        elif choice == "n":
            page += 1
        elif choice == "p":
            page -= 1
        else:
            return clients[int(choice) - 1]


def _select_project_report(client_name: str, base_dir: Path) -> Union[str, object, None]:
    """Handle interactive project selection for reports."""
    console.print("\n[bold]Project Selection[/bold]")

    projects = []
    archived_projects = []
    db_checked = False
    if should_use_database():
        db_checked = True
        try:
            from screenshooter.modules.database import DatabaseOperations

            db_ops = DatabaseOperations()
            # Try to find client by name first, then directory
            client = db_ops.get_client_by_name(client_name)
            if not client:
                client = db_ops.get_client_by_directory(client_name)

            if client and client.id:
                db_projects = db_ops.list_projects(client.id)
                projects = sorted([p.name for p in db_projects if p.name])

                # Get archived projects too
                db_archived = db_ops.list_archived_projects(client.id)
                archived_projects = sorted([p.name for p in db_archived if p.name])
        except Exception as e:
            logger.warning(f"Failed to get projects from database: {e}")

    if not projects and not archived_projects:
        if db_checked:
            console.print(
                "[yellow]No active or archived projects found in database (or database unavailable).[/yellow]"
            )
            if not _confirm_on_new_line(
                "Would you like to check the filesystem for projects?", default=True
            ):
                return None

        client_dir = _resolve_client_dir(base_dir, client_name)
        if client_dir.exists():
            projects = [
                d.name for d in client_dir.iterdir() if d.is_dir() and (d / "sessions").exists()
            ]

    if not projects and not archived_projects:
        console.print(
            f"[bold yellow]No projects with session data found for client '{client_name}'.[/bold yellow]"
        )
        return None  # Cannot proceed

    # Pagination Loop
    viewing_all = False
    current_list = projects
    PAGE_SIZE = 10
    page = 0

    while True:
        # If no active projects but have archived, and not already viewing all, switch to all or allow fallback logic?
        # Here we assume if we have archived, we can show the 'Show archived' option even if active list is empty.
        # But if active list is empty, page_items will be empty for 'projects'.

        total_items = len(current_list)
        if total_items == 0:
            total_pages = 1
        else:
            total_pages = (total_items + PAGE_SIZE - 1) // PAGE_SIZE

        if page >= total_pages:
            page = total_pages - 1
        page = max(page, 0)

        start_idx = page * PAGE_SIZE
        end_idx = min(start_idx + PAGE_SIZE, total_items)
        page_items = current_list[start_idx:end_idx]

        if total_pages > 1:
            console.print(f"\n[bold]Available Projects (Page {page + 1}/{total_pages}):[/bold]")
        else:
            console.print("\n[bold]Available Projects:[/bold]")

        if total_items == 0 and not viewing_all:
            console.print("[dim]No active projects.[/dim]")
        elif total_items == 0 and viewing_all:
            console.print("[dim]No projects found.[/dim]")

        for i, project in enumerate(page_items):
            display_idx = start_idx + i + 1
            suffix = ""
            if viewing_all and project in archived_projects:
                suffix = " [dim](Archived)[/dim]"
            console.print(f"{display_idx}. {project}{suffix}")

        # Build choices
        choices = [str(start_idx + i + 1) for i in range(len(page_items))]
        extra_options = []

        if page < total_pages - 1:
            console.print("n. Next Page")
            extra_options.append("n")

        if page > 0:
            console.print("p. Previous Page")
            extra_options.append("p")

        if not viewing_all and archived_projects:
            console.print(f"a. Show archived projects ({len(archived_projects)})")
            extra_options.append("a")

        prompt_text = "Select project number"
        default_choice = choices[0] if choices else ("a" if "a" in extra_options else None)

        choice = _prompt_with_back(
            prompt_text, choices=choices + extra_options, default=default_choice
        )

        if choice is BACK_OPTION:
            return BACK_OPTION
        elif choice == "n":
            page += 1
        elif choice == "p":
            page -= 1
        elif choice == "a":
            viewing_all = True
            current_list = projects + archived_projects
            page = 0
        else:
            # Selection
            idx = int(choice) - 1
            return current_list[idx]


def _select_report_type() -> Union[str, object]:
    """Handle interactive selection of report type."""
    console.print("\n[bold]Report Type Selection[/bold]")
    report_type_map = {
        "1": ("Session Report (single session)", "session"),
        "2": ("Daily Report (all sessions from a specific day)", "day"),
        "3": ("Project Report (all sessions from the project)", "project"),
    }
    for key, (label, _) in report_type_map.items():
        console.print(f"{key}. {label}")

    choice = _prompt_with_back(
        "Select report type", choices=list(report_type_map.keys()), default="1"
    )
    if choice is BACK_OPTION:
        return BACK_OPTION  # Go back to project selection
    return report_type_map[choice][1]  # Return 'session', 'day', or 'project'


def _select_session(
    project_dir: Path, client_name: Optional[str] = None, project_name: Optional[str] = None
) -> Union[str, object, None]:
    """Handle interactive selection of a specific session."""
    console.print("\n[bold]Session Selection[/bold]")

    sessions = []
    db_checked = False
    if should_use_database() and client_name and project_name:
        db_checked = True
        try:
            from screenshooter.modules.database import DatabaseOperations

            db_ops = DatabaseOperations()
            client = db_ops.get_client_by_name(client_name) or db_ops.get_client_by_directory(
                client_name
            )
            if client and client.id:
                project = db_ops.get_project_by_name(client.id, project_name)
                if project and project.id:
                    db_sessions = db_ops.list_sessions(project.id)
                    sessions = sorted([s.name for s in db_sessions if s.name], reverse=True)
        except Exception as e:
            logger.warning(f"Failed to get sessions from database: {e}")

    if not sessions:
        if db_checked:
            console.print(
                "[yellow]No sessions found in database (or database unavailable).[/yellow]"
            )
            if not _confirm_on_new_line(
                "Would you like to check the filesystem for sessions?", default=True
            ):
                return None

        sessions_dir = project_dir / "sessions"
        if sessions_dir.exists():
            sessions = sorted([d.name for d in sessions_dir.iterdir() if d.is_dir()], reverse=True)

    if not sessions:
        console.print("[bold yellow]No sessions found.[/bold yellow]")
        return None  # Cannot proceed

    # Offer to select a session or use the most recent
    console.print(f"Most recent session: {sessions[0]}")

    use_recent_choice = _prompt_with_back(
        "Use the most recent session?", choices=["y", "n"], default="y"
    )
    if use_recent_choice is BACK_OPTION:
        return BACK_OPTION  # Go back to report type selection

    if use_recent_choice == "y":
        return sessions[0]  # Return the most recent session

    # If user doesn't want to use the most recent, show the full list
    console.print("\nAvailable Sessions:")
    for i, session in enumerate(sessions, 1):
        console.print(f"{i}. {session}")

    choice = _prompt_with_back(
        "Select session number",
        choices=[str(i) for i in range(1, len(sessions) + 1)],
        default="1",
    )
    if choice is BACK_OPTION:
        return BACK_OPTION  # Go back to report type selection
    return sessions[int(choice) - 1]


def _select_day(
    project_dir: Path, client_name: Optional[str] = None, project_name: Optional[str] = None
) -> Union[str, object, None]:
    """Handle interactive selection of a specific day."""
    console.print("\n[bold]Date Selection for Daily Report[/bold]")

    dates = set()
    db_checked = False

    if should_use_database() and client_name and project_name:
        db_checked = True
        try:
            from screenshooter.modules.database import DatabaseOperations

            db_ops = DatabaseOperations()
            client = db_ops.get_client_by_name(client_name) or db_ops.get_client_by_directory(
                client_name
            )
            if client and client.id:
                project = db_ops.get_project_by_name(client.id, project_name)
                if project and project.id:
                    db_sessions = db_ops.list_sessions(project.id)
                    for session in db_sessions:
                        if session.start_time:
                            dates.add(session.start_time.strftime("%Y-%m-%d"))
        except Exception as e:
            logger.warning(f"Failed to get dates from database: {e}")

    if not dates:
        if db_checked:
            console.print("[yellow]No dates found in database (or database unavailable).[/yellow]")
            if not _confirm_on_new_line(
                "Would you like to check the filesystem for dates?", default=True
            ):
                return None

        sessions_dir = project_dir / "sessions"
        if sessions_dir.exists():
            for session in sessions_dir.iterdir():
                if session.is_dir():
                    date_match = re.match(r"(\d{4}-\d{2}-\d{2})_.*", session.name)
                    if date_match:
                        dates.add(date_match.group(1))

    dates = sorted(list(dates), reverse=True)
    if not dates:
        console.print("[bold yellow]No sessions with valid dates found.[/bold yellow]")
        return None  # Cannot proceed

    # Let user select a date or use the most recent
    console.print(f"Most recent date: {dates[0]}")

    use_recent_choice = _prompt_with_back(
        "Use the most recent date?", choices=["y", "n"], default="y"
    )
    if use_recent_choice is BACK_OPTION:
        return BACK_OPTION  # Go back to report type selection

    if use_recent_choice == "y":
        return dates[0]  # Return the most recent date

    # If user doesn't want to use the most recent, show the full list
    console.print("\nAvailable Dates:")
    for i, date in enumerate(dates, 1):
        console.print(f"{i}. {date}")

    choice = _prompt_with_back(
        "Select date number", choices=[str(i) for i in range(1, len(dates) + 1)], default="1"
    )
    if choice is BACK_OPTION:
        return BACK_OPTION  # Go back to report type selection
    return dates[int(choice) - 1]


def _select_date_range(
    project_dir: Path, client_name: Optional[str] = None, project_name: Optional[str] = None
) -> Union[Tuple[str, str], object, None]:
    """Handle interactive selection of a date range for project reports."""
    console.print("\n[bold]Date Range Selection for Project Report[/bold]")

    dates = set()
    db_checked = False

    if should_use_database() and client_name and project_name:
        db_checked = True
        try:
            from screenshooter.modules.database import DatabaseOperations

            db_ops = DatabaseOperations()
            client = db_ops.get_client_by_name(client_name) or db_ops.get_client_by_directory(
                client_name
            )
            if client and client.id:
                project = db_ops.get_project_by_name(client.id, project_name)
                if project and project.id:
                    db_sessions = db_ops.list_sessions(project.id)
                    for session in db_sessions:
                        if session.start_time:
                            dates.add(session.start_time.strftime("%Y-%m-%d"))
        except Exception as e:
            logger.warning(f"Failed to get dates from database: {e}")

    if not dates:
        if db_checked:
            console.print("[yellow]No dates found in database (or database unavailable).[/yellow]")
            if not _confirm_on_new_line(
                "Would you like to check the filesystem for dates?", default=True
            ):
                return None

        sessions_dir = project_dir / "sessions"
        if sessions_dir.exists():
            for session in sessions_dir.iterdir():
                if session.is_dir():
                    date_match = re.match(r"(\d{4}-\d{2}-\d{2})_.*", session.name)
                    if date_match:
                        dates.add(date_match.group(1))

    dates = sorted(list(dates))
    if not dates:
        console.print("[bold yellow]No sessions with valid dates found.[/bold yellow]")
        return None  # Cannot proceed

    console.print(f"Project contains sessions from {dates[0]} to {dates[-1]}")
    use_range_choice = _prompt_with_back("Specify a date range?", choices=["y", "n"], default="n")

    if use_range_choice is BACK_OPTION:
        return BACK_OPTION  # Go back to report type selection
    if use_range_choice == "n":
        return None  # Indicate use full range

    # Select Start Date
    console.print("\n[bold]Select Start Date:[/bold]")
    for i, date in enumerate(dates, 1):
        console.print(f"{i}. {date}")
    start_choice = _prompt_with_back(
        "Select start date number", choices=[str(i) for i in range(1, len(dates) + 1)], default="1"
    )
    if start_choice is BACK_OPTION:
        # If user wants to go back from start date selection, go back to the 'specify range?' question.
        # This requires restructuring the loop or returning a specific signal.
        # For simplicity, let's assume back from here goes back to report type selection.
        return BACK_OPTION

    start_date = dates[int(start_choice) - 1]

    # Select End Date
    later_dates = [d for d in dates if d >= start_date]
    console.print("\n[bold]Select End Date:[/bold]")
    for i, date in enumerate(later_dates, 1):
        console.print(f"{i}. {date}")
    end_choice = _prompt_with_back(
        "Select end date number",
        choices=[str(i) for i in range(1, len(later_dates) + 1)],
        default=str(len(later_dates)),
    )
    if end_choice is BACK_OPTION:
        # Back from end date selection should ideally go back to start date selection.
        # Again, for simplicity, let's route back to report type. Requires loop restructure for finer control.
        return BACK_OPTION

    end_date = later_dates[int(end_choice) - 1]
    return (start_date, end_date)


def interactive_report_generation(use_command_line=False, cli_args=None) -> int:
    """Interactive report generation interface with back functionality."""
    console.print("[bold]PDF Report Generator Setup[/bold]")
    console.print("==========================")

    # Initialize variables with defaults
    client_name = None
    project_name = None
    session_date = None
    base_dir = None
    report_type = "session"
    specific_date = None
    date_range = None
    output_dir = None
    pagesize = None

    # Use command line args if provided
    if use_command_line and cli_args:
        client_name = cli_args.get("client")
        project_name = cli_args.get("project")
        session_date = cli_args.get("session")
        base_dir = Path(cli_args.get("dir")) if cli_args.get("dir") else Path(get_screenshots_dir())
        report_type = cli_args.get("report_type") or "session"
        specific_date = cli_args.get("date")
        if cli_args.get("start_date") and cli_args.get("end_date"):
            date_range = (cli_args.get("start_date"), cli_args.get("end_date"))
        output_dir = cli_args.get("output")
        pagesize = cli_args.get("pagesize")

        # Validation
        if not base_dir.exists():
            console.print(f"[bold red]Screenshots directory not found: {base_dir}[/bold red]")
            return 1

        if not client_name or not project_name:
            console.print(
                "[bold red]Client and project names are required for command line mode.[/bold red]"
            )
            return 1

        # Validate client and project exist
        client_exists = False
        project_exists = False
        db_checked = False

        if should_use_database():
            db_checked = True
            try:
                from screenshooter.modules.database import DatabaseOperations

                db_ops = DatabaseOperations()
                client = db_ops.get_client_by_name(client_name) or db_ops.get_client_by_directory(
                    client_name
                )
                if client and client.id:
                    client_exists = True
                    project = db_ops.get_project_by_name(client.id, project_name)
                    if project and project.id:
                        project_exists = True
            except Exception:
                pass

        if (not client_exists or not project_exists) and db_checked:
            # If DB check failed to find them, try filesystem but don't prompt explicitly here since this is validation
            # Just fall through to filesystem check if implicit fallback allowed, or check if filesystem exists
            # The prompt is trickier in non-interactive validation flow (CLI args)
            # We'll just check filesystem if they exist there, assuming fallback is okay if explicit args provided
            pass

        client_dir = _resolve_client_dir(base_dir, client_name)
        project_dir = _resolve_project_dir(base_dir, client_name, project_name)

        if not client_exists:
            if client_dir.exists() and (client_dir / "client_info.json").exists():
                client_exists = True
                if project_dir.exists() and (project_dir / "sessions").exists():
                    project_exists = True

        if not client_exists:
            console.print(
                f"[bold red]Client '{client_name}' not found or missing client_info.json.[/bold red]"
            )
            return 1

        if not project_exists:
            console.print(
                f"[bold red]Project '{project_name}' not found or has no sessions.[/bold red]"
            )
            return 1

        # For session reports, find the most recent session if not specified
        if report_type == "session" and not session_date:
            sessions = []
            db_checked = False
            if should_use_database():
                db_checked = True
                try:
                    from screenshooter.modules.database import DatabaseOperations

                    db_ops = DatabaseOperations()
                    # We verified client and project exist above, so fetching again is safe enough
                    client = db_ops.get_client_by_name(
                        client_name
                    ) or db_ops.get_client_by_directory(client_name)
                    if client and client.id:
                        project = db_ops.get_project_by_name(client.id, project_name)
                        if project and project.id:
                            db_sessions = db_ops.list_sessions(project.id)
                            sessions = sorted([s.name for s in db_sessions if s.name], reverse=True)
                except Exception:
                    pass

            if not sessions:
                if db_checked:
                    # Implicit fallback for CLI args mode or just check filesystem silently?
                    # Since this is auto-detecting most recent session, we can just check filesystem
                    pass

                sessions_dir = project_dir / "sessions"
                if sessions_dir.exists():
                    sessions = sorted(
                        [d.name for d in sessions_dir.iterdir() if d.is_dir()], reverse=True
                    )

            if not sessions:
                console.print(
                    f"[bold red]No sessions found for project '{project_name}'.[/bold red]"
                )
                return 1
            session_date = sessions[0]
            console.print(f"[green]Using most recent session: {session_date}[/green]")
    else:
        # Interactive Setup with Back Option
        console.print("(Enter 'b' at any prompt to go back to the previous step)")
        base_dir = Path(get_screenshots_dir())
        if not base_dir.exists():
            console.print(f"[bold red]Screenshots directory not found: {base_dir}[/bold red]")
            return 1

        client_name: Optional[str] = None
        project_name: Optional[str] = None
        report_type: Optional[str] = None
        session_date: Optional[str] = None  # For session reports
        specific_date: Optional[str] = None  # For day reports
        date_range: Optional[Tuple[str, str]] = None  # For project reports (optional range)
        # Add other necessary variables like output_dir, pagesize etc. if they need interactive input

        step = 1
        max_steps = 5  # Client -> Project -> Report Type -> Specifics -> PDF Settings

        while step <= max_steps:
            result = None
            if step == 1:  # Select Client
                result = _select_client_report(base_dir)
                if result is BACK_OPTION:
                    console.print("[yellow]Cancelled. Returning to main menu.[/yellow]")
                    return 1
                elif isinstance(result, str):
                    client_name = result
                    step += 1
                elif result is None:  # No clients found
                    return 1  # Exit
            elif step == 2:  # Select Project
                if not client_name:  # Should not happen if step 1 succeeded
                    console.print("[red]Error: Client not selected.[/red]")
                    step = 1
                    continue
                result = _select_project_report(client_name, base_dir)
                if result is BACK_OPTION:
                    step -= 1
                    continue
                elif isinstance(result, str):
                    project_name = result
                    step += 1
                elif result is None:  # No projects found
                    return 1  # Exit (or maybe go back?)
            elif step == 3:  # Select Report Type
                result = _select_report_type()
                if result is BACK_OPTION:
                    step -= 1
                    continue
                elif isinstance(result, str):
                    report_type = result
                    step += 1
            elif step == 4:  # Select Specifics based on Report Type
                if not client_name or not project_name or not report_type:  # Should not happen
                    console.print("[red]Error: Client/Project/Report Type not selected.[/red]")
                    step = 1
                    continue  # Reset

                project_dir = _resolve_project_dir(base_dir, client_name, project_name)
                if report_type == "session":
                    result = _select_session(project_dir, client_name, project_name)
                    if result is BACK_OPTION:
                        step -= 1
                        continue
                    elif isinstance(result, str):
                        session_date = result
                        step += 1
                    elif result is None:
                        return 1  # No sessions
                elif report_type == "day":
                    result = _select_day(project_dir, client_name, project_name)
                    if result is BACK_OPTION:
                        step -= 1
                        continue
                    elif isinstance(result, str):
                        specific_date = result
                        step += 1
                    elif result is None:
                        return 1  # No valid dates
                elif report_type == "project":
                    result = _select_date_range(project_dir, client_name, project_name)
                    if result is BACK_OPTION:
                        step -= 1
                        continue
                    elif isinstance(result, tuple):
                        date_range = result
                        step += 1
                    elif result is None:
                        date_range = None
                        step += 1  # Use full range
            elif step == 5:  # PDF Optimization Settings
                # Adding PDF optimization dialog as step 5
                console.print("\n[bold]PDF Optimization[/bold]")
                pdf_settings = get_pdf_optimization_settings()
                console.print(
                    f"[dim]Default settings: Quality={pdf_settings['image_quality']}, Max dimension={pdf_settings['max_dimension']}px, Format={pdf_settings['image_format']}[/dim]"
                )
                use_default_settings = _prompt_with_back(
                    "Use default PDF optimization settings?", choices=["y", "n"], default="y"
                )
                if use_default_settings is BACK_OPTION:
                    step -= 1
                    continue
                elif use_default_settings == "n":
                    # Could add custom optimization prompts here if needed
                    console.print(
                        "[yellow]Custom optimization not implemented yet, using defaults.[/yellow]"
                    )
                step += 1

            # Error handling / retry logic could be refined here
            # If result is None unexpectedly, maybe retry the step or go back?

        # Ensure all required variables are set after the loop
        if not client_name or not project_name or not report_type:
            console.print("[bold red]Setup incomplete. Exiting report generation.[/bold red]")
            return 1
        # Check specifics based on report type
        if report_type == "session" and not session_date:
            console.print("[bold red]Session date not selected. Exiting.[/bold red]")
            return 1
        if report_type == "day" and not specific_date:
            console.print(
                "[bold red]Specific date not selected for daily report. Exiting.[/bold red]"
            )
            return 1
        # Project report is fine without date_range (means use all)

    # ---- Existing Logic Post-Interactive/CLI Args ----
    # Prepare arguments for ReportGenerator based on interactive selections or CLI args
    output_dir = (
        cli_args.get("output") if use_command_line and cli_args else None
    )  # Or get interactively?
    pagesize = (
        cli_args.get("pagesize") if use_command_line and cli_args else None
    )  # Or get interactively?

    if not output_dir:
        project_dir = _resolve_project_dir(base_dir, client_name, project_name)
        output_dir = project_dir / "reports"
        output_dir.mkdir(parents=True, exist_ok=True)
    else:
        output_dir = Path(output_dir)

    # Prepare Optimization Settings
    pdf_settings = get_pdf_optimization_settings()
    optimize = should_optimize_pdf()
    optimization_params = {}
    if optimize:
        if use_command_line and cli_args:
            # Use command line settings if provided, otherwise use defaults from settings
            optimization_params = {
                "quality": cli_args.get("image_quality") or pdf_settings["image_quality"],
                "dpi": cli_args.get("image_dpi") or 150,
                "format": cli_args.get("image_format") or pdf_settings["image_format"],
                "max_dimension": cli_args.get("max_dimension") or pdf_settings["max_dimension"],
                "use_thumbnails": cli_args.get("thumbnails")
                if cli_args.get("thumbnails") is not None
                else pdf_settings["use_thumbnails"],
                "thumbnail_size": cli_args.get("thumbnail_size") or pdf_settings["thumbnail_size"],
                "compress": not cli_args.get("no_compression")
                if cli_args.get("no_compression") is not None
                else pdf_settings["compress_pdf"],
            }
        else:
            # Access pdf_settings as a dictionary instead of an object with attributes
            optimization_params = {
                "quality": pdf_settings["image_quality"],
                "dpi": 150,  # Set a default or get from settings if available
                "format": pdf_settings["image_format"],
                "max_dimension": pdf_settings["max_dimension"],
                "use_thumbnails": pdf_settings["use_thumbnails"],
                "thumbnail_size": pdf_settings["thumbnail_size"],
                "compress": pdf_settings["compress_pdf"],
            }

    # Use ReportGenerator (assuming it handles different report types)
    generator = ReportGenerator(
        screenshots_dir=str(base_dir),
        client_name=client_name,
        project_name=project_name,
        session_date=session_date if report_type == "session" else None,
        output_dir=str(output_dir),
        page_size=pagesize,
        image_quality=optimization_params.get("quality", 85),
        image_dpi=optimization_params.get("dpi", 150),
        image_format=optimization_params.get("format", "JPEG"),
        max_dimension=optimization_params.get("max_dimension", 1500),
        use_thumbnails=optimization_params.get("use_thumbnails", False),
        thumbnail_size=optimization_params.get("thumbnail_size", 800),
        compress_pdf=optimization_params.get("compress", True),
        report_type=report_type,
        specific_date=specific_date if report_type == "day" else None,
        date_range=date_range if report_type == "project" else None,
        debug=(cli_args.get("debug") if use_command_line and cli_args else False),
    )

    try:
        # TODO: Adapt ReportGenerator.generate() to accept the new structure
        # or call specific generation functions based on report_type.
        # Assuming ReportGenerator needs adaptation or specific functions are called:

        pdf_file_path = None
        if report_type == "session":
            if not session_date:
                console.print(
                    "[bold red]Error: Session date is missing for session report.[/bold red]"
                )
                return 1

            # Load the client info and session data first
            console.print("Loading client and session data...")
            generator.load_client_info()
            generator.load_session()

            # Generate the PDF with progress indicator
            console.print("[bold]Generating PDF report...[/bold]")
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Processing...", total=None)
                pdf_file_path = generate_single_session_pdf(generator)

        elif report_type == "day" or report_type == "project":
            # Load the client info and set up multi-session report first
            console.print("Loading client and session data...")
            generator.load_client_info()
            generator.setup_multi_session_report()

            # Generate the PDF with progress indicator
            console.print("[bold]Generating PDF report...[/bold]")
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Processing...", total=None)
                pdf_file_path = generate_multi_session_pdf(generator)

        if pdf_file_path:
            console.print(
                f"[bold green]PDF report generated successfully:[/bold green]\n{pdf_file_path}"
            )

            # Ask to open the PDF - Skip if in command line mode
            if not use_command_line:
                open_choice = _prompt_with_back(
                    "\nWould you like to open the PDF?", choices=["y", "n"], default="y"
                )
                if open_choice is BACK_OPTION:
                    console.print("[yellow]Not opening PDF.[/yellow]")
                elif open_choice == "y":
                    try:
                        import subprocess
                        import platform

                        # Cross-platform file opening (same approach as session logs)
                        system = platform.system()
                        file_path_str = str(pdf_file_path)

                        if system == "Darwin":
                            subprocess.run(["open", file_path_str], check=False)
                        elif system == "Linux":
                            subprocess.run(["xdg-open", file_path_str], check=False)
                        elif system == "Windows":
                            # On Windows, open file with default application
                            subprocess.Popen(["start", "", file_path_str], shell=True)
                        else:
                            console.print(f"[yellow]Unsupported platform for opening files: {system}[/yellow]")

                    except Exception as e:
                        console.print(f"[red]Failed to open PDF: {e}[/red]")

            # Handle Emailing (if requested)
            if use_command_line and cli_args and cli_args.get("email"):
                # Use command line email settings
                email_settings = get_email_settings()

                # Use command line settings if available
                sender = cli_args.get("sender")
                password = cli_args.get("password")
                smtp = cli_args.get("smtp")
                port = cli_args.get("port") or 587
                sender_name = cli_args.get("sender_name") or ""
                username = cli_args.get("username") or sender
                security = cli_args.get("security") or "TLS"
                recipient_type = cli_args.get("recipient_type") or "TO"

                # Process recipients
                recipients = []
                if cli_args.get("recipients"):
                    recipients = [email.strip() for email in cli_args.get("recipients").split(",")]

                # Try to get missing values from settings
                if (
                    not all([sender, password, smtp])
                    and email_settings
                    and email_settings.get("enabled", False)
                ):
                    sender = sender or email_settings.get("sender_email", "")
                    password = password or email_settings.get("password", "")
                    smtp = smtp or email_settings.get("smtp_server", "")
                    port = port or email_settings.get("smtp_port", 587)
                    sender_name = sender_name or email_settings.get("sender_name", "")
                    username = username or email_settings.get("username", sender)
                    security = security or email_settings.get("connection_security", "TLS")

                # Optional notes input (command-line mode): prompt in terminal
                notes_input = None
                try:
                    notes_input = _prompt_on_new_line(
                        "Add notes (use /n, \\n or <br> for new lines; use /b for bullets)",
                        default="",
                    )
                except Exception:
                    notes_input = None
                extra_lines = _parse_notes_lines(notes_input) if notes_input else None
                # Log raw notes to project logs
                if notes_input:
                    try:
                        generator.log_entry(
                            f"Report email notes (raw input): {notes_input}", terminal_message=""
                        )
                    except Exception:
                        pass

                # Build report meta
                report_meta = None
                try:
                    if report_type == "session" and generator.session_log:
                        import re as _re

                        dur = generator.session_log.session_duration or ""
                        h = (
                            int(_re.search(r"(\d+) hour", dur).group(1))
                            if _re.search(r"(\d+) hour", dur)
                            else 0
                        )
                        m = (
                            int(_re.search(r"(\d+) minute", dur).group(1))
                            if _re.search(r"(\d+) minute", dur)
                            else 0
                        )
                        start_raw = generator.session_log.session_start or ""
                        end_raw = generator.session_log.session_end or ""
                        date_only = start_raw.split(" ")[0] if start_raw else (session_date or "")
                        report_meta = {
                            "date": date_only,
                            "start_time": (start_raw.split(" ")[1][:5] if start_raw else ""),
                            "end_time": (end_raw.split(" ")[1][:5] if end_raw else ""),
                            "hours": h,
                            "minutes": m,
                        }
                    elif report_type in ("day", "project") and generator.multi_sessions:
                        stats = generator.multi_sessions.get_combined_stats()
                        total_seconds = (
                            int(stats["total_duration"].total_seconds())
                            if stats.get("total_duration")
                            else 0
                        )
                        hours = total_seconds // 3600
                        minutes = (total_seconds % 3600) // 60
                        report_meta = {
                            "date": specific_date or "",
                            "session_count": stats.get("total_sessions", 0),
                            "hours": hours,
                            "minutes": minutes,
                        }
                        if report_type == "project":
                            if date_range:
                                report_meta.update(
                                    {
                                        "range_start": date_range[0],
                                        "range_end": date_range[1],
                                    }
                                )
                            else:
                                # Fallback to earliest/latest from stats
                                rs = stats.get("earliest_session_str") or ""
                                re_ = stats.get("latest_session_str") or ""
                                if rs:
                                    report_meta["range_start"] = rs.split(" ")[0]
                                if re_:
                                    report_meta["range_end"] = re_.split(" ")[0]
                except Exception:
                    report_meta = None

                success = send_email(
                    pdf_file=pdf_file_path,
                    client_info=generator.client_info.dict() if generator.client_info else {},
                    project_name=project_name,
                    session_date=session_date
                    or specific_date
                    or (date_range[0] if date_range else ""),
                    sender_email=sender,
                    password=password,
                    smtp_server=smtp,
                    smtp_port=port,
                    sender_name=sender_name,
                    username=username,
                    connection_security=security,
                    recipients=recipients,
                    recipient_type=recipient_type,
                    debug=cli_args.get("debug", False),
                    report_type=report_type,
                    extra_body_lines=extra_lines,
                    report_meta=report_meta,
                )

                if success:
                    console.print("[green]Email sent successfully![/green]")
                    # Show list of recipients
                    recipients_to_show = []
                    if generator.client_info and generator.client_info.contact_email:
                        recipients_to_show.append(generator.client_info.contact_email)
                    if recipients:
                        recipients_to_show.extend(recipients)

                    if recipients_to_show:
                        console.print(f"Email sent to {', '.join(recipients_to_show)}")
                else:
                    console.print("[red]Failed to send email. Please check your settings.[/red]")
            elif not use_command_line:
                # Interactive email option for non-command line mode
                email_choice = _prompt_with_back(
                    "\nWould you like to email this report?", choices=["y", "n"], default="n"
                )
                if email_choice is BACK_OPTION:
                    # Go back to the optimization settings step
                    console.print(
                        "[yellow]Cancelling email and returning to report generation.[/yellow]"
                    )
                    pass  # Continue to return value below
                elif email_choice == "y":
                    # Get stored email settings
                    email_settings = get_email_settings()

                    if email_settings.get("enabled", False):
                        # Use stored settings
                        console.print(
                            "[green]Using email settings from application configuration.[/green]"
                        )
                        sender = email_settings.get("sender_email", "")
                        password = email_settings.get("password", "")
                        smtp = email_settings.get("smtp_server", "")
                        port = email_settings.get("smtp_port", 587)
                        sender_name = email_settings.get("sender_name", "")
                        username = email_settings.get("username", sender)
                        security = email_settings.get("connection_security", "TLS")

                        # Check for client email
                        if generator.client_info and generator.client_info.contact_email:
                            console.print(
                                f"[bold]Primary recipient:[/bold] {generator.client_info.contact_email} (from client settings)"
                            )
                        else:
                            console.print(
                                "[yellow]Warning: No client email found in client settings.[/yellow]"
                            )

                        # Get additional recipients from settings if available
                        recipients = []
                        if email_settings.get("default_recipients"):
                            recipients = email_settings.get("default_recipients", [])

                        # Use recipient type from settings (TO, CC, BCC) so defaults can be hidden if desired
                        recipient_type = email_settings.get("recipient_type", "TO") or "TO"

                        if recipients:
                            console.print(
                                f"[green]Automatically including default recipients as {recipient_type}[/green]"
                            )

                        # Optional notes input (interactive mode)
                        notes_input = _prompt_on_new_line(
                            "Add notes (use /n, \\n or <br> for new lines; use /b for bullets)",
                            default="",
                        )
                        extra_lines = _parse_notes_lines(notes_input) if notes_input else None
                        if notes_input:
                            try:
                                generator.log_entry(
                                    f"Report email notes (raw input): {notes_input}",
                                    terminal_message="",
                                )
                            except Exception:
                                pass

                        # Build report meta
                        report_meta = None
                        try:
                            if report_type == "session" and generator.session_log:
                                import re as _re

                                dur = generator.session_log.session_duration or ""
                                h = (
                                    int(_re.search(r"(\d+) hour", dur).group(1))
                                    if _re.search(r"(\d+) hour", dur)
                                    else 0
                                )
                                m = (
                                    int(_re.search(r"(\d+) minute", dur).group(1))
                                    if _re.search(r"(\d+) minute", dur)
                                    else 0
                                )
                                start_raw = generator.session_log.session_start or ""
                                end_raw = generator.session_log.session_end or ""
                                date_only = (
                                    start_raw.split(" ")[0] if start_raw else (session_date or "")
                                )
                                report_meta = {
                                    "date": date_only,
                                    "start_time": (
                                        start_raw.split(" ")[1][:5] if start_raw else ""
                                    ),
                                    "end_time": (end_raw.split(" ")[1][:5] if end_raw else ""),
                                    "hours": h,
                                    "minutes": m,
                                }
                            elif report_type in ("day", "project") and generator.multi_sessions:
                                stats = generator.multi_sessions.get_combined_stats()
                                total_seconds = (
                                    int(stats["total_duration"].total_seconds())
                                    if stats.get("total_duration")
                                    else 0
                                )
                                hours = total_seconds // 3600
                                minutes = (total_seconds % 3600) // 60
                                report_meta = {
                                    "date": specific_date or "",
                                    "session_count": stats.get("total_sessions", 0),
                                    "hours": hours,
                                    "minutes": minutes,
                                }
                                if report_type == "project":
                                    if date_range:
                                        report_meta.update(
                                            {
                                                "range_start": date_range[0],
                                                "range_end": date_range[1],
                                            }
                                        )
                                    else:
                                        rs = stats.get("earliest_session_str") or ""
                                        re_ = stats.get("latest_session_str") or ""
                                        if rs:
                                            report_meta["range_start"] = rs.split(" ")[0]
                                        if re_:
                                            report_meta["range_end"] = re_.split(" ")[0]
                        except Exception:
                            report_meta = None

                        success = send_email(
                            pdf_file=pdf_file_path,
                            client_info=generator.client_info.dict()
                            if generator.client_info
                            else {},
                            project_name=project_name,
                            session_date=session_date
                            or specific_date
                            or (date_range[0] if date_range else ""),
                            sender_email=sender,
                            password=password,
                            smtp_server=smtp,
                            smtp_port=port,
                            sender_name=sender_name,
                            username=username,
                            connection_security=security,
                            recipients=recipients,
                            recipient_type=recipient_type,
                            debug=False,
                            report_type=report_type,
                            extra_body_lines=extra_lines,
                            report_meta=report_meta,
                        )

                        if success:
                            console.print("[green]Email sent successfully![/green]")
                            # Show list of recipients
                            recipients_to_show = []
                            if generator.client_info and generator.client_info.contact_email:
                                recipients_to_show.append(generator.client_info.contact_email)
                            if recipients:
                                recipients_to_show.extend(recipients)

                            if recipients_to_show:
                                console.print(f"Email sent to {', '.join(recipients_to_show)}")
                        else:
                            console.print(
                                "[red]Failed to send email. Please check your settings.[/red]"
                            )
                    else:
                        console.print(
                            "[yellow]Email settings not configured. Please configure email settings first.[/yellow]"
                        )

            # Ask about returning to main script (only in interactive mode)
            if not use_command_line:
                console.print("\n[bold]Report generation complete![/bold]")
                return_choice = _prompt_with_back(
                    "Would you like to return to the main menu?", choices=["y", "n"], default="y"
                )
                if return_choice is BACK_OPTION:
                    # Can't go back further, so treat as 'no'
                    console.print("[yellow]Exiting ScreenShooter. Goodbye![/yellow]")
                    return 0
                elif return_choice == "n":
                    console.print("\nExiting ScreenShooter. Goodbye!")
                    return 0
                else:
                    # Return with exit code 1 to signal to main script we want to return to menu
                    return 1

            return 0
        else:
            console.print("[bold red]Failed to generate PDF report.[/bold red]")
            return 1

    except Exception as e:
        logger.error(f"Error generating report: {e}", exc_info=True)
        console.print(f"[bold red]An error occurred during report generation: {e}[/bold red]")
        return 1


@click.command()
@click.option("--dir", help="Path to screenshots directory (default: use from settings)")
@click.option("--client", help="Client name")
@click.option("--project", help="Project name")
@click.option(
    "--session",
    help="Session date (format: YYYY-MM-DD_HH-MM-SS), uses most recent if not specified",
)
@click.option("--output", help="Output directory for the PDF report")
@click.option(
    "--pagesize",
    type=click.Choice(["A4", "letter"]),
    help="PDF page size (overrides client preference)",
)
@click.option(
    "--report-type",
    type=click.Choice(["session", "day", "project"]),
    default="session",
    help="Report type: single session, day-based, or project-based",
)
@click.option("--date", help="Specific date for day reports (format: YYYY-MM-DD)")
@click.option("--start-date", help="Start date for project reports (format: YYYY-MM-DD)")
@click.option("--end-date", help="End date for project reports (format: YYYY-MM-DD)")
@click.option("--email", is_flag=True, help="Send PDF report by email")
@click.option("--sender", help="Sender email address")
@click.option("--sender-name", help="Sender display name")
@click.option("--username", help="SMTP username (if different from sender email)")
@click.option("--password", help="Sender email password")
@click.option("--smtp", help="SMTP server address")
@click.option("--port", type=int, default=587, help="SMTP server port")
@click.option(
    "--security",
    type=click.Choice(["TLS", "SSL", "None"]),
    default="TLS",
    help="Connection security",
)
@click.option("--recipients", help="Additional recipients (comma-separated)")
@click.option(
    "--recipient-type",
    type=click.Choice(["TO", "CC", "BCC"]),
    default="TO",
    help="Type for additional recipients",
)
@click.option("--image-quality", type=int, help="Image quality (1-100, lower = smaller file)")
@click.option("--image-dpi", type=int, default=150, help="Image DPI resolution")
@click.option(
    "--image-format", type=click.Choice(["JPEG", "PNG", "WebP"]), help="Image format in PDF"
)
@click.option("--max-dimension", type=int, help="Maximum image dimension (width or height)")
@click.option("--thumbnails", is_flag=True, help="Use thumbnails instead of full-size images")
@click.option("--thumbnail-size", type=int, help="Thumbnail size when --thumbnails is used")
@click.option("--no-compression", is_flag=True, help="Disable PDF compression")
@click.option("--debug", is_flag=True, help="Enable debug logging")
def main(
    dir,
    client,
    project,
    session,
    output,
    pagesize,
    report_type,
    date,
    start_date,
    end_date,
    email,
    sender,
    sender_name,
    username,
    password,
    smtp,
    port,
    security,
    recipients,
    recipient_type,
    image_quality,
    image_dpi,
    image_format,
    max_dimension,
    thumbnails,
    thumbnail_size,
    no_compression,
    debug,
):
    """Generate PDF reports from screenshot sessions."""
    if not any([client, project]):  # If no options are provided, use interactive mode
        return interactive_report_generation()

    # Use command line mode, but leverage the same interactive function code
    return interactive_report_generation(
        use_command_line=True,
        cli_args={
            "dir": dir,
            "client": client,
            "project": project,
            "session": session,
            "output": output,
            "pagesize": pagesize,
            "report_type": report_type,
            "date": date,
            "start_date": start_date,
            "end_date": end_date,
            "email": email,
            "sender": sender,
            "sender_name": sender_name,
            "username": username,
            "password": password,
            "smtp": smtp,
            "port": port,
            "security": security,
            "recipients": recipients,
            "recipient_type": recipient_type,
            "image_quality": image_quality,
            "image_dpi": image_dpi,
            "image_format": image_format,
            "max_dimension": max_dimension,
            "thumbnails": thumbnails,
            "thumbnail_size": thumbnail_size,
            "no_compression": no_compression,
            "debug": debug,
        },
    )


if __name__ == "__main__":
    import sys

    sys.exit(main())
