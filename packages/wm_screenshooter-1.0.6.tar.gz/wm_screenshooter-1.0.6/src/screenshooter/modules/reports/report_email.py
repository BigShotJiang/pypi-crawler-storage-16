#!/usr/bin/env python3
"""Email functionality for ScreenShooter Mac reports."""

import logging
import smtplib
import traceback
from datetime import datetime
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from typing import Any, Dict, List, Optional

from rich.console import Console

# Import S3 helper
from screenshooter.modules.s3 import S3Helper, generate_custom_link, get_s3_settings, is_s3_enabled

# Import the necessary helpers for custom links
from screenshooter.modules.settings.settings_helper import is_s3_custom_link_enabled

# Constants for URL expiration times
ONE_DAY_SECONDS = 86400
THREE_DAYS_SECONDS = 259200

# Initialize rich console
console = Console()

# Configure logging
logger = logging.getLogger("report_email")
logger.setLevel(logging.INFO)

# Remove any existing handlers to prevent duplicate logging
for handler in logger.handlers[:]:
    logger.removeHandler(handler)

# Prevent propagation to root logger (which might have console handlers)
logger.propagate = False


def log_entry(message: str, terminal_message: Optional[str] = None, level: str = "info") -> None:
    """Log a message to both the log file and terminal.

    Args:
        message: Message to log to file
        terminal_message: Optional formatted message for terminal (if None or empty, no terminal output)
        level: Log level (info, warning, error, debug)
    """
    # Log to the appropriate level
    if level == "error":
        logger.error(message)
    elif level == "warning":
        logger.warning(message)
    elif level == "debug":
        logger.debug(message)
    else:
        logger.info(message)

    # Display in terminal if a message is provided
    if terminal_message and terminal_message.strip():  # Only show non-empty terminal messages
        if level == "error":
            console.print(f"[bold red]{terminal_message}[/bold red]")
        elif level == "warning":
            console.print(f"[bold yellow]{terminal_message}[/bold yellow]")
        else:
            console.print(terminal_message)


def setup_report_logging(project_path: Path) -> None:
    """Set up logging to write to the project's log files.

    Instead of using a separate report-generation.log file, this will now
    use the project's primary log files:
    - {project_name}_log.txt
    - {project_name}_report_generation_log.txt
    """
    # Extract project name from the path
    project_name = project_path.name

    # Define the log files
    master_log_file = project_path / f"{project_name}_log.txt"
    report_log_file = project_path / f"{project_name}_report_generation_log.txt"

    # Create the log files if they don't exist
    master_log_file.touch(exist_ok=True)
    report_log_file.touch(exist_ok=True)

    # Remove any existing handlers
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)

    # Prevent propagation to root logger
    logger.propagate = False

    # Create a custom handler that writes to both files
    class DualFileHandler(logging.Handler):
        def emit(self, record):
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            message = record.getMessage()
            entry = f"[{timestamp}] {message}"

            # Write to both log files
            try:
                with open(master_log_file, "a") as f:
                    f.write(f"{entry}\n")
                with open(report_log_file, "a") as f:
                    f.write(f"{entry}\n")
            except Exception:
                # Fall back to standard logging if file write fails
                pass

    # Add the custom handler
    logger.addHandler(DualFileHandler())


def send_email(
    pdf_file: Path,
    client_info: dict[str, Any],
    project_name: str,
    session_date: str,
    sender_email: str,
    password: str,
    smtp_server: str,
    smtp_port: int = 587,
    sender_name: Optional[str] = None,
    username: Optional[str] = None,
    connection_security: str = "TLS",
    recipients: Optional[list[str]] = None,
    recipient_type: str = "TO",
    debug: bool = False,
    report_type: str = "session",
    extra_body_lines: Optional[List[str]] = None,
    report_meta: Optional[Dict[str, Any]] = None,
) -> bool:
    """Send the PDF report as an email attachment or link.

    Args:
        pdf_file: Path to the PDF file to send
        client_info: Client information dictionary
        project_name: Name of the project
        session_date: Session date string
        sender_email: Sender's email address
        password: Sender's email password
        smtp_server: SMTP server address
        smtp_port: SMTP server port
        sender_name: Optional display name for sender
        username: Optional SMTP username (if different from sender_email)
        connection_security: Security type ("TLS", "SSL", or "None")
        recipients: List of additional recipient email addresses
        recipient_type: Type for additional recipients ("TO", "CC", "BCC")
        debug: Enable debug logging

    Returns:
        True if email was sent successfully, False otherwise
    """
    if not pdf_file or not pdf_file.exists():
        log_entry("No PDF file to send", "[red]No PDF file to send[/red]")
        return False

    # Set up logging to the project's report-generation.log
    project_path = pdf_file.parent.parent  # Go up from reports/ to project directory
    setup_report_logging(project_path)

    # Use sender_email as username if not provided
    if username is None:
        username = sender_email

    # Client email is ALWAYS the primary recipient (TO:)
    to_recipients = []
    cc_recipients = []
    bcc_recipients = []

    # Add client email as primary recipient if available
    client_email = None
    if client_info and client_info.get("contact_email"):
        client_email = client_info.get("contact_email")
        to_recipients.append(client_email)
        # logger.info(f"Using client email as primary recipient: {client_email}")
    else:
        logger.warning("No client email found in client settings")

    # Add any additional recipients based on recipient_type
    if recipients:
        for email in recipients:
            if email and email not in to_recipients:  # Avoid duplicates
                if recipient_type == "TO":
                    to_recipients.append(email)
                elif recipient_type == "CC":
                    cc_recipients.append(email)
                elif recipient_type == "BCC":
                    bcc_recipients.append(email)
                if debug:
                    logger.debug(f"Added {recipient_type} recipient: {email}")

    if not to_recipients and not cc_recipients and not bcc_recipients:
        logger.error("No recipient email addresses available")
        return False

    try:
        # Create message
        msg = MIMEMultipart()

        # Set sender with optional display name
        if sender_name:
            msg["From"] = f"{sender_name} <{sender_email}>"
        else:
            msg["From"] = sender_email

        # Set recipients by type
        if to_recipients:
            msg["To"] = ", ".join(to_recipients)
        if cc_recipients:
            msg["Cc"] = ", ".join(cc_recipients)
        # BCC recipients are not added to header

        # Combine all recipients for delivery (not used, but kept for documentation)
        # to_recipients + cc_recipients + bcc_recipients

        # Subject reflects report type
        if report_type == "day":
            subject_label = "Day Report"
        elif report_type == "project":
            subject_label = "Project Report"
        else:
            subject_label = "Session Report"

        # Enhance subject with range for project if available
        subject_suffix = f" - {sender_name}" if sender_name else ""
        if (
            report_type == "project"
            and report_meta
            and report_meta.get("range_start")
            and report_meta.get("range_end")
        ):
            msg["Subject"] = (
                f"{subject_label}: {project_name} - {report_meta['range_start']} to {report_meta['range_end']}{subject_suffix}"
            )
        else:
            msg["Subject"] = f"{subject_label}: {project_name} - {session_date}{subject_suffix}"

        # Initialize S3 helper if needed
        s3_helper: Optional[S3Helper] = None
        s3_settings = get_s3_settings()
        pdf_url: Optional[str] = None

        if is_s3_enabled():
            log_entry("S3/R2 is enabled. Initializing S3 helper.", "")
            s3_helper = S3Helper(
                endpoint_url=s3_settings["endpoint_url"],
                access_key_id=s3_settings["access_key_id"],
                secret_access_key=s3_settings["secret_access_key"],
                bucket_name=s3_settings["bucket_name"],
                region=s3_settings["region"],
                debug=debug,
            )

            # Upload PDF to S3/R2
            log_entry(f"Uploading report PDF '{pdf_file.name}' to S3/R2...", "")
            object_name = s3_helper.upload_file(pdf_file)

            if object_name:
                log_entry(
                    f"Successfully uploaded to S3/R2 as object: {object_name}",
                    "[green]Successfully uploaded to S3 bucket[/green]",
                )
                expiration_seconds = s3_settings["url_expiration"]

                if is_s3_custom_link_enabled():
                    log_entry("Custom link feature enabled. Generating custom URL...")
                    custom_success, pdf_url = generate_custom_link(
                        s3_helper_instance=s3_helper,
                        object_name=object_name,
                        expiration=expiration_seconds,
                        debug=debug,
                    )

                    if custom_success and pdf_url:
                        log_entry(
                            f"Generated custom link: {pdf_url}",
                            "[green]Generated custom link[/green]",
                        )
                    else:
                        log_entry(
                            "Custom URL generation failed. Falling back to direct S3 presigned URL.",
                            "Custom URL generation failed. Falling back to direct S3 presigned URL.",
                        )
                        pdf_url = s3_helper.generate_presigned_url(
                            object_name, expiration=expiration_seconds
                        )
                        if pdf_url:
                            log_entry(
                                f"Using fallback presigned URL: {pdf_url}",
                                "[green]Generated fallback URL[/green]",
                            )
                        else:
                            log_entry(
                                "Failed to generate fallback presigned S3 URL. No URL will be included in the email.",
                                "[red]Failed to generate URL[/red]",
                            )
                else:
                    log_entry("Generating standard S3 presigned URL...", "")
                    pdf_url = s3_helper.generate_presigned_url(
                        object_name, expiration=expiration_seconds
                    )
                    if pdf_url:
                        log_entry(
                            f"Generated presigned URL: {pdf_url}", "[green]Generated URL[/green]"
                        )
                    else:
                        log_entry(
                            "Failed to generate presigned S3 URL. No URL will be included in the email.",
                            "[red]Failed to generate URL[/red]",
                        )
            else:
                log_entry(
                    "Failed to upload PDF to S3/R2. No URL will be included.",
                    "[red]Failed to upload PDF[/red]",
                )

        # If S3 is enabled and we are not attaching the PDF (i.e. we rely on an S3 link),
        # then we must have a valid URL. If we don't, abort sending the email entirely.
        if is_s3_enabled() and not s3_settings["send_attachment"] and not pdf_url:
            log_entry(
                "S3 upload/link generation failed. Email will not be sent.",
                "[red]S3 upload/link failed. Email will not be sent.[/red]",
                level="error",
            )
            return False

        # Construct email body (plain text)
        body_parts = []
        client_name_display = client_info.get("contact_name", "") if client_info else ""

        # Add greeting
        if client_name_display:
            body_parts.append(f"Hello {client_name_display},")
            body_parts.append("")  # Add a blank line

        # Compose body per report type using report_meta
        if report_type == "session":
            date_str = (
                (report_meta.get("date") if report_meta else session_date)
                if report_meta
                else session_date
            )
            start_time = report_meta.get("start_time") if report_meta else ""
            end_time = report_meta.get("end_time") if report_meta else ""
            hours = report_meta.get("hours", 0) if report_meta else 0
            minutes = report_meta.get("minutes", 0) if report_meta else 0

            if project_name:
                if start_time and end_time:
                    body_parts.append(
                        f"Attached is the session report for the {project_name} project from {start_time} to {end_time} on {date_str}."
                    )
                else:
                    body_parts.append(
                        f"Attached is the session report for the {project_name} project on {date_str}."
                    )
            else:
                body_parts.append(f"Attached is the session report on {date_str}.")

            body_parts.append(
                "\nThis report includes all screenshots taken during this work session, along with any notes and captions that were added."
            )
            body_parts.append(
                f"\nTotal time tracked: {hours} hour{'s' if hours != 1 else ''} and {minutes} minute{'s' if minutes != 1 else ''}."
            )

        elif report_type == "day":
            date_str = (
                (report_meta.get("date") if report_meta else session_date)
                if report_meta
                else session_date
            )
            session_count = report_meta.get("session_count", 0) if report_meta else 0
            hours = report_meta.get("hours", 0) if report_meta else 0
            minutes = report_meta.get("minutes", 0) if report_meta else 0

            body_parts.append(
                f"Attached is the day report for the {project_name} project on {date_str}."
            )
            body_parts.append(
                f"\nThis summary includes all {session_count} work sessions completed that day, with their screenshots, notes, and captions."
            )
            body_parts.append(
                f"\nTotal time worked: {hours} hour{'s' if hours != 1 else ''} and {minutes} minute{'s' if minutes != 1 else ''} across {session_count} sessions."
            )

        else:  # project
            session_count = report_meta.get("session_count", 0) if report_meta else 0
            hours = report_meta.get("hours", 0) if report_meta else 0
            minutes = report_meta.get("minutes", 0) if report_meta else 0
            range_start = report_meta.get("range_start", "") if report_meta else ""
            range_end = report_meta.get("range_end", "") if report_meta else ""

            body_parts.append(
                f"Attached is the project report for the {project_name} project from {range_start} to {range_end}."
            )
            body_parts.append(
                f"\nThis summary includes all {session_count} work sessions completed in this period, with their screenshots, notes, and captions."
            )
            body_parts.append(
                f"\nTotal time worked: {hours} hour{'s' if hours != 1 else ''} and {minutes} minute{'s' if minutes != 1 else ''} across {session_count} sessions."
            )

        # Add the PDF link if available
        if pdf_url:
            # Determine expiration string
            expiration_seconds = s3_settings["url_expiration"]
            if expiration_seconds == ONE_DAY_SECONDS:
                expiration_str = "1 day"
            elif expiration_seconds == THREE_DAYS_SECONDS:
                expiration_str = "3 days"
            else:
                hours = expiration_seconds // 3600
                expiration_str = f"{hours} hour{'s' if hours != 1 else ''}"
            body_parts.append(
                f"\nYou can download the report PDF here (link expires in {expiration_str}): {pdf_url}"
            )
        elif is_s3_enabled() and not s3_settings["send_attachment"]:
            body_parts.append("\n(There was an error generating the download link for the report.)")

        # Add password protection notice if applicable
        if client_info and client_info.get("pdf_password"):
            body_parts.append("\nThe attached PDF report is password protected.")
            body_parts.append("You will need the password to open the document.")

        # Insert any extra body lines (e.g., notes) before closing
        if extra_body_lines:
            body_parts.append("")
            body_parts.append("Notes:")
            for line in extra_body_lines:
                cleaned = (line or "").strip()
                if not cleaned:
                    continue
                # Preserve user's bullets only if provided
                body_parts.append(cleaned)

        # Add closing (only if a sender display name is set)
        if sender_name:
            body_parts.append("")
            body_parts.append("Best regards,")
            body_parts.append(sender_name)

        body_text = "\n".join(body_parts)

        # Construct simple HTML alternative
        html_parts = []
        if client_name_display:
            html_parts.append(f"<p>Hello {client_name_display},</p>")

        if report_type == "session":
            date_str = (
                (report_meta.get("date") if report_meta else session_date)
                if report_meta
                else session_date
            )
            start_time = report_meta.get("start_time") if report_meta else ""
            end_time = report_meta.get("end_time") if report_meta else ""
            hours = report_meta.get("hours", 0) if report_meta else 0
            minutes = report_meta.get("minutes", 0) if report_meta else 0
            if start_time and end_time:
                html_parts.append(
                    f"<p>Attached is the <strong>session report</strong> for the <em>{project_name}</em> project from {start_time} to {end_time} on {date_str}.</p>"
                )
            else:
                html_parts.append(
                    f"<p>Attached is the <strong>session report</strong> for the <em>{project_name}</em> project on {date_str}.</p>"
                )
            html_parts.append(
                "<p>This report includes all screenshots taken during this work session, along with any notes and captions that were added.</p>"
            )
            html_parts.append(
                f"<p>Total time tracked: {hours} hour{'s' if hours != 1 else ''} and {minutes} minute{'s' if minutes != 1 else ''}.</p>"
            )

        elif report_type == "day":
            date_str = (
                (report_meta.get("date") if report_meta else session_date)
                if report_meta
                else session_date
            )
            session_count = report_meta.get("session_count", 0) if report_meta else 0
            hours = report_meta.get("hours", 0) if report_meta else 0
            minutes = report_meta.get("minutes", 0) if report_meta else 0
            html_parts.append(
                f"<p>Attached is the <strong>day report</strong> for the <em>{project_name}</em> project on {date_str}.</p>"
            )
            html_parts.append(
                f"<p>This summary includes all {session_count} work sessions completed that day, with their screenshots, notes, and captions.</p>"
            )
            html_parts.append(
                f"<p>Total time worked: {hours} hour{'s' if hours != 1 else ''} and {minutes} minute{'s' if minutes != 1 else ''} across {session_count} sessions.</p>"
            )

        else:  # project
            session_count = report_meta.get("session_count", 0) if report_meta else 0
            hours = report_meta.get("hours", 0) if report_meta else 0
            minutes = report_meta.get("minutes", 0) if report_meta else 0
            range_start = report_meta.get("range_start", "") if report_meta else ""
            range_end = report_meta.get("range_end", "") if report_meta else ""
            html_parts.append(
                f"<p>Attached is the <strong>project report</strong> for the <em>{project_name}</em> project from {range_start} to {range_end}.</p>"
            )
            html_parts.append(
                f"<p>This summary includes all {session_count} work sessions completed in this period, with their screenshots, notes, and captions.</p>"
            )
            html_parts.append(
                f"<p>Total time worked: {hours} hour{'s' if hours != 1 else ''} and {minutes} minute{'s' if minutes != 1 else ''} across {session_count} sessions.</p>"
            )

        if pdf_url:
            html_parts.append(
                f'<p>You can download the report PDF here (link expires in {expiration_str}): <a href="{pdf_url}">{pdf_url}</a></p>'
            )
        elif is_s3_enabled() and not s3_settings["send_attachment"]:
            html_parts.append(
                "<p>(There was an error generating the download link for the report.)</p>"
            )

        if client_info and client_info.get("pdf_password"):
            html_parts.append(
                "<p>The attached PDF report is password protected.<br>You will need the password to open the document.</p>"
            )

        if extra_body_lines:
            html_parts.append("<p><strong>Notes:</strong></p>")
            in_list = False
            for raw in extra_body_lines:
                line = (raw or "").strip()
                if not line:
                    continue
                if line.startswith("- "):
                    if not in_list:
                        html_parts.append("<ul>")
                        in_list = True
                    html_parts.append(f"<li>{line[2:].strip()}</li>")
                else:
                    if in_list:
                        html_parts.append("</ul>")
                        in_list = False
                    html_parts.append(f"<p>{line.replace('\n', '<br>')}</p>")
            if in_list:
                html_parts.append("</ul>")

        # Add closing (only if a sender display name is set)
        if sender_name:
            html_parts.append(f"<p>Best regards,<br>{sender_name}</p>")
        body_html = "\n".join(html_parts)

        alternative = MIMEMultipart("alternative")
        alternative.attach(MIMEText(body_text, "plain"))
        alternative.attach(MIMEText(body_html, "html"))
        msg.attach(alternative)

        # Attach PDF if S3 is disabled or if send_attachment is True
        if not is_s3_enabled() or get_s3_settings()["send_attachment"]:
            # Attach PDF file
            with open(pdf_file, "rb") as f:
                attachment = MIMEApplication(f.read(), _subtype="pdf")
                attachment.add_header("Content-Disposition", "attachment", filename=pdf_file.name)
                msg.attach(attachment)

        # Build full recipient list for SMTP envelope and logging
        recipient_list: List[str] = []
        if to_recipients:
            recipient_list.extend(to_recipients)
        if cc_recipients:
            recipient_list.extend(cc_recipients)
        if bcc_recipients:
            recipient_list.extend(bcc_recipients)

        # Connect to SMTP server with appropriate security
        if connection_security == "SSL":
            server = smtplib.SMTP_SSL(smtp_server, smtp_port)
        else:
            server = smtplib.SMTP(smtp_server, smtp_port)

            if connection_security == "TLS":
                server.starttls()

        # Login and send
        server.login(username, password)
        server.send_message(msg, to_addrs=recipient_list)
        server.quit()

        # Format recipient info for the log
        recipient_count = len(recipient_list)
        recipient_str = ", ".join(recipient_list)

        # Log to both terminal and file
        log_entry(
            f"Email sent successfully to {recipient_count} recipient(s): {recipient_str}",
            f"[green]Email sent successfully to {recipient_count} recipient(s)[/green]",
        )

        # If we attached a file or used S3, add that to the log
        if not is_s3_enabled() or get_s3_settings()["send_attachment"]:
            log_entry(
                f"PDF file '{pdf_file.name}' was attached to the email",
                "[blue]PDF file was attached to the email[/blue]",
            )
        elif pdf_url:
            log_entry(
                f"Email included link to download the PDF: {pdf_url}",
                "[blue]Email included link to download the PDF[/blue]",
            )

        return True

    except Exception as e:
        # Log the error with more details for troubleshooting
        error_msg = f"Error sending email: {e}"
        log_entry(error_msg, f"[red]Failed to send email: {e}[/red]", level="error")

        # Add more detailed debug information if needed
        if debug:
            stack_trace = traceback.format_exc()
            log_entry(f"Email error details: {stack_trace}", level="debug")
        return False
