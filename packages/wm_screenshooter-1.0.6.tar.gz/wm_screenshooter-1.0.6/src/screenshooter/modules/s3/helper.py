#!/usr/bin/env python3
"""S3/R2 helper module for ScreenShooter Mac."""

import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import boto3
from botocore.exceptions import ClientError
from rich.console import Console

# Initialize rich console
console = Console()

# Configure logging
logger = logging.getLogger("s3_helper")
logger.setLevel(logging.INFO)


def log_entry(message: str, terminal_message: Optional[str] = None, debug: bool = False) -> None:
    """Log a message to both the log file and terminal.

    Args:
        message: Message to log to file
        terminal_message: Optional formatted message for terminal (if None, uses message)
        debug: Whether this is a debug message (only shown in terminal if debug=True)
    """
    logger.info(message)
    if debug:
        if terminal_message:
            console.print(terminal_message)
        else:
            console.print(message)


def setup_report_logging(project_path: Path) -> None:
    """Set up logging to write to the project's report-generation.log file."""
    log_file = project_path / "report-generation.log"
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)


# Create a file handler for detailed logging
log_file = Path.home() / ".config" / "screenshooter" / "logs" / "s3_helper.log"
log_file.parent.mkdir(parents=True, exist_ok=True)
file_handler = logging.FileHandler(log_file)
file_handler.setLevel(logging.DEBUG)
file_formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
file_handler.setFormatter(file_formatter)
logger.addHandler(file_handler)

# Create a console handler that only shows errors
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.ERROR)
console_formatter = logging.Formatter("%(levelname)s: %(message)s")
console_handler.setFormatter(console_formatter)
logger.addHandler(console_handler)


class S3Helper:
    """Helper class for S3/R2 operations."""

    def __init__(
        self,
        endpoint_url: str,
        access_key_id: str,
        secret_access_key: str,
        bucket_name: str,
        region: str = "auto",
        debug: bool = False,
    ):
        """Initialize S3 helper with credentials and configuration.

        Args:
            endpoint_url: S3/R2 endpoint URL
            access_key_id: Access key ID
            secret_access_key: Secret access key
            bucket_name: Bucket name
            region: Region name (default: "auto")
            debug: Enable debug logging
        """
        self.endpoint_url = endpoint_url
        self.access_key_id = access_key_id
        self.secret_access_key = secret_access_key
        self.bucket_name = bucket_name
        self.region = region
        self.debug = debug

        # Initialize S3 client
        self.s3_client = boto3.client(
            "s3",
            endpoint_url=endpoint_url,
            aws_access_key_id=access_key_id,
            aws_secret_access_key=secret_access_key,
            region_name=region,
        )

        if debug:
            log_entry(
                "S3 helper initialized with debug mode enabled",
                "[yellow]S3 helper initialized with debug mode enabled[/yellow]",
                debug,
            )

    def upload_file(
        self,
        file_path: Path,
        object_name: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> Optional[str]:
        """Upload a file to S3/R2.

        Args:
            file_path: Path to the file to upload
            object_name: S3 object name (default: file name)
            metadata: Optional metadata to attach to the object

        Returns:
            str: Object key if successful, None if failed
        """
        try:
            # Use file name as object name if not specified
            if object_name is None:
                object_name = file_path.name

            # Add timestamp to object name to ensure uniqueness
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            object_name = f"{Path(object_name).stem}_{timestamp}{Path(object_name).suffix}"

            # Get path prefix from settings
            from screenshooter.modules.settings.settings_helper import get_settings

            settings = get_settings()
            path_prefix = settings.s3.path_prefix.strip("/")  # Remove leading/trailing slashes

            # Combine path prefix with object name
            if path_prefix:
                object_name = f"{path_prefix}/{object_name}"

            # Upload file
            extra_args = {}
            if metadata:
                extra_args["Metadata"] = metadata

            self.s3_client.upload_file(
                str(file_path), self.bucket_name, object_name, ExtraArgs=extra_args
            )

            if self.debug:
                log_entry(
                    f"Successfully uploaded {file_path} to {object_name}",
                    f"[green]Successfully uploaded {file_path} to {object_name}[/green]",
                    self.debug,
                )

            return object_name

        except ClientError as e:
            log_entry(
                f"Error uploading file to S3: {e}", f"[red]Error uploading file to S3: {e}[/red]"
            )
            return None
        except Exception as e:
            log_entry(
                f"Unexpected error uploading file: {e}",
                f"[red]Unexpected error uploading file: {e}[/red]",
            )
            return None

    def generate_presigned_url(self, object_name: str, expiration: int = 3600) -> Optional[str]:
        """Generate a presigned URL for an S3/R2 object.

        Args:
            object_name: Name of the object
            expiration: URL expiration time in seconds (default: 1 hour)

        Returns:
            str: Presigned URL if successful, None if failed
        """
        try:
            url = self.s3_client.generate_presigned_url(
                "get_object",
                Params={"Bucket": self.bucket_name, "Key": object_name},
                ExpiresIn=expiration,
            )

            if self.debug:
                log_entry(
                    f"Generated presigned URL for {object_name}",
                    f"[green]Generated presigned URL for {object_name}[/green]",
                    self.debug,
                )

            return url

        except ClientError as e:
            log_entry(
                f"Error generating presigned URL: {e}",
                f"[red]Error generating presigned URL: {e}[/red]",
            )
            return None
        except Exception as e:
            log_entry(
                f"Unexpected error generating presigned URL: {e}",
                f"[red]Unexpected error generating presigned URL: {e}[/red]",
            )
            return None

    def delete_object(self, object_name: str) -> bool:
        """Delete an object from S3/R2.

        Args:
            object_name: Name of the object to delete

        Returns:
            bool: True if successful, False if failed
        """
        try:
            self.s3_client.delete_object(Bucket=self.bucket_name, Key=object_name)

            if self.debug:
                log_entry(
                    f"Successfully deleted {object_name}",
                    f"[green]Successfully deleted {object_name}[/green]",
                    self.debug,
                )

            return True

        except ClientError as e:
            log_entry(f"Error deleting object: {e}", f"[red]Error deleting object: {e}[/red]")
            return False
        except Exception as e:
            log_entry(
                f"Unexpected error deleting object: {e}",
                f"[red]Unexpected error deleting object: {e}[/red]",
            )
            return False


def get_s3_settings() -> Dict[str, Any]:
    """Get S3/R2 settings from application settings."""
    from screenshooter.modules.settings.settings_helper import get_settings

    settings = get_settings()

    # No need for expiration mapping since we store seconds directly
    return {
        "enabled": settings.s3.enabled,
        "endpoint_url": settings.s3.endpoint_url,
        "access_key_id": settings.s3.access_key_id,
        "secret_access_key": settings.s3.secret_access_key,
        "bucket_name": settings.s3.bucket_name,
        "region": settings.s3.region,
        "url_expiration": settings.s3.url_expiration,  # Use the value directly from settings
        "send_attachment": settings.s3.send_attachment,
        "path_prefix": settings.s3.path_prefix,
    }


def is_s3_enabled() -> bool:
    """Check if S3/R2 functionality is enabled."""
    from screenshooter.modules.settings.settings_helper import get_settings

    return get_settings().s3.enabled
