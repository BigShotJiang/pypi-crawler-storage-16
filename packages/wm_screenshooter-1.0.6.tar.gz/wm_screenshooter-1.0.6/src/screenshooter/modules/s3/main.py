#!/usr/bin/env python3
"""Main entry point for S3/R2 storage module."""

import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console

from screenshooter.modules.s3.helper import S3Helper, get_s3_settings, is_s3_enabled
from screenshooter.modules.s3.vanity_helper import generate_custom_link

# Initialize rich console
console = Console()


@click.group()
def cli():
    """ScreenShooter S3/R2 Storage Module CLI."""
    pass


@cli.command()
@click.option("--file", required=True, help="File to upload to S3/R2", type=click.Path(exists=True))
@click.option("--object-name", help="Object name in S3/R2 (default: file name)")
@click.option("--debug", is_flag=True, help="Enable debug output")
def upload(file: str, object_name: Optional[str], debug: bool):
    """Upload a file to S3/R2 storage."""
    if not is_s3_enabled():
        console.print("[red]S3/R2 storage is not enabled in settings.[/red]")
        return

    s3_settings = get_s3_settings()
    s3_helper = S3Helper(
        endpoint_url=s3_settings["endpoint_url"],
        access_key_id=s3_settings["access_key_id"],
        secret_access_key=s3_settings["secret_access_key"],
        bucket_name=s3_settings["bucket_name"],
        region=s3_settings["region"],
        debug=debug,
    )

    file_path = Path(file)
    uploaded_object = s3_helper.upload_file(file_path=file_path, object_name=object_name)

    if uploaded_object:
        console.print(f"[green]Successfully uploaded {file_path} to {uploaded_object}[/green]")

        # Generate presigned URL
        presigned_url = s3_helper.generate_presigned_url(
            object_name=uploaded_object, expiration=s3_settings["url_expiration"]
        )

        if presigned_url:
            console.print(f"[green]Presigned URL: {presigned_url}[/green]")

            # Generate custom link if enabled
            if s3_settings.get("use_custom_link", False):
                success, custom_url = generate_custom_link(
                    s3_helper_instance=s3_helper,
                    object_name=uploaded_object,
                    expiration=s3_settings["url_expiration"],
                    debug=debug,
                )

                if success and custom_url:
                    console.print(f"[green]Custom URL: {custom_url}[/green]")
    else:
        console.print(f"[red]Failed to upload {file_path}[/red]")


@cli.command()
@click.option("--object-name", required=True, help="Object name in S3/R2")
@click.option("--debug", is_flag=True, help="Enable debug output")
def delete(object_name: str, debug: bool):
    """Delete an object from S3/R2 storage."""
    if not is_s3_enabled():
        console.print("[red]S3/R2 storage is not enabled in settings.[/red]")
        return

    s3_settings = get_s3_settings()
    s3_helper = S3Helper(
        endpoint_url=s3_settings["endpoint_url"],
        access_key_id=s3_settings["access_key_id"],
        secret_access_key=s3_settings["secret_access_key"],
        bucket_name=s3_settings["bucket_name"],
        region=s3_settings["region"],
        debug=debug,
    )

    success = s3_helper.delete_object(object_name=object_name)

    if success:
        console.print(f"[green]Successfully deleted {object_name}[/green]")
    else:
        console.print(f"[red]Failed to delete {object_name}[/red]")


@cli.command()
@click.option("--object-name", required=True, help="Object name in S3/R2")
@click.option(
    "--expiration", type=int, default=3600, help="URL expiration in seconds (default: 1 hour)"
)
@click.option("--custom", is_flag=True, help="Generate custom vanity URL")
@click.option("--debug", is_flag=True, help="Enable debug output")
def url(object_name: str, expiration: int, custom: bool, debug: bool):
    """Generate a presigned URL for an object in S3/R2 storage."""
    if not is_s3_enabled():
        console.print("[red]S3/R2 storage is not enabled in settings.[/red]")
        return

    s3_settings = get_s3_settings()
    s3_helper = S3Helper(
        endpoint_url=s3_settings["endpoint_url"],
        access_key_id=s3_settings["access_key_id"],
        secret_access_key=s3_settings["secret_access_key"],
        bucket_name=s3_settings["bucket_name"],
        region=s3_settings["region"],
        debug=debug,
    )

    if custom:
        # Generate custom vanity URL
        success, custom_url = generate_custom_link(
            s3_helper_instance=s3_helper,
            object_name=object_name,
            expiration=expiration,
            debug=debug,
        )

        if success and custom_url:
            console.print(f"[green]Custom URL: {custom_url}[/green]")
        else:
            console.print(f"[red]Failed to generate custom URL for {object_name}[/red]")
    else:
        # Generate standard presigned URL
        presigned_url = s3_helper.generate_presigned_url(
            object_name=object_name, expiration=expiration
        )

        if presigned_url:
            console.print(f"[green]Presigned URL: {presigned_url}[/green]")
        else:
            console.print(f"[red]Failed to generate presigned URL for {object_name}[/red]")


def main():
    """Entry point for the module."""
    try:
        cli()
    except Exception as e:
        console.print(f"[bold red]Error: {e}[/bold red]")
        sys.exit(1)


if __name__ == "__main__":
    try:
        cli()
    except KeyboardInterrupt:
        console.print("\n[bold]Program terminated by user.[/bold]")
        sys.exit(0)
    except Exception as e:
        console.print(f"\n[bold red]An error occurred: {e}[/bold red]")
        sys.exit(1)
