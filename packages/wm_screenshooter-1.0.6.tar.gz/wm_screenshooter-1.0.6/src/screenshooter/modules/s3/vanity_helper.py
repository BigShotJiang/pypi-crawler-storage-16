#!/usr/bin/env python3
"""Helper module for generating custom S3/R2 links via Cloudflare KV."""

import logging
import uuid
from typing import Optional, Tuple

import requests
from rich.console import Console

from screenshooter.modules.s3.helper import S3Helper, log_entry
from screenshooter.modules.settings.settings_helper import get_settings

# Initialize rich console
console = Console()

# Configure logging
logger = logging.getLogger("s3_vanity_helper")
logger.setLevel(logging.INFO)


def _write_to_cloudflare_kv(key: str, value: str, ttl: int, debug: bool = False) -> bool:
    """Writes a key-value pair to Cloudflare KV with a TTL.

    Reads Cloudflare credentials from settings.
    Returns True on success, False on failure.
    """
    settings = get_settings().s3

    account_id = settings.cloudflare_account_id
    namespace_id = settings.cloudflare_kv_namespace_id
    api_token = settings.cloudflare_api_token

    if not all([account_id, namespace_id, api_token]):
        log_entry(
            "Cloudflare KV settings (Account ID, Namespace ID, API Token) are not configured in application settings.",
            "[red]Cloudflare KV settings (Account ID, Namespace ID, API Token) are not configured in application settings.[/red]",
        )
        return False

    # First, always replace the problematic character
    cleaned_value = value.replace("\u221a", "sqrt")
    if debug and value != cleaned_value:
        log_entry(
            "Replaced square root symbol(s) in the URL",
            "[yellow]Replaced square root symbol(s) in the URL[/yellow]",
            debug,
        )

        # Show where the character was in the URL
        for i, (original, cleaned) in enumerate(zip(value, cleaned_value)):
            if original != cleaned:
                context_start = max(0, i - 5)
                context_end = min(len(value), i + 6)
                log_entry(
                    f"Replacement at position {i}: '{original}' -> '{cleaned}'",
                    f"[yellow]Replacement at position {i}: '{original}' -> '{cleaned}'[/yellow]",
                    debug,
                )
                log_entry(
                    f"Context: '{value[context_start:context_end]}'",
                    f"[yellow]Context: '{value[context_start:context_end]}'[/yellow]",
                    debug,
                )

    # Ensure TTL is at least 60 seconds for Cloudflare KV
    kv_ttl = max(60, ttl)
    api_url = (
        f"https://api.cloudflare.com/client/v4/accounts/{account_id}/"
        f"storage/kv/namespaces/{namespace_id}/values/{key}"
    )

    headers = {
        "Authorization": f"Bearer {api_token}",
        "Content-Type": "text/plain",
    }

    try:
        # Use requests with a direct UTF-8 encoded binary data
        response = requests.put(
            api_url,
            headers=headers,
            data=cleaned_value.encode("utf-8"),
            params={"expiration_ttl": kv_ttl},
            timeout=10,
        )

        if debug:
            log_entry(f"Cloudflare KV API Response Status: {response.status_code}", debug=debug)
            log_entry(f"Cloudflare KV API Response Headers: {response.headers}", debug=debug)
            log_entry(f"Cloudflare KV API Response Body: {response.text}", debug=debug)

        response.raise_for_status()

        response_data = response.json()
        if response_data.get("success"):
            if debug:
                log_entry(
                    f"Successfully wrote key '{key}' to Cloudflare KV with TTL {kv_ttl}s.",
                    debug=debug,
                )
            return True
        else:
            error_details = response_data.get("errors", [{}])[0].get("message", "Unknown API error")
            log_entry(
                f"Cloudflare API reported failure writing key '{key}': {error_details}",
                f"[red]Cloudflare API reported failure writing key '{key}': {error_details}[/red]",
            )
            return False

    except requests.exceptions.RequestException as e:
        log_entry(
            f"Error writing to Cloudflare KV: {e}",
            f"[red]Error writing to Cloudflare KV: {e}[/red]",
        )
        if debug and hasattr(e, "response") and e.response is not None:
            log_entry(f"Response status: {e.response.status_code}", debug=debug)
            log_entry(f"Response body: {e.response.text}", debug=debug)
        return False
    except Exception as e:
        # Catch potential JSON decoding errors or other unexpected issues
        log_entry(
            f"Unexpected error during Cloudflare KV write: {e}",
            f"[red]Unexpected error during Cloudflare KV write: {e}[/red]",
        )
        return False


def generate_custom_link(
    s3_helper_instance: S3Helper,
    object_name: str,
    expiration: Optional[int] = None,
    debug: bool = False,
) -> Tuple[bool, Optional[str]]:
    """Generates a presigned S3 URL, stores it in Cloudflare KV,
       and returns a custom domain link proxied by a Cloudflare Worker.

    Reads Cloudflare and S3 settings from application settings.

    Args:
        s3_helper_instance: An initialized S3Helper instance.
        object_name: Name of the S3 object.
        expiration: Link expiration time in seconds. If None, uses value from settings.
        debug: Enable debug logging.

    Returns:
        Tuple[bool, Optional[str]]: (success, url) where success indicates if custom URL was generated,
                                   and url is the custom URL if successful, None otherwise.
    """
    settings = get_settings().s3

    if not settings.use_custom_link:
        logger.warning("generate_custom_link called but 'use_custom_link' is disabled in settings.")
        return False, None

    custom_base_url = settings.custom_link_base_url
    if not custom_base_url:
        logger.error("Custom link base URL is not configured in settings.")
        return False, None

    # Use expiration from args or fallback to settings
    link_expiration = expiration if expiration is not None else settings.url_expiration

    # 1. Generate the S3 presigned URL using the provided S3Helper instance
    # Max expiration for S3 presigned URL is 7 days (604800 seconds)
    s3_expiration = min(link_expiration, 604800)
    presigned_url = s3_helper_instance.generate_presigned_url(object_name, expiration=s3_expiration)

    # Fix: Replace Unicode characters before processing
    if presigned_url:
        presigned_url = presigned_url.replace("\u221a", "sqrt")

    if not presigned_url:
        logger.error("Failed to generate S3 presigned URL via S3Helper. Cannot create custom link.")
        return False, None

    # Log the presigned URL for debugging if enabled
    if debug:
        # Log only the beginning and end of the URL to avoid exposing the full URL in logs
        url_len = len(presigned_url)
        logger.debug(
            f"Generated presigned URL: {presigned_url[:20]}...{presigned_url[-20:]} (length: {url_len})"
        )

        # Check for problematic characters in the URL
        if "\u221a" in presigned_url:
            indices = [i for i, char in enumerate(presigned_url) if char == "\u221a"]
            logger.warning(f"Square root symbol (√) found at position(s): {indices}")

            # Show more detail for the first occurrence
            if indices:
                pos = indices[0]
                start_idx = max(0, pos - 10)
                end_idx = min(len(presigned_url), pos + 10)
                context = presigned_url[start_idx:end_idx]
                logger.warning(f"Context around first occurrence: '{context}'")

    # 2. Generate a unique ID for the custom link path
    unique_id = uuid.uuid4().hex

    # 3. Store the mapping in Cloudflare KV
    # Set KV TTL slightly longer than S3 URL expiration for safety margin
    kv_ttl = s3_expiration + 300  # Add 5 minutes buffer
    if not _write_to_cloudflare_kv(unique_id, presigned_url, ttl=kv_ttl, debug=debug):
        logger.error("Failed to write mapping to Cloudflare KV. Cannot create custom link.")
        # Consider cleanup or retry logic here if needed
        return False, None

    # 4. Construct the custom link URL
    # Ensure base URL doesn't end with a slash and unique_id doesn't start with one
    custom_url = f"{custom_base_url.rstrip('/')}/{unique_id}"

    if debug:
        logger.debug(f"Generated custom link for {object_name}: {custom_url}")

    return True, custom_url
