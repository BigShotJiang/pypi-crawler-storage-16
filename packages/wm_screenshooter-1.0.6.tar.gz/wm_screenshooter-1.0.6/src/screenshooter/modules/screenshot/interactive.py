#!/usr/bin/env python3
"""Interactive UI functionality for the screenshot module."""

from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from rich.console import Console
from rich.prompt import Prompt

from screenshooter.modules.database import DatabaseOperations
from screenshooter.modules.settings.settings_helper import (
    get_default_screenshot_timer,
    get_screenshots_dir,
)

from .utils import BACK_OPTION, get_connected_displays, get_text_input

# Initialize rich console
console = Console()


def _prompt_with_back(
    prompt_text: str, choices: List[str], default: Optional[str] = None, show_choices: bool = True
) -> Union[str, object]:
    """Wrapper for adding a 'b' for back option, using input() to allow backspace."""
    valid_choices = choices + ["b"]
    while True:
        # Build and display the full prompt with choices and optional default
        choices_str = "/".join(valid_choices)
        # Colorize bracketed choices in purple
        colored_choices = f"\033[95m[{choices_str}]\033[0m"
        # Default is plain text and include a leading space
        default_text = f"({default})" if default is not None else ""
        # Build prompt with single space between choices and default
        prompt_str = f"{prompt_text} (or 'b' to go back) {colored_choices} {default_text}:"
        # Print the full prompt on its own line, then read the response on a new line
        print(prompt_str)
        # Use input-based prompt for proper backspace handling
        response = get_text_input("> ").strip()
        # If the user pressed Enter with no input and a default is provided, use it
        if response == "" and default is not None:
            response = default
        # Handle back navigation
        if response.lower() == "b":
            return BACK_OPTION
        # Validate the numeric choice
        if response in choices:
            return response
        # On invalid entry, show error and repeat the full prompt
        console.print(
            f"[red]Invalid choice: {response}. Please enter one of: {', '.join(choices)}[/red]"
        )


def _select_client_interactive(base_dir: Path) -> Union[str, object, None]:
    """Handle interactive client selection."""
    console.print("\n[bold]Client Selection[/bold]")

    # Check if we should use database
    from screenshooter.modules.settings.settings_helper import should_use_database

    clients = []
    use_database = should_use_database()

    if use_database:
        try:
            db_operations = DatabaseOperations()
            db_clients = db_operations.list_clients(active_only=True)
            clients = [(client.name, client.directory_name) for client in db_clients if client.name]
        except Exception as e:
            console.print(f"[bold red]Database error: {e}[/bold red]")
            console.print("Please check your database configuration.")
            choice = _prompt_with_back(
                "Would you like to return to main menu?", choices=["y", "n"], default="y"
            )
            if choice == "y":
                return BACK_OPTION
            # Otherwise, retry by returning None to re-prompt
            return None
    else:
        # Use filesystem (list directories with client_info.json)
        import json

        clients = []
        for d in base_dir.iterdir():
            if d.is_dir() and (d / "client_info.json").exists():
                try:
                    with open(d / "client_info.json", "r") as f:
                        client_info = json.load(f)
                    # Only include active (non-archived) clients
                    if not client_info.get("archived", False):
                        display_name = client_info.get("client_name", d.name)
                        directory_name = client_info.get("directory_name", d.name)
                        clients.append((display_name, directory_name))
                except (json.JSONDecodeError, IOError):
                    # Include clients with corrupted or unreadable info files
                    clients.append((d.name, d.name))

    if not clients:
        console.print("[yellow]No clients found. Creating a new client.[/yellow]")
        # Call to the full client creation process from client management
        from screenshooter.modules.clients.cli import create_new_client_for_screenshot

        new_client_name = create_new_client_for_screenshot()
        if new_client_name:
            return new_client_name
        else:
            # If cancelled, return None to re-prompt
            return None

    # Pagination Loop
    PAGE_SIZE = 10
    page = 0

    while True:
        total_items = len(clients)
        # We also have a "Create new client" option, which is effectively one more item
        # But we usually treat it as a special option outside the paginated list, or as the last item?
        # In clients/cli.py we made it 'c'. Let's stick to that consistency.
        # So we just paginate the clients list.

        if total_items == 0:
            total_pages = 1
        else:
            total_pages = (total_items + PAGE_SIZE - 1) // PAGE_SIZE

        if page >= total_pages:
            page = total_pages - 1
        page = max(page, 0)

        start_idx = page * PAGE_SIZE
        end_idx = min(start_idx + PAGE_SIZE, total_items)
        page_items = clients[start_idx:end_idx]

        if total_pages > 1:
            console.print(f"\n[bold]Available Clients (Page {page + 1}/{total_pages}):[/bold]")
        else:
            console.print("\n[bold]Available Clients:[/bold]")

        for i, client in enumerate(page_items):
            display_idx = start_idx + i + 1
            display_name, _ = client
            console.print(f"{display_idx}. {display_name}")

        console.print("\n[bold]Options:[/bold]")
        console.print(f"{start_idx + 1}-{end_idx}: Select client")
        console.print("c: Create new client")

        # Check for archived clients and show option if any exist
        archived_clients = []
        if use_database:
            try:
                archived_clients = db_operations.list_archived_clients()
            except Exception:
                pass  # Silently ignore errors for archived clients check
        else:
            # Filesystem mode - check for archived clients
            import json

            for d in base_dir.iterdir():
                if d.is_dir() and (d / "client_info.json").exists():
                    try:
                        with open(d / "client_info.json", "r") as f:
                            client_info = json.load(f)
                        if client_info.get("archived", False):
                            archived_clients.append(True)  # Just need to know if any exist
                            break
                    except (json.JSONDecodeError, IOError):
                        continue

        extra_options = []
        if archived_clients:
            console.print("a: Manage archived clients")
            extra_options.append("a")

        console.print("b: Go back")

        if page < total_pages - 1:
            console.print("n: Next Page")
            extra_options.append("n")
        if page > 0:
            console.print("p: Previous Page")
            extra_options.append("p")

        # Create choices list with client numbers, 'c', 'b', and navigation
        choices = [str(start_idx + i + 1) for i in range(len(page_items))] + ["c"] + extra_options

        prompt_text = "Select a client or create a new one"
        # Default is usually '1' if exists, else 'c'?
        default_choice = "1" if page_items else "c"

        choice = _prompt_with_back(
            prompt_text,
            choices=choices,
            default=default_choice,
        )

        if choice is BACK_OPTION:
            return BACK_OPTION
        elif choice == "n":
            page += 1
        elif choice == "p":
            page -= 1
        elif choice == "a":
            # Handle archived clients
            result = _manage_archived_clients(
                db_operations if use_database else None, base_dir if not use_database else None
            )
            if result is BACK_OPTION:
                return BACK_OPTION
            elif result:  # Client was unarchived and selected
                return result
            # Otherwise, continue the loop (None means cancelled)
        elif choice == "c":
            # Call to the full client creation process from client management
            from screenshooter.modules.clients.cli import create_new_client_for_screenshot

            new_client_name = create_new_client_for_screenshot()
            if new_client_name:
                return new_client_name
            else:
                # If cancelled, return None to re-prompt (loop again or return None?)
                # Returning None makes the caller loop/retry.
                return None
        elif isinstance(choice, str) and choice.isdigit():
            _, directory_name = clients[int(choice) - 1]
            return directory_name
        else:
            # Should not happen given prompt validation
            return None


def _manage_archived_clients(
    db_operations: Optional[DatabaseOperations], base_dir: Optional[Path] = None
) -> Union[str, object, None]:
    """Handle archived client management."""
    console.print("\n[bold]Manage Archived Clients[/bold]")

    try:
        if db_operations:
            archived_clients = db_operations.list_archived_clients()
        else:
            # Filesystem mode - look for archived clients in client_info.json
            import json

            archived_clients = []
            if base_dir:
                for d in base_dir.iterdir():
                    if d.is_dir() and (d / "client_info.json").exists():
                        try:
                            with open(d / "client_info.json", "r") as f:
                                client_info = json.load(f)
                            if client_info.get("archived", False):
                                # Create a simple object with name and directory_name
                                from types import SimpleNamespace

                                archived_clients.append(
                                    SimpleNamespace(
                                        name=client_info.get("client_name", d.name),
                                        directory_name=d.name,
                                        id=None,
                                    )
                                )
                        except (json.JSONDecodeError, IOError):
                            continue

        if not archived_clients:
            console.print("[yellow]No archived clients found.[/yellow]")
            _prompt_with_back("Press Enter to continue...", choices=[""])
            return BACK_OPTION

        # Pagination for archived clients
        PAGE_SIZE = 10
        page = 0
        total_pages = (len(archived_clients) + PAGE_SIZE - 1) // PAGE_SIZE

        while True:
            if page >= total_pages:
                page = total_pages - 1
            page = max(page, 0)

            start_idx = page * PAGE_SIZE
            end_idx = min(start_idx + PAGE_SIZE, len(archived_clients))
            page_items = archived_clients[start_idx:end_idx]

            console.print(f"\n[bold]Archived Clients (Page {page + 1}/{total_pages}):[/bold]")

            for i, client in enumerate(page_items):
                display_idx = start_idx + i + 1
                console.print(f"{display_idx}. {client.name} [dim](Archived)[/dim]")

            console.print("\n[bold]Options:[/bold]")
            console.print(f"{start_idx + 1}-{end_idx}: Select client to unarchive")
            console.print("b: Go back")

            extra_options = []
            if page < total_pages - 1:
                console.print("n: Next Page")
                extra_options.append("n")
            if page > 0:
                console.print("p: Previous Page")
                extra_options.append("p")

            choices = [str(start_idx + i + 1) for i in range(len(page_items))] + extra_options
            default_choice = "1" if page_items else "b"

            choice = _prompt_with_back(
                "Select a client to unarchive or go back",
                choices=choices,
                default=default_choice,
            )

            if choice is BACK_OPTION:
                return BACK_OPTION
            elif choice == "n":
                page += 1
            elif choice == "p":
                page -= 1
            elif isinstance(choice, str) and choice.isdigit():
                selected_idx = int(choice) - 1
                if 0 <= selected_idx < len(archived_clients):
                    selected_client = archived_clients[selected_idx]

                    # Confirm unarchive
                    confirm = _prompt_with_back(
                        f"Unarchive client '{selected_client.name}' and continue?",
                        choices=["y", "n"],
                        default="y",
                    )

                    if confirm is BACK_OPTION:
                        return BACK_OPTION
                    elif confirm == "y":
                        if db_operations:
                            # Database mode
                            success = db_operations.unarchive_client(selected_client.id)
                        else:
                            # Filesystem mode - update client_info.json
                            success = False
                            if base_dir and selected_client.directory_name:
                                client_dir = base_dir / selected_client.directory_name
                                info_file = client_dir / "client_info.json"
                                if info_file.exists():
                                    try:
                                        import json

                                        with open(info_file, "r") as f:
                                            client_info = json.load(f)
                                        client_info["archived"] = False
                                        with open(info_file, "w") as f:
                                            json.dump(client_info, f, indent=2)
                                        success = True
                                    except (json.JSONDecodeError, IOError):
                                        console.print(f"[red]Failed to update {info_file}[/red]")

                        if success:
                            console.print(
                                f"[green]Client '{selected_client.name}' has been unarchived.[/green]"
                            )
                            return selected_client.directory_name
                        else:
                            console.print(
                                f"[red]Failed to unarchive client '{selected_client.name}'.[/red]"
                            )
                    else:
                        console.print("[yellow]Unarchive cancelled.[/yellow]")
                else:
                    console.print("[red]Invalid selection.[/red]")

    except Exception as e:
        console.print(f"[red]Error managing archived clients: {e}[/red]")
        return BACK_OPTION


def _manage_archived_projects(
    client_dir_name: str,
    db_operations: Optional[DatabaseOperations],
    base_dir: Optional[Path] = None,
) -> Union[str, object, None]:
    """Handle archived project management."""
    console.print("\n[bold]Manage Archived Projects[/bold]")

    archived_projects = []

    try:
        if db_operations:
            # Get client by directory name
            client = db_operations.get_client_by_directory(client_dir_name)
            if not client:
                console.print("[red]Client not found in database.[/red]")
                return BACK_OPTION

            # Get archived projects
            if client.id is None:
                console.print("[red]Client ID not found.[/red]")
                return BACK_OPTION
            archived_projects = [
                (
                    project.name or project.directory_name,
                    project.directory_name,
                    project.id,
                )
                for project in db_operations.list_archived_projects(client.id)
            ]
        else:
            # Filesystem mode - look for archived projects in project.json
            import json

            if base_dir:
                client_dir = base_dir / client_dir_name
                if client_dir.exists():
                    for d in client_dir.iterdir():
                        if d.is_dir() and (d / "project.json").exists():
                            try:
                                with open(d / "project.json", "r") as f:
                                    project_info = json.load(f)
                                is_archived = bool(
                                    project_info.get("archived_at")
                                    or project_info.get("archived", False)
                                )
                                if is_archived:
                                    # Create a simple object with name and directory_name
                                    archived_projects.append(
                                        (
                                            project_info.get("project_name", d.name),
                                            d.name,
                                            None,
                                        )
                                    )
                            except (json.JSONDecodeError, IOError):
                                continue

        if not archived_projects:
            console.print("[yellow]No archived projects found.[/yellow]")
            return BACK_OPTION

        # Pagination Loop
        PAGE_SIZE = 10
        page = 0

        while True:
            total_items = len(archived_projects)
            if total_items == 0:
                # Should not happen given check above, but just in case unarchiving empties list
                console.print("[yellow]No more archived projects.[/yellow]")
                return BACK_OPTION

            total_pages = (total_items + PAGE_SIZE - 1) // PAGE_SIZE

            if page >= total_pages:
                page = total_pages - 1
            page = max(page, 0)

            start_idx = page * PAGE_SIZE
            end_idx = min(start_idx + PAGE_SIZE, total_items)
            page_items = archived_projects[start_idx:end_idx]

            if total_pages > 1:
                console.print(f"\n[bold]Archived Projects (Page {page + 1}/{total_pages}):[/bold]")
            else:
                console.print("\n[bold]Archived Projects:[/bold]")

            for i, project in enumerate(page_items):
                display_idx = start_idx + i + 1
                display_name = project[0]
                console.print(f"{display_idx}. {display_name} [dim](Archived)[/dim]")

            console.print("\n[bold]Options:[/bold]")
            console.print(f"{start_idx + 1}-{end_idx}: Select project to unarchive")
            console.print("b: Go back")

            extra_choices = []
            if page < total_pages - 1:
                console.print("n: Next Page")
                extra_choices.append("n")
            if page > 0:
                console.print("p: Previous Page")
                extra_choices.append("p")

            choices = (
                [str(start_idx + i + 1) for i in range(len(page_items))] + ["b"] + extra_choices
            )

            choice = _prompt_with_back(
                "Select a project to unarchive",
                choices=choices,
                default="b",  # Default to back to be safe
            )

            if choice is BACK_OPTION or choice == "b":
                return BACK_OPTION
            elif choice == "n":
                page += 1
            elif choice == "p":
                page -= 1
            elif isinstance(choice, str) and choice.isdigit():
                idx = int(choice) - 1
                if 0 <= idx < len(archived_projects):
                    selected_name, selected_dir_name, selected_id = archived_projects[idx]

                    # Confirm unarchive
                    console.print(f"\n[yellow]Selected project: {selected_name}[/yellow]")
                    confirm = _prompt_with_back(
                        f"Unarchive project '{selected_name}'?",
                        choices=["y", "n"],
                        default="n",
                    )

                    if confirm is BACK_OPTION:
                        continue

                    if isinstance(confirm, str) and confirm.lower() == "y":
                        # Unarchive the project
                        success = False
                        if db_operations and selected_id is not None:
                            # Database mode
                            success = db_operations.unarchive_project(selected_id)
                        else:
                            # Filesystem mode - update project.json
                            if base_dir:
                                client_dir = base_dir / client_dir_name
                                project_dir = client_dir / selected_dir_name
                                project_file = project_dir / "project.json"
                                if project_file.exists():
                                    try:
                                        import json

                                        with open(project_file, "r") as f:
                                            project_info = json.load(f)
                                        project_info["archived_at"] = ""
                                        project_info.pop("archived", None)
                                        with open(project_file, "w") as f:
                                            json.dump(project_info, f, indent=2)
                                        success = True
                                    except (json.JSONDecodeError, IOError):
                                        console.print(f"[red]Failed to update {project_file}[/red]")
                        if success:
                            console.print(
                                f"[green]Project '{selected_name}' has been unarchived.[/green]"
                            )
                            # Return the unarchived project directory name so it can be selected
                            return selected_dir_name
                        else:
                            console.print(
                                f"[red]Failed to unarchive project '{selected_name}'.[/red]"
                            )
                    else:
                        console.print("[yellow]Unarchive cancelled.[/yellow]")
                else:
                    console.print("[red]Invalid selection.[/red]")

    except Exception as e:
        console.print(f"[red]Error managing archived projects: {e}[/red]")
        return BACK_OPTION


def _select_project_interactive(client_dir_name: str, base_dir: Path) -> Union[str, object, None]:
    """Handle interactive project selection."""
    console.print("\n[bold]Project Selection[/bold]")

    # Check if we should use database
    from screenshooter.modules.settings.settings_helper import should_use_database

    projects = []
    archived_projects = []
    use_database = should_use_database()

    if use_database:
        try:
            db_operations = DatabaseOperations()
            # Get client by directory name
            client = db_operations.get_client_by_directory(client_dir_name)
            if client and client.id:
                # Get active projects from database
                db_projects = db_operations.list_projects(client.id, active_only=True)
                projects = [(p.name, p.directory_name) for p in db_projects]
                # Get archived projects too
                db_archived = db_operations.list_archived_projects(client.id)
                archived_projects = [(p.name, p.directory_name, p.id) for p in db_archived]
            else:
                console.print(f"[red]Client '{client_dir_name}' not found in database.[/red]")
                return BACK_OPTION
        except Exception as e:
            console.print(f"[bold red]Database error: {e}[/bold red]")
            console.print("Please check your database configuration.")
            choice = _prompt_with_back(
                "Would you like to return to client selection?", choices=["y", "n"], default="y"
            )
            if choice == "y":
                return BACK_OPTION
            # Otherwise, retry by returning None to re-prompt
            return None
    else:
        # Use filesystem (list directories with project.json)
        client_dir = base_dir / client_dir_name
        if client_dir.exists():
            import json

            for d in client_dir.iterdir():
                if d.is_dir() and (d / "project.json").exists():
                    try:
                        with open(d / "project.json", "r") as f:
                            project_info = json.load(f)
                        display_name = project_info.get("project_name", d.name)
                        directory_name = project_info.get("directory_name", d.name)
                        # Check if archived
                        if project_info.get("archived_at") or project_info.get("archived", False):
                            archived_projects.append((display_name, directory_name, None))
                        else:
                            projects.append((display_name, directory_name))
                    except (json.JSONDecodeError, IOError):
                        # Include projects with corrupted or unreadable info files
                        projects.append((d.name, d.name))

    if not projects and not archived_projects:
        console.print("[yellow]No projects found for this client. Creating a new project.[/yellow]")
        # No 'back' option here if no projects exist
        project_name = Prompt.ask("Enter project name")
        if not project_name:
            return None
        return project_name

    # Pagination Loop
    PAGE_SIZE = 10
    page = 0

    while True:
        total_items = len(projects)
        if total_items == 0:
            total_pages = 1
        else:
            total_pages = (total_items + PAGE_SIZE - 1) // PAGE_SIZE

        if page >= total_pages:
            page = total_pages - 1
        page = max(page, 0)

        start_idx = page * PAGE_SIZE
        end_idx = min(start_idx + PAGE_SIZE, total_items)
        page_items = projects[start_idx:end_idx]

        if total_pages > 1:
            console.print(f"\n[bold]Available Projects (Page {page + 1}/{total_pages}):[/bold]")
        else:
            console.print("\n[bold]Available Projects:[/bold]")

        if not page_items:
            console.print("[dim]No active projects.[/dim]")

        for i, project in enumerate(page_items):
            display_idx = start_idx + i + 1
            display_name, _ = project
            console.print(f"{display_idx}. {display_name}")

        console.print("\n[bold]Options:[/bold]")
        if page_items:
            console.print(f"{start_idx + 1}-{end_idx}: Select project")
        console.print("c: Create new project")
        if archived_projects:
            console.print("a: Manage archived projects")
        console.print("b: Back to client selection")

        extra_choices = ["c"]
        if archived_projects:
            extra_choices.append("a")

        if page < total_pages - 1:
            console.print("n: Next Page")
            extra_choices.append("n")
        if page > 0:
            console.print("p: Previous Page")
            extra_choices.append("p")

        choices = [str(start_idx + i + 1) for i in range(len(page_items))] + extra_choices

        default_choice = "1" if page_items else "c"

        choice = _prompt_with_back(
            "Select a project or create a new one",
            choices=choices,
            default=default_choice,
        )

        if choice is BACK_OPTION or choice == "b":
            return BACK_OPTION
        elif choice == "n":
            page += 1
        elif choice == "p":
            page -= 1
        elif choice == "c":
            # No 'back' option when creating new
            project_name = Prompt.ask("Enter new project name")
            if not project_name:
                return None
            # Return the directory name (slugified) instead of display name
            from screenshooter.modules.clients.utils import slugify_name

            return slugify_name(project_name)
        elif choice == "a" and archived_projects:
            result = _manage_archived_projects(client_dir_name, db_operations, base_dir)
            if result is BACK_OPTION:
                continue  # Just go back to list
            elif isinstance(result, str):
                return result  # Project was unarchived, select it
        # Numeric selection
        elif isinstance(choice, str) and choice.isdigit():
            _, directory_name = projects[int(choice) - 1]
            return directory_name
        else:
            return None


def _select_mode_interactive() -> Union[str, object, None]:
    """Handle interactive screenshot mode selection."""
    console.print("\n[bold]Screenshot Mode[/bold]")
    displays = get_connected_displays()
    mode_options = {"1": "all", "2": "window"}
    option_labels = ["1. All displays", "2. Window"]
    idx = 3
    for d in displays:
        mode_options[str(idx)] = f"display{d}"
        option_labels.append(f"{idx}. Display {d}")
        idx += 1
    mode_options[str(idx)] = "custom"
    option_labels.append(f"{idx}. Custom (choose displays)")

    for label in option_labels:
        console.print(label)

    choices = [str(i) for i in range(1, idx + 1)]
    mode_choice = _prompt_with_back("Select screenshot mode", choices=choices, default="1")

    if mode_choice is BACK_OPTION:
        return BACK_OPTION  # Signal to go back

    if not isinstance(mode_choice, str):
        console.print("[red]Invalid choice type. Please try again.[/red]")
        return None

    mode = mode_options[mode_choice]

    if mode == "custom":
        while True:
            # Allow 'b' to cancel custom selection and return to mode selection?
            # For simplicity now, we assume once you start custom, you finish or restart.
            # Adding 'back' here would require returning BACK_OPTION from this inner loop too.
            custom_input = Prompt.ask(
                f"Enter display numbers separated by space or comma (available: {' '.join(str(d) for d in displays)})"
            )
            # if custom_input.lower() == 'b': return BACK_OPTION # Requires handling in the caller

            parts = [p for p in custom_input.replace(",", " ").split() if p.isdigit()]
            chosen = [int(p) for p in parts]
            if all(d in displays for d in chosen) and chosen:
                return f"custom:{','.join(str(d) for d in chosen)}"
            else:
                console.print(
                    f"[red]Invalid selection. Please choose from: {' '.join(str(d) for d in displays)}[/red]"
                )
    else:
        return mode


def _select_timer_interactive() -> Union[int, str, object, None]:
    """Handle interactive timer selection."""
    console.print("\n[bold]Timer Settings:[/bold]")

    # Get the default timer from settings
    default_timer = get_default_screenshot_timer()

    # Define standard timer options (excluding 5 minutes)
    standard_options = [
        ("Every 15 minutes", 15),
        ("Every 30 minutes", 30),
        ("Every 1 hour", 60),
        ("Custom interval", "custom"),
        ("Manual mode (no automatic screenshots)", "manual"),
    ]

    # Build dynamic options map with default as option 1
    timer_options_map = {}
    option_number = 1

    # Option 1: Default timer
    if default_timer == "manual":
        timer_options_map[str(option_number)] = ("Default (Manual mode)", "manual")
    elif isinstance(default_timer, int):
        if default_timer == 15:
            timer_options_map[str(option_number)] = ("Default (Every 15 minutes)", 15)
        elif default_timer == 30:
            timer_options_map[str(option_number)] = ("Default (Every 30 minutes)", 30)
        elif default_timer == 60:
            timer_options_map[str(option_number)] = ("Default (Every 1 hour)", 60)
        else:
            timer_options_map[str(option_number)] = (
                f"Default (Every {default_timer} minutes)",
                default_timer,
            )
    option_number += 1

    # Add remaining standard options (skip if already added as default)
    for label, value in standard_options:
        if value == default_timer:
            continue  # Skip if this was already added as default
        timer_options_map[str(option_number)] = (label, value)
        option_number += 1

    # Display options
    for key, (label, _) in timer_options_map.items():
        console.print(f"{key}. {label}")

    choices = list(timer_options_map.keys())
    timer_choice = _prompt_with_back("Select timer setting", choices=choices, default="1")

    if timer_choice is BACK_OPTION:
        return BACK_OPTION  # Signal to go back

    if not isinstance(timer_choice, str):
        console.print("[red]Invalid choice type. Please try again.[/red]")
        return None

    # Get selected timer value and resolve custom
    _, timer_value = timer_options_map[timer_choice]
    if timer_value == "custom":
        while True:
            custom_input = Prompt.ask("Enter custom interval in minutes", default="10")
            if custom_input.isdigit() and int(custom_input) > 0:
                return int(custom_input)
            console.print("[red]Invalid input. Please enter a positive integer.[/red]")
    # Return numeric interval or manual string
    return timer_value


def interactive_project_selection() -> Optional[Dict[str, Any]]:
    """Interactive project selection mode with back functionality."""
    console.print("[bold]Screenshot Capture Session Setup[/bold]")
    console.print("=================================")
    console.print("(Enter 'b' at any prompt to go back to the previous step)")

    base_dir = Path(get_screenshots_dir())
    if not base_dir.exists():
        base_dir.mkdir(parents=True, exist_ok=True)

    client_dir_name: Optional[str] = None
    project_name: Optional[str] = None
    mode: Optional[str] = None
    timer: Optional[Union[int, str]] = None

    step = 1
    max_steps = 4  # Client, Project, Mode, Timer
    client_creation_attempts = 0
    max_client_creation_attempts = 3

    while step <= max_steps:
        result = None
        if step == 1:
            result = _select_client_interactive(base_dir)
            if result is BACK_OPTION:
                console.print("[yellow]Cancelled. Returning to main menu.[/yellow]")
                return None
            elif result is None:
                # User cancelled client creation, retry step 1
                client_creation_attempts += 1
                if client_creation_attempts >= max_client_creation_attempts:
                    console.print(
                        "[bold red]Maximum client creation attempts reached. Exiting setup.[/bold red]"
                    )
                    return None
                continue
            elif result and isinstance(result, str):
                client_dir_name = result
                client_creation_attempts = 0  # Reset counter on successful client selection
        elif step == 2:
            # Ensure client_dir_name is valid before proceeding
            if not client_dir_name:
                console.print(
                    "[red]Error: Client directory name not set. Returning to client selection.[/red]"
                )
                step = 1
                continue
            result = _select_project_interactive(client_dir_name, base_dir)
            if result is BACK_OPTION:
                step -= 1
                continue
            elif result and isinstance(result, str):
                project_name = result
        elif step == 3:
            result = _select_mode_interactive()
            if result is BACK_OPTION:
                step -= 1
                continue
            elif result and isinstance(result, str):
                mode = result
        elif step == 4:
            result = _select_timer_interactive()
            if result is BACK_OPTION:
                step -= 1
                continue
            elif isinstance(result, int) or (
                isinstance(result, str) and result == "manual"
            ):  # Accept manual mode
                timer = result

        # If result is None (or indicates an issue other than BACK_OPTION), retry the step?
        # For now, assume valid result means progression.
        if result is not BACK_OPTION and result is not None:
            step += 1
        elif result is None:  # Handle potential error states from sub-functions
            console.print(f"[yellow]Retrying step {step}...[/yellow]")
            # Don't increment step, just loop again

    # Verify all required options are set
    if client_dir_name and project_name and mode is not None and timer is not None:
        return {"client": client_dir_name, "project": project_name, "mode": mode, "timer": timer}
    else:
        console.print("[red]Setup incomplete. Exiting interactive setup.[/red]")
        return None  # Indicate incomplete setup
