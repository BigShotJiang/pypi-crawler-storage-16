#!/usr/bin/env python3
"""Main entry point for the screenshot module."""

import os
import platform
import shutil
import subprocess
import sys
import time
from datetime import datetime
from typing import Optional, Tuple

import click
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt

from screenshooter.modules.settings.settings_helper import should_notify_before_scheduled

from .config import ScreenshooterConfig
from .interactive import interactive_project_selection
from .post_session import post_session_report_flow
from .utils import get_connected_displays, get_key, get_text_input

# Initialize rich console
console = Console()


def _get_notification_capability() -> Tuple[bool, Optional[str]]:
    """Check if desktop notifications are available on this platform.

    Returns:
        Tuple of (can_notify: bool, notifier_path: Optional[str])
    """
    system = platform.system()

    if system == "Darwin":
        # macOS - check for terminal-notifier
        notifier_path = shutil.which("terminal-notifier")
        return bool(notifier_path), notifier_path
    elif system == "Linux":
        # Linux - check for notify-send
        notifier_path = shutil.which("notify-send")
        return bool(notifier_path), notifier_path
    elif system == "Windows":
        # Windows - PowerShell is always available
        return True, "powershell"
    else:
        return False, None


def _send_pre_screenshot_notification(notifier_path: str, title: str, message: str) -> None:
    """Send a pre-screenshot notification cross-platform.

    Args:
        notifier_path: Path to the notification tool or "powershell" for Windows
        title: Notification title
        message: Notification message
    """
    system = platform.system()

    try:
        if system == "Darwin":
            subprocess.run(
                [
                    notifier_path,
                    "-title",
                    title,
                    "-message",
                    message,
                    "-group",
                    "screenshot-warning",
                ],
                check=False,
                capture_output=True,
            )
        elif system == "Linux":
            subprocess.run(
                [notifier_path, title, message],
                check=False,
                capture_output=True,
            )
        elif system == "Windows":
            ps_script = f'''
            Add-Type -AssemblyName System.Windows.Forms
            $notify = New-Object System.Windows.Forms.NotifyIcon
            $notify.Icon = [System.Drawing.SystemIcons]::Information
            $notify.BalloonTipTitle = "{title}"
            $notify.BalloonTipText = "{message}"
            $notify.Visible = $true
            $notify.ShowBalloonTip(5000)
            Start-Sleep -Milliseconds 100
            $notify.Dispose()
            '''
            subprocess.run(
                ["powershell", "-Command", ps_script],
                check=False,
                capture_output=True,
                creationflags=subprocess.CREATE_NO_WINDOW
                if hasattr(subprocess, "CREATE_NO_WINDOW")
                else 0,
            )
    except Exception:
        pass  # Silently fail if notifications don't work


def _open_file_cross_platform(file_path: str) -> bool:
    """Open a file with the system's default application cross-platform.

    Args:
        file_path: Path to the file to open

    Returns:
        True if successful, False otherwise
    """
    system = platform.system()

    try:
        if system == "Darwin":
            subprocess.run(["open", file_path], check=False)
        elif system == "Linux":
            subprocess.run(["xdg-open", file_path], check=False)
        elif system == "Windows":
            # On Windows, open file with default application
            subprocess.Popen(["start", "", file_path], shell=True)
        else:
            return False
        return True
    except Exception:
        return False


def _open_file_with_app(file_path: str, app_name: str) -> bool:
    """Open a file with a specific application (cross-platform).

    Args:
        file_path: Path to the file to open
        app_name: Application name (e.g., "TextEdit" on macOS)

    Returns:
        True if successful, False otherwise
    """
    system = platform.system()

    try:
        if system == "Darwin":
            subprocess.run(["open", "-a", app_name, file_path], check=False)
        elif system == "Linux":
            # On Linux, just use the default text editor
            editor = os.environ.get("EDITOR", "xdg-open")
            subprocess.run([editor, file_path], check=False)
        elif system == "Windows":
            # On Windows, open file with default application
            subprocess.Popen(["start", "", file_path], shell=True)
        else:
            return False
        return True
    except Exception:
        return False


@click.command()
@click.option("--client", help="Set client name for screenshots folder")
@click.option("--project", help="Set project name for screenshots folder")
@click.option(
    "--mode",
    type=click.Choice(["all", "main", "second", "window"]),
    default="all",
    help="Screenshot mode",
)
@click.option(
    "--timer", type=int, default=0, help="Take screenshots every N minutes (0 for single shot)"
)
@click.option("--interactive", is_flag=True, help="Run in interactive mode with guided setup")
def main(
    client: Optional[str], project: Optional[str], mode: str, timer: int, interactive: bool
) -> int:
    """Screenshot capture module for ScreenShooter Mac."""

    # If interactive mode or missing required parameters, run interactive setup
    if interactive or (not client or not project):
        options = interactive_project_selection()
        if options is None:  # Handle incomplete setup or user-cancel
            # console.print("[yellow]Setup cancelled. Returning to main menu.[/yellow]")
            return 1
        client = options["client"]
        project = options["project"]
        mode = options["mode"]
        timer = options["timer"]

    # Ensure client and project are strings after potential interactive selection
    if not client or not project:
        console.print("[bold red]Client and Project names are required.[/bold red]")
        return 1

    # Create configuration
    config = ScreenshooterConfig(client_name=client, project_name=project, mode=mode, timer=timer)

    # Display client info
    config.display_client_info()

    # Get session note
    session_note = get_text_input("\nPlease enter a note to start this session: ")
    while not session_note:
        session_note = get_text_input(
            "Note cannot be empty. Please enter a note to start this session: "
        )
    config.log_entry(
        f"SESSION START NOTE: {session_note}", terminal_message="Session note added successfully."
    )

    # Track mode transition to avoid redundant operations
    mode_transition = False
    # Check if notifications are available (cross-platform)
    can_notify, notifier_path = _get_notification_capability()

    try:
        # Main execution loop - allows switching between modes
        while True:
            if timer == 0:
                # Single shot mode
                config.capture_screenshots()
                config.log_entry("Single screenshot set completed")
                break  # Exit after single shot
            elif timer == "manual":
                # Reset mode transition flag when entering manual mode
                mode_transition = False

                # Enter manual mode: no automatic screenshots
                console.print(
                    "Entering manual screenshot mode. No automatic screenshots will be taken."
                )
                console.print("Press 's' to take a manual screenshot")
                console.print("Press 'n' to add a note to the log")
                console.print("Press 'c' to add a caption to the last screenshot")
                console.print("Press 'd' to change the display mode")
                console.print("Press 'p' to pause the session for sensitive activities")
                console.print("Press 'o' to open the last screenshot in Preview")
                console.print("Press 'l' to open the current session log in TextEdit")
                console.print("Press 'i' to show time in session, today, and project total")
                console.print("Press 'r' to archive the last action (screenshot or note)")
                console.print("Press 'e' to list the last 5 actions")
                console.print("Press 't' to change timer and exit manual mode")
                console.print("Press 'q' to quit (no final screenshot will be taken)")
                console.print("Press 'h' for help")

                # Display current status
                console.print(
                    f"\n[green]Status: Manual mode | Display: {config.mode} | Set: #{config.set_id}[/green]"
                )

                manual_mode_active = True
                while manual_mode_active:
                    try:
                        key = get_key()
                        if not key:
                            continue

                        # Manual commands
                        if key == "s":
                            # Countdown for manual screenshot
                            if config.countdown_for_screenshot(config.countdown_seconds, "Manual screenshot"):
                                config.capture_screenshots("manual")
                                console.print(
                                    f"\n[green]Status: Manual mode | Display: {config.mode} | Set: #{config.set_id}[/green]"
                                )
                        elif key == "n":
                            note = get_text_input("Enter your note: ")
                            if note:
                                config.log_entry(
                                    f"NOTE: {note}", terminal_message="Note added to log."
                                )
                                console.print(
                                    f"\n[green]Status: Manual mode | Display: {config.mode} | Set: #{config.set_id}[/green]"
                                )
                        elif key == "c":
                            if config.set_id == 0:
                                console.print("No screenshot sets have been taken yet.")
                            else:
                                caption = get_text_input(
                                    f"Enter caption for screenshot set #{config.set_id}: "
                                )
                                if caption:
                                    config.log_entry(
                                        f"CAPTION for screenshot set #{config.set_id}: {caption}",
                                        terminal_message="Caption added to log.",
                                    )
                            console.print(
                                f"\n[green]Status: Manual mode | Display: {config.mode} | Set: #{config.set_id}[/green]"
                            )
                        elif key == "o":
                            if config.last_screenshot and os.path.exists(config.last_screenshot):
                                console.print(f"Opening last screenshot: {config.last_screenshot}")
                                if not _open_file_cross_platform(config.last_screenshot):
                                    console.print("[yellow]Could not open screenshot.[/yellow]")
                            else:
                                console.print("No screenshot available to open.")
                            console.print(
                                f"\n[green]Status: Manual mode | Display: {config.mode} | Set: #{config.set_id}[/green]"
                            )
                        elif key == "l":
                            # Open the current session log in a text editor
                            try:
                                if config.session_log_file and config.session_log_file.exists():
                                    console.print(f"Opening session log: {config.session_log_file}")
                                    if not _open_file_with_app(
                                        str(config.session_log_file), "TextEdit"
                                    ):
                                        console.print(
                                            "[yellow]Could not open session log.[/yellow]"
                                        )
                                else:
                                    console.print("Session log file not found.")
                            except Exception as e:
                                console.print(f"Error opening session log: {e}")
                            console.print(
                                f"\n[green]Status: Manual mode | Display: {config.mode} | Set: #{config.set_id}[/green]"
                            )
                        elif key == "i":
                            session_str, today_str, project_str = config.get_time_info()
                            console.print(f"Time in session: {session_str}")
                            console.print(f"Time today: {today_str}")
                            console.print(f"Time in project: {project_str}")
                            console.print(
                                f"\n[green]Status: Manual mode | Display: {config.mode} | Set: #{config.set_id}[/green]"
                            )
                        elif key == "r":
                            # Remove/archive last screenshot or note
                            try:
                                # Use the existing db_logger from config if available
                                if (
                                    hasattr(config, "db_logger")
                                    and config.db_logger
                                    and config.db_logger.is_available()
                                    and config.db_logger.current_session_id
                                ):
                                    db_ops = config.db_logger.db_operations
                                    session_id = config.db_logger.current_session_id

                                    # Get the most recent screenshot and note
                                    screenshots = db_ops.list_screenshots(
                                        session_id, include_archived=True
                                    )
                                    notes = db_ops.list_notes(session_id, include_archived=True)

                                    # Find the most recent item
                                    latest_screenshot = screenshots[-1] if screenshots else None
                                    latest_note = notes[-1] if notes else None

                                    if not latest_screenshot and not latest_note:
                                        console.print(
                                            "No screenshots or notes found in this session."
                                        )
                                    else:
                                        # Compare timestamps to find the most recent
                                        latest_item = None
                                        latest_type = None

                                        if latest_screenshot and latest_note:
                                            if latest_screenshot.timestamp > latest_note.timestamp:
                                                latest_item = latest_screenshot
                                                latest_type = "screenshot"
                                            else:
                                                latest_item = latest_note
                                                latest_type = "note"
                                        elif latest_screenshot:
                                            latest_item = latest_screenshot
                                            latest_type = "screenshot"
                                        else:
                                            latest_item = latest_note
                                            latest_type = "note"

                                        # Archive the item
                                        if latest_type == "screenshot":
                                            success = db_ops.archive_screenshot(latest_item.id)
                                            if success:
                                                # Log with ARCHIVED prefix for clarity in logs
                                                config.log_entry(
                                                    f"ARCHIVED: Screenshot (last, set #{latest_item.set_id})",
                                                    terminal_message=f"Archived last screenshot (set #{latest_item.set_id}).",
                                                )
                                            else:
                                                console.print("Failed to archive screenshot.")
                                        else:  # note
                                            success = db_ops.archive_note(latest_item.id)
                                            if success:
                                                content_preview = (
                                                    latest_item.content[:50] + "..."
                                                    if len(latest_item.content) > 50
                                                    else latest_item.content
                                                )
                                                # Log with ARCHIVED prefix for clarity in logs
                                                config.log_entry(
                                                    f"ARCHIVED: Note: {content_preview}",
                                                    terminal_message=f"Archived last note: {content_preview}",
                                                )
                                            else:
                                                console.print("Failed to archive note.")
                                else:
                                    console.print(
                                        "Database logging is not available. Cannot archive items."
                                    )
                            except Exception as e:
                                console.print(f"Error archiving item: {e}")

                            console.print(
                                f"\n[green]Status: Manual mode | Display: {config.mode} | Set: #{config.set_id}[/green]"
                            )
                        elif key == "e":
                            # Edit/remove specific screenshots or notes
                            try:
                                # Use the existing db_logger from config if available
                                if (
                                    hasattr(config, "db_logger")
                                    and config.db_logger
                                    and config.db_logger.is_available()
                                    and config.db_logger.current_session_id
                                ):
                                    db_ops = config.db_logger.db_operations
                                    session_id = config.db_logger.current_session_id

                                    # Get all screenshots and notes (including archived for management)
                                    screenshots = db_ops.list_screenshots(
                                        session_id, include_archived=True
                                    )
                                    notes = db_ops.list_notes(session_id, include_archived=True)

                                    if not screenshots and not notes:
                                        console.print(
                                            "No screenshots or notes found in this session."
                                        )
                                    else:
                                        console.print("\n[bold]Session Items:[/bold]")
                                        item_list = []

                                        # Combine and sort items by timestamp
                                        combined_items = []

                                        for screenshot in screenshots:
                                            combined_items.append(
                                                ("screenshot", screenshot.id, screenshot)
                                            )

                                        for note in notes:
                                            combined_items.append(("note", note.id, note))

                                        # Sort by timestamp (assuming all objects have a timestamp field)
                                        combined_items.sort(key=lambda x: x[2].timestamp)

                                        # Show only the last 5 actions to keep it simple
                                        if len(combined_items) > 5:
                                            combined_items = combined_items[-5:]

                                        # Save combined list to item_list for selection logic
                                        item_list = combined_items

                                        idx = 1
                                        for item_type, item_id, item in item_list:
                                            status = (
                                                "[dim](archived)[/dim]" if item.archived_at else ""
                                            )

                                            if item_type == "screenshot":
                                                console.print(
                                                    f"{idx}. [Screenshot] Set #{item.set_id} {status}"
                                                )
                                            else:
                                                # Check for caption type
                                                label = "[Note]"
                                                # Safely check note_type attribute if it exists
                                                if (
                                                    hasattr(item, "note_type")
                                                    and str(item.note_type).lower() == "caption"
                                                ):
                                                    label = "[Caption]"

                                                content_preview = (
                                                    item.content[:50] + "..."
                                                    if len(item.content) > 50
                                                    else item.content
                                                )
                                                console.print(
                                                    f"{idx}. {label} {content_preview} {status}"
                                                )
                                            idx += 1

                                        if item_list:
                                            console.print(
                                                "\nSelect item to archive/unarchive (or 'b' to go back):"
                                            )
                                            choice = Prompt.ask("Enter item number", default="b")

                                            if choice.lower() != "b" and choice.isdigit():
                                                item_idx = int(choice) - 1
                                                if 0 <= item_idx < len(item_list):
                                                    item_type, item_id, item = item_list[item_idx]

                                                    # Toggle archive status
                                                    if item.archived_at:
                                                        # Unarchive
                                                        if item_type == "screenshot":
                                                            success = db_ops.unarchive_screenshot(
                                                                item_id
                                                            )
                                                            action = "unarchived"
                                                        else:
                                                            success = db_ops.unarchive_note(item_id)
                                                            action = "unarchived"
                                                    # Archive
                                                    elif item_type == "screenshot":
                                                        success = db_ops.archive_screenshot(item_id)
                                                        action = "archived"
                                                    else:
                                                        success = db_ops.archive_note(item_id)
                                                        action = "archived"

                                                    if success:
                                                        if item_type == "screenshot":
                                                            if action == "archived":
                                                                # Archived via edit list
                                                                config.log_entry(
                                                                    f"ARCHIVED: Screenshot (set #{item.set_id})",
                                                                    terminal_message=f"{action.capitalize()} screenshot (set #{item.set_id}).",
                                                                )
                                                            else:
                                                                # Unarchived via edit list
                                                                config.log_entry(
                                                                    f"UNARCHIVED: Screenshot (set #{item.set_id})",
                                                                    terminal_message=f"{action.capitalize()} screenshot (set #{item.set_id}).",
                                                                )
                                                        else:
                                                            content_preview = (
                                                                item.content[:50] + "..."
                                                                if len(item.content) > 50
                                                                else item.content
                                                            )
                                                            if action == "archived":
                                                                # Archived note/caption via edit list
                                                                config.log_entry(
                                                                    f"ARCHIVED: Note: {content_preview}",
                                                                    terminal_message=f"{action.capitalize()} note: {content_preview}",
                                                                )
                                                            else:
                                                                # Unarchived note/caption via edit list
                                                                config.log_entry(
                                                                    f"UNARCHIVED: Note: {content_preview}",
                                                                    terminal_message=f"{action.capitalize()} note: {content_preview}",
                                                                )
                                                    else:
                                                        console.print(f"Failed to {action} item.")
                                                else:
                                                    console.print("Invalid selection.")
                                            elif choice.lower() == "b":
                                                console.print("Cancelled.")
                                            else:
                                                console.print("Invalid input.")
                                        else:
                                            console.print("No items found.")
                                else:
                                    console.print(
                                        "Database logging is not available. Cannot manage items."
                                    )
                            except Exception as e:
                                console.print(f"Error managing items: {e}")

                            console.print(
                                f"\n[green]Status: Manual mode | Display: {config.mode} | Set: #{config.set_id}[/green]"
                            )
                        elif key == "d":
                            # Change display mode
                            displays = get_connected_displays()
                            mode_options = (
                                ["all", "window"] + [f"display{d}" for d in displays] + ["custom"]
                            )
                            option_labels = (
                                ["all (all displays)", "window (selected window)"]
                                + [f"display{d} (Display {d})" for d in displays]
                                + ["custom (choose displays)"]
                            )
                            console.print("\n[bold]Available display modes:[/bold]")
                            for i, label in enumerate(option_labels, 1):
                                console.print(f"{i}. {label}")
                            mode_choice = Prompt.ask(
                                "Choose display mode",
                                choices=[str(i) for i in range(1, len(mode_options) + 1)],
                                default="1",
                            )
                            new_mode = mode_options[int(mode_choice) - 1]
                            custom_displays = None
                            if new_mode == "custom":
                                while True:
                                    custom_input = Prompt.ask(
                                        f"Enter display numbers separated by space or comma (available: {' '.join(str(d) for d in displays)})"
                                    )
                                    parts = [
                                        p
                                        for p in custom_input.replace(",", " ").split()
                                        if p.isdigit()
                                    ]
                                    chosen = [int(p) for p in parts]
                                    if all(d in displays for d in chosen) and chosen:
                                        custom_displays = chosen
                                        break
                                    console.print(
                                        f"[red]Invalid selection. Please choose from: {' '.join(str(d) for d in displays)}[/red]"
                                    )
                                new_mode = f"custom:{','.join(str(d) for d in custom_displays)}"
                            if new_mode != config.mode:
                                config.mode = new_mode
                                config.log_entry(
                                    f"Display mode changed to: {new_mode}",
                                    terminal_message=f"Display mode updated to: {new_mode}",
                                )
                            console.print(
                                f"\n[green]Status: Manual mode | Display: {config.mode} | Set: #{config.set_id}[/green]"
                            )
                        elif key == "p":
                            # Pause session (with cancellable countdown)
                            if config.countdown_for_screenshot(
                                config.countdown_seconds,
                                "The session will pause",
                                start_message="Pausing session...",
                                show_minimize_hint=False,
                                cancel_message="Pause canceled.",
                            ):
                                config.pause_start_time = datetime.now()
                                pause_reason = (
                                    get_text_input("Enter reason for pausing: ")
                                    or "No reason provided"
                                )
                                config.is_paused = True
                                config.log_entry(
                                    f"SESSION PAUSED: {pause_reason}",
                                    terminal_message=(
                                        f"\nSession paused at "
                                        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                                    ),
                                )
                                console.print("Only the following commands will work while paused:")
                                console.print(
                                    "  'r' - Resume the session (will take a post-pause screenshot)"
                                )
                                console.print("  'q' - Quit and take final screenshot")
                                console.print(
                                    "When resuming, no automatic screenshot will be taken in manual mode."
                                )
                                while config.is_paused:
                                    pause_cmd = Prompt.ask(
                                        "PAUSED (r to resume, q to quit)",
                                        choices=["r", "q"],
                                        default="r",
                                    )
                                    if pause_cmd == "r":
                                        pause_end = datetime.now()
                                        pause_delta = pause_end - config.pause_start_time
                                        config.total_paused_seconds += pause_delta.total_seconds()
                                        formatted = config.format_seconds(
                                            pause_delta.total_seconds()
                                        )
                                        config.log_entry(f"Paused for {formatted}")
                                        config.pause_start_time = None
                                        config.is_paused = False
                                        config.log_entry("SESSION RESUMED")

                                        # Check if we're in manual mode - skip taking the screenshot
                                        if timer == "manual":
                                            # In manual mode, show countdown but don't take screenshot
                                            console.print(
                                                "\nResuming in manual mode (no automatic post-pause screenshot)..."
                                            )
                                            # Sleep for a moment to give user time to read message
                                            time.sleep(2)
                                        # In timer mode, take post-pause screenshot
                                        elif config.countdown_for_screenshot(
                                            config.countdown_seconds, "Post-pause screenshot"
                                        ):
                                            config.capture_screenshots("resume")

                                        # No need to display status here as it will be displayed after exiting the pause loop
                                        break
                                    elif pause_cmd == "q":
                                        should_exit = config.handle_exit()
                                        if should_exit:
                                            post_session_report_flow(config)
                                            return 0
                                # Display status after resuming from pause
                                console.print(
                                    f"\n[green]Status: Manual mode | Display: {config.mode} | Set: #{config.set_id}[/green]"
                                )
                        elif key == "t":
                            # Change to scheduled timer mode (exit manual)
                            console.print(f"Current timer: {timer}")
                            new_timer_input = get_text_input(
                                "Enter new timer value in minutes (positive integer): "
                            )
                            try:
                                new_timer = int(new_timer_input)
                                if new_timer > 0:
                                    config.log_entry(
                                        f"Timer changed from {timer} to {new_timer} minutes"
                                    )
                                    if config.countdown_for_screenshot(
                                        config.countdown_seconds, "First screenshot with new timer"
                                    ):
                                        config.capture_screenshots("timer_changed")
                                    timer = new_timer
                                    config.timer = new_timer
                                    manual_mode_active = (
                                        False  # Exit manual mode loop but stay in main loop
                                    )
                                    mode_transition = (
                                        True  # Set transition flag to skip redundant operations
                                    )
                                    break  # Exit manual mode inner loop
                                console.print("Timer must be positive. Timer unchanged.")
                            except ValueError:
                                console.print("Invalid input. Timer unchanged.")
                            console.print(
                                f"\n[green]Status: Manual mode | Display: {config.mode} | Set: #{config.set_id}[/green]"
                            )
                        elif key == "h":
                            # Show help
                            console.print("\n[bold]Available Commands:[/bold]")
                            console.print("s - Take a screenshot")
                            console.print("n - Add a note to the log")
                            console.print("c - Add a caption to the last screenshot")
                            console.print("o - Open the last screenshot in Preview")
                            console.print("l - Open the current session log in TextEdit")
                            console.print("d - Change the display mode")
                            console.print("p - Pause the session")
                            console.print("r - Remove/archive last screenshot or note")
                            console.print("e - Edit/remove specific screenshots or notes")
                            console.print("t - Change the timer duration (exits manual mode)")
                            console.print("q - Quit (no final screenshot will be taken)")
                            console.print("i - Show time in session, today, and project total")
                            console.print("h - Show this help information")
                        elif key in ["q", "ctrl+c"]:
                            should_exit = config.handle_exit()
                            if should_exit:
                                result = post_session_report_flow(config)
                                return result
                    except KeyboardInterrupt:
                        should_exit = config.handle_exit()
                        if should_exit:
                            result = post_session_report_flow(config)
                            return result

                # If we've exited manual mode loop without returning, and timer is not "manual" anymore,
                # continue to the next iteration which will enter timer mode
                continue

            else:
                # Loop mode
                # Only show the commands if we're not transitioning from manual mode
                if not mode_transition:
                    console.print(
                        f"Starting screenshot loop every {timer} minutes for project '{project}'"
                    )
                    console.print(
                        "Press Ctrl+C to stop... (This will take a final screenshot before exiting)"
                    )
                    console.print("Type 'n' to add a note to the log")
                    console.print("Type 'c' to add a caption to the last screenshot")
                    console.print("Type 's' to take a manual screenshot now and reset timer")
                    console.print("Type 'o' to open the last screenshot in Preview")
                    console.print("Type 'l' to open the current session log in TextEdit")
                    console.print("Type 'q' to quit and take final screenshot")
                    console.print("Type 't' to change the timer duration")
                    console.print("Type 'd' to change the display mode")
                    console.print("Type 'p' to pause the session for sensitive activities")
                    console.print("Type 'm' to switch to manual mode")
                    console.print("Type 'r' to archive the last action (screenshot or note)")
                    console.print("Type 'e' to list the last 5 actions")
                    console.print("Type 'i' to show time in session, today, and project total")
                    console.print("Type 'h' for help")

                    if not can_notify:
                        system = platform.system()
                        if system == "Darwin":
                            hint = "Install with: brew install terminal-notifier"
                        elif system == "Linux":
                            hint = "Install notify-send (libnotify)"
                        else:
                            hint = ""
                        console.print(
                            f"[yellow]Warning: Desktop notifications not available. Pre-screenshot notifications will be disabled.{' ' + hint if hint else ''}[/yellow]"
                        )

                    # Initial screenshot countdown (terminal only)
                    countdown_seconds = config.countdown_seconds
                    console.print(
                        f"\nInitial screenshot will be taken in {countdown_seconds} seconds. Please minimize this terminal window..."
                    )
                    with Progress(
                        SpinnerColumn(),
                        TextColumn("[progress.description]{task.description}"),
                        console=console,
                    ) as progress:
                        task = progress.add_task("Taking initial screenshot...", total=countdown_seconds)
                        for i in range(countdown_seconds):
                            progress.update(
                                task,
                                description=f"Taking initial screenshot in {countdown_seconds - i} seconds...",
                            )
                            time.sleep(1)
                            progress.update(task, advance=1)
                        progress.update(task, description="Taking initial screenshot...")

                    # Take initial screenshot
                    config.capture_screenshots("start")
                else:
                    # If transitioning from manual mode, we've already taken a screenshot
                    # Just reset the transition flag after skipping the redundant operations
                    mode_transition = False

                # Main timer loop
                timer_mode_active = True
                while timer_mode_active:
                    try:
                        skip_automatic_screenshot = (
                            False  # Added flag to control automatic screenshots
                        )
                        notification_sent_this_interval = False  # Flag for 30-sec warning
                        next_time = datetime.now().timestamp() + (timer * 60)

                        # Display status with countdown
                        console.print(
                            f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                        )

                        was_exit_canceled = False  # Flag to track if exit was canceled

                        while datetime.now().timestamp() < next_time:
                            try:
                                # Calculate remaining time
                                remaining = int(next_time - datetime.now().timestamp())
                                minutes = remaining // 60
                                seconds = remaining % 60

                                # Update countdown every second for real-time feedback
                                sys.stdout.write(
                                    f"\rNext screenshot in: {minutes:02d}m {seconds:02d}s "
                                )
                                sys.stdout.flush()

                                # --- Send 30-second notification warning ---
                                if (
                                    can_notify
                                    and notifier_path
                                    and should_notify_before_scheduled()
                                    and 29 <= remaining <= 31
                                    and not notification_sent_this_interval
                                ):
                                    try:
                                        _send_pre_screenshot_notification(
                                            notifier_path,
                                            "Screenshot Soon",
                                            "Approx. 30 seconds until next screenshot. Prepare your screen!",
                                        )
                                        notification_sent_this_interval = True
                                    except Exception as e:
                                        # Log unexpected error during notification attempt, but don't crash
                                        console.print(
                                            f"\n[yellow]Warning: Error sending 30s notification: {e}[/yellow]"
                                        )
                                        notification_sent_this_interval = True  # Avoid retrying
                                # -------------------------------------------

                                # Check for keyboard input (non-blocking with timeout)
                                key = get_key()

                                if key:
                                    # Print a newline to clear the countdown display
                                    sys.stdout.write("\n")
                                    sys.stdout.flush()

                                    if key == "ctrl+c":
                                        # Ctrl+C pressed, call handle_exit
                                        should_exit = config.handle_exit()
                                        if should_exit:
                                            result = post_session_report_flow(config)
                                            return result

                                        # If exit was canceled
                                        was_exit_canceled = True
                                        # Show the updated next screenshot time
                                        console.print(
                                            f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                        )

                                    elif key == "n":
                                        note = get_text_input("Enter your note: ")
                                        if note:
                                            config.log_entry(
                                                f"NOTE: {note}",
                                                terminal_message="Note added to log.",
                                            )
                                        console.print(
                                            f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                        )

                                    elif key == "c":
                                        if config.set_id == 0:
                                            console.print("No screenshot sets have been taken yet.")
                                        else:
                                            caption = get_text_input(
                                                f"Enter caption for screenshot set #{config.set_id}: "
                                            )
                                            if caption:
                                                config.log_entry(
                                                    f"CAPTION for screenshot set #{config.set_id}: {caption}",
                                                    terminal_message="Caption added to log.",
                                                )
                                        console.print(
                                            f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                        )

                                    elif key == "o":
                                        if config.last_screenshot and os.path.exists(
                                            config.last_screenshot
                                        ):
                                            console.print(
                                                f"Opening last screenshot: {config.last_screenshot}"
                                            )
                                            if not _open_file_cross_platform(
                                                config.last_screenshot
                                            ):
                                                console.print(
                                                    "[yellow]Could not open screenshot.[/yellow]"
                                                )
                                        else:
                                            console.print("No screenshot available to open.")
                                        console.print(
                                            f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                        )

                                    elif key == "l":
                                        # Open the current session log in a text editor
                                        try:
                                            if (
                                                config.session_log_file
                                                and config.session_log_file.exists()
                                            ):
                                                console.print(
                                                    f"Opening session log: {config.session_log_file}"
                                                )
                                                if not _open_file_with_app(
                                                    str(config.session_log_file), "TextEdit"
                                                ):
                                                    console.print(
                                                        "[yellow]Could not open session log.[/yellow]"
                                                    )
                                            else:
                                                console.print("Session log file not found.")
                                        except Exception as e:
                                            console.print(f"Error opening session log: {e}")
                                        console.print(
                                            f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                        )

                                    elif key == "i":
                                        session_str, today_str, project_str = config.get_time_info()
                                        console.print(f"Time in session: {session_str}")
                                        console.print(f"Time today: {today_str}")
                                        console.print(f"Time in project: {project_str}")
                                        console.print(
                                            f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                        )

                                    elif key == "r":
                                        # Remove/archive last screenshot or note
                                        try:
                                            # Use the existing db_logger from config if available
                                            if (
                                                hasattr(config, "db_logger")
                                                and config.db_logger
                                                and config.db_logger.is_available()
                                                and config.db_logger.current_session_id
                                            ):
                                                db_ops = config.db_logger.db_operations
                                                session_id = config.db_logger.current_session_id

                                                # Get the most recent screenshot and note
                                                screenshots = db_ops.list_screenshots(
                                                    session_id, include_archived=True
                                                )
                                                notes = db_ops.list_notes(
                                                    session_id, include_archived=True
                                                )

                                                # Find the most recent item
                                                latest_screenshot = (
                                                    screenshots[-1] if screenshots else None
                                                )
                                                latest_note = notes[-1] if notes else None

                                                if not latest_screenshot and not latest_note:
                                                    console.print(
                                                        "No screenshots or notes found in this session."
                                                    )
                                                else:
                                                    # Compare timestamps to find the most recent
                                                    latest_item = None
                                                    latest_type = None

                                                    if latest_screenshot and latest_note:
                                                        if (
                                                            latest_screenshot.timestamp
                                                            > latest_note.timestamp
                                                        ):
                                                            latest_item = latest_screenshot
                                                            latest_type = "screenshot"
                                                        else:
                                                            latest_item = latest_note
                                                            latest_type = "note"
                                                    elif latest_screenshot:
                                                        latest_item = latest_screenshot
                                                        latest_type = "screenshot"
                                                    else:
                                                        latest_item = latest_note
                                                        latest_type = "note"

                                                    # Archive the item
                                                    if latest_type == "screenshot":
                                                        success = db_ops.archive_screenshot(
                                                            latest_item.id
                                                        )
                                                        if success:
                                                            # Log with ARCHIVED prefix for clarity in logs
                                                            config.log_entry(
                                                                f"ARCHIVED: Screenshot (last, set #{latest_item.set_id})",
                                                                terminal_message=f"Archived last screenshot (set #{latest_item.set_id}).",
                                                            )
                                                        else:
                                                            console.print(
                                                                "Failed to archive screenshot."
                                                            )
                                                    else:  # note
                                                        success = db_ops.archive_note(
                                                            latest_item.id
                                                        )
                                                        if success:
                                                            content_preview = (
                                                                latest_item.content[:50] + "..."
                                                                if len(latest_item.content) > 50
                                                                else latest_item.content
                                                            )
                                                            # Log with ARCHIVED prefix for clarity in logs
                                                            config.log_entry(
                                                                f"ARCHIVED: Note: {content_preview}",
                                                                terminal_message=f"Archived last note: {content_preview}",
                                                            )
                                                        else:
                                                            console.print("Failed to archive note.")
                                            else:
                                                console.print(
                                                    "Database logging is not available. Cannot archive items."
                                                )
                                        except Exception as e:
                                            console.print(f"Error archiving item: {e}")

                                        console.print(
                                            f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                        )

                                    elif key == "e":
                                        # Edit/remove specific screenshots or notes
                                        try:
                                            # Use the existing db_logger from config if available
                                            if (
                                                hasattr(config, "db_logger")
                                                and config.db_logger
                                                and config.db_logger.is_available()
                                                and config.db_logger.current_session_id
                                            ):
                                                db_ops = config.db_logger.db_operations
                                                session_id = config.db_logger.current_session_id

                                                # Get all screenshots and notes (including archived for management)
                                                screenshots = db_ops.list_screenshots(
                                                    session_id, include_archived=True
                                                )
                                                notes = db_ops.list_notes(
                                                    session_id, include_archived=True
                                                )

                                                if not screenshots and not notes:
                                                    console.print(
                                                        "No screenshots or notes found in this session."
                                                    )
                                                else:
                                                    console.print("\n[bold]Session Items:[/bold]")
                                                    item_list = []

                                                    # Combine and sort items by timestamp
                                                    combined_items = []

                                                    for screenshot in screenshots:
                                                        combined_items.append(
                                                            (
                                                                "screenshot",
                                                                screenshot.id,
                                                                screenshot,
                                                            )
                                                        )

                                                    for note in notes:
                                                        combined_items.append(
                                                            ("note", note.id, note)
                                                        )

                                                    # Sort by timestamp
                                                    combined_items.sort(
                                                        key=lambda x: x[2].timestamp
                                                    )

                                                    # Show only the last 5 actions to keep it simple
                                                    if len(combined_items) > 5:
                                                        combined_items = combined_items[-5:]

                                                    # Save combined list to item_list for selection logic
                                                    item_list = combined_items

                                                    idx = 1
                                                    for item_type, item_id, item in item_list:
                                                        status = (
                                                            "[dim](archived)[/dim]"
                                                            if item.archived_at
                                                            else ""
                                                        )

                                                        if item_type == "screenshot":
                                                            console.print(
                                                                f"{idx}. [Screenshot] Set #{item.set_id} {status}"
                                                            )
                                                        else:
                                                            # Check for caption type
                                                            label = "[Note]"
                                                            # Safely check note_type attribute if it exists
                                                            if (
                                                                hasattr(item, "note_type")
                                                                and str(item.note_type).lower()
                                                                == "caption"
                                                            ):
                                                                label = "[Caption]"

                                                            content_preview = (
                                                                item.content[:50] + "..."
                                                                if len(item.content) > 50
                                                                else item.content
                                                            )
                                                            console.print(
                                                                f"{idx}. {label} {content_preview} {status}"
                                                            )
                                                        idx += 1

                                                    if item_list:
                                                        console.print(
                                                            "\nSelect item to archive/unarchive (or 'b' to go back):"
                                                        )
                                                        choice = Prompt.ask(
                                                            "Enter item number", default="b"
                                                        )

                                                        if (
                                                            choice.lower() != "b"
                                                            and choice.isdigit()
                                                        ):
                                                            item_idx = int(choice) - 1
                                                            if 0 <= item_idx < len(item_list):
                                                                item_type, item_id, item = (
                                                                    item_list[item_idx]
                                                                )

                                                                # Toggle archive status
                                                                if item.archived_at:
                                                                    # Unarchive
                                                                    if item_type == "screenshot":
                                                                        success = db_ops.unarchive_screenshot(
                                                                            item_id
                                                                        )
                                                                        action = "unarchived"
                                                                    else:
                                                                        success = (
                                                                            db_ops.unarchive_note(
                                                                                item_id
                                                                            )
                                                                        )
                                                                        action = "unarchived"
                                                                # Archive
                                                                elif item_type == "screenshot":
                                                                    success = (
                                                                        db_ops.archive_screenshot(
                                                                            item_id
                                                                        )
                                                                    )
                                                                    action = "archived"
                                                                else:
                                                                    success = db_ops.archive_note(
                                                                        item_id
                                                                    )
                                                                    action = "archived"

                                                                if success:
                                                                    if item_type == "screenshot":
                                                                        if action == "archived":
                                                                            # Archived via edit list
                                                                            config.log_entry(
                                                                                f"ARCHIVED: Screenshot (set #{item.set_id})",
                                                                                terminal_message=f"{action.capitalize()} screenshot (set #{item.set_id}).",
                                                                            )
                                                                        else:
                                                                            # Unarchived via edit list
                                                                            config.log_entry(
                                                                                f"UNARCHIVED: Screenshot (set #{item.set_id})",
                                                                                terminal_message=f"{action.capitalize()} screenshot (set #{item.set_id}).",
                                                                            )
                                                                    else:
                                                                        content_preview = (
                                                                            item.content[:50]
                                                                            + "..."
                                                                            if len(item.content)
                                                                            > 50
                                                                            else item.content
                                                                        )
                                                                        if action == "archived":
                                                                            # Archived note/caption via edit list
                                                                            config.log_entry(
                                                                                f"ARCHIVED: Note: {content_preview}",
                                                                                terminal_message=f"{action.capitalize()} note: {content_preview}",
                                                                            )
                                                                        else:
                                                                            # Unarchived note/caption via edit list
                                                                            config.log_entry(
                                                                                f"UNARCHIVED: Note: {content_preview}",
                                                                                terminal_message=f"{action.capitalize()} note: {content_preview}",
                                                                            )
                                                                else:
                                                                    console.print(
                                                                        f"Failed to {action} item."
                                                                    )
                                                            else:
                                                                console.print("Invalid selection.")
                                                        elif choice.lower() == "b":
                                                            console.print("Cancelled.")
                                                        else:
                                                            console.print("Invalid input.")
                                                    else:
                                                        console.print("No items found.")
                                            else:
                                                console.print(
                                                    "Database logging is not available. Cannot manage items."
                                                )
                                        except Exception as e:
                                            console.print(f"Error managing items: {e}")

                                        console.print(
                                            f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                        )

                                    elif key == "s":
                                        # Show countdown for manual screenshot
                                        if config.countdown_for_screenshot(config.countdown_seconds, "Manual screenshot"):
                                            config.capture_screenshots("manual")
                                            next_time = datetime.now().timestamp() + (timer * 60)
                                            skip_automatic_screenshot = (
                                                True  # Skip the automatic screenshot this cycle
                                            )
                                            console.print(
                                                f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                            )
                                        break

                                    elif key == "q":
                                        # Call handle_exit but keep track if it returns (meaning it was canceled)
                                        before_exit = datetime.now().timestamp()
                                        should_exit = config.handle_exit()
                                        if should_exit:
                                            result = post_session_report_flow(config)
                                            return result

                                        # If we get here, exit was canceled, so we need to restore the countdown timer
                                        was_exit_canceled = True
                                        # Calculate the time spent in the handle_exit function
                                        time_elapsed = datetime.now().timestamp() - before_exit
                                        # Adjust the next_time by adding the elapsed time so we don't lose time from the countdown
                                        next_time += time_elapsed
                                        # Show the updated next screenshot time
                                        console.print(
                                            f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                        )

                                    elif key == "m":
                                        # Switch to manual mode with countdown
                                        if config.countdown_for_screenshot(
                                            config.countdown_seconds,
                                            "Switching to manual mode",
                                            start_message="Switching to manual mode...",
                                            show_minimize_hint=False,
                                            cancel_message="Canceled switch to manual mode.",
                                        ):
                                            config.log_entry(
                                                "Switched from timer mode to manual mode"
                                            )
                                            timer = "manual"
                                            config.timer = "manual"
                                            timer_mode_active = False
                                            break
                                        else:
                                            console.print(
                                                f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                            )

                                    elif key == "t":
                                        # Get current timer value
                                        console.print(f"Current timer: {timer} minutes")
                                        # Ask for new timer value
                                        console.print(
                                            "Enter a new timer value in minutes, or type 'manual' to switch to manual mode"
                                        )
                                        new_timer_input = get_text_input(
                                            "Timer value (or 'manual'): "
                                        )

                                        # Check if user wants to switch to manual mode
                                        if new_timer_input.lower() == "manual":
                                            console.print("Switching to manual mode...")
                                            config.log_entry(
                                                "Switched from timer mode to manual mode via timer change"
                                            )
                                            timer = "manual"
                                            config.timer = "manual"
                                            timer_mode_active = False
                                            break

                                        # Check if input is empty (user wants to keep current value)
                                        if not new_timer_input:
                                            console.print(
                                                f"Timer unchanged. Remaining: {minutes}m {seconds}s"
                                            )
                                            console.print(
                                                f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                            )
                                            continue
                                        # Convert to integer
                                        try:
                                            new_timer = int(new_timer_input)
                                        except ValueError:
                                            console.print("Invalid input. Timer unchanged.")
                                            console.print(
                                                f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                            )
                                            continue
                                        # Validate timer value
                                        if new_timer <= 0:
                                            console.print(
                                                "Timer must be a positive value. Timer unchanged."
                                            )
                                            console.print(
                                                f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                            )
                                            continue
                                        # Check if the timer value actually changed
                                        if new_timer == timer:
                                            console.print(
                                                f"Timer unchanged. Remaining: {minutes}m {seconds}s"
                                            )
                                            console.print(
                                                f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                            )
                                            continue
                                        # Log the timer change
                                        config.log_entry(
                                            f"Timer changed from {timer} to {new_timer} minutes"
                                        )
                                        timer = new_timer
                                        config.timer = new_timer
                                        # Add countdown before restarting with new timer
                                        if config.countdown_for_screenshot(
                                            config.countdown_seconds, "First screenshot with new timer"
                                        ):
                                            # Take a screenshot with the new timer
                                            config.capture_screenshots("timer_changed")
                                            # Set new timer
                                            next_time = datetime.now().timestamp() + (timer * 60)
                                            skip_automatic_screenshot = (
                                                True  # Skip the automatic screenshot
                                            )
                                            console.print(f"Timer updated to {timer} minutes.")
                                            console.print(
                                                f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                            )
                                            break

                                    elif key == "d":
                                        displays = get_connected_displays()
                                        mode_options = (
                                            ["all", "window"]
                                            + [f"display{d}" for d in displays]
                                            + ["custom"]
                                        )
                                        option_labels = (
                                            ["all (all displays)", "window (selected window)"]
                                            + [f"display{d} (Display {d})" for d in displays]
                                            + ["custom (choose displays)"]
                                        )
                                        console.print("\n[bold]Available display modes:[/bold]")
                                        for i, label in enumerate(option_labels, 1):
                                            console.print(f"{i}. {label}")
                                        mode_choice = Prompt.ask(
                                            "Choose display mode",
                                            choices=[
                                                str(i) for i in range(1, len(mode_options) + 1)
                                            ],
                                            default="1",
                                        )
                                        new_mode = mode_options[int(mode_choice) - 1]
                                        custom_displays = None
                                        if new_mode == "custom":
                                            while True:
                                                custom_input = Prompt.ask(
                                                    f"Enter display numbers separated by space or comma (available: {' '.join(str(d) for d in displays)})"
                                                )
                                                parts = [
                                                    p
                                                    for p in custom_input.replace(",", " ").split()
                                                    if p.isdigit()
                                                ]
                                                chosen = [int(p) for p in parts]
                                                if all(d in displays for d in chosen) and chosen:
                                                    custom_displays = chosen
                                                    break
                                                else:
                                                    console.print(
                                                        f"[red]Invalid selection. Please choose from: {' '.join(str(d) for d in displays)}[/red]"
                                                    )
                                            new_mode = f"custom:{','.join(str(d) for d in custom_displays)}"
                                        if new_mode != config.mode:
                                            config.mode = new_mode
                                            config.log_entry(
                                                f"Display mode changed to: {new_mode}",
                                                terminal_message=f"Display mode updated to: {new_mode}",
                                            )
                                        console.print(
                                            f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                        )

                                    elif key == "p":
                                        if config.countdown_for_screenshot(
                                            config.countdown_seconds,
                                            "The session will pause",
                                            start_message="Pausing session...",
                                            show_minimize_hint=False,
                                            cancel_message="Pause canceled.",
                                        ):
                                            config.pause_start_time = datetime.now()
                                            pause_reason = get_text_input(
                                                "Enter reason for pausing: "
                                            )
                                            if not pause_reason:
                                                pause_reason = "No reason provided"

                                            config.is_paused = True
                                            config.log_entry(
                                                f"SESSION PAUSED: {pause_reason}",
                                                terminal_message=(
                                                    f"\nSession paused at "
                                                    f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                                                ),
                                            )
                                            console.print(
                                                "Only the following commands will work while paused:"
                                            )
                                            console.print(
                                                "  'r' - Resume the session (will take a post-pause screenshot)"
                                            )
                                            console.print("  'q' - Quit and take final screenshot")

                                            while config.is_paused:
                                                pause_cmd = Prompt.ask(
                                                    "\nPAUSED", choices=["r", "q"], default="r"
                                                )
                                                if pause_cmd == "r":
                                                    # Calculate pause duration
                                                    pause_end = datetime.now()
                                                    pause_delta = (
                                                        pause_end - config.pause_start_time
                                                    )
                                                    config.total_paused_seconds += (
                                                        pause_delta.total_seconds()
                                                    )
                                                    formatted = config.format_seconds(
                                                        pause_delta.total_seconds()
                                                    )
                                                    config.log_entry(f"Paused for {formatted}")
                                                    config.pause_start_time = None
                                                    config.is_paused = False
                                                    config.log_entry("SESSION RESUMED")

                                                    # Check if we're in manual mode - skip taking the screenshot
                                                    if timer == "manual":
                                                        # In manual mode, show countdown but don't take screenshot
                                                        console.print(
                                                            "\nResuming in manual mode (no automatic post-pause screenshot)..."
                                                        )
                                                        # Sleep for a moment to give user time to read message
                                                        time.sleep(2)
                                                    # In timer mode, take post-pause screenshot
                                                    elif config.countdown_for_screenshot(
                                                        config.countdown_seconds,
                                                        "Post-pause screenshot",
                                                    ):
                                                        config.capture_screenshots("resume")

                                                    # Reset the timer but don't display status yet
                                                    next_time = datetime.now().timestamp() + (
                                                        timer * 60
                                                    )
                                                    break
                                                elif pause_cmd == "q":
                                                    # Proceed to exit (pause finalize will occur in handle_exit)
                                                    should_exit = config.handle_exit()
                                                    if should_exit:
                                                        post_session_report_flow(config)
                                                        return 0

                                            # Display status after resuming from pause (outside the pause loop)
                                            console.print(
                                                f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                            )
                                    elif key == "h":
                                        # Show help
                                        console.print("\n[bold]Available Commands:[/bold]")
                                        console.print(
                                            "s - Take a manual screenshot now and reset timer"
                                        )
                                        console.print("n - Add a note to the log")
                                        console.print("c - Add a caption to the last screenshot")
                                        console.print("o - Open the last screenshot in Preview")
                                        console.print(
                                            "l - Open the current session log in TextEdit"
                                        )
                                        console.print("d - Change the display mode")
                                        console.print("p - Pause the session")
                                        console.print(
                                            "t - Change the timer duration or switch to manual mode"
                                        )
                                        console.print(
                                            "m - Switch to manual mode (with 10-second countdown)"
                                        )
                                        console.print("r - Remove/archive last screenshot or note")
                                        console.print(
                                            "e - Edit/remove specific screenshots or notes"
                                        )
                                        console.print("q - Quit and take final screenshot")
                                        console.print(
                                            "i - Show time in session, today, and project total"
                                        )
                                        console.print("h - Show this help information")

                            except KeyboardInterrupt:
                                # Ctrl+C was pressed during the countdown
                                should_exit = config.handle_exit()
                                if should_exit:
                                    result = post_session_report_flow(config)
                                    return result

                                # If we get here, exit was canceled, so we need to restore the countdown timer
                                was_exit_canceled = True
                                # Show the updated next screenshot time
                                console.print(
                                    f"\n[green]Status: Timer mode | Display: {config.mode} | Set: #{config.set_id} | Next: {datetime.fromtimestamp(next_time).strftime('%H:%M:%S')}[/green]"
                                )

                        # Only take the automatic screenshot if we didn't just take a manual one
                        # and if we didn't just cancel an exit operation
                        if (
                            not skip_automatic_screenshot
                            and not was_exit_canceled
                            and timer_mode_active
                        ):
                            console.print()  # New line after countdown
                            config.capture_screenshots()

                        # Reset the exit canceled flag for the next cycle
                        was_exit_canceled = False

                    except KeyboardInterrupt:
                        # Ctrl+C was pressed
                        should_exit = config.handle_exit()
                        if should_exit:
                            result = post_session_report_flow(config)
                            return result
    except (KeyboardInterrupt, click.Abort):  # handle user aborts gracefully
        # On abrupt aborts, still attempt to finalize the DB session
        try:
            config.update_db_session()
        except Exception:
            pass
        console.print("\nThanks for using ScreenShooter. Goodbye!")
        return 0
    # Normal end of session flow
    config.update_db_session()
    result = post_session_report_flow(config)
    return result


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (KeyboardInterrupt, click.Abort):  # handle user aborts gracefully
        console.print("\nThanks for using ScreenShooter. Goodbye!")
        sys.exit(0)
