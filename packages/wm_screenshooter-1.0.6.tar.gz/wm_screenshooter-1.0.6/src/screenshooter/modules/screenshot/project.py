#!/usr/bin/env python3
"""Project metadata model for project.json."""

from datetime import datetime

from pydantic import BaseModel, Field


class ProjectMetadata(BaseModel):
    """Project metadata stored in project.json."""

    project_name: str
    directory_name: str
    client_name: str
    started_at: str = Field(
        default_factory=lambda: datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    )
    last_updated: str = Field(
        default_factory=lambda: datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    )
    finished_at: str = ""
    archived_at: str = ""

