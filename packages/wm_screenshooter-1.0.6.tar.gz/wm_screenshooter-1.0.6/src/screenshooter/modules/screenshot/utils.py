#!/usr/bin/env python3
"""Utility functions for the screenshot module."""

import platform
import sys
from typing import Any, Dict, List, Optional

# Platform-specific imports for keyboard input
if platform.system() == "Windows":
    import msvcrt
else:
    import select
    import termios
    import tty


# Sentinel value for 'back' option in interactive prompts
BACK_OPTION = object()


def get_key() -> Optional[str]:
    """Get a single keypress from the user with a timeout.

    Works cross-platform on Windows, macOS, and Linux.
    """
    if platform.system() == "Windows":
        return _get_key_windows()
    else:
        return _get_key_unix()


def _get_key_windows() -> Optional[str]:
    """Get a single keypress on Windows."""
    try:
        import time

        # Check if a key is available (non-blocking)
        start = time.time()
        while time.time() - start < 0.1:
            if msvcrt.kbhit():
                ch = msvcrt.getch()
                # Handle special keys
                if ch == b"\x03":  # Ctrl+C
                    return "ctrl+c"
                try:
                    return ch.decode("utf-8").lower()
                except UnicodeDecodeError:
                    return None
            time.sleep(0.01)
        return None
    except Exception:
        return None


def _get_key_unix() -> Optional[str]:
    """Get a single keypress on Unix-like systems (macOS, Linux)."""
    try:
        # Save terminal settings
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)

        # Set terminal to raw mode
        tty.setraw(fd)

        # Use select to check if input is available (with timeout of 0.1 seconds)
        rlist, _, _ = select.select([sys.stdin], [], [], 0.1)

        if rlist:
            # Input is available, read it
            ch = sys.stdin.read(1)
            key = ch.lower()

            # Check for Ctrl+C (ASCII value 3) and handle it specially
            if ord(ch) == 3:  # Ctrl+C pressed
                # Restore terminal settings immediately
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                key = "ctrl+c"

            # Flush any remaining input to prevent key repeat issues
            termios.tcflush(sys.stdin, termios.TCIOFLUSH)
        else:
            # No input available
            key = None

        # Restore terminal settings (return to cooked/echo mode for next input())
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

        return key
    except Exception:
        # If anything goes wrong, return None
        return None


def get_text_input(prompt: str) -> str:
    """Get free-form text input with robust backspace/line-editing support.

    Works cross-platform on Windows, macOS, and Linux.
    Ensures the terminal is in canonical (cooked) mode with echo enabled while
    reading, regardless of any prior raw mode usage elsewhere.
    """
    try:
        import readline  # noqa: F401
    except ImportError:
        pass

    if platform.system() == "Windows":
        # Windows doesn't need special terminal mode handling
        return input(prompt)

    fd = None
    old_settings = None
    try:
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        cooked = termios.tcgetattr(fd)
        # Enable canonical input (ICANON) and echo (ECHO)
        cooked[3] = cooked[3] | termios.ICANON | termios.ECHO
        termios.tcsetattr(fd, termios.TCSADRAIN, cooked)
        return input(prompt)
    finally:
        if fd is not None and old_settings is not None:
            try:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            except Exception:
                pass


def get_connected_displays() -> List[int]:
    """Return a list of connected display numbers (1-based).

    Uses mss for cross-platform monitor detection.
    """
    try:
        import mss

        with mss.mss() as sct:
            # mss.monitors[0] is the "all monitors" virtual screen
            # mss.monitors[1:] are individual monitors
            num_monitors = len(sct.monitors) - 1
            return list(range(1, num_monitors + 1)) if num_monitors > 0 else [1]
    except Exception:
        return [1]  # Fallback to at least one display


def create_slash_command_system(commands: Dict[str, Dict[str, Any]]) -> None:
    """Create a simpler slash command system that doesn't interfere with input visibility.

    Args:
        commands: Dictionary mapping command names to dictionaries with 'description' and 'handler' keys

    Returns:
        A function that handles command input and processing
    """

    def process_commands() -> Optional[str]:
        """Process slash commands, returning the command name if valid.

        Returns:
            The command name (without slash) or None if no command/invalid
        """
        key = get_key()
        if not key:
            return None

        if key == "ctrl+c":
            return "ctrl+c"

        # Return the key directly for command handlers to process
        return key

    return process_commands
