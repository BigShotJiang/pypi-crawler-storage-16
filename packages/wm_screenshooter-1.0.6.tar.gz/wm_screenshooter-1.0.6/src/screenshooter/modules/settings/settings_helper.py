#!/usr/bin/env python3
"""Settings helper for accessing application settings across modules."""

import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional, Union

from screenshooter.modules.settings.models import AppSettings, SettingsManager

# Configure logging
logger = logging.getLogger(__name__)

# Singleton settings instance for caching
_settings_instance = None


def get_config_dir() -> str:
    """Return the application config directory, creating it if missing."""
    config_dir = Path(os.path.expanduser("~/.config/screenshooter"))
    config_dir.mkdir(parents=True, exist_ok=True)
    return str(config_dir)


def get_settings() -> AppSettings:
    """Get the application settings. Results are cached for performance."""
    global _settings_instance

    if _settings_instance is None:
        manager = SettingsManager()
        _settings_instance = manager.load_settings()

    return _settings_instance


def get_screenshots_dir() -> str:
    """Get the base screenshots directory from settings."""
    settings = get_settings()
    screenshots_dir = settings.storage.base_directory

    # Create the directory if it doesn't exist
    Path(screenshots_dir).mkdir(parents=True, exist_ok=True)

    return screenshots_dir


def get_default_screenshot_mode() -> str:
    """Get the default screenshot mode from settings."""
    settings = get_settings()
    return settings.screenshot.default_mode


def get_default_screenshot_timer() -> Union[int, str]:
    """Get the default screenshot timer from settings."""
    settings = get_settings()
    return settings.screenshot.default_timer


def get_default_screenshot_format() -> str:
    """Get the default screenshot format from settings."""
    settings = get_settings()
    return settings.screenshot.default_format


def get_default_screenshot_quality() -> int:
    """Get the default screenshot quality from settings."""
    settings = get_settings()
    return settings.screenshot.default_quality


def get_default_countdown() -> int:
    """Get the default countdown before capture from settings."""
    settings = get_settings()
    return settings.screenshot.countdown_before_capture


def are_notifications_enabled() -> bool:
    """Check if notifications are enabled."""
    settings = get_settings()
    return settings.notifications.enabled


def get_notification_sound_enabled() -> bool:
    """Check if notification sound is enabled."""
    settings = get_settings()
    return settings.notifications.sound and settings.notifications.enabled


def get_notification_display_time() -> int:
    """Get notification display time in seconds."""
    settings = get_settings()
    return settings.notifications.display_time


def should_notify_before_scheduled() -> bool:
    """Check if pre-scheduled notification is enabled."""
    settings = get_settings()
    # Ensure the setting exists for compatibility with older settings files
    return (
        getattr(settings.notifications, "notify_before_scheduled", True)
        and settings.notifications.enabled
    )


def get_email_settings() -> Dict[str, Any]:
    """Get email settings as a dictionary."""
    settings = get_settings()
    return {
        "enabled": settings.email.enabled,
        "sender_email": settings.email.sender_email,
        "sender_name": settings.email.sender_name,
        "smtp_server": settings.email.smtp_server,
        "smtp_port": settings.email.smtp_port,
        "connection_security": settings.email.connection_security,
        "username": settings.email.username,
        "password": settings.email.password,
        "default_recipients": settings.email.default_recipients,
        "recipient_type": settings.email.recipient_type,
        "always_include_defaults": settings.email.always_include_defaults,
    }


def is_auto_organize_enabled() -> bool:
    """Check if auto-organize is enabled."""
    settings = get_settings()
    return settings.storage.auto_organize


def is_auto_cleanup_enabled() -> bool:
    """Check if auto-cleanup is enabled."""
    settings = get_settings()
    return settings.storage.auto_cleanup


def get_max_screenshot_age() -> int:
    """Get maximum screenshot age in days before cleanup."""
    settings = get_settings()
    return settings.storage.max_screenshot_age


# PDF optimization settings
def get_pdf_optimization_settings() -> Dict[str, Any]:
    """Get PDF optimization settings as a dictionary."""
    settings = get_settings()
    return {
        "optimize_pdf": settings.screenshot.optimize_pdf,
        "image_quality": settings.screenshot.pdf_image_quality,
        "image_format": settings.screenshot.pdf_image_format,
        "max_dimension": settings.screenshot.pdf_max_dimension,
        "use_thumbnails": settings.screenshot.pdf_use_thumbnails,
        "thumbnail_size": settings.screenshot.pdf_thumbnail_size,
        "compress_pdf": settings.screenshot.pdf_compression,
        "page_size": settings.screenshot.pdf_page_size
        if hasattr(settings.screenshot, "pdf_page_size")
        else "A4",
    }


def get_pdf_page_size() -> str:
    """Get the default PDF page size from settings."""
    settings = get_settings()
    return (
        settings.screenshot.pdf_page_size if hasattr(settings.screenshot, "pdf_page_size") else "A4"
    )


def should_optimize_pdf() -> bool:
    """Check if PDF optimization is enabled."""
    settings = get_settings()
    return settings.screenshot.optimize_pdf


# Reload settings (used when settings have been changed)
def save_settings(settings: AppSettings, *, allow_overwrite_on_failed_load: bool = False) -> None:
    """Save settings to disk."""
    manager = SettingsManager()
    manager.save_settings(settings, allow_overwrite_on_failed_load=allow_overwrite_on_failed_load)
    # Clear the cached instance so next get_settings() will reload
    global _settings_instance
    _settings_instance = None


def reload_settings() -> None:
    """Reload settings from disk."""
    global _settings_instance
    _settings_instance = None
    get_settings()  # This will reload the settings


# --- S3/R2 Custom Link Helpers ---


def is_s3_custom_link_enabled() -> bool:
    """Check if S3/R2 custom link functionality is enabled."""
    settings = get_settings()
    return settings.s3.enabled and settings.s3.use_custom_link


def get_s3_custom_link_base_url() -> Optional[str]:
    """Get the base URL for S3/R2 custom links."""
    settings = get_settings()
    return settings.s3.custom_link_base_url if is_s3_custom_link_enabled() else None


def get_s3_cloudflare_config() -> Dict[str, Optional[str]]:
    """Get Cloudflare configuration for S3 custom links as a dictionary."""
    settings = get_settings()
    if is_s3_custom_link_enabled():
        return {
            "account_id": settings.s3.cloudflare_account_id,
            "kv_namespace_id": settings.s3.cloudflare_kv_namespace_id,
            "api_token": settings.s3.cloudflare_api_token,
        }
    else:
        return {
            "account_id": None,
            "kv_namespace_id": None,
            "api_token": None,
        }


# --- Data Source Helpers ---


def get_data_source() -> str:
    """Get the current data source setting.

    Returns:
        'log_files' or 'database'
    """
    settings = get_settings()
    data_source = getattr(settings, "data_source", "log_files")

    # Validate the data source value
    if data_source not in ["log_files", "database"]:
        logger.warning(f"Invalid data_source value '{data_source}', defaulting to 'log_files'")
        return "log_files"

    return data_source


def should_use_database() -> bool:
    """Check if database should be used as the data source.

    Returns:
        True if database is configured as data source, False otherwise
    """
    return get_data_source() == "database"


def should_use_log_files() -> bool:
    """Check if log files should be used as the data source.

    Returns:
        True if log files are configured as data source, False otherwise
    """
    return get_data_source() == "log_files"
