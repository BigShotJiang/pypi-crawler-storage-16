#!/usr/bin/env python3
"""Upgrade check module for ScreenShooter.

This module provides functionality to check for new versions of ScreenShooter
using the GitLab releases API.
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import requests
from packaging import version

from screenshooter import __version__

logger = logging.getLogger(__name__)


def format_release_description_preview(description: str) -> str:
    """Format a release description into a preview with first few lines.

    Args:
        description: The full release description text

    Returns:
        Formatted preview string with dimmed styling, or empty string if no description
    """
    if not description:
        return ""

    desc = description.strip()
    if not desc:
        return ""

    # Clean up markdown and limit length
    desc = desc.replace("\r\n", "\n").replace("\r", "\n")
    lines = desc.split("\n")

    # Take first few lines, limit total length
    MAX_PREVIEW_LENGTH = 200
    MAX_PREVIEW_LINES = 5
    preview_lines = []
    total_length = 0
    truncated = False

    for line in lines[:MAX_PREVIEW_LINES]:  # First 5 lines max
        if total_length + len(line) > MAX_PREVIEW_LENGTH:
            truncated_line = line[: MAX_PREVIEW_LENGTH - total_length] + "..."
            preview_lines.append(truncated_line)
            truncated = True
            break
        preview_lines.append(line)
        total_length += len(line) + 1  # +1 for newline

    # Check if there are more lines or content was truncated
    has_more = len(lines) > MAX_PREVIEW_LINES or truncated

    if preview_lines:
        desc_preview = "\n".join(preview_lines)
        if has_more:
            desc_preview += "\n[dim]...and more[/dim]"
        return f"\n[dim]{desc_preview}[/dim]"

    return ""


class GitLabUpgradeChecker:
    """Handles checking for application updates via GitLab releases API."""

    # GitLab project details
    GITLAB_API_URL = "https://gitlab.com/api/v4/projects/workmaster%2Fscreenshooter/releases"

    @staticmethod
    def get_latest_release() -> Optional[Dict[str, Any]]:
        """Fetch the latest release from GitLab.

        Returns:
            Dictionary containing release information or None if failed
        """
        try:
            response = requests.get(GitLabUpgradeChecker.GITLAB_API_URL, timeout=10)
            response.raise_for_status()

            releases = response.json()
            if not releases:
                logger.debug("No releases found")
                return None

            # Get the first (latest) release
            latest = releases[0]

            # Extract version from tag_name (remove 'v' prefix if present)
            tag_name = latest.get("tag_name", "").lstrip("v")

            return {
                "version": tag_name,
                "name": latest.get("name", ""),
                "description": latest.get("description", ""),
                "released_at": latest.get("released_at", ""),
                "assets": latest.get("assets", {}).get("links", []),
                "tag_name": latest.get("tag_name", ""),
            }

        except (requests.RequestException, json.JSONDecodeError, KeyError) as e:
            logger.debug(f"Failed to fetch GitLab releases: {e}")
            return None

    @staticmethod
    def get_latest_version() -> Optional[str]:
        """Get just the latest version string.

        Returns:
            Latest version string or None if failed
        """
        release = GitLabUpgradeChecker.get_latest_release()
        return release["version"] if release else None

    @staticmethod
    def is_upgrade_available() -> Tuple[bool, Optional[str], Optional[Dict[str, Any]]]:
        """Check if an upgrade is available.

        Returns:
            Tuple of (is_available, latest_version, release_info)
        """
        release = GitLabUpgradeChecker.get_latest_release()
        if not release:
            return False, None, None

        latest_version = release["version"]
        if not latest_version:
            return False, None, None

        try:
            current_ver = version.parse(__version__)
            latest_ver = version.parse(latest_version)
            is_available = latest_ver > current_ver
            return is_available, latest_version, release if is_available else None
        except version.InvalidVersion:
            logger.warning(
                f"Invalid version format: current={__version__}, latest={latest_version}"
            )
            return False, None, None

    @staticmethod
    def check_and_notify(console=None) -> bool:
        """Check for updates and display notification if needed.

        Args:
            console: Rich console instance for output (optional)

        Returns:
            True if upgrade is available and notification shown, False otherwise
        """
        is_available, latest_version, release_info = GitLabUpgradeChecker.is_upgrade_available()

        if is_available and latest_version and release_info:
            # Check if user wants to skip this version
            from screenshooter.modules.settings.settings_helper import get_settings

            settings = get_settings()
            if settings.upgrade_check.skip_version == latest_version:
                return False  # Skip notification for this version

            message = "\n[bold yellow]A new version of ScreenShooter is available![/bold yellow]\n"
            message += f"Current version: {__version__}\n"
            message += f"Latest version: {latest_version}\n"

            if release_info.get("name"):
                message += f"Release: {release_info['name']}\n"

            message += (
                "[dim]Download: "
                f"https://gitlab.com/workmaster/screenshooter/-/releases/{release_info['tag_name']}[/dim]"
            )

            # Show release notes preview if available
            desc_preview = format_release_description_preview(release_info.get("description", ""))
            if desc_preview:
                message += desc_preview

            if console:
                console.print(message)
            else:
                print(message)

            return True

        return False

    @staticmethod
    def manual_check_and_display(console) -> None:
        """Perform a manual upgrade check and display results.

        Args:
            console: Rich console instance for output
        """
        from screenshooter import __version__
        from datetime import datetime
        from screenshooter.modules.settings.settings_helper import get_settings, save_settings

        console.print("\n[bold]Checking for updates...[/bold]")
        is_available, latest_version, release_info = GitLabUpgradeChecker.is_upgrade_available()

        if is_available and latest_version and release_info:
            console.print(f"[green]✓ New version available: {latest_version}[/green]")
            console.print(f"Current version: {__version__}")

            if release_info.get("name"):
                console.print(f"Release: {release_info['name']}")

            console.print(
                f"Download: https://gitlab.com/workmaster/screenshooter/-/releases/{release_info['tag_name']}"
            )

            # Show release notes preview if available
            desc_preview = format_release_description_preview(release_info.get("description", ""))
            if desc_preview:
                console.print(desc_preview)

            # Update last check time
            settings = get_settings()
            settings.upgrade_check.last_check = datetime.now()
            save_settings(settings)
        else:
            console.print("[dim]No updates available[/dim]")

            # Check if user has pinned or skipped any versions and inform them
            settings = get_settings()

            if settings.upgrade_check.pin_version:
                console.print(
                    f"[dim]Note: You are pinned to max version {settings.upgrade_check.pin_version}[/dim]"
                )
                console.print(
                    "[dim]Automatic notifications are suppressed for versions newer than this pin[/dim]"
                )
                console.print("[dim]To unpin: screenshooter settings unpin-version[/dim]")

            if settings.upgrade_check.skip_version:
                console.print(
                    f"[dim]Note: You are currently skipping upgrade notifications for version {settings.upgrade_check.skip_version}[/dim]"
                )
                console.print(
                    "[dim]To stop skipping: screenshooter settings skip-upgrade stop[/dim]"
                )
                console.print(
                    "[dim]To skip a different version: screenshooter settings skip-upgrade <version>[/dim]"
                )


def check_for_updates(console=None) -> bool:
    """Convenience function to check for updates.

    Args:
        console: Rich console instance for output (optional)

    Returns:
        True if upgrade is available, False otherwise
    """
    return GitLabUpgradeChecker.check_and_notify(console)


class CachedUpgradeChecker:
    """Cached upgrade checker that stores results for 7 days."""

    CACHE_FILE = Path.home() / ".config" / "screenshooter" / "upgrade_cache.json"
    CACHE_DURATION_DAYS = 7

    @staticmethod
    def _load_cache() -> Optional[Dict[str, Any]]:
        """Load upgrade check cache from disk."""
        if not CachedUpgradeChecker.CACHE_FILE.exists():
            return None

        try:
            with open(CachedUpgradeChecker.CACHE_FILE) as f:
                cache_data = json.load(f)

            # Check if cache is still valid
            cached_at = datetime.fromisoformat(cache_data.get("cached_at", ""))
            if (datetime.now() - cached_at).days >= CachedUpgradeChecker.CACHE_DURATION_DAYS:
                return None  # Cache expired

            return cache_data
        except (json.JSONDecodeError, KeyError, ValueError):
            return None

    @staticmethod
    def _save_cache(is_available: bool, latest_version: Optional[str] = None) -> None:
        """Save upgrade check result to cache."""
        CachedUpgradeChecker.CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)

        cache_data = {
            "cached_at": datetime.now().isoformat(),
            "is_available": is_available,
            "latest_version": latest_version,
            "current_version": __version__,
        }

        try:
            with open(CachedUpgradeChecker.CACHE_FILE, "w") as f:
                json.dump(cache_data, f, indent=2)
        except Exception:
            # Silently fail if we can't write cache
            pass

    @staticmethod
    def check_for_update_simple() -> bool:
        """Check for updates with caching. Returns True if update available and not skipped."""
        # First check cache
        cache = CachedUpgradeChecker._load_cache()
        if cache is not None:
            is_available = cache.get("is_available", False)
            if not is_available:
                return False

            # Check if user wants to skip this version
            from screenshooter.modules.settings.settings_helper import get_settings

            settings = get_settings()
            latest_version = cache.get("latest_version")
            if settings.upgrade_check.skip_version == latest_version:
                return False  # Don't notify about skipped versions

            # Check if version is pinned - don't notify about versions > pinned version
            if settings.upgrade_check.pin_version and latest_version:
                try:
                    from packaging import version as packaging_version

                    current_pin = packaging_version.parse(settings.upgrade_check.pin_version)
                    latest_ver = packaging_version.parse(latest_version)
                    if latest_ver > current_pin:
                        return False  # Don't notify about versions newer than pin
                except packaging_version.InvalidVersion:
                    # If version parsing fails, proceed normally
                    pass

            return True

        # Cache miss or expired - fetch from API
        is_available, latest_version, _ = GitLabUpgradeChecker.is_upgrade_available()

        # Check if user wants to skip this version
        if is_available and latest_version:
            from screenshooter.modules.settings.settings_helper import get_settings

            settings = get_settings()
            if settings.upgrade_check.skip_version == latest_version:
                is_available = False  # Don't cache or notify about skipped versions

            # Check if version is pinned - don't notify about versions > pinned version
            elif settings.upgrade_check.pin_version and latest_version:
                try:
                    from packaging import version as packaging_version

                    current_pin = packaging_version.parse(settings.upgrade_check.pin_version)
                    latest_ver = packaging_version.parse(latest_version)
                    if latest_ver > current_pin:
                        is_available = False  # Don't notify about versions newer than pin
                except packaging_version.InvalidVersion:
                    # If version parsing fails, proceed normally
                    pass

        # Cache the result
        CachedUpgradeChecker._save_cache(is_available, latest_version)

        return is_available


def show_simple_upgrade_notification(console) -> None:
    """Show a simple one-line upgrade notification."""
    is_available = CachedUpgradeChecker.check_for_update_simple()
    if is_available:
        # Check if user wants to skip this version
        from screenshooter.modules.settings.settings_helper import get_settings

        settings = get_settings()
        cache = CachedUpgradeChecker._load_cache()
        latest_version = cache.get("latest_version") if cache else None

        if settings.upgrade_check.skip_version != latest_version:
            console.print(
                "[yellow]Update available! "
                "Run 'screenshooter settings upgrade-check' for details.[/yellow]"
            )
