"""A service to manage a cluster of decentralized Autonomi nodes"""

__version__ = "0.3.18"
