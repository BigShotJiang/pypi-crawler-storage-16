# 🐺 WolfYouTube

**Vəhşi YouTube Downloader - Heç bir şey onu dayandıra bilməz!**

[![PyPI version](https://badge.fury.io/py/wolfyoutube.svg)](https://pypi.org/project/wolfyoutube/)
[![Python](https://img.shields.io/pypi/pyversions/wolfyoutube.svg)](https://pypi.org/project/wolfyoutube/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## 🚀 Quraşdırma

```bash
pip install wolfyoutube