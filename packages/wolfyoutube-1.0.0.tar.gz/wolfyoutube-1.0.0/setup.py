#!/usr/bin/env python
"""Setup script for wolfyoutube."""

from setuptools import setup, find_packages
from pathlib import Path

# README oxu
readme_path = Path(__file__).parent / "README.md"
long_description = readme_path.read_text(encoding="utf-8") if readme_path.exists() else ""

setup(
    name="wolfyoutube",
    version="1.0.0",
    author="Sənin Adın",
    author_email="email@example.com",
    description="🐺 Wolf YouTube Downloader - Vəhşi kimi işləyir!",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/username/wolfyoutube",
    project_urls={
        "Bug Tracker": "https://github.com/username/wolfyoutube/issues",
        "Documentation": "https://github.com/username/wolfyoutube#readme",
    },
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    python_requires=">=3.8",
    install_requires=[
        "yt-dlp>=2023.1.1",
    ],
    extras_require={
        "dev": ["pytest", "black", "mypy"],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords="youtube downloader video audio mp3 mp4 yt-dlp",
)