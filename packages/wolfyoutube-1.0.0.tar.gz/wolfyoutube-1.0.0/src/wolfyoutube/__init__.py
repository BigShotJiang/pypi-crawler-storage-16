"""
🐺 WolfYouTube - Vəhşi YouTube Downloader
pip install wolfyoutube
"""

from .core import YouTube, WolfDownloader
from .exceptions import (
    WolfError,
    DownloadError,
    ExtractError,
    FormatError,
    GeoBlockedError,
    AgeRestrictedError,
    PrivateVideoError
)
from .utils import (
    is_valid_url,
    format_duration,
    format_filesize,
    clean_filename
)

__version__ = "1.0.0"
__author__ = "Sənin Adın"
__email__ = "email@example.com"

__all__ = [
    # Main classes
    "YouTube",
    "WolfDownloader",

    # Exceptions
    "WolfError",
    "DownloadError",
    "ExtractError",
    "FormatError",
    "GeoBlockedError",
    "AgeRestrictedError",
    "PrivateVideoError",

    # Utils
    "is_valid_url",
    "format_duration",
    "format_filesize",
    "clean_filename",
]