"""
🐺 WolfYouTube Exceptions
"""

class WolfError(Exception):
    """Base exception for WolfYouTube"""
    pass

class DownloadError(WolfError):
    """Download failed"""
    pass

class ExtractError(WolfError):
    """Failed to extract video info"""
    pass

class FormatError(WolfError):
    """Requested format not available"""
    pass

class GeoBlockedError(WolfError):
    """Video is geo-blocked"""
    pass

class AgeRestrictedError(WolfError):
    """Video is age-restricted, cookies required"""
    pass

class PrivateVideoError(WolfError):
    """Video is private"""
    pass

class VideoUnavailableError(WolfError):
    """Video is unavailable or deleted"""
    pass