"""
🐺 WolfYouTube Utilities
"""

import re
import os
from typing import Optional

# Dəstəklənən platformalar
SUPPORTED_DOMAINS = [
    'youtube.com', 'youtu.be', 'youtube-nocookie.com',
    'instagram.com', 'twitter.com', 'x.com', 'tiktok.com',
    'facebook.com', 'fb.watch', 'vimeo.com', 'dailymotion.com',
    'twitch.tv', 'reddit.com', 'pinterest.com', 'soundcloud.com',
    'bilibili.com', 'nicovideo.jp', 'vlive.tv'
]


def is_valid_url(url: str) -> bool:
    """
    URL-in dəstəklənən platforma olub-olmadığını yoxla

    Args:
        url: Yoxlanacaq URL

    Returns:
        True əgər dəstəklənirsə
    """
    if not url or not isinstance(url, str):
        return False

    url_lower = url.lower()

    # HTTP/HTTPS ilə başlamalıdır
    if not url_lower.startswith(('http://', 'https://')):
        return False

    # Dəstəklənən domainləri yoxla
    for domain in SUPPORTED_DOMAINS:
        if domain in url_lower:
            return True

    return False


def format_duration(seconds: Optional[int]) -> str:
    """
    Saniyəni oxunaqlı formata çevir

    Args:
        seconds: Saniyə sayı

    Returns:
        "HH:MM:SS" və ya "MM:SS" formatında string
    """
    if not seconds or not isinstance(seconds, (int, float)):
        return "00:00"

    seconds = int(seconds)
    minutes, secs = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)

    if hours > 0:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def format_filesize(size_bytes: Optional[int]) -> str:
    """
    Baytı oxunaqlı formata çevir

    Args:
        size_bytes: Bayt sayı

    Returns:
        "1.5 MB" formatında string
    """
    if not size_bytes or not isinstance(size_bytes, (int, float)):
        return "N/A"

    size_bytes = float(size_bytes)

    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024

    return f"{size_bytes:.1f} PB"


def clean_filename(filename: str, max_length: int = 200) -> str:
    """
    Fayl adını təmizlə

    Args:
        filename: Təmizlənəcək fayl adı
        max_length: Maksimum uzunluq

    Returns:
        Təmizlənmiş fayl adı
    """
    if not filename:
        return "unknown"

    # Təhlükəli simvolları sil
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '', filename)

    # Çox boşluqları tək boşluğa çevir
    cleaned = re.sub(r'\s+', ' ', cleaned)

    # Başdan və sondan boşluqları sil
    cleaned = cleaned.strip()

    # Uzunluğu məhdudlaşdır
    if len(cleaned) > max_length:
        cleaned = cleaned[:max_length].rsplit(' ', 1)[0]

    return cleaned or "unknown"


def get_video_id(url: str) -> Optional[str]:
    """
    YouTube URL-dən video ID çıxar

    Args:
        url: YouTube URL

    Returns:
        Video ID və ya None
    """
    patterns = [
        r'(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})',
        r'youtube\.com\/embed\/([a-zA-Z0-9_-]{11})',
        r'youtube\.com\/v\/([a-zA-Z0-9_-]{11})',
    ]

    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)

    return None


def ensure_dir(path: str) -> str:
    """Qovluğun mövcudluğunu təmin et"""
    os.makedirs(path, exist_ok=True)
    return path