"""
🐺 WolfYouTube Core Tests
"""
import pytest
import tempfile
import os
from wolfyoutube import YouTube, is_valid_url, format_duration, format_filesize


class TestUtils:
    """Utility funksiyaların testləri"""

    def test_valid_youtube_url(self):
        assert is_valid_url("https://www.youtube.com/watch?v=dQw4w9WgXcQ") == True
        assert is_valid_url("https://youtu.be/dQw4w9WgXcQ") == True

    def test_valid_other_urls(self):
        assert is_valid_url("https://www.instagram.com/p/xxx") == True
        assert is_valid_url("https://www.tiktok.com/@user/video/123") == True
        assert is_valid_url("https://twitter.com/user/status/123") == True

    def test_invalid_urls(self):
        assert is_valid_url("") == False
        assert is_valid_url("not a url") == False
        assert is_valid_url("https://google.com") == False
        assert is_valid_url(None) == False

    def test_format_duration(self):
        assert format_duration(0) == "00:00"
        assert format_duration(65) == "01:05"
        assert format_duration(3661) == "1:01:01"
        assert format_duration(None) == "00:00"

    def test_format_filesize(self):
        assert format_filesize(500) == "500.0 B"
        assert format_filesize(1024) == "1.0 KB"
        assert format_filesize(1048576) == "1.0 MB"
        assert format_filesize(None) == "N/A"


class TestYouTube:
    """YouTube class testləri"""

    def test_init_default(self):
        yt = YouTube()
        assert yt.max_retries == 3
        assert yt.timeout == 60
        assert yt.proxy is None

    def test_init_custom(self):
        yt = YouTube(
            max_retries=5,
            timeout=120,
            proxy="socks5://127.0.0.1:9050"
        )
        assert yt.max_retries == 5
        assert yt.timeout == 120
        assert yt.proxy == "socks5://127.0.0.1:9050"

    def test_is_valid_url_method(self):
        yt = YouTube()
        assert yt.is_valid_url("https://youtube.com/watch?v=test") == True
        assert yt.is_valid_url("invalid") == False

    def test_quality_presets_exist(self):
        assert "ultra" in YouTube.QUALITY_PRESETS
        assert "high" in YouTube.QUALITY_PRESETS
        assert "medium" in YouTube.QUALITY_PRESETS
        assert "low" in YouTube.QUALITY_PRESETS
        assert "lowest" in YouTube.QUALITY_PRESETS

    def test_audio_quality_exist(self):
        assert YouTube.AUDIO_QUALITY["high"] == "320"
        assert YouTube.AUDIO_QUALITY["medium"] == "192"
        assert YouTube.AUDIO_QUALITY["low"] == "128"


# Integration test (real yükləmə - CI/CD-də skip edilə bilər)
@pytest.mark.skip(reason="Real yükləmə tələb edir")
class TestDownload:

    def test_download_video(self):
        yt = YouTube()
        with tempfile.TemporaryDirectory() as tmpdir:
            result = yt.download_video(
                "https://www.youtube.com/watch?v=jNQXAC9IVRw",  # Qısa test video
                tmpdir,
                "low"
            )
            assert result["success"] == True
            assert os.path.exists(result["path"])

    def test_get_info(self):
        yt = YouTube()
        info = yt.get_info("https://www.youtube.com/watch?v=jNQXAC9IVRw")
        assert info["success"] == True
        assert "title" in info


if __name__ == "__main__":
    pytest.main([__file__, "-v"])