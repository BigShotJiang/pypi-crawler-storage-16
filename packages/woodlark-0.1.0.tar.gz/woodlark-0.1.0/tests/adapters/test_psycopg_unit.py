"""Unit tests for PsycopgAdapter with mocked RawCursor."""

from __future__ import annotations
import typing as t
from unittest.mock import MagicMock, Mock, patch
import pytest
from woodlark import ManyQuery, MaybeQuery, NoParams, OneQuery, ZeroQuery
from woodlark.adapters.psycopg import PsycopgAdapter


class SampleParams(t.NamedTuple):
    """Sample params for testing."""

    id: int
    name: str


class UserRow(t.NamedTuple):
    """Sample row type for testing."""

    id: int
    name: str
    email: str | None


@pytest.fixture
def mock_cursor() -> MagicMock:
    """Create a mock cursor."""
    cursor = MagicMock()
    cursor.__enter__ = Mock(return_value=cursor)
    cursor.__exit__ = Mock(return_value=False)
    return cursor


@pytest.fixture
def mock_connection() -> MagicMock:
    """Create a mock connection."""
    return MagicMock()


@pytest.fixture
def adapter(mock_connection: MagicMock) -> PsycopgAdapter:
    """Create a PsycopgAdapter with mock connection."""
    return PsycopgAdapter(mock_connection)


# Query fixtures


@pytest.fixture
def zero_query() -> ZeroQuery[SampleParams]:
    """Create a ZeroQuery for testing."""
    return ZeroQuery(
        query="INSERT INTO users (id, name) VALUES ($1, $2)",
        params="tuple",
        row=None,
        cardinality="zero",
        Params=SampleParams,
        Row=type(None),
    )


@pytest.fixture
def zero_query_no_params() -> ZeroQuery[NoParams]:
    """Create a ZeroQuery without params."""
    return ZeroQuery(
        query="DELETE FROM users WHERE expired = true",
        params=None,
        row=None,
        cardinality="zero",
        Params=NoParams,
        Row=type(None),
    )


@pytest.fixture
def one_query() -> OneQuery[SampleParams, UserRow]:
    """Create a OneQuery for testing."""
    return OneQuery(
        query="SELECT id, name, email FROM users WHERE id = $1",
        params="tuple",
        row="tuple",
        cardinality="one",
        Params=SampleParams,
        Row=UserRow,
    )


@pytest.fixture
def one_query_no_params() -> OneQuery[NoParams, UserRow]:
    """Create a OneQuery without params."""
    return OneQuery(
        query="SELECT id, name, email FROM users LIMIT 1",
        params=None,
        row="tuple",
        cardinality="one",
        Params=NoParams,
        Row=UserRow,
    )


@pytest.fixture
def maybe_query() -> MaybeQuery[SampleParams, UserRow]:
    """Create a MaybeQuery for testing."""
    return MaybeQuery(
        query="SELECT id, name, email FROM users WHERE id = $1",
        params="tuple",
        row="tuple",
        cardinality="one?",
        Params=SampleParams,
        Row=UserRow,
    )


@pytest.fixture
def many_query() -> ManyQuery[SampleParams, UserRow]:
    """Create a ManyQuery for testing."""
    return ManyQuery(
        query="SELECT id, name, email FROM users WHERE name LIKE $2",
        params="tuple",
        row="tuple",
        cardinality="many",
        Params=SampleParams,
        Row=UserRow,
    )


@pytest.fixture
def many_query_no_params() -> ManyQuery[NoParams, UserRow]:
    """Create a ManyQuery without params."""
    return ManyQuery(
        query="SELECT id, name, email FROM users",
        params=None,
        row="tuple",
        cardinality="many",
        Params=NoParams,
        Row=UserRow,
    )


class TestPsycopgDriverZeroQuery:
    """Tests for ZeroQuery execution."""

    def test_executes_query_with_params(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
        zero_query: ZeroQuery[SampleParams],
    ) -> None:
        """ZeroQuery executes with correct query and params."""
        params = SampleParams(id=1, name="Alice")

        with patch(
            "woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor
        ) as mock_raw_cursor:
            adapter.execute(zero_query, params)

            mock_raw_cursor.assert_called_once()
            mock_cursor.execute.assert_called_once_with(
                query="INSERT INTO users (id, name) VALUES ($1, $2)",
                params=(1, "Alice"),
            )

    def test_executes_query_without_params(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
        zero_query_no_params: ZeroQuery[NoParams],
    ) -> None:
        """ZeroQuery without params passes None to cursor."""
        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            adapter.execute(zero_query_no_params)

            mock_cursor.execute.assert_called_once_with(
                query="DELETE FROM users WHERE expired = true",
                params=None,
            )

    def test_returns_none(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
        zero_query: ZeroQuery[SampleParams],
    ) -> None:
        """ZeroQuery returns None."""
        params = SampleParams(id=1, name="Alice")

        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            result = adapter.execute(zero_query, params)

        assert result is None


class TestPsycopgDriverOneQuery:
    """Tests for OneQuery execution."""

    def test_executes_query_and_returns_row(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
        one_query: OneQuery[SampleParams, UserRow],
    ) -> None:
        """OneQuery executes and converts result to Row type."""
        mock_cursor.fetchone.return_value = (1, "Alice", "alice@example.com")
        params = SampleParams(id=1, name="Alice")

        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            result = adapter.execute(one_query, params)

        assert isinstance(result, UserRow)
        assert result.id == 1
        assert result.name == "Alice"
        assert result.email == "alice@example.com"

    def test_executes_without_params(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
        one_query_no_params: OneQuery[NoParams, UserRow],
    ) -> None:
        """OneQuery without params passes None to cursor."""
        mock_cursor.fetchone.return_value = (1, "Alice", None)

        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            result = adapter.execute(one_query_no_params)

            mock_cursor.execute.assert_called_once_with(
                query="SELECT id, name, email FROM users LIMIT 1",
                params=None,
            )
        assert result.id == 1

    def test_raises_when_no_row_returned(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
        one_query: OneQuery[SampleParams, UserRow],
    ) -> None:
        """OneQuery raises LookupError when no row found."""
        mock_cursor.fetchone.return_value = None
        params = SampleParams(id=999, name="Nobody")

        with (
            patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor),
            pytest.raises(LookupError, match="expected exactly one row"),
        ):
            adapter.execute(one_query, params)

    def test_handles_null_values(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
        one_query: OneQuery[SampleParams, UserRow],
    ) -> None:
        """OneQuery correctly handles NULL values."""
        mock_cursor.fetchone.return_value = (1, "Alice", None)
        params = SampleParams(id=1, name="Alice")

        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            result = adapter.execute(one_query, params)

        assert result.email is None


class TestPsycopgDriverMaybeQuery:
    """Tests for MaybeQuery execution."""

    def test_returns_row_when_found(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
        maybe_query: MaybeQuery[SampleParams, UserRow],
    ) -> None:
        """MaybeQuery returns row when result exists."""
        mock_cursor.fetchone.return_value = (1, "Alice", "alice@example.com")
        params = SampleParams(id=1, name="Alice")

        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            result = adapter.execute(maybe_query, params)

        assert result is not None
        assert isinstance(result, UserRow)
        assert result.id == 1

    def test_returns_none_when_not_found(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
        maybe_query: MaybeQuery[SampleParams, UserRow],
    ) -> None:
        """MaybeQuery returns None when no result."""
        mock_cursor.fetchone.return_value = None
        params = SampleParams(id=999, name="Nobody")

        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            result = adapter.execute(maybe_query, params)

        assert result is None


class TestPsycopgDriverManyQuery:
    """Tests for ManyQuery execution."""

    def test_returns_sequence_of_rows(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
        many_query: ManyQuery[SampleParams, UserRow],
    ) -> None:
        """ManyQuery returns sequence of Row instances."""
        mock_cursor.fetchall.return_value = [
            (1, "Alice", "alice@example.com"),
            (2, "Bob", "bob@example.com"),
            (3, "Charlie", None),
        ]
        params = SampleParams(id=0, name="A%")

        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            result = adapter.execute(many_query, params)

        assert len(result) == 3
        assert all(isinstance(r, UserRow) for r in result)
        assert result[0].name == "Alice"
        assert result[1].name == "Bob"
        assert result[2].email is None

    def test_returns_empty_sequence_when_no_rows(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
        many_query: ManyQuery[SampleParams, UserRow],
    ) -> None:
        """ManyQuery returns empty sequence when no results."""
        mock_cursor.fetchall.return_value = []
        params = SampleParams(id=0, name="Nobody%")

        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            result = adapter.execute(many_query, params)

        assert result == []
        assert len(result) == 0

    def test_executes_without_params(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
        many_query_no_params: ManyQuery[NoParams, UserRow],
    ) -> None:
        """ManyQuery without params passes None to cursor."""
        mock_cursor.fetchall.return_value = [(1, "Alice", None)]

        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            result = adapter.execute(many_query_no_params)

            mock_cursor.execute.assert_called_once_with(
                query="SELECT id, name, email FROM users",
                params=None,
            )
        assert len(result) == 1


class TestPsycopgDriverCursorManagement:
    """Tests for cursor lifecycle management."""

    def test_cursor_context_manager_used(
        self,
        adapter: PsycopgAdapter,
        mock_connection: MagicMock,
        mock_cursor: MagicMock,
        one_query: OneQuery[SampleParams, UserRow],
    ) -> None:
        """Driver uses RawCursor as context manager."""
        mock_cursor.fetchone.return_value = (1, "Alice", None)
        params = SampleParams(id=1, name="Alice")

        with patch(
            "woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor
        ) as mock_raw_cursor:
            adapter.execute(one_query, params)

            mock_raw_cursor.assert_called_once_with(mock_connection)
            mock_cursor.__enter__.assert_called_once()
            mock_cursor.__exit__.assert_called_once()


class TestPsycopgDriverScalarRows:
    """Tests for scalar row shape handling."""

    def test_one_query_scalar_returns_single_value(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
    ) -> None:
        """OneQuery with scalar row returns the raw value, not a tuple."""
        mock_cursor.fetchone.return_value = (42,)
        scalar_query: OneQuery[NoParams, int] = OneQuery(
            query="SELECT COUNT(*) FROM users",
            params=None,
            row="scalar",
            cardinality="one",
            Params=NoParams,
            Row=int,
        )

        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            result = adapter.execute(scalar_query)

        assert result == 42
        assert isinstance(result, int)

    def test_maybe_query_scalar_returns_single_value(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
    ) -> None:
        """MaybeQuery with scalar row returns the raw value when found."""
        mock_cursor.fetchone.return_value = ("alice@example.com",)
        scalar_query: MaybeQuery[SampleParams, str] = MaybeQuery(
            query="SELECT email FROM users WHERE id = $1",
            params="tuple",
            row="scalar",
            cardinality="one?",
            Params=SampleParams,
            Row=str,
        )
        params = SampleParams(id=1, name="Alice")

        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            result = adapter.execute(scalar_query, params)

        assert result == "alice@example.com"
        assert isinstance(result, str)

    def test_maybe_query_scalar_returns_none_when_not_found(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
    ) -> None:
        """MaybeQuery with scalar row returns None when no row found."""
        mock_cursor.fetchone.return_value = None
        scalar_query: MaybeQuery[SampleParams, str] = MaybeQuery(
            query="SELECT email FROM users WHERE id = $1",
            params="tuple",
            row="scalar",
            cardinality="one?",
            Params=SampleParams,
            Row=str,
        )
        params = SampleParams(id=999, name="Nobody")

        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            result = adapter.execute(scalar_query, params)

        assert result is None

    def test_many_query_scalar_returns_list_of_values(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
    ) -> None:
        """ManyQuery with scalar row returns a list of raw values."""
        mock_cursor.fetchall.return_value = [("Alice",), ("Bob",), ("Charlie",)]
        scalar_query: ManyQuery[NoParams, str] = ManyQuery(
            query="SELECT name FROM users",
            params=None,
            row="scalar",
            cardinality="many",
            Params=NoParams,
            Row=str,
        )

        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            result = adapter.execute(scalar_query)

        assert result == ["Alice", "Bob", "Charlie"]
        assert all(isinstance(r, str) for r in result)

    def test_many_query_scalar_returns_empty_list(
        self,
        adapter: PsycopgAdapter,
        mock_cursor: MagicMock,
    ) -> None:
        """ManyQuery with scalar row returns empty list when no rows."""
        mock_cursor.fetchall.return_value = []
        scalar_query: ManyQuery[NoParams, int] = ManyQuery(
            query="SELECT id FROM users WHERE active = false",
            params=None,
            row="scalar",
            cardinality="many",
            Params=NoParams,
            Row=int,
        )

        with patch("woodlark.adapters.psycopg.RawCursor", return_value=mock_cursor):
            result = adapter.execute(scalar_query)

        assert result == []
