"""Tests for adapter execute method dispatch."""

from __future__ import annotations
from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from woodlark import ManyQuery, MaybeQuery, NoParams, OneQuery, ZeroQuery
    from .conftest import MockAdapter, SampleParams, SampleRow


class TestExecuteDispatch:
    """Test that execute() dispatches to the correct _fetch_* method."""

    def test_execute_dispatches_to_fetch_zero(
        self,
        mock_adapter: MockAdapter,
        zero_query: ZeroQuery[SampleParams],
        sample_params: SampleParams,
    ) -> None:
        """execute() calls _fetch_zero for ZeroQuery."""
        mock_adapter.execute(zero_query, sample_params)

        assert len(mock_adapter.calls) == 1
        assert mock_adapter.calls[0][0] == "zero"

    def test_execute_dispatches_to_fetch_one(
        self,
        mock_adapter: MockAdapter,
        one_query: OneQuery[SampleParams, SampleRow],
        sample_params: SampleParams,
        sample_row: SampleRow,
    ) -> None:
        """execute() calls _fetch_one for OneQuery."""
        mock_adapter.one_result = sample_row

        mock_adapter.execute(one_query, sample_params)

        assert len(mock_adapter.calls) == 1
        assert mock_adapter.calls[0][0] == "one"

    def test_execute_dispatches_to_fetch_maybe(
        self,
        mock_adapter: MockAdapter,
        maybe_query: MaybeQuery[SampleParams, SampleRow],
        sample_params: SampleParams,
        sample_row: SampleRow,
    ) -> None:
        """execute() calls _fetch_maybe for MaybeQuery."""
        mock_adapter.maybe_result = sample_row

        mock_adapter.execute(maybe_query, sample_params)

        assert len(mock_adapter.calls) == 1
        assert mock_adapter.calls[0][0] == "maybe"

    def test_execute_dispatches_to_fetch_many(
        self,
        mock_adapter: MockAdapter,
        many_query: ManyQuery[SampleParams, SampleRow],
        sample_params: SampleParams,
    ) -> None:
        """execute() calls _fetch_many for ManyQuery."""
        mock_adapter.many_result = []

        mock_adapter.execute(many_query, sample_params)

        assert len(mock_adapter.calls) == 1
        assert mock_adapter.calls[0][0] == "many"


class TestExecuteReturnValues:
    """Test that execute() returns correct values for each cardinality."""

    def test_execute_returns_none_for_zero_query(
        self,
        mock_adapter: MockAdapter,
        zero_query: ZeroQuery[SampleParams],
        sample_params: SampleParams,
    ) -> None:
        """execute() returns None for ZeroQuery."""
        result = mock_adapter.execute(zero_query, sample_params)
        assert result is None

    def test_execute_returns_row_for_one_query(
        self,
        mock_adapter: MockAdapter,
        one_query: OneQuery[SampleParams, SampleRow],
        sample_params: SampleParams,
        sample_row: SampleRow,
    ) -> None:
        """execute() returns single row for OneQuery."""
        mock_adapter.one_result = sample_row

        result = mock_adapter.execute(one_query, sample_params)

        assert result == sample_row
        assert result.id == 1
        assert result.value == "result"

    def test_execute_returns_row_for_maybe_query_when_present(
        self,
        mock_adapter: MockAdapter,
        maybe_query: MaybeQuery[SampleParams, SampleRow],
        sample_params: SampleParams,
        sample_row: SampleRow,
    ) -> None:
        """execute() returns row for MaybeQuery when result exists."""
        mock_adapter.maybe_result = sample_row

        result = mock_adapter.execute(maybe_query, sample_params)

        assert result == sample_row

    def test_execute_returns_none_for_maybe_query_when_absent(
        self,
        mock_adapter: MockAdapter,
        maybe_query: MaybeQuery[SampleParams, SampleRow],
        sample_params: SampleParams,
    ) -> None:
        """execute() returns None for MaybeQuery when no result."""
        mock_adapter.maybe_result = None

        result = mock_adapter.execute(maybe_query, sample_params)

        assert result is None

    def test_execute_returns_sequence_for_many_query(
        self,
        mock_adapter: MockAdapter,
        many_query: ManyQuery[SampleParams, SampleRow],
        sample_params: SampleParams,
        sample_row: SampleRow,
    ) -> None:
        """execute() returns sequence for ManyQuery."""
        mock_adapter.many_result = [sample_row, sample_row]

        result = mock_adapter.execute(many_query, sample_params)

        assert len(result) == 2
        assert all(r == sample_row for r in result)

    def test_execute_returns_empty_sequence_for_many_query(
        self,
        mock_adapter: MockAdapter,
        many_query: ManyQuery[SampleParams, SampleRow],
        sample_params: SampleParams,
    ) -> None:
        """execute() returns empty sequence for ManyQuery with no results."""
        mock_adapter.many_result = []

        result = mock_adapter.execute(many_query, sample_params)

        assert result == []
        assert len(result) == 0


class TestExecuteParamsConversion:
    """Test that execute() converts params correctly for _fetch_* methods."""

    def test_params_converted_to_tuple(
        self,
        mock_adapter: MockAdapter,
        one_query: OneQuery[SampleParams, SampleRow],
        sample_params: SampleParams,
        sample_row: SampleRow,
    ) -> None:
        """Params NamedTuple is converted to tuple for _fetch_* methods."""
        mock_adapter.one_result = sample_row

        mock_adapter.execute(one_query, sample_params)

        # Check that the params were converted to a tuple
        _, params = mock_adapter.calls[0]
        assert params == (42, "test")
        assert isinstance(params, tuple)

    def test_no_params_converted_to_empty_tuple(
        self,
        mock_adapter: MockAdapter,
        one_query_no_params: OneQuery[NoParams, SampleRow],
        sample_row: SampleRow,
    ) -> None:
        """NoParams queries pass empty tuple to _fetch_* methods."""
        mock_adapter.one_result = sample_row

        mock_adapter.execute(one_query_no_params)

        # Check that empty tuple was passed
        _, params = mock_adapter.calls[0]
        assert params == ()


class TestExecuteNoParams:
    """Test execute() with NoParams queries."""

    def test_zero_query_no_params(
        self,
        mock_adapter: MockAdapter,
        zero_query_no_params: ZeroQuery[NoParams],
    ) -> None:
        """ZeroQuery with NoParams executes without params argument."""
        result = mock_adapter.execute(zero_query_no_params)
        assert result is None
        assert mock_adapter.calls[0][0] == "zero"

    def test_one_query_no_params(
        self,
        mock_adapter: MockAdapter,
        one_query_no_params: OneQuery[NoParams, SampleRow],
        sample_row: SampleRow,
    ) -> None:
        """OneQuery with NoParams executes without params argument."""
        mock_adapter.one_result = sample_row

        result = mock_adapter.execute(one_query_no_params)

        assert result == sample_row
        assert mock_adapter.calls[0][0] == "one"

    def test_many_query_no_params(
        self,
        mock_adapter: MockAdapter,
        many_query_no_params: ManyQuery[NoParams, SampleRow],
        sample_row: SampleRow,
    ) -> None:
        """ManyQuery with NoParams executes without params argument."""
        mock_adapter.many_result = [sample_row]

        result = mock_adapter.execute(many_query_no_params)

        assert len(result) == 1
        assert mock_adapter.calls[0][0] == "many"
