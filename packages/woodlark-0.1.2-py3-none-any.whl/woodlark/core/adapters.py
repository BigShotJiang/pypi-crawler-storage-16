from __future__ import annotations
import abc
import typing as t
from woodlark.core.params import NoParams


if t.TYPE_CHECKING:
    from woodlark.core.queries import (
        ManyQuery,
        MaybeQuery,
        OneQuery,
        P,
        Query,
        R,
        ZeroQuery,
    )

    T = t.TypeVar("T")
    S: t.TypeAlias = T | NoParams


_s: t.Final[NoParams] = NoParams()


class _ValidatorMixin:
    def _validate(self, q: Query[P, R], /, params: S[P]) -> None:
        # if no params were provided (sentinel value)
        if params is _s:
            # query requires params but none were provided
            if q.params is not None:
                msg = f"query requires params of type '{q.Params}', but none provided"
                raise ValueError(msg)
            return

        # params were provided, check if query expects them
        if q.params is None:
            msg = f"{params=} passed to parameterless query"
            raise ValueError(msg)

        if not isinstance(params, q.Params):
            msg = f"incorrect type '{type(params)}', expected '{q.Params}'"
            raise TypeError(msg)


class Adapter(abc.ABC, _ValidatorMixin):
    @t.overload
    def execute(self, q: ZeroQuery[P], /, params: P) -> None: ...
    @t.overload
    def execute(self, q: ZeroQuery[NoParams], /) -> None: ...

    @t.overload
    def execute(self, q: OneQuery[NoParams, R], /) -> R: ...
    @t.overload
    def execute(self, q: OneQuery[P, R], /, params: P) -> R: ...

    @t.overload
    def execute(self, q: MaybeQuery[NoParams, R], /) -> R | None: ...
    @t.overload
    def execute(self, q: MaybeQuery[P, R], /, params: P) -> R | None: ...

    @t.overload
    def execute(self, q: ManyQuery[NoParams, R], /) -> t.Sequence[R]: ...
    @t.overload
    def execute(self, q: ManyQuery[P, R], /, params: P) -> t.Sequence[R]: ...

    @t.final
    def execute(
        self,
        q: Query[P, R],
        /,
        params: S[P] = _s,
    ) -> R | t.Sequence[R] | None:
        self._validate(q, params=params)

        match q.cardinality:
            case "zero":
                return self._fetch_zero(q, params=tuple(params))
            case "one":
                return self._fetch_one(q, params=tuple(params))
            case "one?":
                return self._fetch_maybe(q, params=tuple(params))
            case "many":
                return self._fetch_many(q, params=tuple(params))

    @abc.abstractmethod
    def _fetch_zero(
        self,
        q: ZeroQuery[P],
        /,
        params: t.Sequence[object],
    ) -> None: ...

    @abc.abstractmethod
    def _fetch_one(self, q: OneQuery[P, R], /, params: t.Sequence[object]) -> R: ...

    @abc.abstractmethod
    def _fetch_maybe(
        self,
        q: MaybeQuery[P, R],
        /,
        params: t.Sequence[object],
    ) -> R | None: ...

    @abc.abstractmethod
    def _fetch_many(
        self,
        q: ManyQuery[P, R],
        /,
        params: t.Sequence[object],
    ) -> t.Sequence[R]: ...


class AsyncAdapter(abc.ABC, _ValidatorMixin):
    @t.overload
    async def execute(self, q: ZeroQuery[P], /, params: P) -> None: ...
    @t.overload
    async def execute(self, q: ZeroQuery[NoParams], /) -> None: ...

    @t.overload
    async def execute(self, q: OneQuery[NoParams, R], /) -> R: ...
    @t.overload
    async def execute(self, q: OneQuery[P, R], /, params: P) -> R: ...

    @t.overload
    async def execute(self, q: MaybeQuery[NoParams, R], /) -> R | None: ...
    @t.overload
    async def execute(self, q: MaybeQuery[P, R], /, params: P) -> R | None: ...

    @t.overload
    async def execute(self, q: ManyQuery[NoParams, R], /) -> t.Sequence[R]: ...
    @t.overload
    async def execute(self, q: ManyQuery[P, R], /, params: P) -> t.Sequence[R]: ...

    @t.final
    async def execute(
        self,
        q: Query[P, R],
        /,
        params: S[P] = _s,
    ) -> R | t.Sequence[R] | None:
        self._validate(q, params=params)

        match q.cardinality:
            case "zero":
                await self._fetch_zero(q, params=tuple(params))
                return None
            case "one":
                return await self._fetch_one(q, params=tuple(params))
            case "one?":
                return await self._fetch_maybe(q, params=tuple(params))
            case "many":
                return await self._fetch_many(q, params=tuple(params))

    @abc.abstractmethod
    async def _fetch_zero(
        self,
        q: ZeroQuery[P],
        /,
        params: t.Sequence[object],
    ) -> None: ...

    @abc.abstractmethod
    async def _fetch_one(
        self,
        q: OneQuery[P, R],
        /,
        params: t.Sequence[object],
    ) -> R: ...

    @abc.abstractmethod
    async def _fetch_maybe(
        self,
        q: MaybeQuery[P, R],
        /,
        params: t.Sequence[object],
    ) -> R | None: ...

    @abc.abstractmethod
    async def _fetch_many(
        self,
        q: ManyQuery[P, R],
        /,
        params: t.Sequence[object],
    ) -> t.Sequence[R]: ...
