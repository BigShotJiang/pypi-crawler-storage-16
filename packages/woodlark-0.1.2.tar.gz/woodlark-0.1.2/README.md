# woodlark

[![PyPI - Version](https://img.shields.io/pypi/v/woodlark.svg)](https://pypi.org/project/woodlark)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/woodlark.svg)](https://pypi.org/project/woodlark)

Woodlark runtime adapters.

## Installation

```console
pip install woodlark
```

## Usage

```python
from woodlark.adapters.psycopg import PsycopgAdapter, PsycopgAsyncAdapter
from generated.queries import GetUser, GetUserParams, CountUsers

def get_user(adapter: PsycopgAdapter, user_id: int) -> GetUserRow:
    return adapter.execute(GetUser, GetUserParams(id=user_id))

async def count_users(adapter: PsycopgAsyncAdapter) -> int:
    return await adapter.execute(CountUsers)
```

## License

`woodlark` is distributed under the terms of the [Apache-2.0](https://spdx.org/licenses/Apache-2.0.html) license.
