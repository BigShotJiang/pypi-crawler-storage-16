import typing as t


@t.runtime_checkable
class Params(t.Protocol):
    def __iter__(self) -> t.Iterator[object]: ...


@t.final
class NoParams:
    def __iter__(self) -> t.Iterator[object]:
        yield from ()
