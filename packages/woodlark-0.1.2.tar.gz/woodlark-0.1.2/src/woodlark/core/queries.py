from __future__ import annotations
import typing as t


if t.TYPE_CHECKING:
    from woodlark.core.params import Params

    Shape = t.Literal["scalar", "tuple"] | None
    Cardinality = t.Literal["zero", "one", "one?", "many"]


P = t.TypeVar("P", bound="Params")
R = t.TypeVar("R")


class _BaseQuery(t.NamedTuple, t.Generic[P, R]):
    query: t.LiteralString
    params: Shape
    row: Shape
    cardinality: Cardinality
    Params: type[P]
    Row: type[R]


class ZeroQuery(_BaseQuery[P, None]):
    """Query that returns no rows."""

    cardinality: t.Literal["zero"]


class OneQuery(_BaseQuery[P, R]):
    """Query that returns exactly one row."""

    cardinality: t.Literal["one"]


class MaybeQuery(_BaseQuery[P, R]):
    """Query that returns between zero and one rows."""

    cardinality: t.Literal["one?"]


class ManyQuery(_BaseQuery[P, R]):
    """Query that returns zero or more rows."""

    cardinality: t.Literal["many"]


Query = ZeroQuery[P] | OneQuery[P, R] | MaybeQuery[P, R] | ManyQuery[P, R]
