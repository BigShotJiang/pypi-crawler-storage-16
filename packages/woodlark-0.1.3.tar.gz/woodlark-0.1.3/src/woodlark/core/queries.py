from __future__ import annotations
import dataclasses
import typing as t


if t.TYPE_CHECKING:
    from woodlark.core.params import Params

    Shape = t.Literal["scalar", "tuple"]
    Cardinality = t.Literal["zero", "one", "one?", "many"]


P = t.TypeVar("P", bound="Params")
# R = t.TypeVar("R", covariant=True)
R = t.TypeVar("R")


@dataclasses.dataclass(frozen=True, kw_only=True)
class _BaseQuery(t.Generic[P, R]):
    query: t.LiteralString
    params: Shape | None
    row: Shape | None
    cardinality: Cardinality
    Params: type[P]
    Row: type[R]


@dataclasses.dataclass(frozen=True, kw_only=True)
class ZeroQuery(_BaseQuery[P, None]):
    """Query that returns no rows."""

    row: None = dataclasses.field(default=None)
    cardinality: t.Literal["zero"] = dataclasses.field(default="zero")
    Row: type[None] = dataclasses.field(default=type(None))


@dataclasses.dataclass(frozen=True, kw_only=True)
class OneQuery(_BaseQuery[P, R]):
    """Query that returns exactly one row."""

    row: Shape
    cardinality: t.Literal["one"] = dataclasses.field(default="one")


@dataclasses.dataclass(frozen=True, kw_only=True)
class MaybeQuery(_BaseQuery[P, R]):
    """Query that returns between zero and one rows."""

    row: Shape
    cardinality: t.Literal["one?"] = dataclasses.field(default="one?")


@dataclasses.dataclass(frozen=True, kw_only=True)
class ManyQuery(_BaseQuery[P, R]):
    """Query that returns zero or more rows."""

    row: Shape
    cardinality: t.Literal["many"] = dataclasses.field(default="many")


Query = ZeroQuery[P] | OneQuery[P, R] | MaybeQuery[P, R] | ManyQuery[P, R]
