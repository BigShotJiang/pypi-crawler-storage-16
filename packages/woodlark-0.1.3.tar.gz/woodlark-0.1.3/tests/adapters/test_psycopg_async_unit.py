"""Unit tests for PsycopgAsyncAdapter with mocked AsyncRawCursor."""

from __future__ import annotations
import typing as t
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from woodlark import ManyQuery, MaybeQuery, NoParams, OneQuery, ZeroQuery
from woodlark.adapters.psycopg import PsycopgAsyncAdapter


class SampleParams(t.NamedTuple):
    """Sample params for testing."""

    id: int
    name: str


class UserRow(t.NamedTuple):
    """Sample row type for testing."""

    id: int
    name: str
    email: str | None


@pytest.fixture
def mock_cursor() -> MagicMock:
    """Create a mock async cursor with async context manager support."""
    cursor = MagicMock()
    # Async context manager support
    cursor.__aenter__ = AsyncMock(return_value=cursor)
    cursor.__aexit__ = AsyncMock(return_value=False)
    # Async methods
    cursor.execute = AsyncMock()
    cursor.fetchone = AsyncMock()
    cursor.fetchall = AsyncMock()
    return cursor


@pytest.fixture
def mock_connection() -> MagicMock:
    """Create a mock async connection."""
    return MagicMock()


@pytest.fixture
def adapter(mock_connection: MagicMock) -> PsycopgAsyncAdapter:
    """Create a PsycopgAsyncAdapter with mock connection."""
    return PsycopgAsyncAdapter(mock_connection)


# Query fixtures


@pytest.fixture
def zero_query() -> ZeroQuery[SampleParams]:
    """Create a ZeroQuery for testing."""
    return ZeroQuery(
        query="INSERT INTO users (id, name) VALUES ($1, $2)",
        params="tuple",
        Params=SampleParams,
    )


@pytest.fixture
def zero_query_no_params() -> ZeroQuery[NoParams]:
    """Create a ZeroQuery without params."""
    return ZeroQuery(
        query="DELETE FROM users WHERE expired = true",
        params=None,
        Params=NoParams,
    )


@pytest.fixture
def one_query() -> OneQuery[SampleParams, UserRow]:
    """Create a OneQuery for testing."""
    return OneQuery(
        query="SELECT id, name, email FROM users WHERE id = $1",
        params="tuple",
        row="tuple",
        Params=SampleParams,
        Row=UserRow,
    )


@pytest.fixture
def one_query_no_params() -> OneQuery[NoParams, UserRow]:
    """Create a OneQuery without params."""
    return OneQuery(
        query="SELECT id, name, email FROM users LIMIT 1",
        params=None,
        row="tuple",
        Params=NoParams,
        Row=UserRow,
    )


@pytest.fixture
def maybe_query() -> MaybeQuery[SampleParams, UserRow]:
    """Create a MaybeQuery for testing."""
    return MaybeQuery(
        query="SELECT id, name, email FROM users WHERE id = $1",
        params="tuple",
        row="tuple",
        Params=SampleParams,
        Row=UserRow,
    )


@pytest.fixture
def many_query() -> ManyQuery[SampleParams, UserRow]:
    """Create a ManyQuery for testing."""
    return ManyQuery(
        query="SELECT id, name, email FROM users WHERE name LIKE $2",
        params="tuple",
        row="tuple",
        Params=SampleParams,
        Row=UserRow,
    )


@pytest.fixture
def many_query_no_params() -> ManyQuery[NoParams, UserRow]:
    """Create a ManyQuery without params."""
    return ManyQuery(
        query="SELECT id, name, email FROM users",
        params=None,
        row="tuple",
        Params=NoParams,
        Row=UserRow,
    )


@pytest.mark.asyncio
class TestPsycopgAsyncDriverZeroQuery:
    """Tests for async ZeroQuery execution."""

    async def test_executes_query_with_params(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
        zero_query: ZeroQuery[SampleParams],
    ) -> None:
        """ZeroQuery executes with correct query and params."""
        params = SampleParams(id=1, name="Alice")

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor", return_value=mock_cursor
        ) as mock_raw_cursor:
            await adapter.execute(zero_query, params)

            mock_raw_cursor.assert_called_once()
            mock_cursor.execute.assert_awaited_once_with(
                query="INSERT INTO users (id, name) VALUES ($1, $2)",
                params=(1, "Alice"),
            )

    async def test_executes_query_without_params(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
        zero_query_no_params: ZeroQuery[NoParams],
    ) -> None:
        """ZeroQuery without params passes None to cursor."""
        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor",
            return_value=mock_cursor,
        ):
            await adapter.execute(zero_query_no_params)

            mock_cursor.execute.assert_awaited_once_with(
                query="DELETE FROM users WHERE expired = true",
                params=None,
            )

    async def test_returns_none(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
        zero_query: ZeroQuery[SampleParams],
    ) -> None:
        """ZeroQuery returns None."""
        params = SampleParams(id=1, name="Alice")

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor", return_value=mock_cursor
        ):
            # ZeroQuery.execute returns None, verify it completes without error
            await adapter.execute(zero_query, params)


@pytest.mark.asyncio
class TestPsycopgAsyncDriverOneQuery:
    """Tests for async OneQuery execution."""

    async def test_executes_query_and_returns_row(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
        one_query: OneQuery[SampleParams, UserRow],
    ) -> None:
        """OneQuery executes and converts result to Row type."""
        mock_cursor.fetchone.return_value = (1, "Alice", "alice@example.com")
        params = SampleParams(id=1, name="Alice")

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor", return_value=mock_cursor
        ):
            result = await adapter.execute(one_query, params)

        assert isinstance(result, UserRow)
        assert result.id == 1
        assert result.name == "Alice"
        assert result.email == "alice@example.com"

    async def test_executes_without_params(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
        one_query_no_params: OneQuery[NoParams, UserRow],
    ) -> None:
        """OneQuery without params passes None to cursor."""
        mock_cursor.fetchone.return_value = (1, "Alice", None)

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor", return_value=mock_cursor
        ):
            result = await adapter.execute(one_query_no_params)

            mock_cursor.execute.assert_awaited_once_with(
                query="SELECT id, name, email FROM users LIMIT 1",
                params=None,
            )
        assert result.id == 1

    async def test_raises_when_no_row_returned(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
        one_query: OneQuery[SampleParams, UserRow],
    ) -> None:
        """OneQuery raises LookupError when no row found."""
        mock_cursor.fetchone.return_value = None
        params = SampleParams(id=999, name="Nobody")

        with (
            patch("woodlark.adapters.psycopg.AsyncRawCursor", return_value=mock_cursor),
            pytest.raises(LookupError, match="expected exactly one row"),
        ):
            await adapter.execute(one_query, params)

    async def test_handles_null_values(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
        one_query: OneQuery[SampleParams, UserRow],
    ) -> None:
        """OneQuery correctly handles NULL values."""
        mock_cursor.fetchone.return_value = (1, "Alice", None)
        params = SampleParams(id=1, name="Alice")

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor", return_value=mock_cursor
        ):
            result = await adapter.execute(one_query, params)

        assert result.email is None


@pytest.mark.asyncio
class TestPsycopgAsyncDriverMaybeQuery:
    """Tests for async MaybeQuery execution."""

    async def test_returns_row_when_found(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
        maybe_query: MaybeQuery[SampleParams, UserRow],
    ) -> None:
        """MaybeQuery returns row when result exists."""
        mock_cursor.fetchone.return_value = (1, "Alice", "alice@example.com")
        params = SampleParams(id=1, name="Alice")

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor", return_value=mock_cursor
        ):
            result = await adapter.execute(maybe_query, params)

        assert result is not None
        assert isinstance(result, UserRow)
        assert result.id == 1

    async def test_returns_none_when_not_found(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
        maybe_query: MaybeQuery[SampleParams, UserRow],
    ) -> None:
        """MaybeQuery returns None when no result."""
        mock_cursor.fetchone.return_value = None
        params = SampleParams(id=999, name="Nobody")

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor", return_value=mock_cursor
        ):
            result = await adapter.execute(maybe_query, params)

        assert result is None


@pytest.mark.asyncio
class TestPsycopgAsyncDriverManyQuery:
    """Tests for async ManyQuery execution."""

    async def test_returns_sequence_of_rows(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
        many_query: ManyQuery[SampleParams, UserRow],
    ) -> None:
        """ManyQuery returns sequence of Row instances."""
        mock_cursor.fetchall.return_value = [
            (1, "Alice", "alice@example.com"),
            (2, "Bob", "bob@example.com"),
            (3, "Charlie", None),
        ]
        params = SampleParams(id=0, name="A%")

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor", return_value=mock_cursor
        ):
            result = await adapter.execute(many_query, params)

        assert len(result) == 3
        assert all(isinstance(r, UserRow) for r in result)
        assert result[0].name == "Alice"
        assert result[1].name == "Bob"
        assert result[2].email is None

    async def test_returns_empty_sequence_when_no_rows(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
        many_query: ManyQuery[SampleParams, UserRow],
    ) -> None:
        """ManyQuery returns empty sequence when no results."""
        mock_cursor.fetchall.return_value = []
        params = SampleParams(id=0, name="Nobody%")

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor", return_value=mock_cursor
        ):
            result = await adapter.execute(many_query, params)

        assert result == []
        assert len(result) == 0

    async def test_executes_without_params(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
        many_query_no_params: ManyQuery[NoParams, UserRow],
    ) -> None:
        """ManyQuery without params passes None to cursor."""
        mock_cursor.fetchall.return_value = [(1, "Alice", None)]

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor", return_value=mock_cursor
        ):
            result = await adapter.execute(many_query_no_params)

            mock_cursor.execute.assert_awaited_once_with(
                query="SELECT id, name, email FROM users",
                params=None,
            )
        assert len(result) == 1


@pytest.mark.asyncio
class TestPsycopgAsyncDriverCursorManagement:
    """Tests for async cursor lifecycle management."""

    async def test_cursor_async_context_manager_used(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_connection: MagicMock,
        mock_cursor: MagicMock,
        one_query: OneQuery[SampleParams, UserRow],
    ) -> None:
        """Driver uses AsyncRawCursor as async context manager."""
        mock_cursor.fetchone.return_value = (1, "Alice", None)
        params = SampleParams(id=1, name="Alice")

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor", return_value=mock_cursor
        ) as mock_raw_cursor:
            await adapter.execute(one_query, params)

            mock_raw_cursor.assert_called_once_with(mock_connection)
            mock_cursor.__aenter__.assert_awaited_once()
            mock_cursor.__aexit__.assert_awaited_once()


@pytest.mark.asyncio
class TestPsycopgAsyncDriverScalarRows:
    """Tests for async scalar row shape handling."""

    async def test_one_query_scalar_returns_single_value(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
    ) -> None:
        """OneQuery with scalar row returns the raw value, not a tuple."""
        mock_cursor.fetchone.return_value = (42,)
        scalar_query = OneQuery(
            query="SELECT COUNT(*) FROM users",
            params=None,
            row="scalar",
            Params=NoParams,
            Row=int,
        )

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor",
            return_value=mock_cursor,
        ):
            result = await adapter.execute(scalar_query)

        assert result == 42
        assert isinstance(result, int)

    async def test_maybe_query_scalar_returns_single_value(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
    ) -> None:
        """MaybeQuery with scalar row returns the raw value when found."""
        mock_cursor.fetchone.return_value = ("alice@example.com",)
        scalar_query = MaybeQuery(
            query="SELECT email FROM users WHERE id = $1",
            params="tuple",
            row="scalar",
            Params=SampleParams,
            Row=str,
        )
        params = SampleParams(id=1, name="Alice")

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor",
            return_value=mock_cursor,
        ):
            result = await adapter.execute(scalar_query, params)

        assert result == "alice@example.com"
        assert isinstance(result, str)

    async def test_maybe_query_scalar_returns_none_when_not_found(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
    ) -> None:
        """MaybeQuery with scalar row returns None when no row found."""
        mock_cursor.fetchone.return_value = None
        scalar_query = MaybeQuery(
            query="SELECT email FROM users WHERE id = $1",
            params="tuple",
            row="scalar",
            Params=SampleParams,
            Row=str,
        )
        params = SampleParams(id=999, name="Nobody")

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor",
            return_value=mock_cursor,
        ):
            result = await adapter.execute(scalar_query, params)

        assert result is None

    async def test_many_query_scalar_returns_list_of_values(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
    ) -> None:
        """ManyQuery with scalar row returns a list of raw values."""
        mock_cursor.fetchall.return_value = [("Alice",), ("Bob",), ("Charlie",)]
        scalar_query = ManyQuery(
            query="SELECT name FROM users",
            params=None,
            row="scalar",
            Params=NoParams,
            Row=str,
        )

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor", return_value=mock_cursor
        ):
            result = await adapter.execute(scalar_query)

        assert result == ["Alice", "Bob", "Charlie"]
        assert all(isinstance(r, str) for r in result)

    async def test_many_query_scalar_returns_empty_list(
        self,
        adapter: PsycopgAsyncAdapter,
        mock_cursor: MagicMock,
    ) -> None:
        """ManyQuery with scalar row returns empty list when no rows."""
        mock_cursor.fetchall.return_value = []
        scalar_query = ManyQuery(
            query="SELECT id FROM users WHERE active = false",
            params=None,
            row="scalar",
            Params=NoParams,
            Row=int,
        )

        with patch(
            "woodlark.adapters.psycopg.AsyncRawCursor", return_value=mock_cursor
        ):
            result = await adapter.execute(scalar_query)

        assert result == []
