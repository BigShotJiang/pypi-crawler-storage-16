"""Integration tests for PsycopgAdapter with real PostgreSQL database.

These tests require PostgreSQL to be available. They are skipped if PostgreSQL
is not installed or the pytest-postgresql plugin cannot create a connection.

Run with: hatch test -- -m integration
Skip with: hatch test -- -m "not integration"
"""

from __future__ import annotations
import typing as t
import pytest
from woodlark import ManyQuery, MaybeQuery, NoParams, OneQuery, ZeroQuery
from woodlark.adapters.psycopg import PsycopgAdapter


# Mark all tests in this module as integration tests
pytestmark = pytest.mark.integration


if t.TYPE_CHECKING:
    import psycopg

    PgConnection = psycopg.Connection[tuple[object, ...]]


# Row types for testing


class UserRow(t.NamedTuple):
    """User row type."""

    id: int
    name: str
    email: str | None


class CountResult(t.NamedTuple):
    """Count result row."""

    total: int


# Param types for testing


class InsertUserParams(t.NamedTuple):
    """Params for inserting a user."""

    name: str
    email: str | None


class GetUserByIdParams(t.NamedTuple):
    """Params for getting user by ID."""

    id: int


class GetUserByNameParams(t.NamedTuple):
    """Params for getting user by name."""

    name: str


class DeleteUserParams(t.NamedTuple):
    """Params for deleting a user."""

    id: int


# Query fixtures


@pytest.fixture
def insert_user_query() -> ZeroQuery[InsertUserParams]:
    """Query to insert a user."""
    return ZeroQuery(
        query="INSERT INTO users (name, email) VALUES ($1, $2)",
        params="tuple",
        Params=InsertUserParams,
    )


@pytest.fixture
def insert_user_returning_query() -> OneQuery[InsertUserParams, UserRow]:
    """Query to insert a user and return the row."""
    return OneQuery(
        query="INSERT INTO users (name, email) VALUES ($1, $2) RETURNING id, name, email",
        params="tuple",
        row="tuple",
        Params=InsertUserParams,
        Row=UserRow,
    )


@pytest.fixture
def get_user_by_id_query() -> MaybeQuery[GetUserByIdParams, UserRow]:
    """Query to get user by ID."""
    return MaybeQuery(
        query="SELECT id, name, email FROM users WHERE id = $1",
        params="tuple",
        row="tuple",
        Params=GetUserByIdParams,
        Row=UserRow,
    )


@pytest.fixture
def get_user_by_name_query() -> OneQuery[GetUserByNameParams, UserRow]:
    """Query to get user by name (expects exactly one)."""
    return OneQuery(
        query="SELECT id, name, email FROM users WHERE name = $1",
        params="tuple",
        row="tuple",
        Params=GetUserByNameParams,
        Row=UserRow,
    )


@pytest.fixture
def get_all_users_query() -> ManyQuery[NoParams, UserRow]:
    """Query to get all users."""
    return ManyQuery(
        query="SELECT id, name, email FROM users ORDER BY id",
        params=None,
        row="tuple",
        Params=NoParams,
        Row=UserRow,
    )


@pytest.fixture
def count_users_query() -> OneQuery[NoParams, CountResult]:
    """Query to count users."""
    return OneQuery(
        query="SELECT COUNT(*)::int AS total FROM users",
        params=None,
        row="tuple",
        Params=NoParams,
        Row=CountResult,
    )


@pytest.fixture
def delete_user_query() -> ZeroQuery[DeleteUserParams]:
    """Query to delete a user."""
    return ZeroQuery(
        query="DELETE FROM users WHERE id = $1",
        params="tuple",
        Params=DeleteUserParams,
    )


@pytest.fixture
def truncate_users_query() -> ZeroQuery[NoParams]:
    """Query to truncate users table."""
    return ZeroQuery(
        query="TRUNCATE users RESTART IDENTITY",
        params=None,
        Params=NoParams,
    )


# Database fixtures


@pytest.fixture
def pg_connection(postgresql: PgConnection) -> PgConnection:
    """Create test table and return connection."""
    with postgresql.cursor() as cur:
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT
            )
        """)
    postgresql.commit()
    # Cleanup handled by pytest-postgresql
    return postgresql


@pytest.fixture
def adapter(pg_connection: PgConnection) -> PsycopgAdapter:
    """Create a PsycopgAdapter with real connection."""
    return PsycopgAdapter(pg_connection)


class TestInsertAndSelect:
    """Test inserting and selecting data."""

    def test_insert_and_select_user(
        self,
        adapter: PsycopgAdapter,
        pg_connection: PgConnection,
        insert_user_returning_query: OneQuery[InsertUserParams, UserRow],
        get_user_by_id_query: MaybeQuery[GetUserByIdParams, UserRow],
    ) -> None:
        """Insert a user and retrieve by ID."""
        # Insert
        inserted = adapter.execute(
            insert_user_returning_query,
            InsertUserParams(name="Alice", email="alice@example.com"),
        )
        pg_connection.commit()

        assert inserted.name == "Alice"
        assert inserted.email == "alice@example.com"
        assert inserted.id > 0

        # Select
        found = adapter.execute(
            get_user_by_id_query,
            GetUserByIdParams(id=inserted.id),
        )

        assert found is not None
        assert found.id == inserted.id
        assert found.name == "Alice"
        assert found.email == "alice@example.com"

    def test_insert_with_null_email(
        self,
        adapter: PsycopgAdapter,
        pg_connection: PgConnection,
        insert_user_returning_query: OneQuery[InsertUserParams, UserRow],
    ) -> None:
        """Insert a user with NULL email."""
        inserted = adapter.execute(
            insert_user_returning_query,
            InsertUserParams(name="Bob", email=None),
        )
        pg_connection.commit()

        assert inserted.name == "Bob"
        assert inserted.email is None


class TestMaybeQuery:
    """Test MaybeQuery behavior."""

    def test_returns_none_when_not_found(
        self,
        adapter: PsycopgAdapter,
        get_user_by_id_query: MaybeQuery[GetUserByIdParams, UserRow],
    ) -> None:
        """MaybeQuery returns None when no matching row."""
        result = adapter.execute(
            get_user_by_id_query,
            GetUserByIdParams(id=99999),
        )

        assert result is None


class TestOneQuery:
    """Test OneQuery behavior."""

    def test_raises_when_not_found(
        self,
        adapter: PsycopgAdapter,
        get_user_by_name_query: OneQuery[GetUserByNameParams, UserRow],
    ) -> None:
        """OneQuery raises LookupError when no matching row."""
        with pytest.raises(LookupError, match="expected exactly one row"):
            adapter.execute(
                get_user_by_name_query,
                GetUserByNameParams(name="NonexistentUser"),
            )


class TestManyQuery:
    """Test ManyQuery behavior."""

    def test_returns_empty_list_when_no_rows(
        self,
        adapter: PsycopgAdapter,
        get_all_users_query: ManyQuery[NoParams, UserRow],
    ) -> None:
        """ManyQuery returns empty list when no rows."""
        result = adapter.execute(get_all_users_query)

        assert result == []
        assert len(result) == 0

    def test_returns_all_rows(
        self,
        adapter: PsycopgAdapter,
        pg_connection: PgConnection,
        insert_user_returning_query: OneQuery[InsertUserParams, UserRow],
        get_all_users_query: ManyQuery[NoParams, UserRow],
    ) -> None:
        """ManyQuery returns all matching rows."""
        # Insert multiple users
        adapter.execute(
            insert_user_returning_query,
            InsertUserParams(name="Alice", email="alice@example.com"),
        )
        adapter.execute(
            insert_user_returning_query,
            InsertUserParams(name="Bob", email=None),
        )
        adapter.execute(
            insert_user_returning_query,
            InsertUserParams(name="Charlie", email="charlie@example.com"),
        )
        pg_connection.commit()

        # Fetch all
        result = adapter.execute(get_all_users_query)

        assert len(result) == 3
        assert all(isinstance(r, UserRow) for r in result)
        assert [r.name for r in result] == ["Alice", "Bob", "Charlie"]


class TestZeroQuery:
    """Test ZeroQuery behavior."""

    def test_delete_user(
        self,
        adapter: PsycopgAdapter,
        pg_connection: PgConnection,
        insert_user_returning_query: OneQuery[InsertUserParams, UserRow],
        delete_user_query: ZeroQuery[DeleteUserParams],
        get_user_by_id_query: MaybeQuery[GetUserByIdParams, UserRow],
    ) -> None:
        """ZeroQuery can delete a user."""
        # Insert
        inserted = adapter.execute(
            insert_user_returning_query,
            InsertUserParams(name="ToDelete", email=None),
        )
        pg_connection.commit()

        # Delete
        result = adapter.execute(
            delete_user_query,
            DeleteUserParams(id=inserted.id),
        )
        pg_connection.commit()

        assert result is None

        # Verify deleted
        found = adapter.execute(
            get_user_by_id_query,
            GetUserByIdParams(id=inserted.id),
        )
        assert found is None


class TestNoParamsQueries:
    """Test queries without parameters."""

    def test_count_users(
        self,
        adapter: PsycopgAdapter,
        pg_connection: PgConnection,
        insert_user_returning_query: OneQuery[InsertUserParams, UserRow],
        count_users_query: OneQuery[NoParams, CountResult],
    ) -> None:
        """Query without params works correctly."""
        # Initially empty
        result = adapter.execute(count_users_query)
        assert result.total == 0

        # Insert some users
        adapter.execute(
            insert_user_returning_query,
            InsertUserParams(name="Alice", email=None),
        )
        adapter.execute(
            insert_user_returning_query,
            InsertUserParams(name="Bob", email=None),
        )
        pg_connection.commit()

        # Count again
        result = adapter.execute(count_users_query)
        assert result.total == 2

    def test_truncate_table(
        self,
        adapter: PsycopgAdapter,
        pg_connection: PgConnection,
        insert_user_returning_query: OneQuery[InsertUserParams, UserRow],
        truncate_users_query: ZeroQuery[NoParams],
        count_users_query: OneQuery[NoParams, CountResult],
    ) -> None:
        """ZeroQuery without params works correctly."""
        # Insert some users
        adapter.execute(
            insert_user_returning_query,
            InsertUserParams(name="Alice", email=None),
        )
        pg_connection.commit()

        # Truncate
        adapter.execute(truncate_users_query)
        pg_connection.commit()

        # Verify empty
        result = adapter.execute(count_users_query)
        assert result.total == 0
