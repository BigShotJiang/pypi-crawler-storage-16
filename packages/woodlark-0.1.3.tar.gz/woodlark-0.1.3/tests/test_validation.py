"""Tests for parameter validation in adapters."""

from __future__ import annotations
import typing as t
import pytest
from .conftest import MockAdapter, SampleParams, SampleRow


if t.TYPE_CHECKING:
    from woodlark import ManyQuery, MaybeQuery, NoParams, OneQuery, ZeroQuery


class TestValidationParamsRequired:
    """Test validation when query requires parameters."""

    def test_raises_when_params_required_but_not_provided(
        self,
        mock_adapter: MockAdapter,
        one_query: OneQuery[SampleParams, SampleRow],
    ) -> None:
        """ValueError when query expects params but none provided."""
        mock_adapter.one_result = SampleRow(id=1, value="test", nullable=None)

        with pytest.raises(ValueError, match="requires params"):
            mock_adapter.execute(one_query)  # type: ignore[arg-type]

    def test_raises_when_params_wrong_type(
        self,
        mock_adapter: MockAdapter,
        one_query: OneQuery[SampleParams, SampleRow],
    ) -> None:
        """TypeError when params have wrong type."""
        mock_adapter.one_result = SampleRow(id=1, value="test", nullable=None)

        # Create a different NamedTuple type
        class WrongParams(t.NamedTuple):
            wrong_field: str

        wrong = WrongParams(wrong_field="oops")

        with pytest.raises(TypeError, match="incorrect type"):
            mock_adapter.execute(one_query, wrong)  # type: ignore[misc]

    def test_accepts_correct_params(
        self,
        mock_adapter: MockAdapter,
        one_query: OneQuery[SampleParams, SampleRow],
        sample_params: SampleParams,
    ) -> None:
        """No error when params match expected type."""
        mock_adapter.one_result = SampleRow(id=1, value="test", nullable=None)

        # Should not raise
        result = mock_adapter.execute(one_query, sample_params)
        assert result is not None


class TestValidationNoParams:
    """Test validation when query does not require parameters."""

    def test_raises_when_params_provided_but_not_expected(
        self,
        mock_adapter: MockAdapter,
        one_query_no_params: OneQuery[NoParams, SampleRow],
        sample_params: SampleParams,
    ) -> None:
        """ValueError when params provided but query doesn't expect them."""
        mock_adapter.one_result = SampleRow(id=1, value="test", nullable=None)

        with pytest.raises(ValueError, match="passed to parameterless query"):
            mock_adapter.execute(one_query_no_params, sample_params)  # type: ignore[misc]

    def test_accepts_no_params_when_not_required(
        self,
        mock_adapter: MockAdapter,
        one_query_no_params: OneQuery[NoParams, SampleRow],
    ) -> None:
        """No error when NoParams query called without params."""
        mock_adapter.one_result = SampleRow(id=1, value="test", nullable=None)

        # Should not raise
        result = mock_adapter.execute(one_query_no_params)
        assert result is not None


class TestValidationZeroQuery:
    """Test validation for ZeroQuery (no return value)."""

    def test_zero_query_with_params_validates(
        self,
        mock_adapter: MockAdapter,
        zero_query: ZeroQuery[SampleParams],
        sample_params: SampleParams,
    ) -> None:
        """ZeroQuery validates params correctly."""
        # Should not raise
        mock_adapter.execute(zero_query, sample_params)
        assert len(mock_adapter.calls) == 1
        assert mock_adapter.calls[0][0] == "zero"

    def test_zero_query_without_params_validates(
        self,
        mock_adapter: MockAdapter,
        zero_query_no_params: ZeroQuery[NoParams],
    ) -> None:
        """ZeroQuery with NoParams validates correctly."""
        # Should not raise
        mock_adapter.execute(zero_query_no_params)
        assert len(mock_adapter.calls) == 1
        assert mock_adapter.calls[0][0] == "zero"

    def test_zero_query_rejects_unexpected_params(
        self,
        mock_adapter: MockAdapter,
        zero_query_no_params: ZeroQuery[NoParams],
        sample_params: SampleParams,
    ) -> None:
        """ZeroQuery with NoParams rejects params."""
        with pytest.raises(ValueError, match="passed to parameterless query"):
            mock_adapter.execute(zero_query_no_params, sample_params)  # type: ignore[misc]


class TestValidationMaybeQuery:
    """Test validation for MaybeQuery."""

    def test_maybe_query_with_params_validates(
        self,
        mock_adapter: MockAdapter,
        maybe_query: MaybeQuery[SampleParams, SampleRow],
        sample_params: SampleParams,
    ) -> None:
        """MaybeQuery validates params correctly."""
        mock_adapter.maybe_result = SampleRow(id=1, value="test", nullable=None)

        # Should not raise
        result = mock_adapter.execute(maybe_query, sample_params)
        assert result is not None


class TestValidationManyQuery:
    """Test validation for ManyQuery."""

    def test_many_query_with_params_validates(
        self,
        mock_adapter: MockAdapter,
        many_query: ManyQuery[SampleParams, SampleRow],
        sample_params: SampleParams,
    ) -> None:
        """ManyQuery validates params correctly."""
        mock_adapter.many_result = [SampleRow(id=1, value="test", nullable=None)]

        # Should not raise
        result = mock_adapter.execute(many_query, sample_params)
        assert len(result) == 1

    def test_many_query_without_params_validates(
        self,
        mock_adapter: MockAdapter,
        many_query_no_params: ManyQuery[NoParams, SampleRow],
    ) -> None:
        """ManyQuery with NoParams validates correctly."""
        mock_adapter.many_result = []

        # Should not raise
        result = mock_adapter.execute(many_query_no_params)
        assert result == []
