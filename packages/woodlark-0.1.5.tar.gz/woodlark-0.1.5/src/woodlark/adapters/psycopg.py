from __future__ import annotations
import contextlib
import typing as t
import psycopg
from psycopg import AsyncRawCursor, RawCursor
from woodlark.core.adapters import Adapter, AsyncAdapter


if t.TYPE_CHECKING:
    from psycopg.rows import TupleRow
    from woodlark.core.queries import (
        ManyQuery,
        MaybeQuery,
        OneQuery,
        P,
        R_co,
        Shape,
        ZeroQuery,
    )

    Connection: t.TypeAlias = psycopg.Connection[TupleRow]
    AsyncConnection: t.TypeAlias = psycopg.AsyncConnection[TupleRow]

    _R = t.TypeVar("_R")


def _convert_row(row: tuple[object, ...], shape: Shape, row_type: type[_R]) -> _R:
    if shape == "scalar":
        return t.cast("_R", row[0])
    return row_type(*row)


class _TxArgs(t.TypedDict):
    savepoint_name: t.NotRequired[str | None]
    force_rollback: t.NotRequired[bool]


class PsycopgAdapter(Adapter[psycopg.Transaction]):
    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def _fetch_zero(self, q: ZeroQuery[P], /, params: t.Sequence[object]) -> None:
        with RawCursor(self._connection) as cursor:
            cursor.execute(query=q.query, params=params or None)

    def _fetch_one(self, q: OneQuery[P, R_co], /, params: t.Sequence[object]) -> R_co:
        with RawCursor(self._connection) as cursor:
            cursor.execute(query=q.query, params=params or None)
            row = cursor.fetchone()
            if row is None:
                msg = "expected exactly one row, got none"
                raise LookupError(msg)
            return _convert_row(row, q.row, q.Row)

    def _fetch_maybe(
        self,
        q: MaybeQuery[P, R_co],
        /,
        params: t.Sequence[object],
    ) -> R_co | None:
        with RawCursor(self._connection) as cursor:
            cursor.execute(query=q.query, params=params or None)
            row = cursor.fetchone()
            if row is None:
                return None
            return _convert_row(row, q.row, q.Row)

    def _fetch_many(
        self,
        q: ManyQuery[P, R_co],
        /,
        params: t.Sequence[object],
    ) -> t.Sequence[R_co]:
        with RawCursor(self._connection) as cursor:
            cursor.execute(query=q.query, params=params or None)
            rows = cursor.fetchall()
            return [_convert_row(row, q.row, q.Row) for row in rows]

    @contextlib.contextmanager
    def transaction(
        self,
        **kwargs: t.Unpack[_TxArgs],
    ) -> t.Iterator[psycopg.Transaction]:
        with self._connection.transaction(**kwargs) as tx:
            yield tx


class PsycopgAsyncAdapter(AsyncAdapter[psycopg.AsyncTransaction]):
    def __init__(self, connection: AsyncConnection) -> None:
        self._connection = connection

    async def _fetch_zero(self, q: ZeroQuery[P], /, params: t.Sequence[object]) -> None:
        async with AsyncRawCursor(self._connection) as cursor:
            await cursor.execute(query=q.query, params=params or None)

    async def _fetch_one(
        self, q: OneQuery[P, R_co], /, params: t.Sequence[object]
    ) -> R_co:
        async with AsyncRawCursor(self._connection) as cursor:
            await cursor.execute(query=q.query, params=params or None)
            row = await cursor.fetchone()
            if row is None:
                msg = "expected exactly one row, got none"
                raise LookupError(msg)
            return _convert_row(row, q.row, q.Row)

    async def _fetch_maybe(
        self,
        q: MaybeQuery[P, R_co],
        /,
        params: t.Sequence[object],
    ) -> R_co | None:
        async with AsyncRawCursor(self._connection) as cursor:
            await cursor.execute(query=q.query, params=params or None)
            row = await cursor.fetchone()
            if row is None:
                return None
            return _convert_row(row, q.row, q.Row)

    async def _fetch_many(
        self,
        q: ManyQuery[P, R_co],
        /,
        params: t.Sequence[object],
    ) -> t.Sequence[R_co]:
        async with AsyncRawCursor(self._connection) as cursor:
            await cursor.execute(query=q.query, params=params or None)
            rows = await cursor.fetchall()
            return [_convert_row(row, q.row, q.Row) for row in rows]

    @contextlib.asynccontextmanager
    async def transaction(
        self,
        **kwargs: t.Unpack[_TxArgs],
    ) -> t.AsyncIterator[psycopg.AsyncTransaction]:
        async with self._connection.transaction(**kwargs) as tx:
            yield tx
