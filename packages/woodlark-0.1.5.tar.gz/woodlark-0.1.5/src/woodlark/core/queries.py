from __future__ import annotations
import dataclasses
import typing as t


if t.TYPE_CHECKING:
    from woodlark.core.params import Params

    Shape = t.Literal["scalar", "tuple"]
    Cardinality = t.Literal["zero", "one", "one?", "many"]


P = t.TypeVar("P", bound="Params")
R_co = t.TypeVar("R_co", covariant=True)


@dataclasses.dataclass(frozen=True, kw_only=True)
class _BaseQuery(t.Generic[P, R_co]):
    query: t.LiteralString
    params: Shape | None
    row: Shape | None
    cardinality: Cardinality
    Params: type[P]
    Row: type[R_co]


@dataclasses.dataclass(frozen=True, kw_only=True)
class ZeroQuery(_BaseQuery[P, None]):
    """Query that returns no rows."""

    row: None = dataclasses.field(default=None)
    cardinality: t.Literal["zero"] = dataclasses.field(default="zero")
    Row: type[None] = dataclasses.field(default=type(None))


@dataclasses.dataclass(frozen=True, kw_only=True)
class OneQuery(_BaseQuery[P, R_co]):
    """Query that returns exactly one row."""

    row: Shape
    cardinality: t.Literal["one"] = dataclasses.field(default="one")


@dataclasses.dataclass(frozen=True, kw_only=True)
class MaybeQuery(_BaseQuery[P, R_co]):
    """Query that returns between zero and one rows."""

    row: Shape
    cardinality: t.Literal["one?"] = dataclasses.field(default="one?")


@dataclasses.dataclass(frozen=True, kw_only=True)
class ManyQuery(_BaseQuery[P, R_co]):
    """Query that returns zero or more rows."""

    row: Shape
    cardinality: t.Literal["many"] = dataclasses.field(default="many")


Query = ZeroQuery[P] | OneQuery[P, R_co] | MaybeQuery[P, R_co] | ManyQuery[P, R_co]
