"""Shared test fixtures for woodlark tests."""

from __future__ import annotations
import contextlib
import os
import typing as t
import pytest
from pytest_postgresql import factories
from woodlark import ManyQuery, MaybeQuery, NoParams, OneQuery, ZeroQuery
from woodlark.core.adapters import Adapter


# PostgreSQL fixture configuration
# Uses external PostgreSQL if POSTGRES_HOST is set (CI), otherwise starts a local process
if os.environ.get("POSTGRES_HOST"):
    # CI environment: connect to service container
    postgresql_noproc = factories.postgresql_noproc(
        host=os.environ.get("POSTGRES_HOST", "localhost"),
        port=int(os.environ.get("POSTGRES_PORT", "5432")),
        user=os.environ.get("POSTGRES_USER", "postgres"),
        password=os.environ.get("POSTGRES_PASSWORD", "postgres"),
    )
    postgresql = factories.postgresql("postgresql_noproc")
else:
    # Local development: start PostgreSQL process
    postgresql = factories.postgresql("postgresql_proc")


# Sample NamedTuple types for testing


class SampleParams(t.NamedTuple):
    """Sample params type for testing."""

    id: int
    name: str


class SampleRow(t.NamedTuple):
    """Sample row type for testing."""

    id: int
    value: str
    nullable: str | None


# Fixtures for param/row types


@pytest.fixture
def params_type() -> type[SampleParams]:
    """Return a sample Params NamedTuple type."""
    return SampleParams


@pytest.fixture
def row_type() -> type[SampleRow]:
    """Return a sample Row NamedTuple type."""
    return SampleRow


# Fixtures for Query instances


@pytest.fixture
def zero_query(params_type: type[SampleParams]) -> ZeroQuery[SampleParams]:
    """Create a ZeroQuery for testing."""
    return ZeroQuery(
        query="INSERT INTO test (id, name) VALUES ($1, $2)",
        params="tuple",
        Params=params_type,
    )


@pytest.fixture
def zero_query_no_params() -> ZeroQuery[NoParams]:
    """Create a ZeroQuery without params for testing."""
    return ZeroQuery(
        query="DELETE FROM test WHERE expired = true",
        params=None,
        Params=NoParams,
    )


@pytest.fixture
def one_query(
    params_type: type[SampleParams],
    row_type: type[SampleRow],
) -> OneQuery[SampleParams, SampleRow]:
    """Create a OneQuery for testing."""
    return OneQuery(
        query="SELECT id, value, nullable FROM test WHERE id = $1",
        params="tuple",
        row="tuple",
        Params=params_type,
        Row=row_type,
    )


@pytest.fixture
def one_query_no_params(row_type: type[SampleRow]) -> OneQuery[NoParams, SampleRow]:
    """Create a OneQuery without params for testing."""
    return OneQuery(
        query="SELECT id, value, nullable FROM test LIMIT 1",
        params=None,
        row="tuple",
        Params=NoParams,
        Row=row_type,
    )


@pytest.fixture
def maybe_query(
    params_type: type[SampleParams],
    row_type: type[SampleRow],
) -> MaybeQuery[SampleParams, SampleRow]:
    """Create a MaybeQuery for testing."""
    return MaybeQuery(
        query="SELECT id, value, nullable FROM test WHERE id = $1",
        params="tuple",
        row="tuple",
        Params=params_type,
        Row=row_type,
    )


@pytest.fixture
def many_query(
    params_type: type[SampleParams],
    row_type: type[SampleRow],
) -> ManyQuery[SampleParams, SampleRow]:
    """Create a ManyQuery for testing."""
    return ManyQuery(
        query="SELECT id, value, nullable FROM test WHERE name = $2",
        params="tuple",
        row="tuple",
        Params=params_type,
        Row=row_type,
    )


@pytest.fixture
def many_query_no_params(row_type: type[SampleRow]) -> ManyQuery[NoParams, SampleRow]:
    """Create a ManyQuery without params for testing."""
    return ManyQuery(
        query="SELECT id, value, nullable FROM test",
        params=None,
        row="tuple",
        Params=NoParams,
        Row=row_type,
    )


# Mock adapter for testing dispatch


class MockAdapter(Adapter[None]):
    """Mock adapter that records calls to _fetch_* methods."""

    def __init__(self) -> None:
        self.calls: list[tuple[str, t.Sequence[object]]] = []
        self.zero_result: None = None
        self.one_result: SampleRow | None = None
        self.maybe_result: SampleRow | None = None
        self.many_result: t.Sequence[SampleRow] = []

    def _fetch_zero(  # type: ignore[override]
        self,
        q: ZeroQuery[object],  # type: ignore[type-var]
        /,
        params: t.Sequence[object],
    ) -> None:
        # NOTE: this is only to silence "unused method argument" warnings for now
        assert q
        self.calls.append(("zero", params))
        return self.zero_result

    def _fetch_one(  # type: ignore[override]
        self,
        q: OneQuery[object, SampleRow],  # type: ignore[type-var]
        /,
        params: t.Sequence[object],
    ) -> SampleRow:
        # NOTE: this is only to silence "unused method argument" warnings for now
        assert q
        self.calls.append(("one", params))
        if self.one_result is None:
            msg = "No result configured"
            raise LookupError(msg)
        return self.one_result

    def _fetch_maybe(  # type: ignore[override]
        self,
        q: MaybeQuery[object, SampleRow],  # type: ignore[type-var]
        /,
        params: t.Sequence[object],
    ) -> SampleRow | None:
        # NOTE: this is only to silence "unused method argument" warnings for now
        assert q
        self.calls.append(("maybe", params))
        return self.maybe_result

    def _fetch_many(  # type: ignore[override]
        self,
        q: ManyQuery[object, SampleRow],  # type: ignore[type-var]
        /,
        params: t.Sequence[object],
    ) -> t.Sequence[SampleRow]:
        # NOTE: this is only to silence "unused method argument" warnings for now
        assert q
        self.calls.append(("many", params))
        return self.many_result

    @contextlib.contextmanager
    def transaction(self) -> t.Iterator[None]:
        """Mock transaction context manager."""
        yield


@pytest.fixture
def mock_adapter() -> MockAdapter:
    """Create a MockAdapter for testing dispatch."""
    return MockAdapter()


@pytest.fixture
def sample_params() -> SampleParams:
    """Create sample params instance."""
    return SampleParams(id=42, name="test")


@pytest.fixture
def sample_row() -> SampleRow:
    """Create sample row instance."""
    return SampleRow(id=1, value="result", nullable=None)
