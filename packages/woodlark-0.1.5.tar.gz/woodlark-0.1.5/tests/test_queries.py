"""Tests for Query type construction and behavior."""

from __future__ import annotations
import dataclasses
from woodlark import ManyQuery, MaybeQuery, NoParams, OneQuery, ZeroQuery
from .conftest import SampleParams, SampleRow


class TestQueryConstruction:
    """Test that Query types can be constructed correctly."""

    def test_zero_query_construction(self) -> None:
        """ZeroQuery can be constructed with all required fields."""
        q = ZeroQuery(
            query="INSERT INTO test (id) VALUES ($1)",
            params="tuple",
            Params=SampleParams,
        )
        assert q.query == "INSERT INTO test (id) VALUES ($1)"
        assert q.params == "tuple"
        assert q.row is None
        assert q.cardinality == "zero"
        assert q.Params is SampleParams
        assert q.Row is type(None)

    def test_one_query_construction(self) -> None:
        """OneQuery can be constructed with all required fields."""
        q = OneQuery(
            query="SELECT * FROM test WHERE id = $1",
            params="tuple",
            row="tuple",
            Params=SampleParams,
            Row=SampleRow,
        )
        assert q.query == "SELECT * FROM test WHERE id = $1"
        assert q.params == "tuple"
        assert q.row == "tuple"
        assert q.cardinality == "one"
        assert q.Params is SampleParams
        assert q.Row is SampleRow

    def test_maybe_query_construction(self) -> None:
        """MaybeQuery can be constructed with all required fields."""
        q = MaybeQuery(
            query="SELECT * FROM test WHERE id = $1",
            params="tuple",
            row="tuple",
            Params=SampleParams,
            Row=SampleRow,
        )
        assert q.query == "SELECT * FROM test WHERE id = $1"
        assert q.cardinality == "one?"

    def test_many_query_construction(self) -> None:
        """ManyQuery can be constructed with all required fields."""
        q = ManyQuery(
            query="SELECT * FROM test",
            params=None,
            row="tuple",
            Params=NoParams,
            Row=SampleRow,
        )
        assert q.query == "SELECT * FROM test"
        assert q.params is None
        assert q.cardinality == "many"
        assert q.Params is NoParams


class TestQueryCardinality:
    """Test that Query subtypes have correctly narrowed cardinality."""

    def test_zero_query_cardinality_is_zero(
        self,
        zero_query: ZeroQuery[SampleParams],
    ) -> None:
        """ZeroQuery.cardinality is 'zero'."""
        assert zero_query.cardinality == "zero"

    def test_one_query_cardinality_is_one(
        self,
        one_query: OneQuery[SampleParams, SampleRow],
    ) -> None:
        """OneQuery.cardinality is 'one'."""
        assert one_query.cardinality == "one"

    def test_maybe_query_cardinality_is_one_optional(
        self,
        maybe_query: MaybeQuery[SampleParams, SampleRow],
    ) -> None:
        """MaybeQuery.cardinality is 'one?'."""
        assert maybe_query.cardinality == "one?"

    def test_many_query_cardinality_is_many(
        self,
        many_query: ManyQuery[SampleParams, SampleRow],
    ) -> None:
        """ManyQuery.cardinality is 'many'."""
        assert many_query.cardinality == "many"


class TestQueryDataclassBehavior:
    """Test that Query types behave as frozen dataclasses."""

    def test_query_is_frozen(
        self,
        one_query: OneQuery[SampleParams, SampleRow],
    ) -> None:
        """Query instances are immutable (frozen dataclass)."""

        assert dataclasses.is_dataclass(one_query)
        # Verify it's frozen by trying to modify a field
        try:
            one_query.query = "modified"  # type: ignore[misc]
            msg = "Should not be able to modify frozen dataclass"
            raise AssertionError(msg)
        except dataclasses.FrozenInstanceError:
            pass

    def test_query_fields_accessible_by_name(
        self,
        one_query: OneQuery[SampleParams, SampleRow],
    ) -> None:
        """Query fields can be accessed by attribute name."""
        assert one_query.query == "SELECT id, value, nullable FROM test WHERE id = $1"
        assert one_query.params == "tuple"
        assert one_query.row == "tuple"
        assert one_query.cardinality == "one"
        assert one_query.Params is SampleParams
        assert one_query.Row is SampleRow

    def test_query_has_correct_fields(
        self,
        one_query: OneQuery[SampleParams, SampleRow],
    ) -> None:
        """Query has expected fields."""

        fields = {f.name for f in dataclasses.fields(one_query)}
        assert fields == {"query", "params", "row", "cardinality", "Params", "Row"}

    def test_query_is_hashable(
        self,
        one_query: OneQuery[SampleParams, SampleRow],
    ) -> None:
        """Query instances are hashable (can be used in sets/dicts)."""
        query_set: set[OneQuery[SampleParams, SampleRow]] = {one_query}
        assert one_query in query_set

    def test_query_equality(self) -> None:
        """Two queries with same fields are equal."""
        q1 = OneQuery(
            query="SELECT 1",
            params=None,
            row="tuple",
            Params=NoParams,
            Row=SampleRow,
        )
        q2 = OneQuery(
            query="SELECT 1",
            params=None,
            row="tuple",
            Params=NoParams,
            Row=SampleRow,
        )
        assert q1 == q2


class TestNoParamsQuery:
    """Test queries that don't require parameters."""

    def test_zero_query_with_no_params(
        self,
        zero_query_no_params: ZeroQuery[NoParams],
    ) -> None:
        """ZeroQuery can be created with NoParams."""
        assert zero_query_no_params.Params is NoParams
        assert zero_query_no_params.params is None

    def test_one_query_with_no_params(
        self,
        one_query_no_params: OneQuery[NoParams, SampleRow],
    ) -> None:
        """OneQuery can be created with NoParams."""
        assert one_query_no_params.Params is NoParams
        assert one_query_no_params.params is None

    def test_many_query_with_no_params(
        self,
        many_query_no_params: ManyQuery[NoParams, SampleRow],
    ) -> None:
        """ManyQuery can be created with NoParams."""
        assert many_query_no_params.Params is NoParams
        assert many_query_no_params.params is None
