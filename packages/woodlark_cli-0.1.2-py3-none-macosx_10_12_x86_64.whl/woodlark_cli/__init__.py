import os
import shutil
import sys
import sysconfig


def _get_bin_path() -> str:
    _suffix = sysconfig.get_config_var("EXE")
    name = f"woodlark{_suffix}"

    bin_dir = os.path.dirname(sys.executable)

    if os.path.isfile(_path := os.path.join(bin_dir, name)):
        return _path

    # HACK: fall back to PATH search
    if found := shutil.which(name):
        return found

    raise FileNotFoundError(name)


def main() -> None:
    _path = _get_bin_path()

    if sys.platform == "win32":
        import subprocess

        completed_process = subprocess.run([_path, *sys.argv[1:]])
        sys.exit(completed_process.returncode)
    else:
        os.execvp(_path, [_path, *sys.argv[1:]])


if __name__ == "__main__":
    main()
