from __future__ import annotations
from woodlark_cli import main


main()
