"""
wowipy.

OPENWOWI Wowiport wrapper for ptyhon
"""

__version__ = "1.1.0"
__author__ = 'Sebastian Bauhaus'
__credits__ = 'Sebastian Bauhaus'
