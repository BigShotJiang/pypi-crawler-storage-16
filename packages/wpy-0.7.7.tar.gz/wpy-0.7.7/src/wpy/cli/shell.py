#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: wxnacy@gmail.com
"""

"""

from wpy.shell import CommandShell

class Shell(CommandShell):
    pass

def main():
    cli = Shell()
    cli.run()

