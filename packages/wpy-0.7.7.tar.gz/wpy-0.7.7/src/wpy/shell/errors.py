#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: wxnacy@gmail.com
"""

"""
class ContinueError(Exception):
    pass

class BreakError(Exception):
    pass

class ExitError(Exception):
    pass

class CommnadNotFoundError(Exception):
    pass
