#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: wxnacy(wxnacy@gmail.com)
# Description:

import unittest
#  from wpy import security
#  from wpy.common import MD5
#  from wpy.functools import find_modules

#  CONTENT = 'wxnacy'
#  FILENAME='tests/test_security.txt'
#  URL='https://raw.githubusercontent.com/wxnacy/wpy/master/tests/test_security.txt'

#  class TestCase(unittest.TestCase):
    #  def setUp(self):
        #  pass
    #  def teardown(self):
        #  pass

    #  def test_find_modules(self):
        #  '''查找模块'''

        #  modules = []
        #  for m in find_modules('tests/submodules'):
            #  modules.append(m)
        #  self.assertEqual(modules, [
            #  'tests.submodules.a.a',
            #  'tests.submodules.b.b',
            #  'tests.submodules.s',
            #  ])




#  if __name__ == "__main__":
    #  unittest.main()
