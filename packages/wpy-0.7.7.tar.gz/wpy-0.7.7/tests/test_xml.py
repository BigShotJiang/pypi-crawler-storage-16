#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: wxnacy(wxnacy@gmail.com)
# Description:

import unittest
#  from wpy.common import XML

#  class TestMain(unittest.TestCase):

    #  def setUp(self):
        #  '''before each test function'''
        #  pass

    #  def tearDown(self):
        #  '''after each test function'''
        #  pass

    #  def do(self, func):
        #  '''todo'''
        #  self.assertEqual(1, 1)
        #  pass

    #  def test_todict(self):
        #  text = '''
            #  <xml>
                #  <return_code>SUCCESS</return_code>
                #  <return_msg>OK</return_msg>
            #  </xml>
        #  '''

        #  json_data = dict(xml = dict(return_code='SUCCESS', return_msg='OK'))
        #  res = XML.xml2dict(text)
        #  self.assertEqual(res, json_data)

        #  xmlstr = XML.dict2xml(json_data)
        #  self.assertEqual(xmlstr, '''<?xml version="1.0" encoding="utf-8"?>
#  <xml><return_code>SUCCESS</return_code><return_msg>OK</return_msg></xml>''')

#  if __name__ == "__main__":
    #  unittest.main()
#  xmltodict = "^0.12.0"
#  PyYAML = "^6.0"
#  termcolor = "^1.1.0"
