"""Tests for wrchart."""
