"""
Jupyter widget integration for wrchart.
"""

# Widget implementation will use ipywidgets for rich interactivity
# For now, the basic Chart class uses inline HTML rendering

__all__ = []
