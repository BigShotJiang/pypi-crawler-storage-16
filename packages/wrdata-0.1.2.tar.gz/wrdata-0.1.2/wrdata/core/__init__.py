"""
Core utilities and configuration for wrdata.
"""

from .config import settings

__all__ = ["settings"]
