import{aT as f}from"./index-SYnWB7Y3.js";export{f as default};
