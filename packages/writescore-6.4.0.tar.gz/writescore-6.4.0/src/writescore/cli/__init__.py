"""
Command-line interface module.
"""

__all__: list[str] = []
