"""Tests for wrtkit."""
