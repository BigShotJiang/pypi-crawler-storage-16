# test_strategy.py is no longer needed - Strategy abstraction was removed
# All strategy logic should now be implemented as direct signal generation functions