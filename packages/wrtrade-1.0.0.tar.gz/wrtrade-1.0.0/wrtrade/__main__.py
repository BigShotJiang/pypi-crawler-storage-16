"""
WRTrade main entry point.
This allows running the CLI with `python -m wrtrade`.
"""

from wrtrade.cli import cli

if __name__ == '__main__':
    cli()