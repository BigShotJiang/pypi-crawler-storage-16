# This file is removed - Strategy abstraction eliminated for performance
# Use direct signal generation functions instead