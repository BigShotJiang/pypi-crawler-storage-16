"""
WSHawk - WebSocket Security Scanner
"""

from .__main__ import *
from .interactive import *

__version__ = "2.0.3"
__author__ = "Regaan (@noobforanonymous)"
