"""WAF detection module"""
from .detector import WAFDetector

__all__ = ['WAFDetector']
