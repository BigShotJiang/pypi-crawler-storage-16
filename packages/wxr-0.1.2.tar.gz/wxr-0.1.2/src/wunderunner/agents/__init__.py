"""Pydantic AI agents for project analysis."""
