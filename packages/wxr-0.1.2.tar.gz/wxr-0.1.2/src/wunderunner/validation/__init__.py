"""Validation utilities for Dockerfile and docker-compose."""

from wunderunner.validation.dockerfile import validate_dockerfile_syntax

__all__ = ["validate_dockerfile_syntax"]
