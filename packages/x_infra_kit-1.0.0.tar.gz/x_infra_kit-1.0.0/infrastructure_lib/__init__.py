"""
x-infra-kit: Reusable CDKTF Infrastructure Library for GCP

This library provides production-ready infrastructure constructs for Google Cloud Platform.

Quick Start:
    from x_infra_kit import StandardPlatform

    platform = StandardPlatform(stack, "platform",
        project_id="my-project",
        region="europe-west1",
        env="prod",
        prefix="myapp"
    )

Building Blocks (for advanced usage):
    from x_infra_kit import StandardVPC, StandardCluster, DevProfile

    profile = DevProfile(project_id, region, env, prefix)
    vpc = StandardVPC(self, "vpc", config=profile.get_network_config())
    cluster = StandardCluster(self, "gke", config=profile.get_cluster_config(), ...)
"""

# Composite (Recommended for most users)
from .composites import StandardPlatform

# Configuration
from .config import ClusterConfig, NetworkConfig
from .gke import StandardCluster

# Building Blocks
from .networking import StandardVPC

# Profiles (Golden Paths)
from .profiles import DevProfile, PlatformProfile, ProdProfile, StagingProfile
from .security import StandardIdentity, StandardSecrets

__all__ = [
    # Composite
    "StandardPlatform",
    # Building Blocks
    "StandardVPC",
    "StandardCluster",
    "StandardSecrets",
    "StandardIdentity",
    # Config
    "NetworkConfig",
    "ClusterConfig",
    # Profiles
    "PlatformProfile",
    "DevProfile",
    "StagingProfile",
    "ProdProfile",
]
