from .xai_setup import xai_setup

__version__="0.1.0"
