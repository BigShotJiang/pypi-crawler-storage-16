# xARPES documentation

The documentation is automatically generated from the NumPy-style docstrings in
the source code using Sphinx:

    python3 -m pip install -r requirements.txt
    make html
