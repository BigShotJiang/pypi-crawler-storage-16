.. include:: ../README.md
   :parser: myst_parser.sphinx_

.. toctree::
   :caption: Modules
   :hidden:

   modules/spectral
   modules/distributions
   modules/functions
   modules/plotting

.. toctree::
   :caption: More
   :hidden:

   genindex
