Plotting
========

.. automodule:: xarpes.plotting
   :members:
