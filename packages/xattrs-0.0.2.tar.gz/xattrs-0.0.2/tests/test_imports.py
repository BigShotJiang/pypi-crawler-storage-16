# isort:skip_file


def test_imports():
    from xattrs import dataclass, define, frozen, field
    from xattrs import asdict, astuple, astree
    from xattrs import derive
    from xattrs import serde
    from xattrs import evolve
