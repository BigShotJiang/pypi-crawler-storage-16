"""
Init for the HtmlBlock.
"""

from .html import HtmlBlock
