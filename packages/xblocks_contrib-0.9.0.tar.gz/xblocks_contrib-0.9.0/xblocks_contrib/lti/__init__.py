"""
THIS BLOCK IS DEPRECATED IN FAVOR OF https://github.com/openedx/xblock-lti-consumer

Learning Tools Interoperability (LTI) module.
"""

from .lti import LTIBlock
