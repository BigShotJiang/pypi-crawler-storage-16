"""
Exceptions for video block.
"""


class TranscriptsGenerationException(Exception):
    pass


class TranscriptNotFoundError(Exception):
    pass
