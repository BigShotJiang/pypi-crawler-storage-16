__version__ = "2.0.0"    
XCD_VERSION = __version__