from XCD_gui import App 
if __name__ == "__main__":
    App().mainloop()