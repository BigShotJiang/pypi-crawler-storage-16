from clios import CliosError


class XcdoError(CliosError):
    pass
