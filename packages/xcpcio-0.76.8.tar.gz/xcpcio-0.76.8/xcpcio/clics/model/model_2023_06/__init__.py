"""
CCS (Contest Control System) models for branch 2023-06.

Auto-generated from https://github.com/icpc/ccs-specs/tree/2023-06
"""

from .model import *  # noqa: F403
