# Copyright (c) 2018-2025 by xcube team and contributors
# Permissions are hereby granted under the terms of the MIT License:
# https://opensource.org/licenses/MIT.

DEFAULT_CALLABLE_NAME = "process_dataset"
DEFAULT_MODULE_NAME = "xcube_byoa"

TEMP_FILE_PREFIX = "xcube-byoa"
