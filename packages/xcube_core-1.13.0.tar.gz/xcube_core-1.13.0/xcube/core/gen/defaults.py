# Copyright (c) 2018-2025 by xcube team and contributors
# Permissions are hereby granted under the terms of the MIT License:
# https://opensource.org/licenses/MIT.

DEFAULT_OUTPUT_PATH = "out.zarr"
DEFAULT_OUTPUT_RESAMPLING = "Nearest"
DEFAULT_OUTPUT_SIZE = [512, 512]
