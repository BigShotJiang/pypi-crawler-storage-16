Bitmask Operations
==================

.. currentmodule:: xgrammar

.. autofunction:: allocate_token_bitmask

.. autofunction:: apply_token_bitmask_inplace

.. autofunction:: reset_token_bitmask

.. autofunction:: get_bitmask_shape

.. autodata:: bitmask_dtype

    The dtype of the bitmask: int32.
