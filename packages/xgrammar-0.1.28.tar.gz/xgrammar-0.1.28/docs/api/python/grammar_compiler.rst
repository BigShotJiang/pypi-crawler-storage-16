﻿xgr.GrammarCompiler
========================

.. currentmodule:: xgrammar

.. autoclass:: GrammarCompiler
   :no-show-inheritance:
   :special-members: __init__
   :autosummary:
