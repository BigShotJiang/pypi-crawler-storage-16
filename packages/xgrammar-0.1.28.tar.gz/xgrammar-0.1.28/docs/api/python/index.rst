.. _apixgrammar:

XGrammar Python API
===================

.. toctree::
   :maxdepth: 2

   grammar
   tokenizer_info
   grammar_compiler
   compiled_grammar
   grammar_matcher
   testing
   structural_tag
   bitmask_ops
   config
   exception
