"""Generators module"""

from .fingerprint import FingerprintGenerator

__all__ = ["FingerprintGenerator"]
