## 核心设计理念

### 1. **分层架构**

- **Builder层**: 纯粹的SQL构建逻辑（无状态）
- **Executor层**: 执行逻辑，适合Prefect Task
- **Manager层**: 高级封装，便捷API

### 2. **Prefect集成策略**

- Builder作为无状态函数，可以直接在Task中使用
- Executor提供可序列化的执行单元
- 使用Prefect Blocks管理数据库连接配置

### 3. **模块职责**

#### `database/builders.py` - SQL构建器

- 纯函数式，无副作用
- 返回SQL和参数分离
- 可在任何环境使用

#### `database/executor.py` - SQL执行器

- 轻量级，适合Prefect Task
- 支持连接池复用
- 可序列化的配置

#### `database/manager.py` - 完整CRUD

- 完整的数据库操作封装
- 适合非Prefect场景
- 提供便捷的高级API

#### `prefect_integration/tasks.py` - Prefect Tasks

- 封装为Prefect Task
- 支持重试、超时配置
- 集成Prefect日志

## Redis

### 初始化

```python
from xll_kit.redis.manager import redis_manager

redis_manager.get_client("cache", url="redis://127.0.0.1:6379/1")
redis_manager.get_async_client("broker", url="redis://127.0.0.1:6379/2")
```

### Lock

```python
from xll_kit.redis.lock import RedisLock

lock = RedisLock(prefix="lock:", instance="cache")

with lock.lock("task1"):
    print("locked")
```

### PubSub

```python
from xll_kit.redis.pubsub import RedisPubSub

pubsub = RedisPubSub(prefix="chat:", instance="broker")

pubsub.publish("system", "hello")
listener = pubsub.subscribe("system")

```

## Database

### 初始化

```python
from xll_kit.database.session_manager import init_session_manager

init_session_manager(database_uri)
```