import pytest
from xll_kit.utils.date_util import DateUtil
import pytz
from datetime import datetime


def test_parse_basic():
    dt = DateUtil.parse("2024-01-01 10:00:00")
    assert isinstance(dt, datetime)
    assert dt.tzinfo == pytz.UTC


def test_parse_with_tz():
    dt = DateUtil.parse("2024-01-01 10:00 CST")
    assert dt.tzinfo.zone == "Asia/Shanghai"


def test_month_start():
    dt = DateUtil.parse("2024-05-15 10:00 UTC")
    ms = DateUtil.month_start(dt)
    assert ms.day == 1
    assert ms.hour == 0


def test_add_months():
    dt = DateUtil.parse("2024-01-31")
    new_dt = DateUtil.add_months(dt, 1)
    assert new_dt.month == 2
