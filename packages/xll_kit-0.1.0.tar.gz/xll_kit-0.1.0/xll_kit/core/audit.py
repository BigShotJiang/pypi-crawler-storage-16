from xll_kit.core.hooks import global_hook_manager, hook_after_create
from xll_kit.models.audit_log import AuditObjectLog, AuditFieldLog


def diff_model(before: dict, after: dict, include=None, exclude=None):
    include = include or []
    exclude = exclude or []

    changes = {}
    for k, old in before.items():
        if k.startswith("_"):
            continue
        if include and k not in include:
            continue
        if exclude and k in exclude:
            continue

        new = after.get(k)
        if new != old:
            changes[k] = (old, new)

    return changes


# ------------------------------------------------------
# 注册全局审计 hook
# ------------------------------------------------------
@hook_after_create(priority=100)  # <-- 优雅注册
def after_create_audit_hook(session, model_name, data, obj=None, **kwargs):
    if not data or session is None:
        return

    # object log
    log = AuditObjectLog(
        obj_type=model_name,
        obj_id=obj.id,
        action="create",
        data=str(data),
    )
    session.add(log)
    session.flush()


# @hook_after_update(priority=100)   # <-- 优雅注册
def after_update_audit_hook(session, model_name, diff, obj=None, **kwargs):
    if not diff or session is None:
        return

    # object log
    log = AuditObjectLog(
        obj_type=model_name,
        obj_id=obj.id,
        action="update",
        data=str(diff),
    )
    session.add(log)
    session.flush()

    # field log
    for f, (old, new) in diff.items():
        session.add(AuditFieldLog(
            obj_type=model_name,
            obj_id=obj.id,
            field=f,
            old_value=str(old),
            new_value=str(new),
            action="update",
        ))


# ---- 注册 ----
# global_hook_manager.register(
#     "after_create",
#     after_create_audit_hook,
#     priority=100,
# )
global_hook_manager.register(
    "after_update",
    after_update_audit_hook,
    priority=100,
)
