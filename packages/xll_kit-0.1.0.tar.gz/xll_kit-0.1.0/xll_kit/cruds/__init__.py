from .base import CRUDBase

__all__ = [
    'CRUDBase'
]