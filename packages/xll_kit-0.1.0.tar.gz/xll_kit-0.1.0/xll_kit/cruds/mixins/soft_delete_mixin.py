# xll_kit/cruds/mixins/soft_delete_mixin.py
from datetime import datetime

class SoftDeleteMixin:
    def soft_delete(self, session, obj):
        if hasattr(obj, "deleted_at"):
            setattr(obj, "deleted_at", datetime.now())
            session.add(obj)
            session.flush()
            return obj
        else:
            session.delete(obj)
            session.flush()
            return None
