"""
版本信息
"""

__version__ = '0.1.0'
__author__ = 'Your Name'
__email__ = 'your.email@example.com'
__license__ = 'MIT'
__description__ = 'Database operation toolkit with Prefect integration'