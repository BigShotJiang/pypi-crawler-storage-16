"""XLSM2Spec - Excel VBAを解析し仕様書を生成するCLIツール"""

__version__ = "0.1.0"
