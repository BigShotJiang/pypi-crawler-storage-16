"""VBA抽出アダプター"""

from xlsm2spec.infrastructure.extractors.vba_extractor import VbaExtractor

__all__ = ["VbaExtractor"]
