"""VBA解析パーサー"""

from xlsm2spec.infrastructure.parsers.vba_parser import VbaParser

__all__ = ["VbaParser"]
