"""Excel読み込みアダプター"""

from xlsm2spec.infrastructure.readers.excel_reader import ExcelReader

__all__ = ["ExcelReader"]
