/**
 * xnote专用ui
 * 依赖库
 *   jquery
 *   layer.js
 * @author xupingmao
 * @since 2017/10/21
 * @modified 2022/04/16 20:24:02
 */

// 代码移动到 x-init.js 里面了
