# -*- coding:utf-8 -*-
"""
@Author       : xupingmao
@email        : 578749341@qq.com
@Date         : 2022-05-01 12:55:32
@LastEditors  : xupingmao
@LastEditTime : 2022-05-01 14:45:23
@FilePath     : /xnote/tests/__init__.py
"""

from .a import *
