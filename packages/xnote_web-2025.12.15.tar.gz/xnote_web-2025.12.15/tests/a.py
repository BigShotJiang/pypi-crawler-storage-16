# -*- coding:utf-8 -*-
"""
@Author       : xupingmao
@email        : 578749341@qq.com
@Date         : 2022-05-01 14:35:03
@LastEditors  : xupingmao
@LastEditTime : 2023-10-21 09:42:54
@FilePath     : /xnote/tests/a.py
@Description  : 设置sys.path路径
"""

from xnote.core import *


