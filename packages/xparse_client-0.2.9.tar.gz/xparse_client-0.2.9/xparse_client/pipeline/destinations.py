#!/usr/bin/env python
# -*- encoding: utf-8 -*-

import json
import logging
import uuid
import boto3

from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any

from botocore.config import Config
from pymilvus import MilvusClient


logger = logging.getLogger(__name__)


def _flatten_dict(data: Dict[str, Any], prefix: str = '', fixed_fields: set = None) -> Dict[str, Any]:
    """递归展平嵌套字典
    
    Args:
        data: 要展平的字典
        prefix: 键的前缀
        fixed_fields: 需要排除的字段集合
        
    Returns:
        展平后的字典
    """
    if fixed_fields is None:
        fixed_fields = set()
    
    result = {}
    for key, value in data.items():
        flat_key = f'{prefix}_{key}' if prefix else key
        
        if flat_key in fixed_fields:
            continue
        
        if isinstance(value, dict):
            # 递归展平嵌套字典
            nested = _flatten_dict(value, flat_key, fixed_fields)
            result.update(nested)
        elif isinstance(value, list):
            # 列表转换为 JSON 字符串
            result[flat_key] = json.dumps(value, ensure_ascii=False)
        else:
            # 其他类型直接使用
            result[flat_key] = value
    
    return result


class Destination(ABC):
    """数据目的地抽象基类"""

    @abstractmethod
    def write(self, data: List[Dict[str, Any]], metadata: Dict[str, Any]) -> bool:
        """写入数据"""
        raise NotImplementedError


class MilvusDestination(Destination):
    """Milvus/Zilliz 向量数据库目的地"""

    def __init__(self, db_path: str, collection_name: str, dimension: int, api_key: str = None, token: str = None):
        from pymilvus import DataType

        self.db_path = db_path
        self.collection_name = collection_name
        self.dimension = dimension

        client_kwargs = {'uri': db_path}
        if api_key:
            client_kwargs['token'] = api_key
        elif token:
            client_kwargs['token'] = token

        self.client = MilvusClient(**client_kwargs)

        if not self.client.has_collection(collection_name):
            schema = self.client.create_schema(
                auto_id=False,
                enable_dynamic_field=True
            )

            schema.add_field(field_name="element_id", datatype=DataType.VARCHAR, max_length=128, is_primary=True)
            schema.add_field(field_name="embeddings", datatype=DataType.FLOAT_VECTOR, dim=dimension)
            schema.add_field(field_name="text", datatype=DataType.VARCHAR, max_length=65535)
            schema.add_field(field_name="record_id", datatype=DataType.VARCHAR, max_length=200)

            index_params = self.client.prepare_index_params()
            index_params.add_index(
                field_name="embeddings",
                index_type="AUTOINDEX",
                metric_type="COSINE"
            )

            self.client.create_collection(
                collection_name=collection_name,
                schema=schema,
                index_params=index_params
            )
            print(f"✓ Milvus/Zilliz 集合创建: {collection_name} (自定义 Schema)")
        else:
            print(f"✓ Milvus/Zilliz 集合存在: {collection_name}")

        logger.info(f"Milvus/Zilliz 连接成功: {db_path}")

    def write(self, data: List[Dict[str, Any]], metadata: Dict[str, Any]) -> bool:
        try:
            # 如果 metadata 中有 record_id，先删除相同 record_id 的现有记录
            record_id = metadata.get('record_id')
            if record_id:
                try:
                    # 删除相同 record_id 的所有记录
                    # MilvusClient.delete 返回删除的记录数（可能是 int 或 dict）
                    result = self.client.delete(
                        collection_name=self.collection_name,
                        filter=f'record_id == "{record_id}"'
                    )
                    # 处理返回值：可能是数字或字典
                    deleted_count = result if isinstance(result, int) else result.get('delete_count', 0) if isinstance(result, dict) else 0
                    if deleted_count > 0:
                        print(f"  ✓ 删除现有记录: record_id={record_id}, 删除 {deleted_count} 条")
                        logger.info(f"删除 Milvus 现有记录: record_id={record_id}, 删除 {deleted_count} 条")
                    else:
                        print(f"  → 未找到现有记录: record_id={record_id}")
                except Exception as e:
                    print(f"  ! 删除现有记录失败: {str(e)}")
                    logger.warning(f"删除 Milvus 现有记录失败: record_id={record_id}, {str(e)}")
                    # 继续执行写入，不因为删除失败而中断
            else:
                print(f"  → 没有 record_id")
                logger.warning(f"没有 record_id")
                return
            
            insert_data = []
            for item in data:
                # 获取元素级别的 metadata
                element_metadata = item.get('metadata', {})
                
                if 'embeddings' in item and item['embeddings']:
                    element_id = item.get('element_id') or item.get('id') or str(uuid.uuid4())
                    
                    # 构建基础数据
                    insert_item = {
                        'embeddings': item['embeddings'],
                        'text': item.get('text', ''),
                        'element_id': element_id,
                        'record_id': record_id
                    }
                    
                    # 合并文件级别的 metadata 和元素级别的 metadata
                    # 文件级别的 metadata 优先级更高
                    merged_metadata = {**element_metadata, **metadata}
                    
                    # 将 metadata 中的字段展平到顶层作为动态字段
                    # 排除已存在的固定字段，避免冲突
                    fixed_fields = {'embeddings', 'text', 'element_id', 'record_id', 'created_at', 'metadata'}
                    for key, value in merged_metadata.items():
                        if key not in fixed_fields:
                            # 特殊处理 data_source 字段：如果是字典则递归展平
                            if key == 'data_source' and isinstance(value, dict):
                                # 递归展平 data_source 字典，包括嵌套的字典
                                flattened = _flatten_dict(value, 'data_source', fixed_fields)
                                insert_item.update(flattened)
                            elif key == 'coordinates' and isinstance(value, list):
                                insert_item[key] = value
                            elif isinstance(value, (dict, list)):
                                continue
                            else:
                                insert_item[key] = value
                    
                    insert_data.append(insert_item)

            if not insert_data:
                print(f"  ! 警告: 没有有效的向量数据")
                return False

            self.client.insert(
                collection_name=self.collection_name,
                data=insert_data
            )
            print(f"  ✓ 写入 Milvus: {len(insert_data)} 条")
            logger.info(f"写入 Milvus 成功: {len(insert_data)} 条")
            return True
        except Exception as e:
            print(f"  ✗ 写入 Milvus 失败: {str(e)}")
            logger.error(f"写入 Milvus 失败: {str(e)}")
            return False


class LocalDestination(Destination):
    """本地文件系统目的地"""

    def __init__(self, output_dir: str):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        print(f"✓ 输出目录: {self.output_dir}")
        logger.info(f"输出目录: {self.output_dir}")

    def write(self, data: List[Dict[str, Any]], metadata: Dict[str, Any]) -> bool:
        try:
            filename = metadata.get('filename', 'output')
            base_name = Path(filename).stem
            stage = metadata.get('stage')  # 用于区分中间结果的阶段
            
            # 如果是中间结果，在文件名中添加阶段标识
            if stage:
                output_file = self.output_dir / f"{base_name}_{stage}.json"
            else:
                output_file = self.output_dir / f"{base_name}.json"

            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

            print(f"  ✓ 写入本地: {output_file}")
            logger.info(f"写入本地成功: {output_file}")
            return True
        except Exception as e:
            print(f"  ✗ 写入本地失败: {str(e)}")
            logger.error(f"写入本地失败: {str(e)}")
            return False


class S3Destination(Destination):
    """S3/MinIO 数据目的地"""

    def __init__(self, endpoint: str, access_key: str, secret_key: str,
                 bucket: str, prefix: str = '', region: str = 'us-east-1'):
        self.endpoint = endpoint
        self.bucket = bucket
        self.prefix = prefix.strip('/') if prefix else ''

        if self.endpoint == 'https://textin-minio-api.ai.intsig.net':
            config = Config(signature_version='s3v4')
        elif self.endpoint.endswith('aliyuncs.com'):
            config = Config(signature_version='s3', s3={'addressing_style': 'virtual'})
        else:
            config = Config(signature_version='s3v4', s3={'addressing_style': 'virtual'})

        self.client = boto3.client(
            's3',
            endpoint_url=endpoint,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name=region,
            config=config
        )

        try:
            self.client.head_bucket(Bucket=bucket)
            test_key = f"{self.prefix}/empty.tmp" if self.prefix else f"empty.tmp"
            self.client.put_object(
                Bucket=bucket,
                Key=test_key,
                Body=b''
            )
            try:
                self.client.delete_object(Bucket=bucket, Key=test_key)
            except Exception:
                pass

            print(f"✓ S3 连接成功且可写: {endpoint}/{bucket}")
            logger.info(f"S3 连接成功且可写: {endpoint}/{bucket}")
        except Exception as e:
            print(f"✗ S3 连接或写入测试失败: {str(e)}")
            logger.error(f"S3 连接或写入测试失败: {str(e)}")
            raise

    def write(self, data: List[Dict[str, Any]], metadata: Dict[str, Any]) -> bool:
        try:
            filename = metadata.get('filename', 'output')
            base_name = Path(filename).stem
            object_key = f"{self.prefix}/{base_name}.json" if self.prefix else f"{base_name}.json"

            json_data = json.dumps(data, ensure_ascii=False, indent=2)
            json_bytes = json_data.encode('utf-8')

            self.client.put_object(
                Bucket=self.bucket,
                Key=object_key,
                Body=json_bytes,
                ContentType='application/json'
            )

            print(f"  ✓ 写入 S3: {self.endpoint}/{self.bucket}/{object_key}")
            logger.info(f"写入 S3 成功: {self.endpoint}/{self.bucket}/{object_key}")
            return True
        except Exception as e:
            print(f"  ✗ 写入 S3 失败: {str(e)}")
            logger.error(f"写入 S3 失败: {str(e)}")
            return False


__all__ = [
    'Destination',
    'MilvusDestination',
    'LocalDestination',
    'S3Destination',
]

