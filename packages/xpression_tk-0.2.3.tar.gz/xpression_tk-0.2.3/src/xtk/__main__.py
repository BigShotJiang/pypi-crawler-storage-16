"""
Entry point for the xtk module when run with python -m xtk.
"""

from .cli import main

if __name__ == '__main__':
    main()