# coding:utf-8

__project__ = "xpw"
__version__ = "0.15"
__urlhome__ = "https://github.com/bondbox/xpw/"
__description__ = "Password management and authentication"

# author
__author__ = "Mingzhe Zou"
__author_email__ = "zoumingzhe@outlook.com"
