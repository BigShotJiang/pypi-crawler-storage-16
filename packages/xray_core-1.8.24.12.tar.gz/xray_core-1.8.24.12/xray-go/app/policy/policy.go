// Package policy is an implementation of policy.Manager feature.
package policy
