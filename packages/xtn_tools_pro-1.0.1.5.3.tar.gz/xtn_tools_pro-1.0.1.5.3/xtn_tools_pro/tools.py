#!/usr/bin/env python
# -*- coding: utf-8 -*-

# 说明：
#    tools
# History:
# Date          Author    Version       Modification
# --------------------------------------------------------------------------------------------------
# 2024/4/17    xiatn     V00.01.000    新建
# --------------------------------------------------------------------------------------------------


def split_image(img):
    """
        切割图片
    :param img:
    :return:
    """
    pass


if __name__ == '__main__':
    pass
