import pymongo
from .config import SERVER, DB

def loadMongoDB(server=SERVER, db=DB, timeout=TIMEOUT):
    client = pymongo.MongoClient(server, serverSelectionTimeoutMS=timeout)
    return getattr(client, db)

def filed_type_func(f):
    return {
        'integer': int,
        'number': float,
        'datetime': datetime.datetime.fromisoformat,
        'date': datetime.datetime.fromisoformat,
        'object': json.loads,
        'oid': ObjectId
    }.get(f, text_type)

def all_fields_type_func(fs):
    return dict([(fn, filed_type_func(ft)) for fn, ft in fs.items()])
