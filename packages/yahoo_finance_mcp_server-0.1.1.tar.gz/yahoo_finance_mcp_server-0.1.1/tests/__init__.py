"""Tests for Yahoo Finance MCP Server."""
