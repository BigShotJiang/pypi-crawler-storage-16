from django.apps import AppConfig

app_name = "yarik_django_airflow_api_manager"


class AirflowAPIConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "yarik_django_airflow_api_manager"
