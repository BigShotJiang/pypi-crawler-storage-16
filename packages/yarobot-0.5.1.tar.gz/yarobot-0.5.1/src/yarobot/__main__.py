from .generate import generate

if __name__ == "__main__":
    generate()
