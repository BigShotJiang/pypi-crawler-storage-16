# ycd2 - YouTube Chat Downloader

A Python tool for downloading YouTube chat messages.

## Installation

```bash
pip install ycd2
```

## Usage

```bash
ycd2 [options]
```

## Features

- Download YouTube chat messages
- Support for various chat formats
- Configurable download options

## Requirements

- Python 3.8 or higher
