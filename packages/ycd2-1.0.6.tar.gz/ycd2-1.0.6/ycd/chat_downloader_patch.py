"""
Monkey patches for chat_downloader YouTube handling.

This keeps ycd2 working even when upstream tokens change.
"""

import chat_downloader.sites.youtube as yt


def _patched_parse_video_data(self, video_id, params=None, video_type='video'):
    details = {}

    if video_type == 'clip':
        original_url = self._YT_CLIP_TEMPLATE.format(video_id)
    else:  # video_type == 'video'
        original_url = self._YT_VIDEO_TEMPLATE.format(video_id)

    yt_initial_data, ytcfg, player_response_info = self._get_initial_info(
        original_url, params)

    if not player_response_info:
        yt.log('debug', yt_initial_data)
        yt.log('warning', 'Unable to parse player response, proceeding with caution')

    streaming_data = player_response_info.get('streamingData') or {}
    first_format = yt.multi_get(
        streaming_data, 'adaptiveFormats', 0) or yt.multi_get(
            streaming_data, 'formats', 0) or {}

    player_renderer = yt.multi_get(
        player_response_info, 'microformat', 'playerMicroformatRenderer') or {}
    live_details = player_renderer.get('liveBroadcastDetails') or {}

    video_details = player_response_info.get('videoDetails') or {}
    details['title'] = video_details.get('title')
    details['author'] = video_details.get('author')
    details['author_id'] = video_details.get('channelId')
    details['original_video_id'] = video_details.get('videoId')

    clip_details = player_response_info.get('clipConfig')
    if clip_details:
        details['clip_start_time'] = (yt.float_or_none(
            clip_details.get('startTimeMs', 0)) / 1e3)
        details['clip_end_time'] = (yt.float_or_none(
            clip_details.get('endTimeMs', 0)) / 1e3)
        details['video_type'] = 'clip'

    elif not video_details.get('isLiveContent'):
        details['video_type'] = 'premiere'

    else:
        details['video_type'] = 'video'

    start_timestamp = live_details.get('startTimestamp')
    end_timestamp = live_details.get('endTimestamp')
    details['start_time'] = yt.parse_iso8601(
        start_timestamp) if start_timestamp else None
    details['end_time'] = yt.parse_iso8601(
        end_timestamp) if end_timestamp else None

    details['duration'] = (yt.float_or_none(first_format.get('approxDurationMs', 0)) / 1e3) or yt.float_or_none(
        video_details.get('lengthSeconds')) or yt.float_or_none(player_renderer.get('lengthSeconds'))

    if not details['duration'] and details['start_time'] and details['end_time']:
        details['duration'] = (
            details['end_time'] - details['start_time']) / 1e6

    # Get live chat renderer
    live_chat_renderer = yt.multi_get(
        yt_initial_data,
        'contents',
        'twoColumnWatchNextResults',
        'conversationBar',
        'liveChatRenderer',
    ) or {}

    # Determine stream status early for continuation strategy
    is_live = video_details.get('isLive') or live_details.get('isLiveNow')
    is_upcoming = video_details.get('isUpcoming')
    is_past = not is_live and not is_upcoming

    continuation_info = {}

    # FIX: For past streams, use direct continuation instead of viewSelector
    # YouTube changed their API and viewSelector continuations now return 400 errors
    if is_past:
        yt.log('debug', 'Past stream detected, using direct continuation')
        direct_continuations = live_chat_renderer.get('continuations', [])
        if direct_continuations:
            for cont in direct_continuations:
                continuation_data = cont.get('reloadContinuationData') or yt.try_get_first_value(cont) or {}
                continuation_token = continuation_data.get('continuation')
                if continuation_token:
                    continuation_info['Live chat replay'] = {
                        'continuation': continuation_token,
                        'clickTrackingParams': continuation_data.get('clickTrackingParams') or continuation_data.get('trackingParams'),
                    }
                    yt.log('debug', f'Using direct continuation: {continuation_token[:50]}...')
                    break
    else:
        # For live/upcoming streams, try viewSelector (original behavior)
        sub_menu_items = yt.multi_get(
            live_chat_renderer,
            'header',
            'liveChatHeaderRenderer',
            'viewSelector',
            'sortFilterSubMenuRenderer',
            'subMenuItems',
        ) or []

        for item in sub_menu_items:
            title = item.get('title')
            if not title:
                continue

            continuation_types = item.get('continuation') or {}
            continuation_data = continuation_types.get('reloadContinuationData') or yt.try_get_first_value(
                continuation_types) or {}
            continuation_token = continuation_data.get('continuation')
            if not continuation_token:
                continue

            continuation_info[title] = {
                'continuation': continuation_token,
                'clickTrackingParams': continuation_data.get('clickTrackingParams') or continuation_data.get('trackingParams'),
            }

    details['continuation_info'] = continuation_info

    if video_details.get('isLive') or live_details.get('isLiveNow'):
        details['status'] = 'live'
    elif video_details.get('isUpcoming'):
        details['status'] = 'upcoming'
    else:
        details['status'] = 'past'

    return details, player_response_info, yt_initial_data, ytcfg


def _patched_get_chat_messages(self, initial_info, ytcfg, params):
    initial_continuation_info = initial_info.get('continuation_info') or {}
    if not initial_continuation_info:
        raise yt.NoContinuation(
            f'Initial continuation information could not be found: {initial_info}')

    status = initial_info.get('status')
    offset = initial_info.get('offset')

    start_time = yt.ensure_seconds(params.get('start_time'))
    end_time = yt.ensure_seconds(params.get('end_time'))

    chat_type = params.get('chat_type', 'live').title()
    continuation_items = list(initial_continuation_info.items())

    def _select_continuation():
        desired_key = 'top' if chat_type == 'Top' else 'live'
        for info in continuation_items:
            if desired_key in (info[0] or '').lower():
                return info
        return continuation_items[0]

    continuation_title, continuation_data = _select_continuation()

    click_tracking_params = None
    if isinstance(continuation_data, dict):
        continuation = continuation_data.get('continuation')
        click_tracking_params = continuation_data.get(
            'clickTrackingParams') or continuation_data.get('trackingParams')
    else:
        continuation = continuation_data

    yt.log('debug', f'Getting {chat_type} chat ({continuation_title}).')

    is_replay = status == 'past'

    api_type = 'live_chat'
    if is_replay:
        api_type += '_replay'

    init_page = self._YOUTUBE_INIT_API_TEMPLATE.format(
        api_type, continuation)

    api_key = ytcfg.get('INNERTUBE_API_KEY')

    continuation_url = self._YOUTUBE_CHAT_API_TEMPLATE.format(
        api_type, api_key)
    offset_milliseconds = (
        start_time * 1000) if isinstance(start_time, (float, int)) else None

    messages_groups_to_add = params.get('message_groups') or []
    messages_types_to_add = params.get('message_types') or []

    invalid_groups = set(messages_groups_to_add) - \
        self._MESSAGE_GROUPS.keys()
    if 'all' not in messages_groups_to_add and invalid_groups:
        raise yt.InvalidParameter(
            f'Invalid groups specified: {invalid_groups}')

    self.check_for_invalid_types(
        messages_types_to_add, self._MESSAGE_TYPES)

    self.update_session_headers(self._generate_headers(ytcfg))

    self.update_session_headers({
        'content-type': 'application/json',
        'referer': init_page
    })

    innertube_context = ytcfg.get('INNERTUBE_CONTEXT') or {}

    message_count = 0
    first_time = True

    while True:
        continuation_params = {
            'context': innertube_context,
            'continuation': continuation
        }

        auth = self._generate_sapisidhash_header()
        if auth:
            self.update_session_headers({
                'authorization': auth
            })

        if is_replay and offset_milliseconds is not None:
            continuation_params['currentPlayerState'] = {
                'playerOffsetMs': offset_milliseconds}

        if click_tracking_params:
            continuation_params['context']['clickTracking'] = {
                'clickTrackingParams': click_tracking_params}

        yt_info = self._get_continuation_info(
            continuation_url, params, json=continuation_params)

        debug_info = {
            'click_tracking': yt.multi_get(continuation_params, 'context', 'clickTracking'),
            'continuation': yt.multi_get(continuation_params, 'continuation')
        }
        yt.log('debug', [
            f'Continuation parameters: {debug_info}',
            f"Session headers: {', '.join(self.session.headers.keys())}"
        ])

        logged_in_info = yt.multi_get(
            yt_info, 'responseContext', 'serviceTrackingParams', 1, 'params', 0)
        yt.log('debug', f'Logged-in info: {logged_in_info}')

        info = yt.multi_get(yt_info, 'continuationContents',
                            'liveChatContinuation')
        if not info:
            yt.log('debug', f'No continuation information found: {yt_info}')
            return

        actions = info.get('actions') or []

        if actions:
            for action in actions:
                data = {}

                replay_chat_item_action = action.get(
                    'replayChatItemAction')
                if replay_chat_item_action:
                    offset_time = replay_chat_item_action.get(
                        'videoOffsetTimeMsec')
                    if offset_time:
                        data['time_in_seconds'] = float(offset_time) / 1000

                    action = replay_chat_item_action['actions'][0]

                action.pop('clickTrackingParams', None)
                original_action_type = yt.try_get_first_key(action)

                data['action_type'] = yt.camel_case_split(
                    yt.remove_suffixes(original_action_type, ('Action', 'Command')))

                original_message_type = None
                original_item = {}

                if original_action_type in self._KNOWN_ITEM_ACTION_TYPES:
                    original_item = yt.multi_get(
                        action, original_action_type, 'item')

                    original_message_type = yt.try_get_first_key(
                        original_item)
                    data = self._parse_item(original_item, data, offset)

                elif original_action_type in self._KNOWN_REMOVE_ACTION_TYPES:
                    original_item = action
                    if original_action_type == 'markChatItemAsDeletedAction':
                        original_message_type = 'deletedMessage'
                    else:
                        original_message_type = 'banUser'

                    data = self._parse_item(original_item, data, offset)

                elif original_action_type in self._KNOWN_REPLACE_ACTION_TYPES:
                    original_item = yt.multi_get(
                        action, original_action_type, 'replacementItem')
                    original_message_type = yt.try_get_first_key(
                        original_item)
                    data = self._parse_item(original_item, data, offset)

                elif original_action_type in self._KNOWN_TOOLTIP_ACTION_TYPES:
                    original_item = yt.multi_get(
                        action, original_action_type, 'tooltip')
                    original_message_type = yt.try_get_first_key(
                        original_item)
                    data = self._parse_item(original_item, data, offset)

                elif original_action_type in self._KNOWN_ADD_BANNER_TYPES:
                    original_item = yt.multi_get(
                        action, original_action_type, 'bannerRenderer')

                    if original_item:
                        original_message_type = yt.try_get_first_key(
                            original_item)
                        contents = original_item[original_message_type].get(
                            'contents')
                        parsed_contents = self._parse_item(
                            contents, offset=offset)

                        data.update(parsed_contents)

                    else:
                        yt.debug_log(
                            'No bannerRenderer item',
                            f'Action type: {original_action_type}',
                            f'Action: {action}',
                            f'Parsed data: {data}'
                        )

                elif original_action_type in self._KNOWN_REMOVE_BANNER_TYPES:
                    original_item = action
                    original_message_type = 'removeBanner'
                    data = self._parse_item(original_item, data, offset)

                elif original_action_type in self._KNOWN_IGNORE_ACTION_TYPES:
                    continue

                else:
                    yt.debug_log(
                        f'Unknown action: {original_action_type}',
                        action,
                        data
                    )

                test_for_missing_keys = original_item.get(
                    original_message_type, {}).keys()
                missing_keys = test_for_missing_keys - self._KNOWN_KEYS

                if not data:
                    yt.debug_log(
                        f'Parse of action returned empty results: {original_action_type}',
                        action
                    )

                if missing_keys:
                    yt.debug_log(
                        f'Missing keys found: {missing_keys}',
                        f'Message type: {original_message_type}',
                        f'Action type: {original_action_type}',
                        f'Action: {action}',
                        f'Parsed data: {data}'
                    )

                if original_message_type:

                    new_index = yt.remove_prefixes(
                        original_message_type, 'liveChat')
                    new_index = yt.remove_suffixes(new_index, 'Renderer')
                    data['message_type'] = yt.camel_case_split(new_index)

                    if original_message_type in self._KNOWN_IGNORE_MESSAGE_TYPES:
                        continue
                    elif original_message_type not in self._KNOWN_ACTION_TYPES[original_action_type]:
                        yt.debug_log(
                            f'Unknown message type "{original_message_type}" for action "{original_action_type}"',
                            f"New message type: {data['message_type']}",
                            f'Action: {action}',
                            f'Parsed data: {data}'
                        )

                else:
                    yt.debug_log(
                        'No message type',
                        f'Action type: {original_action_type}',
                        f'Action: {action}',
                        f'Parsed data: {data}'
                    )
                    continue

                to_add = self._must_add_item(
                    data,
                    self._MESSAGE_GROUPS,
                    messages_groups_to_add,
                    messages_types_to_add
                )

                if not to_add:
                    continue

                if is_replay:
                    time_in_seconds = data.get(
                        'time_in_seconds', 0) + (offset or 0)

                    before_start = start_time is not None and time_in_seconds < start_time
                    after_end = end_time is not None and time_in_seconds > end_time

                    if first_time and before_start:
                        continue
                    elif before_start or after_end:
                        return

                message_count += 1
                yield data

            yt.log('debug', f'Total number of messages: {message_count}')
        elif is_replay:
            break
        else:
            yt.log('debug', 'No actions to process.')

        no_continuation = True

        for cont in info.get('continuations') or []:

            continuation_key = yt.try_get_first_key(cont)
            continuation_info = cont[continuation_key]

            yt.log('debug', f'Continuation info: {continuation_info}')

            if continuation_key in self._KNOWN_CHAT_CONTINUATIONS:
                continuation = continuation_info.get('continuation')
                click_tracking_params = continuation_info.get(
                    'clickTrackingParams') or continuation_info.get('trackingParams')
                no_continuation = False

            elif continuation_key in self._KNOWN_SEEK_CONTINUATIONS:
                pass

            else:
                yt.debug_log(
                    f'Unknown continuation: {continuation_key}',
                    cont
                )

            sleep_duration = continuation_info.get('timeoutMs')
            if sleep_duration:
                sleep_duration = max(min(sleep_duration, 8000), 0)

                yt.log('debug', f'Sleeping for {sleep_duration}ms.')
                yt.interruptible_sleep(sleep_duration / 1000)

        if no_continuation:
            break

        if first_time:
            first_time = False


# Apply patches
yt.YouTubeChatDownloader._parse_video_data = _patched_parse_video_data
yt.YouTubeChatDownloader._get_chat_messages = _patched_get_chat_messages
