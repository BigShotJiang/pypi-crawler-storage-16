# Yeo

Yeo is a declarative dotfiles snapshot tool. 

Put simply, you set up a list of paths which you want to copy into the current directory, run `yeo sync`, and it will copy the files into your current directory - preserving their directory structure.

Yeo is still a WIP.

## Contributing

I am using [uv](https://docs.astral.sh/uv/) to develop Yeo. If you would like to contribute, please: 

1. Clone the Git repository
2. Create a new branch with your changes
3. Make changes
3. Open a pull request

Thank you!
