DEFAULT_CONFIG = {
    "overwrite": False,
    "paths": [
        ".config/nvim/init.lua",
        ".config/alacritty/alacritty.toml",
        ".zshrc",
    ],
}

DEFAULT_TRACKED = {"managed_files": []}
