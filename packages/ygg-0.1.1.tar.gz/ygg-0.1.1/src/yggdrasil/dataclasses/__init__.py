from .dataclass import yggdataclass

__all__ = ["yggdataclass"]
