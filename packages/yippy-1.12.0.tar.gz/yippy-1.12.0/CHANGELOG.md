# Changelog

## [1.12.0](https://github.com/CoreySpohn/yippy/compare/v1.11.2...v1.12.0) (2025-12-09)


### Features

* Add support for Inverse Distance Weighting (IDW) PSF synthesis and enable quarter PSF datacube computation for OffJAX ([fe0a554](https://github.com/CoreySpohn/yippy/commit/fe0a5548e1441ed648c3b7ddd22e20408102b0ed))
* GPU support for PSF datacube ([67d5c64](https://github.com/CoreySpohn/yippy/commit/67d5c645d643843766f43577e56f01ddce0bfc46))


### Bug Fixes

* Ensure stellar diameters are a flat array ([6842932](https://github.com/CoreySpohn/yippy/commit/6842932b1c2aa05aab8430fea8c75dcb529c4e60))

## [1.11.2](https://github.com/CoreySpohn/yippy/compare/v1.11.1...v1.11.2) (2025-11-20)


### Bug Fixes

* Revert incorrect merge ([7272fe1](https://github.com/CoreySpohn/yippy/commit/7272fe1fe0607e1f98bc627ae561ed5a6e3d91a0))

## [1.11.1](https://github.com/CoreySpohn/yippy/compare/v1.11.0...v1.11.1) (2025-11-20)


### Miscellaneous Chores

* release 1.11.1 ([36fca7e](https://github.com/CoreySpohn/yippy/commit/36fca7e19fec936946d439642233363ba788a81d))

## [1.11.0](https://github.com/CoreySpohn/yippy/compare/v1.10.2...v1.11.0) (2025-11-20)


### Features

* Add ability to dump coronagraph performance files that match the EXOSIMS format ([edf276c](https://github.com/CoreySpohn/yippy/commit/edf276cabd858b9b82686f7a5585793273763177))
* Performance metrics ([91d86b5](https://github.com/CoreySpohn/yippy/commit/91d86b5b04fd7b71fae7785f4b7ac6e954be2078))

## [1.10.2](https://github.com/CoreySpohn/yippy/compare/v1.10.1...v1.10.2) (2025-07-21)


### Bug Fixes

* testing new shard_map fix ([30e851d](https://github.com/CoreySpohn/yippy/commit/30e851d13edfe926f2edd51c926e2b3d5b7ce28e))

## [1.10.1](https://github.com/CoreySpohn/yippy/compare/v1.10.0...v1.10.1) (2025-07-21)


### Bug Fixes

* testing shard_map fix ([6d71df8](https://github.com/CoreySpohn/yippy/commit/6d71df89d3c25fc06e5d660f17ae078d02e7b525))

## [1.10.0](https://github.com/CoreySpohn/yippy/compare/v1.9.2...v1.10.0) (2025-06-02)


### Features

* Add information on the maximum separation in the image for 1d case ([f16b56e](https://github.com/CoreySpohn/yippy/commit/f16b56e1d82a669ecb7f8afb84fcbc72f59cce56))

## [1.9.2](https://github.com/CoreySpohn/yippy/compare/v1.9.1...v1.9.2) (2025-04-01)


### Bug Fixes

* Add version info to the coronagraph performance file for future proofing ([c39b40b](https://github.com/CoreySpohn/yippy/commit/c39b40bbebdded4c165f1f879b85c014518ca14c))

## [1.9.1](https://github.com/CoreySpohn/yippy/compare/v1.9.0...v1.9.1) (2025-04-01)


### Bug Fixes

* Exclude 0 values from the IWA indexing ([a45177c](https://github.com/CoreySpohn/yippy/commit/a45177c201307fdb5d90491785dd04c7bd14eda8))
* Exclude 0 values from the IWA indexing ([4020d98](https://github.com/CoreySpohn/yippy/commit/4020d98e95b4756b1251e2ea016f16f87d3f8860))

## [1.9.0](https://github.com/CoreySpohn/yippy/compare/v1.8.1...v1.9.0) (2025-01-16)


### Features

* Add calculation of IWA ([461e392](https://github.com/CoreySpohn/yippy/commit/461e3925540f886a1f414bdf16a446a63160b449))


### Bug Fixes

* Now passes a list of integers into the JAX create_device_mesh function to keep up with a change ([59a39f5](https://github.com/CoreySpohn/yippy/commit/59a39f5fd7737f4012711d383877644a2c8b9cf7))

## [1.8.1](https://github.com/CoreySpohn/yippy/compare/v1.8.0...v1.8.1) (2025-01-07)


### Bug Fixes

* Default to 0 values instead of nan values to avoid erroring out ([d126379](https://github.com/CoreySpohn/yippy/commit/d126379fc34bd291d81de5f7f87c7b5465338d11))

## [1.8.0](https://github.com/CoreySpohn/yippy/compare/v1.7.2...v1.8.0) (2025-01-06)


### Features

* Add calculation of raw contrast and throughput ([a561efe](https://github.com/CoreySpohn/yippy/commit/a561efef0591aa975aeafcfa355f474f81e116c1))

## [1.7.2](https://github.com/CoreySpohn/yippy/compare/v1.7.1...v1.7.2) (2025-01-02)


### Bug Fixes

* Now passes lod values instead of lod quantities into the create_psf function ([64c9d2f](https://github.com/CoreySpohn/yippy/commit/64c9d2fbcfb335dbea7b88fc65fd28935748398c))

## [1.7.1](https://github.com/CoreySpohn/yippy/compare/v1.7.0...v1.7.1) (2024-12-16)


### Bug Fixes

* Mask out pixels with no information ([b02b59b](https://github.com/CoreySpohn/yippy/commit/b02b59b86006b8aaac0cd3455ddc290b287d5de1))

## [1.7.0](https://github.com/CoreySpohn/yippy/compare/v1.6.0...v1.7.0) (2024-12-14)


### Features

* Added a function to generate the psf datacube ([9d69197](https://github.com/CoreySpohn/yippy/commit/9d69197a1524df1514848494c95fd1673e7fb890))


### Bug Fixes

* Cut negative values from the fft_shift functions ([2ccaf77](https://github.com/CoreySpohn/yippy/commit/2ccaf775a81f68d77040c386b0af13f3fbdd7ac0))

## [1.6.0](https://github.com/CoreySpohn/yippy/compare/v1.5.0...v1.6.0) (2024-12-12)


### Features

* Using shard_map for parallel processing with JAX ([ca2ba07](https://github.com/CoreySpohn/yippy/commit/ca2ba07b47431ded18b391ab2a1b13f1aa85f515))


### Bug Fixes

* Add safe reciprocal calculation instead of potential division by zeros ([eeadd32](https://github.com/CoreySpohn/yippy/commit/eeadd322367d2e65ed561ce5f396f86f0a27af6a))

## [1.5.0](https://github.com/CoreySpohn/yippy/compare/v1.4.0...v1.5.0) (2024-12-02)


### Features

* Add OffJAx class ([46c82f9](https://github.com/CoreySpohn/yippy/commit/46c82f92e0957924dc3e8be70dba199d3917b8ea))
* Make x and y symmetry optional, remove rotational symmetry ([fe1cb33](https://github.com/CoreySpohn/yippy/commit/fe1cb3346feff5aedd43a649bfde273672b150c7))


### Bug Fixes

* Added x/y symmetry options to the JAX implementation ([08d08e6](https://github.com/CoreySpohn/yippy/commit/08d08e62e70d1533c3b0644560a5ae7569cd570f))

## [1.4.0](https://github.com/CoreySpohn/yippy/compare/v1.3.0...v1.4.0) (2024-08-30)


### Features

* Add expressive logger ([4eec73c](https://github.com/CoreySpohn/yippy/commit/4eec73c74168b1afd8246919ca05d43cf9e6bb7f))
* Add Fourier interpolation utility functions ([d023e1c](https://github.com/CoreySpohn/yippy/commit/d023e1c650d674829c4117738b05f6816ff2762f))
* Implement FFT based interpolation and rotation ([8ecac66](https://github.com/CoreySpohn/yippy/commit/8ecac660316e9f003f27d997874fc0ebcd5202e9))
* Implemented fft interpolation in the One-D case ([5309cb6](https://github.com/CoreySpohn/yippy/commit/5309cb64ef29819831aad53723b344a3132c3ebc))


### Bug Fixes

* Fix the import of the logger ([4021431](https://github.com/CoreySpohn/yippy/commit/4021431b9a131fd703b3fc154c40f394c145dbf7))
* **main:** Improve the one D PSF to only take the log if necessary ([845fdf5](https://github.com/CoreySpohn/yippy/commit/845fdf53d759894ae17b40e1fff1b689acbb49a8))

## [1.3.0](https://github.com/CoreySpohn/yippy/compare/v1.2.0...v1.3.0) (2024-04-23)


### Features

* **main:** Add a temporary sky_trans file ([ad89135](https://github.com/CoreySpohn/yippy/commit/ad89135fc2687b60af018e7a9fde503513ee1854))
* **main:** Added dataclass that handles the header ([3120eda](https://github.com/CoreySpohn/yippy/commit/3120eda53bb75dc96ead74ae3e37c5cd206785ac))

## [1.2.0](https://github.com/CoreySpohn/yippy/compare/v1.1.1...v1.2.0) (2024-04-17)


### Features

* **main:** Added stellar intensity map ([481d333](https://github.com/CoreySpohn/yippy/commit/481d333b89280a906bf8be3642f0eb7bf1fa946e))
* **main:** Adding more support for 2d and quarter symmetric coronagraphs ([3e98780](https://github.com/CoreySpohn/yippy/commit/3e9878034b37535780ee0004f69ad4409b961445))


### Bug Fixes

* **main:** Fixed error in how the quarter symmetric PSFs handled 0*lam/D values ([3e6943f](https://github.com/CoreySpohn/yippy/commit/3e6943f6bfaf89c8b8ba353921bc5a245696e194))

## [1.1.1](https://github.com/CoreySpohn/yippy/compare/v1.1.0...v1.1.1) (2024-04-05)


### Bug Fixes

* **main:** Fixed handling when given single dimensional offax_psf_offsets_list without a second column of zeros ([86f0cc7](https://github.com/CoreySpohn/yippy/commit/86f0cc795d6471b8abaddc3e80278d97aaf93706))

## [1.1.0](https://github.com/CoreySpohn/yippy/compare/v1.0.0...v1.1.0) (2024-04-05)


### Features

* **main:** Add off-axis psfs with automatic unit conversion ([6f5b815](https://github.com/CoreySpohn/yippy/commit/6f5b815093e6fe7898cd625451ad31ab1acee221))

## 1.0.0 (2024-03-22)


### Features

* Automatic versioning and changelog ([ef1acc1](https://github.com/CoreySpohn/yippy/commit/ef1acc1381058fdb32f6b32bb3d695a2035ad048))


### Bug Fixes

* Adding pre-commit hook for conventional commit formatting ([3b52ed6](https://github.com/CoreySpohn/yippy/commit/3b52ed6e3233b7acaa51f5ee8cd2a2b3f317912f))
* putting the workflows in the right folder ought to help ([ff1bf0a](https://github.com/CoreySpohn/yippy/commit/ff1bf0a12850691de801c9a3ba4202f3e8f4f7f1))
