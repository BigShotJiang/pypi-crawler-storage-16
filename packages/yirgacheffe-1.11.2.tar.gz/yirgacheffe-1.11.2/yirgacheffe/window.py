# this code has moved, and in 2.0 this file should be deleted and the items accessed via the top level import
# pylint: disable=W0611
from ._datatypes.area import Area
from ._datatypes.mapprojection import MapProjection, PixelScale
from ._datatypes.window import Window
