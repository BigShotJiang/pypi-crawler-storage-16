"""Top-level package for YooKassa Payout API Python Client Library."""

__author__ = "YooMoney"
__email__ = 'cms@yoomoney.ru'
__version__ = '2.7.0'
