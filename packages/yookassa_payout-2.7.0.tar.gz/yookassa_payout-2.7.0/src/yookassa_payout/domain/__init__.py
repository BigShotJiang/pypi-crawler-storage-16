"""Package for YooKassa Payout API Python Client Library."""
