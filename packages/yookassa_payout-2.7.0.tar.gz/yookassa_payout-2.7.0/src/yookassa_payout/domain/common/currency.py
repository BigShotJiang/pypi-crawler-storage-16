
class Currency:
    """
    Constants representing currencies. Available values are:
    """
    RUB = 643
    RUB_TEST = 10643
