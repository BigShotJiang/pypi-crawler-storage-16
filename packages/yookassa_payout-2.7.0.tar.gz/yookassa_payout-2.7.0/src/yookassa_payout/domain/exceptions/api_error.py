# -*- coding: utf-8 -*-


class ApiError(Exception):
    pass
