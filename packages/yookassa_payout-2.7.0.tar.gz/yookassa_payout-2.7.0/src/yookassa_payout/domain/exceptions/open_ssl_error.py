# -*- coding: utf-8 -*-
from yookassa_payout.domain.exceptions.api_error import ApiError


class OpenSSLError(ApiError):
    HTTP_CODE = 500
