# -*- coding: utf-8 -*-
from yookassa_payout.domain.response.deposition_response import DepositionResponse


class TestDepositionResponse(DepositionResponse):
    pass
