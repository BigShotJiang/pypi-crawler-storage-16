"""YT G-Sheets Orchestrator - Sistema de orquestração distribuída."""

__version__ = "0.1.2"
