def round2(value):
    """
    Rounds the number to 2 decimals.
    """
    return round(value, 2)