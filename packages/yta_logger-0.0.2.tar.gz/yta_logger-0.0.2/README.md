# Youtube Autonomous Logger Module

The module to simplify the way we log and print the information.