__pypi_version__ = "2025.12.08";__local_version__ = "2025.12.08+157a0b5"
