# yua_one/chat/client.py

from __future__ import annotations

from typing import Any, Dict, Generator, Iterable, List, Optional

from .types import (
  ChatMessage,
  ChatRequest,
  ChatStreamOptions,
  ChatStreamChunk,
  ChatGenerateResult,
)
from .stream import parse_sse_lines, parse_ndjson_lines
from ..utils.http import HttpClient


class ChatClient:
  """
  Chat + Streaming + File Upload 클라이언트.

  base_url 예:
    "https://console.yuaone.com/api"

  이 경우 실제 호출 경로:
    POST /chat/stream
    POST /chat/upload
  """

  def __init__(
      self,
      http: HttpClient,
      default_model: str = "yua-one",
      default_temperature: float = 0.7,
  ) -> None:
    self._http = http
    self._default_model = default_model
    self._default_temperature = default_temperature

  def with_options(
      self,
      *,
      default_model: Optional[str] = None,
      default_temperature: Optional[float] = None,
  ) -> "ChatClient":
    """
    기본 모델/온도만 일부 바꾼 새로운 ChatClient 생성
    """
    return ChatClient(
      http=self._http,
      default_model=default_model or self._default_model,
      default_temperature=(
        default_temperature
        if default_temperature is not None
        else self._default_temperature
      ),
    )

  def stream(
      self,
      *,
      prompt: Optional[str] = None,
      messages: Optional[List[ChatMessage]] = None,
      system: Optional[str] = None,
      model: Optional[str] = None,
      temperature: Optional[float] = None,
  ) -> Generator[ChatStreamChunk, None, None]:
    """
    스트리밍 API (동기 generator).
    - 서버는 SSE(text/event-stream) 또는 NDJSON 응답 가능.
    - Python 쪽에서는 for chunk in chat.stream(...): 로 사용.
    """
    body: Dict[str, Any] = {
      "model": model or self._default_model,
      "system": system,
      "prompt": prompt,
      "messages": messages,
      "temperature": (
        temperature
        if temperature is not None
        else self._default_temperature
      ),
      "stream": True,
    }

    # None 값 제거
    body = {k: v for k, v in body.items() if v is not None}

    res = self._http.post("/chat/stream", json=body, stream=True)
    if not res.ok:
      raise RuntimeError(
        f"Chat stream failed: {res.status_code} {res.text}"
      )

    content_type = res.headers.get("Content-Type", "")

    lines: Iterable[str] = res.iter_lines(decode_unicode=True)

    if "text/event-stream" in content_type:
      yield from parse_sse_lines(lines)
    else:
      yield from parse_ndjson_lines(lines)

  def generate(
      self,
      *,
      prompt: Optional[str] = None,
      messages: Optional[List[ChatMessage]] = None,
      system: Optional[str] = None,
      model: Optional[str] = None,
      temperature: Optional[float] = None,
  ) -> ChatGenerateResult:
    """
    stream()을 내부에서 사용하여 전체 텍스트를 합쳐서 반환.
    """
    full_text = ""
    last_chunk: Optional[ChatStreamChunk] = None

    for chunk in self.stream(
      prompt=prompt,
      messages=messages,
      system=system,
      model=model,
      temperature=temperature,
    ):
      last_chunk = chunk
      if chunk.get("type") == "heartbeat":
        continue
      text = chunk.get("text")
      if isinstance(text, str):
        full_text += text

    return {"text": full_text, "last_chunk": last_chunk}

  def upload_file(self, file_path: str) -> Dict[str, Any]:
    """
    파일 업로드 헬퍼.
    - Next.js API: POST /chat/upload (multipart/form-data)
    - 응답: { id, name, size, type, url }
    """
    with open(file_path, "rb") as f:
      files = {"file": (file_path, f)}
      res = self._http.post_multipart("/chat/upload", files=files)
    if not res.ok:
      raise RuntimeError(
        f"File upload failed: {res.status_code} {res.text}"
      )
    return res.json()
