# yua_one/chat/stream.py

from __future__ import annotations

from typing import Any, Generator, Iterable, Optional

from .types import ChatStreamChunk


def _parse_json_or_text(data: str) -> ChatStreamChunk:
  import json

  if data == "[heartbeat]":
    return {"raw": data, "type": "heartbeat"}

  try:
    obj: Any = json.loads(data)
    text: Optional[str] = (
      obj.get("delta")
      or obj.get("content")
      or obj.get("text")
      if isinstance(obj, dict)
      else None
    )
    typ: Optional[str] = None
    if isinstance(obj, dict):
      typ = obj.get("type") or obj.get("event")
    return {
      "raw": data,
      "json": obj,
      "text": text if isinstance(text, str) else None,
      "type": typ,
    }
  except Exception:
    return {
      "raw": data,
      "text": data,
    }


def parse_sse_lines(lines: Iterable[str]) -> Generator[ChatStreamChunk, None, None]:
  """
  text/event-stream 형식 파서.
  - "data: ..." 라인만 처리
  - [heartbeat] 전송 시 type="heartbeat"
  """
  for line in lines:
    line = line.strip()
    if not line:
      continue
    if line.startswith("data:"):
      payload = line[len("data:") :].strip()
      yield _parse_json_or_text(payload)


def parse_ndjson_lines(
    lines: Iterable[str],
) -> Generator[ChatStreamChunk, None, None]:
  """
  NDJSON 또는 줄 단위 JSON 파서.
  """
  for line in lines:
    line = line.strip()
    if not line:
      continue
    yield _parse_json_or_text(line)
