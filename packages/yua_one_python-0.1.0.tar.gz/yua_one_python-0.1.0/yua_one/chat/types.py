# yua_one/chat/types.py

from __future__ import annotations

from typing import Any, Dict, List, Optional, TypedDict, Literal


Role = Literal["system", "user", "assistant"]


class ChatMessage(TypedDict):
  role: Role
  content: str


class ChatRequest(TypedDict, total=False):
  model: str
  messages: List[ChatMessage]
  prompt: str
  system: str
  temperature: float
  stream: bool


class ChatStreamOptions(ChatRequest, total=False):
  # 향후 확장 가능 (예: signal 등)
  pass


class ChatStreamChunk(TypedDict, total=False):
  raw: str
  json: Any
  text: Optional[str]
  type: Optional[str]


class ChatGenerateResult(TypedDict):
  text: str
  last_chunk: Optional[ChatStreamChunk]
