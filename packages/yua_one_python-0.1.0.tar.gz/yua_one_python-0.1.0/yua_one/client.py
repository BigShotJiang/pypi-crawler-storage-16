# yua_one/client.py

from typing import Optional

from .utils.http import HttpClient
from .chat.client import ChatClient
from .spine.graph import SpineGraph
from .spine.timeline import SpineTimeline
from .spine.intent import SpineIntent


class SpineClient:
  """
  High-level spine client:
    yua.spine.graph.get(...)
    yua.spine.timeline.get(...)
    yua.spine.intent.build(...)
  """

  def __init__(self, http: HttpClient) -> None:
    self.graph = SpineGraph(http)
    self.timeline = SpineTimeline(http)
    self.intent = SpineIntent(http)


class YuaClient:
  """
  YUA ONE top-level client.

  예시:
      from yua_one import YuaClient

      yua = YuaClient(
          base_url="https://console.yuaone.com/api",
          api_key="sk-...",
      )

      result = yua.chat.generate(prompt="Hello YUA ONE")
      print(result["text"])
  """

  def __init__(
      self,
      base_url: str,
      api_key: Optional[str] = None,
      default_model: str = "yua-one",
      default_temperature: float = 0.7,
  ) -> None:
    http = HttpClient(base_url=base_url, api_key=api_key)
    self.chat = ChatClient(
      http=http,
      default_model=default_model,
      default_temperature=default_temperature,
    )
    self.spine = SpineClient(http)
