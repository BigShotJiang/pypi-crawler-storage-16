# yua_one/spine/graph.py

from __future__ import annotations

from typing import Any, Dict

from .types import SpineGraphResponse
from ..utils.http import HttpClient


class SpineGraph:
  def __init__(self, http: HttpClient) -> None:
    self._http = http

  def get(self, thread_id: str) -> SpineGraphResponse:
    """
    GET /chat/spine/graph?threadId=...
    """
    res = self._http.get(f"/chat/spine/graph?threadId={thread_id}")
    if not res.ok:
      raise RuntimeError(
        f"Spine graph failed: {res.status_code} {res.text}"
      )
    data: Dict[str, Any] = res.json()
    return data  # 타입: SpineGraphResponse (TypedDict)
