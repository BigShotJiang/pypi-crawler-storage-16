# yua_one/spine/intent.py

from __future__ import annotations

from typing import Any, Dict, List

from ..utils.http import HttpClient
from ..chat.types import ChatMessage


class SpineIntent:
  """
  Spine Intent Builder 래퍼.
  - 실제 백엔드 엔드포인트: POST /chat/spine/intent
  - body: { messages: ChatMessage[] }
  - 서버 구현이 필요함. (지금 SDK는 타입 & 호출만 제공)
  """

  def __init__(self, http: HttpClient) -> None:
    self._http = http

  def build(self, messages: List[ChatMessage]) -> Dict[str, Any]:
    res = self._http.post("/chat/spine/intent", json={"messages": messages})
    if not res.ok:
      raise RuntimeError(
        f"Spine intent failed: {res.status_code} {res.text}"
      )
    return res.json()
