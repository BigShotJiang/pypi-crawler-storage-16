# yua_one/spine/timeline.py

from __future__ import annotations

from typing import Any, Dict

from .types import SpineTimelineResponse
from ..utils.http import HttpClient


class SpineTimeline:
  def __init__(self, http: HttpClient) -> None:
    self._http = http

  def get(self, thread_id: str, message_id: str) -> SpineTimelineResponse:
    """
    GET /chat/spine/timeline?threadId=...&messageId=...
    """
    res = self._http.get(
      f"/chat/spine/timeline?threadId={thread_id}&messageId={message_id}"
    )
    if not res.ok:
      raise RuntimeError(
        f"Spine timeline failed: {res.status_code} {res.text}"
      )
    data: Dict[str, Any] = res.json()
    return data  # 타입: SpineTimelineResponse
