# yua_one/spine/types.py

from __future__ import annotations

from typing import Any, List, TypedDict


class SpineStage(TypedDict):
  stage: str
  timestamp: int
  output: Any


class SpineTimelineResponse(TypedDict):
  ok: bool
  threadId: str
  messageId: str
  timeline: List[SpineStage]


class SpineGraphNode(TypedDict, total=False):
  id: str
  type: str
  label: str
  timestamp: int
  role: str
  model: str
  stage: str
  threadId: str
  messageId: str


class SpineGraphEdge(TypedDict):
  from_: str  # "from"는 파이썬 키워드라 from_ 로 사용
  to: str


class SpineGraphResponse(TypedDict):
  ok: bool
  threadId: str
  nodes: List[SpineGraphNode]
  edges: List[SpineGraphEdge]
