# yua_one/utils/http.py

from __future__ import annotations

from typing import Any, Dict, Optional

import requests


class HttpClient:
  """
  간단한 HTTP 래퍼.
  - base_url: "https://console.yuaone.com/api"
  - 자동 Authorization 헤더 처리
  """

  def __init__(self, base_url: str, api_key: Optional[str] = None) -> None:
    self.base_url = base_url.rstrip("/")
    self.api_key = api_key

  def _headers(self, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    headers: Dict[str, str] = {
      "Content-Type": "application/json",
    }
    if self.api_key:
      headers["Authorization"] = f"Bearer {self.api_key}"
    if extra:
      headers.update(extra)
    return headers

  def get(self, path: str, **kwargs: Any) -> requests.Response:
    url = f"{self.base_url}{path}"
    return requests.get(url, headers=self._headers(), **kwargs)

  def post(self, path: str, json: Any = None, **kwargs: Any) -> requests.Response:
    url = f"{self.base_url}{path}"
    return requests.post(url, json=json, headers=self._headers(), **kwargs)

  def post_multipart(
      self,
      path: str,
      files: Any,
      data: Optional[Dict[str, Any]] = None,
      **kwargs: Any,
  ) -> requests.Response:
    """
    파일 업로드용 (multipart/form-data)
    - Content-Type은 requests가 자동으로 설정하므로 여기서는 지정하지 않는다.
    """
    url = f"{self.base_url}{path}"
    headers: Dict[str, str] = {}
    if self.api_key:
      headers["Authorization"] = f"Bearer {self.api_key}"
    return requests.post(url, files=files, data=data, headers=headers, **kwargs)
