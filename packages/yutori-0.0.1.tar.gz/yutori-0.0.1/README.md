# Yutori SDK

This folder contains the `yutori` Python package used to interact
with the public Yutori APIs. The SDK is intentionally minimal, designed for
local development or internal tooling while the API surface stabilizes.

You can import the client with:

```python
from yutori import YutoriClient

client = YutoriClient(api_key="sk-your-api-key")
print(client.get_usage())
```

## Available Methods

The `YutoriClient` class exposes the following methods:

- `get_usage()` — Fetch usage statistics for your API key
- `list_scouts()` — List your existing scouts
- `create_scout(request)` — Create a new monitoring scout (provide a payload)
- `agent_run(request)` — Start a one-off agent run (browsing task)
- `chat_completions(request)` — Access chat completion endpoint (LLM/generative)
- `close()` — Release underlying HTTP resources

Each method corresponds to a public Yutori API endpoint.




