# yxd2 - YouTube XML Downloader

A Python tool for downloading YouTube XML data and transcripts.

## Installation

```bash
pip install yxd2
```

## Usage

```bash
yxd2 [options]
```

## Features

- Download YouTube XML data
- Extract video transcripts
- Archive HTML content
- Configurable download options

## Requirements

- Python 3.8 or higher

## License

This project is licensed under the GNU Affero General Public License v3 (AGPLv3).

## Author

vb (i@s.biz)
