{
    "api_key": null,
    "EULA": null,
    "proxy_provider": "dataimpulse",
    "proxy_username": null,
    "proxy_password": null,
    "proxy_location": null,
    "proxy_api_key": null,
    "dataimpulse_username": null,
    "dataimpulse_password": null,
    "dataimpulse_location": null
}
