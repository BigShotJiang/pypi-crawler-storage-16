"""DEPRECATED: Zabbix CLI scripts.

These scripts are now baked directly into the CLI. The current scripts
are just shims to call the CLI with the appropriate arguments.
"""

from __future__ import annotations
