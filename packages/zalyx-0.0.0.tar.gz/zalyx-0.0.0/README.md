echo "# zalyx

Placeholder package. Do not use." > README.md
