# Security Policy

Please report security issues only to security@allauth.org.
