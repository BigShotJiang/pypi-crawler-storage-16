
from ..object import Object


class CallbackGame(Object):
    """Placeholder, currently holds no information.

    Use BotFather to set up your game.
    """

    def __init__(self):
        super().__init__()
