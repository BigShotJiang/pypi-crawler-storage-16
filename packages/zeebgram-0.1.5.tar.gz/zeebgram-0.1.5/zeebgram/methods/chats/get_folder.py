
from typing import Optional

import zeebgram
from zeebgram import types


class GetFolder:
    async def get_folder(
        self: "zeebgram.Client",
        folder_id: int
    ) -> Optional["types.Folder"]:
        """Get a user's folder by id.

        .. include:: /_includes/usable-by/users.rst

        Returns:
            :obj:`~zeebgram.types.Folder`: On success, the user's folder is returned.

        Example:
            .. code-block:: python

                # Get folder by id
                await app.get_folder(123456789)
        """
        async for folder in self.get_folders():
            if folder.id == folder_id:
                return folder
