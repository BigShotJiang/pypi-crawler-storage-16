"""
Simple setup.py for backward compatibility.
Most configuration is now in pyproject.toml
"""
from setuptools import setup

# This file is kept for backward compatibility
# All configuration is in pyproject.toml
setup()