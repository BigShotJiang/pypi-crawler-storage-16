"""
Zelesis Neo API Python Bindings

A Python library for interacting with the Zelesis Neo API.
"""

# Version should match pyproject.toml
__version__ = "0.0.1"

# Import your main classes/functions here when you create them
# Example:
# from .client import Client
# from .api import API

# Make them available at package level
# __all__ = ['Client', 'API']

