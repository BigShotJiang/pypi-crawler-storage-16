"""Zen Mode: Minimalist autonomous agent runner."""

__version__ = "0.1.0"
