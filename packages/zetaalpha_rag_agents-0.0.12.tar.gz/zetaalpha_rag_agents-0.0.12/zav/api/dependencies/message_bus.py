def get_message_bus():

    sentinel_bus = object()
    return sentinel_bus
