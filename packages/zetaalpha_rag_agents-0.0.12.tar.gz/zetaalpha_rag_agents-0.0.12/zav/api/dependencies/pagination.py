def pagination(page: int = 1, page_size: int = 100):

    return {"page": page, "page_size": page_size}
