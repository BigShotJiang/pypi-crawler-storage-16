from zav.message_bus import Command


class CheckIfReady(Command):
    pass
