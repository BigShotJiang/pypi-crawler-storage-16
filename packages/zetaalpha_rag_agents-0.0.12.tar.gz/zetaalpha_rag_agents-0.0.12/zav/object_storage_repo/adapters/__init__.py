from zav.object_storage_repo.adapters.azure_repository import *
from zav.object_storage_repo.adapters.disk_repository import *
from zav.object_storage_repo.adapters.s3_repository import *
