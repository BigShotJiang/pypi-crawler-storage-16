# 1.0.1 — 2025-12-12

- Raise an exception when no `.zim` files are found
- Use `<noscript>` to display JavaScript notices
- Minor refactorings

# 1.0.0 — 2025-11-27

- Initial version
