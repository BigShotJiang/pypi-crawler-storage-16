"""Entry point for the ZK Documentation MCP Server."""

import sys
import argparse
from .server import main, run_init_command


def create_parser() -> argparse.ArgumentParser:
    """Create and configure the CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="zk-doc-mcp-server",
        description="ZK Framework Documentation MCP Server"
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Init subcommand
    init_parser = subparsers.add_parser(
        "init",
        help="Initialize documentation repository and pre-index it"
    )
    init_parser.add_argument(
        "--force",
        action="store_true",
        help="Force re-cloning of repository and re-indexing"
    )

    return parser


def main_cli():
    """Parse arguments and route to appropriate command handler."""
    parser = create_parser()
    args = parser.parse_args()

    if args.command == "init":
        exit_code = run_init_command(force=args.force)
        sys.exit(exit_code)
    else:
        # Default: run server
        main()


if __name__ == "__main__":
    main_cli()
