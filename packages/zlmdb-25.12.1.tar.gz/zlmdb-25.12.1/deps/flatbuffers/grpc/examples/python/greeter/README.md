# Python Greeter example

## Prerequisite

- You need to have grpc python installed on your device `pip install grpcio`
## How to run Server:

- `python server.py ${PORT}`

## How to run Client:

- `python client.py ${PORT} ${NAME}`
