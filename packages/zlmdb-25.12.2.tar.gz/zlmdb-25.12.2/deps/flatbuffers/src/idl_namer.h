#ifndef FLATBUFFERS_IDL_NAMER_H_
#define FLATBUFFERS_IDL_NAMER_H_

#include "codegen/idl_namer.h"

#endif  // FLATBUFFERS_IDL_NAMER_H_
