"""Test coverage for zlw.fourier module
"""


from zlw.fourier import (
    FourierBackend,
    NumpyFourierBackend,
)


class TestFourierBackend:
    """Test base class"""

    def test_init(self):
        """Test initialization"""



