from znsocket.storages.memory import MemoryStorage

__all__ = ["MemoryStorage"]
