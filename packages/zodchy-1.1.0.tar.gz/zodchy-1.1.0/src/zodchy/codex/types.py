import typing


class NoValueType:
    pass


class SkipType:
    pass


Empty: typing.TypeAlias = NoValueType
