from setuptools import setup

# This file is required for compatibility with some tools that do not fully support
# pyproject.toml. It simply delegates to the setuptools build system, which
# will use the configuration from pyproject.toml.
setup()
