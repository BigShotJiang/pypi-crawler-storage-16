import enum


class ClusterMode(enum.Enum):
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
