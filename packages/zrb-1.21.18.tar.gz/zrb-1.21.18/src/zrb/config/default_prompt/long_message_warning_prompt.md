**SYSTEM WARNING:** Almost run out of token.
If the task is not completed, let's conclude with all findings/information/progress/todo list.
Note everything so that you can continue the task in the new session.
