# zuno

[![PyPI - Version](https://img.shields.io/pypi/v/zuno.svg)](https://pypi.org/project/zuno)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/zuno.svg)](https://pypi.org/project/zuno)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install zuno
```

## License

`zuno` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
