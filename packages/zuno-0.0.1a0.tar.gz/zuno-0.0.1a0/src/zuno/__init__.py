# SPDX-FileCopyrightText: 2025-present Yasas Senarath <12231659+ysenarath@users.noreply.github.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1-alpha"
