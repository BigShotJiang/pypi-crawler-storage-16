# AccountObjectNSFieldsSynctoNetSuiteNS

Specifies whether the account should be synchronized with NetSuite. Only available if you have installed the [Zuora Connector for NetSuite](https://www.zuora.com/connect/app/?appId=265). 

## Enum

* `YES` (value: `'Yes'`)

* `NO` (value: `'No'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


