# BatchQueryFormat

The format of the query. The default value is `CSV`. 

## Enum

* `CSV` (value: `'CSV'`)

* `ZIP` (value: `'ZIP'`)

* `GZIP` (value: `'GZIP'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


