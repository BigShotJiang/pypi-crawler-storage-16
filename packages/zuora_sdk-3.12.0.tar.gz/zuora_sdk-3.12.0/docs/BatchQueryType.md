# BatchQueryType

The query type. 

## Enum

* `ZOQL` (value: `'zoql'`)

* `ZOQLEXPORT` (value: `'zoqlexport'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


