# BulkPDFGenerationStepStatus

Status of the Current Step that the Job is undergoing

## Enum

* `JOBCREATED` (value: `'JobCreated'`)

* `TASKSCREATED` (value: `'TasksCreated'`)

* `GENERATEMISSPDF` (value: `'GenerateMissPDF'`)

* `PDFTOZIP` (value: `'PdfToZip'`)

* `POSTPROCESSING` (value: `'PostProcessing'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


