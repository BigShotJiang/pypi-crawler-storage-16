# ChargeModel


## Enum

* `FLATFEE` (value: `'FlatFee'`)

* `PERUNIT` (value: `'PerUnit'`)

* `OVERAGE` (value: `'Overage'`)

* `VOLUME` (value: `'Volume'`)

* `TIERED` (value: `'Tiered'`)

* `TIEREDWITHOVERAGE` (value: `'TieredWithOverage'`)

* `DISCOUNTFIXEDAMOUNT` (value: `'DiscountFixedAmount'`)

* `DISCOUNTPERCENTAGE` (value: `'DiscountPercentage'`)

* `MULTIATTRIBUTEPRICING` (value: `'MultiAttributePricing'`)

* `PRERATEDPERUNIT` (value: `'PreratedPerUnit'`)

* `PRERATEDPRICING` (value: `'PreratedPricing'`)

* `HIGHWATERMARKVOLUMEPRICING` (value: `'HighWatermarkVolumePricing'`)

* `HIGHWATERMARKTIEREDPRICING` (value: `'HighWatermarkTieredPricing'`)

* `DELIVERY` (value: `'Delivery'`)

* `CALCULATED` (value: `'Calculated'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


