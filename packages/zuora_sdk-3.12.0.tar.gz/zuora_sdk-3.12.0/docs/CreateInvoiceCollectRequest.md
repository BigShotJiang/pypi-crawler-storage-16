# CreateInvoiceCollectRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account_key** | **str** | Customer account ID or account number.  | 
**document_date** | **date** | The date that should appear on the invoice and credit memo being generated,  in &#x60;yyyy-mm-dd&#x60; format. If this field is omitted  and &#x60;invoiceId&#x60; is not specified, the current date is used by default.     **Note:** The credit memo is only available if you have the Invoice Settlement feature enabled.    This field is in Zuora REST API version control. Supported minor  versions are &#x60;215.0&#x60; and later. To use this field in the method, you  must set the  &#x60;zuora-version&#x60; parameter to the minor version number in  the request header. | [optional] 
**invoice_date** | **date** | **Note:** This field has been replaced by the &#x60;documentDate&#x60; field in Zuora REST API version &#x60;215.0&#x60; and later. The  &#x60;invoiceDate&#x60; field is only available for backward  compatibility.   The date that should appear on the invoice being generated,  in &#x60;yyyy-mm-dd&#x60; format. If this field is omitted  and &#x60;invoiceId&#x60; is not specified, the current date is used by default.    This field is in Zuora REST API version control. Supported minor  versions are &#x60;214.0&#x60; and earlier. | [optional] 
**invoice_id** | **str** | The ID or Number of an existing invoice for which to collect payment using the account&#39;s default payment method. If this value is specified, no new invoice is generated, and the following fields are ignored:   - &#x60;invoiceDate&#x60; and &#x60;invoiceTargetDate&#x60; (if the Zuora REST API version is 214.0 or earlier)   - &#x60;documentDate&#x60; and &#x60;targetDate&#x60; (if the Zuora REST API version is 215.0 or later)  | [optional] 
**invoice_target_date** | **date** | **Note:** This field has been replaced by the &#x60;targetDate&#x60; field in Zuora REST API version &#x60;215.0&#x60; and later. The  &#x60;invoiceTargetDate&#x60; field is only available for backward  compatibility.    The date through which to calculate charges on this account if an invoice is generated, in &#x60;yyyy-mm-dd&#x60; format. If this field is omitted  and &#x60;invoiceId&#x60; is not specified, the current date is used by default.     This field is in Zuora REST API version control. Supported minor  versions are &#x60;214.0&#x60; and earlier.   | [optional] 
**payment_gateway** | **str** | The name of the gateway that will be used for the payment. Must be a valid gateway name and the gateway must support the specific payment method. If a value is not specified, the default gateway on the Account will be used. | [optional] 
**target_date** | **date** | The date through which to calculate charges on this account if an invoice or a credit memo is generated,   in &#x60;yyyy-mm-dd&#x60; format. If this field is omitted  and &#x60;invoiceId&#x60; is not specified, the current date is used by default.     **Note:** The credit memo is only available if you have the Invoice Settlement feature enabled.    This field is in Zuora REST API version control. Supported minor  versions are &#x60;215.0&#x60; and later. To use this field in the method, you  must set the  &#x60;zuora-version&#x60; parameter to the minor version number in  the request header. | [optional] 
**payment_method_id** | **str** | paymentMethodId. | [optional] 

## Example

```python
from zuora_sdk.models.create_invoice_collect_request import CreateInvoiceCollectRequest

# TODO update the JSON string below
json = "{}"
# create an instance of CreateInvoiceCollectRequest from a JSON string
create_invoice_collect_request_instance = CreateInvoiceCollectRequest.from_json(json)
# print the JSON string representation of the object
print(CreateInvoiceCollectRequest.to_json())

# convert the object into a dict
create_invoice_collect_request_dict = create_invoice_collect_request_instance.to_dict()
# create an instance of CreateInvoiceCollectRequest from a dict
create_invoice_collect_request_from_dict = CreateInvoiceCollectRequest.from_dict(create_invoice_collect_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


