# CreditCardCardType

Type of card. 

## Enum

* `VISA` (value: `'Visa'`)

* `MASTERCARD` (value: `'MasterCard'`)

* `AMERICANEXPRESS` (value: `'AmericanExpress'`)

* `DISCOVER` (value: `'Discover'`)

* `JCB` (value: `'JCB'`)

* `DINERS` (value: `'Diners'`)

* `CUP` (value: `'CUP'`)

* `MAESTRO` (value: `'Maestro'`)

* `ELECTRON` (value: `'Electron'`)

* `APPLEVISA` (value: `'AppleVisa'`)

* `APPLEMASTERCARD` (value: `'AppleMasterCard'`)

* `APPLEAMERICANEXPRESS` (value: `'AppleAmericanExpress'`)

* `APPLEDISCOVER` (value: `'AppleDiscover'`)

* `APPLEJCB` (value: `'AppleJCB'`)

* `ELO` (value: `'Elo'`)

* `HIPERCARD` (value: `'Hipercard'`)

* `NARANJA` (value: `'Naranja'`)

* `NATIVA` (value: `'Nativa'`)

* `TARJETASHOPPING` (value: `'TarjetaShopping'`)

* `CENCOSUD` (value: `'Cencosud'`)

* `ARGENCARD` (value: `'Argencard'`)

* `CABAL` (value: `'Cabal'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


