# CustomObjectDefinitionSchemaType

The custom object definition type. Can only be `object` currently.

## Enum

* `OBJECT` (value: `'object'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


