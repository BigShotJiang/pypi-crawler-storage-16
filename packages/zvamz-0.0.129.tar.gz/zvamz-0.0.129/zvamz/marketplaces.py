class marketplaces:
    @staticmethod
    def US():
        # United State
        url = "https://sellingpartnerapi-na.amazon.com"
        marketplace_id = "ATVPDKIKX0DER"
        return url, marketplace_id

    @staticmethod
    def CA():
        # Canada
        url = "https://sellingpartnerapi-na.amazon.com"
        marketplace_id = "A2EUQ1WTGCTBG2"
        return url, marketplace_id

    @staticmethod
    def MX():
        # Mexico
        url = "https://sellingpartnerapi-na.amazon.com"
        marketplace_id = "A1AM78C64UM0Y8"
        return url, marketplace_id

    @staticmethod
    def BR():
        # Brazil
        url = "https://sellingpartnerapi-na.amazon.com"
        marketplace_id = "A2Q3Y263D00KWC"
        return url, marketplace_id

    @staticmethod
    def ES():
        # Spain
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "A1RKKUPIHCS9HS"
        return url, marketplace_id

    @staticmethod
    def UK():
        # United Kingdom
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "A1F83G8C2ARO7P"
        return url, marketplace_id

    @staticmethod
    def FR():
        # France
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "A13V1IB3VIYZZH"
        return url, marketplace_id

    @staticmethod
    def BE():
        # Belgium
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "AMEN7PMS3EDWL"
        return url, marketplace_id

    @staticmethod
    def NL():
        # Netherlands
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "A1805IZSGTT6HS"
        return url, marketplace_id

    @staticmethod
    def DE():
        # Germany
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "A1PA6795UKMFR9"
        return url, marketplace_id

    @staticmethod
    def IT():
        # Italy
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "APJ6JRA9NG5V4"
        return url, marketplace_id

    @staticmethod
    def SE():
        # Sweden
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "A2NODRKZP88ZB9"
        return url, marketplace_id

    @staticmethod
    def PL():
        # Poland
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "A1C3SOZRARQ6R3"
        return url, marketplace_id

    @staticmethod
    def TR():
        # Turkey
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "A33AVAJ2PDY3EV"
        return url, marketplace_id

    @staticmethod
    def ZA():
        # South Africa
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "AE08WJ6YKNBMC"
        return url, marketplace_id

    @staticmethod
    def EG():
        # Egypt
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "ARBP9OOSHTCHU"
        return url, marketplace_id

    @staticmethod
    def SA():
        # Saoudi Arabia
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "A17E79C6D8DWNP"
        return url, marketplace_id

    @staticmethod
    def AE():
        # United Arab Emerates
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "A2VIGQ35RCS4UG"
        return url, marketplace_id

    @staticmethod
    def IN():
        # India
        url = "https://sellingpartnerapi-eu.amazon.com"
        marketplace_id = "A21TJRUUN4KGV"
        return url, marketplace_id

    @staticmethod
    def JP():
        # Japan
        url = "https://sellingpartnerapi-fe.amazon.com"
        marketplace_id = "A1VC38T7YXB528"
        return url, marketplace_id

    @staticmethod
    def AU():
        # Australia
        url = "https://sellingpartnerapi-fe.amazon.com"
        marketplace_id = "A39IBJ37TRP1C6"
        return url, marketplace_id

    @staticmethod
    def SG():
        # Singapore
        url = "https://sellingpartnerapi-fe.amazon.com"
        marketplace_id = "A19VAU5U5O7RUS"
        return url, marketplace_id
