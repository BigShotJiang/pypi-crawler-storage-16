import re
import time
import datetime
import requests
import base64
import json
import os
from .tools import check_image as _check_image
from .tools import check_filename
from .error import DeerError

try:
    __data = os.environ.get("RUNTIME_USER_INFO")
    if not __data:
        HOST = 'deer.fengniaojianzhan.com'
    else:
        __user_info = json.loads(__data)
        HOST = __user_info.get('currentDomain', 'deer.fengniaojianzhan.com')
except Exception as e:
    HOST = 'deer.fengniaojianzhan.com'


def img_transfer(img, style, dst='./'):
    if not isinstance(img, str):
        raise TypeError("图片名称类型错误")
    _check_image(img)
    if not os.path.exists(img):
        raise ValueError("输入的图片不存在")
    if not isinstance(style, int) or not 0 < style < 10:
        raise ValueError("style非指定范围内的风格")
    if not os.path.exists(dst):
        try:
            os.makedirs(dst)
        except Exception as e:
            raise ValueError("路径错误，创建文件失败")

    url = f'https://{HOST}/dijkstra/images/styletrans'
    with open(img, 'rb') as fp:
        content = fp.read()
    res = requests.post(url, data={"image": base64.b64encode(content).decode("utf-8"), "option": style})
    result = res.json()
    err_no = result.get("errNo")
    if err_no != 0:
        raise ValueError("%s, %s" % (err_no, result.get("errMsg", "接口调用错误")))
    data = result.get("data", {}).get("image")
    if not data:
        raise ValueError("图片转换失败，请稍后重试~")
    image_data = base64.b64decode(data)
    image_name = os.path.split(img)[-1].split('.')[0] + '_transfer_' + str(int(time.time() * 1000)) + '.png'
    filename = os.path.join(dst, image_name)
    with open(filename, 'wb') as fp:
        fp.write(image_data)
    return image_name


def text2image(text, name=None, dst='./'):
    if not isinstance(text, str):
        raise ValueError("文本内容类型错误")
    if len(text) > 100:
        raise ValueError("文本描述内容上限为100个文字")
    if name is None:
        name = 'text2image_' + str(int(time.time() * 1000))
    if not isinstance(name, str):
        raise TypeError("生成文件名称类型错误")
    if not name:
        raise ValueError("生成文件名错误")
    name = name + '.png'
    if not os.path.exists(dst):
        try:
            os.makedirs(dst)
        except Exception as e:
            raise ValueError("路径错误，创建文件失败")
    url = f'https://{HOST}/dijkstra/images/text2image'
    res = requests.post(url, data={"prompt": text})
    result = res.json()
    err_no = result.get("errNo")
    if err_no != 0:
        raise ValueError("%s, %s" % (err_no, result.get("errMsg", "接口调用错误")))
    data = result.get("data")
    if not data:
        raise ValueError("图片生成失败，请稍后重试~")
    pid = data[0]

    url = f'https://{HOST}/dijkstra/images/getimage'
    time.sleep(10)
    while True:
        res = requests.post(url, data={"pid": pid})
        result = res.json()
        err_no = result.get("errNo")
        if err_no != 0:
            raise ValueError("%s, %s" % (err_no, result.get("errMsg", "接口调用错误")))
        data = result.get("data")
        if not data:
            raise ValueError("图片生成失败，请稍后重试~")
        picture = data.get("picture")
        if not picture:
            time.sleep(5)
            continue
        break
    image_data = base64.b64decode(picture)
    filename = os.path.join(dst, name)
    with open(filename, 'wb') as fp:
        fp.write(image_data)
    return name


def write_poem(word, layout=5, mode=0):
    if not isinstance(word, str) or len(word) < 1 or len(word) > 7:
        raise ValueError("提示词为1～7个字符的字符串")
    if layout not in [5, 7]:
        raise ValueError("请输入正确的诗词格式参数，五言诗: 5，七言诗: 7")
    if mode not in [0, 1]:
        raise ValueError("请输入正确的模式参数，藏头：0，藏尾：1")

    url = f'https://{HOST}/dijkstra/lang/poetry'
    res = requests.post(url, data={"word": word, "len": layout, "type":mode})
    result = res.json()
    err_no = result.get("errNo")
    if err_no != 0:
        raise ValueError("%s, %s" % (err_no, result.get("errMsg", "接口调用错误")))
    data = result.get("data", {}).get("poetry", [])
    if not data:
        raise ValueError("获取数据失败")
    return data


def img_cartoon(img, dst='./'):
    """生成卡通图"""
    if not isinstance(img, str):
        raise TypeError("图片名称类型错误")
    _check_image(img)
    if not os.path.exists(img):
        raise ValueError("输入的图片不存在")
    if not os.path.exists(dst):
        try:
            os.makedirs(dst)
        except Exception as e:
            raise ValueError("路径错误，创建文件失败")
    url = f'https://{HOST}/dijkstra/images/image2image'
    with open(img, 'rb') as fp:
        content = fp.read()
    res = requests.post(url, json={"image": base64.b64encode(content).decode("utf-8")})
    result = res.json()
    err_no = result.get("errNo")
    if err_no != 0:
        raise ValueError("%s, %s" % (err_no, result.get("errMsg", "接口调用错误")))
    data = result.get("data", {}).get("image")
    if not data:
        raise ValueError("图片转换失败，请稍后重试~")
    image_data = base64.b64decode(data)
    image_name = os.path.split(img)[-1].split('.')[0] + '_cartoon_' + str(int(time.time() * 1000)) + '.png'
    filename = os.path.join(dst, image_name)
    with open(filename, 'wb') as fp:
        fp.write(image_data)
    return image_name


def face_aging(img, age, dst='./'):
    if not isinstance(img, str):
        raise TypeError("图片名称类型错误")
    _check_image(img)
    if not os.path.exists(img):
        raise ValueError("输入的图片不存在")
    if not isinstance(age, int) or age < 0:
        raise TypeError("age类型错误，需为非负整数")
    if age < 10:
        age = 10
    if age > 100:
        age = 100
    if not os.path.exists(dst):
        try:
            os.makedirs(dst)
        except Exception as e:
            raise ValueError("路径错误，创建文件失败")
    url = f'https://{HOST}/dijkstra/images/aging'
    with open(img, 'rb') as fp:
        content = fp.read()
    res = requests.post(url, json={"image": base64.b64encode(content).decode("utf-8"), "age": age})
    result = res.json()
    err_no = result.get("errNo")
    if err_no != 0:
        raise ValueError("%s, %s" % (err_no, result.get("errMsg", "接口调用错误")))
    data = result.get("data", {}).get("renderImg")
    if not data:
        raise ValueError("图片转换失败，请稍后重试~")
    image_data = base64.b64decode(data)
    image_name = os.path.split(img)[-1].split('.')[0] + '_aging_' + str(int(time.time() * 1000)) + '.png'
    filename = os.path.join(dst, image_name)
    with open(filename, 'wb') as fp:
        fp.write(image_data)
    return image_name


def daily_image(offset=0, vertical=False, name=None, dst='./'):
    """每日一图"""
    if not isinstance(offset, int):
        raise TypeError("时间间隔数值类型错误，需为整型值")
    if not -1 < offset < 31:
        raise ValueError("时间间隔的范围仅限 0~30")
    if not isinstance(vertical, bool):
        raise TypeError("参数2数值类型错误，需为布尔值")
    if name is None:
        name = 'daily_image_' + str(int(time.time() * 1000))
    if len(name) > 50:
        raise ValueError("目标文件名长度需要在50个字符之内")
    if not check_filename(name):
        raise ValueError("目标文件名不合法，创建文件失败")
    image_name = name + '.png'
    if not os.path.exists(dst):
        try:
            os.makedirs(dst)
        except Exception as e:
            raise ValueError("路径错误，创建文件失败")
    if vertical:
        url = 'https://scratch-deer.cdnjtzy.com/daily_images/image_downloads/{date}_1080x1920.jpg'
    else:
        url = 'https://scratch-deer.cdnjtzy.com/daily_images/image_downloads/{date}_1920x1080.jpg'
    now = datetime.datetime.now() - datetime.timedelta(offset)
    date = f'{now.month:02}-{now.day:02}'
    url = url.format(date=date)
    filename = os.path.join(dst, image_name)
    try:
        res = requests.get(url)
        if res.status_code != 200:
            raise DeerError('请求错误')
        with open(filename, 'wb') as fp:
            fp.write(res.content)
    except DeerError:
        raise ValueError('线上文件名错误，找不到对应的图片')
    except requests.exceptions.Timeout:
        raise ValueError("系统繁忙，由于当前访问量过大，系统正在全力处理中。请您稍后再试~ ")
    except Exception as e:
        raise ValueError("获取图片信息失败，请稍后重试~")
    return filename


def get_weather(city=None):
    """实时天气"""
    if city and not isinstance(city, str):
        raise TypeError('城市名称必须为字符串类型')

    url = f'https://{HOST}/dijkstra/location/weatherforecast'
    try:
        if city is None:
            city = ''
        res = requests.post(url, json={"area": city})
        result = res.json()
        err_no = result.get('errNo')
        if err_no != 0:
            if err_no in [6001, 6002, 6003]:
                raise DeerError("城市名称信息错误")
            raise ValueError("获取城市天气错误")
        else:
            data = result.get('data')
            daily = data.get('daily')
            if not daily:
                raise DeerError("城市名称信息错误")
            return daily[0].get('weatherDay')
    except DeerError:
        raise ValueError('无法识别当前城市名')
    except requests.exceptions.Timeout:
        raise ValueError('系统繁忙，由于当前访问量过大，系统正在全力处理中。请您稍后再试~ ')
    except Exception as e:
        raise ValueError('获取天气信息失败，请稍后重试~')


def draw(text, style=None, name=None, dst='./'):
    """文生图"""
    if not isinstance(text, str):
        raise TypeError("文本参数值类型错误，请重新填写")
    if len(text) > 100:
        raise ValueError("提示词文本长度需要在100个字之内")
    style_map = {
        1: {"key": "皮克斯", "prompt": "超细节，3D渲染，写实，3D建模，皮克斯风格，迪士尼风格，动画电影，"},
        2: {"key": "动漫", "prompt": "超细节，日漫风格，京都动漫风格，2D动画风格，二次元，"},
        3: {"key": "贴纸", "prompt": "涂鸦艺术风格，风格可爱，贴纸设计，动漫贴纸，精致的细节描绘，无瑕疵，无损画质，矢量图，背景干净，"},
        4: {"key": "像素", "prompt": "超细节，像素风格，2D，像素画，像素艺术，"},
        5: {"key": "我的世界", "prompt": "超细节，我的世界游戏风格，方块化，3D像素块，3D渲染，平面着色、增强方块感，简单材质纹理，Minecraft风格，低多边形风格，"},
        6: {"key": "手办", "prompt": "Q版手办，3D玩具质感（C4D建模+OC渲染）,简约背景，4K超高清，柔光雾效，"},
        7: {"key": "摄影", "prompt": "超写实，高细节摄影，照片，真实拍摄，真实光照，"},
        8: {"key": "水墨", "prompt": "水墨画，水墨风格，杰作，艺术作品，笔触，"}
    }
    if style is not None:
        if not isinstance(style, int) or style < 1 or style > 8:
            raise TypeError("style风格参数的范围仅限 1~8")
        prompt = style_map.get(style).get("prompt") + text
    else:
        prompt = text

    if name is None:
        name = 'draw_' + str(int(time.time() * 1000))
    if len(name) > 50:
        raise ValueError("目标文件名长度需要在50个字符之内")
    if not check_filename(name):
        raise ValueError("目标文件名不合法，创建文件失败")
    img_name = name + '.png'
    if not os.path.exists(dst):
        try:
            os.makedirs(dst)
        except Exception as e:
            raise ValueError("路径错误，创建文件失败")
    url = f'https://{HOST}/dijkstra/images/text2image'
    try:
        res = requests.post(url, data={"prompt": prompt})
        result = res.json()
        err_no = result.get("errNo")
        if err_no != 0:
            raise ValueError("%s, %s" % (err_no, result.get("errMsg", "接口调用错误")))
        data = result.get("data")
        if not data:
            raise ValueError("图片生成失败，请稍后重试~")
        pid = data[0]

        url = f'https://{HOST}/dijkstra/images/getimage'
        time.sleep(10)
        while True:
            res = requests.post(url, data={"pid": pid})
            result = res.json()
            err_no = result.get("errNo")
            if err_no != 0:
                raise ValueError("%s, %s" % (err_no, result.get("errMsg", "接口调用错误")))
            data = result.get("data")
            if not data:
                raise ValueError("图片生成失败，请稍后重试~")
            picture = data.get("picture")
            if not picture:
                time.sleep(5)
                continue
            break
        image_data = base64.b64decode(picture)
        filename = os.path.join(dst, img_name)
        with open(filename, 'wb') as fp:
            fp.write(image_data)
    except TimeoutError:
        raise ValueError('系统繁忙，由于当前访问量过大，系统正在全力处理中。请您稍后再试~ ')
    except Exception as e:
        raise ValueError('接口请求错误，请重试')
    return filename

