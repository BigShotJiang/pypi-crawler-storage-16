import re
from PIL import Image


def check_image(img):
    try:
        with Image.open(img) as im:
            if im.format.lower() not in ['jpg', 'jpeg', 'png']:
                raise ValueError("图片格式错误，请修改后重试~")
    except Exception as e:
        raise ValueError("图片格式错误，请修改后重试~")


check_filename_re = re.compile(r'^[\u4e00-\u9fa5A-Za-z0-9_\-\(\)]+$')


def check_filename(name):
    if not isinstance(name, str) or not name.strip():
        return False
    if not check_filename_re.fullmatch(name):
        return False
    return True




