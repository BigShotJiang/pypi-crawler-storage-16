"""Zylch CLI - Thin client for Zylch AI API server.

This is a thin client that connects to the Zylch API server.
It does NOT work standalone - requires a running server.
"""

__version__ = "0.9.0"
