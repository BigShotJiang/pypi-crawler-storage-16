"""Zylch CLI - Main entry point for thin client.

Interactive CLI that communicates with Zylch API server.
"""

import logging
import sys
from pathlib import Path
from typing import Optional

import click
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.keys import Keys
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from .config import load_config, save_config, CLIConfig, check_token_status, needs_token_refresh, refresh_firebase_token
from .api_client import ZylchAPIClient, ZylchAPIError, ZylchAuthError
from .local_storage import LocalStorage
from .modifier_queue import ModifierQueue
from .oauth_handler import initiate_browser_login, initiate_service_connect

logger = logging.getLogger(__name__)
console = Console()

# Profile path
PROFILE_PATH = Path.home() / ".zylch" / "profile"
DEFAULT_PROFILE = """# Zylch CLI Profile
# Commands here run at startup (after login)
# Lines starting with # are comments

# Show connection status at startup
/connect
"""


class ZylchCLI:
    """Zylch thin CLI client."""

    def __init__(self):
        """Initialize CLI."""
        self.config = load_config()
        self.api_client = ZylchAPIClient(
            server_url=self.config.api_server_url,
            session_token=self.config.session_token
        )
        self.storage = LocalStorage(db_path=Path(self.config.local_db_path))
        self.queue = ModifierQueue(db_path=Path(self.config.local_db_path))

        logger.info("Zylch CLI initialized")

    def check_server(self) -> bool:
        """Check if server is reachable.

        Returns:
            True if server is up
        """
        try:
            health = self.api_client.health_check()
            if health.get('status') == 'healthy':
                console.print("✅ Server is running", style="green")
                return True
            else:
                console.print("⚠️  Server responded but unhealthy", style="yellow")
                return False
        except Exception as e:
            console.print(f"❌ Cannot reach server: {e}", style="red")
            console.print(f"\nMake sure the server is running:")
            console.print(f"  cd /Users/mal/hb/zylch")
            console.print(f"  uvicorn zylch.api.main:app --reload --port 8000")
            return False

    def check_auth(self, verbose: bool = False) -> bool:
        """Check if user is authenticated.

        Args:
            verbose: If True, print status messages

        Returns:
            True if authenticated
        """
        if not self.config.session_token:
            return False

        # Check token expiry locally first
        is_valid, _ = check_token_status(self.config.session_token)
        if not is_valid:
            return False

        if verbose:
            console.print(
                f"✅ Logged in as {self.config.email}",
                style="green"
            )
        return True

    def try_refresh_token(self) -> bool:
        """Try to refresh the session token if it's expiring soon.

        Returns:
            True if token is valid (either still valid or successfully refreshed)
        """
        if not self.config.session_token:
            return False

        # Check if refresh is needed
        if not needs_token_refresh(self.config.session_token):
            return True  # Token still valid, no refresh needed

        # Try to refresh if we have a refresh token
        if not self.config.refresh_token:
            logger.debug("Token expiring but no refresh token available")
            return False

        logger.debug("Token expiring soon, attempting refresh...")
        result = refresh_firebase_token(self.config.refresh_token)

        if result:
            new_token, new_refresh_token = result

            # Update config
            self.config.session_token = new_token
            self.config.refresh_token = new_refresh_token
            save_config(self.config)

            # Update API client
            self.api_client.set_token(new_token)

            logger.debug("Token refreshed successfully")
            return True
        else:
            logger.debug("Token refresh failed")
            return False

    def login(self):
        """Login flow - opens browser for OAuth authentication."""
        console.print(Panel.fit(
            "[bold]Zylch CLI Login[/bold]\n\n"
            "Your browser will open for authentication.\n"
            "Please sign in and authorize the application.\n\n"
            "If the browser doesn't open automatically,\n"
            "you'll see a URL to visit manually.",
            title="Login",
            border_style="cyan"
        ))

        try:
            # Initiate browser-based OAuth flow
            result = initiate_browser_login(
                server_url=self.config.api_server_url,
                callback_port=8765
            )

            if result is None:
                console.print("❌ Login timeout - no response received", style="red")
                return

            if 'error' in result:
                console.print(f"❌ Login failed: {result['error']}", style="red")
                return

            # Extract token data
            token = result.get('token')
            refresh_token = result.get('refresh_token')
            owner_id = result.get('owner_id')
            email = result.get('email')

            if token:
                # Save session with refresh token
                self.config.session_token = token
                self.config.refresh_token = refresh_token or ''
                self.config.owner_id = owner_id or ''
                self.config.email = email or ''
                save_config(self.config)

                # Update the api_client with new token
                self.api_client.set_token(token)

                console.print(f"\n✅ Logged in as {self.config.email}", style="green")

                # Run profile commands after successful login
                self._run_profile()
            else:
                console.print("❌ Login failed - no token received", style="red")

        except Exception as e:
            console.print(f"❌ Login error: {e}", style="red")
            logger.exception("Login failed")

    def logout(self):
        """Logout and clear session."""
        try:
            self.api_client.logout()
        except:
            pass  # Ignore errors on logout

        # Clear local session
        self.config.session_token = ""
        self.config.refresh_token = ""
        self.config.owner_id = ""
        self.config.email = ""
        save_config(self.config)

        console.print("✅ Logged out", style="green")

    def status(self):
        """Show CLI status."""
        console.print(Panel.fit(
            f"[bold]Zylch CLI Status[/bold]\n\n"
            f"Server URL: {self.config.api_server_url}\n"
            f"Logged in: {'Yes' if self.config.session_token else 'No'}\n"
            f"Email: {self.config.email or 'N/A'}\n"
            f"Owner ID: {self.config.owner_id or 'N/A'}\n"
            f"Offline mode: {'Enabled' if self.config.enable_offline else 'Disabled'}\n"
            f"Local DB: {self.config.local_db_path}",
            title="Status",
            border_style="cyan"
        ))

        # Cache stats
        if self.config.session_token:
            stats = self.storage.get_cache_stats()
            console.print("\n[bold]Local Cache:[/bold]")
            console.print(f"  Emails: {stats['email']['cached_threads']}")
            console.print(f"  Calendar: {stats['calendar']['cached_events']}")
            console.print(f"  Contacts: {stats['contacts']['cached_contacts']}")
            console.print(f"  Pending modifiers: {stats['modifier_queue']['pending_operations']}")

    def sync(self):
        """Sync data from server."""
        if not self.check_auth():
            console.print("❌ Not logged in. Run: /login", style="red")
            return

        console.print("🔄 Syncing data from server...", style="cyan")

        try:
            # Sync emails
            console.print("  Fetching emails...")
            emails_response = self.api_client.list_emails(days_back=30, limit=100)
            threads = emails_response.get('threads', [])
            for thread in threads:
                self.storage.cache_email_thread(thread['thread_id'], thread)
            console.print(f"    ✅ Cached {len(threads)} email threads")

            # Sync calendar
            console.print("  Fetching calendar events...")
            calendar_response = self.api_client.list_calendar_events(limit=100)
            events = calendar_response.get('events', [])
            for event in events:
                self.storage.cache_calendar_event(event['event_id'], event)
            console.print(f"    ✅ Cached {len(events)} calendar events")

            # Sync contacts
            console.print("  Fetching contacts...")
            contacts_response = self.api_client.list_contacts(limit=100)
            contacts = contacts_response.get('contacts', [])
            for contact in contacts:
                self.storage.cache_contact(contact['memory_id'], contact)
            console.print(f"    ✅ Cached {len(contacts)} contacts")

            # Record sync
            self.storage.record_sync('email', success=True)
            self.storage.record_sync('calendar', success=True)
            self.storage.record_sync('contacts', success=True)

            console.print("\n✅ Sync complete!", style="green")

        except ZylchAuthError:
            console.print("❌ Authentication failed - please login again", style="red")
        except ZylchAPIError as e:
            console.print(f"❌ Sync failed: {e}", style="red")

    def chat(self):
        """Start interactive chat with Zylch AI."""
        console.print(Panel.fit(
            "[bold]Zylch AI Chat[/bold]\n\n"
            "Chat with your AI assistant.\n\n"
            "[bold]Input:[/bold]\n"
            "  Enter          Send message\n"
            "  Ctrl+J         New line\n"
            "  Paste          Multiline text supported\n\n"
            "[bold]Commands:[/bold]\n"
            "  /login     Login to Zylch\n"
            "  /logout    Logout from Zylch\n"
            "  /connect   Connect services\n"
            "  /status    Show connection status\n"
            "  /help      Show all commands\n"
            "  /quit      Exit Zylch",
            title="Zylch",
            border_style="cyan"
        ))

        # Show connection status at startup
        self._show_startup_status()

        session_id = None

        # Setup prompt_toolkit for history and autocomplete
        history_file = Path.home() / ".zylch" / "chat_history"
        history_file.parent.mkdir(parents=True, exist_ok=True)

        class CommandCompleter(Completer):
            """Custom completer for slash commands."""
            def __init__(self, api_client):
                self.api_client = api_client
                self.base_commands = [
                    # Client-side commands
                    '/login', '/logout', '/status', '/new', '/quit', '/exit',
                    '/connect', '/connect --reset',
                    # Server-side commands (sent to backend)
                    '/help', '/sync', '/gaps', '/briefing',
                    '/archive', '/archive --help', '/archive --stats', '/archive --init', '/archive --sync', '/archive --search',
                    '/cache', '/cache --help', '/cache --clear',
                    '/memory', '/memory --help', '/memory --list', '/memory --stats', '/memory --add',
                    '/model', '/model haiku', '/model sonnet', '/model opus', '/model auto',
                    '/trigger', '/trigger --help', '/trigger --list', '/trigger --add', '/trigger --remove', '/trigger --types',
                    '/mrcall', '/mrcall --help',
                    '/share', '/revoke', '/sharing',
                    '/tutorial',
                ]
                self.connect_commands = []
                self._load_connect_commands()

            def _load_connect_commands(self):
                """Load /connect provider commands from API."""
                try:
                    # Only load if authenticated (avoid 401 errors during login flow)
                    if self.api_client and hasattr(self.api_client, 'get_connections_status'):
                        # Check if we have an auth token before making the request
                        if 'Authorization' not in self.api_client.session.headers:
                            return  # Skip if not authenticated yet

                        status_data = self.api_client.get_connections_status(include_unavailable=False)
                        providers = status_data.get('connections', [])
                        for provider in providers:
                            if provider.get('is_available'):
                                self.connect_commands.append(f"/connect {provider['provider_key']}")
                except Exception:
                    # Fallback to empty if API fails
                    pass

            def get_completions(self, document, complete_event):
                text = document.text_before_cursor.lower()
                all_commands = self.base_commands + self.connect_commands
                for cmd in all_commands:
                    if cmd.lower().startswith(text):
                        yield Completion(cmd, start_position=-len(text))

        # Key bindings for multiline input
        # - Enter: submit (unless Shift/Alt held)
        # - Shift+Enter or Alt+Enter: insert newline
        kb = KeyBindings()

        @kb.add(Keys.Enter)
        def handle_enter(event):
            """Submit on Enter (single line or end of multiline)."""
            buf = event.app.current_buffer
            # If text is empty or doesn't look like it needs continuation, submit
            text = buf.text
            # Submit the input
            buf.validate_and_handle()

        @kb.add('escape', 'enter')  # Option+Enter on macOS (Esc then Enter)
        def handle_option_enter(event):
            """Insert newline on Option+Enter (or Esc then Enter)."""
            event.app.current_buffer.insert_text('\n')

        @kb.add('c-j')  # Control+J (universal newline)
        def handle_ctrl_j(event):
            """Insert newline on Control+J."""
            event.app.current_buffer.insert_text('\n')


        prompt_session = PromptSession(
            history=FileHistory(str(history_file)),
            auto_suggest=AutoSuggestFromHistory(),
            completer=CommandCompleter(self.api_client),
            key_bindings=kb,
            multiline=True
        )

        try:
            while True:
                # Get user input with history and autocomplete
                try:
                    console.print()  # Newline before prompt
                    user_input = prompt_session.prompt('You: ')
                except (KeyboardInterrupt, EOFError):
                    console.print("\n\n👋 Goodbye!", style="yellow")
                    break

                # Check for empty input
                if not user_input.strip():
                    continue

                # Handle special commands (client-side only)
                cmd = user_input.strip().lower()

                # Commands that MUST be handled client-side (auth, session management)
                if cmd in ['/quit', '/exit', '/q']:
                    console.print("\n👋 Goodbye!", style="yellow")
                    break
                elif cmd == '/login':
                    self.login()
                    continue
                elif cmd == '/logout':
                    self.logout()
                    continue
                elif cmd == '/status':
                    self.status()
                    continue
                elif cmd == '/new':
                    session_id = None
                    console.print("\n✨ Started new conversation", style="green")
                    continue
                elif cmd == '/connect':
                    self.connect()
                    continue
                elif cmd == '/connect anthropic':
                    self.connect(service='anthropic')
                    continue
                elif cmd == '/connect google':
                    self.connect(service='google')
                    continue
                elif cmd == '/connect microsoft':
                    self.connect(service='microsoft')
                    continue
                elif cmd == '/connect --reset':
                    self.connect(reset=True)
                    continue
                elif cmd.startswith('/connect '):
                    # Handle "/connect <service>"
                    service = cmd.split(' ', 1)[1].strip()
                    self.connect(service=service)
                    continue

                # All other /commands go to server (including /help, /sync, /gaps, /archive, etc.)
                # The server's command_handlers.py handles them

                # Check auth before sending message
                if not self.config.session_token:
                    console.print("\n❌ Not logged in. Use /login first.", style="red")
                    continue

                # Try to refresh token if expiring soon
                if not self.try_refresh_token():
                    # Token expired and couldn't refresh
                    console.print("\n❌ Session expired. Use /login to authenticate again.", style="red")
                    continue

                # Send message to API
                try:
                    import time
                    start_time = time.time()

                    # Show appropriate waiting message
                    if user_input.startswith('/'):
                        console.print(f"\n[dim]Running {user_input.split()[0]}...[/dim]")
                    else:
                        console.print("\n[dim]Thinking...[/dim]")

                    response = self.api_client.send_chat_message(
                        message=user_input,
                        session_id=session_id
                    )

                    elapsed = time.time() - start_time

                    # Update session ID
                    session_id = response.get('session_id')

                    # Display response
                    assistant_response = response.get('response', '')
                    console.print(f"\n[bold green]Zylch[/bold green]: {assistant_response}")

                    # Show timing for commands or in debug mode
                    metadata = response.get('metadata', {})
                    if user_input.startswith('/') or logger.level <= logging.DEBUG:
                        server_time = metadata.get('execution_time_ms', 0) / 1000
                        console.print(f"\n[dim]⏱ {elapsed:.1f}s total ({server_time:.1f}s server)[/dim]")

                except ZylchAuthError:
                    console.print("\n❌ Session expired. Use /login to authenticate again.", style="red")
                except ZylchAPIError as e:
                    console.print(f"\n❌ Error: {e}", style="red")

        except Exception as e:
            console.print(f"\n❌ Chat error: {e}", style="red")
            logger.exception("Chat failed")

    def _ensure_profile_exists(self):
        """Ensure ~/.zylch/profile exists with default content."""
        if not PROFILE_PATH.exists():
            PROFILE_PATH.parent.mkdir(parents=True, exist_ok=True)
            PROFILE_PATH.write_text(DEFAULT_PROFILE)
            logger.info(f"Created default profile at {PROFILE_PATH}")

    def _run_profile(self):
        """Run commands from ~/.zylch/profile.

        Executes each command, shows output, continues on error (like bashrc).
        """
        self._ensure_profile_exists()

        try:
            profile_content = PROFILE_PATH.read_text()
        except Exception as e:
            logger.warning(f"Could not read profile: {e}")
            return

        console.print("\n[dim]Running profile...[/dim]")

        for line in profile_content.splitlines():
            line = line.strip()

            # Skip empty lines and comments
            if not line or line.startswith('#'):
                continue

            # Execute the command
            logger.debug(f"Profile: executing '{line}'")
            try:
                self._execute_profile_command(line)
            except Exception as e:
                # Continue on error (like bashrc)
                console.print(f"[yellow]Profile error on '{line}': {e}[/yellow]")
                logger.warning(f"Profile command '{line}' failed: {e}")

    def _execute_profile_command(self, cmd: str):
        """Execute a single profile command.

        Args:
            cmd: Command to execute (e.g., '/connect')
        """
        cmd_lower = cmd.lower()

        # Handle client-side commands
        if cmd_lower == '/connect':
            self.connect()
        elif cmd_lower == '/status':
            self.status()
        elif cmd_lower.startswith('/connect '):
            service = cmd.split(' ', 1)[1].strip()
            self.connect(service=service)
        elif cmd_lower == '/sync':
            self.sync()
        elif cmd_lower.startswith('/'):
            # Server-side command - send to API
            if not self.config.session_token:
                console.print(f"[dim]Skipping {cmd} (not logged in)[/dim]")
                return

            try:
                response = self.api_client.send_chat_message(message=cmd, session_id=None)
                assistant_response = response.get('response', '')
                if assistant_response:
                    console.print(f"[green]Zylch[/green]: {assistant_response}")
            except Exception as e:
                console.print(f"[yellow]Error running {cmd}: {e}[/yellow]")
        else:
            # Non-command text - send to AI as chat message
            if not self.config.session_token:
                console.print(f"[dim]Skipping '{cmd}' (not logged in)[/dim]")
                return

            try:
                console.print(f"\n[dim]→ {cmd}[/dim]")
                response = self.api_client.send_chat_message(message=cmd, session_id=None)
                assistant_response = response.get('response', '')
                if assistant_response:
                    console.print(f"[green]Zylch[/green]: {assistant_response}")
            except Exception as e:
                console.print(f"[yellow]Error: {e}[/yellow]")

    def _show_startup_status(self):
        """Show connection status at chat startup (legacy - now uses profile)."""
        # Check login status first
        if not self.config.session_token:
            console.print("\n[bold]Status:[/bold]")
            console.print("  ❌ Not logged in → /login", style="red")
            return

        # Check token expiry
        is_valid, _ = check_token_status(self.config.session_token)
        if not is_valid:
            console.print("\n[bold]Status:[/bold]")
            console.print("  ⚠️  Session expired → /login", style="yellow")
            return

        # Run profile commands (replaces old hardcoded status checks)
        self._run_profile()

    def _show_help(self):
        """Show help for chat commands."""
        console.print(Panel.fit(
            "[bold]Session & Auth:[/bold]\n"
            "  /login               Login to Zylch\n"
            "  /logout              Logout from Zylch\n"
            "  /status              Show CLI status\n"
            "  /new                 Start new conversation\n"
            "  /quit                Exit Zylch\n\n"
            "[bold]Integrations:[/bold]\n"
            "  /connect             Show connected services\n"
            "  /connect anthropic   Set your Anthropic API key\n"
            "  /connect google      Connect Google (Gmail, Calendar)\n"
            "  /connect microsoft   Connect Microsoft (Outlook)\n"
            "  /connect --reset     Disconnect all services\n"
            "  /mrcall              Link to MrCall assistant\n\n"
            "[bold]Data & Sync:[/bold]\n"
            "  /sync [days]         Sync emails & calendar\n"
            "  /gaps                Show relationship gaps\n"
            "  /archive             Email archive (--help for details)\n"
            "  /cache               Cache management (--help for details)\n\n"
            "[bold]AI & Memory:[/bold]\n"
            "  /memory              Behavioral memory (--help for details)\n"
            "  /model               Switch AI model (haiku/sonnet/opus)\n"
            "  /trigger             Event automation (--help for details)\n\n"
            "[bold]Sharing:[/bold]\n"
            "  /share <email>       Share data with user\n"
            "  /revoke <email>      Revoke sharing access\n"
            "  /sharing             Show sharing status\n\n"
            "[bold]Other:[/bold]\n"
            "  /tutorial            Interactive tutorial\n"
            "  /help                Show this help",
            title="Zylch Commands",
            border_style="cyan"
        ))

    def connect(self, service: Optional[str] = None, reset: bool = False):
        """Connect or manage service integrations (Google, Microsoft, etc.).

        Args:
            service: Service to connect ('google', 'microsoft')
            reset: If True, disconnect all integrations
        """
        if not self.check_auth():
            console.print("❌ Not logged in. Run: /login", style="red")
            return

        # Handle reset (disconnect all)
        if reset:
            self._disconnect_all_services()
            return

        # Show status if no service specified
        if not service:
            self._show_connection_status()
            return

        # Route to specific service handlers
        service_lower = service.lower()

        if service_lower == 'google':
            self._connect_google()
        elif service_lower == 'microsoft':
            self._connect_microsoft()
        elif service_lower == 'anthropic':
            self._connect_anthropic()
        elif service_lower in ['vonage', 'pipedrive']:
            self._connect_api_key_service(service_lower)
        else:
            # Unknown service - show available providers
            console.print(f"❌ Unknown service: {service}", style="red")
            console.print("\nAvailable services:")
            self._show_connection_status()

    def _show_connection_status(self):
        """Show status of all service connections from backend API."""
        try:
            # Get all connections from backend API
            status_data = self.api_client.get_connections_status(include_unavailable=True)
            connections = status_data.get('connections', [])

            # Group by status
            connected = [c for c in connections if c.get('status') == 'connected']
            disconnected = [c for c in connections if c.get('is_available') and c.get('status') == 'disconnected']
            coming_soon = [c for c in connections if not c.get('is_available')]

            # Build output
            lines = []
            lines.append("[bold]Your Connections[/bold]")
            lines.append("")
            lines.append("Use /connect {provider} to connect")
            lines.append("")

            # Connected
            if connected:
                lines.append("[green]✅ Connected:[/green]")
                for i, conn in enumerate(connected, 1):
                    line = f"{i}. {conn['display_name']}"
                    if conn.get('connected_email'):
                        line += f" - {conn['connected_email']}"
                    lines.append(line)
                lines.append("")

            # Available but not connected
            if disconnected:
                lines.append("[yellow]❌ Available (Not Connected):[/yellow]")
                for i, conn in enumerate(disconnected, len(connected) + 1):
                    lines.append(f"{i}. {conn['display_name']}  [dim]\\[{conn['provider_key']}][/dim]")
                lines.append("")

            # Coming soon
            if coming_soon:
                lines.append("[dim]⏳ Coming Soon:[/dim]")
                for i, conn in enumerate(coming_soon, len(connected) + len(disconnected) + 1):
                    lines.append(f"{i}. {conn['display_name']}  [dim]\\[{conn['provider_key']}][/dim]")
                lines.append("")

            console.print(Panel("\n".join(lines), title="Integrations", border_style="cyan"))

        except Exception as e:
            console.print(f"❌ Error fetching connections: {e}", style="red")
            console.print("Run /connect {provider} to manage connections")

    def _connect_google(self):
        """Connect Google account via OAuth with local callback."""
        self._connect_service('google')

    def _connect_microsoft(self):
        """Connect Microsoft account via OAuth with local callback."""
        self._connect_service('microsoft')

    def _connect_anthropic(self):
        """Set Anthropic API key for AI chat."""
        import os
        from rich.prompt import Confirm

        console.print(Panel.fit(
            "[bold]Connect Anthropic API[/bold]\n\n"
            "Zylch uses Claude AI for chat. You need your own API key.\n\n"
            "Get your API key at: https://console.anthropic.com/\n\n"
            "Your key will be stored securely and used for your chats.",
            title="Anthropic API Key",
            border_style="cyan"
        ))

        # Check if already configured
        try:
            status = self.api_client.get_anthropic_status()
            if status.get('has_key'):
                console.print("\n✅ API key already configured.", style="green")
                if not Confirm.ask("Replace with a new key?"):
                    return
        except Exception:
            pass  # Continue to prompt for key

        # Check for environment variable first
        env_key = os.environ.get('ANTHROPIC_API_KEY')
        if env_key and env_key.startswith('sk-ant-'):
            masked_key = env_key[:12] + '...' + env_key[-4:]
            console.print(f"\n Found ANTHROPIC_API_KEY in environment: {masked_key}", style="cyan")
            if Confirm.ask("Use this key?"):
                api_key = env_key
            else:
                api_key = None
        else:
            api_key = None

        # Prompt for API key if not using env var
        if not api_key:
            from rich.prompt import Prompt
            console.print("")
            api_key = Prompt.ask("Enter your Anthropic API key", password=True)

            if not api_key or not api_key.strip():
                console.print("❌ No API key provided.", style="red")
                return

        api_key = api_key.strip()

        # Validate format
        if not api_key.startswith('sk-ant-'):
            console.print("⚠️  Warning: API key doesn't look like an Anthropic key (should start with 'sk-ant-')", style="yellow")
            from rich.prompt import Confirm
            if not Confirm.ask("Continue anyway?"):
                return

        # Save to server
        try:
            result = self.api_client.set_anthropic_key(api_key)
            if result.get('success'):
                console.print("\n✅ Anthropic API key saved!", style="green")
                console.print("You can now use Zylch chat.")
            else:
                console.print(f"\n❌ Failed to save API key: {result.get('error', 'Unknown error')}", style="red")
        except Exception as e:
            console.print(f"\n❌ Error saving API key: {e}", style="red")

    def _connect_api_key_service(self, service: str):
        """Connect an API key-based service (Vonage, Pipedrive, etc.).

        Args:
            service: Service name (vonage, pipedrive, etc.)
        """
        from rich.prompt import Prompt

        service_info = {
            'vonage': {
                'display_name': 'Vonage SMS',
                'description': 'Send SMS messages via Vonage',
                'url': 'https://dashboard.nexmo.com/',
                'fields': [
                    {'name': 'api_key', 'label': 'API Key', 'placeholder': 'Your Vonage API Key'},
                    {'name': 'api_secret', 'label': 'API Secret', 'placeholder': 'Your Vonage API Secret'},
                    {'name': 'from_number', 'label': 'From Number', 'placeholder': 'e.g., ZylchAI or +1234567890'}
                ]
            },
            'pipedrive': {
                'display_name': 'Pipedrive CRM',
                'description': 'Sync contacts and deals with Pipedrive',
                'url': 'https://app.pipedrive.com/settings/api',
                'fields': [
                    {'name': 'api_token', 'label': 'API Token', 'placeholder': 'Your Pipedrive API Token'}
                ]
            }
        }

        info = service_info.get(service)
        if not info:
            console.print(f"❌ Configuration not available for {service}", style="red")
            return

        console.print(Panel.fit(
            f"[bold]Connect {info['display_name']}[/bold]\n\n"
            f"{info['description']}\n\n"
            f"Get your credentials at: {info['url']}",
            title=info['display_name'],
            border_style="cyan"
        ))

        # Collect credentials
        credentials = {}
        for field in info['fields']:
            value = Prompt.ask(f"\n{field['label']}", password=(field['name'] in ['api_secret', 'api_token']))
            if not value:
                console.print("❌ Setup cancelled.", style="yellow")
                return
            credentials[field['name']] = value.strip()

        # Save to server
        try:
            result = self.api_client.save_provider_credentials(service, credentials)
            if result.get('success'):
                console.print(f"\n✅ {info['display_name']} connected successfully!", style="green")
                if service == 'vonage':
                    console.print("You can now send SMS messages via the agent.")
                    console.print("Try: \"Send an SMS to +1234567890 saying hello\"")
            else:
                console.print(f"\n⚠️  {result.get('message', 'Unknown error')}", style="yellow")
        except Exception as e:
            console.print(f"\n❌ Error saving credentials: {e}", style="red")

    def _connect_service(self, service: str):
        """Connect a service (Google/Microsoft) via OAuth with local callback.

        Args:
            service: 'google' or 'microsoft'
        """
        service_name = service.capitalize()
        console.print(Panel.fit(
            f"[bold]Connect {service_name} Account[/bold]\n\n"
            f"This will connect your {service_name} account to Zylch.\n"
            f"You'll be able to sync {'Gmail and Calendar' if service == 'google' else 'Outlook and Calendar'}.\n\n"
            "Your browser will open for authentication.",
            title=f"{service_name} OAuth",
            border_style="cyan"
        ))

        try:
            # Check if already connected (Google only for now)
            if service == 'google':
                status = self.api_client.get_google_status()
                if status.get('has_credentials') and not status.get('expired'):
                    email = status.get('email', 'Unknown')
                    console.print(f"\n✅ Already connected as {email}", style="green")
                    console.print("To reconnect, run: /connect --reset")
                    return

            # Use local callback server flow
            result = initiate_service_connect(
                server_url=self.config.api_server_url,
                service=service,
                auth_token=self.config.session_token or '',
                callback_port=8766
            )

            if result is None:
                console.print(f"\n⏱️  Timeout waiting for {service_name} authorization.", style="yellow")
                console.print("If you completed authorization in browser, try again.")
                return

            if 'error' in result:
                console.print(f"\n❌ {service_name} connection failed: {result['error']}", style="red")
                return

            # Success
            email = result.get('email', 'Unknown')
            console.print(f"\n✅ {service_name} connected successfully!", style="green")
            if email and email != 'Unknown':
                console.print(f"Connected as: {email}")
            console.print(f"\nYou can now sync your {'Gmail and Calendar' if service == 'google' else 'Outlook and Calendar'}.")

        except Exception as e:
            console.print(f"❌ Error connecting {service_name}: {e}", style="red")

    def _disconnect_all_services(self):
        """Disconnect all service integrations."""
        console.print(Panel.fit(
            "[bold]Disconnect All Services[/bold]\n\n"
            "This will revoke access to:\n"
            "• Anthropic API key\n"
            "• Google (Gmail, Calendar)\n"
            "• Microsoft (when available)\n\n"
            "You will need to re-configure to use Zylch again.",
            title="Disconnect",
            border_style="yellow"
        ))

        from rich.prompt import Confirm
        if not Confirm.ask("\nAre you sure you want to disconnect all services?"):
            console.print("Cancelled.", style="dim")
            return

        # Disconnect Anthropic
        try:
            status = self.api_client.get_anthropic_status()
            if status.get('has_key'):
                self.api_client.revoke_anthropic()
                console.print("✅ Anthropic API key deleted", style="green")
            else:
                console.print("ℹ️  Anthropic was not configured", style="dim")
        except Exception as e:
            console.print(f"⚠️  Error deleting Anthropic key: {e}", style="yellow")

        # Disconnect Google
        try:
            status = self.api_client.get_google_status()
            if status.get('has_credentials'):
                self.api_client.revoke_google()
                console.print("✅ Google disconnected", style="green")
            else:
                console.print("ℹ️  Google was not connected", style="dim")
        except Exception as e:
            console.print(f"⚠️  Error disconnecting Google: {e}", style="yellow")

        console.print("\n✅ All services disconnected.", style="green")

    def _show_history(self, session_id: Optional[str] = None):
        """Show chat history."""
        try:
            response = self.api_client.get_chat_history(session_id=session_id, limit=20)

            messages = response.get('messages', [])
            if not messages:
                console.print("\n[dim]No messages in this conversation[/dim]")
                return

            console.print("\n[bold]Conversation History:[/bold]")
            for msg in messages:
                role = msg.get('role', '')
                content = msg.get('content', '')
                timestamp = msg.get('timestamp', '')

                if role == 'user':
                    console.print(f"\n[cyan]You[/cyan] ({timestamp}):")
                    console.print(f"  {content}")
                else:
                    console.print(f"\n[green]Zylch[/green] ({timestamp}):")
                    console.print(f"  {content}")

        except ZylchAPIError as e:
            console.print(f"\n❌ Error fetching history: {e}", style="red")


@click.command()
@click.option('--host', default=None, help='Server host (default: from config)')
@click.option('--port', default=None, type=int, help='Server port (default: from config)')
@click.option('--log', type=click.Choice(['debug', 'info', 'warning', 'error']), default='warning', help='Log level')
def main(host, port, log):
    """Zylch - Your AI assistant for email and calendar."""
    # Setup logging based on --log flag
    log_levels = {
        'debug': logging.DEBUG,
        'info': logging.INFO,
        'warning': logging.WARNING,
        'error': logging.ERROR
    }
    logging.basicConfig(
        level=log_levels.get(log, logging.WARNING),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    # Initialize CLI
    cli = ZylchCLI()

    # Override server URL if host/port provided
    if host or port:
        # Parse existing URL to get defaults
        from urllib.parse import urlparse
        parsed = urlparse(cli.config.api_server_url)

        new_host = host or parsed.hostname or 'localhost'
        new_port = port or parsed.port or 9000
        new_scheme = 'https' if new_host not in ['localhost', '127.0.0.1'] else 'http'

        # Build new URL
        server_url = f"{new_scheme}://{new_host}:{new_port}"
        cli.config.api_server_url = server_url
        cli.api_client.server_url = server_url

    # Check server connectivity
    if not cli.check_server():
        sys.exit(1)

    # Launch chat
    cli.chat()


if __name__ == '__main__':
    main()
